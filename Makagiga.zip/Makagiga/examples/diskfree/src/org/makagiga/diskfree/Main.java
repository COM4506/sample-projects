
// API: http://makagiga.sourceforge.net/api/

package org.makagiga.diskfree;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;

import org.makagiga.commons.GeneralSettings;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MMainWindow;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMenuBar;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MSettingsDialog;
import org.makagiga.commons.swing.MSystemTray;
import org.makagiga.console.Console;
import org.makagiga.plugins.LookAndFeelPlugin;
import org.makagiga.plugins.LookAndFeelSettings;
import org.makagiga.plugins.PluginManager;

public class Main extends MApplication {

	private DiskFreePanel diskFreePanel;
	private MMainWindow mainWindow;
	
	public static void main(String[] args) {
		// register config properties for auto read/write
		addConfigEntries(DiskFreeModel.class);
		
		// common initialization
		init(args, "makagiga-diskfree", Main.class);
		
		// initialize plugin manager
		PluginManager.init();
		
		// create application and invoke "startup" on EDT
		launch(Main.class);
	}
	
	@Override
	protected void startup() {
		// use Look And Feel plugin (if available)
		LookAndFeelPlugin.applyLookAndFeel();

		diskFreePanel = new DiskFreePanel();
		mainWindow = new MMainWindow();
		
		MMenuBar menuBar = new MMenuBar();
		
		MMenu fileMenu = new MMenu(i18n("&File"));
			fileMenu.add(new MAction(MActionInfo.SETTINGS, action -> {
				MSettingsDialog dialog = new MSettingsDialog(
					mainWindow,
					MSettingsDialog.STANDARD_DIALOG | MSettingsDialog.APPLY_BUTTON,
					"diskfree" // config ID to remember/restore last visible page
				);
				dialog.getAdvancedButton().setVisible(true);
				dialog.addPage(new DiskFreeSettings(diskFreePanel));
				dialog.addPage(new GeneralSettings());
				dialog.addPage(new LookAndFeelSettings());
				dialog.exec();
			} ));
			fileMenu.addSeparator();
			fileMenu.add(MApplication.getQuitAction());
		menuBar.add(fileMenu);

		MMenu helpMenu = new MMenu(i18n("&Help"));
			helpMenu.add(new Console.Action());
			helpMenu.addSeparator();
			helpMenu.add(new MApplication.AboutAction());
		menuBar.add(helpMenu);
		
		mainWindow.setJMenuBar(menuBar);
		
		mainWindow.add(diskFreePanel);
		mainWindow.setVisible(true);

		// set default focus
		diskFreePanel.focus();

		if (UI.systemTray.get()) {
			MSystemTray.setBackground(Color.WHITE);
			MSystemTray.setVisible(true);
		}

		PluginManager.postInit();
		
		if (DiskFreeModel.showInfo.get()) {
			DiskFreeModel.showInfo.no();
			
			MMessage.info(
				mainWindow,
				"This program demonstrates basic Makagiga API usage.\n" +
				"You can use this API to build your own Java/Swing-based application!\n" +
				"\n" +
				"More Information: http://sf.net/p/makagiga/wiki/SDK"
			);
		}
	}

}
