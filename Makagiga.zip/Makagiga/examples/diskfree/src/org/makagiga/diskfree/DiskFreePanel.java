
package org.makagiga.diskfree;

import static org.makagiga.commons.UI.i18n;

import java.awt.Font;
import java.nio.file.FileStore;
import java.nio.file.FileSystems;

import org.makagiga.chart.ChartPainter;
import org.makagiga.chart.ChartPanel;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MColor;
import org.makagiga.commons.OS;
import org.makagiga.commons.swing.Focusable;
import org.makagiga.commons.swing.MComboBox;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MTimer;
import org.makagiga.commons.swing.MToolBar;

public class DiskFreePanel extends ChartPanel<DiskFreeModel> implements Focusable {
	
	private MComboBox<FileStore> roots;
	private MTimer refreshTimer;
	
	public DiskFreePanel() {
		super(new DiskFreeModel(), MApplication.getTitle());
		
		// init tool bar
		
		MToolBar toolBar = getToolBar();

		roots = new MComboBox<>();
		roots.setCompactSize(true);
		roots.onSelect((self, root) -> {
			DiskFreeModel model = getModel();
			model.setRoot(root);
			refresh();

			// remember last disk
			DiskFreeModel.fs.set(root.toString());
		} );

		toolBar.add(MLabel.createFor(roots, i18n("Disk:")));
		toolBar.addGap();
		toolBar.add(roots);

		toolBar.add(new MAction(i18n("Refresh Disk List"), "ui/refresh",
			action -> refreshRootsList(null)
		));

		// init chart look and feel
		ChartPainter<?> p = getPainter();
		//p.fxShine.no();
		p.outlineBorder.no();
		//p.outlineVisible.no();
		p.textAlpha.set(0.7f);
		p.textBackground.set(MColor.WHITE);
		p.textDistance.set(-5);
		p.textFont.set(new Font(Font.DIALOG, Font.BOLD, 16));
		p.textLineAutoColor.yes();
		p.textLineSize.set(2);
		p.textPadding.set(10);
		//p.textType.set(ChartPainter.TextType.RECT);
		p.textVisible.yes();
		
		refreshRootsList(DiskFreeModel.fs.get());

		// auto refresh every 5 seconds
		refreshTimer = MTimer.seconds(5, timer -> {
			refresh();

			return MTimer.CONTINUE;
		} );
		refreshTimer.start();
	}

	@Override
	public void focus() {
		roots.requestFocusInWindow();
	}

	public void refresh() {
		getModel().refresh();
		getView().repaint();
	}
	
	private void refreshRootsList(String selectFS) {
		roots.setEventsEnabled(false); // do not invoke roots.onSelect()

		roots.removeAllItems();
		for (FileStore i : FileSystems.getDefault().getFileStores()) {
			// skip system FS
			if (!OS.isWindows()) {
				switch (i.type()) {
					case "binfmt_misc":
					case "debugfs":
					case "devpts":
					case "devtmpfs":
					case "proc":
					case "fusectl":
					case "fuse.gvfs-fuse-daemon":
					case "securityfs":
					case "sysfs":
					case "tmpfs":
						continue; // for
				}
			}

			roots.addItem(i);
		}
		
		roots.setSelectedIndex(0);
		if (selectFS != null)
			roots.setSelectedItem(i -> selectFS.equals(i.toString()));

		roots.setEventsEnabled(true); // enable roots.onSelect()
		
		if (!roots.isEmpty())
			getModel().setRoot(roots.getSelectedItem());
		refresh();
	}

}
