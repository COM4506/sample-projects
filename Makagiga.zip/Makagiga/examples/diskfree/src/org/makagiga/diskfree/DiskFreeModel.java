
package org.makagiga.diskfree;

import static org.makagiga.commons.UI.i18n;

import java.io.IOException;
import java.nio.file.FileStore;
import java.util.Objects;

import org.makagiga.chart.ChartModel;
import org.makagiga.commons.BooleanProperty;
import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.EnumProperty;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MFormat;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.StringProperty;
import org.makagiga.commons.annotation.ConfigEntry;

public class DiskFreeModel extends ChartModel {

	@ConfigEntry("DiskFree.showInfo")
	public static final BooleanProperty showInfo = new BooleanProperty(true);

	@ConfigEntry("DiskFree.availableColor")
	public static final ColorProperty availableColor = new ColorProperty(MColor.SKY_BLUE);
	
	@ConfigEntry("DiskFree.usedColor")
	public static final ColorProperty usedColor = new ColorProperty(MColor.getDarker(MColor.RED));
	
	@ConfigEntry("DiskFree.format")
	public static final EnumProperty<MFormat.ByteFormat> format = new EnumProperty<>(MFormat.ByteFormat.AUTO);

	@ConfigEntry(value = "DiskFree.fs", platform = true)
	public static final StringProperty fs = new StringProperty();
	
	public DiskFreeModel() { }
	
	private FileStore root;

	public FileStore getRoot() { return root; }

	public void setRoot(FileStore root) {
		this.root = Objects.requireNonNull(root);
	}
	
	public void refresh() {
		clear(); // remove all model items

		try {
			long free = root.getUsableSpace();
			long total = root.getTotalSpace();

			setFormat("${text} (${percent-int})");

			long used = (total - free);
			addItem(i18n("Used: {0}", MFormat.toSize(used, format.get())), used, usedColor.get());
			addItem(i18n("Available: {0}", MFormat.toSize(free, format.get())), free, availableColor.get());
		}
		catch (IOException exception) {
			setFormat("${text}");
			
			addItem(i18n("Error"), 0, MColor.RED, MIcon.unscaled("ui/error"));
		}
	}

}
