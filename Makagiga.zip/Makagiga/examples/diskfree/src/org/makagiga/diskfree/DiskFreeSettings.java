
package org.makagiga.diskfree;

import static org.makagiga.commons.UI.i18n;

import java.lang.ref.WeakReference;

import org.makagiga.commons.swing.MSettingsPage;

public class DiskFreeSettings extends MSettingsPage {

	private WeakReference<DiskFreePanel> panelRef;
	
	public DiskFreeSettings(DiskFreePanel panel) {
		super(i18n("Chart"), "ui/chart"); // title and icon
		panelRef = new WeakReference<>(panel);
		
		addHeader(i18n("Colors"));
		bind(DiskFreeModel.usedColor, i18n("\"Used\" Color"));
		bind(DiskFreeModel.availableColor, i18n("\"Available\" Color"));
		
		addHeader(i18n("Advanced"));
		bind(DiskFreeModel.format, i18n("Size Format:"));
	}
	
	// OK or Apply button pressed:
	@Override
	protected void onOK() {
		panelRef.get().refresh();
	}

}
