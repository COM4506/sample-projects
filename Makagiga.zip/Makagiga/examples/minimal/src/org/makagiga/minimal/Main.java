
// API: http://makagiga.sourceforge.net/api/

package org.makagiga.minimal;

import static org.makagiga.commons.UI.i18n;

import org.makagiga.commons.MApplication;
import org.makagiga.commons.help.HelpMenu;
import org.makagiga.commons.swing.MMainWindow;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMenuBar;

public class Main extends MApplication {

	public static void main(String[] args) {
		// Initialize the platform.
		init(
			// Parse command line arguments.
			// You can always access all arguments later
			// via org.makagiga.commons.Args.
			args,

			// Set application ID. This ID will be used
			// as the configuration directory (example ~/.makagiga-example-minimal)
			"makagiga-example-minimal",
			
			// Where to find application info resource file
			// (generated automatically by "ant compile" - see "commons.xml")
			Main.class
		);
		
		// Set the "best" look and feel
		// (the actual LAF initialization is invoked on EDT)
		initPlatform(Init.LOOK_AND_FEEL);
		
		// Instantiate "Main" and invoke "startup" on EDT
		launch(Main.class);
	}
	
	@Override
	protected void startup() {
		// Create main window (JFrame-based).
		MMainWindow mainWindow = new MMainWindow();
		
		// Create and set menu bar.
		MMenuBar menuBar = new MMenuBar();
		mainWindow.setJMenuBar(menuBar);
		
		// Create menus:

		// "_" will automatically translate a String
		// (if language translation is supported).
		// Of course you can still use plain "&File".
		//
		// & - will automatically insert "mnemonic" character
		//     (Alt+F keyboard shortcut)
		MMenu fileMenu = new MMenu(i18n("&File"));
			// Do not use "System.exit(0)" to shutdown application.
			// Use MApplication.quit() or MApplication.getQuitAction() instead.
			fileMenu.add(MApplication.getQuitAction());
		menuBar.add(fileMenu);

		menuBar.add(new HelpMenu());

		// Show the window.
		mainWindow.setVisible(true);
	}

}
