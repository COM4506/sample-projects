// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package makagiga.sdk;

import static java.awt.event.KeyEvent.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import javax.swing.Icon;

import org.makagiga.commons.ComparableItem;
import org.makagiga.commons.FS;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.MProperties;
import org.makagiga.commons.OS;
import org.makagiga.commons.UI;
import org.makagiga.commons.io.MProcess;
import org.makagiga.commons.swing.ActionGroup;
import org.makagiga.commons.swing.MComboBox;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MStatusBar;
import org.makagiga.console.Console;
import org.makagiga.console.ConsoleIO;

final class Projects extends MComboBox<Projects.Info> {
	
	// private
	
	private final File dir;
	private static MProcess currentProcess;
	
	// package
	
	final ActionGroup actionGroup;
	Console console;
	
	// private
	
	private String findAntCommand() {
		StringBuilder s = new StringBuilder();
		
		String antHome = System.getenv("ANT_HOME");
		if (antHome != null) {
			File antBinDir = new File(antHome, "bin");
			if (antBinDir.exists() && antBinDir.isDirectory()) {
				s.append(antBinDir);
				s.append(File.separator);
			}
		}
		
		if (OS.isWindows())
			s.append("ant.bat");
		else
			s.append("ant");

		return s.toString();
	}
	
	private void run(final String... commandAndArgs) {
		Info projectInfo = getSelectedItem();
		
		if (projectInfo == null) {
			MStatusBar.error("Please create a new project first...");
			
			return;
		}

		File projectDir = projectInfo.getValue();
		try {
			console.getOutput().setText(null);

			ConsoleIO io = console.getIO();
			io.printLine(io.createColorAttr(MColor.BLUE), String.join(" ", commandAndArgs));
			
			ProcessBuilder pb = new ProcessBuilder(commandAndArgs);
			pb.directory(projectDir);
			
			// HACK: Ant may pick wrong Java version
			if (OS.isLinux()) {
				String javaHome = System.getProperty("java.home");
				if (javaHome != null) {
					File f = new File(javaHome);
					if (f.isDirectory())
						pb.environment().put("JAVA_HOME", javaHome);
				}
			}
			
			currentProcess = new MProcess(pb, System.out, System.err) {
				@Override
				protected void onRedirectComplete() {
					Projects.currentProcess = null;
					UI.invokeLater(new Runnable() {
						@Override
						public void run() {
							Projects.this.updateRunActions();
						}
					} );
				}
			};
		}
		catch (IOException exception) {
			MMessage.error(null, exception);
		}
	}
	
	private void updateRunActions() {
		boolean running = (currentProcess != null);
		for (ActionGroup.Item i : actionGroup) {
			if (i.getAction() instanceof RunAction) {
				i.getAction().setEnabled(!running);
			}
		}
		actionGroup.setEnabled("stop", running && !isEmpty());
	}
	
	// package protected
	
	Projects(final File dir) {
		this.dir = dir;
		setCompactSize(true);

		String antCommand = findAntCommand();
		
		setRenderer(ComparableItem.createListCellRenderer());
		setToolTipText("Project List");
		
		actionGroup = new ActionGroup();

		actionGroup.add("run", new RunAction("Run", "ui/run", VK_F9, 0, antCommand, "run"))
			.setShowTextInToolBar(true);
		actionGroup.add("compile", new RunAction("Compile", "ui/misc", VK_F8, 0, antCommand, "compile"))
			.setShowTextInToolBar(true);

		actionGroup.addSeparator();

		actionGroup.add("stop", new MAction("Stop", "ui/stop", action -> {
			currentProcess.kill();
			currentProcess = null;
			updateRunActions();
		} ));

		actionGroup.addSeparator();

		actionGroup.add("bugs", new RunAction("Find Bugs", "ui/warning", VK_F7, ALT_MASK, antCommand, "bugs"))
			.setVisibleInToolBar(false);
		actionGroup.add("test", new RunAction("Test Project", "ui/ok", VK_F6, ALT_MASK, antCommand, "test"))
			.setVisibleInToolBar(false);

		actionGroup.addSeparator()
			.setVisibleInToolBar(false);
		
		actionGroup.add("clean", new RunAction("Clean Project", "ui/clearright", VK_F10, SHIFT_MASK, antCommand, "clean"))
			.setVisibleInToolBar(false);
		actionGroup.add("dist", new RunAction("Create Plugin Packages (.mgplugin file)", "ui/download", 0, 0, antCommand, "dist"))
			.setVisibleInToolBar(false);
		actionGroup.add("open", new MAction(MActionInfo.BROWSE, action -> {
			Info projectInfo = getSelectedItem();
			if (projectInfo == null) {
				MStatusBar.error("Please create a new project first...");
			}
			else {
				Path projectDir = projectInfo.getValue().toPath().normalize();
				MApplication.openURI(projectDir.toUri());
			}
		} ))
			.setVisibleInToolBar(false);

		updateRunActions();
		
		refresh(null);
	}
	
	void refresh(final String internalName) {
		removeAllItems();
		
		Info select = null;
		
		for (File i : FS.listFiles(dir, FS.DIRECTORY_FILTER)) {
			File propertiesFile = new File(i, "plugin.properties");
			if (propertiesFile.exists()) {
				try {
					Info info = new Info(i, propertiesFile);
					addItem(info);

					if ((select == null) && (internalName != null) && internalName.equals(i.getName()))
						select = info;
				}
				catch (IllegalArgumentException exception) {
					MLogger.info("sdk", "Loading Project... %s", i.getName());
					MMessage.error(UI.windowFor(this), exception);
				}
				catch (IOException exception) {
					MLogger.exception(exception);
				}
			}
		}
		
		sort();
		
		if (select != null)
			setSelectedItem(select);
	}
	
	// private classes
	
	private final class RunAction extends MDataAction<String[]> {
		
		// public
		
		@Override
		public void onAction() {
			Projects.this.run(this.getData());
			Projects.this.updateRunActions();
		}
		
		// private
		
		private RunAction(final String name, final String iconName, final int keyCode, final int modifiers, final String... commandAndArgs) {
			super(commandAndArgs, name, iconName);
			this.setToolTipText(String.join(" ", commandAndArgs));
			if (keyCode != 0)
				this.setAcceleratorKey(keyCode, modifiers);
		}
		
	}
	
	// package protected classes
	
	static final class Info extends ComparableItem<File> {
		
		// private
		
		private final MProperties properties;
		
		// public
		
		@Override
		public String getText() {
			String text = super.getText();
			if (text == null) {
				String type = properties.getProperty("String.type", null);
				if (type == null)
					type = "?";
				text = (getValue().getName() + " (" + type + ")");
				setText(text);
			}
			
			return text;
		}
		
		// protected

		@Override
		protected Icon createIcon() {
			String iconName = properties.getProperty("String.icon", null);
			
			if (iconName != null)
				return MIcon.medium(iconName);

			File iconFile = new File(getValue(), "icon.png");
			
			if (iconFile.exists())
				return MIcon.get(iconFile, MIcon.getMediumSize());
				
			return MIcon.medium("ui/error");
		}

		// private
		
		private Info(final File dir, final File propertiesFile) throws IOException {
			super(dir);
			
			properties = new MProperties();
			properties.loadUTF8(propertiesFile);
		}
		
	}

}
