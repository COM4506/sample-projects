// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package makagiga.sdk;

import static java.awt.event.KeyEvent.*;

import java.awt.Window;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Path;
import java.util.Locale;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import makagiga.sdk.Template.Macro;
import org.makagiga.Main;
import org.makagiga.commons.Args;
import org.makagiga.commons.FS;
import org.makagiga.commons.GeneralSettings;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MCalendar;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MDate;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.OS;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.VersionProperty;
import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.form.Field;
import org.makagiga.commons.form.Form;
import org.makagiga.commons.form.FormPanel;
import org.makagiga.commons.form.Info;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.script.ScriptYourself;
import org.makagiga.commons.swing.MCheckBox;
import org.makagiga.commons.swing.MComboBox;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MLinkAction;
import org.makagiga.commons.swing.MLinkButton;
import org.makagiga.commons.swing.MMainWindow;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMenuBar;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MSettingsDialog;
import org.makagiga.commons.swing.MText;
import org.makagiga.commons.swing.MTextField;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.commons.swing.MWizardDialog;
import org.makagiga.commons.validator.PropertyValidator;
import org.makagiga.commons.validator.TextComponentValidator;
import org.makagiga.commons.validator.URLValidator;
import org.makagiga.console.Console;
import org.makagiga.console.ConsoleIO;
import org.makagiga.plugins.LookAndFeelPlugin;
import org.makagiga.plugins.LookAndFeelSettings;
import org.makagiga.plugins.PluginManager;
import org.makagiga.plugins.PluginType;

public final class SDK extends MApplication {

	private static File baseDir;
	private static File projectsDir;
	private static Projects projects;

	public static void main(final String... args) {
		// init application
		init(args, "makagiga-sdk", Main.class);
		//initPlatform(Init.LOOK_AND_FEEL);
		setDescription("Create and test Makagiga plugins");

		Args.add("base-dir", "Base directory");

		MLogger.developer.set(true);
		
		// init paths

		// base directory
		String baseDirOption = Args.getOption("base-dir"); // used in "start.sh"
		if (baseDirOption == null)
			baseDirOption = System.getProperty("user.dir");
		baseDir = new File(baseDirOption);
		MLogger.debug("sdk", "Base Directory = \"%s\"", baseDir);

		// projects directory (relative to the base directory)
		projectsDir = new File(baseDir, FS.makePath("..", "Projects"));
		MLogger.debug("sdk", "Projects Directory = \"%s\"", projectsDir);

		// template directory
		Template.dir = new File(baseDir, "template");
		MLogger.debug("sdk", "Template Directory = \"%s\"", Template.dir);

		// validate path
		if (!Template.dir.exists()) {
			MMessage.error(null, "Invalid base directory:\n" + baseDir);

			return;
		}

		// create the SDK application
		launch(SDK.class);
	}

	/**
	 * Create and show the main window.
	 */
	@Override
	protected void startup() {
		LookAndFeelPlugin.applyLookAndFeel();

		Console console = new Console(false);
		ConsoleIO io = console.getIO();
		io.redirectOutput();

		console.getCommandLinePanel().setVisible(false);
		console.getToolBar().setVisible(false);
		io.printLine();
		io.printLine(io.createColorAttr(MColor.DARK_GRAY), "Makagiga SDK");
		io.printLine();
		
		projects = new Projects(projectsDir);
		projects.console = console;
		
		MMainWindow window = new MMainWindow();
		window.setTitle(getTitle());
		window.setSize(UI.WindowSize.MEDIUM);
		window.setLocationRelativeTo(null); // center on screen
		
		window.addCenter(console);

		// init menu bar

		MMenuBar menuBar = new MMenuBar();
		menuBar.putClientProperty("org.makagiga.commons.MLogger.noMemoryButton", true);

		// file menu

		MMenu fileMenu = new MMenu("&File");

		MAction newProjectAction = new MAction("New Project...", "ui/newfile",
			action -> new Wizard(window)
		);
		newProjectAction.setAcceleratorKey(VK_N, MAction.getMenuMask());
		fileMenu.add(newProjectAction);

		fileMenu.addSeparator();

		fileMenu.add(new MAction(MActionInfo.SETTINGS, action -> {
			MSettingsDialog dialog = new MSettingsDialog(
				window,
				MSettingsDialog.STANDARD_DIALOG | MSettingsDialog.APPLY_BUTTON,
				"sdk" // config ID to remember/restore last visible page
			);
			dialog.getAdvancedButton().setVisible(true);
			dialog.addPage(new GeneralSettings());
			dialog.addPage(new LookAndFeelSettings());
			dialog.exec();
		} ));

		fileMenu.addSeparator();

		fileMenu.add(getQuitAction());

		menuBar.add(fileMenu);
		
		// project menu
		
		MMenu projectMenu = projects.actionGroup.createMenu("&Project");
		menuBar.add(projectMenu);
		
		// help menu

		MMenu helpMenu = new MMenu("&Help");
		
		helpMenu.add(new MLinkAction(URI.create("http://sourceforge.net/p/makagiga/wiki/Home/"), "Wiki"));
		
		helpMenu.addSeparator();

		Path basePath = baseDir.toPath().normalize();
		
		// NOTE: sync. with ScriptIDE
		helpMenu.add(new MLinkAction(basePath.resolve("API/index.html").toUri(), "Makagiga API"));
		helpMenu.add(new MLinkAction(URI.create("http://docs.oracle.com/javase/8/docs/api/"), "Java" + UI.TM + " 8 SE API"));
		helpMenu.addSeparator();
		helpMenu.add(new MLinkAction(URI.create("http://docs.oracle.com/javase/8/docs/technotes/guides/scripting/"), "Scripting for the Java Platform"));
		helpMenu.add(new MLinkAction(URI.create("http://www.w3schools.com/js/"), "JavaScript Tutorial"));

		MMenu requirementsMenu = new MMenu("Requirements");
			requirementsMenu.add(new MLinkAction(URI.create("http://www.oracle.com/technetwork/java/javase/downloads/index.html"), "Java" + UI.TM +" SE 8 (JDK)"));
			requirementsMenu.add(new MLinkAction(URI.create("http://ant.apache.org/"), "Ant"));
			requirementsMenu.add(new MLinkAction(URI.create("http://www.gnu.org/software/gettext/"), "Gettext Utilities"));
			requirementsMenu.add(new MLinkAction(URI.create("http://findbugs.sourceforge.net/"), "FindBugs" + UI.TM));
		helpMenu.add(requirementsMenu);

		helpMenu.addSeparator();

		helpMenu.add(new MLinkAction(basePath.resolve("doc/README.html").toUri(), "README"));
		helpMenu.add(new AboutAction());

		menuBar.add(helpMenu);

		window.setJMenuBar(menuBar);
		
		// init tool bar
		
		MToolBar toolBar = new MToolBar();
		toolBar.setTextPosition(MToolBar.TextPosition.ALONGSIDE_ICONS);
		
		toolBar.add(newProjectAction, MToolBar.SHOW_TEXT);
		
		toolBar.addGap();
		
		projects.actionGroup.updateToolBar(toolBar);
		toolBar.add(projects);
		
		toolBar.addGap();
		
		ScriptYourself.install(toolBar, "sdk");
		
		window.addNorth(toolBar);

		window.setVisible(true);
	}

	private static final class Wizard extends MWizardDialog implements ChangeListener {

		private MCheckBox wantScript;
		private MComboBox<LicenseItem> licenses;
		private MComboBox<PluginType> pluginTypes;
		private MLabel finishMessage;
		private MLinkButton directoryInfo;
		private final Page internalNamePage;
		private final Page packageNamePage;
		private final Page projectInfoPage;
		
		private final FormPanel<ProjectInfoForm> projectInfoPanel;
		private final FormPanel<ProjectInternalNameForm> projectInternalNamePanel;
		private final FormPanel<ProjectPackageForm> projectPackagePanel;

		@Override
		public void stateChanged(final ChangeEvent e) {
			if (isDone())
				onFinish();
			else
				onPageChange();
		}
		
		private void createCommons(final String projectDir) throws IOException {
			String licenseFile = FS.makePath("licenses", licenses.getSelectedItem().getValue());
			Template.copy(
				licenseFile,
				FS.makePath(projectDir, "LICENSE.txt")
			);
			Template.copy("README.txt", projectDir);
			Template.copy("icon.png", projectDir);
			
			File poDir = new File(projectDir, "po");
			poDir.mkdirs();
		}

		private void createNetBeansProject(final String projectDir) throws IOException {
			ProjectInfoForm projectInfo = projectInfoPanel.getForm();

			String netBeansProjectDir = FS.makePath(projectDir, "nbproject");
			String netBeansProjectLibs;
			if (projectInfo.libs.isEmpty())
				netBeansProjectLibs = "";
			else
				netBeansProjectLibs = (":" + TK.escapeXML(projectInfo.libs).replace(' ', ':'));
			new File(netBeansProjectDir).mkdir();
			Template.copy(
				"netbeans-project.xml",
				FS.makePath(netBeansProjectDir, "project.xml"),
				new Macro("PROJECT_LIBS", netBeansProjectLibs),
				new Macro("PROJECT_NAME", TK.escapeXML(projectInfo.name))
			);
		}

		private void createProperties(final String projectDir, final PluginType pluginType) throws IOException {
			ProjectInfoForm projectInfo = projectInfoPanel.getForm();
			ProjectInternalNameForm projectInternalName = projectInternalNamePanel.getForm();
			ProjectPackageForm projectPackage = projectPackagePanel.getForm();

			String pluginClassName =
				wantScript.isSelected() && pluginType.isScriptSupport()
			        ? "String.scriptName=main.js"
			        : "String.className=" + projectPackage.packageName + ".Plugin";
			
			Template.copy(
				FS.makePath(pluginType.getType(), "PROPERTIES.properties"),
				FS.makePath(projectDir, "plugin.properties"),
				new Macro(
					"PLUGIN_TRANSLATION",
					(pluginType == PluginType.LOCALE) && projectInfo.languageTranslation
					? "String.translation=application"
					: ""
				)
			);

			Template.copy(
				"plugin.properties",
				projectDir,
				new Macro("LICENSE_NAME", licenses.getSelectedItem().getText()),
				new Macro("LICENSE_URL", licenses.getSelectedItem().getURL()),
				new Macro("PLUGIN_CLASS_NAME", pluginClassName),
				new Macro("PLUGIN_TYPE", pluginType.getType()),
				new Macro(
					"PLUGIN_WHERE_TEXT",
					(pluginType == PluginType.CONSOLE)
					? "${console} -> TODO: command name"
					: ""
				),
				new Macro("PROJECT_COPYRIGHT", projectInfo.copyright),
				new Macro("PROJECT_DESCRIPTION", projectInfo.description),
				new Macro("PROJECT_HOME_PAGE", projectInfo.homePage.isEmpty() ? ProjectInfoForm.DEFAULT_HOME_PAGE : projectInfo.homePage),
				new Macro("PROJECT_ID", projectInternalName.pluginID.trim()),
				new Macro("PROJECT_LIBS", projectInfo.libs),
				new Macro("PROJECT_NAME", projectInfo.name),
				new Macro("PROJECT_VERSION", projectInfo.version.isEmpty() ? "1.0" : projectInfo.version)
			);
		}
		
		private void createTest(final String projectDir) throws IOException {
			File testDir = new File(projectDir, FS.makePath("test", "src"));
			testDir.mkdirs();
			Template.copy(
				"TestDefault.java",
				testDir.getPath()
			);
		}
		
		private void onFinish() {
			ProjectInfoForm projectInfo = projectInfoPanel.getForm();
			ProjectInternalNameForm projectInternalName = projectInternalNamePanel.getForm();
			ProjectPackageForm projectPackage = projectPackagePanel.getForm();

			// init package name

			projectPackage.packageName = TK.toLowerCase(projectPackage.packageName.trim());

			// save text auto completion
			projectInfoPanel.writeConfig(null);
			projectInternalNamePanel.writeConfig(null);
			projectPackagePanel.writeConfig(null);

			// init package directory (foo.bar -> foo/bar)
			String packageDir = projectPackage.packageName;
			packageDir = packageDir.replace('.', File.separatorChar);

			// init project directory
			File projectPath = new File(projectsDir, projectInternalName.internalName);
			projectPath.mkdirs();
			String projectDir = projectPath.getPath();

			final PluginType pt = pluginTypes.getSelectedItem();

			try { // IOException exception

			createCommons(projectDir);

			String pluginType = pt.getType();
			if (wantScript.isSelected() && pt.isScriptSupport()) {
				// copy script template
				Template.copy(
					FS.makePath(pluginType, "SCRIPT.js"),
					FS.makePath(projectDir, "main.js")
				);
				// create "resources" dir
				new File(projectDir, "resources").mkdirs();
			}
			else {
				String srcDir = FS.makePath(projectDir, "src");
				String absolutePackageDir = FS.makePath(srcDir, packageDir);
				new File(absolutePackageDir).mkdirs();

				// copy template files
				Template.copy(
					FS.makePath(pluginType, "CLASS.java"),
					FS.makePath(absolutePackageDir, "Main.java"),
					new Macro("PROJECT_PACKAGE_NAME", projectPackage.packageName)
				);
				Template.copy(
					"ChangeLog",
					projectDir,
					new Macro("DATE_YYYYMMDD", MDate.now().format("yyyy-MM-dd", Locale.ENGLISH)),
					new Macro("PROJECT_VERSION", projectInfo.version)
				);
				Template.copy(
					FS.makePath(pluginType, "PLUGIN.java"),
					FS.makePath(absolutePackageDir, "Plugin.java"),
					new Macro("PROJECT_PACKAGE_NAME", projectPackage.packageName)
				);
			}

			// create build.xml file

			Template.copy(
				"build.xml.template",
				FS.makePath(projectDir, "build.xml"),
				new Macro("PROJECT_INTERNAL_NAME", TK.escapeXML(projectInternalName.internalName)),
				new Macro("PROJECT_NAME", TK.escapeXML(projectInfo.name)),
				// PROJECT_PACKAGE_DIR: always use "/"; this fixes URL class loader
				new Macro("PROJECT_PACKAGE_DIR", TK.escapeXML(packageDir.replace('\\', '/'))),
				new Macro("PROJECT_PACKAGE_NAME", TK.escapeXML(projectPackage.packageName))
			);

			createNetBeansProject(projectDir);
			createProperties(projectDir, pt);
			createTest(projectDir);

			}
			catch (IOException exception) {
				MMessage.error(this, exception);
			}

			// show final messages

			Path projectLocation = projectPath.toPath().normalize();
			directoryInfo.setURIAndText(projectLocation.toUri());

			switch (pt) {
				case INTERNET_SEARCH:
				case LOOK_AND_FEEL:
					finishMessage.setHTML("<b>Hint</b>: See \"plugin.properties\" file for more plugin settings...");
					break;
				case LOCALE:
					new File(projectDir, "resources").mkdir();
					break;
			}
			
			projects.refresh(projectInternalName.internalName);

			complete(); // show "Close" button
		}

		private void onPageChange() {
			ProjectInfoForm projectInfo = projectInfoPanel.getForm();
			ProjectInternalNameForm projectInternalName = projectInternalNamePanel.getForm();
			ProjectPackageForm projectPackage = projectPackagePanel.getForm();

			Page page = getCurrentPage();
			if (page == internalNamePage) {
				// create internal name from the project name
				projectInternalName.internalName = projectInfo.name.trim();
				// remove all non-word or digit characters
				projectInternalName.internalName = projectInternalName.internalName.replaceAll("(\\W|\\d)", "");
				projectInternalName.internalName = TK.toLowerCase(projectInternalName.internalName);
				projectInternalNamePanel.updateView();
				projectInternalNamePanel.makeDefault("internalName");
			}
			else if (page == packageNamePage) {
				String s = projectInternalName.internalName.trim();
				projectPackage.packageName = "your.unique.packagename." + TK.toLowerCase(s);
				projectPackagePanel.updateView();
				projectPackagePanel.makeDefault("packageName");
			}
			else if (page == projectInfoPage) {
				projectInfoPanel.makeDefault("name");
				projectInfoPanel.setEnabled("languageTranslation", pluginTypes.getSelectedItem() == PluginType.LOCALE);
			}
		}

		private Wizard(final Window parent) {
			super(parent, "New Project");

			addPage("Plugin Type", MIcon.stock("ui/plugin"), null, createPluginTypePanel());
			
			projectInfoPanel = createPanel(new ProjectInfoForm());
			
			MTextField copyrightField = projectInfoPanel.getWrappedComponent("copyright");
			String copyrightUser = OS.getUserFullName();
			String copyrightYear = Integer.toString(MCalendar.now().getYear());
			copyrightField.setText("Copyright (C) " + copyrightYear + " " + copyrightUser);

			AutoCompletion ac = MText.getAutoCompletion(copyrightField);
			ac.addStaticItem("(C) " + copyrightYear + " " + copyrightUser);
			ac.addStaticItem("Copyright (C) " + copyrightYear + " " + copyrightUser);

			projectInfoPage = addPage("Project Info", MIcon.stock("ui/info"), null, projectInfoPanel);

			projectInternalNamePanel = createPanel(new ProjectInternalNameForm());
			internalNamePage = addPage("Internal Name", MIcon.stock("ui/info"), null, projectInternalNamePanel);

			projectPackagePanel = createPanel(new ProjectPackageForm());
			packageNamePage = addPage("Package Name", MIcon.stock("ui/info"), null, projectPackagePanel);
			
			addPage("Finish", MIcon.stock("ui/ok"), null, createFinishPanel());
			addChangeListener(this);

			pack();
			exec(pluginTypes);
		}

		private MPanel begin() {
			MPanel p = MPanel.createVBoxPanel();
			p.setContentMargin();

			return p;
		}

		private MPanel createFinishPanel() {
			MPanel p = begin();

			MLabel dirLabel = new MLabel("Your new project has been created in:");
			p.add(dirLabel);

			p.addGap();

			directoryInfo = new MLinkButton();
			dirLabel.setLabelFor(directoryInfo);
			directoryInfo.setShowLinkActions(false);
			p.add(directoryInfo);

			p.addGap();

			finishMessage = new MLabel();
			p.add(finishMessage);

			end(p);
			
			return p;
		}

		private <T> FormPanel<T> createPanel(final T form) {
			FormPanel<T> panel = new FormPanel<>(form);
			panel.setContentMargin();
			panel.addStretch();
			panel.alignLabels();
			panel.addValidators(this);
			
			return panel;
		}

		private MPanel createPluginTypePanel() {
			MPanel p = begin();
			pluginTypes = new MComboBox<>();
			pluginTypes.onSelect((self, type) -> {
				if (wantScript != null)
					wantScript.setEnabled(type.isScriptSupport());
			} );
			pluginTypes.setRenderer(new MRenderer<PluginType>() {
				@Override
				protected void onRender(final PluginType value) {
					setIcon(value.getIcon());

					StringBuilder s = new StringBuilder(value.getText());
					switch (value) {
						case CONSOLE:
							s.append(" - a Console command");
							break;
						case EDITOR:
							s.append(" - a document editor/viewer (example: Notepad)");
							break;
						case FILE_SYSTEM:
							s.append(" - a Virtual File System (example: Feeds, Trash)");
							break;
						case GENERAL:
							s.append(" - other plugins (example: Pastebin)");
							break;
						case INTERNET_SEARCH:
							s.append(" - a search provider for the Internet Search widget");
							break;
						case LIBRARY:
							s.append(" - a Java library (example: SQL Database)");
							break;
						case LOCALE:
							s.append(" - a language translation, spell checker dictionary...");
							break;
						case LOOK_AND_FEEL:
							s.append(" - a skin, color theme, or icon theme...");
							break;
						case WIDGET:
							s.append(" - a small useful application (example: Clock)");
							break;
					}
					setText(s.toString());
				}
			} );
			pluginTypes.addAllItems(PluginType.values());
			pluginTypes.setMaximumRowCount(-1);
			MPanel pluginTypesPanel = MPanel.createHLabelPanel(pluginTypes, "Plugin Type:");
			pluginTypesPanel.limitHeight();
			p.add(pluginTypesPanel);

			p.addContentGap();

			wantScript = new MCheckBox("Use JavaScript Language");
			wantScript.setEnabled(false);

			HTMLBuilder html = HTMLBuilder.newSwingDoc();
			html.appendBulletList(
				"Java - faster, consumes less memory",
				"JavaScript - easy to write and modify"
			);
			html.endSwingDoc();
			wantScript.setToolTipText(html.toString());

			p.add(wantScript);

			p.addContentGap();
			
			licenses = new MComboBox<>();
			licenses.addAllItems(LicenseItem.list());
			MPanel licensesPanel = MPanel.createHLabelPanel(licenses, "Plugin License:");
			licensesPanel.limitHeight();
			p.add(licensesPanel);

			p.addStretch();

			end(p);
			
			return p;
		}

		private void end(final MPanel p) {
			p.addStretch();
			p.alignLabels();
		}

	}

	@Form(order = {
		"nameAndVersion", "name", "description",
		"versionText", "version",
		"homePageAndCopyright", "homePage",
		"authorText", "copyright", "advanced",
		"libsText", "libs", "languageTranslation"
	} )
	@SuppressFBWarnings("URF_UNREAD_FIELD")
	private static final class ProjectInfoForm {

		private static final String DEFAULT_HOME_PAGE = "http://makagiga.sourceforge.net/";

		@Info(type = Info.TYPE_SEPARATOR)
		private String nameAndVersion = "Plugin Name and Version";

		// name

		@Field(label = "Name:", autoCompletion = "sdk-project-name", validators = ProjectNameValidator.class)
		private String name;

		// description

		@Field(label = "Description:", autoCompletion = "sdk-project-description", validators = ProjectDescriptionValidator.class)
		private String description;

		// version

		@Info(type = Info.TYPE_HTML, style = "font-size: smaller; margin-top: " + MPanel.DEFAULT_CONTENT_MARGIN)
		private String versionText =
			"A project version number in the following format: " + HTMLBuilder.createCode("mm.ii[.bb] (mm - major, ii - minor, bb - bugfix/update)") + "<br>" +
			"Examples: " + HTMLBuilder.createCode("1.0, 2.5.10-beta, 0.0.7");

		@Field(label = "Version:", autoCompletion = "sdk-project-version", validators = ProjectVersionValidator.class)
		private String version = "1.0";

		@Info(type = Info.TYPE_SEPARATOR)
		private String homePageAndCopyright = "Plugin Home Page and Copyright";

		// home page
			
		@Field(label = "Home Page URL:", autoCompletion = "sdk-project-home-page", validators = URLValidator.class)
		private String homePage = DEFAULT_HOME_PAGE;

		// copyright

		@Info(type = Info.TYPE_TEXT, style = "font-size: smaller; margin-top: " + MPanel.DEFAULT_CONTENT_MARGIN)
		private String authorText = "A short copyright notice (authors, company, etc...)";

		@Field(label = "Copyright:", autoCompletion = "sdk-project-copyright")
		private String copyright;

		// libs

		@Info(type = Info.TYPE_SEPARATOR)
		private String advanced = "Advanced";

		@Info(type = Info.TYPE_HTML, style = "font-size: smaller")
		private String libsText =
			"A space separated list of additional JAR files used by the plugin.<br>" +
			"Example: " + HTMLBuilder.createCode("foo.jar bar.jar") + "<br>" +
			"NOTE: Don't forget to place the above Jars in the \"Project Directory\".";

		@Field(label = "Required Libraries (.jar files):", autoCompletion = "sdk-libs")
		private String libs = "";

		@Field(label = "Language Translation")
		private boolean languageTranslation;

	}

	@Form(order = "info,internalName,advanced,pluginID")
	@SuppressFBWarnings("URF_UNREAD_FIELD")
	private static final class ProjectInternalNameForm {

		@Info(type = Info.TYPE_HTML)
		private String info =
			"An internal project name. Example: " + HTMLBuilder.createCode("kitchensink") + "<br>" +
			"NOTE: This name will be used in some file names<br>" +
			"so it cannot contain space or any other special characters.";

		@Field(label = "Internal Name:", autoCompletion = "sdk-internal-name", validators = ProjectInternalNameValidator.class)
		private String internalName;

		@Info(type = Info.TYPE_SEPARATOR)
		private String advanced = "Advanced";

		@Field(label = "Random/Unique Plugin ID:", validators = ProjectPluginIDValidator.class)
		private String pluginID = TK.createRandomUUID();

	}

	@Form(order = "info,packageName,more")
	@SuppressFBWarnings("URF_UNREAD_FIELD")
	private static final class ProjectPackageForm {
	
		@Info(type = Info.TYPE_HTML)
		private String info = 
			"An unique package name for your class files.<br>" +
			"Example: " + HTMLBuilder.createCode("com.example.plugins.foo");
			
		@Field(label = "Package Name:", autoCompletion = "sdk-package-name", validators = PackageNameValidator.class)
		private String packageName;

		@Field(label = "Read more about packages...")
		private URI more = URI.create("https://docs.oracle.com/javase/tutorial/java/package/packages.html");

	}

	// validators

	public static final class PackageNameValidator extends TextComponentValidator {

		// public

		public PackageNameValidator() { }

		// protected

		@Override
		protected boolean isValid() throws Exception {
			String s = getText().trim();

			if (s.isEmpty())
				throw new Exception("Package name cannot be empty");

			if (s.chars().anyMatch(Character::isWhitespace))
				throw new Exception("No whitespace allowed");

			String[] packageParts = s.split("\\.");
			for (String i : packageParts) {
				if (i.isEmpty())
					throw new Exception("Invalid package name");

				if (!i.isEmpty() && !Character.isLetter(i.charAt(0))) {
					throw new Exception("Non-letter character after '.' (" + i + ")");
				}
			}

			return true;
		}

	}

	public static final class ProjectDescriptionValidator extends TextComponentValidator {

		// public

		public ProjectDescriptionValidator() { }

		// protected

		@Override
		protected boolean isValid() throws Exception {
			String s = getText().trim();

			if (s.isEmpty()) {
				setMessageType(MessageType.INFO);

				throw new Exception("Enter a short plugin description...");
			}

			return true;
		}

	}

	public static final class ProjectInternalNameValidator extends TextComponentValidator {

		// public

		public ProjectInternalNameValidator() { }

		// protected

		@Override
		protected boolean isValid() throws Exception {
			String s = getText().trim();

			if (s.isEmpty())
				throw new Exception("Internal name cannot be empty");

			if (s.chars().anyMatch(Character::isWhitespace))
				throw new Exception("No whitespace allowed");

			if (new File(SDK.projectsDir, s).exists())
				throw new Exception("Project with this name already exists");

			return true;
		}

	}

	public static final class ProjectNameValidator extends TextComponentValidator {

		// public

		public ProjectNameValidator() { }

		// protected

		@Override
		protected boolean isValid() throws Exception {
			String s = getText().trim();

			if (s.isEmpty())
				throw new Exception("Enter a short human readable project name");

			return true;
		}

	}

	public static final class ProjectPluginIDValidator extends TextComponentValidator {

		// public

		public ProjectPluginIDValidator() { }

		// protected

		@Override
		protected boolean isValid() throws Exception {
			PluginManager.validatePluginID(getText().trim());

			return true;
		}

	}

	public static final class ProjectVersionValidator extends PropertyValidator {

		// public

		public ProjectVersionValidator() {
			setProperty(new VersionProperty());
		}

	}

}
