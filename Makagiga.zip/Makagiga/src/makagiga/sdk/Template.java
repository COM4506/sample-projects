// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package makagiga.sdk;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.AbstractMap;

import org.makagiga.commons.FS;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;

final class Template {
	
	// package protected
	
	static File dir;
	
	// package protected
	
	/**
	 * Copy template file to the destination location.
	 * 
	 * @param from the source file located in the "template" directory
	 * @param to the destination location (file or directory)
	 * @param replace an array of text to find-and-replace (text files only)
	 */
	static void copy(final String from, final String to, final Replace... replace) throws IOException {
		// init source file
		File sourceFile = new File(dir, from);
		if (!sourceFile.exists()) {
			MLogger.debug("template", "\"%s\" does not exist. Skipping...", sourceFile);

			return;
		}

		// init destination file
		File destinationFile = new File(to);
		if (destinationFile.isDirectory())
			destinationFile = new File(to, sourceFile.getName());

		MLogger.debug("template", "Copying \"%s\" to \"%s\"...", sourceFile, destinationFile);

		if (TK.isEmpty(replace)) {
			// copy binary file
			FS.copyFile(sourceFile, destinationFile);
		}
		else {
			// copy text file
			String text = readText(new FS.BufferedFileInput(sourceFile), replace);
			if (destinationFile.exists()) {
				// append text to the end of existing file
				FS.write(new FileOutputStream(destinationFile, true), text);
			}
			else {
				FS.write(destinationFile, text);
			}
		}

		// copy attributes
		destinationFile.setExecutable(sourceFile.canExecute());
	}

	// private
	
	@Uninstantiable
	private Template() { }

	/**
	 * Reads UTF-8 text from @p input,
	 * and replaces all matching text using @p replace array.
	 * 
	 * @return {@code null} if read failed
	 */
	private static String readText(final InputStream input, final Replace... replace) throws IOException {
		StringBuilder result = FS.readLines(input, "UTF8", true);
		for (Replace i : replace) {
			if (result.indexOf(i.getKey()) == -1) {
				MLogger.debug("template", "Unused macro \"" + i + "\"");
			}
			else {
				TK.fastReplace(result, i.getKey(), i.getValue());
			}
		}

		return result.toString();
	}

	// package protected classes
	
	static final class Macro extends Replace {
		
		// package protected

		Macro(final String name, final String text) {
			super("@@" + name + "@@", text);
		}

	}

	static class Replace extends AbstractMap.SimpleEntry<String, String> {
		
		// package protected

		Replace(final String before, final String after) {
			super(before, after);
		}

	}

}
