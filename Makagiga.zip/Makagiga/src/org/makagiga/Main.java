// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// TODO: 2.0: export to HTML for all files (via "HTML writer" interface)
// TODO: 2.0: Serving selected files via http/https, File sharing (?)
package org.makagiga;

import static org.makagiga.commons.UI.i18n;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.net.URI;

import org.makagiga.commons.Args;
import org.makagiga.commons.Benchmark;
import org.makagiga.commons.Config;
import org.makagiga.commons.FS;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MFormat;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.VersionProperty;
import org.makagiga.commons.cache.FileCache;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MNotification;
import org.makagiga.commons.swing.MSplashScreen;
import org.makagiga.console.ConsoleIO;
import org.makagiga.internetsearch.InternetSearchPlugin;
import org.makagiga.plugins.LookAndFeelPlugin;
import org.makagiga.plugins.PluginDownloader;
import org.makagiga.plugins.PluginInfo;
import org.makagiga.plugins.PluginManager;
import org.makagiga.search.Index;
import org.makagiga.todo.TaskState;

/** The main Makagiga class. */
public final class Main extends MApplication {

	// private
	
	private static Benchmark startupBenchmark;
	
	// package
	
	static long startTime;
	
	// public

	/**
	 * The main function.
	 * Use @ref org.makagiga.commons.Args to access @p args.
	 * @param args A command line arguments
	 */
	public static void main(final String... args) {
		startTime = System.currentTimeMillis();
	
		if (mainSDK(args))
			return;
		
		addConfigEntries(Vars.class);

		init(args, "makagiga", Main.class);
		initArgs();

		if (Args.isSet("test-time"))
			startupBenchmark = Benchmark.begin("core");

		if (!checkOneInstance())
			return;

		statReset();
		initPlatform(Init.AUTHENTICATOR, Init.PROXY, Init.TIPS, Init.USER_AGENT);
		stat("PLATFORM INIT");

		Config config = Config.getDefault();

		// check version change
		VersionProperty internalVersion = getInternalVersion();
		VersionProperty lastVersion = new VersionProperty();
		lastVersion.read(config, "lastVersion");

		if (!lastVersion.equals(internalVersion)) {
			int lastNumber = lastVersion.get();

			//MLogger.info("core", "Version changed: %s -> %s", lastVersion, internalVersion);
			internalVersion.write(config, "lastVersion");
			config.write("updatePlugins", lastNumber != 0);
			config.sync();
			
			// pre 3.7.2 Beta
			if (lastNumber < 0x03_07_02) {
				//MLogger.info("core", "Fixing search-index cache...");
				Index.getInstance().clear();
			}
		}

		// HACK: Default Security Manager (if any)
		// may cause minor incompatibilities.
		System.setSecurityManager(null);

		statReset();
		initPlugins();
		stat("PLUGINS INIT");

		statReset();
		ConsoleIO.install();
		stat("CONSOLE INIT");

		FileCache.setMaximumGroupSize(MFormat.MB * (FS.isPortable() ? 50 : 100));

		launch(Main.class); // init and show main window

		if (startupBenchmark != null)
			quit();
	}

	// protected

/* TEST:
	@org.makagiga.commons.form.Form
	public static final class FormTest {
		@org.makagiga.commons.form.Field(label="Label")
		private boolean checkBox;
	}
*/

	@Override
	protected void startup() {
/* TEST:
		org.makagiga.commons.form.FormPanel<FormTest> panel = new org.makagiga.commons.form.FormPanel<>(new FormTest());
		panel.getForm().checkBox = true;
		panel.updateView();
		panel.createDialog(null, "Test").exec();
		System.out.println(panel.getForm().checkBox);
		System.exit(0);
*/

		Config config = Config.getDefault();
		TaskState.readConfig(config, "Tasks");

		MSplashScreen.setProgressBarBounds(5, 9);

		if (!isSafeMode()) {
			statReset();
			LookAndFeelPlugin.applyLookAndFeel(); // after plugin init, EDT
			stat("LAF INIT");
		}

		statReset();
		MainWindow mainWindow = MainWindow.getInstance();
		stat("MAIN WINDOW INIT");

		if (config.read("updatePlugins", false)) {
			if (mainWindow.isLocked()) {
				// show update notification after main window unlock
				mainWindow.addPropertyChangeListener(new PropertyChangeListener() {
					@Override
					public void propertyChange(final PropertyChangeEvent e) {
						if (TK.isProperty(e, MainWindow.LOCKED_PROPERTY, false)) {
							MainWindow.getInstance().removePropertyChangeListener(this);

							MAccessController.doPrivileged(() -> {
								updatePlugins();
									
								return null;
							} );
						}
					}
				} );
			}
			else {
				updatePlugins();
			}
		}

		addShutDownListener(e -> {
			Index.getInstance().shutDown();
			if (MainWindow.isInstance())
				MainWindow.getInstance().saveSession(Tabs.QUIET_SAVE);
		} );
	}
	
	// private
	
	private static void initArgs() {
		Args.add("autostart", i18n("Start application in minimized or hidden window"));
		Args.add("full-screen", i18n("Start application in full screen window"));
		Args.add("test-plugin", "Used internally by the Makagiga SDK");
		Args.add("test-time", "Used internally to test Makagiga startup time");
	}
	
	private static void initPlugins() {
		PluginManager.defaultSource.set(URI.create("http://makagiga.sourceforge.net/stuff.xml.gz"));
		// TEST: PluginManager.defaultSource.set(URI.create("file:///tmp/stuff.xml.gz"));
		// TEST: PluginManager.defaultSource.set(URI.create("http://makagiga.sourceforge.net/stuff.php?v3=1"));
		// TEST: http://127.0.0.1/~kdt/upload/stuff.php?v3=1
		PluginManager.publicKeyAlias.set("makagiga");
		PluginManager.signatureFileName.set("MAKAGIGA");
		
		PluginManager.init();
		PluginManager plugins = PluginManager.getInstance();
		// desktop
		plugins.registerInternal("org/makagiga/desktop/calendar");
		plugins.registerInternal("org/makagiga/desktop/internetsearch");
		plugins.registerInternal("org/makagiga/desktop/note");
		plugins.registerInternal("org/makagiga/desktop/todo");
		// editor
		plugins.registerInternal("org/makagiga/editors/image");
		plugins.registerInternal("org/makagiga/editors/link");
		plugins.registerInternal("org/makagiga/editors/notepad");
		plugins.registerInternal("org/makagiga/editors/text");
		plugins.registerInternal("org/makagiga/editors/todo");
		// fs
		plugins.registerInternal("org/makagiga/fs/feeds");
		plugins.registerInternal("org/makagiga/fs/trash");
		// general
		plugins.registerInternal("org/makagiga/tools/backup");
		plugins.registerInternal("org/makagiga/tools/deleteprivatedata");
		plugins.registerInternal("org/makagiga/tools/stats");
		plugins.registerInternal("org/makagiga/tools/update");
		// internet search
		InternetSearchPlugin.init();
		
		// plugin test
		String pluginTestDir = Args.getOption("test-plugin");
		if (pluginTestDir != null) {
			MLogger.developer.set(true);
			MLogger.info("plugin", "Testing \"%s\" plugin...", pluginTestDir);
			if (!plugins.registerExternal(new File(pluginTestDir), PluginManager.REGISTER_TEST | PluginManager.REGISTER_UNPACK)) {
				MMessage.error(
					null,
					"Cannot register plugin.\n" +
					"Try to uninstall current plugin before test.\n" +
					"See \"standard output\" log messages for more details..."
				);
			}
		}
	}

	@SuppressWarnings("PMD.SystemPrintln")
	private static boolean mainSDK(final String... args) {
		if (args.length > 0) {
			switch (args[0]) {
			case "--test-profile": {
				System.out.println("Press <Enter> to continue...");
				try {
					FS.newBufferedReader(System.in) // no close
						.readLine();
				}
				catch (IOException exception) {
					MLogger.exception(exception);
				}
			} break;
			} // switch
		}

		return false;
	}

	private static void stat(final String text) {
		if (startupBenchmark != null)
			startupBenchmark.end(text);
	}

	private static void statReset() {
		if (startupBenchmark != null)
			startupBenchmark.reset();
	}

	private static void updatePlugins() {
		MLogger.info("core", "Starting plugin update");

		Config config = Config.getDefault();
		config.write("updatePlugins", false);
		config.sync();

		if (PluginManager.getInstance().canUpdate()) {
			MNotification.Message updateMessage = new MNotification.Message();
			updateMessage.setAction(new MAction(MActionInfo.UPDATE, action ->
				PluginDownloader.update(MainWindow.getInstance())
			));
			updateMessage.setColor(MColor.DARK_GREEN);
			updateMessage.setText(i18n("Click here to update plugins"));
			updateMessage.show();
		}
	}
	
	// package
	
	static boolean isTodoPluginEnabled() {
		PluginManager pm = PluginManager.getInstance();
		
		PluginInfo pi1 = pm.getByID("{0f04e3a2-05a8-4c41-9d66-a6619479eafd}");
		PluginInfo pi2 = pm.getByID("{9afcf313-d31d-4d23-ba63-24451a691552}");
		
		return
			((pi1 != null) && pi1.enabled.get()) ||
			((pi2 != null) && pi2.enabled.get());
	}

}
