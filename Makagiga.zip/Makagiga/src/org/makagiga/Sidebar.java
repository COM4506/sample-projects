// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.JComponent;

import org.makagiga.commons.Config;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.MComponent;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.MSettingsDialog;
import org.makagiga.commons.swing.MSplitPane;
import org.makagiga.commons.swing.MToggleButton;
import org.makagiga.commons.swing.MWhatsThis;
import org.makagiga.commons.swing.event.PopupAdapter;
import org.makagiga.editors.Designer;
import org.makagiga.editors.Editor;
import org.makagiga.tools.summary.SummaryPanel;
import org.makagiga.tree.Tree;
import org.makagiga.tree.TreePanel;

/**
 * The Sidebar.
 * 
 * @since 3.0
 */
public final class Sidebar extends MPanel {
	
	// public
	
	public enum Tab {
	
		// public

		TREE(i18n("Tree"), "ui/tree", i18n("Tree - all files and folders")),
		SUMMARY(i18n("Tasks"), "labels/todo", i18n("Summary - all tasks ({0})", UI.toString(VK_S, CTRL_MASK + SHIFT_MASK))),
		DESIGNER(i18n("Properties"), "ui/wizard", i18n("Tools and properties ({0})", "F4"));

		// private

		private String iconName;
		private String title;
		private String toolTipText;

		// public

		/**
		 * @since 3.8
		 */
		public String getIconName() { return iconName; }

		public String getTitle() { return title; }

		public String getToolTipText() { return toolTipText; }

		// private

		private Tab(final String title, final String iconName, final String toolTipText) {
			this.title = title;
			this.iconName = iconName;
			this.toolTipText = toolTipText;
		}

	}

	// private

	private final ButtonGroup buttonGroup = new ButtonGroup();
	private Designer currentDesigner;
	private final MArrayList<Button> buttonList = new MArrayList<>();
	private MPanel buttonPanel;
	private MPanel mainPanel;
	private final MScrollPane designerScrollPane;
	private static Sidebar _instance = new Sidebar();
	private Tab lastTab;

	// public

	/**
	 * Adds a new sidebar tab.
	 * @param component A component visible in the sidebar tab
	 * @param id An ID of the component
	 *
	 * @throws NullPointerException If @p component is @c null
	 * @throws IllegalArgumentException If @p id is @c null or empty
	 */
	public Button addTab(final JComponent component, final String id) {
		return addTab(component, id, null, null, null);
	}

	/**
	 * Adds a new sidebar tab.
	 * @param component A component visible in the sidebar tab
	 * @param id An ID of the component
	 * @param onInit An action invoked when the tab is initialized
	 * @param onShow An action invoked when the tab becomes visible
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * Sidebar.Button button = Sidebar.getInstance().addTab(new MCalendarPanel(), "calendar");
	 * button.setText("Calendar");
	 * button.setIcon(MIcon.small("ui/calendar"));
	 * </pre>
	 *
	 * @throws NullPointerException If @p component is @c null
	 * @throws IllegalArgumentException If @p id is @c null or empty
	 */
	public Button addTab(final JComponent component, final String id, final Action onInit, final Action onShow) {
		return addTab(component, id, onInit, onShow, null);
	}

	public Button getButtonFor(final Tab tab) {
		for (Button i : buttonList) {
			if (i.tab == tab)
				return i;
		}
		
		return null;
	}

	/**
	 * @since 3.8.9
	 */
	public List<Button> getButtonList() {
		return Collections.unmodifiableList(buttonList);
	}

	/**
	 * @since 3.8.9
	 */
	public MPanel getButtonPanel() { return buttonPanel; }

	/**
	 * @since 4.10
	 */
	public Designer getDesigner() { return currentDesigner; }
	
	public void setDesigner(final Designer newDesigner) {
		// update components
		Button button = getButtonFor(Tab.DESIGNER);
		button.setEnabled(newDesigner != null);

		Container oldContainer = (currentDesigner == null) ? null : MScrollPane.getScrollPane(currentDesigner);
		if (oldContainer == null)
			oldContainer = currentDesigner;

		Container newContainer;
		if (newDesigner == null) {
			designerScrollPane.setViewportView(null);
			newContainer = null;
		}
		else {
			if (newDesigner.isScrollable()) {
				designerScrollPane.setViewportView(newDesigner);
				newContainer = designerScrollPane;
			}
			else {
				designerScrollPane.setViewportView(null);
				newContainer = newDesigner;
			}
		}

		MComponent.replace(mainPanel, oldContainer, newContainer, Tab.DESIGNER.name(), false);
		currentDesigner = newDesigner;
	}

	/**
	 * @since 3.8
	 */
	public MIcon.Size getIconSize() {
		return Vars.sidebarSmallIcons.get() ? MIcon.Size.SMALL : MIcon.Size.DEFAULT;
	}

	/**
	 * Returns an instance of the Sidebar.
	 */
	public static Sidebar getInstance() { return _instance; }

	/**
	 * @since 3.8.9
	 */
	public MPanel getMainPanel() { return mainPanel; }
	
	public void goTo(final Tab tab) {
		goTo(tab, true);
	}

	/**
	 * Switches to the @p tab.
	 */
	public void goTo(final Tab tab, final boolean focus) {
		// remember "last tab" before switch
		for (Button i : buttonList) {
			if (i.isSelected()) {
				if (i.tab != lastTab)
					lastTab = i.tab;
				
				break; // while
			}
		}

		if (!isSelected(tab)) {
			// do not select disabled "Designer" tab
			if (!getButtonFor(tab).isEnabled() && (tab == Tab.DESIGNER))
				return;

			selectTab(tab);
		}

		switch (tab) {
			case TREE:
				if (focus) {
					MainWindow.showSidebar();
					final Tree tree = Tree.getInstance();
					tree.requestFocusInWindow();
					tree.focusItem(Tabs.getInstance().getCurrentMetaInfo());
				}
				break;
			case SUMMARY:
				if (focus)
					SummaryPanel.getInstance().focus();
				break;
			case DESIGNER:
				if (focus && (currentDesigner != null))
					MComponent.requestFocus(currentDesigner);
				break;
			default:
				throw new WTFError(tab);
		}
	}

	/**
	 * Returns @c true if "Designer" is selected.
	 */
	public boolean isDesignerSelected() {
		return isSelected(Tab.DESIGNER);
	}

	public boolean isSelected(final Tab tab) {
		return getButtonFor(tab).isSelected();
	}

	/**
	 * Returns @c true if "Summary" is selected.
	 */
	public boolean isSummarySelected() {
		return isSelected(Tab.SUMMARY);
	}

	/**
	 * Returns @c true if "Tree" is selected.
	 */
	public boolean isTreeSelected() {
		return isSelected(Tab.TREE);
	}
	
	public void selectLastTab() {
		if (lastTab != null)
			selectTab(lastTab);
	}

	// private

	private Sidebar() {
		designerScrollPane = new MScrollPane(MScrollPane.NO_BORDER | MScrollPane.FAST_SCROLL);

		MWhatsThis.set(this, i18n("Sidebar"))
			.setKeyStroke(VK_F9);
		mainPanel = MPanel.createCardPanel();
		addCenter(mainPanel);

		buttonPanel = MPanel.createGridPanel(1, 1);
		for (Tab i : Tab.values())
			addTab(null, i.name(), null, null, i);
		addSouth(buttonPanel);

		// add Tree panel and make it selected
		getButtonFor(Tab.TREE).setSelected(true);
		mainPanel.add(TreePanel.getInstance(), Tab.TREE.name());

		mainPanel.add(SummaryPanel.getInstance(), Tab.SUMMARY.name());
	}

	private Button addTab(final JComponent component, final String id, final Action onInit, final Action onShow, final Tab tab) {
		if (tab == null) {
			Objects.requireNonNull(component);
			TK.checkNullOrEmpty(id, "id");
		}
		
		Button button = new Button(id, onInit, onShow, tab);
		buttonGroup.add(button);
		buttonList.add(button);

		if (tab == Tab.DESIGNER) {
			MWhatsThis.set(button, "")
				.setKeyStroke(VK_F4);
		}
		else if (tab == Tab.SUMMARY) {
			if (!Main.isTodoPluginEnabled())
				button.setVisible(false);
		}

		if (button.isVisible() && button.isVisibleInSidebar()) {
			GridLayout layout = (GridLayout)buttonPanel.getLayout();
			if (layout.getRows() == buttonPanel.getComponentCount())
				layout.setRows(layout.getRows() + 1);
			buttonPanel.add(button);
		}
		else {
			button.setVisible(false);
		}
		
		if (component != null)
			mainPanel.add(component, id);
		
		return button;
	}
	
	private void selectTab(final Tab tab) {
		Button button = getButtonFor(tab);
		
		if (!button.isEnabled())
			return;
		
		if (!button.isSelected())
			button.setSelected(true);
		
		mainPanel.showCard(tab.name());
	}
	
	private void showButtonMenu(final InputEvent e) {
		MMenu menu = new MMenu();
		for (final Button i : buttonList) {
			Icon icon;
			if (getIconSize() == MIcon.Size.SMALL)
				icon = i.getIcon();
			else if (i.tab != null)
				icon = MIcon.small(i.tab.getIconName());
			else
				icon = null;
		
			MAction action = new MAction(i.getText(), icon, self -> {
				i.setVisibleInSidebar(self.isSelected());
				updateLayout();
			} );
			
			// "Tree" panel is always visible
			if (i.tab == Tab.TREE)
				action.setEnabled(false);
			
			menu.addCheckBox(action, i.isVisible());
		}
		
		menu.addSeparator();

		MAction smallIconsAction = new MAction(i18n("Small Icons"), action -> {
			Vars.sidebarSmallIcons.set(action.isSelected());
			updateIconSize();
		} );
		menu.addCheckBox(smallIconsAction, Vars.sidebarSmallIcons.get());
		
		menu.showPopup(e);
	}
	
	private void updateIconSize() {
		boolean hasPluginButtons = false;
	
		for (Button button : buttonList) {
			Sidebar.Tab tab = button.tab;
			if (tab != null)
				button.setIcon(MIcon.stock(tab.getIconName(), getIconSize()));
			else
				hasPluginButtons = true;
		}
		
		if (hasPluginButtons)
			MSettingsDialog.showRestartInfo();
	}
	
	private void updateLayout() {
		int numVisible = 0;
		for (Button i : buttonList) {
			if (i.isVisible())
				numVisible++;
		}
		buttonPanel.removeAll();
		GridLayout layout = (GridLayout)buttonPanel.getLayout();
		layout.setRows(numVisible);
		for (Button i : buttonList) {
			if (i.isVisible())
				buttonPanel.add(i);
		}
		buttonPanel.revalidate();
	}

	// package

	static void show(final Tab tab, final boolean toggle, final MSplitPane mainSplitPane) {
		Sidebar sidebar = getInstance();
		mainSplitPane.setSidebarVisible(true);
		if (tab != null) {
			if (toggle) {
				if (sidebar.isSelected(tab))
					sidebar.selectLastTab();
				else
					sidebar.goTo(tab);
			}
			else {
				sidebar.goTo(tab);
			}
		}
	}

	void update(final Editor<?> editor, final Designer designer, final MAction toggleDesignerAction) {
		Button button = getButtonFor(Tab.DESIGNER);
		setDesigner(designer);
		if (designer == null) {
			button.setText(Tab.DESIGNER.getTitle());

			if (isDesignerSelected())
				goTo(Tab.TREE, false);
			toggleDesignerAction.setEnabled(false);
		}
		else {
			button.setText(Objects.toString(designer.getDisplayText(), Tab.DESIGNER.getTitle()));

			designer.repaint(); // required
			if (editor != null)
				designer.setLocked(!editor.getMetaInfo().canModify());
			toggleDesignerAction.setEnabled(true);

			// HACK: switch back to designer after update
			if (isDesignerSelected())
				button.select();
		}
		toggleDesignerAction.setName(i18n("Toggle: {0}", button.getText()));
	}
	
	// public classes
	
	/**
	 * A sidebar button.
	 */
	public final class Button extends MToggleButton {
		
		// private

		private final Action onInit;
		private final Action onShow;
		private boolean initDone;
		private final Sidebar.Tab tab;
		private final String id;

		// private
		
		private Button(final String id, final Action onInit, final Action onShow, final Sidebar.Tab tab) {
			this.onInit = onInit;
			this.onShow = onShow;
			this.tab = tab;
			this.id = id;
			setToolTipLocationPolicy(UI.ToolTipLocationPolicy.ALONGSIDE);
			
			if (tab != null) {
				if (tab == Tab.SUMMARY) {
					// show progress info; this text will be updated later
					// in SummaryData.updateAlarms()
					setText(i18n("Tasks ({0})", i18n("Loading...")));
				}
				else {
					setText(tab.getTitle());
				}
				setIcon(MIcon.stock(tab.getIconName(), Sidebar.this.getIconSize()));
				setToolTipText(tab.getToolTipText());
			}

			new PopupAdapter(Sidebar.this::showButtonMenu)
				.install(this);
		}
		
		// public

		@Override
		public Dimension getMinimumSize() {
			Dimension d = super.getMinimumSize();

			return new Dimension(50, d.height);
		}

		@Obsolete
		@Override
		public Point getToolTipLocation(final MouseEvent e) {
			return super.getToolTipLocation(e);
		}

		@Obsolete
		@Override
		public String getToolTipText(final MouseEvent e) {
			return super.getToolTipText(e);
		}
		
		public void select() {
			MainWindow.showSidebar();
			TK.fireActionPerformed(this, this.getActionListeners());
		}
		
		@Override
		public void updateUI() {
			if (UI.isQuaqua())
				putClientProperty("JButton.buttonType", "gradient");
			super.updateUI();
			setHorizontalAlignment(LEADING);
			setRequestFocusEnabled(false);
			if (!UI.isQuaqua())
				setStyle("padding: 0 5 0 5");
		}
		
		// protected
		
		@Override
		protected void onClick() {
			if (tab == null) {
				if (!initDone) {
					initDone = true;
					if (onInit != null)
						MAction.fire(onInit, this);
				}
				Sidebar.this.mainPanel.showCard(id);
				if (onShow != null)
					MAction.fire(onShow, this);
				this.setSelected(true);
			}
			else {
				Sidebar.this.selectTab(tab);
			}
		}
		
		// private
		
		private boolean isVisibleInSidebar() {
			String KEY = "Sidebar." + id + ".visible";
			SecurityManager sm = System.getSecurityManager();

			if (sm == null)
				return Config.getDefault().read(KEY, true);

			return MAccessController.doPrivileged(() ->
				Config.getDefault().read(KEY, true)
			);
		}

		private void setVisibleInSidebar(final boolean value) {
			setVisible(value);
			Config config = Config.getDefault();
			config.write("Sidebar." + id + ".visible", value);
			config.sync();
		}

	}

}
