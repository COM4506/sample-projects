// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import javax.swing.KeyStroke;

import org.makagiga.commons.ClipboardException;
import org.makagiga.commons.Flags;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MClipboard;
import org.makagiga.commons.MDate;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.PassiveException;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.html.HTMLSelection;
import org.makagiga.commons.swing.Focusable;
import org.makagiga.commons.swing.MComponent;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MSettingsDialog;
import org.makagiga.commons.swing.MStatusBar;
import org.makagiga.commons.swing.MTabbedPane;
import org.makagiga.commons.swing.MWhatsThis;
import org.makagiga.commons.swing.MainView;
import org.makagiga.commons.swing.Mnemonic;
import org.makagiga.commons.swing.border.MLineBorder;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.editors.Editor;
import org.makagiga.editors.EditorConfig;
import org.makagiga.editors.EditorCrypto;
import org.makagiga.editors.EditorDesigner;
import org.makagiga.editors.EditorPlugin;
import org.makagiga.fs.AbstractFS;
import org.makagiga.fs.FSHelper;
import org.makagiga.fs.MetaInfo;
import org.makagiga.fs.MetaInfoAction;
import org.makagiga.fs.trash.TrashFS;
import org.makagiga.plugins.PluginManager;
import org.makagiga.plugins.PluginMenu;
import org.makagiga.tabs.DesktopTab;
import org.makagiga.tools.SessionManager;

/**
 * The tabs.
 * 
 * @since 3.0
 */
public final class Tabs extends MTabbedPane<Editor<?>> {

	// public

	// "closeEditorAt" flags

	/**
	 * Remove tab component.
	 */
	public static final int REMOVE_TAB = 1;

	/**
	 * Save editor before remove.
	 */
	public static final int SAVE_TO_FILE = 1 << 1;

	/**
	 * Do not invoke {@link #fireStateChanged()}.
	 *
	 * @since 5.0
	 */
	public static final int NO_CHANGE_EVENT = 1 << 2;

	// "saveEditor" flags

	/**
	 * Normal save.
	 */
	public static final int NORMAL_SAVE = 1;

	/**
	 * Quiet save (no message boxes).
	 */
	public static final int QUIET_SAVE = 1 << 1;

	// private

	private final AccessControlContext acc;
	private boolean inMiddleButtonEvent;
	private final KeyStroke historyKeyStroke = KeyStroke.getKeyStroke(VK_T, MAction.getMenuMask() | SHIFT_MASK);
	private final LinkedList<MetaInfo> recentlyClosedTabs = new LinkedList<>();
	private static Tabs _instance;

	// private actions
	private final CloseAction closeAction = new CloseAction();
	private final CloseAllAction closeAllAction = new CloseAllAction();
	private final CloseAllOthersAction closeAllOthersAction = new CloseAllOthersAction();
	
	// package
	
	boolean removingTab;

	// public
	
	public void addEditor(final Editor<?> editor) {
		AccessController.doPrivileged(new PrivilegedAction<Void>() {
			@Override
			public Void run() {
				addEditorPrivileged(editor);

				return null;
			}
		}, acc);
	}
	
	private void addEditorPrivileged(final Editor<?> editor) { // private
		MetaInfo metaInfo = editor.getMetaInfo();
		if (metaInfo != null)
			metaInfo.setOpen(true);
		
		recentlyClosedTabs.remove(metaInfo);
		
		addTab(null, editor);
		int tabIndex = indexOfComponent(editor);
		if (tabIndex == -1)
			MLogger.error("editor", "Tabs.indexOfComponent(editor) == -1");

		setTabInfo(editor, metaInfo);
		setSelectedComponent(editor);
		if (editor instanceof Focusable)
			Focusable.class.cast(editor).focus();
		if (metaInfo != null)
			metaInfo.refresh(false);
		
		// load config
		if (editor instanceof EditorConfig)
			EditorConfig.class.cast(editor).loadConfig(metaInfo.getConfig());
	}
	
	public void addRecentlyClosedTab(final MetaInfo metaInfo) {
		if (!metaInfo.isAnyFile())
			return;

		recentlyClosedTabs.remove(metaInfo);
		recentlyClosedTabs.addFirst(metaInfo);
	}

	/**
	 * Closes editor at the specified index.
	 * @param index A tab index
	 * @param aFlags Flags (e.g. @ref REMOVE_TAB)
	 */
	public void closeEditorAt(final int index, final int aFlags) {
		Editor<?> editor = getTabAt(index);

		if (editor == null)
			return;

		if (!editor.isCloseable())
			return;
		
		Flags flags = Flags.valueOf(aFlags);

		if (flags.isSet(SAVE_TO_FILE)) {
			// do not close on error
			//MLogger.info("editor", "Close: Saving \"%s\"...", editor.getMetaInfo());

			if (!saveEditor(editor, NORMAL_SAVE))
				return;
		}

		if (!editor.onBeforeClose())
			return;

		if (flags.isSet(REMOVE_TAB)) {
			//MLogger.info("editor", "Close: Remove tab: %d", index);
			try {
				removingTab = true;
				removeTabAt(index);
			}
			// HACK: "Comparison method violates its general contract!"
			// http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6923200
			// http://www.java.net/node/700601
			catch (IllegalArgumentException exception) {
				MLogger.exception(exception);
			}
			finally {
				removingTab = false;
			}
			// HACK: fire event after "removeTabAt"
			// to avoid focus transfer problems.
			if (flags.isClear(NO_CHANGE_EVENT))
				fireStateChanged();
		}
		
		MMenu.hideCurrentPopup();

		MetaInfo metaInfo = editor.getMetaInfo();
		metaInfo.setOpen(false);
		editor.destroy();
		metaInfo.refresh(false);
		
		addRecentlyClosedTab(metaInfo);
	}

	public MMenu createRecentlyClosedTabsMenu() {
		MMenu menu = new MMenu(MActionInfo.HISTORY);
		menu.onSelect(this::updateRecentlyClosedTabsMenu);
		
		return menu;
	}
	
	public MMenu createTabsMenu() {
		MMenu menu = new MMenu(i18n("Tabs"));
		MetaInfo metaInfo = getCurrentMetaInfo();
		if (metaInfo != null)
			menu.addSeparator(TK.rightSqueeze(metaInfo.toString(), 50));
		menu.add(closeAction);
		menu.add(closeAllAction);
		menu.add(closeAllOthersAction);
		PluginManager.updateMenu(menu, PluginMenu.TABS_MENU, false);
		
		return menu;
	}

	public void deletePrivateData() {
		recentlyClosedTabs.clear();
	}

	/**
	 * @since 4.0
	 */
	@SuppressWarnings("unchecked")
	public <T extends Editor<?>> T findByID(final String id) {
		for (Editor<?> i : this) {
			if (id.equals(i.getClientProperty(Editor.ID_PROPERTY)))
				return (T)i;
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	public <T extends Editor<?>> T findEditor(final Class<T> clazz) {
		for (Editor<?> i : this) {
			if ((i != null) && (i.getClass().equals(clazz)))
				return (T)i;
		}
		
		return null;
	}
	
	/**
	 * Finds editor with @p metaInfo.
	 * @return An editor index, or -1 if editor could not be found
	 */
	public int findEditor(final MetaInfo metaInfo) {
		return (metaInfo == null) ? -1 : findEditor(metaInfo.getFilePath());
	}

	/**
	 * Finds editor with @p path.
	 * @return An editor index, or -1 if editor could not be found
	 */
	public int findEditor(final String path) {
		if (TK.isEmpty(path))
			return -1;

		for (Editor<?> i : this) {
			if ((i != null) && i.getMetaInfo().getFilePath().equals(path))
				return indexOfComponent(i);
		}

		return -1;
	}
	
	public MAction getCloseAction() { return closeAction; }
	
	public MAction getCloseAllAction() { return closeAllAction; }

	/**
	 * Returns the active editor's meta info (current tab).
	 */
	public MetaInfo getCurrentMetaInfo() {
		Editor<?> editor = getSelectedTab();

		if (editor == null)
			return null;

		return editor.getMetaInfo();
	}

	/**
	 * Creates and returns the instance of the tabs.
	 */
	public synchronized static Tabs getInstance() {
		if (_instance == null) {
			Tabs tabs = new Tabs(); // set "_instance" in constructor
			tabs.restoreBorderContentInsets();
		}

		return _instance;
	}
	
	/**
	 * @since 3.0
	 */
	public List<MetaInfo> getRecentlyClosedTabs() { return recentlyClosedTabs; }
	
	public Editor<?> getTabAt(final MetaInfo metaInfo) {
		int i = findEditor(metaInfo);
		
		return (i == -1) ? null : getTabAt(i);
	}

	public synchronized boolean openEditor(final MetaInfo metaInfo) {
		if (metaInfo == null) {
			MLogger.trace();
			MLogger.error("editor", "Null meta info");

			return false;
		}

		if (TrashFS.isInTrash(metaInfo)) {
			MStatusBar.warning(i18n("Cannot open file from the Trash"));

			return false;
		}

		int editorIndex = findEditor(metaInfo); // file already open?
		if (editorIndex != -1) {
			// select already open file
			selectEditorAt(editorIndex);

			return true;
		}

		// open new file
		Editor<?> editor;
		try {
			editor = EditorPlugin.createEditorForPath(metaInfo.getFilePath());

// TODO: 2.0: autodownload/suggest a missing plugin
			if (editor == null) {
				MStatusBar.warning(i18n("Could not open \"{0}\" file (disabled or missing plugin): {1}", metaInfo.getFileExtension(), metaInfo.getNicePath()));

				return false;
			}
			
			// check core
			if (editor.getCore() == null)
				throw new Exception(editor.getClass().getName() + ": getCore() == null");
		}
		catch (Exception exception) {
			MMessage.error(UI.windowFor(null), exception, i18n("Could not open file"));

			return false;
		}

		editor.setMetaInfo(metaInfo);

		// load file
		MLogger.info("editor", "Loading \"%s\"...", metaInfo.getFilePath());
		//MStatusBar.message(i18n("Loading..."));
		UI.setWaitCursor(true);
		try {
			while (true) {
				try {
					editor.loadFromFile();
				}
				catch (EditorCrypto.InvalidPasswordException exception) {
					MLogger.exception(exception);
					MMessage.error(UI.windowFor(this), exception.getLocalizedMessage());

					continue; // try to enter password again
				}
				
				break; // all ok
			}
			metaInfo.setLastOpenTime();
			
			boolean readOnly = !metaInfo.canModify();
			editor.setLocked(readOnly);
			if (editor instanceof EditorDesigner<?>)
				EditorDesigner.class.cast(editor).getEditorDesigner().setLocked(readOnly);

			// save to disk if new file
			editor.setModified(metaInfo.getFile().length() == 0);

			addEditor(editor);

			// update designer
			if (editor instanceof EditorDesigner<?>)
				EditorDesigner.class.cast(editor).updateEditorDesigner();

			MStatusBar.ready();

			return true;
		}
		catch (PassiveException exception) {
			// MStatusBar.ready(); - do not change status bar
			MMessage.error(UI.windowFor(null), exception, i18n("Could not open file"));

			return false;
		}
		catch (Exception exception) {
			MStatusBar.ready();
			MMessage.error(UI.windowFor(null), exception, i18n("Could not open file"));
			
			return false;
		}
		finally {
			UI.setWaitCursor(false);
		}
	}

	/**
	 * Saves all open editors (all tabs).
	 */
	public void saveAllEditors(final int flags) {
		for (Editor<?> i : this)
			saveEditor(i, flags);
	}

	/**
	 * Saves @p editor.
	 * See source for details.
	 * @see #openEditor(MetaInfo)
	 */
	public boolean saveEditor(final Editor<?> editor, final int flags) {
		if (editor == null)
			return false;
		
		boolean quiet = (flags & QUIET_SAVE) != 0;
		
		return editor.sync(quiet);
	}
	
	public void selectEditor(final Editor<?> editor) {
		if (editor == null)
			return;

		int i = indexOfComponent(editor);
		if (i != -1) {
			setSelectedIndex(i);
			MComponent.requestFocus(editor);
		}
	}

	/**
	 * Selects and focuses an editor at @p index.
	 */
	public void selectEditorAt(final int index) {
		selectEditor(getTabAt(index));
	}
	
	@Override
	public void setSelectedIndex(final int index) {
		// HACK: middle clicks from BasicTabbedPane
		if (!inMiddleButtonEvent)
			super.setSelectedIndex(index);
	}

	/**
	 * Updates the tab info with @p metaInfo.
	 * Updated tab infos:
	 * - background color
	 * - foreground color
	 * - icon
	 * - tab name
	 * - tool tip text
	 * - editor color
	 *
	 * @deprecated Since 4.2
	 */
	@Deprecated
	public void setTabInfo(final MetaInfo metaInfo) {
		int index = findEditor(metaInfo);
		if (index != -1)
			setTabInfo(null, metaInfo, index);
	}
	
	/**
	 * @since 4.2
	 */
	public void setTabInfo(final Editor<?> tab, final MetaInfo metaInfo) {
		int i = indexOfComponent(tab);
		if (i != -1)
			setTabInfo(tab, metaInfo, i);
	}
	
	private void setTabInfo(Editor<?> editor, final MetaInfo metaInfo, final int index) { // private
		if (editor == null)
			editor = getTabAt(index);
		setColors(metaInfo, index);
		
		TabComponent tabComponent = (TabComponent)getTabComponentAt(index);
		MIcon icon = Vars.tabsSmallIcons.get() ? metaInfo.getSmallIcon() : metaInfo.getIcon();
		if (icon == null)
			icon = Vars.tabsSmallIcons.get() ? MIcon.small("ui/file") : MIcon.stock("ui/file");
		if (tabComponent == null) {
			tabComponent = new TabComponent(this) {
				@Override
				protected void onClick() {
					int i = this.getIndex();
					Editor<?> tab = Tabs.this.getTabAt(i);
					if ((tab != null) && tab.isCloseable())
						Tabs.this.close(i);
					else
						Tabs.this.selectEditorAt(i);
				}
			};
			tabComponent.setColorPosition(MLineBorder.Position.LEFT);
			tabComponent.getTextLabel()
				.setHTMLEnabled(false);
			
			if (!editor.isCloseable()) {
				TabIcon ti = tabComponent.getTabIcon();
				ti.setSafeAction(false);
				ti.setToolTipText(null);
			}
			setTabComponentAt(index, tabComponent);
		}
		tabComponent.setIcon(icon);

		// HACK: A03 does not support tab scrolling
		if (UI.isA03())
			tabComponent.setText(TK.rightSqueeze(metaInfo.toString(), 50));
		else
			tabComponent.setText(metaInfo.toString());
	}

	/**
	 * Updates tabs state (sets active editor, updates actions and colors).
	 */
	public void updateState() {
		Editor<?> editor = getSelectedTab();
		boolean isEditor = editor != null;
		closeAction.setEnabled(isEditor && editor.isCloseable());
		closeAllAction.setEnabled(isEditor && (getTabCount() > 1));
		closeAllOthersAction.setEnabled(isEditor && (getTabCount() > 1));
		updateColors();

		for (Editor<?> i : this)
			Mnemonic.setExcluded(i, (i instanceof DesktopTab) || (i != editor));
		new Mnemonic(this);
	}
	
	@Override
	public void updateUI() {
		if (UI.isQuaqua()) {
			putClientProperty("Quaqua.Component.visualMargin", new Insets(/*-*/3, -3, -3, -3));
			putClientProperty("Quaqua.TabbedPane.contentBorderPainted", false);
		}

		super.updateUI();
		
		if (UI.isGTK())
			setBorder(null);
	}
	
	// protected
	
	@Override
	protected void onAfterTabMove(final int from, final int to) {
		Editor<?> editor = getTabAt(to);
		setTabInfo(editor, editor.getMetaInfo(), to);
	}

	@Override
	protected void onBeforeTabMove(final int from, final int to) {
		Editor<?> editor = getTabAt(from);
		editor.sync(false);
	}
	
	@Override
	protected void processMouseEvent(final MouseEvent e) {
		if (MMouseAdapter.isMiddle(e)) {
			try {
				inMiddleButtonEvent = true;
				super.processMouseEvent(e);
			}
			finally {
				inMiddleButtonEvent = false;
			}

			return;
		}

		super.processMouseEvent(e);
	}

	// private

	private Tabs() {
		if (_instance != null)
			throw new WTFError("org.makagiga.Tabs already created");
		
		acc = AccessController.getContext();
		_instance = this;
		
		setReorderingAllowed(true);
		MWhatsThis.set(this, i18n("Tabs - All the open documents are here"));

		if (UI.isMetal()) {
			setBorderContentInsets(createBorderContentInsetsForPlacement(getTabPlacement()));
			updateUI(); // required after "setBorderContentInsets" call
		}

		UI.onKeyPressed(this, e -> {
			if (UI.isPopupTrigger(e))
				popupContextMenu(null);
		} );
		
		addMouseListener(new MMouseAdapter() {
			@Override
			public void buttonClicked/*mouseClicked*/(final MouseEvent e) {
				int tabIndex = Tabs.this.indexAtLocation(e.getPoint());

				if (tabIndex == -1)
					return; // no tab under mouse
				
				if (isMiddle(e))
					Tabs.this.close(tabIndex);
			}
			@Override
			public void mouseClicked(final MouseEvent e) {
				int tabIndex = Tabs.this.indexAtLocation(e.getPoint());
				
				if (tabIndex == -1)
					return; // no tab under mouse
				
				if (isLeft(e) && isDoubleClick(e))
					Tabs.this.rename();
			}
			@Override
			public void popupTrigger(final MouseEvent e) {
				popupContextMenu(e.getPoint());
			}
		} );

		MainView.bind(
			new HistoryMenuAction(),
			new TabsMenuAction()
		);
	}

	private void close() {
		close(getSelectedIndex());
	}
	
	private void close(final int index) {
		closeEditorAt(index, REMOVE_TAB | SAVE_TO_FILE);
		boolean focus = false;
		Sidebar sidebar = Sidebar.getInstance();
		if (sidebar.isDesignerSelected()) {
			if (getSelectedTab() instanceof EditorDesigner<?>)
				sidebar.goTo(Sidebar.Tab.DESIGNER, focus);
			else
				sidebar.goTo(Sidebar.Tab.TREE, focus);
		}
		else if (sidebar.isSummarySelected()) {
			sidebar.goTo(Sidebar.Tab.SUMMARY, focus);
		}
		else {
			sidebar.goTo(Sidebar.Tab.TREE, focus);
		}
	}

	private void closeAll() {
		if (isEmpty())
			return;

		int before = getTabCount();

		for (int i = getTabCount() - 1; i >= 0; --i)
			closeEditorAt(i, REMOVE_TAB | SAVE_TO_FILE | NO_CHANGE_EVENT);

		if (getTabCount() != before)
			fireStateChanged();

		Sidebar sidebar = Sidebar.getInstance();
		if (sidebar.isDesignerSelected())
			sidebar.goTo(Sidebar.Tab.TREE, false);
	}

	private void closeAllOthers() {
		if (getTabCount() < 2)
			return;

		int before = getTabCount();
		int currentEditor = getSelectedIndex();

		for (int i = getTabCount() - 1; i >= 0; --i) {
			if (i != currentEditor)
				closeEditorAt(i, REMOVE_TAB | SAVE_TO_FILE | NO_CHANGE_EVENT);
		}
		
		if (getTabCount() != before)
			fireStateChanged();
	}

	/**
	 * Displays the tab context menu at @p p position.
	 */
	private void popupContextMenu(Point p) {
		int tabUnderMouse;
		if (p == null) {
			tabUnderMouse = -1;
			p = getTabComponentAt(getSelectedIndex()).getLocation();
		}
		else {
			tabUnderMouse = indexAtLocation(p);
		}
		try {
			if (tabUnderMouse != -1)
				setSelectedIndex(tabUnderMouse);
			final MetaInfo metaInfo = getCurrentMetaInfo();
			
			// create and show popup menu
			MMenu menu = createTabsMenu();
			menu.addSeparator();
			
			MMenu copyMenu = new MMenu(MActionInfo.COPY);
			copyMenu.setPopupMenuVerticalAlignment(UI.CENTER);

			MAction copyNameAction = new MAction(i18n("Copy Name"), action -> {
				try {
					MClipboard.setString(metaInfo.toString());
				}
				catch (ClipboardException exception) {
					action.showErrorMessage(exception);
				}
			} );
			copyNameAction.setEnabled(metaInfo != null);
			if (copyNameAction.isEnabled())
				copyNameAction.setHelpText(i18n("Copy - {0}", TK.rightSqueeze(metaInfo.toString(), 50)));
			copyMenu.add(copyNameAction);

			boolean isFile = (metaInfo != null) && metaInfo.isFile();

			MAction copyFileLocationAction = new MAction(i18n("Copy File Path"), action -> {
				try {
					MClipboard.setString(metaInfo.getFilePath());
				}
				catch (ClipboardException exception) {
					action.showErrorMessage(exception);
				}
			} );
			copyFileLocationAction.setEnabled(isFile);
			if (copyFileLocationAction.isEnabled())
				copyFileLocationAction.setHelpText(i18n("Copy - {0}", TK.centerSqueeze(metaInfo.getFilePath(), 50)));
			copyMenu.add(copyFileLocationAction);

			MAction copyLinkAddressAction = new MAction(MActionInfo.COPY_LINK_ADDRESS.noIcon(), action -> {
				HTMLSelection selection = HTMLSelection.fromURI(metaInfo.toURI());
				selection.copyToClipboard();
			} );
			copyLinkAddressAction.setEnabled(isFile);
			if (copyLinkAddressAction.isEnabled())
				copyLinkAddressAction.setHelpText(i18n("Copy - {0}", TK.centerSqueeze(metaInfo.toURI().toString(), 50)));
			copyMenu.add(copyLinkAddressAction);

			menu.add(copyMenu);

			MAction renameAction = new MAction(MActionInfo.RENAME,
				action -> rename()
			);
			renameAction.setEnabled(!Vars.treeReadOnly.get() && (metaInfo != null) && metaInfo.isPermission(AbstractFS.ActionType.RENAME));
			menu.add(renameAction);
			
			menu.addSeparator();
			
			menu.addCheckBox(new MAction(i18n("Small Icons"), action -> {
				Vars.tabsSmallIcons.set(action.isSelected());
				MSettingsDialog.showRestartInfo();
			} ), Vars.tabsSmallIcons.get());

			menu.showPopup(this, p);
		}
		catch (IndexOutOfBoundsException exception) {
			MLogger.exception(exception);
		}
	}
	
	private void rename() {
		MetaInfo metaInfo = getCurrentMetaInfo();
		if (metaInfo != null)
			FSHelper.renameUI(UI.windowFor(this), metaInfo);
	}

	private void setColors(final MetaInfo metaInfo, final int index) {
		TabComponent tabComponent = (TabComponent)getTabComponentAt(index);
		if (tabComponent != null)
			tabComponent.setColor(metaInfo.getColor());
	}

	private void updateColors() {
		for (Editor<?> i : this)
			setColors(i.getMetaInfo(), indexOfComponent(i));
	}

	private void updateRecentlyClosedTabsMenu(final MMenu menu) {
		menu.removeAll();

		// limit list size
		
		int limit = 20;
		int noTimeLimit = limit / 2;
		
		// first, try to remove items w/o "last open" date (e.g. RSS articles);
		
		int numNoTime = 0;
		for (MetaInfo i : recentlyClosedTabs) {
			if (i.getLastOpenTime() == MDate.INVALID_TIME)
				numNoTime++;
		}
		if (numNoTime > noTimeLimit) {
			ListIterator<MetaInfo> it = recentlyClosedTabs.listIterator(recentlyClosedTabs.size());
			while (((numNoTime > noTimeLimit) && it.hasPrevious())) {
				MetaInfo i = it.previous();
				if (i.getLastOpenTime() == MDate.INVALID_TIME) {
					numNoTime--;
					it.remove();
				}
			}
		}
		
		// remove other items
		
		if (recentlyClosedTabs.size() > limit)
			recentlyClosedTabs.subList(limit, recentlyClosedTabs.size()).clear();

		boolean noItems = true;
		boolean setAcceleratorKey = true;

		Iterator<MetaInfo> it = recentlyClosedTabs.iterator();
		String lastTitle = null;
		while (it.hasNext()) {
			MetaInfo i = it.next();
// FIXME: 2.2: tree: automatically clear parent of all virtual files on dfolder delete
			if (
				(i.getParent() == null) || // deleted file?
				(i.getParent().getParent() == null) // removed dynamic folder?
			) {
				it.remove(); // item deleted; remove from the list
			}
		}
		
		MArrayList<MetaInfo> sortedList = new MArrayList<>(recentlyClosedTabs);
		sortedList.sort((o1, o2) -> {
			long t1 = o1.getLastOpenTime();
			long t2 = o2.getLastOpenTime();
				
			// items w/o date first
			int i = TK.compareFirst((t1 == MDate.INVALID_TIME), (t2 == MDate.INVALID_TIME));
				
			if (i == 0) {
				// sort by date
				i = Long.compare(t1, t2) * -1;
					
				// keep original order if same date
				if (i == 0)
					i = Integer.compare(recentlyClosedTabs.indexOf(o1), recentlyClosedTabs.indexOf(o2));
			}
				
			return i;
		} );
		for (MetaInfo i : sortedList) {
			// group by last open date
			long lastOpenTime = i.getLastOpenTime();
			String title;
			if (lastOpenTime != MDate.INVALID_TIME) {
				MDate date = new MDate(lastOpenTime);
				title = date.fancyFormat(0);
			}
			else {
				title = "";
			}
			if (!title.equals(lastTitle)) {
				lastTitle = title;
				if (!title.isEmpty())
					menu.addSeparator(title);
			}

			MetaInfoAction action = new MetaInfoAction(i, false);
			menu.add(action);

			noItems = false;

			if (setAcceleratorKey && !recentlyClosedTabs.isEmpty() && (i == recentlyClosedTabs.getFirst())) {
				setAcceleratorKey = false;
				action.setAcceleratorKey(historyKeyStroke);
			}
		}

		if (noItems) {
			menu.addNoItemsInfo(true);
		}
		else {
			menu.addSeparator();
			menu.add(new MAction(MActionInfo.CLEAR_HISTORY, action -> {
				if (action.showConfirmMessage()) {
					deletePrivateData();
					SessionManager.deletePrivateData();
				}
			} ));
		}
	}

	// private classes

	private static final class CloseAction extends MAction {

		// public

		@Override
		public void onAction() {
			Tabs.getInstance().close();
		}

		// private
		
		private CloseAction() {
			super(MActionInfo.CLOSE);
			setEnabled(false);
			setHTMLHelp(i18n("Closes the current tab."));
		}

	}

	private final class CloseAllAction extends MAction {

		// public

		public CloseAllAction() {
			super(MActionInfo.CLOSE_ALL);
			setEnabled(false);
			setHTMLHelp(i18n("Closes all tabs."));
		}

		@Override
		public void onAction() {
			closeAll();
		}

	}

	private final class CloseAllOthersAction extends MAction {

		// public

		public CloseAllOthersAction() {
			super(i18n("Close All Others"));
			setEnabled(false);
			setHTMLHelp(i18n("Closes all other tabs."));
		}

		@Override
		public void onAction() {
			closeAllOthers();
		}

	}

	private static final class HistoryMenuAction extends MAction {

		// public

		@Override
		public void onAction() {
			MMenu menu = new MMenu();
			menu.addTitle(MActionInfo.HISTORY);

			Tabs tabs = Tabs.getInstance();
			tabs.updateRecentlyClosedTabsMenu(menu);
			menu.showPopup(tabs);
		}

		// private

		private HistoryMenuAction() {
			super(MActionInfo.HISTORY);
			setAcceleratorKey(Tabs.getInstance().historyKeyStroke);
			setAuthorizationProperty(Vars.tabsRecentlyClosedTabs);
		}

	}

	private final class TabsMenuAction extends MAction {
		
		// public
		
		@Override
		public void onAction() {
			if (!Tabs.this.isEmpty())
				Tabs.this.popupContextMenu(null);
		}
		
		// private
		
		private TabsMenuAction() {
			super(i18n("Select next link/Show tabs menu"), VK_T, getMenuMask());
		}
		
	}

}
