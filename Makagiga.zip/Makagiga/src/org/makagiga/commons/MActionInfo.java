// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static org.makagiga.commons.UI.i18n;

import static java.awt.event.KeyEvent.*;

import java.io.Serializable;
import java.util.Objects;
import javax.swing.Icon;
import javax.swing.KeyStroke;

import org.makagiga.commons.annotation.Important;

/**
 * @mg.threadSafe
 *
 * @since 3.0
 */
public final class MActionInfo implements Serializable {

	// private

	private static final String CLEAR_TEXT = i18n("Clear");
	private static final String CLOSE_TEXT = i18n("Close");
	private static final String DELETE_TEXT = i18n("Delete");
	
	// public
	
	public static final MActionInfo ABOUT = new MActionInfo(i18n("About"), "ui/info");

	/**
	 * @since 4.6
	 */
	public static final MActionInfo ADD = new MActionInfo(i18n("Add"), "ui/add", VK_INSERT);

	/**
	 * @since 3.4
	 */
	public static final MActionInfo ADD_STAR = new MActionInfo(i18n("Add Star"), "ui/star");

	/**
	 * @since 3.4
	 */
	public static final MActionInfo ADVANCED = new MActionInfo(i18n("Advanced..."), "ui/misc");

	/**
	 * @since 3.8.8
	 */
	public static final MActionInfo BACK = new MActionInfo(i18n("Back"), "ui/previous");

	/**
	 * @since 5.4
	 */
	public static final MActionInfo BROWSE = new MActionInfo(i18n("Browse..."), "ui/open");
	
	public static final MActionInfo CANCEL = new MActionInfo(i18n("Cancel"), "ui/cancel");

	/**
	 * @since 4.6
	 */
	public static final MActionInfo CHOOSE_FONT = new MActionInfo(i18n("Choose Font..."), "ui/font");

	/**
	 * @since 3.8.1
	 */
	public static final MActionInfo CLEAR = new MActionInfo(CLEAR_TEXT, "ui/delete");

	/**
	 * @since 3.8.1
	 */
	public static final MActionInfo CLEAR_HISTORY = new MActionInfo(i18n("Clear History"), "ui/delete");
	
	public static final MActionInfo CLEAR_LEFT = new MActionInfo(CLEAR_TEXT, "ui/clearleft");
	
	public static final MActionInfo CLEAR_RIGHT = new MActionInfo(CLEAR_TEXT, "ui/clearright");
	
	public static final MActionInfo CLOSE = new MActionInfo(CLOSE_TEXT, "ui/close", VK_W, MAction.getMenuMask());
	
	/**
	 * @since 4.6
	 */
	public static final MActionInfo CLOSE_ALL = new MActionInfo(i18n("Close All"), VK_W, MAction.getMenuMask() | SHIFT_MASK);

	/**
	 * @since 3.8
	 *
	 * @deprecated As of 4.2, replaced by {@link #CLOSE} and {@link #noKeyStroke()}
	 */
	@Deprecated
	public static final MActionInfo CLOSE_NO_KEY_STROKE = new MActionInfo(CLOSE_TEXT, "ui/close");

	public static final MActionInfo CONTINUE = new MActionInfo(i18n("Continue"), "ui/next");

	public static final MActionInfo COPY = new MActionInfo(i18n("Copy"), "ui/copy", VK_C, MAction.getMenuMask());
	
	/**
	 * @since 4.6
	 */
	public static final MActionInfo COPY_ALL = new MActionInfo(i18n("Copy All"), "ui/copy", VK_C, MAction.getMenuMask());

	/**
	 * @since 3.8
	 */
	public static final MActionInfo COPY_AS_HTML = new MActionInfo(i18n("Copy as HTML"), "ui/copy");

	/**
	 * @since 4.10
	 */
	public static final MActionInfo COPY_LINK_ADDRESS = new MActionInfo(i18n("Copy Link Address"), "ui/copy");

	public static final MActionInfo CURRENT_DATE_AND_TIME = new MActionInfo(i18n("Current Date and Time"), "ui/today");
	
	public static final MActionInfo CUT = new MActionInfo(i18n("Cut"), "ui/cut", VK_X, MAction.getMenuMask());
	
	public static final MActionInfo DELETE = new MActionInfo(DELETE_TEXT, "ui/delete", VK_DELETE);
	
	/**
	 * @deprecated As of 4.2, replaced by {@link #DELETE} and {@link #noKeyStroke()}
	 */
	@Deprecated
	public static final MActionInfo DELETE_NO_KEY_STROKE = new MActionInfo(DELETE_TEXT, "ui/delete");

	/**
	 * @since 3.4
	 */
	public static final MActionInfo DOWNLOAD = new MActionInfo(i18n("Download"), "ui/download");

	/**
	 * @since 4.8
	 */
	public static final MActionInfo DUPLICATE = new MActionInfo(i18n("Duplicate"), "ui/copy", VK_D, MAction.getMenuMask());

	/**
	 * @since 5.6
	 */
	public static final MActionInfo EXPERIMENTAL = new MActionInfo(i18n("Experimental"), "ui/experimental");

	/**
	 * @since 3.8.8
	 */
	public static final MActionInfo FORWARD = new MActionInfo(i18n("Forward"), "ui/next");

	/**
	 * @since 3.8.1
	 */
	public static final MActionInfo FIND = new MActionInfo(i18n("Find..."), "ui/find", VK_F, MAction.getMenuMask());

	/**
	 * @since 4.0
	 */
	public static final MActionInfo FIND_NEXT = new MActionInfo(i18n("Find Next"), "ui/down", MAction.getFindNextKeyStroke());

	/**
	 * @since 4.6
	 */
	public static final MActionInfo FIND_PREVIOUS = new MActionInfo(i18n("Find Previous"), "ui/up", MAction.getFindPreviousKeyStroke());

	/**
	 * @since 3.8.2
	 */
	public static final MActionInfo HELP = new MActionInfo(i18n("Help"), "ui/help", VK_F1);

	/**
	 * @since 4.4
	 */
	public static final MActionInfo HISTORY = new MActionInfo(i18n("History"), "ui/history");

	public static final MActionInfo IMPORT = new MActionInfo(i18n("Import"), "ui/ok");

	public static final MActionInfo INSTALL = new MActionInfo(i18n("Install"), "ui/save");
	
	/**
	 * @since 5.4
	 */
	public static final MActionInfo INSTALL_FROM_FILE = new MActionInfo(i18n("Install from File..."), "ui/newfile");

	/**
	 * @since 3.8.6
	 */
	public static final MActionInfo LOCK = new MActionInfo(i18n("Lock"), "ui/locked");
	
	public static final MActionInfo LOGIN = new MActionInfo(i18n("Login"), "ui/ok");
	
	public static final MActionInfo NEW = new MActionInfo(i18n("New"), "ui/newfile", VK_N, MAction.getMenuMask());

	/**
	 * @since 3.8.1
	 */
	public static final MActionInfo NEW_FOLDER = new MActionInfo(i18n("New Folder..."), "ui/newfolder", VK_N, MAction.getMenuMask() | SHIFT_MASK);

	/**
	 * @since 3.8.8
	 */
	public static final MActionInfo NEXT = new MActionInfo(i18n("Next"), "ui/next");

	public static final MActionInfo NO_DATE_TIME = new MActionInfo(i18n("No Date/Time"), "ui/clearright");
	
	public static final MActionInfo OK = new MActionInfo(i18n("OK"), "ui/ok");

	public static final MActionInfo OPEN = new MActionInfo(i18n("Open..."), "ui/open", VK_O, MAction.getMenuMask());

	public static final MActionInfo OPEN_URI = new MActionInfo(i18n("Open"), "ui/run", VK_L, MAction.getMenuMask());

	public static final MActionInfo OVERWRITE = new MActionInfo(i18n("Overwrite"), "ui/ok");
	
	public static final MActionInfo PASTE = new MActionInfo(i18n("Paste"), "ui/paste", VK_V, MAction.getMenuMask());

	/**
	 * @since 3.8.8
	 */
	public static final MActionInfo PREVIOUS = new MActionInfo(i18n("Previous"), "ui/previous");
	
	public static final MActionInfo PRINT = new MActionInfo(i18n("Print..."), "ui/print", VK_P, MAction.getMenuMask());

	public static final MActionInfo PROPERTIES = new MActionInfo(i18n("Properties"), "ui/properties", VK_ENTER, ALT_MASK);
	
	public static final MActionInfo QUIT = new MActionInfo(i18n("Quit"), "ui/quit", VK_Q, MAction.getMenuMask() | SHIFT_MASK);
	
	/**
	 * @since 3.2
	 */
	public static final MActionInfo REFRESH = new MActionInfo(i18n("Refresh"), "ui/refresh");

	/**
	 * @since 4.4
	 */
	public static final MActionInfo REMOVE = new MActionInfo(i18n("Remove"), "ui/remove", VK_DELETE);

	/**
	 * @since 3.4
	 */
	public static final MActionInfo REMOVE_STAR = new MActionInfo(i18n("Remove Star"), "ui/star");
	
	/**
	 * @since 4.10
	 */
	public static final MActionInfo RENAME = new MActionInfo(i18n("Rename..."), VK_F2);

	/**
	 * @since 3.4
	 */
	public static final MActionInfo RESTORE_DEFAULT_VALUES = new MActionInfo(i18n("Restore Default Values"), "ui/revert");

	public static final MActionInfo REVERT = new MActionInfo(i18n("Revert"), "ui/revert");
	
	/**
	 * @since 4.2
	 */
	public static final MActionInfo ROTATE_LEFT = new MActionInfo(i18n("Rotate Left"), "ui/rotateleft", VK_OPEN_BRACKET, CTRL_MASK);

	/**
	 * @since 4.2
	 */
	public static final MActionInfo ROTATE_RIGHT = new MActionInfo(i18n("Rotate Right"), "ui/rotate", VK_CLOSE_BRACKET, CTRL_MASK);

	public static final MActionInfo SAVE = new MActionInfo(i18n("Save"), "ui/save", VK_S, MAction.getMenuMask());

	/**
	 * @since 3.8.8
	 */
	public static final MActionInfo SAVE_AS = new MActionInfo(i18n("Save As..."), "ui/save");

	/**
	 * @since 3.4
	 */
	public static final MActionInfo SAVE_AS_DEFAULT = new MActionInfo(i18n("Save As Default"), "ui/save");

	/**
	 * @since 3.8.1
	 */
	public static final MActionInfo SEARCH = new MActionInfo(i18n("Search..."), "ui/find");

	public static final MActionInfo SELECT_ALL = new MActionInfo(i18n("Select All"), VK_A, MAction.getMenuMask());

	/**
	 * @since 4.2
	 */
	public static final MActionInfo SET_COLOR = new MActionInfo(i18n("Set Color..."), "ui/color");

	/**
	 * @since 3.8.1
	 */
	public static final MActionInfo SET_DATE_TIME = new MActionInfo(i18n("Set Date/Time..."), "ui/calendar");
	
	public static final MActionInfo SETTINGS = new MActionInfo(i18n("Settings"), "ui/configure");

	/**
	 * @since 3.8.3
	 */
	public static final MActionInfo SHOW_GRID = new MActionInfo(i18n("Show Grid"), "ui/grid");

	/**
	 * @since 3.4
	 */
	public static final MActionInfo SHOW_STARRED = new MActionInfo(i18n("Show Starred"), "ui/star");

	/**
	 * @since 5.4
	 */
	public static final MActionInfo STATISTICS = new MActionInfo(i18n("Statistics"), "ui/chart");

	public static final MActionInfo UNINSTALL = new MActionInfo(i18n("Uninstall"), "ui/delete");

	/**
	 * @since 3.8.6
	 */
	public static final MActionInfo UNLOCK = new MActionInfo(i18n("Unlock"), "ui/unlocked");

	public static final MActionInfo UNSELECT_ALL = new MActionInfo(i18n("Unselect All"), VK_A, MAction.getMenuMask() | SHIFT_MASK);
	
	/**
	 * @since 4.2
	 */
	public static final MActionInfo UPDATE = new MActionInfo(i18n("Update"), "ui/refresh");
	
	/**
	 * @since 4.2
	 */
	public static final MActionInfo WHATS_THIS = new MActionInfo(i18n("What's This?"), VK_F1, SHIFT_MASK);
	
	// private

	private int hash;
	private int keyCode;
	private int modifiers;
	private String iconName;
	private String text;
	
	// public
	
	/**
	 * @since 4.2
	 */
	public MActionInfo(final String text) {
		this(text, null);
	}

	public MActionInfo(final String text, final String iconName) {
		this(text, iconName, 0, 0);
	}

	/**
	 * @since 4.2
	 */
	public MActionInfo(final String text, final String iconName, final int keyCode) {
		this(text, iconName, keyCode, 0);
	}

	public MActionInfo(final String text, final String iconName, final int keyCode, final int modifiers) {
		this.text = text;
		this.iconName = iconName;
		this.keyCode = keyCode;
		this.modifiers = modifiers;
	}

	/**
	 * @since 4.6
	 */
	public MActionInfo(final String text, final int keyCode, final int modifiers) {
		this(text, null, keyCode, modifiers);
	}

	/**
	 * @since 4.0
	 */
	public MActionInfo(final String text, final String iconName, final KeyStroke keyStroke) {
		this(text, iconName, keyStroke.getKeyCode(), keyStroke.getModifiers());
	}

	/**
	 * @since 4.10
	 */
	public MActionInfo(final String text, final int keyCode) {
		this(text, null, keyCode, 0);
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o)
			return true;

		if ((o == null) || (this.getClass() != o.getClass()))
			return false;

		MActionInfo other = (MActionInfo)o;

		return
			(this.keyCode == other.keyCode) &&
			(this.modifiers == other.modifiers) &&
			Objects.equals(this.iconName, other.iconName) &&
			Objects.equals(this.text, other.text);
	}

	/**
	 * Returns a text suitable for dialog titles.
	 * The current implementation returns {@link #getText()}
	 * without leading and trailing <code>"..."</code>.
	 *
	 * @since 3.8.1
	 */
	public String getDialogTitle() {
		return getDialogTitle(getText());
	}

	public Icon getIcon() {
		return MIcon.stock(iconName);
	}
	
	public String getIconName() { return iconName; }
	
	public int getKeyCode() { return keyCode; }

	/**
	 * @since 3.8.7
	 */
	public KeyStroke getKeyStroke() {
		if (keyCode == 0)
			return null;

		return KeyStroke.getKeyStroke(keyCode, modifiers);
	}

	/**
	 * @since 3.8.10
	 */
	public Icon getMediumIcon() {
		return MIcon.medium(iconName);
	}

	public int getModifiers() { return modifiers; }
	
	public Icon getSmallIcon() {
		return MIcon.small(iconName);
	}
	
	public String getText() { return text; }
	
	@Override
	public int hashCode() {
		if (hash == 0)
			hash = TK.hash(Objects.hashCode(iconName), Objects.hashCode(text), keyCode, modifiers);
		
		return hash;
	}

	/**
	 * Returns a copy of this object without icon info.
	 *
	 * @since 4.4
	 */
	public MActionInfo noIcon() {
		if (iconName == null)
			return this;
		
		return new MActionInfo(text, null, keyCode, modifiers);
	}

	/**
	 * Returns a copy of this object without key stroke info.
	 *
	 * @since 4.2
	 */
	public MActionInfo noKeyStroke() {
		if (keyCode == 0)
			return this;
		
		return new MActionInfo(text, iconName);
	}

	@Important
	@Override
	public String toString() {
		return Objects.toString(text, "");
	}

	/**
	 * @since 5.6
	 */
	public MActionInfo withDialogTitle() {
		return withText(getDialogTitle());
	}

	/**
	 * Returns a copy of this object with a specified key stroke info.
	 *
	 * @since 4.2
	 */
	public MActionInfo withKeyStroke(final int keyCode) {
		return new MActionInfo(text, iconName, keyCode, 0);
	}

	/**
	 * Returns a copy of this object with a specified key stroke info.
	 *
	 * @since 4.2
	 */
	public MActionInfo withKeyStroke(final int keyCode, final int modifiers) {
		return new MActionInfo(text, iconName, keyCode, modifiers);
	}

	/**
	 * Returns a copy of this object with a specified key stroke info.
	 *
	 * @since 4.2
	 */
	public MActionInfo withKeyStroke(final KeyStroke keyStroke) {
		return new MActionInfo(text, iconName, keyStroke);
	}

	/**
	 * @since 5.6
	 */
	public MActionInfo withText(final String newText) {
		return new MActionInfo(newText, iconName, keyCode, modifiers);
	}

	/**
	 * @since 4.10
	 */
	public static String getDialogTitle(final String text) {
		String result = text;

		if (TK.isEmpty(result))
			return result;

		result = TK.removePrefix(result, "...");
		result = TK.removeSuffix(result, "...");

		return result.trim();
	}

}
