// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.cache;

import java.io.Closeable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;

/**
 * @since 4.0
 */
public abstract class CacheGroup<K, V> implements Closeable {

	// private
	
	private final Cache<K, V> parent;
	private int version = 1;
	private final Map<K, CacheEntry<V>> map = new HashMap<>(1024);
	private final Object lock = new Object();
	private final String name;

	// public
	
	public CacheGroup(final Cache<K, V> parent, final String name) {
		parent.getLog().infoFormat("%s: Creating", name);
		this.parent = Objects.requireNonNull(parent);
		this.name = TK.validateID(name);
	}
	
	public void clear() {
		getLog().infoFormat("%s: Clear", name);
		
		synchronized (lock) {
			map.clear();
		}
	}
	
	public String getName() { return name; }

	public int getVersion() {
		synchronized (lock) {
			return version;
		}
	}

	public boolean isEmpty() {
		return size() == 0;
	}
	
	public int size() {
		synchronized (lock) {
			return map.size();
		}
	}
	
	public CacheEntry<V> remove(final K key) {
		getLog().infoFormat("%s: Remove: %s", name, key);
	
		Objects.requireNonNull(key);

		synchronized (lock) {
			return map.remove(key);
		}
	}
	
	// Closeable
	
	@Override
	public void close() { }
	
	// protected

	protected Object getLock() { return lock; }
	
	protected MLogger getLog() {
		return parent.getLog();
	}
	
	protected Map<K, CacheEntry<V>> getMap() { return map; }
	
	protected Cache<K, V> getParent() { return parent; }

	protected void setVersion(final int value) {
		synchronized (lock) {
			version = value;
		}
	}

}