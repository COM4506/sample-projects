// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.cache;

import java.io.Closeable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;

/**
 * @since 4.0
 */
public abstract class Cache<K, V> implements Closeable {

	// private
	
	private final Map<String, CacheGroup<K, V>> groupMap = new HashMap<>(16);
	private final MLogger log;
	private final Object lock = new Object();
	private final String id;

	// public

	public void clear() {
		synchronized (lock) {
			for (CacheGroup<K, V> i : groupMap.values())
				i.clear();
			groupMap.clear();
		}
	}

	public synchronized void debug() {
		if (!MLogger.isDeveloper())
			return;
	
		for (Map.Entry<String, CacheGroup<K, V>> i : groupMap.entrySet()) {
			System.err.println();
			Map<K, CacheEntry<V>> map = i.getValue().getMap();
			System.err.println("==== CACHE: " + id);
			System.err.printf("==== GROUP: %s (%d entries)%n", i.getKey(), map.size());
			for (Map.Entry<K, CacheEntry<V>> mapEntry : map.entrySet())
				System.err.println(mapEntry);
		}
	}

	/**
	 * Returns a cache group identified by {@code name}.
	 *
	 * @mg.note
	 * The implementation may return {@code null} if group does not exist.
	 *
	 * @param name the group name
	 *
	 * @throws NullPointerException If {@code name} is {@code null}
	 */
	public CacheGroup<K, V> getGroup(final String name) {
		Objects.requireNonNull(name);
	
		CacheGroup<K, V> group;
		synchronized (lock) {
			group = groupMap.get(name);
			if (group == null) {
				group = createCacheGroup(name);
				groupMap.put(name, group);
			}
		}
		
		return group;
	}
	
	/**
	 * Returns the number of groups.
	 */
	public int getGroupCount() {
		synchronized (lock) {
			return groupMap.size();
		}
	}

	// Closeable
	
	@Override
	public void close() {
		synchronized (lock) {
			for (CacheGroup<K, V> i : groupMap.values()) {
				try {
					i.close();
				}
				catch (Exception exception) {
					MLogger.exception(exception);
				}
			}
		}
	}

	// protected
	
	protected Cache(final String id) {
		this.id = TK.validateID(id);
		this.log = MLogger.get(id);
	}

	/**
	 * Invoked from {@link #getGroup(String)} to create a new cache group.
	 *
	 * @param name the group name
	 */
	protected abstract CacheGroup<K, V> createCacheGroup(final String name);

	protected Object getLock() { return lock; }
	
	protected MLogger getLog() { return log; }

}