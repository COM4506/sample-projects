// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.cache;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Flushable;
import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Pattern;

import org.makagiga.commons.FS;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MFormat;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Tuple;
import org.makagiga.commons.io.DataHeader;
import org.makagiga.commons.io.MDataInputStream;
import org.makagiga.commons.io.MDataOutputStream;
import org.makagiga.commons.security.MGuardedObject;
import org.makagiga.commons.security.PermissionInfo;

/**
 * A file cache.
 *
 * @mg.note
 * This implementation is <b>not</b> serializable.
 *
 * @mg.threadSafe
 *
 * @since 4.0
 */
public class FileCache extends Cache<String, Void> {

	// public
	
	public static final long IGNORE_DATE = Long.MIN_VALUE;
	public static final long NO_DATE = 0;
	
	/**
	 * @since 4.12
	 */
	public static final long UNLIMITED_SIZE = -1;

	// private
	
	private static long maximumGroupSize = UNLIMITED_SIZE;
	private final Path directory;

	// public

	/**
	 * Constructs a new file cache.
	 *
	 * @param directory the "root" directory
	 *
	 * @throws CacheException If {@code directory} initialization failed
	 * @throws NullPointerException If {@code directory} is {@code null}
	 *
	 * @see #getDirectory()
	 * @see #getInstance()
	 */
	public FileCache(final Path directory) {
		super("file-cache");
		
		this.directory = Objects.requireNonNull(directory);
		try {
			Files.createDirectories(directory);
			
			// remove unused old cache entries
			try {
				Path oldIndex = directory.resolve("index.xml");
				if (Files.exists(oldIndex)) {
					getLog().info("Removing old (Makagiga 3.x) cache entries");
					try (DirectoryStream<Path> ds = Files.newDirectoryStream(directory)) {
						for (Path i : ds) {
							if (Files.isRegularFile(i))
								FS.deleteSilently(i);
						}
					}
				}
			}
			catch (IOException exception) {
				MLogger.exception(exception); // non-fatal
			}
		}
		catch (IOException exception) {
			throw new CacheException(exception); // fatal
		}
	}
	
	@Override
	public void clear() {
		// initialize all cache groups before clear
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(directory)) {
			for (Path i : ds) {
				if (
					Files.isDirectory(i) &&
					Files.exists(i.resolve("INDEX"))
				) {
					getGroup(FS.getFileName(i));
				}
			}
		}
		catch (IOException exception) {
			MLogger.exception(exception);
		}

		super.clear();
	}
	
	public static FileCache.Group getDefaultGroup() {
		return getInstance().getGroup("default");
	}

	/**
	 * Returns a cache group identified by {@code name}.
	 *
	 * @mg.note
	 * This implementation never returns {@code null} group.
	 *
	 * @param name the group name
	 *
	 * @throws CacheException If group initialization failed
	 * @throws NullPointerException If {@code name} is {@code null}
	 */
	@Override
	public FileCache.Group getGroup(final String name) {
		return (FileCache.Group)super.getGroup(name);
	}

	/**
	 * Returns the cache "root" directory (created automatically).
	 */
	public Path getDirectory() { return directory; }
	
	public static FileCache.Group getDownloadGroup() {
		return getInstance().getGroup("download");
	}

	/**
	 * Returns the shared singleton instance.
	 */
	public static FileCache getInstance() {
		return LazyFileCacheHolder.INSTANCE.get();
	}

	/**
	 * @since 4.12
	 */
	public static long getMaximumGroupSize() { return maximumGroupSize; }

	/**
	 * @since 4.12
	 */
	public static void setMaximumGroupSize(final long value) {
		if ((value != UNLIMITED_SIZE) && (value < MFormat.MB))
			throw new IllegalArgumentException("Maximum size cannot be less than 1 MB: " + value);

		maximumGroupSize = value;
	}

	public static FileCache.Group getPreviewGroup() {
		return getInstance().getGroup("preview");
	}

	// protected

	/**
	 * @throws CacheException If group initialization failed
	 * @throws NullPointerException If {@code name} is {@code null}
	 */
	@Override
	protected CacheGroup<String, Void> createCacheGroup(final String name) {
		return new Group(this, name);
	}

	// private
	
	private FileCache() {
		this(FS.newConfigPath("cache"));
	}
	
	// public classes
	
	public static class Entry extends CacheEntry<Void> {

		// private

		private int hits;
		private final long lastModified;

		// public

		public Entry(final String id, final long lastModified) {
			super(id);
			this.lastModified = lastModified;
		}

		@Override
		public synchronized int getHits() { return hits; }

		public long getLastModified() { return lastModified; }

		public synchronized void incHits() { hits++; }
		
		@Override
		public String toString() {
			return super.toString() + ",lastModified=" + lastModified;
		}
		
		// private
		
		private Path toPath(final Group group) {
			return group.subdirectory.resolve(getID().toString());
		}

	}

	public static class Group extends CacheGroup<String, Void> implements Flushable {
	
		// private
	
		private final DataHeader indexHeader;
		private static final int INDEX_VERSION = 1;
		private final Path indexFile;
		private final Path subdirectory;
	
		// public
		
		@Override
		public void clear() {
			super.clear();
			
			try (DirectoryStream<Path> ds = Files.newDirectoryStream(subdirectory)) {
				for (Path i : ds) {
					if (Files.isRegularFile(i))
						FS.deleteSilently(i);
				}
			}
			catch (IOException exception) {
				MLogger.exception(exception);
			}

			flush();
		}

		@Override
		public synchronized void close() {
			int maxCount = 2000;
			int beforeCount = getMap().size();
			List<Tuple.Two<String, CacheEntry<Void>>> _sortedList = null;
			
			// remove unused cache entries

			if (beforeCount > maxCount) {
				int maxRemove = maxCount / 2;
				int removed = 0;
				if (_sortedList == null)
					_sortedList = createSortedList();
				for (Tuple.Two<String, CacheEntry<Void>> i : _sortedList) {
					getLog().debugFormat("%s: %d hit(s), Removing unused cache entry: %s", getName(), i.get2().getHits(), i);

					removeNoFlush(i.get1());
					removed++;
					
					if (removed == maxRemove)
						break; // for
				}
				
				getLog().debugFormat("%s: Clean up: %d -> %d", getName(), beforeCount, getMap().size());
			}

			HashSet<String> goodFiles = new HashSet<>(getMap().size());
			for (CacheEntry<Void> i : getMap().values())
				goodFiles.add(i.getID().toString());
		
			long totalSize = 0;
			try (DirectoryStream<Path> ds = Files.newDirectoryStream(subdirectory)) {
				for (Path i : ds) {
					if (
						Files.isRegularFile(i) &&
						!i.equals(indexFile)
					) {
						if (!goodFiles.contains(FS.getFileName(i))) {
							getLog().infoFormat("%s: Removing broken/temporary cache entry: %s", getName(), i.getFileName());
							FS.deleteSilently(i);
						}
						else {
							totalSize += Files.size(i);
						}
					}
				}
			}
			catch (IOException exception) {
				MLogger.exception(exception);
			}
			
			// trim size

			long maxGroupSize = FileCache.getMaximumGroupSize();
			if ((maxGroupSize != FileCache.UNLIMITED_SIZE) && (totalSize > maxGroupSize)) {
				if (_sortedList == null)
					_sortedList = createSortedList();
				long currentSize = totalSize;
				for (Tuple.Two<String, CacheEntry<Void>> i : _sortedList) {
					FileCache.Entry entry = (FileCache.Entry)i.get2();
					Path file = entry.toPath(this);
					try {
						currentSize -= Files.size(file);
						removeNoFlush(i.get1());
						getLog().debugFormat("%s: %d hit(s), Removing entry: %s", getName(), entry.getHits(), i);
					}
					catch (NoSuchFileException exception) { } // quiet; already removed above
					catch (IOException exception) {
						MLogger.exception(exception);
					}
					
					if (currentSize <= maxGroupSize) {
						getLog().debugFormat("%s: Reduce size: %s -> %s", getName(), MFormat.toAutoSize(totalSize), MFormat.toAutoSize(currentSize));
					
						break; // for
					}
				}
			}

			flush();

			super.close();
		}

		public File getFile(final String key) {
			return getFile(key, FileCache.IGNORE_DATE);
		}
		
		public File getFile(final String key, final long lastModified) {
			Path path = getPath(key, lastModified);
			
			return (path == null) ? null : path.toFile();
		}

		public File getFile(final URL key, final long lastModified) {
			return getFile(key.toString(), lastModified);
		}

		public Path getPath(final String key) {
			return getPath(key, FileCache.IGNORE_DATE);
		}
		
		public Path getPath(final String key, final long lastModified) {
			FileCache.Entry entry;
			synchronized (getLock()) {
				entry = (FileCache.Entry)getMap().get(key);
			}
			
			if (entry == null)
				return null;
			
			Path path = entry.toPath(this);

			if (!Files.exists(path)) {
				getLog().warningFormat("%s: Broken cache entry: %s", getName(), key);
				remove(key);
				
				return null;
			}

			if ((lastModified != IGNORE_DATE) && (entry.lastModified != lastModified)) {
				getLog().infoFormat("%s: Removing expired cache entry: %s", getName(), key);
				remove(key);
				
				return null;
			}
			
			entry.incHits();
			getLog().infoFormat("%s: Using existing cache entry: %s (hits=%d)", getName(), key, entry.getHits());
			
			return path;
		}

		public Path newPath(final String key, final long lastModified, final String newPathSuffix) {
			String fileName = UUID.randomUUID().toString();
			if (newPathSuffix != null)
				fileName += newPathSuffix;

			if (lastModified == NO_DATE) {
				getLog().warningFormat("%s: File with \"zero\" date will not be cached: %s", getName(), key);
				try {
					return Files.createFile(subdirectory.resolve(fileName));
				}
				catch (IOException exception) {
					throw new CacheException(exception);
				}
			}
			
			try {
				getLog().infoFormat("%s: Creating new path entry: %s = %s", getName(), key, fileName);
				Path path = Files.createFile(subdirectory.resolve(fileName));
				
				Entry entry = new Entry(fileName, lastModified);
				synchronized (getLock()) {
					getMap().put(key, entry);
				}
				
				flush();

				return path;
			}
			catch (IOException exception) {
				throw new CacheException(exception);
			}
		}
		
		public Path newPath(final URL key, final long lastModified, final String newPathSuffix) {
			return newPath(key.toString(), lastModified, newPathSuffix);
		}

		public synchronized void remove(final Pattern keyPattern) {
			boolean needFlush = false;
			for (Object key : getMap().keySet().toArray()) {
				if (keyPattern.matcher(key.toString()).matches()) {
					needFlush = true;
					remove(key.toString());
				}
			}
			if (needFlush)
				flush();
		}
		
		@Override
		public CacheEntry<Void> remove(final String key) {
			CacheEntry<Void> old = removeNoFlush(key);
			if (old != null)
				flush();
				
			return old;
		}

		public CacheEntry<Void> remove(final URL url) {
			return remove(url.toString());
		}

		// Flushable
		
		@Override
		public void flush() {
			//getLog().infoFormat("%s: Flush", getName());
			
			synchronized (getLock()) {
				try (MDataOutputStream data = new MDataOutputStream(
					new FS.BufferedFileOutput(indexFile.toFile())
				)) {
					data.writeHeader(indexHeader);
					data.writeProperty("items", getMap().size());
					Map<String, Object> properties = new LinkedHashMap<>();
					for (Map.Entry<String, CacheEntry<Void>> i : getMap().entrySet()) {
						properties.clear();
						properties.put("k", i.getKey());
						FileCache.Entry entry = (FileCache.Entry)i.getValue();
						properties.put("i", entry.getID());
						properties.put("h", entry.getHits());
						properties.put("m", entry.getLastModified());
						data.writePropertyMap(properties);
					}
				}
				catch (IOException exception) {
					MLogger.exception(exception);
				}
			}
		}

		// private
		
		private Group(final FileCache cache, final String name) {
			super(cache, name);
			
			subdirectory = cache.directory.resolve(name);
			try {
				Files.createDirectories(subdirectory);
				indexFile = subdirectory.resolve("INDEX");
				indexHeader = new DataHeader("INDEX", INDEX_VERSION);

				try (MDataInputStream data = new MDataInputStream(
					new FS.BufferedFileInput(indexFile.toFile())
				)) {
					data.readHeader(indexHeader.getID());
					int items = (Integer)data.readProperty("items");
					for (int i = 0; i < items; i++) {
						Map<String, ?> properties = data.readPropertyHashMap();
						FileCache.Entry entry = new FileCache.Entry(
							(String)properties.get("i"),
							(Long)properties.get("m")
						);
						entry.hits = (Integer)properties.get("h");
						getMap().put((String)properties.get("k"), entry);
					}
				}
				catch (FileNotFoundException exception) {
					getLog().infoFormat("%s: Index file not found", getName());
				}
				catch (IOException exception) {
					MLogger.exception(exception);
				}
			}
			catch (IOException exception) {
				throw new CacheException(exception);
			}
		}

		private List<Tuple.Two<String, CacheEntry<Void>>> createSortedList() {
			MArrayList<Tuple.Two<String, CacheEntry<Void>>> sorted = new MArrayList<>(getMap().size());
			for (Map.Entry<String, CacheEntry<Void>> i : getMap().entrySet())
				sorted.add(Tuple.of(i.getKey(), i.getValue()));

			// sort by hits (low usage first)
			sorted.sort((o1, o2) -> Integer.compare(o1.get2().getHits(), o2.get2().getHits()));
			
			return sorted;
		}

		private CacheEntry<Void> removeNoFlush(final String key) {
			FileCache.Entry old = (FileCache.Entry)super.remove(key);
			if (old != null)
				FS.deleteSilently(old.toPath(this));
			
			return old;
		}
		
	}

	// private classes

	private static final class LazyFileCacheHolder {

		// private

		private static final MGuardedObject<FileCache> INSTANCE = new MGuardedObject<>(
			new FileCache(),
			"org.makagiga.commons.cache.FileCache",
			PermissionInfo.ThreatLevel.MEDIUM,
			"Cache"
		);

		// private

		private LazyFileCacheHolder() { }

	}

}