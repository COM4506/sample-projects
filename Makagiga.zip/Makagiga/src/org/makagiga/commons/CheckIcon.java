// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.JMenuItem;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;

final class CheckIcon implements Icon {

	// private
	
	private static final BasicStroke stroke = new BasicStroke(2.5f, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
	private final Color selectedBackground = new Color(0xDDE8F3); // NOTE: gradient color from UI class
	private final int size = MIcon.getSmallSize();

	// public
	
	public CheckIcon() { }
	
	// Icon

	@Override
	public int getIconHeight() { return size; }

	@Override
	public int getIconWidth() { return size; }

	@Override
	public void paintIcon(final Component c, final Graphics graphics, int x, int y) {
		if (!(c instanceof AbstractButton))
			return;

		Graphics2D g = (Graphics2D)graphics.create();
		AbstractButton button = (AbstractButton)c;
		boolean menu = (button instanceof JMenuItem);
		boolean selected = button.isSelected();
		int margin = menu ? 0 : 1;

		x += margin;
		if (menu)
			x--;
		y += margin;
		int w = size - margin * 2;
		int h = size - margin * 2;

		UI.setAntialiasing(g, true);

		Color bg = selected ? selectedBackground : MColor.WHITE;
		Color fg = MColor.getContrastBW(bg);
		Color border = MColor.getContrast(bg);

		// radio button
		if ((button instanceof JRadioButton) || (button instanceof JRadioButtonMenuItem)) {
			if (!menu) {
				g.setColor(bg);
				g.fillOval(x, y, w, h);
				g.setColor(border);
				g.drawOval(x, y, w, h);
			}

			if (selected) {
				g.setColor(fg);
				int p = 4; // padding
				g.fillOval(x + p, y + p, w - p * 2 + 1, h - p * 2 + 1);
			}
		}
		// check box
		else {
			if (!menu) {
				g.setColor(bg);
				g.fillRect(x, y, w, h);
				g.setColor(border);
				g.drawRect(x, y, w, h);
			}
			
			if (selected) {
				int midX = x + w / 2;
				int midY = y + h / 2;

				g.setColor(fg);
				g.setStroke(stroke);
				g.drawPolyline(
					new int[] { midX - w / 4, midX, midX + w / 4 },
					new int[] { midY, midY + h / 4, midY - h / 4 },
					3
				);
/* DEAD: x
				g.setStroke(new BasicStroke(2.5f));
				g.setColor(fg);
				int x1 = x + p;
				int y1 = y + p;
				int x2 = x + w - p;
				int y2 = y + h - p;
				g.drawLine(x1, y1, x2, y2);
				g.drawLine(x2, y1, x1, y2);
*/
			}
		}

		g.dispose();
	}

}
