// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.print;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import javax.swing.border.Border;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MMessageLabel;
import org.makagiga.commons.swing.MNumberSpinner;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.MSpinnerPanel;
import org.makagiga.commons.swing.MTimer;

// FIXME: 2.0: printing image (landscape)
// TODO: paper size preview
/**
 * @since 3.0
 */
public class PrintPreviewPanel extends MPanel implements MDisposable {
	
	// private

	private boolean inPageNumberUpdate;
	private Border shadowBorder;
	private int pageCount;
	private MLabel pageLabel;
	private final MMessageLabel errorLabel;
	private MNumberSpinner<Integer> pageNumber;
	private MPanel pagePanel;
	private MTimer calcPageCountTimer;
	private final PrintInfo<?> printInfo;
	
	// package protected
	
	Flags flags = Flags.NONE;
	int orientation = PageFormat.PORTRAIT;
	MLabel preview;
	
	// public
	
	public PrintPreviewPanel(final PrintInfo<?> printInfo) {
		this.printInfo = printInfo;
		createPagePanel();
		
		preview = new MLabel();
		preview.setFocusable(true);
		preview.setHorizontalAlignment(UI.CENTER);
		preview.setVerticalAlignment(UI.TOP);
		preview.setStyle("font-weight: bold; margin: " + getContentMargin());
		preview.setToolTipText(i18n("Print Preview"));
		addCenter(preview, MScrollPane.BROWSE_LAYER | MScrollPane.FAST_SCROLL);
		
		errorLabel = new MMessageLabel();
		errorLabel.setVisible(false);
		addSouth(errorLabel);
	}

	/**
	 * @since 3.8.3
	 */
	public MPanel getPagePanel() { return pagePanel; }

	public void refresh(final boolean recalcPageCount) {
		Printable printable = getPrintable();
		if (printable == null) {
			setInfo(i18n("Preview not available"));
			pageLabel.setVisible(false);
			pageNumber.setEnabled(false);
		}
		else {
			if (recalcPageCount) {
				try {
					inPageNumberUpdate = true;
					pageNumber.setNumber(1);
				}
				finally {
					inPageNumberUpdate = false;
				}
				calcPageCount();
			}
			generatePreview(printable);
		}
	}
	
	// MDisposable
	
	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		calcPageCountTimer = TK.dispose(calcPageCountTimer);
		pageNumber = null;
		preview.setIcon(null);
	}

	// private
	
	private void calcPageCount() {
		calcPageCountTimer = TK.dispose(calcPageCountTimer);
		pageCount = 0;
		final Printable printable = getPrintable();
		calcPageCountTimer = MTimer.milliseconds(100, timer -> {
			if (isPageValid(printable, pageCount)) {
				pageCount++;
				updateComponents();
					
				return MTimer.CONTINUE;
			}

			timer.stop(); // make sure this.isRunning() is false
			updateComponents();
				
			return MTimer.STOP;
		} );
		calcPageCountTimer.start();
	}

	private void createPagePanel() {
		pagePanel = MPanel.createVBoxPanel();

		pagePanel.addGap();

		pageLabel = new MLabel();
		pagePanel.add(pageLabel);

		pagePanel.addGap();

		pageNumber = new MNumberSpinner<>();
		pageNumber.setRange(1, 9999);
		pageNumber.setNumber(1);
		pageNumber.setToolTipText(i18n("Current Page"));
		pageNumber.addChangeListener(e -> {
			if (!inPageNumberUpdate)
				refresh(false);
		} );
		pageLabel.setLabelFor(pageNumber);
		pagePanel.add(new MSpinnerPanel(pageNumber));
	}
	
	private void generatePreview(final Printable printable) {
		BufferedImage image = generatePreview(printable, pageNumber.getNumber() - 1, true);
		if (image == null) {
			setInfo(i18n("No such page/empty page: {0}", pageNumber.getNumber()));
		}
		else {
			errorLabel.setVisible(false);
			preview.setImage(image);
			preview.setPreferredSize(new Dimension(
				image.getWidth() + getContentMargin() * 4,
				image.getHeight() + getContentMargin() * 4
			));
			preview.setText(null);
		}
		updateComponents();
	}
	
	private BufferedImage generatePreview(final Printable printable, final int index, final boolean changeCursor) {
		final int INSETS = 5;
		PageFormat pageFormat = getPageFormat();
		int w = (int)pageFormat.getWidth() + INSETS;
		int h = (int)pageFormat.getHeight() + INSETS;

		BufferedImage image = UI.createCompatibleImage(w, h, false);
		Graphics2D g = image.createGraphics();
		
		// background
		if (shadowBorder == null)
			shadowBorder = UI.createDropShadowBorder();

		int i = INSETS + 1;
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w - i, h - i);
		g.setColor(Color.BLACK);
		g.drawRect(0, 0, w - i, h - i);
		Color bg = UI.getBackground(this);
		g.setColor(bg);
		g.fillRect(w - INSETS, 0, INSETS, h);
		g.fillRect(0, h - INSETS, w - INSETS, INSETS);
		shadowBorder.paintBorder(this, g, 0, 0, w, h);

		try {
			if (changeCursor)
				UI.setWaitCursor(this, true);
			int result = printable.print(g, pageFormat, index);
			if (result == Printable.NO_SUCH_PAGE)
				image = null;
		}
		
		// HACK: Substance (?)
		catch (NegativeArraySizeException exception) {
			MLogger.exception(exception);
		}

		catch (PrinterException exception) {
			MLogger.exception(exception);
			setError(exception.getLocalizedMessage());
		}
		finally {
			g.dispose();
			if (changeCursor)
				UI.setWaitCursor(this, false);
		}
		
		return image;
	}
	
	private PageFormat getPageFormat() {
		PageFormat result = new PageFormat();
		result.setOrientation(orientation);
		
		return result;
	}

	private Printable getPrintable() {
		try {
			return printInfo.getPrintable(flags);
		}
		catch (PrinterException exception) {
			MLogger.exception(exception);
			setError(exception.getLocalizedMessage());
			
			return null;
		}
	}

	private boolean isPageValid(final Printable printable, final int page) {
		BufferedImage image = UI.createCompatibleImage(1, 1, false);
		Graphics2D g = image.createGraphics();
		try {
			int result = printable.print(g, getPageFormat(), page);
			
			return (result != Printable.NO_SUCH_PAGE);
		}
		catch (PrinterException exception) {
			MLogger.exception(exception);
			
			return false;
		}
		finally {
			g.dispose();
		}
	}

	private void setError(final String text) {
		errorLabel.setVisible(true);
		errorLabel.setErrorMessage(text);
	}
	
	private void setInfo(final String text) {
		errorLabel.setVisible(true);
		errorLabel.setWarningMessage(text);
	}
	
	private void updateComponents() {
		pageLabel.setHTML(
			i18n("Page {0} of {1}",
				"<b>" + Math.max(Math.min(pageNumber.getNumber(), pageCount), 1) + "</b>",
				"<b>" + (Math.max(pageCount, 1) + (calcPageCountTimer.isRunning() ? "+" : "")) + "</b>"
			)
		);
	}
	
}
