// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.print;

import java.awt.Component;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.util.Objects;

import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.OrientationRequested;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MDate;
import org.makagiga.commons.TK;

/**
 * @since 2.0
 */
public abstract class AbstractPrintInfo<T extends Component> implements PrintInfo<T> {
	
	// private
	
	private Path path;
	private final String documentTitle;
	private final String footer;
	private final String header;

	// public
	
	public AbstractPrintInfo(final String documentTitle, final String header, final String footer) {
		this.documentTitle = documentTitle;
		this.header = header;
		this.footer = footer;
	}
	
	/**
	 * @since 4.4
	 */
	public Path getPath() { return path; }

	/**
	 * @since 4.4
	 */
	public void setPath(final Path value) { path = value; }

	/**
	 * @since 3.4
	 */
	public static PrintRequestAttributeSet getPrintRequestAttributeSet(final Flags flags) {
		return getPrintRequestAttributeSet(flags, null);
	}

	/**
	 * @since 2.4
	 */
	public static String getCurrentDateTime() {
		return MDate.now().formatDateTime(MDate.FULL, MDate.SHORT);
	}
	
	@Override
	public T getPrintComponent() { return null; }
	
	@Override
	public MessageFormat getPrintHeader(final boolean enabled) {
		if (!enabled || (header == null))
			return null;
		
		return new MessageFormat(header);
	}
	
	@Override
	public MessageFormat getPrintFooter(final boolean enabled) {
		if (!enabled || (footer == null))
			return null;
		
		return new MessageFormat(footer);
	}

	@Override
	public int getPrintingCapabilities() {
		int result = 0;
		
		if (header != null)
			result |= PRINT_HEADER;

		if (footer != null)
			result |= PRINT_FOOTER;

		return result;
	}
	
	@Override
	public String getPrintTitle() {
		if (header == null)
			return Objects.toString(documentTitle, "?");

		return header;
	}

	// package

	static PrintRequestAttributeSet getPrintRequestAttributeSet(final Flags flags, final String printTitle) {
		HashPrintRequestAttributeSet attr = new HashPrintRequestAttributeSet();

		if (flags.isSet(OPTION_ORIENTATION_LANDSCAPE)) {
			if (flags.isSet(OPTION_ORIENTATION_REVERSE))
				attr.add(OrientationRequested.REVERSE_LANDSCAPE);
			else
				attr.add(OrientationRequested.LANDSCAPE);
		}
		else if (flags.isSet(OPTION_ORIENTATION_PORTRAIT)) {
			if (flags.isSet(OPTION_ORIENTATION_REVERSE))
				attr.add(OrientationRequested.REVERSE_PORTRAIT);
			else
				attr.add(OrientationRequested.PORTRAIT);
		}

		String s = MApplication.getFullName();
		if (!TK.isEmpty(printTitle))
			s += (" - " + printTitle);
		attr.add(new JobName(s, null));

		return attr;
	}

}
