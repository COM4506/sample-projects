// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.print;

import java.awt.Color;
import java.awt.Component;
import java.lang.ref.WeakReference;

/**
 * @since 3.4
 */
public abstract class ComponentPrintInfo<T extends Component> extends AbstractPrintInfo<T> {

	// private

	private Color oldBackground;
	private Color oldForeground;
	private final WeakReference<T> componentRef;
	
	// public
	
	public ComponentPrintInfo(final String documentTitle, final T component, final String header, final String footer) {
		super(documentTitle, header, footer);
		componentRef = new WeakReference<>(component);
	}

	@Override
	public void afterPrint(final PrintResult result) {
		T t = componentRef.get();
		if (t != null) {
			t.setBackground(oldBackground);
			t.setForeground(oldForeground);
		}
	}

	@Override
	public void beforePrint() {
		T t = componentRef.get();
		if (t != null) {
			oldBackground = t.getBackground();
			oldForeground = t.getForeground();
			t.setBackground(Color.WHITE);
			t.setForeground(Color.BLACK);
		}
	}

	@Override
	public T getPrintComponent() {
		return componentRef.get();
	}

}
