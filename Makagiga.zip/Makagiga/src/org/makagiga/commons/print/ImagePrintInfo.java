// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.print;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.Image;
import java.awt.print.Printable;
import java.awt.print.PrinterAbortException;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import javax.print.attribute.PrintRequestAttributeSet;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.TK;
import org.makagiga.commons.swing.MSwingWorker;

/**
 * @since 2.0
 */
public class ImagePrintInfo extends AbstractPrintInfo<Component> implements MDisposable {
	
	// private
	
	private Image image;
	
	// public
	
	public ImagePrintInfo(final String documentTitle, final Image image) {
		super(documentTitle, null, null);
		this.image = image;
	}
	
	@Override
	public void afterPrint(final PrintResult result) { }
	
	@Override
	public void beforePrint() { }
	
	@Override
	public Printable getPrintable(final Flags flags) throws PrinterException {
		return new PrintableImage(image);
	}

	@Override
	public PrintInfo.PrintResult printDocument(final Flags flags) throws PrinterException {
		return printDocument(
			getPrintable(flags),
			getPrintTitle(),
			flags
		);
	}

	/**
	 * @since 3.4
	 */
	public static PrintResult printDocument(final Printable printable, final String documentTitle, final Flags flags) throws PrinterException {
		PrinterJob job = PrinterJob.getPrinterJob();
		job.setPrintable(printable);

		PrintRequestAttributeSet attr = getPrintRequestAttributeSet(flags, documentTitle);

		if (!job.printDialog(attr))
			return PrintResult.CANCELLED;

		PrintTask printTask = new PrintTask(printable, documentTitle, attr, job);
		printTask.start();

		return PrintResult.IN_PROGRESS;
	}

	// MDisposable

	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		image = null;
	}

	// private classes

	private static final class PrintTask extends MSwingWorker<Void> {

		// private

		private Printable printable;
		private PrinterJob job;
		private final PrintRequestAttributeSet attr;

		// protected

		@Override
		protected Void doInBackground() throws PrinterException {
			job.print(attr);

			return null;
		}

		@Override
		protected void onEnd() {
			job = null;
			if (printable instanceof MDisposable)
				printable = TK.dispose((MDisposable)printable);
			else
				printable = null;
		}

		@Override
		protected void onError(final Throwable throwable, final boolean cancelled) {
			if (cancelled) {
				job.cancel();
				PrintDialog.showMessage(PrintResult.CANCELLED);
			}
			else {
				if (throwable instanceof PrinterAbortException)
					PrintDialog.showMessage(PrintResult.CANCELLED, throwable);
				else
					PrintDialog.showMessage(PrintResult.ERROR, throwable);
			}
		}

		@Override
		protected void onSuccess(final Void result) {
			PrintDialog.showMessage(PrintResult.COMPLETE);
		}

		// private

		private PrintTask(final Printable printable, final String documentTitle, final PrintRequestAttributeSet attr, final PrinterJob job) {
			super(null, i18n("Printing \"{0}\"...", documentTitle), Option.STATUS_ICON);
			this.printable = printable;
			this.attr = attr;
			this.job = job;
		}

	}
	
}
