// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.print;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;

import org.makagiga.commons.MDisposable;
import org.makagiga.commons.UI;

/**
 * Based on the "Printing In Java" by Rob MacGrogan.
 * http://www.developerdotstar.com/community/node/124
 *
 * @since 2.0
 */
public class PrintableImage
implements
	MDisposable,
	Printable
{
	
	// private

	private Image image;
	
	// public

	/**
	 * @since 4.2
	 */
	public PrintableImage(final Component c) {
		int w = c.getWidth();
		int h = c.getHeight();
		BufferedImage bi = UI.createCompatibleImage(w, h, true);
		Graphics2D g = bi.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);
		UI.setBasicTextAntialiasing(g, true);
		c.print(g);
		g.dispose();
		image = bi;
	}

	public PrintableImage(final Image image) {
		this.image = image;
	}

	@Override
	public int print(final Graphics graphics, final PageFormat pageFormat, final int pageIndex) {
		if (pageIndex > 0)
			return NO_SUCH_PAGE;
		
		double pageHeight = pageFormat.getImageableHeight();
		double scale = UI.getAutoScale(image, new Dimension((int)pageFormat.getImageableWidth(), (int)pageHeight));

		Graphics2D g = (Graphics2D)graphics;

		g.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
		g.translate(0.0f, -pageIndex * pageHeight);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		g.scale(scale, scale);
		g.drawImage(image, 0, 0, null);

		return PAGE_EXISTS;
	}

	// MDisposable

	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		image = null;
	}
	
}
