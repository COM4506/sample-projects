// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.print;

import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import javax.swing.text.JTextComponent;

import org.makagiga.commons.AbstractMarkupBuilder;
import org.makagiga.commons.Flags;
import org.makagiga.commons.html.MHTMLViewer;

/**
 * @since 2.0
 */
public class TextPrintInfo extends ComponentPrintInfo<JTextComponent> {
	
	// public
	
	public TextPrintInfo(final String documentTitle, final JTextComponent text, final String header, final String footer) {
		super(documentTitle, text, header, footer);
	}
	
	@Override
	public Printable getPrintable(final Flags flags) throws PrinterException {
		return getPrintComponent().getPrintable(
			getPrintHeader(flags.isSet(PRINT_HEADER)),
			getPrintFooter(flags.isSet(PRINT_FOOTER))
		);
	}

	/**
	 * @since 4.0
	 */
	public static TextPrintInfo html(final String documentTitle, final AbstractMarkupBuilder html, final String header, final String footer) {
		return html(documentTitle, html.toString(), header, footer);
	}

	/**
	 * @since 2.4
	 */
	public static TextPrintInfo html(final String documentTitle, final String html, final String header, final String footer) {
		MHTMLViewer viewer = new MHTMLViewer();
		viewer.setHTML(html);

		return new TextPrintInfo(documentTitle, viewer, header, footer);
	}

	@Override
	public PrintInfo.PrintResult printDocument(final Flags flags) throws PrinterException {
		return printDocument(
			getPrintComponent(),
			flags,
			getPrintHeader(flags.isSet(PRINT_HEADER)),
			getPrintFooter(flags.isSet(PRINT_FOOTER)),
			getPrintTitle()
		);
	}

	/**
	 * @since 3.4
	 */
	public static PrintResult printDocument(final JTextComponent textComponent, final Flags flags, final MessageFormat header, final MessageFormat footer) throws PrinterException {
		return printDocument(textComponent, flags, header, footer, null);
	}

	/**
	 * @since 3.8.11
	 */
	public static PrintResult printDocument(final JTextComponent textComponent, final Flags flags, final MessageFormat header, final MessageFormat footer, final String printTitle) throws PrinterException {
		return textComponent.print(
			header,
			footer,
			true, // show print dialog
			null, // default print service
			getPrintRequestAttributeSet(flags, printTitle),
			true // interactive
		)
		? PrintResult.COMPLETE
		: PrintResult.CANCELLED;
	}

}
