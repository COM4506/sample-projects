// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.print;

import static org.makagiga.commons.UI.i18n;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import javax.swing.JTable;

import org.makagiga.commons.Config;
import org.makagiga.commons.EnumProperty;
import org.makagiga.commons.Flags;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.TriBoolean;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MCheckBox;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MFileChooser;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MRadioButton;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.MStatusBar;
import org.makagiga.commons.swing.MTable;

/**
 * @since 2.0
 */
public class PrintDialog extends MDialog {
	
	// private

	private JTable table;
	private MCheckBox printFooter;
	private MCheckBox printHeader;
	private MRadioButton fitWidthTablePrintMode;
	private MRadioButton normalTablePrintMode;
	private PrintInfo<?> printInfo;
	private PrintInfo.PrintResult printResult = PrintInfo.PrintResult.UNKNOWN;
	private PrintPreviewPanel printPreview;
	
	// public

	public PrintDialog(final Window parent, final PrintInfo<?> printInfo) {
		super(
			parent,
			i18n("\"{0}\" - Print Preview", TK.centerSqueeze(printInfo.getPrintTitle())),
			"ui/print",
			FORCE_STANDARD_BORDER | SIDE_BUTTONS | STANDARD_DIALOG | USER_BUTTON
		);
		this.printInfo = printInfo;
		if (printInfo.getPrintComponent() instanceof JTable)
			table = (JTable)printInfo.getPrintComponent();
		printInfo.beforePrint();
		
		getOKButton().setActionInfoUI(MActionInfo.CONTINUE);
		getMainPanel().setMargin(0, 0, 0, MPanel.DEFAULT_CONTENT_MARGIN);

		Path path =
			(printInfo instanceof AbstractPrintInfo<?>)
			? AbstractPrintInfo.class.cast(printInfo).getPath()
			: null;
		final File file = (path == null) ? null : path.toFile();
		
		MButton userButton = getUserButton();
		userButton.setText(MActionInfo.ADVANCED.getText()); // no icon
		
// TODO: native ImagePrintInfo, HTML, etc.
		MAction externalPrintAction = new MAction(i18n("Print using an external application..."), self -> {
			try {
				Desktop desktop = Desktop.getDesktop();
				desktop.print(file);
			}
			catch (IllegalArgumentException | IOException | UnsupportedOperationException exception) {
				self.showErrorMessage(exception);
			}
		} );

		try {
			externalPrintAction.setEnabled(
				(file != null) &&
				Desktop.getDesktop().isSupported(Desktop.Action.PRINT)
			);
		}
		catch (UnsupportedOperationException exception) {
			externalPrintAction.setEnabled(false);
		}
		// bad implementation...
		catch (Exception exception) {
			MLogger.exception(exception);
			externalPrintAction.setEnabled(false);
		}
		externalPrintAction.setIconName("ui/print");
		
		MMenu advancedMenu = new MMenu();
		advancedMenu.add(externalPrintAction);
		
		userButton.setComponentPopupMenu(advancedMenu.getPopupMenu());
		userButton.setEnabled(externalPrintAction.isEnabled());
		userButton.setPopupMenuEnabled(true);

		// read window size
		Config config = getConfigPrivileged();
		
		Dimension minSize = UI.WindowSize.MEDIUM.getDimension();
		Dimension size = config.readDimension(Config.getScreenKey("PrintPreview"), UI.WindowSize.LARGE.getDimension());
		size.width = Math.max(minSize.width, size.width);
		size.height = Math.max(minSize.height, size.height);
		setSize(size);

		printPreview = new PrintPreviewPanel(printInfo);
		printPreview.orientation = config.readInt("PrintPreview.orientation", PageFormat.PORTRAIT);
		addCenter(printPreview);

		MPanel p = getButtonsPanel();

		p.addSeparator(i18n("Current Page"));
		p.add(printPreview.getPagePanel());

		p.addSeparator(i18n("Options"));
		createComponents(p);

		updatePreview();
	}
	
	/**
	 * @since 3.8.4
	 */
	public static PrintInfo.PrintResult printDocument(final PrintInfo<?> printInfo, final Flags flags) {
		PrintInfo.PrintResult result;
		try {
			result = printInfo.printDocument(flags);
			showMessage(result);
		}
		catch (PrinterException exception) {
			result = PrintInfo.PrintResult.ERROR;
			showMessage(result, exception);
		}

		return result;
	}

	public static void showMessage(final PrintInfo.PrintResult result) {
		showMessage(result, null);
	}
	
	public static void showMessage(final PrintInfo.PrintResult result, final Throwable cause) {
		switch (result) {
			case CANCELLED:
				if (cause != null)
					MLogger.exception(cause);
				MStatusBar.error(i18n("Printing cancelled"));
				break;
			case ERROR:
				MMessage.error(UI.windowFor(null), cause, i18n("Print failed"));
				break;
			case IN_PROGRESS:
				if (cause != null)
					MLogger.exception(cause);
				MStatusBar.info(i18n("Printing in progress"));
				break;
			case COMPLETE:
				if (cause != null)
					MLogger.exception(cause);
				MStatusBar.info(i18n("Printing complete"));
				break;
			default: // UNKNOWN
		}
	}

	/**
	 * @since 3.2
	 */
	@InvokedFromConstructor
	public void updatePreview() {
		printPreview.flags = getPrintFlags();
		printPreview.refresh(true);
	}

	// protected

	@Override
	protected boolean onAccept() {
		// init look and feel
		MFileChooser.init(); // for "Print to file" dialog

		final int optionOrientation = getSelectedOrientation();
		final TriBoolean optionPrintFooter = printFooter.isEnabled() ? TriBoolean.of(printFooter.isSelected()) : TriBoolean.UNDEFINED;
		final TriBoolean optionPrintHeader = printHeader.isEnabled() ? TriBoolean.of(printHeader.isSelected()) : TriBoolean.UNDEFINED;
		final String optionFitWidthTablePrintMode;
		if (fitWidthTablePrintMode != null) {
			optionFitWidthTablePrintMode =
				fitWidthTablePrintMode.isSelected()
				? MTable.PrintMode.FIT_WIDTH.toString()
				: MTable.PrintMode.NORMAL.toString();
		}
		else {
			optionFitWidthTablePrintMode = null;
		}

		MAccessController.doPrivileged(() -> {
			Config config = Config.getDefault();
			if (optionPrintFooter.isDefined())
				config.write("Print.footer", optionPrintFooter.isTrue());
			if (optionPrintHeader.isDefined())
				config.write("Print.header", optionPrintHeader.isTrue());
			config.write("PrintPreview.orientation", optionOrientation);
			if (optionFitWidthTablePrintMode != null)
				config.write("Print.tablePrintMode", optionFitWidthTablePrintMode);
			config.sync();

			return null;
		} );
		
		printResult = printDocument(printInfo, getPrintFlags());
		
		return true;
	}
	
	@Override
	protected void onClose() {
		printPreview = TK.dispose(printPreview);
		
		// save window size
		Dimension size = getSize();
		MAccessController.doPrivileged(() -> {
			Config config = Config.getDefault();
			config.write(Config.getScreenKey("PrintPreview"), size);
			config.sync();

			return null;
		} );

		printInfo.afterPrint(printResult);
		if (printInfo instanceof MDisposable)
			printInfo = TK.dispose((MDisposable)printInfo);
		else
			printInfo = null;
	}

	// private

	private void createComponents(final MPanel p) {
		Config config = getConfigPrivileged();

		// paper format

		MRadioButton portraitOrientation = new MRadioButton(i18n("Portrait"));
		portraitOrientation.addActionListener(e -> setPageFormat(PageFormat.PORTRAIT));
		portraitOrientation.setSelected(printPreview.orientation == PageFormat.PORTRAIT);
		portraitOrientation.setToolTipText(i18n("Orientation"));
		p.add(portraitOrientation);

		MRadioButton landscapeOrientation = new MRadioButton(i18n("Landscape"));
		landscapeOrientation.addActionListener(e -> setPageFormat(PageFormat.LANDSCAPE));
		landscapeOrientation.setSelected(printPreview.orientation == PageFormat.LANDSCAPE);
		landscapeOrientation.setToolTipText(i18n("Orientation"));
		p.add(landscapeOrientation);

		UI.group(portraitOrientation, landscapeOrientation);
		
		p.addGap();

		Flags capabilities = Flags.valueOf(printInfo.getPrintingCapabilities());
		
		printHeader = new MCheckBox(i18n("Print Header"));
		printHeader.addActionListener(e -> {
			updatePreview();
			MScrollPane.scrollToTop(printPreview.preview, false);
		} );
		printHeader.setToolTipText(i18n("Select this option to print page number and title."));
		if (capabilities.isSet(PrintInfo.PRINT_HEADER))
			printHeader.setSelected(config.read("Print.header", true));
		else
			printHeader.setEnabled(false);
		p.add(printHeader);

		printFooter = new MCheckBox(i18n("Print Footer"));
		printFooter.addActionListener(e -> {
			updatePreview();
			MScrollPane.scrollToBottom(printPreview.preview, false);
		} );
		printFooter.setToolTipText(i18n("Select this option to print current date and time."));
		if (capabilities.isSet(PrintInfo.PRINT_FOOTER))
			printFooter.setSelected(config.read("Print.footer", true));
		else
			printFooter.setEnabled(false);
		p.add(printFooter);

		// tool tips based on the "javax.swing.JTable.PrintMode" API documentation

		// table support
		if (table != null) {
			p.addSeparator(i18n("Table"));
			// fit width
			fitWidthTablePrintMode = new MRadioButton(i18n("Fit Width"));
			fitWidthTablePrintMode.addActionListener(e -> updatePreview());
			UI.setHTMLHelp(fitWidthTablePrintMode, i18n("Printing mode that scales the output smaller,<br>if necessary, to fit the table's entire width on each page."));
			p.add(fitWidthTablePrintMode);
			// normal
			normalTablePrintMode = new MRadioButton(i18n("Normal"));
			normalTablePrintMode.addActionListener(e -> updatePreview());
			UI.setHTMLHelp(normalTablePrintMode, i18n("Printing mode that prints the table at its current size,<br>spreading both columns and rows across multiple pages if necessary."));
			p.add(normalTablePrintMode);

			UI.group(
				fitWidthTablePrintMode,
				normalTablePrintMode
			);
			
			// NOTE: backward compatibility: do not use "readEnum"
			MTable.PrintMode printMode = EnumProperty.parse(config.read("Print.tablePrintMode", null), MTable.PrintMode.FIT_WIDTH);
			switch (printMode) {
				case FIT_WIDTH:
					fitWidthTablePrintMode.setSelected(true);
					break;
				case NORMAL:
					normalTablePrintMode.setSelected(true);
					break;
				default:
					throw new WTFError(printMode);
			}
		}
	}

	private Config getConfigPrivileged() {
		SecurityManager sm = System.getSecurityManager();

		if (sm == null)
			return Config.getDefault();

		return MAccessController.doPrivileged(Config::getDefault);
	}

	private Flags getPrintFlags() {
		long flags = 0;
		
		if (fitWidthTablePrintMode != null) {
			if (fitWidthTablePrintMode.isSelected())
				flags |= PrintInfo.TABLE_FIT_WIDTH;
			else if (normalTablePrintMode.isSelected())
				flags |= PrintInfo.TABLE_NORMAL_WIDTH;
		}
		
		if (printHeader.isEnabled() && printHeader.isSelected())
			flags |= PrintInfo.PRINT_HEADER;

		if (printFooter.isEnabled() && printFooter.isSelected())
			flags |= PrintInfo.PRINT_FOOTER;

		int pageFormat = getSelectedOrientation();
		switch (pageFormat) {
			case PageFormat.PORTRAIT:
				flags |= PrintInfo.OPTION_ORIENTATION_PORTRAIT;
				break;
			case PageFormat.LANDSCAPE:
				flags |= PrintInfo.OPTION_ORIENTATION_LANDSCAPE;
				break;
			case PageFormat.REVERSE_LANDSCAPE:
				flags |= (PrintInfo.OPTION_ORIENTATION_LANDSCAPE | PrintInfo.OPTION_ORIENTATION_REVERSE);
				break;
			default:
				throw new WTFError("Uknown page format orientation: " + pageFormat);
		}

		return Flags.valueOf(flags);
	}

	private int getSelectedOrientation() {
		return (printPreview != null) ? printPreview.orientation : PageFormat.PORTRAIT;
	}

	private void setPageFormat(final int value) {
		// check if all components are initialized
		if ((printPreview != null) && (printHeader != null)) {
			printPreview.orientation = value;
			updatePreview();
		}
	}
	
}
