// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Dimension;

import org.makagiga.commons.annotation.Uninstantiable;

public final class MFormat {
	
	// public
	
	/**
	 * @since 2.2
	 */
	public enum ByteFormat { AUTO, B, KB, MB, GB }

	/**
	 * @since 2.2
	 */
	public static final long KB = 1024;
	
	/**
	 * @since 2.2
	 */
	public static final long MB = KB * KB;
	
	/**
	 * @since 2.2
	 */
	public static final long GB = MB * KB;
	
	// public

	/**
	 * @since 5.2
	 */
	public static String dimension(final Dimension size) {
		return dimension(size.width, size.height);
	}

	/**
	 * @since 5.2
	 */
	public static String dimension(final int w, final int h) {
		return w + " " + UI.MULTIPLICATION_SIGN + " " + h;
	}

	/**
	 * @since 5.2
	 */
	public static String nano(final long value) {
		return String.format("%1.2f", value / 1000000f);
	}
	
	public static String toAutoSize(final long value) {
		if (value == -1)
			return "? KiB";

		if (value > GB)
			return toGB(value);
		
		if (value > MB)
			return toMB(value);
		
		return toKB(value);
	}

	/**
	 * @since 2.2
	 */
	public static String toGB(final long value) {
		return String.format("%1.2f GiB", value / (float)GB);
	}

	public static String toKB(final long value) {
		return String.format("%1.2f KiB", value / (float)KB);
	}

	public static String toMB(final long value) {
		return String.format("%1.2f MiB", value / (float)MB);
	}
	
	/**
	 * @since 2.2
	 */
	public static String toSize(final long value, final ByteFormat format) {
		switch (format) {
			case AUTO:
				return toAutoSize(value);
			case B:
				return (Long.toString(value) + " B");
			case KB:
				return toKB(value);
			case MB:
				return toMB(value);
			case GB:
				return toGB(value);
			default:
				throw new WTFError(format);
		}
	}
	
	/**
	 * @since 2.0
	 */
	public static String toPercent(final float value) {
		return String.format("%1.1f%%", value);
	}
	
	// private
	
	@Uninstantiable
	private MFormat() {
		TK.uninstantiable();
	}
	
}
