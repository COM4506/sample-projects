// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.Objects;
import java.util.regex.Pattern;

import org.makagiga.commons.annotation.DesignPattern;
import org.makagiga.commons.annotation.Important;

/**
 * @since 4.10
 *
 * @deprecated Since 5.6
 */
@Deprecated
@DesignPattern(DesignPattern.BUILDER)
public class PatternBuilder implements Serializable {

	// private
	
	@SuppressWarnings("PMD.AvoidStringBufferField")
	private final StringBuilder buf;

	// public

	public PatternBuilder() {
		buf = new StringBuilder();
	}

	public PatternBuilder any() {
		buf.append('.');
	
		return this;
	}

	public PatternBuilder clear() {
		buf.setLength(0);
	
		return this;
	}

	public PatternBuilder digit() {
		buf.append("\\d");

		return this;
	}

	public PatternBuilder oneOrMore() {
		buf.append('+');

		return this;
	}

	public PatternBuilder pattern(final String pattern) {
		Objects.requireNonNull(pattern);
	
		buf.append(pattern);

		return this;
	}

	public PatternBuilder quote(final String text) {
		Objects.requireNonNull(text);
	
		buf.append("\\Q");
		buf.append(text);
		buf.append("\\E");
		
		return this;
	}
	
	public static PatternBuilder startsWithQuote(final String text) {
		PatternBuilder p = new PatternBuilder();
		p.quote(text).any().zeroOrMore();
		
		return p;
	}
	
	public Pattern toPattern() {
		return Pattern.compile(toString());
	}

	@Important
	@Override
	public String toString() {
		return buf.toString();
	}

	public PatternBuilder zeroOrMore() {
		buf.append('*');

		return this;
	}

}
