// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Comparator;

import org.makagiga.commons.AbstractScanner;
import org.makagiga.commons.FS;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Obsolete;

/**
 * A recursive file scanner.
 * All files are sorted by name (directories first, ignored case).
 *
 * @see java.nio.file.FileVisitor
 *
 * @since 4.0 (org.makagiga.commons.io package)
 */
@Obsolete
public abstract class FileScanner<I, E extends Exception> extends AbstractScanner {

	// private

	private Comparator<File> comparator;
	private static final Comparator<File> defaultComparator = new DefaultComparator();

	// public

	/**
	 * Constructs a file scanner.
	 * 
	 * @param parentItem A parent item. Can be @c null.
	 * @param root A start directory
	 * @param comparator A file comparator (may be @c null).
	 *
	 * @throws E A generic exception
	 * @throws FileNotFoundException If @p root directory does not exist
	 *
	 * @since 2.0
	 */
	public FileScanner(final I parentItem, final File root, final Comparator<File> comparator) throws E, FileNotFoundException {
		if (!root.exists())
			throw new FileNotFoundException(root.getPath());
		
		this.comparator = comparator;

		recurse(parentItem, root);
	}

	/**
	 * Constructs a file scanner with the @ref getDefaultComparator.
	 * @param parentItem A parent item. Can be @c null.
	 * @param root A start directory
	 *
	 * @throws E A generic exception
	 * @throws FileNotFoundException If @p root directory does not exist
	 *
	 * @since 2.0
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public FileScanner(final I parentItem, final File root) throws E, FileNotFoundException {
		this(parentItem, root, getDefaultComparator());
	}

	/**
	 * Constructs a file scanner with the @ref getDefaultComparator.
	 * @param root The start directory
	 *
	 * @throws E A generic exception
	 * @throws FileNotFoundException If @p root directory does not exist
	 *
	 * @since 2.0
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public FileScanner(final File root) throws E, FileNotFoundException {
		this(null, root, getDefaultComparator());
	}
	
	/**
	 * Returns the file comparator (may be @c null).
	 *
	 * @since 1.2
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public Comparator<File> getComparator() { return comparator; }
	
	/**
	 * Sets the file comparator to @p value (may be @c null).
	 *
	 * @since 1.2
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public void setComparator(final Comparator<File> value) { comparator = value; }

	/**
	 * Returns the default file comparator.
	 * 
	 * PROPERTIES:
	 * - Sorts files by its name
	 * - Directories first
	 * - Ignored case
	 *
	 * @since 1.2
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public static Comparator<File> getDefaultComparator() { return defaultComparator; }

	/**
	 * Called on each directory.
	 * @param parentItem A parent item. Can be @c null.
	 * @param dir A directory
	 *
	 * @throws E A generic exception
	 */
	public I processDir(final I parentItem, final File dir) throws E { return null; }

	/**
	 * Called on each regular file.
	 * @param parentItem A parent item. Can be @c null.
	 * @param file A regular file
	 *
	 * @throws E A generic exception
	 */
	public abstract void processFile(final I parentItem, final File file) throws E;
	
	/**
	 * @since 1.2
	 */
	public void processParentDir(final I item, final File dir) throws E { }

	// private

	private void recurse(final I parentItem, final File dir) throws E {
		if (isStopped())
			return;

		File[] files = FS.listFiles(dir);

		if (files.length == 0)
			return;

		if (comparator != null)
			Arrays.sort(files, comparator);

		for (File i : files) {
			// folder
			if (i.isDirectory()) {
				I parent = processDir(parentItem, i);

				if (isStopped())
					return;

				recurse(parent, i);

				if (isStopped())
					return;
				
				processParentDir(parent, i);
				
				if (isStopped())
					return;
			}
			// file
			else if (i.isFile()) {
				processFile(parentItem, i);

				if (isStopped())
					return;
			}
		}
	}
	
	// public classes
	
	/**
	 * @since 3.0
	 */
	@Obsolete
	public static class Simple extends FileScanner<Object, Exception> {
		
		// public
		
		public Simple(final File root) throws Exception {
			super(root);
		}

		public Simple(final File root, final Comparator<File> comparator) throws Exception {
			super(null, root, comparator);
		}

		/**
		 * @deprecated Since 4.6
		 */
		@Deprecated
		public Simple(final String root) throws Exception {
			super(new File(root));
		}

		public void processDir(final File file) throws Exception { }
		
		public void processFile(final File file) throws Exception { }

		@Override
		public final Object processDir(final Object parentItem, final File dir) throws Exception {
			processDir(dir);
			
			return null;
		}
		
		@Override
		public final void processFile(final Object parentItem, final File file) throws Exception {
			processFile(file);
		}

	}

	// private classes

	private static final class DefaultComparator
	implements
		Comparator<File>,
		Serializable
	{

		// public

		@Override
		public int compare(final File f1, final File f2) {
			int i = TK.compareFirst(f1.isDirectory(), f2.isDirectory());
			
			if (i != 0)
				return i;

			return f1.getName().compareToIgnoreCase(f2.getName());
		}

		// private

		private DefaultComparator() { }

	}

}
