// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MDate;

/**
 * A type-safe data input stream.
 *
 * @see MDataOutputStream
 *
 * @since 3.8.12
 */
public class MDataInputStream extends DataInputStream {

	// public

	/**
	 * Constructs a new input stream.
	 *
	 * @param buf the input bytes
	 *
	 * @throws NullPointerException If {@code buf} is {@code null}
	 */
	public MDataInputStream(final byte[] buf) {
		super(new ByteArrayInputStream(buf));
	}

	/**
	 * Constructs a new input stream.
	 *
	 * @param in the underlying input stream (or {@code null})
	 */
	public MDataInputStream(final InputStream in) {
		super(in);
	}

	/**
	 * Reads an array.
	 *
	 * @throws IOException If data type verification failed
	 *
	 * @see MDataOutputStream#writeArray(Object[])
	 */
	public Object[] readArray() throws IOException {
		DataType.ARRAY.verifyID(this);

		int len = readInt();
		Object[] result = new Object[len];
		for (int i = 0; i < len; i++) {
			result[i] = readProperty();
		}

		return result;
	}

	public List<?> readCollection() throws IOException {
		DataType.COLLECTION.verifyID(this);

		int len = readInt();
		MArrayList<Object> result = new MArrayList<>(len);
		for (int i = 0; i < len; i++) {
			result.add(readProperty());
		}
		
		return result;
	}

	public DataHeader readHeader() throws IOException {
		return readHeader(null);
	}

	public DataHeader readHeader(final String expectedID) throws IOException {
		Map<String, ?> map = readPropertyMap();

		if (expectedID != null) {
			String id = (String)map.get(DataHeader.ID);

			if (!expectedID.equals(id))
				throw new IOException("Invalid ID: " + id + " (expected: " + expectedID + ")");
		}

		DataHeader header = new DataHeader();
		header.putAll(map);

		return header;
	}

	@SuppressFBWarnings("URV_UNRELATED_RETURN_VALUES")
	public Object readProperty() throws IOException {
		byte type = readByte();
		switch (type) {
			case DataType.NULL_ID: return null;
			case DataType.BOOLEAN_ID: return readBoolean();
			case DataType.BYTE_ID: return readByte();
			case DataType.CHARACTER_ID: return readChar();
			case DataType.DOUBLE_ID: return readDouble();
			case DataType.FLOAT_ID: return readFloat();
			case DataType.INTEGER_ID: return readInt();
			case DataType.LONG_ID: return readLong();
			case DataType.SHORT_ID: return readShort();
			case DataType.STRING_ID: return readUTF();
			case DataType.BYTE_ARRAY_ID: {
				int len = readInt();
				byte[] b = new byte[len];
				readFully(b);
			
				return b;
			}
			case DataType.DATE_ID: return new MDate(readLong());
			case DataType.COLOR_ID: {
				return new Color(
					readUnsignedByte(), // r
					readUnsignedByte(), // g
					readUnsignedByte(), // b
					readUnsignedByte() // a
				);
			}
			default: throw new IOException("Unsupported property type: " + type);
		}
	}

	public Object readProperty(final String expectedName) throws IOException {
		String name = readUTF();

		if (!expectedName.equals(name))
			throw new IOException("Invalid property name: " + name + " (expected: " + expectedName + ")");

		return readProperty();
	}

	/**
	 * @since 5.0
	 */
	public Map<String, ?> readPropertyHashMap() throws IOException {
		DataType.MAP.verifyID(this);

		int len = readInt();
		Map<String, Object> result = new HashMap<>(len, 1.0f);
		for (int i = 0; i < len; i++) {
			result.put(readUTF(), readProperty());
		}

		return result;
	}

	public Map<String, ?> readPropertyMap() throws IOException {
		DataType.MAP.verifyID(this);

		int len = readInt();
		Map<String, Object> result = new LinkedHashMap<>(len, 1.0f);
		for (int i = 0; i < len; i++) {
			result.put(readUTF(), readProperty());
		}

		return result;
	}

}