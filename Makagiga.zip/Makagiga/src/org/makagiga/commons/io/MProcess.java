// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;
import java.util.concurrent.atomic.LongAdder;

import org.makagiga.commons.FS;
import org.makagiga.commons.MLogger;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.io package)
 */
public class MProcess {

	// private

	private static final LongAdder nextNumber = new LongAdder();
	private static final MLogger log = MLogger.get("process");
	private OutputStream errStream;
	private OutputStream outStream;
	private Process process;
	
	// public
	
	public MProcess(final String... commandAndArgs) throws IOException {
		this((File)null, commandAndArgs);
	}

	/**
	 * @since 3.0
	 */
	public MProcess(final File dir, final String... commandAndArgs) throws IOException {
		ProcessBuilder pb = new ProcessBuilder(commandAndArgs);
		if (dir != null)
			pb.directory(dir);
		
		pb.inheritIO();
		
		process = pb.start();
	}

	/**
	 * @since 3.0
	 */
	public MProcess(final File dir, final OutputStream targetOutputStream, final OutputStream targetErrorStream, final String... commandAndArgs) throws IOException {
		ProcessBuilder pb = new ProcessBuilder(commandAndArgs);
		if (dir != null)
			pb.directory(dir);

		process = pb.start();
		initRedirect(targetOutputStream, targetErrorStream);
	}

	/**
	 * @since 4.2
	 */
	public MProcess(final ProcessBuilder processBuilder, final OutputStream targetOutputStream, final OutputStream targetErrorStream) throws IOException {
		process = processBuilder.start();
		initRedirect(targetOutputStream, targetErrorStream);
	}

	public Process getProcess() { return process; }
	
	/**
	 * Returns a @c non-null error stream
	 * specified in the @c MProcess constructor.
	 * 
	 * The default error stream is @c System.err.
	 * 
	 * @since 3.0
	 */
	public OutputStream getTargetErrorStream() { return errStream; }

	/**
	 * Returns a @c non-null output stream
	 * specified in the @c MProcess constructor.
	 * 
	 * The default error stream is @c System.out.
	 * 
	 * @since 3.0
	 */
	public OutputStream getTargetOutputStream() { return outStream; }
	
	public boolean isRunning() {
		return process.isAlive();
	}
	
	public void kill() {
		process.destroy();
	}
	
	/**
	 * @since 4.2
	 */
	public static StringBuilder readOutputText(final ProcessBuilder p, final Charset charset) throws InterruptedException, IOException {
		Path out = Files.createTempFile("out_" + p.command().get(0), null);
		try {
			p.inheritIO();
			p.redirectOutput(out.toFile());
			p.start()
				.waitFor();

			return FS.read(out, charset);
		}
		finally {
			FS.deleteSilently(out);
		}
	}

	// protected
	
	/**
	 * @since 4.0
	 */
	protected void onRedirectComplete() { }
	
	// private
	
	private void initRedirect(final OutputStream outStream, final OutputStream errStream) {
		this.outStream = Objects.requireNonNull(outStream);
		this.errStream = Objects.requireNonNull(errStream);

		nextNumber.increment();

		Thread t = new Thread(() -> {
			log.debug("Begin thread");

			do {
				try {
					FS.copyStream(process.getInputStream(), outStream);
					FS.copyStream(process.getErrorStream(), errStream);
				}
				catch (IOException exception) {
					MLogger.exception(exception);

					break; // while
				}
			} while (isRunning() /*&& !MApplication.isShutDown()*/);

			log.debug("End thread");

			onRedirectComplete();
		}, "Process " + nextNumber.longValue());
		t.setDaemon(true);
		t.start();
	}
	
}
