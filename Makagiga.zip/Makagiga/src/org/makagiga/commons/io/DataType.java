// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @since 3.8.12
 */
public enum DataType {

	// public

	NULL(0),
	BOOLEAN(1),
	BYTE(2),
	CHARACTER(3),
	DOUBLE(4),
	FLOAT(5),
	INTEGER(6),
	LONG(7),
	SHORT(8),
	STRING(9),
	
	ARRAY(10),
	COLLECTION(11),
	MAP(12),
	
	BYTE_ARRAY(13),
	DATE(14),
	COLOR(15);

	// private

	private final byte id;

	// package

	static final byte NULL_ID = 0;
	static final byte BOOLEAN_ID = 1;
	static final byte BYTE_ID = 2;
	static final byte CHARACTER_ID = 3;
	static final byte DOUBLE_ID = 4;
	static final byte FLOAT_ID = 5;
	static final byte INTEGER_ID = 6;
	static final byte LONG_ID = 7;
	static final byte SHORT_ID = 8;
	static final byte STRING_ID = 9;
	static final byte ARRAY_ID = 10;
	static final byte COLLECTION_ID = 11;
	static final byte MAP_ID = 12;
	static final byte BYTE_ARRAY_ID = 13;
	static final byte DATE_ID = 14;
	static final byte COLOR_ID = 15;

	// public

	/**
	 * Returns the ID byte.
	 */
	public byte getID() { return id; }

	/**
	 * @since 4.2
	 */
	public void verifyID(final DataInputStream in) throws IOException {
		byte b = in.readByte();
		
		if (b != id)
			throw new IOException("Expected " + name() + " data type ID");
	}

	/**
	 * @since 4.2
	 */
	public void writeID(final DataOutputStream out) throws IOException {
		out.writeByte(id);
	}

	// private
	
	private DataType(final int id) {
		this.id = (byte)id;
	}

}