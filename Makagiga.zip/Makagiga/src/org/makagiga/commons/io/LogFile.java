// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import java.io.Closeable;
import java.io.File;
import java.io.Flushable;
import java.io.Serializable;
import java.util.Objects;

import org.makagiga.commons.FS;
import org.makagiga.commons.annotation.Important;

/**
 * A log file.
 *
 * <ul>
 * <li>Log file size is automatically limited to 0,5 MB</li>
 * <li>Previous log file will be saved with an ".old" extension</li>
 * </ul>
 *
 * @mg.threadSafe
 *
 * @since 1.2, 4.0 (org.makagiga.commons.io package)
 */
public class LogFile
implements
	Closeable,
	Flushable,
	Serializable
{
	
	// private
	
	private final File file;
	private final int maxBufSize;
	private static final int MIN_SIZE = 64 * 1024; // 64 KB
	private final long maxFileSize;
	
	@SuppressWarnings("PMD.AvoidStringBufferField")
	private StringBuilder buf;
	
	// public

	/**
	 * Constructs a log file with an empty buffer.
	 *
	 * @param file the output file
	 *
	 * @throws NullPointerException If {@code file} is {@code null}
	 */
	public LogFile(final File file) {
		this(file, 512 * 1024, MIN_SIZE);
	}

	/**
	 * @since 4.2
	 */
	public LogFile(final File file, final long maxFileSize, final int maxBufferSize) {
		this.file = Objects.requireNonNull(file);

		if (maxFileSize < MIN_SIZE)
			throw new IllegalArgumentException("maxFileSize < " + MIN_SIZE);

		if (maxBufferSize < MIN_SIZE)
			throw new IllegalArgumentException("maxBufferSize < " + MIN_SIZE);

		this.maxFileSize = maxFileSize;
		this.maxBufSize = maxBufferSize;
		buf = new StringBuilder(maxBufSize);
	}

	/**
	 * Appends {@code text} to the log file.
	 * Does nothing if the log was closed by the {@link #close()} method.
	 */
	public synchronized void append(final String text) {
		if (buf == null)
			return;

		buf.append(text);
		if (buf.length() > maxBufSize)
			flush();
	}
	
	/**
	 * Clears the buffer and deletes the log file.
	 * Does nothing if the log was closed by the {@link #close()} method.
	 */
	public synchronized void clear() {
		if (buf == null)
			return;

		buf.setLength(0); // reset
		
		File oldLog = new File(file.getPath() + ".old");
		oldLog.delete();

		file.delete();
	}

	/**
	 * Writes all collected data to the log file and clears the buffer.
	 *
	 * @see #flush()
	 */
	@Override
	public void close() {
		flush();
		synchronized (this) {
			buf = null;
		}
	}

	/**
	 * Writes all collected data to the log file and clears the buffer.
	 * Does nothing if the log was closed by the {@link #close()} method.
	 *
	 * @see #close()
	 */
	@Override
	public synchronized void flush() {
		if (buf == null)
			return;

		try {
			// limit log file size
			if (file.length() > maxFileSize) {
				// keep previous log file
				File oldLog = new File(file.getPath() + ".old");
				oldLog.delete();
				file.renameTo(oldLog);

				file.delete();
			}
			FS.append(file, buf.toString());
			file.setReadable(false, false);
			file.setReadable(true, true);
			buf.setLength(0); // reset
		}
		catch (Exception exception) {
			buf.setLength(0); // reset
			
			// quiet because of possible System.err/out IO redirections
		}
	}

	/**
	 * Returns the log file.
	 */
	public synchronized File getFile() { return file; }
	
	/**
	 * @mg.default 64 KB
	 *
	 * @since 4.2
	 */
	public int getMaximumBufferSize() { return maxBufSize; }

	/**
	 * @mg.default 0,5 MB
	 *
	 * @since 4.2
	 */
	public long getMaximumFileSize() { return maxFileSize; }

	/**
	 * Returns the log text,
	 * or empty {@code String} if log was closed.
	 */
	@Important
	@Override
	public synchronized String toString() {
		return Objects.toString(buf, "");
	}
	
}
