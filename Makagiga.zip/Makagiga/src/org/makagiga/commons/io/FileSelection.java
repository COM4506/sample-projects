// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.List;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.AbstractSelection;
import org.makagiga.commons.FS;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;

/**
 * @since 4.0 (org.makagiga.commons.io package)
 */
public class FileSelection extends AbstractSelection<FileSelection.FileList> {
	
	// public
	
	public static final DataFlavor URI_LIST = createDataFlavor("text/uri-list", "java.lang.String");
	public static final String MOZ_URL = "text/x-moz-url";

	// private
	
	private static final String LINE_SEPARATOR = "\r\n";

	// public
	
	public FileSelection(final FileList files) {
		super(
			files,
			URI_LIST, DataFlavor.javaFileListFlavor
		);
	}

	@Override
	@SuppressFBWarnings("URV_INHERITED_METHOD_WITH_RELATED_TYPES")
	public synchronized Object getContents(final DataFlavor flavor) {
		if (flavor.equals(DataFlavor.javaFileListFlavor))
			return new FileList(getData());

		return toURIList(getData(), flavor);
	}
	
	public synchronized static URIList getURIList(final Transferable transferable) {
		for (DataFlavor flavor : transferable.getTransferDataFlavors()) {
			if (flavor.equals(DataFlavor.javaFileListFlavor)) {
				try {
					Object data = transferable.getTransferData(flavor);

					if (data instanceof List<?>) {
						@SuppressWarnings("unchecked")
						List<File> fileList = (List<File>)data;
						if (!fileList.isEmpty()) {
							URIList result = new URIList(fileList.size());
							for (File i : fileList)
								result.add(i.toPath().toUri());

							return result;
						}
					}
				}
				catch (IOException | UnsupportedFlavorException exception) {
					MLogger.exception(exception);
				}
			}

			// RFC 2483 - URI list
			// HACK: workaround for
			// http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4899516
			if (
				flavor.getMimeType().startsWith("text/uri-list") &&
				flavor.getRepresentationClass().equals(String.class)
			) {
				FS.TextReader reader = null;
				try {
					Object data = transferable.getTransferData(flavor);

					if (data instanceof String) {
						URIList result = new URIList();
						reader = new FS.TextReader(data.toString());
						for (String line : reader) {
							if (TK.startsWith(line, '#') || line.equals("\u0000"))
								continue; // while

							result.add(new URI(line));
						}

						return result;
					}
				}
				catch (IOException | UnsupportedFlavorException | URISyntaxException exception) {
					MLogger.exception(exception);
				}
				finally {
					FS.close(reader);
				}
				
				return null;
			}
			// Mozilla URL
			else if (flavor.getMimeType().startsWith(MOZ_URL)) {
				try {
					// get URL as text/plain
					Object data = transferable.getTransferData(DataFlavor.stringFlavor);
					if (data instanceof String) {
						URIList result = new URIList();
						result.add(new URI(data.toString()));

						return result;
					}
				}
				catch (IOException | UnsupportedFlavorException | URISyntaxException exception) {
					MLogger.exception(exception);
				}
				
				return null;
			}
		}
		
		return null;
	}
	
	/**
	 * @since 3.0
	 */
	public static boolean isURIList(final DataFlavor flavor) {
		return flavor.equals(URI_LIST) || flavor.getMimeType().startsWith(MOZ_URL);
	}
	
	/**
	 * @since 2.2
	 */
	public synchronized static String toURIList(final FileList fileList, final DataFlavor flavor) {
		if (flavor.equals(DataFlavor.stringFlavor)) {
			StringBuilder result = new StringBuilder(512);
			for (File i : fileList) {
				result.append(i.toPath().toUri());
				if (fileList.size() > 1)
					result.append(LINE_SEPARATOR);
			}
			
			return result.toString();
		}
		else if (flavor.equals(URI_LIST)) {
			StringBuilder result = new StringBuilder(512);
			for (File i : fileList)
				result.append(i.toPath().toUri()).append(LINE_SEPARATOR);
			
			return result.toString();
		}
		else {
			return null;
		}
	}
	
	// public classes
	
	public static final class FileList extends MArrayList<File> {
		
		// public
		
		public FileList() { }
		
		public FileList(final Collection<File> c) {
			super(c);
		}

		public FileList(final int size) {
			super(size);
		}

	}
	
	public static final class URIList extends MArrayList<URI> {
		
		// public
		
		public URIList() { }
		
		public URIList(final int size) {
			super(size);
		}
		
	}
	
}
