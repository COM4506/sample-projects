// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import java.awt.Color;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;

/**
 * A type-safe data output stream.
 *
 * @see MDataInputStream
 *
 * @since 3.8.12
 */
public class MDataOutputStream extends DataOutputStream {

	// public

	/**
	 * Constructs a new output stream.
	 *
	 * @param out the underlying output stream (or {@code null})
	 */
	public MDataOutputStream(final OutputStream out) {
		super(out);
	}

	/**
	 * Writes an array.
	 *
	 * @param values the array to write
	 *
	 * @throws IOException If {@code values} contains unsupported data type
	 * @throws NullPointerException If {@code values} is {@code null}
	 *
	 * @see MDataInputStream#readArray()
	 */
	public void writeArray(final Object... values) throws IOException {
		Objects.requireNonNull(values);

		DataType.ARRAY.writeID(this);

		writeInt(values.length);
		for (Object i : values) {
			writeProperty(i);
		}
	}

	public void writeCollection(final Collection<?> collection) throws IOException {
		Objects.requireNonNull(collection);

		DataType.COLLECTION.writeID(this);

		writeInt(collection.size());
		for (Object i : collection) {
			writeProperty(i);
		}
	}

	public void writeHeader(final DataHeader header) throws IOException {
		writePropertyMap(header);
	}

	public void writeProperty(final Object value) throws IOException {
		if (value == null) {
			DataType.NULL.writeID(this);
		}
		else if (value instanceof Boolean) {
			DataType.BOOLEAN.writeID(this);
			writeBoolean((Boolean)value);
		}
		else if (value instanceof Byte) {
			DataType.BYTE.writeID(this);
			writeByte((Byte)value);
		}
		else if (value instanceof Character) {
			DataType.CHARACTER.writeID(this);
			writeChar((Character)value);
		}
		else if (value instanceof Double) {
			DataType.DOUBLE.writeID(this);
			writeDouble((Double)value);
		}
		else if (value instanceof Float) {
			DataType.FLOAT.writeID(this);
			writeFloat((Float)value);
		}
		else if (value instanceof Integer) {
			DataType.INTEGER.writeID(this);
			writeInt((Integer)value);
		}
		else if (value instanceof Long) {
			DataType.LONG.writeID(this);
			writeLong((Long)value);
		}
		else if (value instanceof Short) {
			DataType.SHORT.writeID(this);
			writeShort((Short)value);
		}
		else if (value instanceof String) {
			DataType.STRING.writeID(this);
			writeUTF((String)value);
		}
		else if (value instanceof byte[]) {
			DataType.BYTE_ARRAY.writeID(this);
			byte[] b = (byte[])value;
			writeInt(b.length);
			write(b);
		}
		else if (value instanceof java.util.Date) {
			DataType.DATE.writeID(this);
			writeLong(java.util.Date.class.cast(value).getTime());
		}
		else if (value instanceof Color) {
			DataType.COLOR.writeID(this);
			Color c = (Color)value;
			writeByte(c.getRed());
			writeByte(c.getGreen());
			writeByte(c.getBlue());
			writeByte(c.getAlpha());
		}
		else {
			throw new IOException("Unsupported property type: " + value + " (" + value.getClass().getName() + ")");
		}
	}

	/**
	 * Writes a named property.
	 *
	 * @param name the property name
	 * @param value the property value
	 *
	 * @throws IOException If data type of {@code value} is unsupported
	 * @throws NullPointerException If {@code name} is {@code null}
	 *
	 * @see #writeProperty(Object)
	 * @see MDataInputStream#readProperty()
	 * @see MDataInputStream#readProperty(String)
	 */
	public void writeProperty(final String name, final Object value) throws IOException {
		writeUTF(Objects.requireNonNull(name));
		writeProperty(value);
	}

	public void writePropertyMap(final Map<String, ?> map) throws IOException {
		Objects.requireNonNull(map);

		DataType.MAP.writeID(this);

		writeInt(map.size());
		for (Map.Entry<String, ?> i : map.entrySet()) {
			writeProperty(i.getKey(), i.getValue());
		}
	}

}