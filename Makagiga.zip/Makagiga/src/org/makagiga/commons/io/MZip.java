// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.io;

import static org.makagiga.commons.UI.i18n;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.makagiga.commons.Flags;
import org.makagiga.commons.FS;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.annotation.Obsolete;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.io package)
 */
public class MZip
implements
	Closeable,
	Iterable<ZipEntry>
{

	// public

	public static final int UNPACK_VALIDATE_ENTRY = 1;
	
	// private
	
	private ZipInputStream zipInput;
	private ZipOutputStream zipOutput;
	
	// public
	
	@Obsolete
	public ZipEntry addEntry(final String name, final File file) throws IOException {
		try (FS.BufferedFileInput input = new FS.BufferedFileInput(file)) {
			return addEntry(name, input);
		}
	}
	
	public ZipEntry addEntry(final String name, final InputStream input) throws IOException {
		ZipEntry result = beginEntry(name);
		copyToEntry(input);

		return result;
	}

	/**
	 * @since 5.6
	 */
	public ZipEntry addEntry(final String name, final Path file) throws IOException {
		try (FS.BufferedFileInput input = new FS.BufferedFileInput(file)) {
			ZipEntry result = beginEntry(name);

			// copy date/time info
			BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);
			result.setCreationTime(attr.creationTime());
			result.setLastAccessTime(attr.lastAccessTime());
			result.setLastModifiedTime(attr.lastModifiedTime());

			copyToEntry(input);

			return result;
		}
	}

	public ZipEntry beginEntry(final String name) throws IOException {
		ZipEntry result = new ZipEntry(name);
		zipOutput.putNextEntry(result);
		
		return result;
	}

	@Override
	public void close() throws IOException {
		if (zipInput != null)
			zipInput.close();
		if (zipOutput != null)
			zipOutput.close();
	}

	public void copyEntryTo(final File file) throws IOException {
		try (FS.BufferedFileOutput output = new FS.BufferedFileOutput(file)) {
			copyEntryTo(output);
		}
	}

	public void copyEntryTo(final OutputStream output) throws IOException {
		FS.copyStream(zipInput, output);
	}

	public void copyToEntry(final InputStream input) throws IOException {
		try {
			FS.copyStream(input, zipOutput);
		}
		finally {
			zipOutput.closeEntry();
		}
	}
	
	public ZipInputStream getInputStream() { return zipInput; }
	
	public ZipOutputStream getOutputStream() { return zipOutput; }
	
	@Override
	public Iterator<ZipEntry> iterator() {
		return new Iterator<ZipEntry>() {
			private ZipEntry nextZipEntry;
			@Override
			public boolean hasNext() {
				try {
					nextZipEntry = zipInput.getNextEntry();
				
					return nextZipEntry != null;
				}
				catch (IOException exception) {
					MLogger.exception(exception);
					
					return false;
				}
			}
			@Override
			public ZipEntry next() {
				if (nextZipEntry == null)
					throw new NoSuchElementException();
			
				return nextZipEntry;
			}
		};
	}
	
	public static MZip read(final File file) throws FileNotFoundException {
		return new MZip(new FS.BufferedFileInput(file));
	}

	public static MZip read(final InputStream input) {
		return new MZip(input);
	}

	/**
	 * @since 4.0
	 */
	public void unpackTo(final File dir, final int flags) throws IOException {
		Flags f = Flags.valueOf(flags);
		for (ZipEntry i : this) {
			String entryName = i.getName();
			entryName = entryName.replace('/', File.separatorChar);
			
			if (
				f.isSet(UNPACK_VALIDATE_ENTRY) &&
				(
					entryName.startsWith(File.separator) ||
					entryName.contains(".." + File.separator)
				)
			)
				throw new IOException("Zip entry name contains unsafe characters");
			
			File outputPath = new File(dir, entryName);
			// directory
			if (i.isDirectory()) {
				mkdirs(outputPath);
			}
			// file
			else {
				File parent = outputPath.getParentFile();
				if (parent != null)
					mkdirs(parent);

				copyEntryTo(outputPath);
			}
		}
	}

	@Obsolete
	public static MZip write(final File file) throws FileNotFoundException {
		return new MZip(new FS.BufferedFileOutput(file));
	}

	public static MZip write(final OutputStream output) {
		return new MZip(output);
	}

	/**
	 * @since 5.4
	 */
	public static MZip write(final Path file) throws IOException {
		return new MZip(new FS.BufferedFileOutput(file));
	}
	
	// protected
	
	protected MZip(final InputStream input) {
		zipInput = new ZipInputStream(input);
	}

	protected MZip(final OutputStream output) {
		zipOutput = new ZipOutputStream(output);
	}

	// private

	private void mkdirs(final File dir) throws IOException {
		if (!dir.exists() && !dir.mkdirs())
			throw new IOException(i18n("Could not create \"{0}\" directory", dir));
	}

}
