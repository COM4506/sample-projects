// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * @since 3.8.5
 */
public class CommandOptions implements Serializable {

	// public

	public enum ErrorMode { IGNORE, WARNING, FATAL }

	// private

	private ErrorMode errorMode = ErrorMode.IGNORE;
	private final MArrayList<Option> registeredOptions = new MArrayList<>();
	private final List<Option> readOnlyRegisteredOptions = Collections.unmodifiableList(registeredOptions);
	private String[] options = TK.EMPTY_STRING_ARRAY;
	
	// public

	/**
	 * Constructs an empty command options manager.
	 * with {@code ErrorMode.IGNORE}.
	 *
	 * @see #registerOption(String, String, String)
	 * @see #set(String[])
	 */
	public CommandOptions() { }

	public boolean containsRaw(final String name) {
		return indexOfRaw(name) != -1;
	}

	public ErrorMode getErrorMode() { return errorMode; }

	public void setErrorMode(final ErrorMode value) {
		errorMode = Objects.requireNonNull(value);
	}

	public String getOption(final String name) {
		TK.checkNullOrEmpty(name);

		checkError(name);

		synchronized (this) {
			for (int i = 0; i < options.length; i++) {
				if (matches(options[i], name)) {
					if (i < options.length - 1)
						return options[i + 1];

					return null;
				}
			}
		}

		return null;
	}

	public synchronized String getRaw(final int index) {
		return options[index];
	}

	public synchronized List<Option> getRegisteredOptions() { return readOnlyRegisteredOptions; }

	public synchronized int indexOfRaw(final String name) {
		for (int i = 0; i < options.length; i++) {
			if (options[i].equals(name))
				return i;
		}

		return -1;
	}

	/**
	 * Returns {@code true} if no option set.
	 *
	 * @see #set(String[])
	 * @see #size()
	 */
	public synchronized boolean isEmpty() {
		return options.length == 0;
	}

	/**
	 * @since 4.4
	 */
	public boolean isSet(final Option option) {
		Objects.requireNonNull(option);

		if (isEmpty())
			return false;

		synchronized (this) {
			for (String i : options) {
				if (option.matches(i))
					return true;
			}
		}

		return false;
	}

	/**
	 * Returns {@code true} if {@code name} is set.
	 *
	 * @param name the <i>short</i> or <i>long</i> option name to test
	 *
	 * @see #getOption(String)
	 * @see #set(String[])
	 *
	 * @throws IllegalArgumentException If {@code name} is {@code null} or empty
	 */
	public boolean isSet(final String name) {
		TK.checkNullOrEmpty(name);

		checkError(name);

		if (isEmpty())
			return false;

		synchronized (this) {
			for (String i : options) {
				if (matches(i, name))
					return true;
			}
		}

		return false;
	}

	public Option registerOption(final String shortName, final String longName, final String description) {
		Option o = new Option(shortName, longName, description);
		synchronized (this) {
			registeredOptions.add(o);
		}

		return o;
	}

	public synchronized void set(final String... options) {
		this.options = TK.copyOf(options);
	}

	/**
	 * Returns the number of options set.
	 *
	 * @see #isEmpty()
	 * @see #set(String[])
	 */
	public synchronized int size() { return options.length; }

	@Override
	public synchronized String toString() {
		StringBuilder s = new StringBuilder();

		int max = 0;
		for (Option i : registeredOptions) {
			int len = 0;
			if (i.shortName != null)
				len += i.shortName.length() + 1 /* "-" */;
			if (i.longName != null) {
				if (len > 0)
					len += 2; /* ", " */
				len += i.longName.length() + 2 /* "--" */;
			}
			max = Math.max(len, max);
		}

		@SuppressWarnings("unchecked")
		List<Option> sortedRegisteredOptions = (List<Option>)registeredOptions.clone();
		sortedRegisteredOptions.sort(null);
		for (Option i : sortedRegisteredOptions) {
			s.append(i.toString(max)).append('\n');
		}

		return s.toString();
	}

	// private

	private boolean checkError(final String name) {
		if (errorMode == ErrorMode.IGNORE)
			return true;

		boolean valid = false;
		synchronized (this) {
			for (Option i : registeredOptions) {
				if (name.equals(i.shortName) || name.equals(i.longName)) {
					valid = true;

					break; // for
				}
			}
		}

		if (!valid) {
			if (errorMode == ErrorMode.FATAL)
				throw new IllegalArgumentException("Unregistered/unknown option name: " + name);

			if (errorMode == ErrorMode.WARNING)
				MLogger.warning("core", "Unregistered/unknown option name: " + name);
		}

		return valid;
	}

	private boolean matches(final String arg1, final String arg2) {
		return arg1.equals('-' + arg2) || arg1.equals("--" + arg2);
	}

	// public classes

	public static final class Option
	implements
		Comparable<Option>,
		Serializable
	{

		// private

		private final String description;
		private final String longName;
		private final String shortName;

		// public

		public String getDescription() { return description; }

		public String getLongName() { return longName; }

		public String getShortName() { return shortName; }
		
		/**
		 * @since 4.4
		 */
		public boolean matches(final String name) {
			if (name == null)
				return false;
		
			return
				name.equals('-' + shortName) ||
				name.equals("--" + longName) ||
				name.equals('-' + longName) ||
				name.equals("--" + shortName);
		}

		@Override
		public String toString() {
			return toString(-1);
		}

		// Comparable

		@Override
		public int compareTo(final Option other) {
			String name1 = (this.shortName == null) ? this.longName : this.shortName;
			String name2 = (other.shortName == null) ? other.longName : other.shortName;

			return name1.compareTo(name2);
		}

		// private

		private Option(final String shortName, final String longName, final String description) {
			this.shortName = shortName;
			this.longName = longName;
			this.description = description;
		}

		private String toString(final int maxNamesLen) {
			StringBuilder s = new StringBuilder();

			if (shortName != null)
				s.append('-').append(shortName);

			if (longName != null) {
				if (s.length() > 0)
					s.append(", ");
				s.append("--").append(longName);
			}

			if (maxNamesLen == -1)
				s.append("  ");
			else
				TK.append(s, ' ', (maxNamesLen - s.length()) + 2);

			s.append(description);

			return s.toString();
		}

	}

}
