// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

/**
 * A date property.
 *
 * @mg.note
 * Since version 4.0 this class uses {@link java.util.Date} instead of {@link MDate}.
 *
 * @since 2.0
 */
public class DateProperty extends Property<java.util.Date> {

	// public

	/**
	 * Constructs a date property with the date/time at which it was allocated.
	 */
	public DateProperty() {
		super(new java.util.Date());
	}
	
	@Override
	public Object clone() {
		DateProperty copy = (DateProperty)super.clone();
		if (getDefaultValue() != null)
			copy.setDefaultValue((java.util.Date)getDefaultValue().clone());
		java.util.Date date = get();
		if (date != null)
			copy.set((java.util.Date)date.clone());
		
		return copy;
	}

	/**
	 * @since 2.4
	 */
	@Override
	public Class<java.util.Date> getType() { return java.util.Date.class; }
	
	@Override
	public boolean isDateType() { return true; }

	@Override
	public void read(final Config config, final String key) {
		set(config.readDate(key, getDefaultValue()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, get());
	}

	/**
	 * [Based on the java.util.Date API documentation]
	 * Sets this property to represent a point in time that is @p value milliseconds after
	 * January 1, 1970 00:00:00 GMT.
	 *
	 * @param value The number of milliseconds
	 */
	public void setTime(final long value) {
		get().setTime(value);
	}

}
