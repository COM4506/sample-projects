// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.text.ParseException;

/**
 * A @c float property.
 * 
 * @mg.example
 * <pre class="brush: java">
 * public static final FloatProperty myProperty = new FloatProperty(3.14f);
 * </pre>
 * 
 * @mg.note This class is <b>not</b> thread-safe.
 * 
 * @since 2.4
 */
public class FloatProperty extends NumberProperty<Float> {
	
	// public
	
	/**
	 * Constructs a @c float property.
	 * The default value is @c 0.0f.
	 */
	public FloatProperty() {
		super(0.0f);
	}

	/**
	 * Constructs a @c float property with @p value.
	 * The default value is @p value.
	 */
	public FloatProperty(final float value) {
		super(value);
	}

	/**
	 * @since 4.0
	 */
	public FloatProperty(final float value, final int options) {
		super(value, options);
	}

	/**
	 * Constructs a @c float property with @p value.
	 * The default value is @p value.
	 *
	 * @see #parse(String)
	 *
	 * @throws ParseException If @p value is invalid
	 */
	public FloatProperty(final String value) throws ParseException {
		parse(value);
		setDefaultValue(get());
	}
	
	/**
	 * @return {@code Float.class}
	 */
	@Override
	public Class<Float> getType() { return Float.class; }
	
	@Override
	public boolean isFloatType() { return true; }

	/**
	 * Converts a @c String @p value to @c float.
	 * 
	 * @throws ParseException If @p value is invalid
	 */
	@Override
	public void parse(final String value) throws ParseException {
		try {
			set(Float.valueOf(value));
		}
		catch (NullPointerException exception) {
			parseError(exception);
		}
		catch (NumberFormatException exception) {
			parseError(exception);
		}
	}

	@Override
	public void read(final Config config, final String key) {
		set(config.readFloat(key, getDefaultValue()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, get().floatValue());
	}

}
