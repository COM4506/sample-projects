// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Objects;
import javax.swing.Action;

import org.makagiga.commons.annotation.InvokedFromConstructor;

/**
 * @mg.threadSafe
 *
 * @since 3.8.5
 */
public class HistoryManager<T>
implements
	Iterable<T>,
	Serializable
{

	// public

	public static final int NO_LIMIT = -1;

	// private

	private boolean modified;
	private int current;
	private int limit = 1000;
	private final LinkedList<T> list = new LinkedList<>();
	private final List<T> readOnlyList = Collections.unmodifiableList(list);
	
	// public
	
	/**
	 * Constructs an empty, unmodified history manager.
	 */
	public HistoryManager() {
		clear();
	}
	
	public synchronized boolean add(final T element) {
		Objects.requireNonNull(element);

		// do not add duplicates
		if (!isEmpty() && Objects.equals(list.get(current), element))
			return false;

		if (current == list.size() - 1) {
			list.add(element);
			current = list.size() - 1;
		}
		else if (isEmpty()) {
			list.add(element);
			current = 0;
		}
		else {
			list.add(++current, element);
		}
		modified = true;
		
		if ((limit != NO_LIMIT) && (list.size() > limit)) {
			list.removeFirst();
			if (current > list.size() - 1)
				current = list.size() - 1;
		}

		return true;
	}

	/**
	 * @throws NoSuchElementException If the previous element is not available
	 */
	public T back() {
		if (!canBack())
			throw new NoSuchElementException();
			
		synchronized (this) {
			current--;
	
			return list.get(current);
		}
	}

	public synchronized boolean canBack() {
		return !isEmpty() && (current > 0);
	}

	public synchronized boolean canForward() {
		return !isEmpty() && (current < list.size() - 1);
	}

	@InvokedFromConstructor
	public boolean clear() {
		if (isEmpty())
			return false;

		synchronized (this) {
			list.clear();
			current = 0;
			modified = false;
		}

		return true;
	}

	/**
	 * @throws NoSuchElementException If the next element is not available
	 */
	public T forward() {
		if (!canForward())
			throw new NoSuchElementException();
		
		synchronized (this) {
			current++;
	
			return list.get(current);
		}
	}

	/**
	 * @throws NoSuchElementException If history is empty
	 */
	public synchronized T getCurrent() {
		if (isEmpty())
			throw new NoSuchElementException();

		return list.get(current);
	}
	
	public synchronized int getLimit() { return limit; }

	/**
	 * @see #NO_LIMIT
	 */
	public void setLimit(final int value) {
		if ((value != NO_LIMIT) && (value < 1))
			throw new IllegalArgumentException("History limit cannot be less than 1 (NO_LIMIT - unlimited): " + value);

		synchronized (this) {
			limit = value;

			// trim to limit
			if (limit > 0) {
				while (list.size() > limit) {
					list.removeLast();
				}

				if (current > list.size() - 1)
					current = list.size() - 1;
			}
		}
	}

	public synchronized boolean isEmpty() {
		return list.isEmpty();
	}

	public synchronized boolean isModified() { return modified; }

	@SuppressWarnings("unchecked")
	public synchronized void read(final BufferedReader r) throws IOException {
		String line;
		while ((line = r.readLine()) != null) {
			list.add((T)line);
		}
		current = Math.max(0, list.size() - 1);
	}

	/**
	 * @since 3.8.6
	 */
	public synchronized int size() {
		return list.size();
	}
	
	public synchronized List<T> toList() { return readOnlyList; }

	/**
	 * @since 3.8.8
	 */
	public void updateActions(final Action backAction, final Action forwardAction) {
		backAction.setEnabled(canBack());
		forwardAction.setEnabled(canForward());
	}

	// Iterable

	@Override
	public Iterator<T> iterator() {
		return toList().iterator();
	}

	// public classes

	/**
	 * @since 3.8.8
	 */
	public static abstract class BackAction<T> extends HistoryAction<T> {

		// public

		public BackAction(final HistoryManager<T> historyManager) {
			super(MActionInfo.BACK, historyManager);
			setEnabled(historyManager.canBack());
		}

		@Override
		public final void onAction() {
			HistoryManager<T> historyManager = get();
			if (historyManager.canBack()) {
				try {
					onAction(historyManager.back());
				}
				finally {
					setEnabled(historyManager.canBack());
				}
			}
		}

	}

	/**
	 * @since 3.8.8
	 */
	public static abstract class ForwardAction<T> extends HistoryAction<T> {

		// public

		public ForwardAction(final HistoryManager<T> historyManager) {
			super(MActionInfo.FORWARD, historyManager);
			setEnabled(historyManager.canForward());
		}

		@Override
		public final void onAction() {
			HistoryManager<T> historyManager = get();
			if (historyManager.canForward()) {
				try {
					onAction(historyManager.forward());
				}
				finally {
					setEnabled(historyManager.canForward());
				}
			}
		}

	}

	/**
	 * @since 3.8.8
	 */
	public static abstract class HistoryAction<T> extends MDataAction.Weak<HistoryManager<T>> {

		// protected

		protected HistoryAction(final MActionInfo info, final HistoryManager<T> historyManager) {
			super(historyManager, info);
		}

		protected abstract void onAction(final T element);

	}

}
