// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Image;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import javax.swing.JComponent;
import javax.swing.TransferHandler;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.swing.MDownloadDialog;

/**
 * @since 3.8
 */
public final class MDataTransfer {

	// public

	/**
	 * @since 3.8.7
	 */
	public static final DataFlavor URL_DATA_FLAVOR = new DataFlavor(URL.class, "URL");

	public static final String IMAGE_PNG_MIME_TYPE = "image/png";

	// private

	private static final String UTF_8_CHARSET = "UTF-8";
	
	// public

	public static void debug(final DataFlavor[] flavors) {
		for (DataFlavor i : flavors)
			MLogger.debug("data", "[%s] %s, %s", i.getHumanPresentableName(), i.getMimeType(), i.getRepresentationClass());
	}

	/**
	 * Returns a text/html flavor or {@code null}.
	 *
	 * @since 3.8.7
	 */
	public static DataFlavor findBestHTMLFlavor(final DataFlavor[] flavors, final boolean isDrop) {
		boolean isMozilla = false;
		DataFlavor noCharset = null;
		DataFlavor unicodeCharset = null;
		DataFlavor unicodeString = null;
		DataFlavor utf8Charset = null;
		DataFlavor utf8CharsetByteArray = null;
		for (DataFlavor i : flavors) {
			String mime = getSimpleMimeType(i);
			String subType = i.getSubType();
			if ("text/html".equals(mime)) {
				String charset = i.getParameter("charset");

				if (byte[].class.equals(i.getRepresentationClass())) {
					if ((utf8CharsetByteArray == null) && UTF_8_CHARSET.equalsIgnoreCase(charset))
						utf8CharsetByteArray = i;
				}
				else if (InputStream.class.equals(i.getRepresentationClass())) {
					if ((unicodeCharset == null) && "unicode".equalsIgnoreCase(charset))
						unicodeCharset = i;
					else if ((utf8Charset == null) && UTF_8_CHARSET.equalsIgnoreCase(charset))
						utf8Charset = i;
					else if ((noCharset == null) && TK.isEmpty(charset))
						noCharset = i;
				}
				else if (Reader.class.equals(i.getRepresentationClass())) {
					if ((utf8Charset == null) && UTF_8_CHARSET.equalsIgnoreCase(charset))
						utf8Charset = i;
				}
				else if (String.class.equals(i.getRepresentationClass())) {
					unicodeString = i;
				}
			}
			else if (
				(subType != null) && !isMozilla &&
				(subType.contains("_moz_") || subType.contains("-moz-"))
			) {
				isMozilla = true;
			}
		}

		// HACK: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6740877
		if (isMozilla && isDrop && OS.isLinux())
			return null;

		if (unicodeString != null)
			return unicodeString;

		if (utf8CharsetByteArray != null)
			return utf8CharsetByteArray;

		if (utf8Charset != null)
			return utf8Charset;

		if (unicodeCharset != null)
			return unicodeCharset;

		if (noCharset != null)
			return noCharset;

		return null;
	}

	public static DataFlavor findBestImageFlavor(final DataFlavor[] flavors, final String preferredMimeType) {
		DataFlavor imageFlavor = null;
		DataFlavor preferredFlavor = null;
		for (DataFlavor i : flavors) {
			if (i.equals(DataFlavor.imageFlavor))
				imageFlavor = i;
			else if ((preferredMimeType != null) && getSimpleMimeType(i).equals(preferredMimeType))
				preferredFlavor = i;
		}

		if (preferredFlavor != null)
			return preferredFlavor;

		return imageFlavor;
	}

	/**
	 * @since 3.8.7
	 */
	public static DataFlavor[] getAvailableDataFlavors(final Object source) {
		if (source instanceof Clipboard) {
			try {
				return Clipboard.class.cast(source).getAvailableDataFlavors();
			}
			// HACK: workaround for "Failed to retrieve atom name" NPE exception
			catch (NullPointerException exception) {
				MLogger.exception(exception);

				return new DataFlavor[0];
			}
		}

		if (source instanceof Transferable)
			return Transferable.class.cast(source).getTransferDataFlavors();

		throw new IllegalArgumentException("Unsupported data source: " + source);
	}

	/**
	 * @since 3.8.7
	 */
	public static Object getData(final Object source, final DataFlavor flavor) throws IOException, UnsupportedFlavorException {
		if (source instanceof Clipboard) {
			try {
				return MClipboard.getContents((Clipboard)source, flavor);
			}
			catch (ClipboardException exception) {
				throw new IOException(exception);
			}
		}

		if (source instanceof Transferable)
			return Transferable.class.cast(source).getTransferData(flavor);

		throw new IllegalArgumentException("Unsupported data source: " + source);
	}

	@SuppressWarnings("unchecked")
	public static <T> T getData(final Transferable transferable, final DataFlavor flavor, final Class<T> type) throws IOException, UnsupportedFlavorException {
		Object data = transferable.getTransferData(flavor);

		if (type.isInstance(data))
			return (T)data;

		return null;
	}

	/**
	 * @since 3.8.7
	 */
	public static String getHTML(final Object source, final DataFlavor flavor) throws IOException, UnsupportedFlavorException {
		Object data = getData(source, flavor);

		byte[] buf;
		if (data instanceof InputStream) {
			InputStream input = (InputStream)data;
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			FS.copyStream(input, output);
			FS.close(input);
			FS.close(output);
			buf = output.toByteArray();
		}
		else if (data instanceof Reader) {
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			try (
				Reader reader = (Reader)data;
				Writer writer = FS.newBufferedWriter(output)
			) {
				FS.copyChars(reader, writer);
			}
			buf = output.toByteArray();
		}
		else if (data instanceof String) {
			buf = data.toString().getBytes("UTF8");
		}
		else if (data instanceof byte[]) {
			buf = (byte[])data;
		}
		else {
			throw new IOException("No input stream for " + flavor);
		}

		String html = fixGarbage(buf, UTF_8_CHARSET);

		//MLogger.debug("data", "HTML before: \"%s\"", html);
		try {
			html = TK.substring(html, "<!--StartFragment-->", "<!--EndFragment-->", false);
		}
		catch (ParseException exception) {
			MLogger.debug("data", "<!--StartFragment--> or <!--EndFragment--> not found");
		}
		//MLogger.debug("data", "HTML after: \"%s\"", html);

		return html;
	}

	/**
	 * @since 3.8.7
	 */
	public static Image getImage(final Object source) throws IOException, UnsupportedFlavorException {
		DataFlavor[] flavors = getAvailableDataFlavors(source);
		DataFlavor bestFlavor = findBestImageFlavor(flavors, IMAGE_PNG_MIME_TYPE);

		if (bestFlavor == null)
			bestFlavor = DataFlavor.imageFlavor;

		return getImage(source, bestFlavor);
	}

	/**
	 * @since 3.8.7
	 */
	public static Image getImage(final Object source, final DataFlavor flavor) throws IOException, UnsupportedFlavorException {
		return toImage(getData(source, flavor));
	}

	/**
	 * @since 4.2
	 */
	public static Path getImage(final URI uri) throws IOException {
		return getImage(uri, (Path)null);
	}

	/**
	 * @since 4.2
	 */
	public static Path getImage(final URI uri, final Path destination) throws IOException {
		String suffix = "." + FS.getFileExtension(uri.getPath());
					
		if (!isImageSupported(suffix))
			throw new IOException(uri.toString());

		File dest = null;
		try {
			dest = (destination == null) ? File.createTempFile("image", suffix) : destination.toFile();
			Net.DownloadInfo downloadInfo = new Net.DownloadInfo(
				uri.toURL(),
				null,
				Net.DOWNLOAD_USE_CACHE
			);
			downloadInfo.setDestinationFile(dest);
			MDownloadDialog.download(UI.windowFor(null), downloadInfo);

			return (destination != null) ? destination : dest.toPath();
		}
		catch (MalformedURLException exception) {
			throw new IOException(exception);
		}
	}
	
	/**
	 * @since 4.2
	 */
	public static Map<String, Object> getImageInfo(final String suffix, final InputStream input) throws IOException {
		if (TK.isEmpty(suffix))
			throw new IOException("Unknown image type (provide a valid \"suffix\" parameter)");
	
		Map<String, Object> map = new HashMap<>();
		resetImageInfo(map);

		Iterator<ImageReader> it = ImageIO.getImageReadersBySuffix(suffix);
		
		if (!it.hasNext()) {
			MLogger.debug("data", "No image reader for suffix: %s", suffix);
		
			return map;
		}
		
		ImageReader reader = it.next();
		try (ImageInputStream imageInput = ImageIO.createImageInputStream(input)) {
			reader.setInput(imageInput);
			readImageInfo(reader, map);
		}
		finally {
			reader.dispose();
		}
		
		return map;
	}

	public static String getSimpleMimeType(final DataFlavor flavor) {
		return flavor.getPrimaryType() + "/" + flavor.getSubType();
	}

	/**
	 * @since 3.8.7
	 */
	public static String getString(final Object source) throws IOException, UnsupportedFlavorException {
		return toString(getData(source, DataFlavor.stringFlavor));
	}

	public static String getString(final Transferable transferable) throws IOException, UnsupportedFlavorException {
		String data = getData(transferable, DataFlavor.stringFlavor, String.class);

		return toString(data);
	}

	public static Transferable getTransferable(final TransferHandler.TransferSupport support) {
		if (support.isDrop())
			return support.getTransferable();

		return MClipboard.getDefault().getContents(null);
	}

	public static boolean importFromClipboard(final JComponent c) {
		TransferHandler handler = c.getTransferHandler();

		if (handler == null)
			return false;

		TransferHandler.TransferSupport support = new TransferHandler.TransferSupport(
			c,
			MClipboard.getDefault().getContents(null)
		);
		
		if (handler.canImport(support))
			return handler.importData(support);

		return false;
	}

	/**
	 * @since 4.2
	 */
	public static boolean isImageSupported(String path) {
		if (!path.isEmpty()) {
			path = TK.toUpperCase(path);
			String[] suffixes = ImageIO.getReaderFileSuffixes();
			for (String i : suffixes) {
				if (path.endsWith("." + TK.toUpperCase(i)))
					return true;
			}
		}

		return false;
	}

	/**
	 * @since 3.8.7
	 */
	@Obsolete
	public static boolean isImage(final URL url) {
		return isImageSupported(url.getPath());
	}

	/**
	 * @since 4.2
	 */
	public static void readImageInfo(final ImageReader reader, final Map<String, Object> map) throws IOException {
		resetImageInfo(map);
	
		int index = reader.getMinIndex();
		map.put("width", reader.getWidth(index));
		map.put("height", reader.getHeight(index));

		try {
			IIOMetadata metadata = reader.getImageMetadata(index);
			Node root = metadata.getAsTree("javax_imageio_1.0");

			if (root == null)
				return;
				
			for (Node text : TK.iterable(root)) {
				if ("Text".equals(text.getLocalName())) {
					for (Node textEntry : TK.iterable(text)) {
						if ("TextEntry".equals(textEntry.getLocalName()) && textEntry.hasAttributes()) {
							NamedNodeMap attr = textEntry.getAttributes();
							Node keywordAttr = attr.getNamedItem("keyword");
							if ((keywordAttr != null) && "comment".equals(keywordAttr.getNodeValue())) {
								Node valueAttr = attr.getNamedItem("value");
								if (valueAttr != null) {
									map.put("comment", Objects.toString(valueAttr.getNodeValue(), ""));
									
									break; // for
								}
							}
						}
					}
					
					break; // for
				}
			}
		}
		catch (Exception exception) {
			// HACK: some images caused "JFIF APP0 must be first marker after SOI" error
			MLogger.exception(exception);
		}
	}

	public static Image toImage(final Object data) throws IOException {
		if (data instanceof Image)
			return (Image)data;

		if (data instanceof InputStream)
			return ImageIO.read((InputStream)data);

		return null;
	}

	public static String toString(final Object data) {
		if (data instanceof String)
			return (String)data;

		return null;
	}

	// private

	@Uninstantiable
	private MDataTransfer() {
		TK.uninstantiable();
	}

	/**
	 * HACK: The DataFlavor (text/html, UTF-8, InputStream) reported by Firefox/Linux (3.6.x) on
	 * Java 6 is actually UTF-16LE
	 * with "REPLACEMENT CHARACTER"s (0xEF 0xBF 0xBD 0xEF 0xBF 0xBD).
	 *
	 * This function filters the {@code buf} and returns the correct UTF-8 string (I hope ;)
	 *
	 * @see <a href="http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6740877">Java Bug #6740877</a>
	 * @see <a href="http://www.fileformat.info/info/unicode/char/fffd/index.htm">REPLACEMENT CHARACTER</a>
	 */
	private static String fixGarbage(final byte[] buf, @Obsolete final String charset) throws UnsupportedEncodingException {
		if ((buf == null) || (buf.length == 0))
			return "";

		boolean isUTF16LE = false;
		if (
			"UTF8".equals(charset) /* alias name */ ||
			UTF_8_CHARSET.equals(charset)
		) {
			for (byte i : buf) {
				if (i == 0) {
					// UTF-8 contains 0x00 bytes
					isUTF16LE = true;

					break; // for
				}
			}
		}

		if (
			isUTF16LE && (buf.length >= 6) &&
			(buf[0] == (byte)0xef) && (buf[1] == (byte)0xbf) && (buf[2] == (byte)0xbd) &&
			(buf[3] == (byte)0xef) && (buf[4] == (byte)0xbf) && (buf[5] == (byte)0xbd)
		) {
			// skip "REPLACEMENT CHARACTER"s (0xEF 0xBF 0xBD 0xEF 0xBF 0xBD) at the zero index
			int skip = 6;

			return new String(buf, skip, buf.length - skip, StandardCharsets.UTF_16LE);
		}
		else {
			return new String(buf, charset);
		}
	}
	
	private static void resetImageInfo(final Map<String, Object> map) {
		map.clear();
		// put non-null values
		map.put("comment", "");
		map.put("width", 0);
		map.put("height", 0);
	}

}
