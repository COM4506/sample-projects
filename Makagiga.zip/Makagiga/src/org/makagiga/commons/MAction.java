// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.function.Consumer;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;

import org.makagiga.commons.annotation.DesignPattern;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MStatusBar;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * An application action.
 *
 * @mg.example
 * <pre class="brush: java">
 * // Create File|Quit menu item
 * MMenuBar menuBar = new MMenuBar();
 * MMenu fileMenu = new MMenu("File");
 * fileMenu.add(new NewFileAction());
 * menuBar.add(fileMenu);
 * ...
 * private static final class NewFileAction extends MAction {
 *   NewFileAction() {
 *     super(
 *       i18n("New"), // action name visible in user interface
 *       "ui/newfile", // icon name
 *       VK_N, getMenuMask() // Ctrl+N shortcut
 *     );
 *     setHTMLHelp(i18n("Creates a new file."));
 *   }
 *   {@literal @}Override
 *   public void onAction() {
 *     createNewFile();
 *   }
 * }
 * </pre>
 *
 * @since 2.0
 */
@DesignPattern(DesignPattern.COMMAND)
public class MAction extends AbstractAction implements MIcon.Name {
	
	// public

	/**
	 * @mg.default
	 * {@code null}
	 *
	 * @since 3.2
	 */
	public static final String ALTERNATE_ACCELERATOR_KEY = "org.makagiga.commons.MAction.ALTERNATE_ACCELERATOR_KEY";

	/**
	 * @mg.default
	 * {@code null}
	 *
	 * @since 3.8
	 */
	public static final String MOUSE_GESTURE_KEY = "org.makagiga.commons.MAction.MOUSE_GESTURE_KEY";

	/**
	 * @mg.default
	 * {@code null}
	 *
	 * @since 3.8.3
	 */
	public static final String VISIBLE_KEY = "org.makagiga.commons.MAction.VISIBLE_KEY";

	/**
	 * @since 3.0
	 */
	public static final Object NO_SOURCE = new Object();
	
	// private
	
	private transient ActionEvent actionEvent;
	private boolean htmlEnabled = true;
	private Consumer<MAction> actionHandler;
	private static final int menuMask;
	private Property<Boolean> authProperty;
	private ScriptEvent _onAction;
	private static final String HIGHLIGHTED_COMPONENT_KEY = "org.makagiga.commons.MAction.HIGHLIGHTED_COMPONENT_KEY";

	// public

	static {
		menuMask = GraphicsEnvironment.isHeadless()
			? KeyEvent.CTRL_MASK // fallback
			: Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
	}

	/**
	 * Constructs a new action.
	 */
	public MAction() {
		this(null, (Icon)null, 0, 0);
	}

	/**
	 * @since 5.0
	 */
	public MAction(final Consumer<? extends MAction> actionHandler) {
		this();
		setActionHandler(actionHandler);
	}

	/**
	 * @since 3.0
	 */
	public MAction(final MActionInfo info) {
		this(info.getText(), info.getIconName(), info.getKeyCode(), info.getModifiers());
	}

	/**
	 * @since 5.0
	 */
	public MAction(final MActionInfo info, final Consumer<? extends MAction> actionHandler) {
		this(info);
		setActionHandler(actionHandler);
	}
	
	/**
	 * @since 4.0
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public MAction(final ScriptEvent event) {
		_onAction = event;
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 */
	public MAction(final String text) {
		this(text, (Icon)null, 0, 0);
	}

	/**
	 * @since 5.0
	 */
	public MAction(final String text, final Consumer<? extends MAction> actionHandler) {
		this(text);
		setActionHandler(actionHandler);
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param icon An icon (@c null = no icon)
	 */
	public MAction(final String text, final Icon icon) {
		this(text, icon, 0, 0);
	}

	/**
	 * @since 5.0
	 */
	public MAction(final String text, final Icon icon, final Consumer<? extends MAction> actionHandler) {
		this(text, icon);
		setActionHandler(actionHandler);
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param iconName An icon name (@c null = no icon)
	 */
	public MAction(final String text, final String iconName) {
		this(text, iconName, 0, 0);
	}

	/**
	 * @since 5.0
	 */
	public MAction(final String text, final String iconName, final Consumer<? extends MAction> actionHandler) {
		this(text, iconName);
		setActionHandler(actionHandler);
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param iconName An icon name (@c null = no icon)
	 * @param keyCode A key code (e.g. @c VK_X)
	 */
	public MAction(final String text, final String iconName, final int keyCode) {
		this(text, iconName, keyCode, 0);
	}

	/**
	 * @since 5.4
	 */
	public MAction(final String text, final String iconName, final int keyCode, final Consumer<? extends MAction> actionHandler) {
		this(text, iconName, keyCode);
		setActionHandler(actionHandler);
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param iconName An icon name (@c null = no icon)
	 * @param keyStroke A key stroke
	 */
	public MAction(final String text, final String iconName, final KeyStroke keyStroke) {
		this(text, iconName, keyStroke.getKeyCode(), keyStroke.getModifiers());
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param keyCode A key code (e.g. @c VK_X)
	 * @param modifiers Modifiers keys (e.g. @c CTRL_MASK)
	 */
	public MAction(final String text, final int keyCode, final int modifiers) {
		this(text, (Icon)null, keyCode, modifiers);
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param keyCode A key code (e.g. @c VK_X)
	 */
	public MAction(final String text, final int keyCode) {
		this(text, (Icon)null, keyCode, 0);
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param icon An icon (@c null = no icon)
	 * @param keyCode A key code (e.g. @c VK_X)
	 * @param modifiers Modifiers keys (e.g. @c CTRL_MASK)
	 */
	public MAction(final String text, final Icon icon, final int keyCode, final int modifiers) {
		setName(text);

		if (keyCode != 0)
			setAcceleratorKey(keyCode, modifiers);

		if (icon != null)
			setSmallIcon(icon);
	}

	/**
	 * Constructs a new action.
	 * @param text A text to display
	 * @param iconName An icon name (@c null = no icon)
	 * @param keyCode A key code (e.g. @c VK_X)
	 * @param modifiers Modifiers keys (e.g. @c CTRL_MASK)
	 */
	public MAction(final String text, final String iconName, final int keyCode, final int modifiers) {
		this(text, (Icon)null, keyCode, modifiers);
		setIconName(iconName);
	}
	
	/**
	 * @since 5.4
	 */
	public MAction(final String text, final String iconName, final int keyCode, final int modifiers, final Consumer<? extends MAction> actionHandler) {
		this(text, iconName, keyCode, modifiers);
		setActionHandler(actionHandler);
	}

	/**
	 * @param e An action event
	 *
	 * @see #getActionEvent()
	 * @see #onAction()
	 */
	@Override
	public final void actionPerformed(final ActionEvent e) {
		if (!isAuthorized()) {
			TK.beep();

			return;
		}

		try {
			actionEvent = e;
			
			if ((_onAction != null) && "true".equals(_onAction.event(this)))
				return;

			if (actionHandler != null)
				actionHandler.accept(this);
			else
				onAction();
		}
		finally {
			actionEvent = null;
		}
	}

	/**
	 * @throws IllegalArgumentException If action name is @c null or empty
	 */
	public void connect(final JComponent component, final int condition) {
		connect(component, condition, this);
	}

	/**
	 * @throws IllegalArgumentException If action name is @c null or empty
	 */
	public void connect(final JComponent component, final int condition, final int keyCode) {
		connect(component, condition, keyCode, this);
	}

	/**
	 * @throws IllegalArgumentException If action name is @c null or empty
	 */
	public void connect(final JComponent component, final int condition, final int keyCode, final int modifiers) {
		connect(component, condition, keyCode, modifiers, this);
	}

	public void connect(final JComponent component, final String actionName) {
		connect(component, actionName, this);
	}

	/**
	 * Connects component with the specified action.
	 * @param component A component to connect with action
	 * @param condition A condition which must be complete to perform the @p action (e.g. @c UI.WHEN_FOCUSED)
	 * @param action An action to connect with component
	 *
	 * @throws IllegalArgumentException If @p action name is @c null or empty
	 * @throws IllegalArgumentException If @p action has no accelerator key
	 */
	public static void connect(final JComponent component, final int condition, final Action action) {
		KeyStroke keyStroke = getValue(action, ACCELERATOR_KEY, null);
			
		if (keyStroke == null)
			throw new IllegalArgumentException("Action has no accelerator key");

		connect(component, condition, keyStroke.getKeyCode(), keyStroke.getModifiers(), action);

		KeyStroke alternateKeyStroke = getValue(action, ALTERNATE_ACCELERATOR_KEY, null);
		if ((alternateKeyStroke != null) && !alternateKeyStroke.equals(keyStroke)) {
			connect(component, condition, alternateKeyStroke.getKeyCode(), alternateKeyStroke.getModifiers(), action);
		}
	}

	/**
	 * Connects component with the specified action.
	 * @param component A component to connect with action
	 * @param condition A condition which must be complete to perform the @p action (e.g. @c UI.WHEN_FOCUSED)
	 * @param keyCode A shortcut associated with component-action
	 * @param action An action to connect with component
	 *
	 * @throws IllegalArgumentException If @p action name is @c null or empty
	 */
	public static void connect(
		final JComponent component,
		final int condition,
		final int keyCode,
		final Action action
	) {
		connect(component, condition, keyCode, 0, action);
	}

	/**
	 * Connects component with the specified action.
	 * @param component A component to connect with action
	 * @param condition A condition which must be complete to perform the @p action (e.g. @c UI.WHEN_FOCUSED)
	 * @param keyCode A shortcut associated with component-action
	 * @param modifiers A shortcut modifiers associated with component-action
	 * @param action An action to connect with component
	 *
	 * @throws IllegalArgumentException If @p action name is @c null or empty
	 */
	public static void connect(
		final JComponent component,
		final int condition,
		final int keyCode,
		final int modifiers,
		final Action action
	) {
		String actionName = getValue(action, Action.NAME, null);
		
		if (TK.isEmpty(actionName))
			throw new IllegalArgumentException("Cannot connect action without name");
		
		component.getActionMap().put(actionName, action);
		component.getInputMap(condition).put(KeyStroke.getKeyStroke(keyCode, modifiers), actionName);
	}

	public static void connect(final JComponent component, final String actionName, final Action action) {
		ActionMap actionMap = component.getActionMap().getParent();
		actionMap.put(actionName, action);
	}

	/**
	 * @since 4.8
	 */
	public MMessage.Builder createMessage() {
		return new MMessage.Builder()
			.icon(getIcon())
			.ok(new MActionInfo(getDialogTitle(), getIconName()))
			.simpleText();
	}

	/**
	 * Disconnects this action from @p component.
	 *
	 * @throws IllegalArgumentException If @p action name is @c null or empty
	 */
	public void disconnect(final JComponent component, final int condition) {
		String actionName = getName();
		
		if (TK.isEmpty(actionName))
			throw new IllegalArgumentException("Cannot disconnect action without name");
		
		component.getActionMap().remove(actionName);
		component.getInputMap(condition).remove(getAcceleratorKey());

		KeyStroke alternateKeyStroke = getAlternateAcceleratorKey();
		if (alternateKeyStroke != null)
			component.getInputMap(condition).remove(alternateKeyStroke);
	}

	public void fire() {
		fire(NO_SOURCE);
	}
	
	/**
	 * @since 3.0
	 */
	public void fire(final Object source) {
		fire(this, source);
	}

	/**
	 * Fires an action.
	 * 
	 * @param action the action to fire
	 * @param source the event source
	 * 
	 * @since 3.0
	 */
	public static void fire(final Action action, final Object source) {
		if (action == null)
			return;

		if (!action.isEnabled())
			return;

		ActionEvent e = new ActionEvent(source, ActionEvent.ACTION_PERFORMED, "");
		action.actionPerformed(e);
	}
	
	public static void fire(
		final MouseWheelEvent e,
		final String upAction,
		final String downAction,
		final JComponent source
	) {
		fire((e.getWheelRotation() < 0) ? upAction : downAction, source);
		e.consume();
	}

	/**
	 * Fires an action.
	 * 
	 * @param actionName the action name to fire
	 * @param source the event source
	 */
	public static void fire(final String actionName, final JComponent source) {
		if ((actionName != null) && (source != null))
			fire(source.getActionMap().get(actionName), source);
	}

	/**
	 * Returns the key stroke associated with this action.
	 */
	public KeyStroke getAcceleratorKey() {
		return getValue(ACCELERATOR_KEY, null);
	}

	/**
	 * @since 5.0
	 */
	public void setAcceleratorKey(final int keyCode) {
		setAcceleratorKey(keyCode, 0);
	}

	/**
	 * Sets the keyboard shortcut.
	 * @param keyCode A key code (e.g. @c VK_X)
	 * @param modifiers Modifiers keys (e.g. @c CTRL_MASK)
	 */
	@InvokedFromConstructor
	public void setAcceleratorKey(final int keyCode, final int modifiers) {
		putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(keyCode, modifiers));
	}

	/**
	 * Sets the keyboard shortcut.
	 * @param keyStroke A key stroke
	 */
	public void setAcceleratorKey(final KeyStroke keyStroke) {
		putValue(ACCELERATOR_KEY, keyStroke);
	}

	/**
	 * Returns the alternate key stroke associated with this action.
	 *
	 * @since 3.2
	 */
	public KeyStroke getAlternateAcceleratorKey() {
		return getValue(ALTERNATE_ACCELERATOR_KEY, null);
	}

	/**
	 * Sets the alternate keyboard shortcut.
	 *
	 * @param keyCode the key code (e.g. @c VK_X)
	 * @param modifiers the modifier keys (e.g. @c CTRL_MASK)
	 *
	 * @since 3.2
	 */
	public void setAlternateAcceleratorKey(final int keyCode, final int modifiers) {
		putValue(ALTERNATE_ACCELERATOR_KEY, KeyStroke.getKeyStroke(keyCode, modifiers));
	}

	/**
	 * Sets the alternate keyboard shortcut.
	 *
	 * @param keyStroke the key stroke
	 *
	 * @since 3.2
	 */
	public void setAlternateAcceleratorKey(final KeyStroke keyStroke) {
		putValue(ALTERNATE_ACCELERATOR_KEY, keyStroke);
	}

	/**
	 * Returns a text suitable for dialog titles.
	 * The current implementation returns {@link #getName()}
	 * without leading and trailing <code>"..."</code>.
	 *
	 * @since 4.2
	 */
	public String getDialogTitle() {
		return MActionInfo.getDialogTitle(getName());
	}

	/**
	 * Returns the <i>find next</i> keyboard shortcut.
	 */
	public static KeyStroke getFindNextKeyStroke() {
		// Meta+G
		if (OS.isMac())
			return KeyStroke.getKeyStroke(VK_G, getMenuMask());

		// F3
		return KeyStroke.getKeyStroke(VK_F3, 0);
	}

	/**
	 * Returns the <i>find previous</i> keyboard shortcut.
	 *
	 * @since 4.6
	 */
	public static KeyStroke getFindPreviousKeyStroke() {
		// Shift+Meta+G
		if (OS.isMac())
			return KeyStroke.getKeyStroke(VK_G, getMenuMask() | SHIFT_MASK);

		// Shift+F3
		return KeyStroke.getKeyStroke(VK_F3, SHIFT_MASK);
	}

	/**
	 * Returns the <i>full screen</i> keyboard shortcut.
	 *
	 * @deprecated Since 4.4
	 */
	@Deprecated
	public static KeyStroke getFullScreenKeyStroke() {
		// Ctrl+Shift+F11
		if (OS.isKDE())
			return KeyStroke.getKeyStroke(VK_F, getMenuMask() | SHIFT_MASK);

		// F11
		return KeyStroke.getKeyStroke(VK_F11, 0);
	}

	/**
	 * Returns the help ({@code LONG_DESCRIPTION}).
	 *
	 * @mg.default
	 * {@code null}
	 *
	 * @see #getToolTipText()
	 *
	 * @since 4.0
	 */
	public String getHelpText() {
		return getHelpText(this);
	}

	/**
	 * Sets the help ({@code LONG_DESCRIPTION}).
	 * This value is automatically used in {@link org.makagiga.commons.swing.MMenuItem}s as a tool tip text.
	 *
	 * @see #setHTMLHelp(String)
	 * @see #setToolTipText(String)
	 *
	 * @since 4.0
	 */
	public void setHelpText(final String value) {
		putValue(LONG_DESCRIPTION, value);
	}

	/**
	 * @since 4.0
	 */
	public static String getHelpText(final Action action) {
		return getValue(action, LONG_DESCRIPTION, null);
	}

	/**
	 * @since 3.8.6
	 */
	public Component getHighlightedComponent() {
		WeakReference<Component> ref = getValue(HIGHLIGHTED_COMPONENT_KEY, null);

		return (ref == null) ? null : ref.get();
	}

	/**
	 * @since 3.8.6
	 */
	public void setHighlightedComponent(final Component c) {
		WeakReference<Component> ref = getValue(HIGHLIGHTED_COMPONENT_KEY, null);
		if (ref != null)
			ref.clear();

		putValue(HIGHLIGHTED_COMPONENT_KEY, (c == null) ? null : (new WeakReference<>(c)));
	}

	/**
	 * Returns the @b large icon. If large icon is not available,
	 * returns the @b small icon or @c null.
	 */
	public Icon getIcon() {
		Icon icon = getLargeIcon();
		
		return (icon == null) ? getSmallIcon() : icon;
	}
	
	public static Icon getIcon(final Action action, final MIcon.Size iconSize) {
		Icon icon;
		switch (iconSize) {
			case SMALL:
				return getValue(action, SMALL_ICON, null);
			case MEDIUM:
				icon = getValue(action, LARGE_ICON_KEY, null);
				if (icon == null)
					icon = getValue(action, SMALL_ICON, null);
				if (icon instanceof MIcon) {
					String iconName = MIcon.class.cast(icon).getName();
					
					if (iconName != null)
						icon = MIcon.medium(iconName);
				}
				
				return icon;
			default: // DEFAULT
				icon = getValue(action, LARGE_ICON_KEY, null);
				if (icon == null)
					icon = getValue(action, SMALL_ICON, null);
				
				return icon;
		}
	}
	
	/**
	 * @since 4.2
	 */
	public void setIcon(final Icon value) {
		setLargeIcon(value);
		setSmallIcon(value);
	}

	/**
	 * Returns the large icon associated with this action.
	 */
	public Icon getLargeIcon() {
		return getValue(LARGE_ICON_KEY, null);
	}

	/**
	 * Sets large icon to @p value.
	 */
	public void setLargeIcon(final Icon value) {
		putValue(LARGE_ICON_KEY, value);
	}

	/**
	 * Sets large icon to @p iconName.
	 */
	public void setLargeIcon(final String value) {
		setLargeIcon(MIcon.stock(value));
	}

	/**
	 * Returns the <i>mask</i> for the menu shortcut key
	 * (example: {@code KeyEvent.CTRL_MASK} on Windows).
	 *
	 * @since 3.8.2
	 */
	public static int getMenuMask() { return menuMask; }

	/**
	 * @since 3.8
	 */
	public String getMouseGesture() {
		return getValue(MOUSE_GESTURE_KEY, null);
	}

	/**
	 * @since 3.8
	 */
	public void setMouseGesture(final String value) {
		putValue(MOUSE_GESTURE_KEY, value);
	}

	/**
	 * Returns the name or @c null.
	 */
	public String getName() {
		return getValue(NAME, null);
	}

	/**
	 * Sets name to @p value.
	 */
	@InvokedFromConstructor
	public void setName(final String value) {
		putValue(NAME, TK.isEmpty(value) ? null : value);
	}

	/**
	 * Returns the <i>redo</i> keyboard shortcut.
	 */
	public static KeyStroke getRedoKeyStroke() {
		// Ctrl+Shift+Z
		if (OS.isKDE() || OS.isMac())
			return KeyStroke.getKeyStroke(VK_Z, getMenuMask() | SHIFT_MASK);

		// Ctrl+Y
		return KeyStroke.getKeyStroke(VK_Y, getMenuMask());
	}

	/**
	 * @since 5.8
	 */
	public String getShortDescription() {
		return getValue(this, SHORT_DESCRIPTION, null);
	}

	/**
	 * @since 5.8
	 */
	public void setShortDescription(final String value) {
		putValue(SHORT_DESCRIPTION, value);
	}

	/**
	 * Returns the small icon associated with this action.
	 */
	public Icon getSmallIcon() {
		return getValue(SMALL_ICON, null);
	}

	/**
	 * Sets small icon to @p value.
	 */
	@InvokedFromConstructor
	public void setSmallIcon(final Icon value) {
		putValue(SMALL_ICON, value);
	}

	/**
	 * Sets small icon to @p value.
	 */
	public void setSmallIcon(final String value) {
		setSmallIcon(MIcon.small(value));
	}

	/**
	 * @since 5.0
	 */
	public Object getSource() {
		return actionEvent.getSource();
	}

	/**
	 * @since 3.0
	 */
	public Window getSourceWindow() {
		Object source = actionEvent.getSource();
		Window result = null;
		if (source instanceof Component) {
			Component c = (Component)source;
			Window window = UI.windowFor(c);
			
			if (window != null)
				return window;

			c = c.getParent();
			if (c instanceof JPopupMenu) {
				c = JPopupMenu.class.cast(c).getInvoker();
				if (c instanceof MMenu) {
					c = c.getParent();
					if (c instanceof JPopupMenu)
						c = JPopupMenu.class.cast(c).getInvoker();
				}
				
				if (c != null)
					result = UI.windowFor(c);
			}
		}
		
		return (result == null) ? UI.windowFor(null) : result;
	}

	/**
	 * Returns the tool tip text ({@code SHORT_DESCRIPTION}).
	 * 
	 * @mg.default
	 * {@code null}
	 *
	 * @see #getHelpText()
	 *
	 * @since 3.8.3
	 */
	public String getToolTipText() {
		return getToolTipText(this);
	}

	/**
	 * @since 3.8.3
	 */
	public static String getToolTipText(final Action action) {
		return getValue(action, SHORT_DESCRIPTION, null);
	}

	/**
	 * Sets the tool tip text ({@code SHORT_DESCRIPTION}).
	 *
	 * @see #setHelpText(String)
	 *
	 * @since 3.8.3
	 */
	public void setToolTipText(final String value) {
		putValue(SHORT_DESCRIPTION, value);
	}

	@SuppressWarnings("unchecked")
	public <T> T getValue(final String key, final T defaultValue) {
		Object value = getValue(key);
		
		return (value == null) ? defaultValue : (T)value;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getValue(final Action action, final String key, final T defaultValue) {
		Object value = action.getValue(key);
		
		return (value == null) ? defaultValue : (T)value;
	}
	
	/**
	 * @since 4.0
	 */
	public boolean isHTMLEnabled() { return htmlEnabled; }

	/**
	 * @since 4.0
	 */
	public void setHTMLEnabled(final boolean value) { htmlEnabled = value; }

	/**
	 * Returns @c true if item associated with this action is selected (checked).
	 */
	public boolean isSelected() {
		return getValue(SELECTED_KEY, false);
	}

	/**
	 * Selects the item associated with this action.
	 * @param value {@code true} = select
	 */
	public void setSelected(final boolean value) {
		putValue(SELECTED_KEY, value);
	}

	/**
	 * Returns a <i>visibility</i> hint ({@link #VISIBLE_KEY}) for a component.
	 * Supported by {@link org.makagiga.commons.swing.MButton} component.
	 * 
	 * @mg.default
	 * {@code true}
	 *
	 * @since 3.8.3
	 */
	public boolean isVisible() {
		return getValue(VISIBLE_KEY, true);
	}

	/**
	 * Sets a <i>visibility</i> hint ({@link #VISIBLE_KEY}) for a component.
	 * Supported by {@link org.makagiga.commons.swing.MButton} component.
	 *
	 * @since 3.8.3
	 */
	public void setVisible(final boolean value) {
		putValue(VISIBLE_KEY, value);
	}

	public static boolean isTrigger(final InputEvent e) {
		if (e instanceof KeyEvent) {
			KeyEvent ke = (KeyEvent)e;
			
			return TK.isKeyStroke(ke, VK_ENTER) || TK.isKeyStroke(ke, VK_SPACE);
		}
		else if (e instanceof MouseEvent) {
			MouseEvent me = (MouseEvent)e;

			return MMouseAdapter.isLeft(me) && MMouseAdapter.isSingleClick(me);
		}
		else {
			return false;
		}
	}

	/**
	 * Invoked when an action occurs.
	 */
	public void onAction() { }
	
	/**
	 * Sets HTML help text to {@code value}.
	 *
	 * @see #setHelpText(String)
	 */
	public void setHTMLHelp(final String value) {
		setHelpText(TK.isEmpty(value) ? null : UI.makeHTML(value));
	}

	/**
	 * @since 3.8.7
	 */
	public void setActionInfo(final MActionInfo info) {
		setAcceleratorKey(info.getKeyStroke());
		setIconName(info.getIconName());
		setName(info.getText());
	}

	@Override
	public void setEnabled(final boolean value) {
		if (isAuthorized())
			super.setEnabled(value);
		else
			super.setEnabled(false);
	}

	/**
	 * @since 4.8
	 */
	public boolean showConfirmMessage() {
		return createMessage()
			.exec(this);
	}

	/**
	 * @since 4.0
	 */
	public void showErrorMessage() {
		MStatusBar.error(i18n("Action failed: {0}", getName()));
	}

	/**
	 * @since 4.10
	 */
	public void showErrorMessage(final Throwable error) {
		MMessage.error(getSourceWindow(), error, i18n("Action failed: {0}", getName()));
	}

	/**
	 * @since 5.0
	 */
	public void showFeedback() {
		MStatusBar.ok(getName());
	}

	/**
	 * @since 3.8.12
	 */
	public MActionInfo toActionInfo() {
		KeyStroke ks = getAcceleratorKey();

		if (ks == null)
			return new MActionInfo(getName(), getIconName());

		return new MActionInfo(getName(), getIconName(), ks.getKeyCode(), ks.getModifiers());
	}

	// MIcon.Name

	/**
	 * @since 3.2
	 */
	@Override
	public String getIconName() {
		return MIcon.getName(getIcon());
	}

	/**
	 * @mg.note This sets both large and small icon.
	 *
	 * @since 3.2
	 */
	@Override
	public void setIconName(final String value) {
		setLargeIcon(value);
		setSmallIcon(value);
	}

	// protected

	protected ActionEvent getActionEvent() { return actionEvent; }

	/**
	 * @since 3.8.9
	 */
	protected void setAuthorizationProperty(final Property<Boolean> property) {
		authProperty = property;
		super.setEnabled(isAuthorized());
	}

	// private

	private boolean isAuthorized() {
		return (authProperty == null) || Boolean.TRUE.equals(authProperty.get());
	}
	
	@SuppressWarnings("unchecked")
	private void setActionHandler(final Consumer<? extends MAction> actionHandler) {
		this.actionHandler = (Consumer<MAction>)Objects.requireNonNull(actionHandler);
	}

	// public classes
	
	/**
	 * @deprecated Since 5.0
	 */
	@Deprecated
	@FunctionalInterface
	public static interface ScriptEvent extends Serializable {

		// public

		/**
		 * @since 4.0
		 */
		public String event(final MAction action);

	}

}
