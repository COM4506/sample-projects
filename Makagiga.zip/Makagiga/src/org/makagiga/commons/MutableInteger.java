// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import org.makagiga.commons.annotation.Important;

/**
 * @since 3.8
 */
public class MutableInteger extends Number
implements
	Cloneable,
	Comparable<MutableInteger>,
	Copyable<MutableInteger>
{

	// private

	private int value;
	
	// public
	
	public MutableInteger() { }

	public MutableInteger(final int value) {
		this.value = value;
	}

	@Override
	public double doubleValue() { return (double)value; }

	@Override
	public float floatValue() { return (float)value; }

	@Override
	public int intValue() { return value; }

	@Override
	public long longValue() { return (long)value; }

	public void set(final int value) { this.value = value; }

	@Override
	public boolean equals(final Object o) {
		if (o == this)
			return true;

		if (!(o instanceof MutableInteger))
			return false;

		return this.value == MutableInteger.class.cast(o).value;
	}

	@Override
	public int hashCode() { return 0; }

	@Important
	@Override
	public String toString() {
		return Integer.toString(value);
	}

	// Cloneable

	/**
	 * @deprecated As of 4.4, replaced by {@link #copy()}
	 */
	@Deprecated
	@Override
	public Object clone() {
		try {
			return super.clone();
		}
		catch (CloneNotSupportedException exception) {
			throw new WTFError(exception);
		}
	}

	// Comparable

	@Override
	public int compareTo(final MutableInteger other) {
		return Integer.compare(this.value, other.value);
	}
	
	// Copyable
	
	/**
	 * @since 4.4
	 */
	@Override
	public MutableInteger copy() {
		return new MutableInteger(value);
	}

}
