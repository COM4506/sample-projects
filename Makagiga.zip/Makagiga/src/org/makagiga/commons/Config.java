// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Pattern;

import org.makagiga.commons.annotation.ConfigEntry;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.security.MPermission;

/**
 * A configuration file.
 *
 * I18N support.
 * You can use the following syntax in a .properties file:
 * <pre>
 * ...
 * # English text
 * String.text=Hello
 * # Polish text
 * String.text[pl]=Witaj
 * ...
 * </pre>
 *
 * @mg.threadSafe
 */
public class Config implements Serializable {

	// public

	// config flags
	
	public static final int READ_ONLY = 1;
	public static final int RESOURCE = 1 << 1;
	private static final int DEFAULT = 1 << 2; // private

	// private

	private static final Config.Permission GET_DEFAULT_PERMISSION = new Config.Permission("DEFAULT", Config.Permission.GET_DEFAULT_ACTION);
	private List<Class<?>> registeredClasses;
	private static List<Class<?>> defaultClasses;
	private boolean loadError;
	private boolean modified;
	private boolean readOnly;
	private static Config global;
	private final Flags flags;
	private Map<String, Property<?>> registeredProperties;
	private static final MLogger log = MLogger.get("config");
	private MProperties properties;
	private static String defaultComment;
	private static String langKey;
	private String path;

	// public
	
	static {
		init();
	}
	
	/**
	 * @since 2.0
	 */
	public Config() {
		this((String)null, 0);
	}

	/**
	 * @since 3.8
	 */
	public Config(final MProperties properties, final int flags) {
		this.flags = Flags.valueOf(flags);
		readOnly = this.flags.isSet(READ_ONLY);
		path = ""; // see isError()
		this.properties = properties;
	}

	/**
	 * @since 5.4
	 */
	public Config(final Path path) {
		this(path.toString(), 0);
	}

	/**
	 * Constructs a new configuration file.
	 * Configuration values are loaded from the specified file.
	 * @param path A configuration file to load
	 * @param flags Flags (e.g. @ref RESOURCE)
	 *
	 * @see #isError() Use this function to check for load error
	 */
	public Config(final String path, final int flags) {
		this.flags = Flags.valueOf(flags);
		readOnly = this.flags.isSet(READ_ONLY);
		this.path = path;
		if (this.flags.isClear(DEFAULT))
			loadError = !load();
	}

	/**
	 * Constructs a new configuration file.
	 * Configuration values are loaded from the specified file.
	 * @param path A configuration file to load
	 *
	 * @see #isError() Use this function to check for load error
	 */
	public Config(final String path) {
		this(path, 0);
	}

	/**
	 * Returns the default (global) configuration.
	 * 
	 * @throws IllegalStateException If "internal name" is not set
	 */
	public static Config getDefault() {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(GET_DEFAULT_PERMISSION);

		//Benchmark benchmark = Benchmark.begin("config");
		synchronized (Config.class) {
			if (global != null)
				return global;
		
			if (FS.isRestricted()) {
				global = new Config();

				return global;
			}
		
			int flags = DEFAULT;
			global = new Config(FS.makeConfigPath(MApplication.getInternalName() + ".properties"), flags);

			global.registerProperty("Debug.log", MLogger.debugLog);
			global.registerProperty("developer", MLogger.developer);

			global.registerProperty("Net.connectTimeout", Net.connectTimeout);
			global.registerProperty("Net.readTimeout", Net.readTimeout);

			global.registerProperty("OS.openCommand", OS.openCommand);
			
			global.registerClass(Kiosk.class);
			global.registerClass(MApplication.class);
			global.registerClass(UI.class);
			if (defaultClasses != null) {
				for (Class<?> i : defaultClasses)
					global.registerClass(i);
			}
			global.load();
		}
		//benchmark.end();
		
		return global;
	}

	public synchronized static String getDefaultComment() { return defaultComment; }
	
	/**
	 * Sets the default comment to @p value.
	 * The comment value is stored in the configuration file as a comment.
	 */
	public synchronized static void setDefaultComment(final String value) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new Config.Permission(value, Config.Permission.WRITE_ACTION));

		defaultComment = value;
	}

	public synchronized String getPath() { return path; }
	
	public synchronized void setPath(final String value) {
		checkPermission(null, Permission.WRITE_ACTION);
		
		path = value;
	}
	
	/**
	 * @since 3.0
	 */
	public static String getPlatformKey(final String key) {
		return (key + '@' + OS.getInternalName());
	}
	
	/**
	 * @since 2.0
	 */
	public synchronized MProperties getProperties() {
		checkPermission(null, Permission.WRITE_ACTION);
		
		return properties;
	}

	/**
	 * @since 4.6
	 */
	public Map<String, ConfigEntry> getRegisteredConfigEntries() {
		Map<String, ConfigEntry> map = new HashMap<>();
		synchronized (this) {
			if (registeredClasses == null)
				return map;

			for (Class<?> clazz : registeredClasses) {
				try {
					for (Map.Entry<Field, Property<?>> i : Property.listStatic(clazz).entrySet()) {
						Field field = i.getKey();
						ConfigEntry configEntry = field.getAnnotation(ConfigEntry.class);
						if (configEntry != null)
							map.put(configEntry.value(), configEntry);
					}
				}
				catch (IllegalAccessException exception) {
					MLogger.exception(exception);
				}
			}
		}
		
		return map;
	}

	/**
	 * @since 2.0
	 */
	public Map<String, Property<?>> getRegisteredProperties() {
		Map<String, Property<?>> map = new HashMap<>();
		synchronized (this) {
			if (registeredProperties != null)
				map.putAll(registeredProperties);
		
			if (registeredClasses == null)
				return map;

			for (Class<?> clazz : registeredClasses) {
				try {
					for (Map.Entry<Field, Property<?>> i : Property.listStatic(clazz).entrySet()) {
						Field field = i.getKey();
						ConfigEntry configEntry = field.getAnnotation(ConfigEntry.class);
						if (configEntry != null)
							map.put(configEntry.value(), i.getValue());
					}
				}
				catch (IllegalAccessException exception) {
					MLogger.exception(exception);
				}
			}
		}
		
		return map;
	}

	/**
	 * @since 4.2
	 */
	public static String getScreenKey(final String key) {
		return getScreenKey(key, UI.getScreenSize());
	}

	/**
	 * @since 4.2
	 */
	public static String getScreenKey(final String key, final Dimension screenSize) {
		return key + '.' + screenSize.width + 'x' + screenSize.height;
	}

	/**
	 * Returns @c false if configuration file could not be loaded.
	 */
	public synchronized boolean isError() {
		return loadError || (path == null);
	}

	/**
	 * @since 4.0
	 */
	public boolean isReadOnly() { return readOnly; }

	@InvokedFromConstructor
	public synchronized boolean load() {
		checkPermission(null, Permission.READ_ACTION);

		if (path == null)
			return false;

		boolean immutable = false;
		MProperties defaults = flags.isSet(DEFAULT) ? getGlobalDefaults() : null;
		if (defaults == null) {
			properties = new MProperties();
		}
		else {
			// check if config is marked as immutable
			if ("true".equals(defaults.getProperty("IMMUTABLE"))) {
				immutable = true;
				readOnly = true;
				properties = defaults;
			}
			else {
				properties = new MProperties(defaults);
			}
		}
		
		try {
			if (!immutable) {
				if (flags.isSet(RESOURCE)) {
					try (InputStream input = getClass().getClassLoader().getResourceAsStream(path)) {
						properties.loadUTF8(input);
					}
				}
				else {
					properties.loadUTF8(new File(path));
				}
			}
			modified = false;

			return true;
		}
		catch (FileNotFoundException exception) { // quiet
			return false;
		}
		catch (IOException exception) {
			MLogger.exception(exception);
			
			return false;
		}
		finally {
			if (registeredClasses != null) {
				for (Class<?> i : registeredClasses)
					read(i);
			}

			if (registeredProperties != null) {
				for (Map.Entry<String, Property<?>> i : registeredProperties.entrySet()) {
					Property<?> p = i.getValue();
					readProperty(p.isOption(Property.PLATFORM) ? getPlatformKey(i.getKey()) : i.getKey(), p);
				}
			}
		}
	}

	/**
	 * @since 5.0
	 */
	public <T> ListReader<T> newListReader(final String keyPrefix) {
		return new ListReader<>(this, keyPrefix);
	}

	/**
	 * @since 5.0
	 */
	public <T> ListWriter<T> newListWriter(final String keyPrefix) {
		return new ListWriter<>(this, keyPrefix);
	}

	/**
	 * @deprecated As of 4.6, replaced by {@link #readStaticProperties(java.lang.Class)}
	 */
	@Deprecated
	public void read(final Class<?> clazz) {
		read(clazz, null);
	}

	/**
	 * @since 3.0
	 *
	 * @deprecated As of 4.6, replaced by {@link #readProperties(java.lang.Object)} and {@link #readStaticProperties(java.lang.Class)}
	 */
	@Deprecated
	public synchronized void read(final Class<?> clazz, final Object object) {
		try {
			Map<Field, Property<?>> map =
				(object == null)
				? Property.listStatic(clazz)
				: Property.list(object);
			for (Map.Entry<Field, Property<?>> i : map.entrySet()) {
				String key = getKey(i.getKey());
				if (key != null)
					readProperty(key, i.getValue());
			}
		}
		catch (IllegalAccessException exception) {
			MLogger.exception(exception);
		}
	}

	/**
	 * Reads a @c boolean value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist.
	 */
	public boolean read(final String key, final boolean defaultValue) {
		String value = readValue("Boolean", key, Boolean.toString(defaultValue));

		return Boolean.parseBoolean(value);
	}
	
	/**
	 * Reads a @c String value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist.
	 */
	public String read(final String key, final String defaultValue) {
		return readValue("String", key, defaultValue);
	}

	/**
	 * Reads a @c Color value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist, or if value is invalid.
	 */
	public Color readColor(final String key, final Color defaultValue) {
		try {
			String value = readValue("Color", key, null);

			if (TK.isEmpty(value))
				return defaultValue;

			return ColorProperty.parseColor(value);
		}
		catch (ParseException exception) {
			synchronized (this) {
				log.errorFormat("Invalid color value (%s, %s)", key, path);
			}

			return defaultValue;
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return defaultValue;
		}
	}

	/**
	 * Reads a @c Date value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist, or if value is invalid.
	 *
	 * @since 2.0
	 */
	public MDate readDate(final String key, final java.util.Date defaultValue) {
		return readDate(key, (defaultValue == null) ? 0 : defaultValue.getTime());
	}

	/**
	 * Reads a @c Date value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist, or if value is invalid.
	 *
	 * @since 2.0
	 */
	public MDate readDate(final String key, final long defaultValue) {
		return new MDate(readDateValue(key, defaultValue));
	}

	/**
	 * @since 4.0
	 */
	public long readDateValue(final String key, final long defaultValue) {
		try {
			String value = readValue("Date", key, null);

			if (value == null)
				return defaultValue;

			return Long.parseLong(value);
		}
		catch (NumberFormatException exception) {
			synchronized (this) {
				log.errorFormat("Invalid date value (%s, %s)", key, path);
			}

			return defaultValue;
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return defaultValue;
		}
	}

	/**
	 * @since 3.8.3
	 */
	public Dimension readDimension(final String key, final Dimension defaultValue) {
		return readDimension(key, defaultValue.width, defaultValue.height);
	}

	/**
	 * @since 3.8.3
	 */
	public Dimension readDimension(final String key, final int defaultWidth, final int defaultHeight) {
		return new Dimension(
			readInt(key + ".width", defaultWidth),
			readInt(key + ".height", defaultHeight)
		);
	}

	/**
	 * @since 3.0
	 */
	public double readDouble(final String key, final double defaultValue) {
		try {
			String value = readValue("Double", key, "");

			if (value.isEmpty())
				return defaultValue;

			return Double.parseDouble(value);
		}
		catch (NumberFormatException exception) {
			synchronized (this) {
				log.errorFormat("Invalid double value (%s, %s)", key, path);
			}

			return defaultValue;
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return defaultValue;
		}
	}

	/**
	 * @since 2.0
	 */
	public <T extends Enum<T>> T readEnum(final String key, final T defaultValue) {
		String value = readValue("Enum", key, null);
		
		return EnumProperty.parse(value, defaultValue);
	}

	/**
	 * Reads a @c float value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist, or if value is invalid.
	 */
	public float readFloat(final String key, final float defaultValue) {
		try {
			String value = readValue("Float", key, "");

			if (value.isEmpty())
				return defaultValue;

			return Float.parseFloat(value);
		}
		catch (NumberFormatException exception) {
			synchronized (this) {
				log.errorFormat("Invalid float value (%s, %s)", key, path);
			}

			return defaultValue;
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return defaultValue;
		}
	}
	
	/**
	 * @since 2.0 
	 */
	public Font readFont(final String key, final Font defaultValue) {
		String value = readValue("Font", key, null);
		
		if (value == null)
			return defaultValue;
		
		return Font.decode(value);
	}

	/**
	 * Reads an @c int value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist, or if value is invalid.
	 */
	public int readInt(final String key, final int defaultValue) {
		try {
			String value = readValue("Integer", key, null);

			if (value == null)
				return defaultValue;

			return Integer.parseInt(value);
		}
		catch (NumberFormatException exception) {
			synchronized (this) {
				log.errorFormat("Invalid integer value (%s, %s)", key, path);
			}

			return defaultValue;
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return defaultValue;
		}
	}
	
	public int readInt(final String key, final int defaultValue, final int minValue) {
		return readInt(key, defaultValue, minValue, Integer.MAX_VALUE);
	}

	/**
	 * Reads an {@code int} value from the configuration.
	 *
	 * @param key the key
	 * @param defaultValue the default value
	 * @param minValue the minimal value
	 * @param maxValue the maximal value
	 *
	 * @mg.warning
	 * Since version 4.0 the returned value is limited using {@link TK#limit(int, int, int)},
	 * so it returns {@code minValue} or {@code maxValue} rather than the {@code defaultValue}.
	 */
	public int readInt(final String key, final int defaultValue, final int minValue, final int maxValue) {
		return TK.limit(readInt(key, defaultValue), minValue, maxValue);
	}

	/**
	 * @since 3.0
	 */
	public int readInt(final String key, final int defaultValue, final IntRange range) {
		IntInfo info = range.getIntInfo();

		return readInt(key, defaultValue, info.getMinimum(), info.getMaximum());
	}

	/**
	 * Reads a @c long value from the configuration file.
	 * @param key A configuration key
	 * @param defaultValue A default value. This value is returned if @p key does not exist, or if value is invalid.
	 */
	public long readLong(final String key, final long defaultValue) {
		try {
			String value = readValue("Integer", key, "");

			if (value.isEmpty())
				return defaultValue;

			return Long.parseLong(value);
		}
		catch (NumberFormatException exception) {
			synchronized (this) {
				log.errorFormat("Invalid integer (long) value (%s, %s)", key, path);
			}

			return defaultValue;
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return defaultValue;
		}
	}

	/**
	 * @since 5.6
	 */
	public boolean readOnce(final String key, final boolean defaultValue) {
		boolean currentValue = read(key, defaultValue);
		if (currentValue == defaultValue) {
			write(key, !currentValue);
			sync();
		}
		
		return currentValue;
	}

	/**
	 * @since 3.8.3
	 */
	public Point readPoint(final String key, final int defaultX, final int defaultY) {
		return new Point(
			readInt(key + ".x", defaultX),
			readInt(key + ".y", defaultY)
		);
	}

	/**
	 * @since 3.8.3
	 */
	public Point readPoint(final String key, final Point defaultValue) {
		return readPoint(key, defaultValue.x, defaultValue.y);
	}

	/**
	 * @since 4.6
	 */
	public void readProperties(final Object object) {
		validateObject(object);
		read(null, object);
	}

	/**
	 * @since 3.0
	 */
	public <T extends Property<?>> void readProperty(final String key, final T o) {
		if (o == null)
			return;

		try {
			o.read(this, key);
		}
		catch (UnsupportedOperationException exception) {
			synchronized (this) {
				log.errorFormat("Cannot read unsupported %s property: %s (%s)", o.getClass().getName(), key, path);
			}
		}
	}

	/**
	 * @since 4.6
	 */
	public void readStaticProperties(final Class<?> clazz) {
		read(clazz, null);
	}

	public String readValue(final String key, final String defaultValue) {
		//checkPermission(key, Permission.READ_ACTION);
		
		if (key == null)
			return defaultValue;

		synchronized (this) {
			if (properties == null)
				return defaultValue;

			// try i18n value
			String result = properties.getProperty(key + langKey, null);

			if (result != null)
				return result;

			// try default value
			result = properties.getProperty(key, defaultValue);

			return (result == null) ? defaultValue : result;
		}
	}
	
	public String readValue(final String prefix, final String key, final String defaultValue) {
		return readValue(prefix + '.' + key, defaultValue);
	}

	/**
	 * @since 2.0
	 */
	public synchronized void registerClass(final Class<?> clazz) {
		checkPermission(clazz.getName(), Permission.WRITE_ACTION);
		
		if (registeredClasses == null)
			registeredClasses = new MArrayList<>();
		
		registeredClasses.add(clazz);
	}
	
	/**
	 * @since 2.0
	 */
	public synchronized static void registerDefaultClass(final Class<?> clazz) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new Config.Permission(clazz.getName(), Config.Permission.WRITE_ACTION));
		
		if (defaultClasses == null)
			defaultClasses = new MArrayList<>();
		defaultClasses.add(clazz);
	}
	
	/**
	 * @since 4.6
	 */
	public synchronized void registerProperty(final String key, final Property<?> property) {
		if (registeredProperties == null)
			registeredProperties = new HashMap<>();
		registeredProperties.put(key, property);
	}

	/**
	 * Removes all keys/values and marks configuration as modified.
	 * Does nothing if configuration is read only.
	 *
	 * @since 2.0
	 */
	public synchronized void removeAll() {
		checkPermission(null, Permission.WRITE_ACTION);
		
		if (!readOnly) {
			modified = true;
			if (properties != null)
				properties.clear();
		}
	}

	public void removeBoolean(final String key) {
		removeValue("Boolean." + key);
	}

	/**
	 * Removes a <i>date</i> value identified by @p key.
	 *
	 * @since 1.2
	 */
	public void removeDate(final String key) {
		removeValue("Date." + key);
	}

	/**
	 * Removes an <i>integer</i> value identified by @p key.
	 *
	 * @since 1.2
	 */
	public void removeInt(final String key) {
		removeValue("Integer." + key);
	}

	public void removeString(final String key) {
		removeValue("String." + key);
	}

	public synchronized void removeValue(final String key) {
		checkPermission(key, Permission.WRITE_ACTION);
		
		if (readOnly)
			return;
		
		if ((properties != null) && properties.containsKey(key)) {
			properties.remove(key);
			modified = true;
		}
	}

	/**
	 * Removes all values that matches {@code pattern}.
	 *
	 * @since 2.0
	 */
	public void removeAllValues(final Pattern pattern) {
		// HACK: asPredicate uses Matcher.find()
		// which is undocumented and confusing:
		// http://stackoverflow.com/questions/23540817/bug-in-pattern-aspredicate
		//removeAllValues(pattern.asPredicate());
		removeAllValues(key -> pattern.matcher(key).matches());
	}
	
	/**
	 * @since 4.10
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public void removeAllValues(final PatternBuilder pattern) {
		removeAllValues(pattern.toPattern());
	}
	
	/**
	 * @since 5.6
	 */
	public synchronized void removeAllValues(final Predicate<String> predicate) {
		checkPermission("*", Permission.WRITE_ACTION);
		
		if (readOnly || (properties == null))
			return;

		Iterator<Object> it = properties.keySet().iterator();
		while (it.hasNext()) {
			Object key = it.next();
			if (predicate.test(key.toString())) {
				it.remove();
				modified = true;
			}
		}
	}
	
	/**
	 * Saves the configuration to the file.
	 * You can change target file name using @ref path.
	 * 
	 * @return {@code true} if successful; otherwise {@code false}
	 * 
	 * @since 3.0
	 */
	public synchronized boolean sync() {
		if (readOnly || (properties == null))
			return false;
		
		if (registeredClasses != null) {
			for (Class<?> i : registeredClasses)
				write(i);
		}

		if (registeredProperties != null) {
			for (Map.Entry<String, Property<?>> i : registeredProperties.entrySet()) {
				Property<?> p = i.getValue();
				write(p.isOption(Property.PLATFORM) ? getPlatformKey(i.getKey()) : i.getKey(), p);
			}
		}

		//log.debugFormat("modified=%s", modified);

		if (!modified)
			return true;

		if (path == null)
			return false;

		properties.setComment(defaultComment);
		try {
			properties.storeUTF8(new File(path));
			modified = false;

			return true;
		}
		catch (IOException exception) {
			MLogger.exception(exception);

			return false;
		}
	}
	
	/**
	 * @since 4.6
	 */
	public void syncProperties(final Object object) {
		writeProperties(object);
		sync();
	}

	/**
	 * @since 4.6
	 */
	public void syncStaticProperties(final Class<?> clazz) {
		writeStaticProperties(clazz);
		sync();
	}

	/**
	 * @deprecated As of 4.6, replaced by {@link #writeStaticProperties(java.lang.Class)}
	 */
	@Deprecated
	public void write(final Class<?> clazz) {
		write(clazz, null);
	}
	
	/**
	 * @since 3.0
	 *
	 * @deprecated As of 4.6, replaced by {@link #writeProperties(java.lang.Object)} and {@link #writeStaticProperties(java.lang.Class)}
	 */
	@Deprecated
	public synchronized void write(final Class<?> clazz, final Object object) {
		try {
			Map<Field, Property<?>> map =
				(object == null)
				? Property.listStatic(clazz)
				: Property.list(object);
			for (Map.Entry<Field, Property<?>> i : map.entrySet()) {
				String key = getKey(i.getKey());
				if (key != null)
					write(key, i.getValue());
			}
		}
		catch (IllegalAccessException exception) {
			MLogger.exception(exception);
		}
	}

	/**
	 * Writes a @c boolean value.
	 * @param key A configuration key
	 * @param value A value to write
	 */
	public void write(final String key, final boolean value) {
		writeValue("Boolean", key, Boolean.toString(value));
	}

	/**
	 * Writes a @c Color value.
	 * The value is stored in a RRGGBB format (e.g. ff0000 = red color, rrggbb).
	 * @param key A configuration key
	 * @param value A value to write
	 */
	public void write(final String key, final Color value) {
		writeValue(
			"Color",
			key,
			(value == null) ? "" : ColorProperty.toHex(value)
		);
	}

	/**
	 * Writes a @c Date value.
	 * The date is stored as the @c long type.
	 * @param key A configuration key
	 * @param value A value to write
	 */
	public void write(final String key, final java.util.Date value) {
		writeDate(key, (value == null) ? 0 : value.getTime());
	}

	/**
	 * @since 3.8.3
	 */
	public void write(final String key, final Dimension value) {
		write(key + ".width", value.width);
		write(key + ".height", value.height);
	}

	/**
	 * @since 3.0
	 */
	public void write(final String key, final double value) {
		writeValue("Double", key, Double.toString(value));
	}

	/**
	 * @since 2.0
	 */
	public void write(final String key, final Enum<?> value) {
		writeValue("Enum", key, value.name());
	}

	/**
	 * Writes a @c float value.
	 * @param key A configuration key
	 * @param value A value to write
	 */
	public void write(final String key, final float value) {
		writeValue("Float", key, Float.toString(value));
	}

	/**
	 * @since 2.0 
	 */
	public void write(final String key, final Font value) {
		writeValue("Font", key, FontProperty.toString(value));
	}

	/**
	 * Writes an {@code int} value.
	 *
	 * @param key the configuration key
	 * @param value the value to write
	 *
	 * @since 3.8.3
	 */
	public void write(final String key, final int value) {
		writeValue("Integer", key, Integer.toString(value));
	}

	/**
	 * Writes a @c long value.
	 * @param key A configuration key
	 * @param value A value to write
	 */
	public void write(final String key, final long value) {
		writeValue("Integer", key, Long.toString(value));
	}

	/**
	 * @since 3.8.3
	 */
	public void write(final String key, final Point value) {
		write(key + ".x", value.x);
		write(key + ".y", value.y);
	}

	/**
	 * @since 2.4
	 */
	public void write(final String key, final Property<?> p) {
		if (p == null)
			return;

		try {
			p.write(this, key);
		}
		catch (UnsupportedOperationException exception) {
			synchronized (this) {
				log.errorFormat("Cannot write unsupported %s property: %s=%s (%s)", p.getClass().getName(), key, p, path);
			}
		}
	}

	/**
	 * Writes a @c String value.
	 * @param key A configuration key
	 * @param value A value to write
	 */
	public void write(final String key, final String value) {
		writeValue("String", key, value);
	}

	/**
	 * Writes a @c Date value.
	 * The date is stored as the @c long type.
	 * @param key A configuration key
	 * @param value A value to write
	 *
	 * @since 2.0
	 */
	public void writeDate(final String key, final long value) {
		writeValue("Date", key, Long.toString(value));
	}

	/**
	 * @since 4.6
	 */
	public void writeProperties(final Object object) {
		validateObject(object);
		write(null, object);
	}

	/**
	 * @since 4.6
	 */
	public void writeStaticProperties(final Class<?> clazz) {
		write(clazz, null);
	}

	public void writeValue(final String key, final String value) {
		writeValue(null, key, value);
	}
	
	public synchronized void writeValue(final String prefix, final String key, final String value) {
		if (readOnly || (properties == null))
			return;

		if (key == null) {
			log.errorFormat("key == null (%s)", path);

			return;
		}

		String k = (prefix == null) ? key : (prefix + '.' + key);

		try {
			String old = properties.getProperty(k, null);
			if (!Objects.equals(old, value)) {
				checkPermission(k, Permission.WRITE_ACTION);
				if (value == null) {
					properties.remove(k);
				}
				else {
					properties.setProperty(k, value);
				}
				//log.debugFormat("change: KEY=\"%s\" OLD=\"%s\" NEW=\"%s\"", k, old, value);
				modified = true;
			}
/*
			else {
				log.debugFormat("no change: KEY=\"%s\" OLD=\"%s\" NEW=\"%s\", PATH=\"%s\"", k, old, value, path);
			}
*/
		}
		catch (NullPointerException exception) {
			MLogger.exception(exception);
		}
	}
	
	// protected
	
	/**
	 * @since 2.4
	 */
	protected void checkPermission(final String name, final String actions) {
		if (flags.isSet(DEFAULT)) {
			SecurityManager sm = System.getSecurityManager();
			if (sm != null)
				sm.checkPermission(new Config.Permission(name, actions));
		}
	}

	// private
	
	private static MProperties getGlobalDefaults() {
		File file;
		if (OS.isUnix())
			file = new File("/etc/makagiga/makagiga.properties");
		else
			file = new File(FS.getBaseDir(), "makagiga.properties"); // example: C:\Program Files\Makagiga
		
		if (!file.exists())
			return null;
		
		MProperties defaults = new MProperties();
		try {
			MLogger.info("core", "Using \"%s\" as default settings", file);
			defaults.loadUTF8(file);
		
			return defaults;
		}
		catch (IOException exception) {
			MLogger.exception(exception);
			
			return null;
		}
	}

	private String getKey(final Field field) {
		ConfigEntry configEntry = field.getAnnotation(ConfigEntry.class);
		if (configEntry != null) {
			if (configEntry.platform())
				return configEntry.value() + '@' + OS.getInternalName();

			return configEntry.value();
		}

		return null;
	}
	
	private void validateObject(final Object object) {
		if (object instanceof Class<?>)
			MLogger.error("core", "Object instance expected instead of: %s", object);
	}

	// package
	
	static void init() {
		langKey = ('[' + Locale.getDefault(Locale.Category.DISPLAY).getLanguage() + ']');
	}

	// public classes

	/**
	 * @since 2.0
	 */
	@FunctionalInterface
	public static interface GlobalEntry {
		
		// public
		
		/**
		 * Returns a config key used to read/write the global configuration.
		 *
		 * @param key The base config key
		 */
		public String getGlobalEntry(final String key);
		
	}

	/**
	 * @since 3.0
	 */
	public static final class IntInfo {
		
		// private
		
		private final int max;
		private final int min;
		
		// public
		
		public IntInfo(final int min, final int max) {
			this.min = min;
			this.max = max;
		}
		
		public int getMaximum() { return max; }
		
		public int getMinimum() { return min; }

	}
		
	/**
	 * @since 3.0
	 */
	@FunctionalInterface
	public static interface IntRange {
		
		// public
		
		public IntInfo getIntInfo();
		
	}
	
	/**
	 * @since 4.4
	 */
	public static class ListReader<T> extends ListSupport {
	
		// private
		
		private int currentIndex;

		// public

		@Obsolete
		public ListReader(final Config config, final String keyPrefix) {
			this(config, keyPrefix, 1);
		}

		@Obsolete
		public ListReader(final Config config, final String keyPrefix, final int startIndex) {
			super(config, keyPrefix, startIndex);
		}

		@Override
		public int getCurrentIndex() { return currentIndex; }

		@Obsolete
		public List<T> read() {
			return read(null);
		}

		/**
		 * @since 5.0
		 */
		public List<T> read(final Supplier<T> itemReader) {
			int count = getConfig().readInt(getKeyPrefix() + ".count", 0, 0, Integer.MAX_VALUE);
			MArrayList<T> result = new MArrayList<>(count);
			
			if (count == 0)
				return result;
			
			this.currentIndex = getStartIndex();
			for (int i = 0; i < count; i++) {
				T item = (itemReader != null) ? itemReader.get() : readItem();
				if (item != null) {
					result.add(item);
					currentIndex++;
				}
			}
			
			return result;
		}
		
		@Obsolete
		public T readItem() { return null; }

	}
	
	/**
	 * @since 4.4
	 */
	public static class ListWriter<T> extends ListSupport {
	
		// private
	
		private int currentIndex;
	
		// public
		
		@Obsolete
		public ListWriter(final Config config, final String keyPrefix) {
			this(config, keyPrefix, 1);
		}
		
		@Obsolete
		public ListWriter(final Config config, final String keyPrefix, final int startIndex) {
			super(config, keyPrefix, startIndex);
		}
		
		/**
		 * @deprecated Since 4.10
		 */
		@Deprecated
		public void clean() { }
		
		@Override
		public int getCurrentIndex() { return currentIndex; }
		
		public void removeAll(final String... names) {
			Config config = getConfig();
			String prefix =
				"(Boolean|Color|Date|Double|Enum|Float|Font|Integer|String)" +
				Pattern.quote('.' + getKeyPrefix() + '.');
			for (String i : names)
				config.removeAllValues(Pattern.compile(prefix + Pattern.quote(i + '.') + ".+"));
		}
		
		@Obsolete
		public void write(final Iterable<? extends T> iterable) {
			write(iterable, null);
		}
		
		/**
		 * @since 5.0
		 */
		public void write(final Iterable<? extends T> iterable, final Function<? super T, Boolean> itemWriter) {
			Iterator<? extends T> it = iterable.iterator();
			Config config = getConfig();

			if (!it.hasNext()) {
				clean();
				config.write(getKeyPrefix() + ".count", 0);
				
				return;
			}
			
			int count = 0;
			this.currentIndex = getStartIndex();
			while (it.hasNext()) {
				T i = it.next();
				if (((itemWriter != null) && itemWriter.apply(i)) || writeItem(i)) {
					count++;
					currentIndex++;
				}
			}
			
			config.write(getKeyPrefix() + ".count", count);
		}
		
		@Obsolete
		public boolean writeItem(final T item) { return false; }
	
	}

	/**
	 * @since 2.4
	 */
	public static final class Permission extends MPermission {
		
		// public

		public static final String GET_DEFAULT_ACTION = "get-default";
		public static final String READ_ACTION = "read";
		public static final String WRITE_ACTION = "write";
		
		// private
		
		private Permission(final String name, final String actions) {
			super(
				Objects.toString(name, "NULL"),
				ThreatLevel.MEDIUM,
				"Global Configuration File"
			);
			setActions(actions);
		}
		
	}
	
	// private classes
	
	private static abstract class ListSupport {

		// private

		private final Config config;
		private final int startIndex;
		private final String keyPrefix;
		
		// public
		
		public Config getConfig() { return config; }
		
		public abstract int getCurrentIndex();
		
		public String getKeyPrefix() { return keyPrefix; }
		
		public int getStartIndex() { return startIndex; }

		public String itemKey(final String name) {
			return keyPrefix + '.' + name + '.' + getCurrentIndex();
		}

		// protected
		
		protected ListSupport(final Config config, final String keyPrefix, final int startIndex) {
			this.config = Objects.requireNonNull(config);
			this.keyPrefix = TK.checkNullOrEmpty(keyPrefix);
			this.startIndex = startIndex;
		}
	
	}

}
