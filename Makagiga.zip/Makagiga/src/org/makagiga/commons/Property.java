// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Color;
import java.awt.Font;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.ParseException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.security.MPermission;

/**
 * A property.
 *
 * @mg.example
 * <pre class="brush: java">
 * public final Property&lt;URI&gt; homePage = new Property&lt;&gt;();
 * ...
 * homePage.set(URI.create("http://example.com/"));
 * ...
 * System.out.println("Opening " + homePage);
 * java.awt.Desktop.getDesktop().browse(homePage.get());
 * </pre>
 *
 * @see BeanProperty
 * @see BooleanProperty
 * @see ColorProperty
 * @see DateProperty
 * @see DoubleProperty
 * @see EnumProperty
 * @see FloatProperty
 * @see FontProperty
 * @see IntegerProperty
 * @see NumberProperty
 * @see StringProperty
 * @see VersionProperty
 */
public class Property<T>
implements
	Cloneable,
	Comparable<Property<T>>,
	Serializable,
	Supplier<T>
{
	private static final long serialVersionUID = 2380920075570387681L;
	
	// public
	
	/**
	 * @since 4.0
	 */
	public static final int READ_ONLY = 1;

	/**
	 * @since 4.0
	 */
	public static final int SECURE_READ = 1 << 1;

	/**
	 * @since 4.0
	 */
	public static final int SECURE_WRITE = 1 << 2;

	/**
	 * @since 4.0
	 */
	public static final int SECURE_ALL = SECURE_READ | SECURE_WRITE;

	/**
	 * Throw {@code NullPointerException} if <i>value</i> or <i>default value</i> is {@code null}.
	 *
	 * @since 4.2
	 */
	public static final int NON_NULL = 1 << 3;

	/**
	 * @since 4.6
	 */
	public static final int PLATFORM = 1 << 4;

	/**
	 * @since 2.4
	 */
	public static final String DEFAULT_VALUE_PROPERTY = "defaultValue";

	/**
	 * @since 2.4
	 */
	public static final String VALUE_PROPERTY = "value";

	// private
	
	private final int options;
	private static final Map<Class<?>, Map<Field, Property<?>>> listCache = new ConcurrentHashMap<>();
	private PropertyChangeSupport propertyChangeSupport;
	private static final Property.Permission READ_PERMISSION = new Property.Permission("read");
	private static final Property.Permission WRITE_PERMISSION = new Property.Permission("write");
	transient private T defaultValue;
	transient private T value;

	// public

	/**
	 * Constructs a property with {@code null} value.
	 */
	public Property() {
		this(null, 0);
	}

	/**
	 * Constructs a property with @p value (can be @c null).
	 */
	public Property(final T value) {
		this(value, 0);
	}

	/**
	 * @since 4.0
	 */
	public Property(final T value, final int options) {
		this.options = options;
		
		checkNonNull(value);
		
		this.value = value;
		defaultValue = value;
	}
	
	/**
	 * @since 5.0
	 */
	public void addChangeListener(final ChangeListener<T> l) {
		addPropertyChangeListener(l);
	}

	/**
	 * @since 2.4
	 */
	public void addPropertyChangeListener(final PropertyChangeListener l) {
		checkSecureRead();
		checkSecureWrite();

		if (l != null) {
			if (propertyChangeSupport == null)
				propertyChangeSupport = new PropertyChangeSupport(this);
			propertyChangeSupport.addPropertyChangeListener(l);
		}
	}

	/**
	 * @since 2.4
	 */
	public PropertyChangeListener[] getPropertyChangeListeners() {
		checkSecureRead();

		if (propertyChangeSupport == null)
			return TK.EMPTY_PROPERTY_CHANGE_LISTENER_ARRAY;

		return propertyChangeSupport.getPropertyChangeListeners();
	}

	/**
	 * @since 2.4
	 */
	public void removePropertyChangeListener(final PropertyChangeListener l) {
		checkSecureWrite();

		if (propertyChangeSupport != null)
			propertyChangeSupport.removePropertyChangeListener(l);
	}

	/**
	 * Returns {@code true} if value returned by {@link #get()} equals {@code o}.
	 *
	 * @since 2.0
	 * 
	 * @see #equals(Object)
	 */
	public boolean equalsValue(final T o) {
		return Objects.equals(get(), o);
	}
	
	/**
	 * @since 4.6
	 */
	public int getOptions() { return options; }
	
	/**
	 * @since 3.0
	 */
	public static String getTypeAsString(final Property<?> p) {
		Class<?> type = p.getType();
					
		if (type != null)
			return type.getSimpleName();
		
		if (p instanceof EnumProperty<?>)
			return "Enum";
				
		return "?";
	}

	/**
	 * @since 5.2
	 */
	public void ifPresent(final Consumer<? super T> consumer) {
		T value = get();
		if (value != null)
			consumer.accept(value);
	}
	
	/**
	 * @since 4.0
	 */
	public boolean isBooleanType() {
		return Boolean.class.equals(getType()) || boolean.class.equals(getType());
	}

	/**
	 * @since 4.0
	 */
	public boolean isColorType() {
		return Color.class.isAssignableFrom(getType());
	}

	/**
	 * @since 4.0
	 */
	public boolean isDateType() {
		return java.util.Date.class.isAssignableFrom(getType());
	}

	/**
	 * @since 4.0
	 */
	public boolean isDoubleType() {
		return Double.class.equals(getType()) || double.class.equals(getType());
	}

	/**
	 * @since 4.0
	 */
	public boolean isEnumType() {
		return Enum.class.isAssignableFrom(getType());
	}

	/**
	 * @since 4.0
	 */
	public boolean isFloatType() {
		return Float.class.equals(getType()) || float.class.equals(getType());
	}

	/**
	 * @since 4.0
	 */
	public boolean isFontType() {
		return Font.class.isAssignableFrom(getType());
	}

	/**
	 * @since 4.0
	 */
	public boolean isIntegerType() {
		return Integer.class.equals(getType()) || int.class.equals(getType());
	}
	
	/**
	 * Returns {@code true} if value is {@code null}.
	 *
	 * @see #isPresent()
	 */
	public boolean isNull() {
		return get() == null;
	}

	/**
	 * @since 4.4
	 */
	public boolean isOption(final int option) {
		return (this.options & option) != 0;
	}

	/**
	 * Returns {@code true} if value is non-{@code null}.
	 *
	 * @see #isNull()
	 *
	 * @since 4.6
	 */
	public boolean isPresent() {
		return get() != null;
	}

	public boolean isReadOnly() {
		return (options & READ_ONLY) != 0;
	}

	/**
	 * @since 4.0
	 */
	public boolean isSecure(final int options) {
		return (this.options & options) != 0;
	}

	/**
	 * @since 4.0
	 */
	public boolean isStringType() {
		return String.class.equals(getType());
	}

	/**
	 * @since 2.0
	 */
	public static Map<Field, Property<?>> listStatic(final Class<?> clazz) throws IllegalAccessException {
		return list(clazz, null);
	}

	/**
	 * @since 2.0
	 */
	public static Map<Field, Property<?>> list(final Object object) throws IllegalAccessException {
		return list(object.getClass(), object);
	}
	
	// Cloneable

	/**
	 * Returns a "deep" copy of this property.
	 *
	 * @since 2.0
	 */
	@Obsolete
	@Override
	public Object clone() {
		try {
			return super.clone();
		}
		catch (CloneNotSupportedException exception) {
			throw new WTFError(exception);
		}
	}
	
	// Comparable

	/**
	 * Compares this property with {@code another} property by its value.
	 *
	 * @throws UnsupportedOperationException If value does not implement {@code Comparable} interface
	 * 
	 * @since 2.0
	 */
	@Override
	@SuppressWarnings("unchecked")
	public int compareTo(final Property<T> another) {
		T o = get();

		if (o instanceof Comparable<?>)
			return Comparable.class.cast(o).compareTo(another.get());

		throw new UnsupportedOperationException("Property value does not implement \"Comparable\" interface");
	}
	
	// standard methods

	/**
	 * Returns {@code true} if this property equals {@code o}.
	 * The default implementation compares the two values returned by {@link #get()}.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * StringProperty a = new StringProperty("A");
	 * StringProperty b = new StringProperty("B");
	 * assert !a.equals(null);
	 * assert a.equals(a);
	 * assert !a.equals(b);
	 * assert !a.equals("A");
	 * </pre>
	 * 
	 * @see #equalsValue(Object)
	 */
	@Override
	public boolean equals(final Object o) {
		// no security required
		if (o == this)
			return true;

		// no security required
		if (!(o instanceof Property<?>))
			return false;

		// security provided by "equalsValue" and "get"
		@SuppressWarnings("unchecked")
		Property<T> property = (Property<T>)o;
		
		return equalsValue(property.get());
	}

	/**
	 * Returns the value of this property.
	 *
	 * @see #get(Object)
	 */
	@Override
	public T get() {
		checkSecureRead();

		return value;
	}

	/**
	 * Returns the value of this property.
	 *
	 * @return {@code returnIfNull} if value of this property is {@code null}.
	 *
	 * @see #get()
	 * @see #isNull()
	 * @see #isPresent()
	 *
	 * @since 4.6
	 */
	public T get(final T returnIfNull) {
		T result = get();

		return (result != null) ? result : returnIfNull;
	}

	/**
	 * Sets value of this property to @p value.
	 */
	public boolean set(final T value) {
		if (isReadOnly())
			return false;

		checkNonNull(value);
		checkSecureWrite();
	
		T old = this.value;
		this.value = value;
		if ((propertyChangeSupport != null) && !Objects.equals(old, this.value))
			propertyChangeSupport.firePropertyChange(VALUE_PROPERTY, old, this.value);

		return true;
	}

	/**
	 * Returns the default value.
	 */
	public T getDefaultValue() {
		checkSecureRead();

		return defaultValue;
	}

	/**
	 * Returns @c true if value of this property is set to the default value.
	 */
	public boolean isDefaultValue() {
		return equalsValue(getDefaultValue());
	}

	/**
	 * Sets the default value to @p value.
	 */
	public boolean setDefaultValue(final T value) {
		if (isReadOnly())
			return false;

		checkNonNull(value);
		checkSecureWrite();
	
		T old = defaultValue;
		defaultValue = value;
		if ((propertyChangeSupport != null) && !Objects.equals(old, defaultValue))
			propertyChangeSupport.firePropertyChange(DEFAULT_VALUE_PROPERTY, old, defaultValue);

		return true;
	}

	/**
	 * Returns the type of {@code this} property value.
	 *
	 * @return {@code null} if the type is undefined
	 *
	 * @mg.default
	 * {@code null}
	 *
	 * @since 2.4
	 */
	public Class<T> getType() { return null; }

	/**
	 * Returns a hash code for this property.
	 *
	 * @return {@code 0} if value is {@code null}
	 */
	@Override
	public int hashCode() {
		return Objects.hashCode(get());
	}

	/**
	 * Converts a @c String @p value to the property @c T type.
	 *
	 * @throws ParseException If parse failed
	 * @throws UnsupportedOperationException If property does not support string parsing (default)
	 */
	public void parse(final String value) throws ParseException {
		throw new UnsupportedOperationException();
	}

	/**
	 * @since 4.0
	 */
	public void read(final Config config, final String key) {
		throw new UnsupportedOperationException();
	}

	/**
	 * @since 4.0
	 */
	public void write(final Config config, final String key) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Sets the current value to {@link #getDefaultValue()}.
	 *
	 * @since 2.4
	 */
	public boolean reset() {
		return set(getDefaultValue());
	}

	/**
	 * @since 5.0
	 */
	public Optional<T> toOptional() {
		return Optional.ofNullable(get());
	}

	/**
	 * Returns a {@code String} representation of this property.
	 *
	 * @return An empty {@code String} if value of this property is {@code null}
	 */
	@Override
	public String toString() {
		return Objects.toString(get(), "");
	}
	
	// protected
	
	/**
	 * @since 4.0
	 */
	protected PropertyChangeSupport getPropertyChangeSupport() { return propertyChangeSupport; }

	// private

	private void checkNonNull(final T o) {
		if ((o == null) && ((options & NON_NULL) != 0))
			throw new NullPointerException("Null property value");
	}

	private void checkSecureRead() {
		if (!isSecure(SECURE_READ))
			return;

		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(READ_PERMISSION);
	}

	private void checkSecureWrite() {
		if (!isSecure(SECURE_WRITE))
			return;

		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(WRITE_PERMISSION);
	}
	
	private static Map<Field, Property<?>> list(final Class<?> clazz, final Object object) throws IllegalAccessException {
		boolean statik = (object == null);
		Map<Field, Property<?>> result;
		
		if (statik) {
			result = listCache.get(clazz);

			if (result != null)
				return result;
		}
	
		result = new HashMap<>();
		for (Field i : clazz.getFields()) {
			if (Modifier.isPublic(i.getModifiers())) {
				if (!Modifier.isFinal(i.getModifiers()) && Property.class.isAssignableFrom(i.getType()))
					MLogger.warning("core", "\"%s\" property in class \"%s\" should be declared as \"final\"", i.getName(), clazz.getName());

				Object fieldValue = i.get(object);
				if (fieldValue instanceof Property<?>)
					result.put(i, (Property<?>)fieldValue);
			}
		}
		
		if (statik) {
			result = Collections.unmodifiableMap(result);
			listCache.put(clazz, result);
		}
		
		return result;
	}

	// Serializable

	@SuppressWarnings("unchecked")
	private void readObject(final ObjectInputStream input) throws ClassNotFoundException, IOException {
		input.defaultReadObject();
		Object o;
		
		o = TK.deserialize(input, "defaultValue");
		if (o != null)
			setDefaultValue((T)o);
		
		o = TK.deserialize(input, "value");
		if (o != null)
			set((T)o);
	}

	private void writeObject(final ObjectOutputStream output) throws IOException {
		checkSecureRead();

		output.defaultWriteObject();
		TK.serialize(output, "defaultValue", getDefaultValue());
		TK.serialize(output, "value", get());
	}

	// public classes

	/**
	 * @since 5.0
	 */
	@FunctionalInterface
	public static interface ChangeListener<T> extends PropertyChangeListener {
	
		// public

		@Override
		@SuppressWarnings("unchecked")
		public default void propertyChange(final PropertyChangeEvent e) {
			if (Property.VALUE_PROPERTY.equals(e.getPropertyName()))
				valueChange(e, (T)e.getNewValue());
		}

		public void valueChange(final PropertyChangeEvent e, final T value);

	}

	/**
	 * @since 4.0
	 */
	public static final class Permission extends MPermission {

		// private

		private Permission(final String name) {
			super(name, ThreatLevel.MEDIUM, "Configuration/Property");
		}

	}

	/**
	 * @since 3.8.8
	 */
	@Obsolete
	public static abstract class ValueChangeListener<T> implements PropertyChangeListener {

		// private

		private transient Property<? extends T> source;
		
		// public

		public ValueChangeListener() { }

		@Override
		@SuppressWarnings("unchecked")
		public void propertyChange(final PropertyChangeEvent e) {
			if (Property.VALUE_PROPERTY.equals(e.getPropertyName())) {
				try {
					source = (Property<? extends T>)e.getSource();
					onChange((T)e.getNewValue());
				}
				finally {
					source = null;
				}
			}
		}

		// protected

		protected Property<? extends T> getSource() { return source; }

		protected abstract void onChange(final T property);
		
	}

}
