// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.help;

import static org.makagiga.commons.UI.i18n;

import static java.awt.event.KeyEvent.*;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import javax.swing.Action;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import org.makagiga.commons.Args;
import org.makagiga.commons.CollectionMap;
import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.FS;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.OS;
import org.makagiga.commons.TK;
import org.makagiga.commons.Tuple;
import org.makagiga.commons.UI;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMenuBar;
import org.makagiga.commons.swing.MWhatsThis;
import org.makagiga.commons.swing.MainView;
import org.makagiga.commons.swing.Mnemonic;
import org.makagiga.commons.swing.MouseGestures;

/**
 * Generates a HTML help from the UI.
 *
 * @since 2.0, 4.0 (org.makagiga.commons.help.HelpGenerator name)
 */
public class HelpGenerator {

	// private

	private boolean highlightRow;
	private final CollectionMap<String, Shortcut> shortcutInfo = new CollectionMap<>(
		CollectionMap.MapType.LINKED_HASH_MAP,
		CollectionMap.CollectionType.TREE_SET
	);
	private HTMLBuilder builder;
	private final MArrayList<MMenu> excludeMenus = new MArrayList<>();
	private final MArrayList<Tuple.Two<URI, String>> links = new MArrayList<>();
	private MMenuBar menuBar;
	private final String menuForeground;
	private final String menuItemBackground1;
	private final String menuItemBackground2;
	private final String menuItemForeground;
	private Path indexFile;
	private Path outputDir;
	private String shortcutGroup = "";
	private String title;

	// public
	
	public HelpGenerator() {
		title = MApplication.getTitle();
	
		menuForeground = ColorProperty.toString(MColor.BLACK);
		Color bg = MColor.WHITE;
		menuItemBackground1 = ColorProperty.toString(bg);
		menuItemBackground2 = ColorProperty.toString(UI.getDarker(bg, Color.WHITE));
		menuItemForeground = ColorProperty.toString(MColor.BLACK);
	}
	
	/**
	 * @since 4.0
	 */
	public void addCommonShortcuts() {
		addShortcut(i18n("Common Keyboard Shortcuts"));

		for (Action i : MainView.getBindList()) {
			if (i instanceof MAction) {
				MAction a = (MAction)i;
				
				KeyStroke ks = a.getAcceleratorKey();
				if (ks != null)
					addShortcut(a.getName(), ks.getKeyCode(), ks.getModifiers());

				ks = a.getAlternateAcceleratorKey();
				if (ks != null)
					addShortcut(a.getName(), ks.getKeyCode(), ks.getModifiers());
			}
		}

		int[] tabKeys = Mnemonic.getTabKeys();
		addShortcut(
			i18n("Change active tab ({0}..{1})", UI.toString(tabKeys[0], ALT_MASK), UI.toString(tabKeys[tabKeys.length - 1], ALT_MASK)),
			VK_1, ALT_MASK
		);
		addShortcut(i18n("Open selected link"), VK_SPACE, CTRL_MASK);
		addShortcut(MActionInfo.RENAME.getDialogTitle(), MActionInfo.RENAME.getKeyCode());
		addShortcut(i18n("Focus table header/splitter bar (press Tab to cancel)"), VK_F8);
		addShortcut(i18n("Activate context menu"), VK_CONTEXT_MENU);
		addShortcut(i18n("Activate context menu"), VK_F10, SHIFT_MASK);
		addShortcut(i18n("Show tool tip text"), VK_F1, CTRL_MASK);

		for (MWhatsThis.Info i : MWhatsThis.getAll(MainView.getWindow())) {
			KeyStroke ks = i.getKeyStroke();
			if (ks != null)
				addShortcut(i.getText(), ks.getKeyCode(), ks.getModifiers());
		}

		addShortcut(i18n("Text"));

		addShortcut(i18n("Move selected text"), VK_UP, CTRL_MASK + SHIFT_MASK);
		addShortcut(i18n("Move selected text"), VK_DOWN, CTRL_MASK + SHIFT_MASK);

		addShortcut(i18n("Scroll up ({0})", i18n("without selection change")), VK_UP, CTRL_MASK);
		addShortcut(i18n("Scroll down ({0})", i18n("without selection change")), VK_DOWN, CTRL_MASK);
		
		addShortcut(i18n("Change layout (right-to-left)"), VK_O, CTRL_MASK + SHIFT_MASK);
	}
	
	public void addExcludeMenu(final MMenu menu) {
		excludeMenus.add(menu);
	}
	
	/**
	 * @since 4.6
	 */
	public void addLink(final String description, final URI uri) {
		links.add(Tuple.of(uri, description));
	}

	/**
	 * Adds shortcut help.
	 * @param description A shortcut description
	 */
	public void addShortcut(final String description) {
		shortcutGroup = description;
	}

	/**
	 * Adds shortcut help.
	 * @param description A shortcut description
	 * @param keyCode A shortcut key code
	 */
	public void addShortcut(final String description, final int keyCode) {
		addShortcut(description, keyCode, 0);
	}

	/**
	 * Adds shortcut help.
	 * @param description A shortcut description
	 * @param keyCode A shortcut key code
	 * @param modifiers A shortcut modifiers
	 */
	public void addShortcut(final String description, final int keyCode, final int modifiers) {
		shortcutInfo.add(shortcutGroup, new Shortcut(description, keyCode, modifiers));
	}

	/**
	 * @since 4.2
	 */
	public void addShortcut(final String description, final String trigger) {
		shortcutInfo.add(shortcutGroup, new Shortcut(description, trigger));
	}

	/**
	 * Starts the HTML generator.
	 */
	public void generate() throws IOException {
		if (outputDir == null)
			throw new IllegalStateException("Output directory not set");
	
		processActions(); // always rebuild
		
		builder = new HTMLBuilder(HTMLBuilder.HTML_TRANSITIONAL);
		beginDocument(title);

		if (!shortcutInfo.isEmpty())
			addIndexLink("shortcuts.html", i18n("Keyboard/Mouse Shortcuts"));
		if (menuBar != null)
			addIndexLink("actions.html", i18n("Actions"));

		addIndexLink("mousegestures.html", i18n("Mouse Gestures"));
		addIndexLink("cli.html", i18n("Command Line Options"));

		addSeparator();

		addIndexLink(getReadmeURI().toString(), "README");
		
		if (!links.isEmpty()) {
			addSeparator();
			links.forEach(tuple ->
				tuple.accept((uri, description) -> addIndexLink(uri.toString(), description))
			);
		}
			
		builder.endDoc();
		builder.write(indexFile);

		generateShortcuts(i18n("Keyboard Shortcuts"))
			.write(outputDir.resolve("shortcuts.html"));
		processCommandLineOptions();
		processMouseGestures();
	}
	
	/**
	 * @since 4.0
	 */
	public Path getIndexFile() { return indexFile; }

	/**
	 * Sets menu bar to @p value.
	 */
	public void setMenuBar(final MMenuBar value) { menuBar = value; }

	/**
	 * Sets the output directory to {@code value}.
	 *
	 * @since 4.0
	 */
	public void setOutputDirectory(final Path value) {
		outputDir = Objects.requireNonNull(value);
		indexFile = outputDir.resolve("index.html");
	}

	/**
	 * Sets help title to @p value.
	 */
	public void setTitle(final String value) { title = value; }

	// private
	
	private void addIndexLink(final String url, final String text) {
		builder.doubleTag(
			"p",
			HTMLBuilder.createLink(url, text),
			"class", "indexitem"
		);
	}

	private void addSeparator() {
		builder.singleTag("hr");
	}
	
	private void beginDocument(final String title) {
		builder.beginHTML(title, HTMLBuilder.UTF_8);
		builder.beginStyle();

		builder.beginRule(".table-value");
			builder.addAttr("font-weight", "bold");
		builder.endRule();

		builder.beginRule("a");
			builder.addAttr("color", MColor.getLinkForeground(null));
		builder.endRule();

		builder.beginRule("body");
			builder.addAttr("background-color", "white");
			builder.addAttr("color", "black");
			builder.addAttr("margin", "0px");
			builder.addAttr("padding", "0px");
		builder.endRule();

		builder.beginRule("div.key");
			builder.addAttr("background-color", "#eeeeee");
			builder.addAttr("color", Color.BLACK);

			builder.addAttr("font-family", Font.DIALOG);
			builder.addAttr("font-weight", "bold");

			builder.addAttr("border-top", "1px solid white");
			builder.addAttr("border-left", "1px solid white");
			builder.addAttr("border-bottom", "1px solid gray");
			builder.addAttr("border-right", "1px solid gray");

			builder.addAttr("padding-top", "2px");
			builder.addAttr("padding-bottom", "2px");
			builder.addAttr("padding-left", "4px");
			builder.addAttr("padding-right", "4px");
			builder.addAttr("white-space", "nowrap");
			// HACK: force min width
			builder.addAttr("width", "1%");
		builder.endRule();

		builder.beginRule("p.indexitem");
			builder.addAttr("font-size", "larger");
			builder.addAttr("margin", "5px");
			builder.addAttr("padding", "0px");
		builder.endRule();

		builder.beginRule("table");
			builder.addAttr("border", "0px solid black");
			builder.addAttr("border-spacing", "0px");
			builder.addAttr("margin", "10px");
			builder.addAttr("width", "80%");
		builder.endRule();

		builder.beginRule("td.header");
			builder.addAttr("font-size", "larger");
			builder.addAttr("font-weight", "bold");
			builder.addAttr("padding-top", "5px");
			builder.addAttr("padding-bottom", "5px");
		builder.endRule();

		builder.endStyle();
		builder.beginDoc();
	}

	private File findReadmeFile(final String dir, final Locale locale) {
		String name = "README";
		if (locale != null)
			name += ("_" + locale.getLanguage());
		name += ".html";
		File readmeFile = new File(dir, name);
		
		return readmeFile.exists() ? readmeFile : null;
	}

	private String getMenuItemStyle() {
		return String.format(
			"background-color: %s; color: %s",
			(highlightRow ? menuItemBackground1 : menuItemBackground2),
			menuItemForeground
		);
	}

	private String getMenuStyle() {
		return "color: " + menuForeground;
	}
	
	private URI getReadmeURI() {
		File readmeFile = null;

		if (!OS.isWebStart()) {
			String baseDir = FS.getBaseDir();
	
			// 1. check base directory (e.g. C:\Program Files\Makagiga)
			readmeFile = findReadmeFile(baseDir, null);

			// 1.1. Check "help" subdirectory (e.g. portable version)
			if (readmeFile == null)
				readmeFile = findReadmeFile(FS.makePath(baseDir, "help"), null);

			// 2. check installation directory
			if ((readmeFile == null) && OS.isLinux()) {
				String prefix = FS.getInstallPrefix("/usr");
				readmeFile = findReadmeFile(prefix + "/share/doc/makagiga-" + MApplication.getFileVersion(), null);
			}
		}

		// 3. find localized readme
		if (readmeFile != null) {
			String readmeDir = readmeFile.getParent();
			if (readmeDir != null) {
				File localizedReadmeFile = findReadmeFile(readmeDir, Locale.getDefault(Locale.Category.DISPLAY));
				if (localizedReadmeFile != null)
					readmeFile = localizedReadmeFile;
			}
		}

		// use local(ized) file
		if (readmeFile != null) {
			MLogger.debug("browser", "Using local README file: %s", readmeFile);
			
			return readmeFile.toPath().toUri();
		}
		// use file on the Internet (no localization here)
		else {
			String uri = MApplication.getResourceString("Application.x.documentation", null);
			if (uri == null) {
				uri = MApplication.getHomePage();
				if (!uri.endsWith("/"))
					uri += "/";
				uri += "README.html";
			}
			URI readmeURI = URI.create(uri);
			MLogger.debug("browser", "Using online README file: %s", readmeURI);
			
			return readmeURI;
		}
	}

	private void processActions() throws IOException {
		if (menuBar == null)
			return;

		builder = new HTMLBuilder(HTMLBuilder.HTML_TRANSITIONAL);
		beginDocument(i18n("Actions"));
		builder.beginTag("table");
		for (JMenu i : menuBar) {
			if ((i instanceof MMenu) && !excludeMenus.contains((MMenu)i))
				processMenu((MMenu)i, 1);
		}
		builder.endTag("table");
		builder.endDoc();
		builder.write(outputDir.resolve("actions.html"));
	}

	private void processCommandLineOptions() throws IOException {
		builder = new HTMLBuilder(HTMLBuilder.HTML_TRANSITIONAL);
		beginDocument(i18n("Command Line Options"));
		builder.beginTag("table");
		builder.beginTag(
			"tr",
			"style", getMenuStyle()
		);
		builder.doubleTag(
			"td",
			builder.escape(i18n("Command Line Options")),
			"class", "header",
			"colspan", 2
		);
		builder.endTag("tr");

		highlightRow = false;
		for (Map.Entry<String, String> i : Args.getAdded().entrySet()) {
			builder.beginTag("tr");
			builder.doubleTag(
				"td",
				builder.escape("--" + i.getKey()),
				"class", "table-value",
				"style", getMenuItemStyle() + "; font-family: " + UI.getMonospacedFontName()
			);
			builder.doubleTag(
				"td",
				builder.escape(i.getValue()),
				"style", getMenuItemStyle()
			);
			builder.endTag("tr");
			highlightRow = !highlightRow;
		}
		builder.endTag("table");
		builder.endDoc();
		builder.write(outputDir.resolve("cli.html"));
	}

	private void processMenu(final MMenu menu, final int level) throws IOException {
		if ((menu == null) || menu.isEmpty())
			return;

		builder.beginTag(
			"tr",
			"style", getMenuStyle()
		);
		// text
		builder.doubleTag(
			"td",
			builder.escape(menu.getText()),
			"class", "header",
			"colspan", 3
		);
		builder.endTag("tr");
		highlightRow = false;
		for (JMenuItem i : menu) {
			if (i instanceof MMenu) {
				if (!excludeMenus.contains((MMenu)i)) {
					processMenu((MMenu)i, level + 1);
				}
			}
			else if (i != null) {
				processMenuItem(i);
			}
		}

		// end of previous menu
		if (level > 1)
			builder.doubleTag("td", "<p></p>", "colspan", 3);
	}

	private void processMenuItem(final JMenuItem item) throws IOException {
		if (item == null)
			return;
		
		String text = item.getText();

		if (TK.isEmpty(text))
			return;

		Action swingAction = item.getAction();
		KeyStroke keyStroke = null;
		String description = null;
		if (swingAction instanceof MAction) {
			MAction action = (MAction)swingAction;
			description = action.getHelpText();
			if (description != null) {
				description = description.replace(UI.HTML_BEGIN, "");
				description = description.replace(UI.HTML_END, "");
			}
			keyStroke = action.getAcceleratorKey();
		}

		builder.beginTag(
			"tr",
			"style", getMenuItemStyle()
		);

		// key stroke

		builder.doubleTag(
			"td",
			(keyStroke == null) ? "" : createKey(UI.toString(keyStroke)),
			"class", "table-value"
		);

		// text

		builder.doubleTag("td", builder.escape(text));

		// description

		builder.doubleTag("td", description); // no escape

		builder.endTag("tr");
		highlightRow = !highlightRow;
	}
	
	private void processMouseGestures() throws IOException {
		MouseGestures mouseGestures = MainView.getWindow().getMouseGestures();

		highlightRow = false;
		builder = new HTMLBuilder(HTMLBuilder.HTML_TRANSITIONAL);
		beginDocument(i18n("Mouse Gestures"));
		builder.beginTag("table");
		builder.beginTag(
			"tr",
			"style", getMenuStyle()
		);
		builder.doubleTag(
			"td",
			builder.escape(i18n("Mouse Gestures (hold right mouse button and move)")),
			"class", "header",
			"colspan", 2
		);
		builder.endTag("tr");
		builder.beginTag("tr");
		builder.doubleTag(
			"td",
			builder.escape(i18n("Gesture")),
			"style", getMenuItemStyle() + "; font-weight: bold"
		);
		builder.doubleTag(
			"td",
			builder.escape(i18n("Description")),
			"style", getMenuItemStyle() + "; font-weight: bold"
		);
		builder.endTag("tr");
		highlightRow = true;
		
		for (Map.Entry<String, Action> i : mouseGestures.getMap().entrySet()) {
			String name = (String)i.getValue().getValue(Action.NAME); // uh

			builder.beginTag("tr");
			builder.doubleTag(
				"td",
				createKey(MouseGestures.toDisplayString(i.getKey())),
				"class", "table-value",
				"style", getMenuItemStyle()
			);
			builder.doubleTag(
				"td",
				builder.escape(name),
				"style", getMenuItemStyle()
			);
			builder.endTag("tr");
			highlightRow = !highlightRow;
		}
		builder.endTag("table");
		builder.endDoc();
		builder.write(outputDir.resolve("mousegestures.html"));
	}

	/**
	 * @since 4.8
	 */
	public HTMLBuilder generateShortcuts(final String title) { // public
		if (shortcutInfo.isEmpty())
			return null;

		highlightRow = false;
		builder = new HTMLBuilder(HTMLBuilder.HTML_TRANSITIONAL);
		beginDocument(title);
		builder.beginTag("table");
		for (Map.Entry<String, Collection<Shortcut>> e : shortcutInfo) {

			// title

			String t = e.getKey();
			if (!t.isEmpty()) {
				highlightRow = false;
				builder.beginTag(
					"tr",
					"style", getMenuStyle()
				);
				builder.doubleTag(
					"td",
					builder.escape(t),
					"class", "header",
					"colspan", 2
				);
				builder.endTag("tr");
			}

			// rows

			for (Shortcut i : e.getValue()) {
				if (!i.isValid())
					continue; // for

				builder.beginTag("tr");
				builder.doubleTag(
					"td",
					createKey(i.toString()),
					"class", "table-value",
					"style", getMenuItemStyle()
				);
				builder.doubleTag(
					"td",
					builder.escape(i.description),
					"style", getMenuItemStyle()
				);
				builder.endTag("tr");
				highlightRow = !highlightRow;
			}

		}
		builder.endTag("table");
		builder.endDoc();
		
		return builder;
	}

	// private
	
	private static String createKey(final String key) {
		return "<div class=\"key\">" + TK.escapeXML(key.replace("+", " + ")) + "</div>";
	}

	// private classes

	private static final class Shortcut implements Comparable<Shortcut> {

		// private

		private final int keyCode;
		private final int modifiers;
		private final String description;
		private final String trigger;

		// public

		@Override
		public boolean equals(final Object o) {
			if (this == o)
				return true;

			if ((o == null) || (this.getClass() != o.getClass()))
				return false;

			Shortcut other = (Shortcut)o;

			return
				(this.keyCode == other.keyCode) &&
				(this.modifiers == other.modifiers);
		}

		@Override
		public int hashCode() {
			return TK.hash(keyCode, modifiers);
		}

		@Override
		public String toString() { return trigger; }

		// Comparable

		@Override
		public int compareTo(final Shortcut o) {
			return this.trigger.compareTo(o.trigger);
		}

		// private

		private Shortcut(final String description, final int keyCode, final int modifiers) {
			this.description = description;
			this.keyCode = keyCode;
			this.modifiers = modifiers;

			trigger = isValid() ? UI.toString(keyCode, modifiers) : "";
		}
		
		private Shortcut(final String description, final String trigger) {
			this.description = description;
			this.keyCode = 0;
			this.modifiers = 0;

			this.trigger = trigger;
		}

		private boolean isValid() {
			return (keyCode != 0) || (modifiers != 0) || !trigger.isEmpty();
		}

	}

}
