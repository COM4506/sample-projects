// Copyright 2012 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.help;

import static org.makagiga.commons.UI.i18n;

import java.util.List;
import java.util.Objects;

import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.swing.MainView;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MWhatsThis;

/**
 * @since 4.2
 */
public class HelpMenu extends MMenu {

	// public

	public HelpMenu() {
		super(i18n("&Help"));
		setVisible(Kiosk.actionHelp.get());
		onInit();
		
		MMenu topicsMenu = new MMenu(i18n("Topics"));
		topicsMenu.onSelect(self -> {
			if (self.isEmpty()) {
				onInitTopics(self);
				self.addNoItemsInfo(self.isEmpty());
			}
		} );
		add(topicsMenu);
	
		if (Kiosk.actionWhatsThis.get())
			add(new MWhatsThis.Action(MainView.getWindow()));
		addSeparator(false);
		add(new MApplication.AboutAction());
	}

	// protected
	
	@InvokedFromConstructor
	protected void onInit() { }
	
	protected void onInitTopics(final MMenu topics) { }
	
	// public classes

	public static class HowToAction extends MAction {
	
		// public
		
		public HowToAction(final String text, final String iconName, final List<?> steps) {
			super(text, iconName);

			if (steps != null) {
				HTMLBuilder html = HTMLBuilder.newSwingDoc();
				for (Object i : steps) {
					html
						.append(" <b>-&gt;</b> <i>")
						.appendEscaped(Objects.toString(i))
						.append("</i>");
				}
				html.endSwingDoc();
				setHelpText(html.toString());
			}
		}
	
	}
	
}
