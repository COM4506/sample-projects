// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.help;

import java.net.URI;
import java.util.List;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MLinkAction;
import org.makagiga.commons.swing.MMenu;

/**
 * @since 5.0
 */
public class HelpButton extends MButton {

	// private
	
	private final MArrayList<HelpContext> helpContextList = new MArrayList<>();

	// public

	public HelpButton() {
		if (UI.isMac()) {
			setText("?");
			putClientProperty("JButton.buttonType", "help");
		}
		else if (UI.isQuaqua()) {
			setText("?");
			putClientProperty("Quaqua.Button.style", "help");
		}
		else {
			if (UI.buttonIcons.get())
				setIconName(MActionInfo.HELP.getIconName());
			else
				setText("?");
		}
		
		updateProperties();
	}
	
	public void addHelpContext(final HelpContext helpContext) {
		helpContextList.add(helpContext);

		updateProperties();
	}

	public void removeHelpContext(final HelpContext helpContext) {
		helpContextList.remove(helpContext);

		updateProperties();
	}

	public HelpContext getHelpContext() {
		return helpContextList.isEmpty() ? null : helpContextList.getFirst();
	}

	public void setHelpContext(final HelpContext helpContext) {
		helpContextList.clear();
		if (helpContext != null)
			helpContextList.add(helpContext);

		updateProperties();
	}

	public List<HelpContext> getHelpContextList() { return helpContextList; }

	// protected
	
	@Override
	protected void onClick() {
		Help.show(this, helpContextList.getFirst());
	}
	
	@Override
	protected MMenu onPopupMenu() {
		MMenu menu = new MMenu();
		for (HelpContext i : helpContextList) {
			if (i.getType() == HelpContext.Type.URI) {
				URI uri = URI.create(i.getURI());
				String text = i.getDisplayName();

				if (text.isEmpty())
					menu.add(new MLinkAction(uri));
				else
					menu.add(new MLinkAction(uri, text));
			}
			else {
				menu.add(new MAction(i.toString(), action -> Help.show(this, i)));
			}
		}
		
		return menu;
	}
	
	// private
	
	private void updateProperties() {
		HelpContext primaryHelpContext = getHelpContext();
		if (primaryHelpContext == null) {
			setPopupMenuEnabled(false);
			setToolTipText(MActionInfo.HELP.getText());
		}
		else if ((helpContextList.size() == 1) && (primaryHelpContext.getType() == HelpContext.Type.URI)) {
			setPopupMenuEnabled(false);
			setToolTipText(UI.getLinkToolTipText(primaryHelpContext.getURI()));
		}
		else {
			setPopupMenuEnabled(helpContextList.size() > 1);
			setToolTipText(MActionInfo.HELP.getText());
		}
	}

}
