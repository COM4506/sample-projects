// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.help;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.util.Objects;

import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.html.MHTMLViewer;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MStatusBar;

/**
 * @since 3.8
 */
public final class Help {

	// private

	private static HelpSystem defaultHelpSystem;
	private static HelpSystem helpSystem;
	
	// public

	public synchronized static HelpSystem getHelpSystem() { return helpSystem; }

	public synchronized static void setHelpSystem(final HelpSystem value) { helpSystem = value; }

	public static boolean show(final Component source, final HelpContext context) {
		if (context == null)
			return false;

		Objects.requireNonNull(source);

		HelpSystem hs;
		synchronized (Help.class) {
			if (helpSystem == null) {
				if (defaultHelpSystem == null)
					defaultHelpSystem = new DefaultHelpSystem();
				hs = defaultHelpSystem;
			}
			else {
				hs = helpSystem;
			}
		}

		hs.show(source, context);

		return true;
	}
	
	// private

	@Uninstantiable
	private Help() {
		TK.uninstantiable();
	}

	// private classes

	private static final class DefaultHelpSystem extends HelpSystem {

		// public

		@Override
		public void show(final Component source, final HelpContext context) {
			switch (context.getType()) {
				case HTML:
					showHTML(source, context);
					break;
				case URI:
					MApplication.openURI(context.getURI());
					break;
				default:
					MStatusBar.error(i18n("Could not display help for \"{0}\"", context));
			}
		}
		
		// private
		
		private void showHTML(final Component source, final HelpContext context) {
			MDialog dialog = new MDialog(UI.windowFor(source), MActionInfo.HELP, MDialog.SIMPLE_DIALOG | MDialog.HEADER_BAR);
			dialog.addCenter(new MHTMLViewer(context.getHTML()));
			dialog.setSize(UI.WindowSize.MEDIUM);
			dialog.exec();
		}

	}

}
