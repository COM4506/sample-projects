// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.help;

import java.io.Serializable;
import java.util.Objects;

import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.html.HTMLBuilder;

/**
 * @mg.threadSafe
 *
 * @since 3.8
 */
public final class HelpContext implements Serializable {

	// public

	public enum Type {
	
		DEFAULT, URI,
		
		/**
		 * @since 4.8
		 */
		HTML;
	
	}

	// private

	private final String displayName;
	private final String group;
	private final String id;
	private final Type type;
	
	// public

	/**
	 * @since 4.8
	 */
	public HelpContext(final HTMLBuilder html) {
		this(null, html.toString(), Type.HTML, "");
	}

	/**
	 * @throws IllegalArgumentException If @p group or @p id is @c null or empty
	 */
	public HelpContext(final String group, final String id) {
		this(group, id, Type.DEFAULT, "");
	}

	/**
	 * @throws IllegalArgumentException If @p group or @p id is @c null or empty
	 * @throws NullPointerException If @p type is @c null
	 */
	public HelpContext(final String group, final String id, final Type type) {
		this(group, id, type, "");
	}

	/**
	 * @since 5.0
	 */
	public HelpContext(final String group, final String id, final Type type, final String displayName) {
		this.group = group;
		this.id = TK.checkNullOrEmpty(id, "id");
		this.type = Objects.requireNonNull(type);
		this.displayName = Objects.requireNonNull(displayName);
	}

	@Override
	public boolean equals(final Object o) {
		if (o == this)
			return true;

		if (!(o instanceof HelpContext))
			return false;

		HelpContext other = (HelpContext)o;

		return
			(this.type == other.type) &&
			this.group.equals(other.group) &&
			this.id.equals(other.id) &&
			this.displayName.equals(other.displayName);
	}

	@Override
	public int hashCode() {
		return Objects.hash(group, id, type, displayName);
	}
	
	/**
	 * @since 5.0
	 */
	public String getDisplayName() { return displayName; }

	public String getGroup() { return group; }
	
	/**
	 * @since 4.8
	 */
	public String getHTML() {
		if (type != Type.HTML)
			throw new IllegalStateException();
	
		return id;
	}

	public String getID() { return id; }

	public HelpContext.Type getType() { return type; }
	
	/**
	 * @since 4.8
	 */
	public String getURI() {
		if (type != Type.URI)
			throw new IllegalStateException();

		return id;
	}

	@Important
	@Override
	public String toString() {
		if (!displayName.isEmpty())
			return displayName;

		StringBuilder result = new StringBuilder();
		result
			.append((type == Type.HTML) ? "HTML" : id)
			.append('@')
			.append(group);

		return result.toString();
	}

}
