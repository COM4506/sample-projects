// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

/**
 * An internal error.
 * 
 * @since 2.4, 3.8.4 - extends {@code java.lang.AssertionError}
 */
public final class WTFError extends AssertionError {
	
	// public

	/**
	 * Constructs a new error.
	 * 
	 * @param e the <i>unsupported</i> enum value (can be {@code null})
	 */
	public WTFError(final Enum<?> e) {
		super("Unsupported enum value: " + e);
	}

	/**
	 * Constructs a new error.
	 * 
	 * @param message the detail message (can be {@code null})
	 */
	public WTFError(final String message) {
		super(message);
	}

	/**
	 * @since 5.0
	 */
	public WTFError(final String message, final Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructs a new error.
	 * 
	 * @param cause the detail message
	 */
	public WTFError(final Throwable cause) {
		super(cause);
	}

}
