// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Color;
import java.text.ParseException;

import org.makagiga.commons.annotation.Important;

/** A @c Color property. */
public class ColorProperty extends Property<Color> {

	// public

	/**
	 * Constructs a @c Color property with @c Color.BLACK value.
	 */
	public ColorProperty() {
		super(Color.BLACK);
	}

	/**
	 * Constructs a @c Color property with @p value (can be @c null).
	 */
	public ColorProperty(final Color value) {
		super(value);
	}

	/**
	 * @since 4.0
	 */
	public ColorProperty(final Color value, final int options) {
		super(value, options);
	}

	/**
	 * Constructs a @c Color property with @p value.
	 */
	public ColorProperty(final int value) {
		super(new Color(value));
	}

	/**
	 * Constructs a @c Color property with @p value.
	 *
	 * @see #parseColor(String)
	 *
	 * @throws ParseException If @p value is invalid
	 *
	 * @since 2.0
	 */
	public ColorProperty(final String value) throws ParseException {
		super(parseColor(value));
	}

	/**
	 * @since 2.4
	 */
	@Override
	public Class<Color> getType() { return Color.class; }
	
	@Override
	public boolean isColorType() { return true; }

	/**
	 * Parses the color @p value.
	 *
	 * @see #parseColor(String)
	 *
	 * @throws ParseException If @p value is invalid
	 */
	@Override
	public void parse(final String value) throws ParseException {
		set(parseColor(value));
	}
	
	/**
	 * Parses the color @p value.
	 * The value must be in the <i>HTML format</i>.
	 *
	 * EXAMPLE VALUES:
	 * - "#000000" (black)
	 * - "#fff" (white)
	 * - "fff" (white)
	 * - "#ff0000" (red)
	 * - "#00ff00" (green)
	 * - "#0000ff" (blue)
	 *
	 * @throws ParseException If @p value is invalid
	 */
	public static Color parseColor(final String value) throws ParseException {
		if (TK.isEmpty(value))
			throw new ParseException("Null or empty color value", 0);
		
		try {
			int len = value.length();
			switch (len) {
				case 3: // rgb -> rrggbb
				case 4: // #rgb -> rrggbb
					char r;
					char g;
					char b;
					if ((len == 4) && (value.charAt(0) == '#')) {
						r = value.charAt(1);
						g = value.charAt(2);
						b = value.charAt(3);
					}
					else {
						r = value.charAt(0);
						g = value.charAt(1);
						b = value.charAt(2);
					}

					return new Color(parseByte(r), parseByte(g), parseByte(b));
				
				case 6: // rrggbb
				case 7: // #rrggbb
// TODO: Integer.parseInt(CharSeq... #jdk9
					return new Color(Integer.parseInt(
						((len == 7) && (value.charAt(0) == '#')) ? value.substring(1) : value,
						16
					));
				default:
					throw new ParseException("Invalid color value: \"" + value + "\"", 0);
			}
		}
		catch (NumberFormatException exception) {
			ParseException e = new ParseException("Invalid color value: \"" + value + "\"", 0);
			e.initCause(exception);

			throw e;
		}
	}

	@Override
	public void read(final Config config, final String key) {
		set(config.readColor(key, getDefaultValue()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, get());
	}
	
	/**
	 * @since 5.0
	 */
	public static String toDisplayString(final Color color) {
		return TK.toUpperCase(toString(color));
	}

	/**
	 * @since 4.4
	 */
	public static String toHex(final Color color) {
		return toHex(new StringBuilder(6), color);
	}

	/**
	 * @see #toString(Color)
	 */
	@Important
	@Override
	public String toString() {
		return toString(get());
	}

	/**
	 * Converts @p color to <i>HTML value</i>.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * String htmlColor = ColorProperty.toString(Color.RED);
	 * assert htmlColor.equals("#ff0000");
	 * </pre>
	 *
	 * @return <code>"#000000"</code> if @p color is @c null
	 */
	public static String toString(final Color color) {
		if (color == null)
			return "#000000";

		StringBuilder s = new StringBuilder(7);
		s.append('#');

		return toHex(s, color);
	}
	
	// private

	private static int parseByte(final char c) {
		byte b = Byte.parseByte(Character.toString(c), 16);

		return (b << 4) + b;
	}
	
	private static String toHex(final StringBuilder s, final Color color) {
		int i = color.getRed();
		if (i < 16)
			s.append('0');
		s.append(Integer.toHexString(i));

		i = color.getGreen();
		if (i < 16)
			s.append('0');
		s.append(Integer.toHexString(i));

		i = color.getBlue();
		if (i < 16)
			s.append('0');
		s.append(Integer.toHexString(i));

		return s.toString();
	}

}
