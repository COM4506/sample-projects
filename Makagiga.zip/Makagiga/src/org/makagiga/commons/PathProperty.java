// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;

/**
 * A {@link java.nio.file.Path} property.
 *
 * @since 5.4
 */
public class PathProperty extends Property<Path> {

	// public

	public PathProperty() {
		super(null);
	}

	public PathProperty(final Path value) {
		super(value);
	}

	public PathProperty(final Path value, final int options) {
		super(value, options);
	}

	@Override
	public Class<Path> getType() { return Path.class; }

	@Override
	public void parse(final String value) throws ParseException {
		set(parsePath(value));
	}
	
	public static Path parsePath(final String value) throws ParseException {
		if (value == null)
			throw new ParseException("Null path value", 0);
	
		try {
			return Paths.get(value);
		}
		catch (InvalidPathException exception) {
			ParseException exception2 = new ParseException(exception.getMessage(), 0);
			exception2.initCause(exception);
			
			throw exception2;
		}
	}

	@Override
	public void read(final Config config, final String key) {
		try {
			String s = config.read(key, "");
			if (s.isEmpty())
				set(getDefaultValue());
			else
				parse(s);
		}
		catch (ParseException exception) {
			MLogger.exception(exception);

			set(getDefaultValue());
		}
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, toString());
	}
	
}
