// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.FileSystemException;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.security.SecureRandom;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.regex.Pattern;

import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.io.FileScanner;
import org.makagiga.commons.swing.MMessage;

/** IO utilities. */
public final class FS {

	// public

	/**
	 * @since 5.4
	 */
	public static final DirectoryStream.Filter<Path> IS_DIRECTORY = Files::isDirectory;

	/**
	 * @since 5.4
	 */
	public static final DirectoryStream.Filter<Path> IS_REGULAR_FILE = Files::isRegularFile;

	/**
	 * @since 3.0
	 */
	@Obsolete
	public static final FileFilter DIRECTORY_FILTER = new DirectoryFilter();

	/**
	 * @since 2.0
	 */
	@Obsolete
	public static final int COPY_BUF_LENGTH = 4096;

	/**
	 * Create directory. A @ref makeConfigPath flag.
	 */
	public static final int CREATE_DIR = 1;
	
	/**
	 * An empty @c File array.
	 * 
	 * @since 3.0
	 */
	@Obsolete
	public static final File[] EMPTY_FILE_ARRAY = new File[0];

	/**
	 * @since 3.2
	 */
	@Obsolete
	public static final FileFilter FILE_FILTER = new RegularFileFilter();

	/**
	 * @since 5.4
	 */
	public static final String SEPARATOR;

	/**
	 * @since 5.4
	 */
	public static final char SEPARATOR_CHAR;

	// private

	private static boolean portable;
	private static Path basePath;
	private static Path configPath;
	private static Path userPath;
	private static String baseDir;
	private static String configDir;
	private static String profile;
	private static String userDir;
	
	// package
	
	static boolean restricted = true;

	// public

	static {
		SEPARATOR = FileSystems
			.getDefault()
			.getSeparator();
		SEPARATOR_CHAR = SEPARATOR.charAt(0);
	}

	/**
	 * @since 2.0
	 */
	@Obsolete
	public static void append(final File file, final String text) throws IOException {
		write(new FileOutputStream(file, true), text);
	}

	/**
	 * Silently closes a closeable stream/reader/writer.
	 * 
	 * @param closeable The object to close
	 * 
	 * @return {@code true} if succsessfull; otherwise {@code false}
	 */
	public static boolean close(final Closeable closeable) {
		if (closeable == null)
			return false;

		try {
			closeable.close();

			return true;
		}
		catch (IOException exception) { // quiet
			return false;
		}
	}

	public static void copyChars(final Reader in, final Writer out) throws IOException {
		copyChars(in, out, COPY_BUF_LENGTH);
	}
	
	public static void copyChars(final Reader in, final Writer out, final int bufSize) throws IOException {
		char[] buf = new char[bufSize];
		int bufLen;
		while ((bufLen = in.read(buf)) != -1) {
			out.write(buf, 0, bufLen);
		}
	}

	/**
	 * Copies @p sourceFile to @p destinationFile.
	 *
	 * @throws FileNotFoundException If error
	 * @throws IOException If error
	 *
	 * @since 1.2
	 */
	@Obsolete
	public static void copyFile(final File sourceFile, final File destinationFile) throws IOException {
		copyFile(sourceFile, destinationFile, null);
	}

	/**
	 * @since 2.0
	 */
	@Obsolete
	public static void copyFile(final File sourceFile, final File destinationFile, final ProgressListener progressListener) throws IOException {
		try (
			BufferedInputStream input = new BufferedFileInput(sourceFile);
			BufferedOutputStream output = new BufferedFileOutput(destinationFile)
		) {
			if (progressListener == null)
				copyStream(input, output);
			else
				copyStream(input, output, COPY_BUF_LENGTH, sourceFile.length(), progressListener);
		}
	}

	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public static void copyFile(final String sourceFile, final String destinationFile) throws IOException {
		copyFile(new File(sourceFile), new File(destinationFile));
	}

	public static void copyStream(final InputStream in, final OutputStream out) throws IOException {
		copyStream(in, out, COPY_BUF_LENGTH, -1, null);
	}
	
	/**
	 * @since 2.0
	 */
	public static void copyStream(final InputStream in, final OutputStream out, final int bufSize, final long inputLength, final ProgressListener progressListener) throws IOException {
		byte[] buf = new byte[bufSize];
		int bufLen;
		long complete = 0;
		while ((bufLen = in.read(buf)) != -1) {
			if (out != null)
				out.write(buf, 0, bufLen);
			if (progressListener != null) {
				complete += bufLen;
				if (!progressListener.updateProgress(complete, inputLength))
					break; // while
			}
		}
	}
	
	/**
	 * @since 2.0
	 */
	public static File createUniqueFile(final File dir, final String suffix) throws IOException {
		String name = TK.createRandomUUID();
		if (!TK.isEmpty(suffix))
			name += suffix;
		File file = new File(dir, name);

		if (!file.createNewFile())
			throw new IOException("Cannot create unique file: " + file);
		
		return file;
	}

	/**
	 * Recursively deletes all files and directories within a @p dir.
	 *
	 * @param dir A directory to delete
	 * @param deleteTopDir If @c true, also delete the <i>top</i> directory (@p dir)
	 *
	 * @return {@code true} if succsessfull; otherwise {@code false}
	 *
	 * @since 2.0
	 */
	public static boolean deleteDir(final File dir, final boolean deleteTopDir) {
		final BooleanProperty ok = new BooleanProperty(true);
		try {
			new FileScanner.Simple(dir, null) {
				@Override
				public void processFile(final File file) throws Exception {
					if (!file.delete())
						ok.no();
				}
				@Override
				public void processParentDir(final Object parentItem, final File dir) throws Exception {
					if (!dir.delete())
						ok.no();
				}
			};
			
			if (deleteTopDir) {
				if (!dir.delete())
					ok.no();
			}

			return ok.get();
		}
		catch (Exception exception) {
			return false;
		}
	}
	
	/**
	 * @since 2.0
	 */
	@Obsolete
	public static boolean deleteFiles(final File dir, final Pattern pattern) {
		File[] files = listFiles(dir);
		for (File i : files) {
			if ((pattern == null) || pattern.matcher(i.getName()).matches()) {
				if (!i.delete())
					return false;
			}
		}
		
		return true;
	}
	
	/**
	 * @since 4.2
	 */
	public static boolean deleteSilently(final Path path) {
		try {
			Files.deleteIfExists(path);
			
			return true;
		}
		catch (FileSystemException exception) {
			// HACK: this is usually caused by antiviruses
			MLogger.error("core", "Could not delete file (trying again): %s", exception);
			
			TK.sleep(50);
			try {
				Files.deleteIfExists(path);
			
				return true;
			}
			catch (IOException exception2) {
				MLogger.error("core", "Could not delete file (try #2): %s", exception2);
			
				return false;
			}
		}
		catch (IOException exception) {
			MLogger.error("core", "Could not delete file: %s", exception);
			
			return false;
		}
	}

	/**
	 * @see #getBasePath()
	 */
	@Obsolete
	public synchronized static String getBaseDir() {
		// NOTE: do not check for "restricted" mode
		
		if (baseDir != null)
			return baseDir;
			
		ProtectionDomain pd = FS.class.getProtectionDomain();
		if (pd == null) {
			baseDir = "";
				
			return baseDir;
		}

		CodeSource cs = pd.getCodeSource();
		if (cs == null) {
			baseDir = "";
			
			return baseDir;
		}

		try {
			URL location = cs.getLocation();
			if (location == null) {
				baseDir = "";
						
				return baseDir;
			}

			File file = new File(cs.getLocation().toURI());
			if (!file.isDirectory())
				file = file.getParentFile();
			baseDir = (file == null) ? "" : file.getPath();
		}
		catch (IllegalArgumentException /* Web Start fix */ | URISyntaxException exception) {
			MLogger.exception(exception);
			baseDir = "";
		}

		return baseDir;
	}
	
	/**
	 * Returns the application base directory, or empty path ("").
	 *
	 * @mg.example
	 * "/usr/share/myapp", "C:\Program Files\My App", etc.
	 *
	 * @mg.warning
	 * This method is not suitable for applications launched via Web Start.
	 *
	 * @since 4.2
	 *
	 * @see OS#isWebStart()
	 */
	public static Path getBasePath() {
		String s = getBaseDir(); // init

		synchronized (FS.class) {
			if (basePath == null)
				basePath = Paths.get(s);

			return basePath;
		}
	}
	
	/**
	 * @since 5.4
	 */
	public static String getBaseName(final Path path) {
		return getBaseName(getFileName(path));
	}
	
	/**
	 * Returns a @p path without extension suffix.
	 * 
	 * @mg.example
	 * <pre class="brush: java">
	 * assert FS.getBaseName(null) == null;
	 * assert FS.getBaseName("").isEmpty();
	 * assert FS.getBaseName("/foo/bar.ext").equals("/foo/bar");
	 * assert FS.getBaseName("/foo/bar").equals("/foo/bar");
	 * </pre>
	 * 
	 * @return {@code null} if {@code path} is {@code null}
	 * 
	 * @since 3.0
	 */
	public static String getBaseName(final String path) {
		if (TK.isEmpty(path))
			return path;
		
		int i = path.lastIndexOf('.');
		
		return (i == -1) ? path : path.substring(0, i);
	}
	
	/**
	 * Creates and returns the user configuration directory.
	 * (e.g. "/home/user/.internalname")
	 * Internal name is a value returned by @ref MApplication.getInternalName.
	 * 
	 * @throws IllegalStateException If "internal name" is not set
	 * 
	 * @see #getConfigPath()
	 * @see #getUserPath()
	 */
	@Obsolete
	public synchronized static String getConfigDir() {
		if (restricted)
			throw new IllegalStateException("Restricted mode");
		
		if (configDir == null) {
			portable = Args.isSet("portable");
			if (portable) {
				configDir = getBaseDir();
				if (configDir.isEmpty()) {
					MMessage.error(null, "Could not initialize \"portable\" folder");
					portable = false;
				}
				else {
					File file = new File(configDir, "portable");
					file.mkdirs();
					if (!file.exists() || !file.canWrite()) {
						MMessage.error(null, "Could not initialize \"portable\" folder\n" + file);
						portable = false;
					}
					configDir = file.getPath();
				}
			}
			if (!portable) {
				configDir = makePath(getUserDir(), "." + MApplication.getInternalName());
				Path dir = Paths.get(configDir);
				if (!Files.exists(dir)) {
					try {
						dir = Files.createDirectories(dir);

						// hide ".makagiga" folder
						try {
							if (OS.isWindows())
								Files.setAttribute(dir, "dos:hidden", true);
						}
						catch (Exception exception) { } // quiet
					}
					catch (IOException exception) {
						MLogger.exception(exception);
					
						String text = "Could not initialize configuration directory\n" + configDir; // no i18n
						MMessage.error(null, text);
					
						throw new WTFError(text, exception);
					}
				}
			}
			
			String userFiles = Args.getOption("user-files");
			if (TK.isEmpty(userFiles))
				userFiles = System.getenv("MAKAGIGA_USER_FILES");
			File userFilesDir = TK.isEmpty(userFiles) ? null : new File(userFiles);
			
			boolean validUserFilesDir = false;
			if (userFilesDir != null) {
				if (userFilesDir.exists()) {
					if (userFilesDir.isDirectory())
						validUserFilesDir = true;
					else
						MMessage.error(null, "Directory expected\n" + userFilesDir);
				}
				else {
					MMessage.error(null, String.format("Directory \"%s\"%ndoes not exist", userFilesDir.getPath()));
				}
			}
				
			if (validUserFilesDir) {
				configDir = userFilesDir.getPath();
				profile = configDir;
			}
			else {
				profile = Args.getOption("profile");
				if (TK.isEmpty(profile))
					profile = System.getenv("MAKAGIGA_PROFILE");
				if (TK.isEmpty(profile)) {
					profile = null;
				}
				else {
					if (profile.contains("\\") || profile.contains("/") || profile.contains(".")) {
						MMessage.error(null, "Invalid profile name: " + profile);
						profile = null;

						return configDir;
					}

					File profileDir = new File(makePath(makePath(configDir, "profiles"), profile));
					profileDir.mkdirs();
					if (profileDir.exists()) {
						MLogger.info("core", "Profile directory: \"%s\"", profileDir.getPath());
						configDir = profileDir.getPath();
					}
					else {
						profile = null;
					}
				}
			}
			MLogger.info("core", "Configuration root directory: \"%s\"", configDir);
		}

		return configDir;
	}

	/**
	 * @since 5.0
	 */
	public static void lines(final Path path, final Consumer<Stream<String>> consumer) throws IOException {
		try (Stream<String> stream = Files.lines(path)) {
			consumer.accept(stream);
		}
		catch (UncheckedIOException exception) {
			throw exception.getCause();
		}
	}

	/**
	 * @since 3.8.9
	 */
	public synchronized static void setConfigDir(final String value) {
		if (configDir != null)
			throw new IllegalStateException("Configuration directory already set");
		
		if (!new File(value).exists())
			throw new IllegalArgumentException(String.format("Directory \"%s\"%ndoes not exist", value));
		
		configDir = value;
		configPath = null; // reset cache
		restricted = false;
	}

	/**
	 * @since 4.4
	 */
	public static Path getConfigPath() {
		String s = getConfigDir(); // init

		synchronized (FS.class) {
			if (configPath == null)
				configPath = Paths.get(s);
			
			return configPath;
		}
	}

	/**
	 * @since 4.4
	 */
	public static long getDirectorySize(final Path path) throws IOException {
		return getDirectorySize(path, EnumSet.noneOf(FileVisitOption.class));
	}

	/**
	 * @since 4.4
	 */
	public static long getDirectorySize(final Path path, final Set<FileVisitOption> options) throws IOException {
		FileSizeVisitor visitor = new FileSizeVisitor();
		Files.walkFileTree(path, options, Integer.MAX_VALUE, visitor);
		
		return visitor.size;
	}

	/**
	 * @since 4.0
	 */
	@Obsolete
	public static String getFileExtension(final File file) {
		return getFileExtension(file.getPath());
	}

	/**
	 * @since 4.0
	 */
	public static String getFileExtension(final Path path) {
		return getFileExtension(getFileName(path));
	}

	/**
	 * Returns a file type (extension, suffix) extracted from the {@code path}.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * assert FS.getFileExtension("image.png").equals("png");
	 * assert FS.getFileExtension("my.image.png").equals("png");
	 * assert FS.getFileExtension("image").isEmpty();
	 * assert FS.getFileExtension(".dot_hidden").isEmpty();
	 * assert FS.getFileExtension("name.").isEmpty();
	 * </pre>
	 *
	 * @throws NullPointerException If {@code path} is {@code null}
	 *
	 * @since 4.0
	 */
	public static String getFileExtension(final String path) {
		int i = path.lastIndexOf('.');

		if ((i == -1) || (i == 0) /* i == 0 - hidden file */)
			return "";
		
		// /foo/.bar
		if ((path.charAt(i - 1) == SEPARATOR_CHAR))
			return "";

		return (i == path.length() - 1) ? "" : path.substring(i + 1);
	}

	/**
	 * @since 5.6
	 */
	public static String getFileName(final Path path) {
		return Objects.toString(path.getFileName(), "");
	}

	/**
	 * Returns the installation directory "prefix".
	 *
	 * @since 3.8.1
	 */
	@Obsolete
	public static String getInstallPrefix(final String defaultPrefix) {
		if (OS.isLinux()) {
			String s = getBaseDir();
			if (!s.isEmpty()) {
				// /usr/share/makagiga
				File f = new File(s);
				// /usr/share
				f = f.getParentFile();
				if (f != null) {
					// /usr
					f = f.getParentFile();
					if (f != null) {
						MLogger.debug("fs", "Found Install Prefix: %s", f);

						return f.getPath();
					}
				}
			}
		}

		return defaultPrefix;
	}

	/**
	 * Returns a "platform" configuration path of @p relativePath.
	 *
	 * - The returned path is merged with the directory returned by @ref getConfigDir()
	 * - All backslashes ("\") and slashes ("/") are replaced with @c File.separatorChar
	 *
	 * @throws NullPointerException If @p relativePath is @c null
	 *
	 * @see #getPortableConfigPath(String)
	 *
	 * @since 3.8
	 */
	public static String getPlatformConfigPath(final String relativePath) {
		String path = relativePath
			.replace('\\', File.separatorChar)
			.replace('/', File.separatorChar);
		
		return makeConfigPath(path);
	}

	/**
	 * Returns a "portable" configuration path of @p absolutePath.
	 *
	 * - The returned path may be relative to the directory returned by @ref getConfigDir()
	 * - All backslashes ("\") are replaced with slashes ("/")
	 *
	 * @throws NullPointerException If @p absolutePath is @c null
	 *
	 * @see #getPlatformConfigPath(String)
	 *
	 * @since 3.8
	 */
	public static String getPortableConfigPath(String absolutePath) {
		String cd = getConfigDir();

		if (absolutePath.startsWith(cd))
			absolutePath = absolutePath.substring(cd.length() + 1);

		return absolutePath.replace('\\', '/');
	}
	
	public static String getProfile() { return profile; }

	/**
	 * Returns the user home directory. (e.g. "/home/user")
	 *
	 * @see #getConfigDir()
	 * @see #getUserPath()
	 */
	@Obsolete
	public synchronized static String getUserDir() {
		if (userDir == null) {
			userDir = getAbsolute(System.getProperty("user.home"));
			userPath = Paths.get(userDir);
			MLogger.info("core", "User directory: \"%s\"", userDir);
		}

		return userDir;
	}
	
	/**
	 * @since 4.2
	 */
	public static Path getUserPath() {
		getUserDir(); // init
		
		return userPath;
	}

	/**
	 * Returns an UTF-8 reader.
	 * @param file A file to read
	 * @return A @c FS.TextReader if succsessfull; otherwise @c null
	 * @throws FileNotFoundException If {@code file} not found
	 */
	@Obsolete
	public static TextReader getUTF8Reader(final File file) throws FileNotFoundException {
		return getUTF8Reader(new FileInputStream(file));
	}

	/**
	 * Returns an UTF-8 reader.
	 * @param input An input stream
	 * @return A @c FS.TextReader if succsessfull; otherwise @c null
	 */
	@Obsolete
	public static TextReader getUTF8Reader(final InputStream input) {
		return new TextReader(input, StandardCharsets.UTF_8);
	}

	/**
	 * Returns an UTF-8 writer.
	 * @param file A file to write
	 * @return A @c FS.TextWriter if succsessfull; otherwise @c null
	 * @throws FileNotFoundException If {@code file} not found
	 */
	@Obsolete
	public static TextWriter getUTF8Writer(final File file) throws FileNotFoundException {
		return getUTF8Writer(new FileOutputStream(file));
	}

	/**
	 * Returns an UTF-8 writer.
	 *
	 * @param output the output stream
	 *
	 * @return A {@code FS.TextWriter} if succsessfull; otherwise {@code null}
	 */
	@Obsolete
	public static TextWriter getUTF8Writer(final OutputStream output) {
		return new TextWriter(output, StandardCharsets.UTF_8);
	}
	
	/**
	 * @since 4.4
	 */
	public synchronized static boolean isInitialized() { return configDir != null; }

	/**
	 * @since 2.0
	 */
	public synchronized static boolean isPortable() { return portable; }
	
	/**
	 * @since 2.0
	 */
	public synchronized static boolean isRestricted() { return restricted; }

	/**
	 * Returns a list of files.
	 * @param dir A directory to list
	 * @return An empty array if no files in @p dir
	 */
	@Obsolete
	public static File[] listFiles(final File dir) {
		File[] result = dir.listFiles();
		
		return (result == null) ? EMPTY_FILE_ARRAY : result;
	}

	/**
	 * @since 3.0
	 */
	@Obsolete
	public static File[] listFiles(final File dir, final FileFilter filter) {
		File[] result = dir.listFiles(filter);
		
		return (result == null) ? EMPTY_FILE_ARRAY : result;
	}
	
	/**
	 * Returns a list of file names.
	 * @param dir A directory to list
	 * @return An empty array if no files in @p dir
	 *
	 * @since 2.0
	 */
	@Obsolete
	public static String[] listNames(final File dir) {
		String[] result = dir.list();
		
		return (result == null) ? TK.EMPTY_STRING_ARRAY : result;
	}

	/**
	 * Returns a file created from @ref getConfigDir and @p part2.
	 *
	 * @since 3.0
	 *
	 * @see #newConfigPath(java.lang.String)
	 */
	@Obsolete
	public static File makeConfigFile(final String part2) {
		return makeConfigFile(part2, 0);
	}

	/**
	 * Returns a file created from @ref getConfigDir and @p part2.
	 * You can use @ref CREATE_DIR as a @p flag.
	 *
	 * @since 3.0
	 */
	@Obsolete
	public static File makeConfigFile(final String part2, final int flag) {
		File file = new File(getConfigDir(), part2);
		if (flag == CREATE_DIR)
			file.mkdirs();

		return file;
	}

	/**
	 * Returns a path created from @ref getConfigDir and @p part2.
	 *
	 * @see #newConfigPath(java.lang.String)
	 */
	@Obsolete
	public static String makeConfigPath(final String part2) {
		return makePath(getConfigDir(), part2);
	}

	/**
	 * Returns a path created from @ref getConfigDir and @p part2.
	 * You can use @ref CREATE_DIR as a @p flag.
	 */
	@Obsolete
	public static String makeConfigPath(final String part2, final int flag) {
		String path = makePath(getConfigDir(), part2);
		if (flag == CREATE_DIR)
			new File(path).mkdirs();

		return path;
	}

	/**
	 * Constructs and returns a new path created from
	 * {@code part1}, {@code File.separator} and {@code part2}.
	 * If {@code part1} is empty (or {@code null}) then function will return {@code part2}.
	 * If {@code part2} is empty (or {@code null}) then function will return {@code part1}.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * assert FS.makePath("/usr/src", "linux").equals("/usr/src/linux");
	 * </pre>
	 */
	@Obsolete
	public static String makePath(final String part1, final String part2) {
		if (TK.isEmpty(part1))
			return part2;

		if (TK.isEmpty(part2))
			return part1;

		return part1 + SEPARATOR + part2;
	}
	
	/**
	 * @since 4.2
	 */
	public static Path newConfigPath(final String part2) {
		return getConfigPath().resolve(part2);
	}

	/**
	 * @since 5.4
	 */
	public static Path newConfigPath(final String part2, final int flag) {
		Path path = getConfigPath().resolve(part2);
		if (flag == CREATE_DIR) {
			try {
				Files.createDirectories(path);
			}
			catch (IOException exception) {
				MLogger.exception(exception);
			}
		}

		return path;
	}

	/**
	 * @since 5.4
	 */
	public static BufferedReader newBufferedReader(final InputStream input) {
		return newBufferedReader(input, StandardCharsets.UTF_8);
	}

	/**
	 * @since 5.4
	 */
	public static BufferedReader newBufferedReader(final InputStream input, final Charset charset) {
		return new BufferedReader(new InputStreamReader(input, charset));
	}

	/**
	 * @since 5.4
	 */
	public static BufferedWriter newBufferedWriter(final OutputStream output) {
		return newBufferedWriter(output, StandardCharsets.UTF_8);
	}

	/**
	 * @since 5.4
	 */
	public static BufferedWriter newBufferedWriter(final OutputStream output, final Charset charset) {
		return new BufferedWriter(new OutputStreamWriter(output, charset));
	}

	/**
	 * @since 5.6
	 */
	public static String readAllText(final Path file) throws IOException {
		try (BufferedReader reader = Files.newBufferedReader(file)) {
			StringBuilder buf = new StringBuilder((int)Files.size(file));
			readLines(reader, buf);

			return buf.toString();
		}
	}

	/**
	 * @since 2.0
	 */
	@Obsolete
	public static String read(final File file, final String encoding) throws IOException {
		try (BufferedFileInput input = new BufferedFileInput(file)) {
			return read(input, encoding, (int)file.length());
		}
	}

	/**
	 * @since 4.2
	 */
	public static StringBuilder read(final Path path, final Charset charset) throws IOException {
		try (BufferedReader reader = Files.newBufferedReader(path, charset)) {
			StringBuilder buf = new StringBuilder((int)Files.size(path));
			readLines(reader, buf);

			return buf;
		}
	}

	/**
	 * @mg.warning
	 * The {@code input} stream will be automatically closed after read.
	 *
	 * @since 2.0
	 */
	@Obsolete
	public static String read(final InputStream input, final String encoding) throws IOException {
		return read(input, encoding, COPY_BUF_LENGTH);
	}

	/**
	 * @mg.warning
	 * The {@code input} stream will be automatically closed after read.
	 *
	 * @since 3.2
	 */
	public static String read(final InputStream input, final String encoding, final int bufSize) throws IOException {
		try (TextReader reader = new TextReader(input, encoding)) {
			StringBuilder buf = new StringBuilder(Math.max(bufSize, 0));
			readLines(reader, buf);

			return buf.toString();
		}
	}

	/**
	 * @since 3.8.12
	 */
	public static void readLines(final BufferedReader reader, final StringBuilder output) throws IOException {
		String line;
		while ((line = reader.readLine()) != null) {
			output.append(line).append('\n');
		}
	}

	/**
	 * @since 3.8.12
	 */
	public static StringBuilder readLines(final InputStream input, final String charset, final boolean close) throws IOException {
		TextReader r = null;
		try {
			r = new TextReader(input, charset);
			StringBuilder buf = new StringBuilder(Math.max(input.available(), COPY_BUF_LENGTH));
			readLines(r, buf);

			return buf;
		}
		finally {
			if (close)
				close(r);
		}
	}

	/**
	 * @since 3.8.8
	 */
	public static String replaceUnsafeCharacters(final String name) {
		// HACK: "[" triggers global pattern filter in JFileChooser
		return name.replaceAll("(\\?|\\*|\\\\|/|\\:|\\\"|\\\'|\\`|\\||\\>|\\<|\\[|\\])", "_");
	}

	/**
	 * @since 3.8.10
	 */
	public static void secureDelete(final File file) throws IOException {
		if (!file.exists())
			return;

		RandomAccessFile raf = new RandomAccessFile(file, "rws");
		byte[] buf = new byte[1024];
		try {
			SecureRandom random = new SecureRandom();
			long length = raf.length();
			long pos = 0;
			while (pos < length) {
				random.nextBytes(buf);
				raf.write(buf);
				
				pos += buf.length;
				raf.seek(pos);
			}
			FileDescriptor fd = raf.getFD();
			if (fd != null)
				fd.sync();
		}
		finally {
			close(raf);
		}
	
		if (!deleteSilently(file.toPath()))
			throw new IOException("Could not delete file: " + file);
	}

	/**
	 * @since 5.4
	 */
	public static List<Path> toList(final Path dir, final DirectoryStream.Filter<? super Path> filter) throws IOException {
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, filter)) {
			MArrayList<Path> result = new MArrayList<>(256);

			for (Path i : ds)
				result.add(i);

			return result;
		}
	}

	/**
	 * @since 5.4
	 */
	public static List<Path> toList(final Path dir, final String glob) throws IOException {
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, glob)) {
			MArrayList<Path> result = new MArrayList<>(256);

			for (Path i : ds)
				result.add(i);

			return result;
		}
	}

	@Obsolete
	public static URL toURL(final File file) {
		try {
			return file.toURI().toURL();
		}
		catch (MalformedURLException exception) { // quiet
			return null;
		}
	}

	/**
	 * @since 5.4
	 */
	public static URL toURL(final Path file) {
		try {
			return file.toUri().toURL();
		}
		catch (MalformedURLException exception) { // quiet
			return null;
		}
	}

	/**
	 * @since 2.0
	 */
	public static void write(final File file, final String text) throws IOException {
		write(new FileOutputStream(file), text);
	}
	
	/**
	 * @mg.warning
	 * The {@code output} stream will be automatically closed after write.
	 *
	 * @since 2.0
	 */
	@Obsolete
	public static void write(final OutputStream output, final String text) throws IOException {
		try (TextWriter writer = getUTF8Writer(output)) {
			if (text != null)
				writer.write(text);
			
			if (writer.checkError())
				throw new IOException("Text write error");
		}
	}
	
	// private
	
	@Uninstantiable
	private FS() {
		TK.uninstantiable();
	}
	
	private static String getAbsolute(final String dir) {
		if (dir.contains("../") || dir.contains("..\\"))
			return new File(dir).getAbsolutePath();
			
		return dir;
	}

	// public classes

	public static final class BufferedFileInput extends BufferedInputStream {
		
		// public
		
		@Obsolete
		public BufferedFileInput(final File file) throws FileNotFoundException {
			super(new FileInputStream(file));
		}

		/**
		 * @since 5.4
		 */
		public BufferedFileInput(final Path file) throws IOException {
			super(Files.newInputStream(file));
		}

	}

	public static final class BufferedFileOutput extends BufferedOutputStream {
		
		// public
		
		@Obsolete
		public BufferedFileOutput(final File file) throws FileNotFoundException {
			super(new FileOutputStream(file));
		}

		@Obsolete
		public BufferedFileOutput(final File file, final boolean append) throws FileNotFoundException {
			super(new FileOutputStream(file, append));
		}

		/**
		 * @since 5.4
		 */
		public BufferedFileOutput(final Path file) throws IOException {
			super(Files.newOutputStream(file));
		}

		/**
		 * @since 3.4
		 */
		public boolean sync() {
			if (out instanceof FileOutputStream) {
				try {
					flush();

					FileOutputStream fos = (FileOutputStream)out;
					FileDescriptor fd = fos.getFD();
					if (fd != null)
						fd.sync();
					
					return true;
				}
				catch (IOException exception) {
					return false;
				}
			}
			else {
				return false;
			}
		}

	}
	
	/**
	 * @since 3.0
	 */
	@Obsolete
	public static final class FileExtensionFilter implements FileFilter {
		
		// private
		
		private final String[] extensions;
		
		// public
		
		public FileExtensionFilter(final String... extensions) {
			this.extensions = TK.copyOf(extensions);
		}

		@Override
		public boolean accept(final File file) {
			if (!file.isFile())
				return false;
			
			String ext = FS.getFileExtension(file);
			
			if (ext.isEmpty())
				return false;
			
			for (String i : extensions) {
				if (ext.equalsIgnoreCase(i))
					return true;
			}
			
			return false;
		}

	}

	/**
	 * @since 3.0
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public static final class FileNameRegExpFilter implements FileFilter {
		
		// private
		
		private final Pattern pattern;
		
		// public
		
		public FileNameRegExpFilter(final String pattern) {
			this.pattern = Pattern.compile(pattern);
		}

		@Override
		public boolean accept(final File file) {
			return file.isFile() && pattern.matcher(file.getName()).matches();
		}

	}

	/**
	 * @since 2.0
	 */
	@FunctionalInterface
	public static interface ProgressListener {
		
		// public
		
		public boolean updateProgress(final long complete, final long length);
		
	}

	@Obsolete
	public static final class TextReader extends BufferedReader implements Iterable<String> {

		// public

		/**
		 * @since 4.6
		 */
		public TextReader(final InputStream input, final Charset encoding) {
			super(new InputStreamReader(input, encoding));
		}

		/**
		 * @deprecated Since 4.6
		 */
		@Deprecated
		public TextReader(final InputStream input, final String encoding) throws UnsupportedEncodingException {
			super(new InputStreamReader(input, encoding));
		}

		/**
		 * @since 3.8.10
		 */
		public TextReader(final Reader reader) {
			super(reader);
		}

		/**
		 * @since 3.8.1
		 */
		@Obsolete
		public TextReader(final String text) {
			super(new StringReader(text));
		}
		
		@Obsolete
		@Override
		public void close() throws IOException {
			super.close();
		}

		// Iterable

		/**
		 * Returns a line iterator (non-{@code null} lines).
		 *
		 * @since 3.8.1
		 */
		@Override
		public Iterator<String> iterator() {
			return new LineIterator(this);
		}
		
	}

	@Obsolete
	public static final class TextWriter extends PrintWriter {

		// public

		/**
		 * @since 4.6
		 */
		public TextWriter(final OutputStream output, final Charset encoding) {
			super(new BufferedWriter(new OutputStreamWriter(output, encoding)));
		}

		/**
		 * @deprecated Since 4.6
		 */
		@Deprecated
		public TextWriter(final OutputStream output, final String encoding) throws UnsupportedEncodingException {
			super(new BufferedWriter(new OutputStreamWriter(output, encoding)));
		}

		@Obsolete
		@Override
		public void close() {
			super.close();
		}

		/**
		 * @since 3.4
		 *
		 * @deprecated Since 5.4
		 */
		@Deprecated
		public boolean sync() {
			return false;
		}
		
	}
	
	// private classes
	
	private static final class DirectoryFilter implements FileFilter {
		
		// public

		@Override
		public boolean accept(final File file) {
			return file.isDirectory();
		}

	}
	
	private static final class FileSizeVisitor extends SimpleFileVisitor<Path> {
	
		// public
		
		public long size;
		
		// public
		
		@Override
		public FileVisitResult visitFile(final Path file, final BasicFileAttributes attr) {
			if (attr.isRegularFile())
				size += attr.size();
			
			return FileVisitResult.CONTINUE;
		}
	
	}

	private static final class LineIterator implements Iterator<String> {

		// private

		private boolean eof;
		private final BufferedReader reader;
		private String next;

		// public

		@Override
		public boolean hasNext() {
			if (eof)
				return false;

			return next != null;
		}

		@Override
		public String next() {
			if (eof)
				throw new NoSuchElementException("EOF");

			String result = next;
			readNextLine();

			return result;
		}

		// private

		private LineIterator(final BufferedReader reader) {
			this.reader = reader;

			readNextLine();
		}

		private void readNextLine() {
			try {
				next = reader.readLine();
				eof = (next == null);
			}
			catch (IOException exception) {
				MLogger.exception(exception);
			}
		}

	}

	private static final class RegularFileFilter implements FileFilter {

		// public

		@Override
		public boolean accept(final File file) {
			return file.isFile();
		}

	}

}
