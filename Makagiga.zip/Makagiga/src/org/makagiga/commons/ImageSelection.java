// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.datatransfer.DataFlavor;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Objects;
import javax.imageio.ImageIO;

/** An image object that can be copied to the clipboard. */
public class ImageSelection extends AbstractSelection<Image> {
	
	// private
	
	private final Color backgroundColor;
	private static DataFlavor bmpImageFlavor = createDataFlavor("image/bmp", "java.awt.Image");
	private static DataFlavor pngImageFlavor = createDataFlavor("image/png", "java.awt.Image");

	// public

	/**
	 * Constructs an image selection.
	 *
	 * @param image An image you want to copy to the clipboard
	 * @param backgroundColor An image background color. Used when @p image is being converted to the BMP format on Windows platform. May be @c null.
	 *
	 * @throws NullPointerException If @p image is @c null
	 */
	public ImageSelection(final Image image, final Color backgroundColor) {
		super(
			Objects.requireNonNull(image, "image"),
			DataFlavor.imageFlavor, pngImageFlavor, bmpImageFlavor
		);
		this.backgroundColor = backgroundColor;
	}

	/**
	 * Returns the @c Image object.
	 *
	 * @param dataFlavor A data flavor
	 */
	@Override
	public synchronized Object getContents(final DataFlavor dataFlavor) {
		boolean imageFlavor = dataFlavor.equals(DataFlavor.imageFlavor);
		
		if ((imageFlavor && OS.isWindows()) || dataFlavor.equals(bmpImageFlavor))
			return convertToBMP(getData());
		
		return getData();
	}
	
	// private

	private BufferedImage convertToBMP(final Image image) {
		try {
			int w = image.getWidth(null);
			int h = image.getHeight(null);
			BufferedImage bmp = new BufferedImage(w, h, UI.getTypeForImageFormat("bmp"));
			Graphics2D g = bmp.createGraphics();
			g.setColor(TK.get(backgroundColor, Color.WHITE));
			g.fillRect(0, 0, w, h);
			g.drawImage(image, 0, 0, null, null);
			g.dispose();

			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ImageIO.write(bmp, "bmp", out);
			FS.close(out);
			
			return ImageIO.read(new ByteArrayInputStream(out.toByteArray()));
		}
		catch (IOException exception) {
			MLogger.exception(exception);
			
			return null;
		}
	}
	
}
