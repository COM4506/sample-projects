// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.lang.ref.WeakReference;
import java.util.function.Consumer;
import javax.swing.Icon;

/**
 * @since 3.8
 */
public class MDataAction<T> extends MAction {

	// private

	private final T data;
	
	// public

	public MDataAction(final T data, final MActionInfo info) {
		super(info);
		this.data = data;
	}

	/**
	 * @since 5.0
	 */
	public MDataAction(final T data, final MActionInfo info, final Consumer<? extends MDataAction<T>> onAction) {
		super(info, onAction);
		this.data = data;
	}

	public MDataAction(final T data, final String name) {
		super(name);
		this.data = data;
	}

	/**
	 * @since 5.0
	 */
	public MDataAction(final T data, final String name, final Consumer<? extends MDataAction<T>> onAction) {
		super(name, onAction);
		this.data = data;
	}

	public MDataAction(final T data, final String name, final Icon icon) {
		super(name, icon);
		this.data = data;
	}

	/**
	 * @since 5.0
	 */
	public MDataAction(final T data, final String name, final Icon icon, final Consumer<? extends MDataAction<T>> onAction) {
		super(name, icon, onAction);
		this.data = data;
	}

	public MDataAction(final T data, final String name, final String iconName) {
		super(name, iconName);
		this.data = data;
	}

	/**
	 * @since 5.0
	 */
	public MDataAction(final T data, final String name, final String iconName, final Consumer<? extends MDataAction<T>> onAction) {
		super(name, iconName, onAction);
		this.data = data;
	}

	/**
	 * Returns the data object or {@code null}.
	 *
	 * @return the data object or {@code null}.
	 */
	public T getData() { return data; }

	public boolean isData() {
		return data != null;
	}

	// public classes

	public static class Weak<T> extends MDataAction<WeakReference<T>> {

		// public

		public Weak(final T data, final MActionInfo info) {
			super(new WeakReference<>(data), info);
		}

		/**
		 * @since 5.4
		 */
		public Weak(final T data, final MActionInfo info, final Consumer<? extends MDataAction.Weak<T>> onAction) {
			super(new WeakReference<>(data), info, onAction);
		}

		public Weak(final T data, final String name) {
			super(new WeakReference<>(data), name);
		}

		/**
		 * @since 5.4
		 */
		public Weak(final T data, final String name, final Consumer<? extends MDataAction.Weak<T>> onAction) {
			super(new WeakReference<>(data), name, onAction);
		}

		public Weak(final T data, final String name, final Icon icon) {
			super(new WeakReference<>(data), name, icon);
		}

		public Weak(final T data, final String name, final String iconName) {
			super(new WeakReference<>(data), name, iconName);
		}

		public T get() {
			return getData().get();
		}

	}

}
