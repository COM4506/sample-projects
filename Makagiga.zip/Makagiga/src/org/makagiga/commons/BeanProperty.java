// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Objects;

/**
 * A JavaBean wrapper.
 *
 * @since 3.4
 */
public class BeanProperty<T> extends Property<T> implements PropertyChangeListener {

	// private

	private Class<T> type;
	private Method getter;
	private Method setter;
	private Object object;
	private String name;
	
	// public
	
	public BeanProperty(final Object object, final Class<T> type, final String name) {
		this.object = Objects.requireNonNull(object);
		this.type = Objects.requireNonNull(type);
		this.name = TK.checkNullOrEmpty(name);

		Class<?> clazz = object.getClass();
		getter = getGetter(clazz, name);
		setter = getSetter(clazz, name, type);
		setDefaultValue(get());
	}

	/**
	 * @since 3.8.4
	 */
	public BeanProperty(final Object object, final Class<T> type, final String name, final Method getter, final Method setter) {
		this.object = Objects.requireNonNull(object);
		this.type = Objects.requireNonNull(type);
		this.name = TK.checkNullOrEmpty(name);

		this.getter = getter;
		this.setter = setter;
		setDefaultValue(get());
	}

	/**
	 * @since 3.8.4
	 */
	@SuppressWarnings("unchecked")
	public BeanProperty(final Object object, final PropertyDescriptor descriptor) {
		this(
			object,
			(Class<T>)descriptor.getPropertyType(),
			descriptor.getName(),
			descriptor.getReadMethod(),
			descriptor.getWriteMethod()
		);
	}

	/**
	 * Returns @c true if <i>getter</i> method is available.
	 *
	 * @see #get()
	 */
	public boolean canRead() {
		return getter != null;
	}

	/**
	 * Returns @c true if <i>setter</i> method is available.
	 *
	 * @see #set(Object)
	 */
	public boolean canWrite() {
		return setter != null;
	}

	public static Method getGetter(final Class<?> clazz, final String name) {
		String suffix = TK.capitalize(name);
		try {
			Method result = getGetter(clazz, "is", suffix);
			if (result == null)
				result = getGetter(clazz, "get", suffix);

			return result;
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			return null;
		}
	}

	/**
	 * Returns a non-null name of this bean property.
	 */
	public String getName() { return name; }

	/**
	 * Returns a non-null owner of this bean property.
	 */
	public Object getObject() { return object; }

	public static Method getSetter(final Class<?> clazz, final String name, final Class<?> type) {
		String setterName = "set" + TK.capitalize(name);
		try {
			return clazz.getMethod(setterName, type);
		}
		catch (NoSuchMethodException exception) {
			//MLogger.exception(exception);

			return null;
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			return null;
		}
	}

	/**
	 * @return {@code null} if {@link #canRead()} returned {@code false}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public T get() {
		if (!canRead())
			return null;

		try {
			return (T)getter.invoke(object);
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			return null;
		}
	}

	/**
	 * Does nothing if @ref canWrite() returned @c false.
	 */
	@Override
	public boolean set(final T value) {
		if (!canWrite())
			return false;

		try {
			setter.invoke(object, value);

			return true;
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			return false;
		}
	}

	@Override
	public boolean isReadOnly() {
		return !canWrite() || super.isReadOnly();
	}

	/**
	 * Returns a non-null type of this bean property.
	 */
	@Override
	public Class<T> getType() { return type; }

	// PropertyChangeListener

	@Override
	public void propertyChange(final PropertyChangeEvent e) {
		PropertyChangeSupport propertyChangeSupport = getPropertyChangeSupport();
		if (propertyChangeSupport != null)
			propertyChangeSupport.firePropertyChange(e);
	}

	// private

	private static Method getGetter(final Class<?> clazz, final String prefix, final String suffix) {
		try {
			return clazz.getMethod(prefix + suffix);
		}
		catch (NoSuchMethodException exception) {
			return null;
		}
	}

}
