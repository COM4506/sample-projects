// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import java.util.function.Consumer;

import org.makagiga.commons.MDataAction;

/**
 * @since 3.0
 */
public class CategoryAction extends MDataAction<Category> {
	
	// public
	
	public CategoryAction(final Category category) {
		super(category, category.getName(), category.getCategoryIcon());
		setHTMLEnabled(false);
	}

	/**
	 * @since 5.6
	 */
	public CategoryAction(final Category category, final Consumer<? extends CategoryAction> eventHandler) {
		super(category, category.getName(), category.getCategoryIcon(), eventHandler);
		setHTMLEnabled(false);
	}

}
