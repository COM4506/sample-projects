// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Iterator;
import java.util.Objects;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.painters.GlassPainter;
import org.makagiga.commons.swing.FontBuilder;

/**
 * Renders a list of categories.
 *
 * @since 3.0
 */
public class CategoryListRenderer<T> extends MRenderer<T> {

	// public
	
	/**
	 * @since 4.12
	 */
	public static final String ALIGNMENT_PROPERTY = "org.makagiga.commons.category.CategoryListRenderer.ALIGNMENT_PROPERTY";

	/**
	 * @since 4.12
	 */
	public static final String ALPHA_PROPERTY = "org.makagiga.commons.category.CategoryListRenderer.ALPHA_PROPERTY";

	/**
	 * @since 4.12
	 */
	public static final String BASE_FONT_PROPERTY = "org.makagiga.commons.category.CategoryListRenderer.BASE_FONT_PROPERTY";

	// private

	private static final CategoryList EMPTY_CATEGORY_LIST = new CategoryList();
	private final CategoryManager categoryManager;
	private static final String FONT_CACHE_PROPERTY = "org.makagiga.commons.category.CategoryListRenderer.FONT_CACHE_PROPERTY";
	private static final String UNDERLINE_FONT_CACHE_PROPERTY = "org.makagiga.commons.category.CategoryListRenderer.UNDERLINE_FONT_CACHE_PROPERTY";
	private String promptText;
	
	private static final int GAP = 5;
	private static final int ICON_TEXT_GAP = 4;
	private static final int PADDING_H = 4;
	private static final int PADDING_V = 3;
	
	// public

	public CategoryListRenderer(final CategoryManager categoryManager) {
		this.categoryManager = Objects.requireNonNull(categoryManager);
	}
	
	/**
	 * @since 4.6
	 */
	public static void clearFontCache(final JComponent c) {
		c.putClientProperty(FONT_CACHE_PROPERTY, null);
		c.putClientProperty(UNDERLINE_FONT_CACHE_PROPERTY, null);
	}

	/**
	 * @since 3.8.10
	 */
	public static Color getBorderColor(final Category category, final Color backgroundColor) {
		Color color = category.getColor();
		if (color == null)
			color = backgroundColor;

		return MColor.deriveColor(color, 0.9f);
	}

	public CategoryManager getCategoryManager() { return categoryManager; }

	/**
	 * @since 3.2
	 */
	public static Dimension getPreferredSize(final Component c, final CategoryList categoryList) {
		if (TK.isEmpty(categoryList))
			return new Dimension(0, 0);

		FontMetrics fm = c.getFontMetrics(getFont(c, FONT_CACHE_PROPERTY));
		Dimension result = new Dimension(1, fm.getHeight() + (PADDING_V * 2));
		for (Category i : categoryList) {
			Icon icon = i.getIcon();
			int iconWidth =
				(
					MIcon.isEmpty(icon) ||
					((icon instanceof ImageIcon) && (ImageIcon.class.cast(icon).getImage() == null))
				)
				? 0
				: (icon.getIconWidth() + ICON_TEXT_GAP);
			result.width += (iconWidth + fm.stringWidth(i.getName()) + (PADDING_H * 2) + GAP) - 1;
		}
		result.width += GAP;

		return result;
	}
	
	/**
	 * @since 4.6
	 */
	public static void paint(final Component c, final Graphics2D graphics, final CategoryList categoryList, final Color backgroundColor) {
		paint(c, graphics, categoryList, backgroundColor, null);
	}

	/**
	 * @since 3.2
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public static void paint(final Component c, final Graphics2D graphics, final CategoryList categoryList, final Color backgroundColor, final Color foregroundColor) {
		if (TK.isEmpty(categoryList))
			return;
		
		Graphics2D g = (Graphics2D)graphics.create();
		UI.setAntialiasing(g, true);
		UI.setTextAntialiasing(g, null);

		g.setFont(getFont(c, FONT_CACHE_PROPERTY));

		FontMetrics fm = g.getFontMetrics();
		int stringHeight = fm.getHeight();
		
		int rectY = (c.getHeight() - stringHeight) / 2;
		int stringY = rectY + fm.getAscent();
		rectY -= PADDING_V;
		int rectHeight = stringHeight + (PADDING_V * 2) - 1;

		float alpha;
		int align;
		if (c instanceof JComponent) {
			align = UI.getClientProperty((JComponent)c, ALIGNMENT_PROPERTY, UI.LEFT);
			alpha = UI.getClientProperty((JComponent)c, ALPHA_PROPERTY, 1.0f);
		}
		else {
			align = UI.LEFT;
			alpha = 1.0f;
		}
		if (alpha < 1.0f)
			g.setComposite(AlphaComposite.SrcOver.derive(alpha));

		int x;
		Iterator<Category> it;
		if (align == UI.LEFT) {
			it = categoryList.iterator();
			x = GAP;
		}
		// UI.RIGHT
		else {
			it = categoryList.descendingIterator();
			x = c.getWidth() - 1;
		}

		while (it.hasNext()) {
			Category i = it.next();
			String display = i.getName();

			Icon icon = i.getIcon();
			int iconWidth =
				(
					MIcon.isEmpty(icon) ||
					((icon instanceof ImageIcon) && (ImageIcon.class.cast(icon).getImage() == null))
				)
				? 0
				: (icon.getIconWidth() + ICON_TEXT_GAP);

			int stringWidth = fm.stringWidth(display);
			int rectWidth = iconWidth + stringWidth + (PADDING_H * 2) - 1;
			if (align == UI.RIGHT)
				x -= (rectWidth + GAP);

			Color bg = i.getColor();
			if (bg == null)
				bg = backgroundColor;
			Color borderColor = getBorderColor(i, backgroundColor);
			paintBackground(c, g, bg, borderColor, x, rectY, rectWidth, rectHeight);

			// draw icon
			if ((icon != null) && (iconWidth > 0)) {
				int iconHeight = icon.getIconHeight();
				int iconY = rectY + rectHeight / 2 - iconHeight / 2 + 1;
				icon.paintIcon(c, g, x + PADDING_H, iconY);
			}

			// draw text
			g.setColor((bg != null) ? MColor.getContrastBW(bg) : MColor.BLACK);
			g.drawString(display, x + iconWidth + PADDING_H, stringY);

			if (align == UI.LEFT) {
				x += (rectWidth + GAP);

				if (x > c.getWidth())
					break; // for
			}
			// UI.RIGHT
			else {
				if (x < 0)
					break; // for
			}
		}
		g.dispose();
	}
	
	/**
	 * @since 4.10
	 */
	public void setPromptText(final String value) { promptText = value; }

	// protected
	
	@Override
	protected JComponent createView() {
		return new View();
	}

	/**
	 * Returns a list of categories.
	 * The default implementation splits @p categories using comma separator.
	 *
	 * @return An empty list if no categories
	 */
	protected CategoryList getCategoryList(final T categories) {
		if (categories == null)
			return EMPTY_CATEGORY_LIST;

		String s = categories.toString();

		if (TK.isEmpty(s))
			return EMPTY_CATEGORY_LIST;

		return new CategoryList(categoryManager, s);
	}

	@Override
	protected void onRender(final T categories) {
		View view = (View)getView();
		view.categoryList = getCategoryList(categories);
		view.promptText = (getSelectionCount() == 1) ? this.promptText : null;
		view.selected = this.isSelected();
		view.promptColor = (view.selected && (getTable() != null)) ? getTable().getSelectionForeground() : null;
	}
	
	// package

	static void paintBackground(final Component c, final Graphics2D g, final Color backgroundColor, final Color borderColor, final int x, final int y, final int w, final int h) {
		g.setColor(backgroundColor);

		if ((c instanceof JComponent) && JComponent.class.cast(c).isPaintingForPrint()) {
			g.fillRect(x, y, w, h);
		}
		else {
			int arc = GlassPainter.getArcForHeight(h);
			UI.setAntialiasing(g, true);

			g.fillRoundRect(
				x, y,
				w, h,
				arc, arc
			);

			if (borderColor != null) {
				g.setColor(borderColor);
				g.drawRoundRect(x, y, w, h, arc, arc);
			}
		}

	}

	// private
	
	private static Font getFont(final Component c, final String cacheKey) {
		FontBuilder fontBuilder = new FontBuilder()
			.setUnderline(UNDERLINE_FONT_CACHE_PROPERTY.equals(cacheKey));
		
		if (c instanceof JComponent) {
			JComponent jc = (JComponent)c;
			Font f = UI.getClientProperty(jc, cacheKey, null);
			if (f == null) {
				Font baseFont = UI.getClientProperty(jc, BASE_FONT_PROPERTY, null);
				if (baseFont == null)
					baseFont = UI.getFont(c);
				fontBuilder.setBaseFont(baseFont);
				
				f = fontBuilder.build();
				jc.putClientProperty(cacheKey, f);
			}

			return f;
		}

		// fallback
		return fontBuilder
			.setBaseFont(UI.getFont(c))
			.build();
	}
	
	// public classes
	
	public static class View extends OptimizedPanel {
		
		// private

		private boolean selected;
		private transient CategoryList categoryList;
		private final Color backgroundColor;
		private Color promptColor;
		private String promptText;
		
		// public

		/**
		 * @since 3.8.10
		 */
		public View() {
			this(Category.DEFAULT_COLOR, Color.BLACK);
		}

		/**
		 * @since 4.6
		 */
		public View(final Color backgroundColor) {
			super(null);
			setOpaque(false);
			this.backgroundColor = Objects.requireNonNull(backgroundColor);
		}

		/**
		 * @deprecated Since 4.6
		 */
		@Deprecated
		public View(final Color backgroundColor, final Color foregroundColor) {
			this(backgroundColor);
		}

		@Override
		public Dimension getPreferredSize() {
			if (TK.isEmpty(categoryList)) {
				int fontSize = UI.getFont(this).getSize();
				int padding = 16;
				int rectHeight = fontSize + padding - 1;

				return new Dimension(super.getPreferredSize().width, rectHeight);
			}
			else {
				return CategoryListRenderer.getPreferredSize(this, categoryList);
			}
		}

		/**
		 * @since 3.8.10
		 */
		public void setCategoryList(final CategoryList value) { categoryList = value; }

		// protected

		@Override
		protected void paintComponent(final Graphics graphics) {
			super.paintComponent(graphics);

			if (selected && TK.isEmpty(categoryList) && !TK.isEmpty(promptText)) {
				Graphics2D g = (Graphics2D)graphics.create();
				UI.setTextAntialiasing(g, null);
				
				Font font = CategoryListRenderer.getFont(this, CategoryListRenderer.UNDERLINE_FONT_CACHE_PROPERTY);
				g.setFont(font);

				FontMetrics fm = g.getFontMetrics();
				g.setColor(TK.get(promptColor, MColor.BLACK));
				g.drawString(promptText, GAP, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
				g.dispose();
			}
			else {
				CategoryListRenderer.paint(this, (Graphics2D)graphics, categoryList, backgroundColor);
			}
		}

	}

}
