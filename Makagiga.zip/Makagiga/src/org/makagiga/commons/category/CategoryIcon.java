// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import java.awt.Component;
import java.awt.Graphics2D;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.color.MColorIcon;

/**
 * @since 3.4
 */
public class CategoryIcon extends MColorIcon {

	// public

	public CategoryIcon(final Category category) {
		super(category.getColor(), MIcon.getSmallSize(), category.getIcon());
		setPadding(1);
	}

	// protected

	@Override
	protected void paintBackground(final Component c, final Graphics2D g, final int x, final int y, final int w, final int h) {
		if (getColor() == null)
			setColor(Category.DEFAULT_COLOR);
		CategoryListRenderer.paintBackground(c, g, getColor(), null, x, y, w, h);
	}

}
