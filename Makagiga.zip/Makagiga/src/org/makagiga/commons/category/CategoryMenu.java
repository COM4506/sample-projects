// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import static org.makagiga.commons.UI.i18n;

import java.lang.ref.WeakReference;
import java.util.Objects;

import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.swing.MMenu;

/**
 * @since 3.0
 */
public class CategoryMenu extends MMenu {

	// private

	private final CategoryList categoryList;
	private final CategoryManager categoryManager;
	
	// public
	
	public CategoryMenu(final CategoryManager categoryManager, final String categories) {
		super(i18n("Category"));
		setPopupMenuVerticalAlignment(CENTER);
		this.categoryManager = Objects.requireNonNull(categoryManager);

		categoryList = new CategoryList(categoryManager, categories);

		CategoryList all = new CategoryList();
		all.addAll(categoryList);
		all.addAll(categoryManager.getCategorySet());
		int numLeft = all.size();
		for (Category i : all) {
			if (numLeft-- < 2)
				setAutoSplit(false);
		
			boolean selected = categoryList.contains(i);
			boolean add = !selected;
			addDefaultCheckBox(new Action(this, i, add), selected);
		}
		
		if (categoryManager.isEditable()) {
			setAutoSplit(false);
		
			if (Kiosk.actionSettings.get()) {
				if (!isEmpty())
					addSeparator();

				add(new MAction(i18n("Edit Categories...")) {
					@Override
					public void onAction() {
						CategoryMenu.this.categoryManager.showDialog(this.getSourceWindow());
					}
				} );
			}

			setAutoSplit(true);
		}
	}

	public CategoryList getCategoryList() { return categoryList; }

	public CategoryManager getCategoryManager() { return categoryManager; }

	// protected

	protected void onCategoryChange(final Category category) { }

	// private classes

	private static final class Action extends CategoryAction {

		// private

		private final boolean add;
		private final WeakReference<CategoryMenu> menuRef;

		// public

		@Override
		public void onAction() {
			CategoryMenu menu = menuRef.get();

			if (menu == null)
				return;

			Category category = getData();
			if (add)
				menu.categoryList.add(category);
			else
				menu.categoryList.remove(category);
			menu.onCategoryChange(category);
		}

		// private

		private Action(final CategoryMenu menu, final Category category, final boolean add) {
			super(category);
			menuRef = new WeakReference<>(menu);
			this.add = add;
		}

	}

}
