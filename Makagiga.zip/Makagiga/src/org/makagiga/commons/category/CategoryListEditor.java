// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import java.awt.Component;
import java.util.Objects;
import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;

import org.makagiga.commons.swing.MTable;

/**
 * @since 3.0
 */
public class CategoryListEditor<T> extends AbstractCellEditor implements TableCellEditor {

	// private

	private final CategoryManager categoryManager;
	private String categoryList;
	
	// public

	public CategoryListEditor(final CategoryManager categoryManager) {
		this.categoryManager = Objects.requireNonNull(categoryManager, "categoryManager");
	}

	public CategoryManager getCategoryManager() { return categoryManager; }

	@Override
	public Object getCellEditorValue() { return categoryList; }

	@Override
	public Component getTableCellEditorComponent(
		final JTable table,
		final Object value,
		final boolean isSelected,
		final int row,
		final int column
	) {
		categoryList = value.toString();
		CategoryMenu menu = new CategoryMenu(categoryManager, categoryList) {
			@Override
			protected void onCategoryChange(final Category category) {
				// HACK: do not invoke stopCellEditing and return null
				table.setValueAt(this.getCategoryList().toString(), row, column);
			}
		};
		MTable.showPopupMenu(table, row, column, menu);

		return null;
	}

}
