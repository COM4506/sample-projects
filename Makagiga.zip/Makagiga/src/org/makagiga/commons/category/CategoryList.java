// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;

/**
 * @since 3.0
 */
@Obsolete
public class CategoryList extends TreeSet<Category> {

	// public

	public static final char DEFAULT_SEPARATOR = ',';
	
	/**
	 * @since 4.4
	 */
	public static final String DEFAULT_SEPARATOR_STRING = ",";

	// public

	public CategoryList() { }

	public CategoryList(final CategoryManager categoryManager, final String categories) {
		add(categoryManager, categories);
	}

	/**
	 * @since 3.8.12
	 */
	@InvokedFromConstructor
	@Obsolete // confusing name
	public void add(final CategoryManager categoryManager, final String categories) {
		for (String i : toList(categories)) {
			if (i != null) {
				i = i.trim();
				if (!i.isEmpty())
					addCategory(categoryManager, i);
			}
		}
	}
	
	/**
	 * @since 4.4
	 */
	public Category addCategory(final CategoryManager cm, final String name) {
		Category c = cm.createCategory(name);
		add(c);
		
		return c;
	}

	/**
	 * @since 5.6
	 */
	public Category addCategory(final CategoryManager cm, final Hashtag hashtag) {
		return addCategory(cm, hashtag.getName());
	}

	/**
	 * @since 4.0
	 */
	public static int compare(final String list1, final String list2) {
		String s1 = Objects.toString(list1, "");
		String s2 = Objects.toString(list2, "");
		
		int i = TK.compareFirst(!s1.isEmpty(), !s2.isEmpty()); // non empty category list on top
		
		if (i != 0)
			return i;

		return s1.compareToIgnoreCase(s2);
	}

	/**
	 * @since 5.6
	 */
	public static String join(final Collection<String> categories) {
		if (categories.isEmpty())
			return "";

		return categories.stream()
			.map(i -> i.replace(Category.SEPARATOR, ' '))
			.collect(Collectors.joining(Category.SEPARATOR_STRING));
	}

	/**
	 * @since 5.2
	 */
	public String toDisplayString() {
		return TK.join(", ", this);
	}

	/**
	 * @since 4.0
	 */
	public static List<String> toList(final String categories) {
		return TK.fastSplit(categories, DEFAULT_SEPARATOR);
	}

	@Important
	@Override
	public String toString() {
		if (isEmpty())
			return "";

		return stream()
			.map(i -> i.toString().replace(Category.SEPARATOR, ' '))
			.collect(Collectors.joining(Category.SEPARATOR_STRING));
	}

}
