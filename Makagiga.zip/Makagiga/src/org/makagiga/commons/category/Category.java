// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Objects;
import javax.swing.Icon;

import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.mv.MRenderer;

/**
 * @mg.threadSafe
 *
 * @since 3.0
 */
public final class Category
implements
	Comparable<Category>,
	MRenderer.Renderable,
	Serializable
{
	private static final long serialVersionUID = -7649010919031915926L;
	
	// public

	/**
	 * @since 5.6
	 */
	public static final char SEPARATOR = ',';
	
	/**
	 * @since 5.6
	 */
	public static final String SEPARATOR_STRING = ",";

	/**
	 * @since 3.8.10
	 */
	public static final Color DEFAULT_COLOR = MColor.SKY_BLUE.getBrighter(60);

	// private

	private transient boolean noIcon;
	private transient CategoryIcon categoryIcon;
	private Color color;
	private int hash;
	private transient MIcon icon;
	private transient Object data;
	private String iconName;
	private String name;

	// public

	public Category(final String name) {
		this(name, null, null, null);
	}

	public Category(final String name, final Color color) {
		this(name, color, null, null);
	}

	public Category(final String name, final Color color, final String iconName) {
		this(name, color, iconName, null);
	}

	public Category(final String name, final Color color, final String iconName, final Object data) {
		this.name = Objects.requireNonNull(name);
		this.color = color;
		this.iconName = iconName;
		this.data = data;

		hash = Objects.hash(color, iconName, name);
	}

	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public static String validateName(final String name) {
		if (name == null)
			throw new IllegalArgumentException("Category name cannot be null");

		return name;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o)
			return true;
		
		if ((o == null) || (this.getClass() != o.getClass()))
			return false;

		Category category = (Category)o;

		return
			// NOTE: compareTo ignores case
			this.name.equals(category.name) &&
			Objects.equals(this.color, category.color) &&
			Objects.equals(this.iconName, category.iconName);
	}

	@Override
	public int hashCode() { return hash; }

	/**
	 * Returns a non-null icon with image and color.
	 *
	 * @see #getIcon()
	 *
	 * @since 3.4
	 */
	public synchronized CategoryIcon getCategoryIcon() {
		if (categoryIcon == null)
			categoryIcon = new CategoryIcon(this);

		return categoryIcon;
	}

	public Color getColor() { return color; }

	public Object getData() { return data; }

	/**
	 * Returns an icon with image only.
	 *
	 * @return {@code null} if no icon
	 *
	 * @see #getCategoryIcon()
	 */
	public synchronized Icon getIcon() {
		if (noIcon)
			return null;

		if (icon == null) {
			if (iconName == null) {
				noIcon = true;
			}
			else {
				icon = MIcon.fromFileURI(iconName, MIcon.getSmallSize());
				if (icon == null)
					noIcon = true;
			}
		}

		return icon;
	}

	public String getIconName() { return iconName; }

	public String getName() { return name; }

	@Important
	@Override
	public String toString() { return name; }

	// Comparable

	@Override
	public int compareTo(final Category o) {
		int i = this.name.compareToIgnoreCase(o.name);
		if (i == 0) {
			i = MColor.compare(
				TK.get(this.color, MColor.DEFAULT),
				TK.get(o.color, MColor.DEFAULT)
			) * -1;
		}

		return i;
	}

	// MRenderer.Renderable

	/**
	 * @since 3.6
	 */
	@Override
	public void setupRenderer(final MRenderer<?> r) {
		r.setIcon(getCategoryIcon());
		r.setText(toString());
	}

	// private

	// Serializable

	private void readObject(final ObjectInputStream input) throws ClassNotFoundException, IOException {
		input.defaultReadObject();

		Objects.requireNonNull(name);

		Object o = TK.deserialize(input, "data");
		if (o != null)
			data = o;
	}

	private void writeObject(final ObjectOutputStream output) throws IOException {
		output.defaultWriteObject();
		TK.serialize(output, "data", data);
	}

}
