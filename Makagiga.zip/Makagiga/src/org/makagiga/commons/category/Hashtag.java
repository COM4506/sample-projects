// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.category;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.ObjIntConsumer;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.TK;

/**
 * @since 5.6
 */
public final class Hashtag implements Serializable {

	// public

	public static final Comparator<Hashtag> BY_NAME_INSENSITIVE =
		Comparator.comparing(Hashtag::getName, String.CASE_INSENSITIVE_ORDER);

	// private

	private final int position;
	private final Object context;
	private final String name;

	// public

	@Override
	public boolean equals(final Object o) {
		if (o == this)
			return true;
		
		if (o == null)
			return false;
		
		if (o.getClass() != this.getClass())
			return false;
		
		Hashtag other = (Hashtag)o;
		
		return
			(this.position == other.position) &&
			this.name.equals(other.name) &&
			Objects.equals(this.context, other.context);
	}

	@Override
	public int hashCode() {
		return TK.hash(name.hashCode(), position, Objects.hash(context));
	}

	public Object getContext() { return context; }

	public String getName() { return name; }
	
	public int getPosition() { return position; }
	
	public static Hashtag of(final String name) {
		return new Hashtag(name, 0, null);
	}

	public static Hashtag of(final String name, final int position) {
		return new Hashtag(name, position, null);
	}

	public static Hashtag of(final String name, final int position, final Object context) {
		return new Hashtag(name, position, context);
	}

	public static List<Hashtag> parse(final CharSequence text) {
		if (text.length() == 0)
			return Collections.emptyList();

		MArrayList<Hashtag> result = new MArrayList<>();
		parse(text, result);
		
		return result;
	}

	public static void parse(final CharSequence text, final Collection<Hashtag> output) {
		parse(text, (name, position) -> output.add(new Hashtag(name, position, null)));
	}

	public static void parse(final CharSequence text, final Consumer<Hashtag> consumer) {
		parse(text, (name, position) -> consumer.accept(new Hashtag(name, position, null)));
	}

	public static void parse(final CharSequence text, final ObjIntConsumer<String> consumer) {
		Objects.requireNonNull(text);
		Objects.requireNonNull(consumer);

		int len = text.length();
		
		if (len == 0)
			return;

		int tagStart = -1;
		int tagEnd = -1;

		// Now I have only _one_ problem:
		for (int i = 0; i < len; i++) {
			char c = text.charAt(i);
			if (
				// #foo
				// ^...
				(c == '#') &&
				// Start of text or after a whitepace.
				// (^|\s)#foo
				//      ^...
				((i == 0) || Character.isWhitespace(text.charAt(i - 1)))
			) {
				flush(text, consumer, tagStart, tagEnd);

				tagStart = i;
			}
			else if (tagStart != -1) {
				// Check if starts with a valid character.
				// #(foo|_)
				//  ^...
				boolean alpha = Character.isLetter(c) || (c == '_');

				// Hashtag cannot start with a digit, etc.
				// #123foo
				//  ^...
				if ((i == tagStart + 1) && !alpha) {
					tagStart = -1;
					
					continue; // for
				}

				// Consume a valid character.
				// #(foo|123)
				//  ^...
				if (alpha || Character.isDigit(c))
					tagEnd = i;

				// EOF or a whitespace separator.
				// #foo(\s|$)
				//     ^...
				if ((i == len - 1) || Character.isWhitespace(c)) {
					flush(text, consumer, tagStart, tagEnd);
					tagStart = -1;
					
					continue; // for
				}
			}
		}
	}

	@Override
	public String toString() { return name; }

	public Hashtag withContext(final Object context) {
		if (Objects.equals(this.context, context))
			return this;

		return new Hashtag(this.name, this.position, context);
	}

	public Hashtag withPosition(final int position) {
		if (this.position == position)
			return this;

		return new Hashtag(this.name, position, this.context);
	}

	// private
	
	private Hashtag(final String name, final int position, final Object context) {
		Objects.requireNonNull(name);

		if (name.length() < 2)
			throw new IllegalArgumentException("Invalid name: " + name);

		if (name.charAt(0) != '#')
			throw new IllegalArgumentException("Invalid name: " + name);

		this.name = name;
		this.position = position;
		this.context = context;
	}

	private static void flush(final CharSequence text, final ObjIntConsumer<String> consumer, final int start, final int end) {
		if ((start != -1) && (end != -1))
			consumer.accept(text.subSequence(start, end + 1).toString(), start);
	}

}
