// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.crypto;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.makagiga.commons.TK;

/**
 * A Password-Based Encryption helper.
 *
 * @mg.threadSafe
 * 
 * @since 2.2
 */
public final class PBEInfo {

	// public

	/**
	 * The default transformation ("PBEWithSHA1AndDESede").
	 *
	 * @since 2.4
	 */
	public static final String DEFAULT_TRANSFORMATION = "PBEWithSHA1AndDESede";
	
	// private

	private final boolean valid;
	private byte[] iv;
	private byte[] salt;
	private final int iterationCount;
	private PBEParameterSpec paramSpec;
	private final SecretKey secretKey;
	private String transformation;
	
	// public
	
	/**
	 * Constructs an invalid PBE info.
	 *
	 * @see #isValid()
	 *
	 * @since 4.10
	 */
	public PBEInfo() {
		iterationCount = 20;
		secretKey = null;
		valid = false;
	}

	/**
	 * Constructs a valid PBE info.
	 *
	 * @param password the password used in encryption/decryption
	 * @param transformation the transformation algorithm (example: "PBEWithSHA1AndDESede")
	 * @param salt the random salt (@c null - to automatically create a new random salt)
	 *
	 * @throws IllegalArgumentException If @p password is empty
	 * @throws InvalidKeySpecException If @c PBEKeySpec is invalid
	 * @throws NoSuchAlgorithmException If @p transformation is invalid
	 * @throws NullPointerException If @p password or @p transformation is @c null
	 *
	 * @since 3.6
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public PBEInfo(final char[] password, final String transformation, final byte[] salt) throws InvalidKeySpecException, NoSuchAlgorithmException {
		this(password, transformation, salt, 20, null);
	}

	/**
	 * @since 5.0
	 */
	public PBEInfo(final char[] password, final String transformation, final byte[] salt, final int iterationCount, final byte[] iv) throws InvalidKeySpecException, NoSuchAlgorithmException {
		checkPassword(password);
		this.transformation = Objects.requireNonNull(transformation, "transformation");
		initSalt(salt);
		this.iterationCount = iterationCount;
		this.iv = (iv == null) ? null : iv.clone();
		this.secretKey = createSecretKey(password);
		valid = true;
	}

	/**
	 * Constructs a valid PBE info.
	 *
	 * @param secretKey the secret key used in encryption/decryption
	 * @param salt the random salt (@c null - to automatically create a new random salt)
	 *
	 * @throws NullPointerException If @p secretKey is @c null
	 *
	 * @since 2.4
	 */
	public PBEInfo(final SecretKey secretKey, final byte[] salt) {
		iterationCount = 20;
		this.secretKey = Objects.requireNonNull(secretKey, "secretKey");
		initSalt(salt);
		valid = true;
	}

	/**
	 * Clears the salt value.
	 */
	public synchronized void clear() {
		CryptoUtils.clear(salt);
	}

	/**
	 * Creates and returns a new @c Cipher.
	 *
	 * @param mode the cipher mode (@c Cipher.DECRYPT_MODE or @c Cipher.ENCRYPT_MODE)
	 *
	 * @throws Exception If error
	 */
	public synchronized Cipher createCipher(final int mode) throws Exception {
		return createCipher(mode, transformation);
	}

	/**
	 * Creates and returns a new @c Cipher.
	 *
	 * @param mode the cipher mode (@c Cipher.DECRYPT_MODE or @c Cipher.ENCRYPT_MODE)
	 * @param transformation the transformation algorithm compatible with the current secret key
	 *
	 * @throws Exception If error
	 *
	 * @since 3.6
	 */
	public synchronized Cipher createCipher(final int mode, final String transformation) throws Exception {
		if (paramSpec == null) {
			if (iv != null)
				paramSpec = new PBEParameterSpec(salt, iterationCount, new IvParameterSpec(iv));
			else
				paramSpec = new PBEParameterSpec(salt, iterationCount);
		}

		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(mode, secretKey, paramSpec);

		return cipher;
	}

	/**
	 * Creates and returns a {@code javax.crypto.Mac} for {@code this PBEInfo}.
	 * The {@code javax.crypto.Mac} is initialized with
	 * {@code algorithm} and key of {@code this PBEInfo}.
	 *
	 * @param algorithm the {@code javax.crypto.Mac} algorithm
	 *
	 * @return {@code javax.crypto.Mac} for {@code this PBEInfo}
	 *
	 * @throws IllegalArgumentException If {@code algorithm} is {@code null} or empty
	 * @throws InvalidKeyException If key of {@code this PBEInfo} is invalid or unsupported
	 * @throws NoSuchAlgorithmException If {@code algorithm} is invalid
	 *
	 * @since 3.8.5
	 */
	public synchronized Mac createMac(final String algorithm) throws InvalidKeyException, NoSuchAlgorithmException {
		TK.checkNullOrEmpty(algorithm);

		Mac mac = Mac.getInstance(algorithm);
		mac.init(secretKey);

		return mac;
	}

	/**
	 * @since 5.0
	 */
	public int getIterationCount() { return iterationCount; }

	/**
	 * @since 5.0
	 */
	public byte[] getIV() {
		return (iv == null) ? null : iv.clone();
	}

	/**
	 * Returns a copy of the salt.
	 *
	 * @since 3.6
	 */
	public synchronized byte[] getSalt() {
		return salt.clone();
	}
	
	/**
	 * Returns the transformation or @c null.
	 *
	 * @since 2.4
	 */
	public String getTransformation() { return transformation; }

	/**
	 * @since 4.10
	 */
	public boolean isValid() { return valid; }

	// private

	private void checkPassword(final char[] password) {
		Objects.requireNonNull(password, "password");

		if (password.length == 0)
			throw new IllegalArgumentException("Password cannot be empty");
	}

	private SecretKey createSecretKey(final char[] password) throws InvalidKeySpecException, NoSuchAlgorithmException {
		PBEKeySpec keySpec = new PBEKeySpec(password);
		SecretKeyFactory factory = SecretKeyFactory.getInstance(transformation);
		SecretKey result = factory.generateSecret(keySpec);
		keySpec.clearPassword();

		return result;
	}

	private void initSalt(final byte[] value) {
		salt = (value == null) ? CryptoUtils.createSalt(9) : value.clone();
	}
	
}
