// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.crypto;

import static org.makagiga.commons.UI.i18n;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.security.MPermission;

/**
 * @since 3.4
 */
public final class MasterKey {

	// private

	private static byte[] data;
	private static long lastUse = System.currentTimeMillis();
	private static SecretKey key;

	// public

	/**
	 * @since 4.2
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static PBEInfo createPBEInfo(final String transformation, final byte[] salt) throws Exception {
		return createPBEInfo(transformation, salt, 20, null);
	}

	/**
	 * @since 5.0
	 */
	public synchronized static PBEInfo createPBEInfo(final String transformation, final byte[] salt, final int iterationCount, final byte[] iv) throws Exception {
		char[] password = getMasterPassword();
		try {
			return new PBEInfo(password, transformation, salt, iterationCount, iv);
		}
		finally {
			CryptoUtils.clear(password);
		}
	}

	public synchronized static void deletePrivateData() {
		checkPermission(false);

		CryptoUtils.clear(data);
		data = null;
		key = null;
		lastUse = System.currentTimeMillis();
	}
	
	/**
	 * @since 4.4
	 */
	public static char[] getMasterPassword() throws Exception {
		checkPermission(true);

		if (checkExpired())
			return null;

		if ((data == null) || (key == null))
			return null;

		lastUse = System.currentTimeMillis();

		// decrypt password
		return new String(doFinal(Cipher.DECRYPT_MODE, data), StandardCharsets.UTF_8).toCharArray();
	}
	
	/**
	 * @since 4.4
	 */
	public synchronized static boolean isMasterPassword() {
		if (checkExpired())
			return false;
	
		return (data != null);
	}
	
	/**
	 * @since 4.2
	 */
	public synchronized static boolean setMasterPassword(final char[] password) {
		checkPermission(true);
		
		deletePrivateData(); // reset
		
		if ((password == null) || (password.length == 0))
			return true;
		
		try {
			// encrypt password
			KeyGenerator generator = KeyGenerator.getInstance("AES");
			generator.init(new SecureRandom());
			key = generator.generateKey();

			data = doFinal(Cipher.ENCRYPT_MODE, new String(password).getBytes(StandardCharsets.UTF_8));
			
			return true;
		}
		catch (Exception exception) {
			MLogger.exception(exception);
		
			deletePrivateData();
			
			return false;
		}
	}

	// private

	@Uninstantiable
	private MasterKey() {
		TK.uninstantiable();
	}

	private synchronized static boolean checkExpired() {
		// clear password if unused for 30+ minutes
		if (TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - lastUse) > 30) {
		//if (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - lastUse) > 30) { // TEST
			deletePrivateData();
		
			return true;
		}
		
		return false;
	}

	private static void checkPermission(final boolean requiresSecurityManager) {
		SecurityManager sm = System.getSecurityManager();
		
		if ((sm == null) && requiresSecurityManager)
			throw new SecurityException("No Security Manager");
		
		if (sm != null)
			sm.checkPermission(new MasterKey.Permission());
	}
	
	private static byte[] doFinal(final int mode, final byte[] bytes) throws Exception {
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		cipher.init(mode, key);

		return cipher.doFinal(bytes);
	}
	
	// public classes

	/**
	 * @since 3.8.7
	 */
	public static final class Permission extends MPermission {

		// public

		@Override
		public String getIconName() { return "ui/password"; }

		// private

		private Permission() {
			super("masterKey", ThreatLevel.HIGH, i18n("Master Password"));
		}

	}

}
