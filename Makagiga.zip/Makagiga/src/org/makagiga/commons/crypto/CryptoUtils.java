// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.crypto;

import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;
import javax.crypto.Mac;

import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * A low-level crypto helper.
 *
 * @since 2.2
 */
public final class CryptoUtils {
	
	// public
	
	/**
	 * Fills @p array with zero values.
	 * Does nothing if @p array is @c null.
	 */
	public static void clear(final byte[] array) {
		if (array != null)
			Arrays.fill(array, (byte)0);
	}

	/**
	 * Fills {@code password} with zero values.
	 * Does nothing if {@code password} is {@code null}.
	 *
	 * @param password the password to clear
	 */
	public static void clear(final char[] password) {
		if (password != null)
			Arrays.fill(password, '\0');
	}

	/**
	 * Returns a new byte array (of @p length elements) filled with random values.
	 * The random values are generated using @c java.security.SecureRandom.
	 *
	 * @throws NegativeArraySizeException If @p length is negative
	 * 
	 * @since 2.4
	 */
	public static byte[] createSalt(final int length) {
		byte[] result = new byte[length];
		new SecureRandom().nextBytes(result);
		
		return result;
	}

	/**
	 * Parses a comma-separated array of bytes.
	 * 
	 * @param string the comma-separated array of bytes
	 * 
	 * @return An empty array if @p string is @c null, empty, or does not contain any values
	 * 
	 * @throws ParseException If @p string contains invalid byte numbers
	 */
	public static byte[] parseByteArray(final String string) throws ParseException {
		if (string == null)
			return TK.EMPTY_BYTE_ARRAY;
		
		try {
			List<String> values = TK.fastSplit(string, ',');
			byte[] result = new byte[values.size()];
			for (int i = 0; i < result.length; i++)
				result[i] = Byte.parseByte(values.get(i));
			
			return result;
		}
		catch (NumberFormatException exception) {
			ParseException e = new ParseException(exception.getMessage(), 0);
			e.initCause(exception);
			
			throw e;
		}
	}

	/**
	 * Returns a comma-separated byte values of {@code array}.
	 *
	 * @return An empty string if {@code array} is empty
	 * 
	 * @throws NullPointerException If {@code array} is {@code null}
	 */
	public static String toString(final byte[] array) {
		StringJoiner result = new StringJoiner(",");
		for (byte i : array)
			result.add(Byte.toString(i));
		
		return result.toString();
	}
	
	// private
	
	@Uninstantiable
	private CryptoUtils() {
		TK.uninstantiable();
	}

	// public classes

	/**
	 * @since 3.8.5
	 */
	public static final class MacInputStream extends FilterInputStream {

		// private

		private final Mac mac;

		// public

		public MacInputStream(final InputStream input, final Mac mac) {
			super(input);
			this.mac = Objects.requireNonNull(mac);
		}

		public Mac getMac() { return mac; }

		@Override
		public int read() throws IOException {
			int i = in.read();
			if (i != -1)
				mac.update((byte)i);

			return i;
		}

		@Override
		public int read(final byte[] buf, final int offset, final int len) throws IOException {
			int i = in.read(buf, offset, len);
			if (i > 0)
				mac.update(buf, offset, i);

			return i;
		}

	}

	/**
	 * @since 3.8.5
	 */
	public static final class MacOutputStream extends FilterOutputStream {

		// private

		private final Mac mac;

		// public

		public MacOutputStream(final OutputStream output, final Mac mac) {
			super(output);
			this.mac = Objects.requireNonNull(mac);
		}

		public Mac getMac() { return mac; }

		@Override
		public void write(final int b) throws IOException {
			out.write(b);
			mac.update((byte)b);
		}

		@Override
		public void write(final byte[] buf, final int offset, final int len) throws IOException {
			out.write(buf, offset, len);
			mac.update(buf, offset, len);
		}

	}

}
