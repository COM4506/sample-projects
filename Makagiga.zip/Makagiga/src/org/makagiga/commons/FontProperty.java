// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Font;
import java.text.ParseException;
import java.util.StringJoiner;

/**
 * @since 2.0
 */
public class FontProperty extends Property<Font> {
	
	// public
	
	/**
	 * Constructs a property with default font.
	 * 
	 * @see UI#createDefaultFont()
	 * 
	 * @since 3.0
	 */
	public FontProperty() { }
	
	public FontProperty(final Font font) {
		super(font);
	}
	
	public FontProperty(final String name, final int style, final int size) {
		this(new Font(name, style, size));
	}
	
	@Override
	public synchronized Font get() {
		Font f = super.get();
		if (f == null) {
			f = UI.createDefaultFont();
			set(f);
			setDefaultValue(f);
		}
		
		return f;
	}
	
	/**
	 * @since 2.4
	 */
	@Override
	public Class<Font> getType() { return Font.class; }
	
	@Override
	public boolean isFontType() { return true; }
	
	@Override
	public void parse(final String value) throws ParseException {
		set(Font.decode(value));
	}

	@Override
	public void read(final Config config, final String key) {
		set(config.readFont(key, getDefaultValue()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, get());
	}

	@Override
	public String toString() {
		return toString(get());
	}

	/**
	 * Returns a {@code String} represenation of the {@code Font}.
	 * You can convert back the returned {@code String}
	 * using {@link java.awt.Font#decode(String)}.
	 *
	 * @param value the font
	 *
	 * @throws NullPointerException If {@code value} is {@code null}
	 */
	public static String toString(final Font value) {
		// JAVA BUG #4732794, Closed, will not be fixed
		// "(...) Its trivial for the few developers who want this to
		// write a method which constructs the necessary string."
		// -- Sun
		StringJoiner v = new StringJoiner("-");
		v.add(value.getName());
		switch (value.getStyle()) {
			case Font.PLAIN:
				v.add("PLAIN");
				break;
			case Font.ITALIC:
				v.add("ITALIC");
				break;
			case Font.BOLD:
				v.add("BOLD");
				break;
			case Font.BOLD + Font.ITALIC:
				v.add("BOLDITALIC");
				break;
			default:
				v.add("PLAIN");
				break;
		}
		v.add(Integer.toString(value.getSize()));
		
		return v.toString();
	}

}
