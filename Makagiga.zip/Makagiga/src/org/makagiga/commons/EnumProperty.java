// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.text.ParseException;

import org.makagiga.commons.annotation.Important;

public class EnumProperty<E extends Enum<?>> extends Property<E> {

	// private
	
	private final Class<E> type;
	private E[] enumValues;
	
	// public

	/**
	 * @mg.note
	 * Since version 4.2, the type returned by {@link #getType()}
	 * is automatically initialized from the non-{@code null} {@code value}.
	 *
	 * @since 2.0, 4.0 (public)
	 */
	public EnumProperty(final E value) {
		this(value, 0);
	}

	/**
	 * @since 4.4
	 */
	@SuppressWarnings("unchecked")
	public EnumProperty(final E value, final int options) {
		super(value, options);
		if (value != null)
			type = (Class<E>)value.getDeclaringClass();
		else
			type = null;
	}

	/**
	 * @see #getEnumValues()
	 * @see #getType()
	 *
	 * @since 3.0, 4.0 (public)
	 */
	public EnumProperty(final E value, final Class<E> type) {
		super(value);
		this.type = type;
	}

	/**
	 * @see #getEnumValues()
	 *
	 * @since 2.0, 4.0 (public)
	 *
	 * @deprecated Since 4.2
	 */
	@Deprecated
	public EnumProperty(final E value, final E[] enumValues) {
		super(value);
		this.enumValues = TK.copyOf(enumValues);
		type = null;
	}

	/**
	 * Returns an array of enum values or {@code null}.
	 *
	 * @since 2.0
	 */
	public E[] getEnumValues() {
		return TK.copyOf(initEnumValues());
	}
	
	/**
	 * @see #getEnumValues()
	 * 
	 * @since 2.0
	 *
	 * @deprecated As of 4.2, replaced by {@link #getEnumValues()}
	 */
	@Deprecated
	public boolean hasEnumValues() {
		return initEnumValues() != null;
	}

	@Override
	public Class<E> getType() { return type; }
	
	@Override
	public boolean isEnumType() { return true; }

	@Override
	public void parse(final String value) throws ParseException {
		set(value);
	}
	
	/**
	 * @since 1.2
	 */
	public static <T extends Enum<T>> T parse(final String name, final T defaultValue) {
		if (name == null)
			return defaultValue;
		
		try {
			return Enum.valueOf(defaultValue.getDeclaringClass(), name);
		}
		catch (IllegalArgumentException exception) { // quiet
			return defaultValue;
		}
	}
	
	public void set(final String name) {
		set(this, name);
	}

	@Override
	public void read(final Config config, final String key) {
		set(config.readValue("Enum", key, getDefaultValue().name()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, get());
	}

	/**
	 * @since 3.8.6
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	@SuppressWarnings("unchecked")
	public static <E extends Enum<?>> void set(final Property<E> property, final String name) {
		try {
			// E value = property.get();
			// ECJ error: The method valueOf(Class<T>, String) in the type Enum
			//            is not applicable for the arguments (Class<capture#5-of ?>, String)
			Enum<?> value = property.get();

			property.set((E)Enum.valueOf(value.getDeclaringClass(), name));
		}
		catch (IllegalArgumentException exception) { // quiet
			property.reset();
		}
	}

	@Important
	@Override
	public String toString() {
		return get().name();
	}

	// private

	@SuppressWarnings("PMD.MethodReturnsInternalArray")
	private synchronized E[] initEnumValues() {
		if ((enumValues == null) && (type == null))
			return null;

		if (enumValues == null)
			enumValues = type.getEnumConstants();

		return enumValues;
	}
	
}
