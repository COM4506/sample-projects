// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mods;

import java.util.Collection;

import org.makagiga.commons.CollectionMap;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.security.MPermission;

/**
 * Modify OK/Cancel panel background
 * @mg.example
 * <pre class="brush: java">
 * Mods.add(MPanel.MOD_ADD_NOTIFY, new Mod() {
 *   {@literal @}Override
 *   public Object exec(Object source, String command, Object... args) {
 *     if (source instanceof MButtonPanel) {
 *       MButtonPanel buttonPanel = (MButtonPanel)source;
 *       buttonPanel.setPainter(new GlassPainter(MColor.SKY_BLUE, GlassPainter.RoundType.NONE));
 *     }
 *     return null;
 *   }
 * } );
 * </pre>
 *
 * Invert icon color
 * @mg.example
 * <pre class="brush: java">
 * Mods.add(DefaultIconLoader.MOD_LOAD, new Mod() {
 *   {@literal @}Override
 *   public Object exec(Object source, String command, Object... args) {
 *     if ((source instanceof DefaultIconLoader) &amp;&amp; (args.length == 3)) {
 *       MIcon icon = (MIcon)args[0];
 *       if ((icon != null) &amp;&amp; (icon.getImage() != null))
 *         return icon.getFilteredInstance(new com.jhlabs.image.InvertFilter());
 *     }
 *     return null;
 *   }
 * } );
 * </pre>
 *
 * @since 3.4
 */
public final class Mods {

	// public

	/**
	 * @see org.makagiga.commons.swing.MDialog#MOD_CLOSE
	 *
	 * @since 3.8.4
	 */
	public static final String DIALOG_CLOSE = "close@org.makagiga.commons.swing.MDialog";

	/**
	 * @see org.makagiga.commons.swing.MDialog#MOD_EXEC
	 *
	 * @since 3.8.4
	 */
	public static final String DIALOG_EXEC = "exec@org.makagiga.commons.swing.MDialog";

	/**
	 * @since 4.2
	 */
	public static final String GET_MORE_PLUGINS_PROPERTY = "org.makagiga.commons.mods.Mods.GET_MORE_PLUGINS_PROPERTY";

	// private

	private static CollectionMap<String, Mod> commandMap = new CollectionMap<>(
		CollectionMap.MapType.SYNCHRONIZED_HASH_MAP,
		CollectionMap.CollectionType.SYNCHRONIZED_ARRAY_LIST
	);
	
	// public

	public static void add(final String command, final Mod mod) {
		validateCommand(command);

		if (!checkPermission(command))
			return;

		commandMap.add(command, mod);
	}

	/**
	 * @since 3.8.8
	 */
	public static boolean contains(final String command) {
		return commandMap.containsKey(command);
	}

	public static void remove(final String command, final Mod mod) {
		Collection<Mod> modList = commandMap.get(command);
		if (modList != null) {
			if (!checkPermission(command))
				return;
			
			modList.remove(mod);
		}
	}

	/**
	 * @since 3.8.8
	 */
	public static void replace(final String command, final Mod mod) {
		validateCommand(command);

		if (!checkPermission(command))
			return;

		commandMap.remove(command);
		commandMap.add(command, mod);
	}

	public static Object exec(final Object source, final String command, final Object... args) {
		Collection<Mod> modList = commandMap.get(command);
		if (modList != null) {
			try {
				Object result = null;
				for (Mod i : modList) {
					result = i.exec(source, command, (args == null) ? TK.EMPTY_STRING_ARRAY : args);
				}

				return result;
			}
			catch (SecurityException exception) {
				MLogger.warning("mods", "No permission to execute: " + command);

				return null;
			}
			catch (Throwable exception) { // catch all
				MLogger.warning("mods", "Failed: " + command);
				MLogger.exception(exception);

				return null;
			}
		}
		else {
			return null;
		}
	}

	// private

	@Uninstantiable
	private Mods() {
		TK.uninstantiable();
	}

	private static boolean checkPermission(final String name) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			try {
				sm.checkPermission(new Mods.Permission(name));
			}
			catch (SecurityException exception) {
				MLogger.exception(exception);
				
				return false;
			}
		}

		return true;
	}

	private static void validateCommand(final String command) {
		if (
			(command == null) ||
			(command.indexOf('@') == -1)
		)
			throw new IllegalArgumentException("Mod command must be in format: Command@ClassName (example: exec@org.makagiga.commons.swing.MDialog)");
	}

	// public classes

	public static final class Permission extends MPermission {

		// private

		private Permission(final String name) {
			super(
				name,
				ThreatLevel.HIGH,
				"User Interface Modifications"
			);
			setActions("install");
		}

	}

}
