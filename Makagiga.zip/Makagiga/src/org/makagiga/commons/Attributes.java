// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * A simple attributes.
 *
 * @param <K> the type of the key/name
 * @param <V> the type of the value
 *
 * @mg.threadSafe
 *
 * @since 3.8
 */
public class Attributes<K, V> implements Serializable {
	private static final long serialVersionUID = 99393030233996406L;

	// private

	private final Map<K, V> backend;
	private final Map<K, V> readOnlyBackend;
	
	// public

	/**
	 * Constructs an empty attributes with default {@code java.util.HashMap} backend.
	 */
	public Attributes() {
		this.backend = new HashMap<>();
		this.readOnlyBackend = Collections.unmodifiableMap(backend);
	}

	/**
	 * Constructs attributes with the specified <i>backend map</i>.
	 *
	 * @param backend the <i>backend map</i>
	 *
	 * @throws NullPointerException If {@code backend} is {@code null}
	 */
	public Attributes(final Map<K, V> backend) {
		this.backend = Objects.requireNonNull(backend);
		this.readOnlyBackend = Collections.unmodifiableMap(backend);
	}

	/**
	 * @since 4.0
	 */
	public Attributes(final Attributes<? extends K, ? extends V> attributes) {
		this();
		this.backend.putAll(attributes.backend);
	}

	/**
	 * Removes all attributes.
	 */
	public void clear() {
		synchronized (this) {
			backend.clear();
		}
	}

	/**
	 * Returns the value specified by the {@code key}.
	 *
	 * @param key the key/name of the attribute
	 *
	 * @mg.note The returned value may be {@code null}.
	 *
	 * @return the value specified by the {@code key}.
	 */
	public V get(final K key) {
		synchronized (this) {
			return backend.get(key);
		}
	}

	/**
	 * Returns the value specified by the {@code key}.
	 *
	 * @param <T> the type of the returned value
	 * @param key the key/name of the attribute
	 * @param defaultValue the value returned if attribute does not exist,
	 * or if its value is {@code null}
	 *
	 * @return the value specified by the {@code key}.
	 */
	@SuppressWarnings("unchecked")
	public <T extends V> T get(final K key, final T defaultValue) {
		V value = get(key);

		return (value == null) ? defaultValue : (T)value;
	}

	/**
	 * Sets the attribute value.
	 *
	 * @param key the key/name of the attribute
	 * @param value the attribute value
	 */
	public void set(final K key, final V value) {
		synchronized (this) {
			backend.put(key, value);
		}
	}

	/**
	 * @since 4.0
	 */
	public Map<K, V> getMap() { return readOnlyBackend; }

	/**
	 * Returns {@code true} if no attributes.
	 *
	 * @return {@code true} if no attributes.
	 *
	 * @see #size()
	 */
	public boolean isEmpty() {
		synchronized (this) {
			return backend.isEmpty();
		}
	}

	/**
	 * Returns the number of attributes.
	 *
	 * @return the number of attributes.
	 *
	 * @see #isEmpty()
	 */
	public int size() {
		synchronized (this) {
			return backend.size();
		}
	}

}
