// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.text.ParseException;

/**
 * An @c int property.
 * 
 * @mg.example
 * <pre class="brush: java">
 * public static final IntegerProperty myProperty = new IntegerProperty(10);
 * ...
 * if (myProperty.get() == 10) {
 *   ...
 * }
 * </pre>
 * 
 * @mg.warning This class is <b>not</b> thread-safe.
 */
public class IntegerProperty extends NumberProperty<Integer> {

	// public

	/**
	 * Constructs an @c int property.
	 * The default value is @c 0.
	 */
	public IntegerProperty() {
		super(0);
	}

	/**
	 * Constructs an @c int property with @p value.
	 */
	public IntegerProperty(final int value) {
		super(value);
	}

	/**
	 * @since 4.0
	 */
	public IntegerProperty(final int value, final int options) {
		super(value, options);
	}

	/**
	 * Constructs an @c int property with @p value.
	 *
	 * @see #parse(String)
	 *
	 * @throws ParseException If @p value is invalid
	 *
	 * @since 2.0
	 */
	public IntegerProperty(final String value) throws ParseException {
		parse(value);
		setDefaultValue(get());
	}

	/**
	 * @since 4.0
	 */
	public int get(final int minValue, final int maxValue) {
		return TK.limit(get(), minValue, maxValue);
	}

	/**
	 * @since 2.4
	 */
	@Override
	public Class<Integer> getType() { return Integer.class; }
	
	@Override
	public boolean isIntegerType() { return true; }

	/**
	 * Converts a @c String @p value (signed decimal integer) to @c int.
	 * 
	 * @throws ParseException If @p value is invalid
	 */
	@Override
	public void parse(final String value) throws ParseException {
		try {
			set(Integer.valueOf(value));
		}
		catch (NumberFormatException exception) {
			parseError(exception);
		}
	}

	@Override
	public void read(final Config config, final String key) {
		set(config.readInt(key, getDefaultValue()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, get().intValue());
	}

}
