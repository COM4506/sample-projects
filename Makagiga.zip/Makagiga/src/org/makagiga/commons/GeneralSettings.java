// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static org.makagiga.commons.UI.i18n;

import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MLinkButton;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MSettingsPage;
import org.makagiga.commons.swing.MSystemTray;
import org.makagiga.commons.swing.MText;
import org.makagiga.commons.swing.MTextField;
import org.makagiga.commons.swing.MTip;
import org.makagiga.commons.swing.MWrapperPanel;

/**
 * The "General" settings.
 * 
 * @since 3.0, 4.0 (org.makagiga.commons package)
 */
public class GeneralSettings extends MSettingsPage {

	// private

	private boolean oldSystemTray;
	private MTextField browserField;
	
	// package
	
	static boolean inTest;
	boolean openCommandOnly;

	// public

	/**
	 * Constructs a "General" settings.
	 */
	public GeneralSettings() {
		super(i18n("General"));
	}
	
	@Override
	public MSettingsPage createAdvancedPage() {
		if (openCommandOnly)
			return null;

		return new Advanced();
	}

	// protected
	
	@Override
	protected void onClose() {
		super.onClose();
		browserField = null;
	}

	@Override
	protected void onInit() {
		if (!openCommandOnly) {
			bind(MApplication.confirmExit, i18n("Confirm Exit"));
		
			boolean systemTraySupported = MSystemTray.isSupported();
			addSeparator(i18n("System Tray"));
			
			if (!systemTraySupported)
				add(MLabel.createSmall(i18n("Not supported on this platform"), MIcon.small("ui/info")));
			
			oldSystemTray = UI.systemTray.get();
			bind(UI.systemTray, i18n("Show System Tray Icon"))
				.setEnabled(systemTraySupported);
			bind(UI.hideMainWindowInTray, i18n("Hide Main Window in Tray"))
				.setEnabled(systemTraySupported);
			if (systemTraySupported)
				bind(UI.systemTray, "selected", UI.hideMainWindowInTray, "enabled");
		}
		
		if (!OS.isDesktopAPIReliable()) {
			addSeparator(i18n("Browser"));

			MPanel p = bindPanel(OS.openCommand, i18n("Open Links/Files With:"));
			browserField = MWrapperPanel.getWrappedView(p);

			browserField.setAutoCompletion("browser");
			AutoCompletion ac = MText.getAutoCompletion(browserField);
			for (Tuple.Three<String, String, Boolean> i : OS.getOpenCommands()) {
				if (!i.get1().isEmpty())
					ac.addStaticItem(i.get2());
			}

			browserField.setColumns(25);
			UI.setHTMLHelp(
				browserField,
				i18n("Enter a command used to open external files<br>and web addresses.") + "<br>" +
				"<br>" +
				i18n("{0} - the link address", "<b>%u</b>")
			);

			MPanel eastPanel = MPanel.createHBoxPanel();

			MButton insertButton = new MButton(i18n("Insert"));
			insertButton.setPopupMenu(() -> {
				MMenu menu = new MMenu();
				menu.addTitle(i18n("Command"));
				OS.getOpenCommands().forEach(tuple -> {
					tuple.accept((command, text, installed) -> {
						if (command.isEmpty())
							menu.addSeparator();
						else
							menu.add(new SetOpenCommandAction(browserField, command, text, installed));
					} );
				} );
				
				return menu;
			} );
			eastPanel.add(insertButton);

			eastPanel.addContentGap();

			MLinkButton testButton = new MLinkButton(i18n("Test"));
			testButton.setToolTipText(UI.getLinkToolTipText(MApplication.getHomePage()));
			testButton.addActionListener(e -> {
				inTest = true;
				String oldLauncher = OS.openCommand.get();
				try {
					String newLauncher = browserField.getText();
					OS.openCommand.set(newLauncher);
					MApplication.openURI(MApplication.getHomePage());
				}
				finally {
					OS.openCommand.set(oldLauncher);
					inTest = false;
				}
			} );
			eastPanel.add(testButton);

			p.addEast(eastPanel);
		}
	}

	@Override
	protected void onOK() {
		if (browserField != null)
			browserField.saveAutoCompletion();

		// do not initialize MSystemTray class if tray icon is disabled
		if (!openCommandOnly && !UI.systemTray.equalsValue(oldSystemTray)) {
			oldSystemTray = UI.systemTray.get();
			MSystemTray.setVisible(UI.systemTray.get());
		}
	}

	// public classes

	public static class Advanced extends MSettingsPage {
		
		// public
		
		public Advanced() {
			super(i18n("General"));

			MButton button = new MButton(i18n("Enable All Tips"));
			button.addActionListener(e -> {
				MTip.reset();
				button.setEnabled(false);
				button.showFeedback(MIcon.small("ui/ok"));
			} );
			add(button);
		}

	}
	
	// private classes
	
	private static final class SetOpenCommandAction extends MText.InsertAction {
	
		// public
		
		public SetOpenCommandAction(final MTextField textField, final String name, final String command, final boolean installed) {
			super(
				textField,
				command.isEmpty() ? name : name + " (" + command + ")",
				command
			);
			if (installed)
				setIconName("ui/ok");
		}
		
		// protected
		
		@Override
		protected void insertText(final String text) {
			get().setText(text); // replace
		}
	
	}

}
