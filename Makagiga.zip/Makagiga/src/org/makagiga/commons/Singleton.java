// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.util.Objects;
import java.util.function.Supplier;

import org.makagiga.commons.annotation.DesignPattern;

/**
 * A lazily initialized "singleton" object.
 * It uses a "double-checked locking" to ensure thread-safety.
 *
 * @mg.example
 * <pre class="brush: java">
 * private static final Singleton&lt;HeavyObject&gt; INSTANCE = new Singleton&lt;&gt;(HeavyObject::new);
 * (...)
 * public HeavyObject getInstance() {
 *     return INSTANCE.get();
 * }
 * </pre>
 *
 * @mg.threadSafe
 *
 * @since 5.0
 *
 * @see <a href="http://en.wikipedia.org/wiki/Double-checked_locking#Usage_in_Java">http://en.wikipedia.org/wiki/Double-checked_locking#Usage_in_Java</a>
 * @see <a href="http://www.cs.umd.edu/~pugh/java/memoryModel/DoubleCheckedLocking.html">http://www.cs.umd.edu/~pugh/java/memoryModel/DoubleCheckedLocking.html</a>
 */
@DesignPattern(DesignPattern.SINGLETON)
public final class Singleton<T> implements Supplier<T> {

	// private
	
	private final Supplier<T> supplier;
	private volatile T value;

	// public

	public Singleton(final Supplier<T> supplier) {
		this.supplier = Objects.requireNonNull(supplier);
	}

	@Override
	public T get() {
		if (value == null) {
			synchronized (this) {
				if (value == null)
					value = supplier.get();
			}
		}
		
		return value;
	}

}
