// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.form;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Window;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URI;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.event.DocumentEvent;
import javax.swing.text.JTextComponent;

import org.makagiga.commons.BeanProperty;
import org.makagiga.commons.BooleanProperty;
import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.Config;
import org.makagiga.commons.FontProperty;
import org.makagiga.commons.IntegerProperty;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Property;
import org.makagiga.commons.StringProperty;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.swing.AbstractSpinner;
import org.makagiga.commons.swing.ContainerScanner;
import org.makagiga.commons.swing.MCheckBox;
import org.makagiga.commons.swing.MComponent;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MEditorPane;
import org.makagiga.commons.swing.MFontButton;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MLinkButton;
import org.makagiga.commons.swing.MNumberSpinner;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MPasswordField;
import org.makagiga.commons.swing.MText;
import org.makagiga.commons.swing.MTextField;
import org.makagiga.commons.swing.MTip;
import org.makagiga.commons.swing.MWrapperPanel;
import org.makagiga.commons.validator.Validator;

// TODO: 2.0: common properties, Icon support
/**
 * @mg.example
 * <pre class="brush: java">
 * // (...)
 * {@literal @}Form(order = "user,password")
 * public class LoginForm { // this can be static inner class, too
 *
 *   {@literal @}Field(label = "User Name:", required = true)
 *   private String user;
 *
 *   {@literal @}Field(label = "Password:")
 *   private char[] password;
 *
 * }
 * // (...)
 * LoginForm form = new LoginForm();
 * form.user = "joe"; // set default values...
 *
 * FormPanel&lt;LoginForm&gt; panel = new FormPanel&lt;&gt;(form);
 * MDialog dialog = panel.createDialog(null, "Enter Name and Password");
 * if (dialog.exec()) {
 *   // OK button pressed...
 *   System.out.println(form.user);
 *   // (...)
 * }
 * </pre>
 *
 * <table border="1">
 * <caption>Supported Data Types</caption>
 * <thead>
 * <tr>
 *   <td>Field Type</td><td>Created Component</td>
 * </tr>
 * </thead>
 * <tbody>
 * <tr>
 *   <td><code>boolean</code></td><td>{@link org.makagiga.commons.swing.MCheckBox}</td>
 * </tr>
 * <tr>
 *   <td><code>int</code></td><td>{@link org.makagiga.commons.swing.MNumberSpinner} ({@code Integer} type)</td>
 * </tr>
 * <tr>
 *   <td><code>char[]</code></td><td>{@link org.makagiga.commons.swing.MPasswordField}</td>
 * </tr>
 * <tr>
 *   <td><code>java.awt.Color</code></td><td>{@link org.makagiga.commons.color.MSmallColorChooser}</td>
 * </tr>
 * <tr>
 *   <td><code>java.lang.String</code></td><td>{@link org.makagiga.commons.swing.MTextField} or {@link org.makagiga.commons.swing.MEditorPane}</td>
 * </tr>
 * <tr>
 *   <td><code>java.awt.Font</code></td><td>{@link org.makagiga.commons.swing.MFontButton}</td>
 * </tr>
 * <tr>
 *   <td><code>java.net.URI</code></td><td>{@link org.makagiga.commons.swing.MLinkButton}</td>
 * </tr>
 * <tr>
 *   <td>Other data types with the {@code Field} annotation</td><td>Throws {@code IllegalArgumentException}</td>
 * </tr>
 * </tbody>
 * </table>
 *
 * @see Field
 * @see org.makagiga.commons.swing.MDialog
 *
 * @since 3.4, 4.0 (org.makagiga.commons.form package)
 */
public class FormPanel<F> extends PropertyPanel implements MDisposable {

	// private

	private boolean accept = true;
	private final F form;
	private final Map<String, JComponent> elements = new HashMap<>();
	private final MArrayList<Validator<Object>> validatorList = new MArrayList<>();
	private StaticHandler staticHandler;
	private String defaultComponent;
	
	// public
	
	public FormPanel(final F form) {
		this.form = Objects.requireNonNull(form, "form");

		staticHandler = new StaticHandler(this);

		Class<?> clazz = form.getClass();
		Form d = clazz.getAnnotation(Form.class);

		if (d == null)
			throw new IllegalArgumentException("\"form\" object does not contain \"Form\" annotation");

		setHighlightFocusedEditor(d.autoSelectAll());

		for (final java.lang.reflect.Field field : getOrderedFields(d, clazz)) {
			if (field.isAnnotationPresent(DefaultFocus.class)) {
				if (defaultComponent != null)
					throw new IllegalArgumentException("\"DefaultFocus\" annotation already set for \"" + defaultComponent + "\"");

				defaultComponent = field.getName();
			}

			// info

			Info info = field.getAnnotation(Info.class);
			if (info != null) {
				addInfo(info, field);

				continue; // for
			}

			final Field f = field.getAnnotation(Field.class);

			if (f == null)
				continue; // for

			boolean primitive = field.getType().isPrimitive();

			// primitive boolean - check box

			if (primitive && (field.getType() == boolean.class)) {
				createBooleanEditor(f, field);
			}

			// int primitive - number spinner

			else if (primitive && (field.getType() == int.class)) {
				createIntegerEditor(d, f, field);
			}

			// char array - password

			else if (field.getType() == char[].class) {
				if (!f.autoCompletion().isEmpty())
					throw new IllegalArgumentException("Cannot use \"autoCompletion\" with \"" + field + "\"");

				MPasswordField c = (MPasswordField)bind(char[].class, field, f.label(), MPasswordField.class);
				setupEditor(d, c, f, !c.isEmpty());
			}

			// Color - small color chooser

			else if (field.getType() == Color.class) {
				JComponent c = bind(Color.class, field, f.label());
				setupEditor(d, c, f, true);
			}

			// String - labeled text field, text area

			else if (field.getType() == String.class) {
				String text = (String)getFieldValue(field);
				if (text == null) {
					text = "";
					setFieldValue(field, text);
				}

				if (f.type() == Field.TYPE_EDITOR_PANE) {
					if (!f.autoCompletion().isEmpty())
						throw new IllegalArgumentException("Cannot use \"autoCompletion\" with \"" + field + "\"");

					MEditorPane stringField = new FormEditorPane(this, f, field);
					stringField.setText(text);
					stringField.setCaretPosition(0);

					MWrapperPanel<MEditorPane> wrapper = new MWrapperPanel<>(0, 5, UI.VERTICAL, stringField, f.label());
					addTextComponent(stringField, wrapper, stringField.isEmpty(), field, f);
				}
				// TYPE_AUTO
				else {
					MTextField c = (MTextField)bind(String.class, field, f.label());
					setupEditor(d, c, f, !c.isEmpty());
				}
			}

			// Font - font button

			else if (field.getType() == Font.class) {
				// null - use default button text
				String label = f.label().isEmpty() ? null : f.label();

				MFontButton c = (MFontButton)bind(Font.class, field, label);
				setupEditor(d, c, f, c.isSelected());
			}

			// URI - link button

			else if (field.getType() == URI.class) {
				URI uri = (URI)getFieldValue(field);
				addLink(field, uri, f.label());
			}

			// unsupported

			else {
				throw new IllegalArgumentException("Unsupported field type: " + field);
			}

			// find validators

			for (Class<? extends Validator<?>> validatorClass : f.validators()) {
				String name = field.getName();
				JComponent element = MWrapperPanel.getWrappedView(getComponent(name));
				if (element != null) {
					try {
						@SuppressWarnings("unchecked")
						Validator<Object> v = (Validator<Object>)validatorClass.newInstance();
						v.setComponent(element);
						validatorList.add(v);
					}
					catch (Exception exception) {
						MLogger.exception(exception);
					}
				}
			}
		}
	}

	/**
	 * Add all validators to {@code dialog}.
	 *
	 * @since 4.0
	 */
	public void addValidators(final MDialog dialog) {
		for (Validator<Object> validator : validatorList)
			dialog.getValidatorSupport().add(validator);
	}

	/**
	 * @since 4.0
	 */
	public boolean canAccept() { return accept; }

	/**
	 * @since 4.0
	 */
	public void setCanAccept(final boolean value) {
		accept = value;

		MDialog dialog = MDialog.of(this);
		if (dialog != null)
			dialog.getOKButton().setEnabled(accept);
	}

	/**
	 * @since 3.8.8
	 */
	public MDialog createDialog(final Window owner, final MActionInfo actionInfo) {
		return createDialog(owner, actionInfo, MDialog.STANDARD_DIALOG);
	}

	/**
	 * @since 3.8.8
	 */
	public MDialog createDialog(final Window owner, final MActionInfo actionInfo, final int flags) {
		return createDialog(owner, actionInfo.getDialogTitle(), actionInfo.getIconName(), flags);
	}

	public MDialog createDialog(final Window owner, final String title) {
		return createDialog(owner, title, (Icon)null, MDialog.STANDARD_DIALOG);
	}

	public MDialog createDialog(final Window owner, final String title, final Icon icon, final int flags) {
		Form formAnnotation = form.getClass().getAnnotation(Form.class);
		MDialog dialog = new MDialog(
			owner,
			(title == null) ? formAnnotation.label() : title,
			icon,
			flags
		) {
			@Override
			public boolean exec(JComponent defaultFocus) {
				FormPanel.this.alignLabels();

				if ((defaultFocus == null) && (FormPanel.this.defaultComponent != null))
					defaultFocus = FormPanel.this.getComponent(FormPanel.this.defaultComponent);

				return super.exec(defaultFocus);
			}
			@Override
			protected boolean onAccept() {
				FormPanel.this.saveAutoCompletion();

				// forward event to the FormPanel
				return FormPanel.this.onAccept();
			}
			@Override
			protected void onClose() {
				super.onClose();
				TK.dispose(FormPanel.this);
			}
			@Override
			protected void onUserClick() {
				// forward event to the FormPanel
				FormPanel.this.onUserClick();
			}
		};

		// install validators

		if (!validatorList.isEmpty()) {
			addValidators(dialog);
			dialog.installValidatorMessage();
		}

		dialog.addCenter(this);
		if (!canAccept())
			dialog.getOKButton().setEnabled(false);

		return dialog;
	}

	public MDialog createDialog(final Window owner, final String title, final String iconName) {
		return createDialog(owner, title, MIcon.stock(iconName), MDialog.STANDARD_DIALOG);
	}

	public MDialog createDialog(final Window owner, final String title, final String iconName, final int flags) {
		return createDialog(owner, title, MIcon.stock(iconName), flags);
	}

	public MDialog createSettingsDialog(final Window owner) {
		return createSettingsDialog(owner, MDialog.STANDARD_DIALOG);
	}

	public MDialog createSettingsDialog(final Window owner, final int flags) {
		MDialog dialog = createDialog(owner, MActionInfo.SETTINGS, flags | MDialog.COMPACT_HEADER);
		MPanel center = dialog.getMainPanel();
		if (center != null)
			center.setMargin(center.getContentMargin() * 2);

		return dialog;
	}
	
	/**
	 * @since 4.6
	 */
	public AutoCompletion getAutoCompletion(final String fieldName) {
		JComponent c = getComponent(fieldName);

		if (c instanceof MWrapperPanel<?>) {
			MWrapperPanel<?> panel = (MWrapperPanel<?>)c;
			c = panel.getView();
		}

		if (c instanceof AbstractSpinner<?, ?>)
			return MText.getAutoCompletion(AbstractSpinner.class.cast(c).getTextField());

		if (c instanceof JTextComponent)
			return MText.getAutoCompletion((JTextComponent)c);

		return null;
	}

	@SuppressWarnings("unchecked")
	public <T extends JComponent> T getComponent(final String name) {
		return (T)elements.get(name);
	}

	public F getForm() { return form; }

	/**
	 * @since 3.8
	 */
	@SuppressWarnings("unchecked")
	public <T extends JComponent> T getWrappedComponent(final String name) {
		JComponent c = getComponent(name);

		return (T)MWrapperPanel.getWrappedView(c);
	}

	public void makeDefault(final String name) {
		JComponent c = getComponent(name);
		MComponent.requestFocus(c);
	}

	/**
	 * @mg.warning Not implemented.
	 */
	public void readConfig(final Config config) { }

	public void writeConfig(final Config config) {
		saveAutoCompletion();
	}

	public void setEnabled(final String name, final boolean enabled) {
		JComponent c = getComponent(name);
		c.setEnabled(enabled);
	}

	public void setLabel(final String name, final String label) {
		JComponent element = getComponent(name);
		Class<?> elementClass = element.getClass();
		FieldEditor fieldEditor = elementClass.getAnnotation(FieldEditor.class);
		if (fieldEditor != null) {
			if (!fieldEditor.labelProperty().isEmpty()) {
				BeanProperty<String> bp = new BeanProperty<>(element, String.class, fieldEditor.labelProperty());
				bp.set(label);
			}
		}
		else if (element instanceof AbstractButton) { // MButton, MFontButton, MLinkButton
			AbstractButton ab = (AbstractButton)element;
			ab.setText(label);
		}
		else if (element instanceof MLabel) {
			MLabel l = (MLabel)element;
			l.setText(label);
		}
		else if (element instanceof MWrapperPanel<?>) {
			MWrapperPanel<?> w = (MWrapperPanel<?>)element;
			w.getLabel().setText(label);
		}
		else {
			throw new IllegalArgumentException("Element not found: " + name);
		}
	}

	public void setVisible(final String name, final boolean visible) {
		JComponent c = getComponent(name);

		if (c == null)
			throw new IllegalArgumentException("Element not found: " + name);

		c.setVisible(visible);
	}

	@Override
	public void updateView() {
		super.updateView();
		updateForm();
	}

	// MDisposable

	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		if (staticHandler != null) {
			uninstallPropertyChangeListeners(staticHandler);
			staticHandler = null;
		}
		elements.clear();
		validatorList.clear();
	}

	// protected

	/**
	 * @see org.makagiga.commons.swing.MDialog#onAccept()
	 *
	 * @since 3.8
	 */
	protected boolean onAccept() { return true; }

	/**
	 * @see org.makagiga.commons.swing.MDialog#onUserClick()
	 */
	protected void onUserClick() { }

	// private

	private void addComponent(final String style, final JComponent c) {
		if (getComponentCount() > 0)
			addGap();
		UI.setStyle(style, c);
		add(c);
	}

	private void addInfo(final Info info, final java.lang.reflect.Field field) {
		MLabel label;
		String style = info.style();
		String value = (String)getFieldValue(field);
		switch (info.type()) {
			case Info.TYPE_COOL:
				if (getComponentCount() > 0)
					addGap();
				label = addCoolHeader(value);
				label.setStyle(style);
				break;
			case Info.TYPE_HTML:
				label = new MLabel();
				label.setHTML(value);
				addComponent(style, label);
				break;
			case Info.TYPE_SEPARATOR:
				label = addSeparator(value);
				label.setStyle(style);
				break;
			case Info.TYPE_TEXT:
				label = new MLabel(value);
				addComponent(style, label);
				break;
			case Info.TYPE_TIP:
				MTip tip = new MTip(value);
				tip.showNextTip();
				label = tip;
				addComponent(style, label);
				break;
			default: // Info.TYPE_HEADER
				label = createHeaderLabel(null);
				
				// 1.
				if (!info.html())
					label.setHTMLEnabled(false);

				// 2.
				label.setText(value);

				addComponent(style, label);
				break;
		}
		putElement(field.getName(), label);
	}

	private void addLink(final java.lang.reflect.Field field, final URI uri, String text) {
		if ("".equals(text))
			text = Objects.toString(uri);
		MLinkButton urlButton = new MLinkButton();
		urlButton.setText(text);
		urlButton.setURI(uri);
		putElement(field.getName(), urlButton);
		urlButton.setName(field.getName());
		addComponent(null, urlButton);
	}

	private void addTextComponent(final JTextComponent textComponent, final MWrapperPanel<? extends JTextComponent> wrapper, final boolean empty, final java.lang.reflect.Field field, final Field f) {
		putElement(field.getName(), wrapper);
		wrapper.setName(field.getName());
		if (f.required() && empty)
			setCanAccept(false);
		UI.setStyle(f.style(), textComponent);
		addComponent(null, wrapper);
	}

	private JComponent bind(final Class<?> type, final java.lang.reflect.Field field, final String text) {
		return bind(type, field, text, null);
	}

	private JComponent bind(final Class<?> type, final java.lang.reflect.Field field, final String text, final Class<? extends JComponent> editorClass) {
		try {
			Field f = field.getAnnotation(Field.class);

			Property<?> p;
			if (type == Boolean.class)
				p = new BooleanFieldProperty(field, form);
			else if (type == char[].class)
				p = new PasswordFieldProperty(field, form);
			else if (type == Color.class)
				p = new ColorFieldProperty(field, form);
			else if (type == Font.class)
				p = new FontFieldProperty(field, form);
			else if (type == Integer.class)
				p = new IntegerFieldProperty(field, form);
			else if (type == String.class)
				p = new StringFieldProperty(field, form);
			else
				throw new WTFError("Unsupported type: " + type);

			JComponent c = bind(p, text, editorClass);
			putElement(field.getName(), c);
			c.setName(field.getName());

			// work on "wrapped" component:

			c = MWrapperPanel.getWrappedView(c);
			UI.setStyle(f.style(), c);

			p.addPropertyChangeListener(staticHandler);

			return c;
		}
		catch (IllegalAccessException exception) {
			MLogger.exception(exception);

			return null;
		}
	}

	private void createBooleanEditor(final Field f, final java.lang.reflect.Field field) {
		if (!f.autoCompletion().isEmpty())
			throw new IllegalArgumentException("Cannot use \"autoCompletion\" with \"" + field + "\"");

		MCheckBox c = (MCheckBox)bind(Boolean.class, field, f.label());
		setupEditor(null, c, f, c.isSelected());
	}

	private void createIntegerEditor(final Form form, final Field f, final java.lang.reflect.Field field) {
		@SuppressWarnings("unchecked")
		MNumberSpinner<Integer> c = (MNumberSpinner<Integer>)bind(Integer.class, field, f.label());
		IntegerRange r = field.getAnnotation(IntegerRange.class);
		if (r != null)
			c.setRange(r.minimum(), r.maximum());
		setupEditor(form, c, f, true);
	}

	private Object getFieldValue(final java.lang.reflect.Field field) {
		return getFieldValue(form, field);
	}

	private static Object getFieldValue(final Object form, final java.lang.reflect.Field field) {
		try {
			Method getterMethod = BeanProperty.getGetter(form.getClass(), field.getName());

			if (getterMethod != null)
				return getterMethod.invoke(form);
		}
		catch (Exception exception) {
			MLogger.exception(exception);
		}

		boolean updateAccessible = !Modifier.isPublic(field.getModifiers());
		try {
			if (updateAccessible)
				field.setAccessible(true);

			return field.get(form);
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			return null;
		}
		finally {
			if (updateAccessible)
				field.setAccessible(false);
		}
	}

	private void setFieldValue(final java.lang.reflect.Field field, final Object value) {
		try {
			Method setterMethod = BeanProperty.getSetter(form.getClass(), field.getName(), field.getType());
			if (setterMethod != null) {
				setterMethod.invoke(form, value);

				return;
			}
		}
		catch (Exception exception) {
			MLogger.exception(exception);
		}

		boolean updateAccessible = !Modifier.isPublic(field.getModifiers());
		try {
			if (updateAccessible)
				field.setAccessible(true);

			field.set(form, value);
		}
		catch (Exception exception) {
			MLogger.exception(exception);
		}
		finally {
			if (updateAccessible)
				field.setAccessible(false);
		}
	}

	private List<java.lang.reflect.Field> getOrderedFields(final Form formAnnotation, final Class<?> clazz) {
		java.lang.reflect.Field[] fields = AccessController.doPrivileged(new PrivilegedAction<java.lang.reflect.Field[]>() {
			@Override
			public java.lang.reflect.Field[] run() {
				return clazz.getDeclaredFields();
			}
		} );

		String[] order = formAnnotation.order();
		if (order.length == 0)
			MLogger.warning("form", "Add \"order()\" attribute: %s", formAnnotation.label());

		// "foo,bar"
		if ((order.length == 1) && order[0].contains(",")) {
			List<String> orderList = TK.fastSplit(order[0], ',');
			order = orderList.toArray(new String[orderList.size()]);
		}
		
		// normalize
		for (int i = 0; i < order.length; i++)
			order[i] = order[i].trim();
		
		LinkedHashMap<String, java.lang.reflect.Field> orderMap = new LinkedHashMap<>(fields.length);
		for (java.lang.reflect.Field i : fields)
			orderMap.put(i.getName(), i);

		return TK.order(orderMap, order);
	}

	private void putElement(final String name, final JComponent component) {
		elements.put(name, component);
	}

	private void saveAutoCompletion() {
		for (JComponent i : elements.values()) {
			if (i instanceof MText.TextFieldExtensions) {
				MText.TextFieldExtensions.class.cast(i).saveAutoCompletion();
			}
			else if (i instanceof JTextComponent) {
				MText.saveAutoCompletion((JTextComponent)i);
			}
			else if (i instanceof MWrapperPanel<?>) {
				MWrapperPanel<?> w = (MWrapperPanel<?>)i;
				JComponent e = w.getView();
				if (e instanceof MText.TextFieldExtensions)
					MText.TextFieldExtensions.class.cast(e).saveAutoCompletion();
			}
		}
	}

	private void setupEditor(final Form form, final JComponent c, final Field f, final boolean canAccept) {
		if ((c instanceof MText.TextFieldExtensions) && !f.autoCompletion().isEmpty())
			MText.TextFieldExtensions.class.cast(c).setAutoCompletion(f.autoCompletion());

		if ((form != null) && form.autoSelectAll()) {
			JTextComponent textComponent;
			if (c instanceof AbstractSpinner<?, ?>)
				textComponent = AbstractSpinner.class.cast(c).getTextField();
			else if (c instanceof JTextComponent)
				textComponent = (JTextComponent)c;
			else
				textComponent = null;
		
			if ((textComponent != null) && !MText.isMultiline(textComponent))
				textComponent.putClientProperty(MWrapperPanel.AUTO_SELECT_ALL_PROPERTY, true);
		}

		if (f.required() && !canAccept)
			setCanAccept(false);
	}

	private void updateForm() {
		new ContainerScanner(this) {
			@Override
			@SuppressWarnings("unchecked")
			public void processComponent(final Container parent, final Component component) {
				if (component instanceof JComponent) {
					JComponent c = (JComponent)component;
					String name = c.getName();
					if (name != null) {
						if (name.startsWith("method-"))
							return;

						try {
							java.lang.reflect.Field field = form.getClass().getDeclaredField(name);
							Field f = field.getAnnotation(Field.class);
							if (f != null) {
								Class<?> fieldType = field.getType();
								FieldEditor fieldEditor = c.getClass().getAnnotation(FieldEditor.class);

								if ((fieldEditor != null) && fieldEditor.type().equals(fieldType)) {
									BeanProperty<Object> bp = new BeanProperty<>(c, (Class<Object>)fieldEditor.type(), fieldEditor.valueProperty());
									if (bp.canWrite())
										bp.set(getFieldValue(field));
								}
								else if (fieldType.isPrimitive() && (fieldType == int.class)) {
									MNumberSpinner<Integer> numberSpinner = (MNumberSpinner<Integer>)c;
									numberSpinner.setNumber((Integer)getFieldValue(field));
								}
								else if (fieldType == char[].class) {
									char[] value = (char[])getFieldValue(field);
									MPasswordField passwordField = MWrapperPanel.getWrappedView(c);
									passwordField.setText((value == null) ? null : new String(value));
								}
								else if (fieldType == Font.class) {
									MFontButton.class.cast(c).setValue((Font)getFieldValue(field));
								}
								else if (fieldType == URI.class) {
									URI uri = (URI)getFieldValue(field);
									MLinkButton.class.cast(c).setURI(uri);
								}
								else {
									if (f.type() == Field.TYPE_AUTO) {
										MTextField textField = MWrapperPanel.getWrappedView(c);
										textField.setText((String)getFieldValue(field));
									}
									else if (f.type() == Field.TYPE_EDITOR_PANE) {
										MEditorPane editorPane = MWrapperPanel.getWrappedView(c);
										editorPane.setText((String)getFieldValue(field));
										editorPane.setCaretPosition(0);
									}
								}
							}
						}
						catch (NoSuchFieldException exception) {
							MLogger.exception(exception);
						}
					}
				}
			}
		};
	}

	// private classes

	private static interface FieldProperty {

		// public

		public boolean canAccept();

		public java.lang.reflect.Field getField();

	}

	private static final class BooleanFieldProperty extends BooleanProperty implements FieldProperty {

		// private

		private final boolean readOnly;
		private final java.lang.reflect.Field field;

		// public

		@Override
		public boolean canAccept() { return get(); }

		@Override
		public java.lang.reflect.Field getField() { return field; }

		@Override
		public boolean isReadOnly() { return readOnly; }

		// private

		private BooleanFieldProperty(final java.lang.reflect.Field field, final Object form) throws IllegalAccessException {
			super((Boolean)FormPanel.getFieldValue(form, field));
			this.field = field;
			this.readOnly = field.getAnnotation(Field.class).readOnly();
		}

	}

	private static final class ColorFieldProperty extends ColorProperty implements FieldProperty {

		// private

		private final boolean readOnly;
		private final java.lang.reflect.Field field;

		// public

		@Override
		public boolean canAccept() { return true; }

		@Override
		public java.lang.reflect.Field getField() { return field; }

		@Override
		public boolean isReadOnly() { return readOnly; }

		// private

		private ColorFieldProperty(final java.lang.reflect.Field field, final Object form) throws IllegalAccessException {
			super((Color)FormPanel.getFieldValue(form, field));
			this.field = field;
			this.readOnly = field.getAnnotation(Field.class).readOnly();
		}

	}

	private static final class FontFieldProperty extends FontProperty implements FieldProperty {

		// private

		private final boolean readOnly;
		private final java.lang.reflect.Field field;

		// public

		@Override
		public boolean canAccept() { return true; }

		@Override
		public java.lang.reflect.Field getField() { return field; }

		@Override
		public boolean isReadOnly() { return readOnly; }

		// private

		private FontFieldProperty(final java.lang.reflect.Field field, final Object form) throws IllegalAccessException {
			super((Font)FormPanel.getFieldValue(form, field));
			this.field = field;
			this.readOnly = field.getAnnotation(Field.class).readOnly();
		}

	}
	
	private static final class FormEditorPane extends MEditorPane {
	
		// private
		
		private final Field formField;
		private final java.lang.reflect.Field objectField;
		private final WeakReference<FormPanel<Object>> formPanelRef;
	
		// protected
		
		@SuppressWarnings("unchecked")
		protected FormEditorPane(final FormPanel<?> formPanel, final Field formField, final java.lang.reflect.Field objectField) {
			formPanelRef = new WeakReference<>((FormPanel<Object>)formPanel);
			this.formField = formField;
			this.objectField = objectField;
			
			setEditable(!formField.readOnly());
		}

		@Override
		protected void onChange(final DocumentEvent e) {
			FormPanel<Object> p = TK.get(formPanelRef);
			p.setFieldValue(objectField, getText());
			if (formField.required())
				p.setCanAccept(!isEmpty());
		}

	}

	private static final class IntegerFieldProperty extends IntegerProperty implements FieldProperty {

		// private

		private final boolean readOnly;
		private final java.lang.reflect.Field field;

		// public

		@Override
		public boolean canAccept() { return true; }

		@Override
		public java.lang.reflect.Field getField() { return field; }

		@Override
		public boolean isReadOnly() { return readOnly; }

		// private

		private IntegerFieldProperty(final java.lang.reflect.Field field, final Object form) throws IllegalAccessException {
			super((Integer)FormPanel.getFieldValue(form, field));
			this.field = field;
			this.readOnly = field.getAnnotation(Field.class).readOnly();
		}

	}

	private static final class PasswordFieldProperty extends StringProperty implements FieldProperty {

		// private

		private final boolean readOnly;
		private final java.lang.reflect.Field field;

		// public

		@Override
		public boolean canAccept() {
			return !isEmpty();
		}

		@Override
		public java.lang.reflect.Field getField() { return field; }

		@Override
		public boolean isReadOnly() { return readOnly; }

		// private

		private PasswordFieldProperty(final java.lang.reflect.Field field, final Object form) throws IllegalAccessException {
			char[] value = (char[])FormPanel.getFieldValue(form, field);
			set((value == null) ? null : (new String(value)));
			this.field = field;
			this.readOnly = field.getAnnotation(Field.class).readOnly();
		}

	}

	private static final class StaticHandler implements PropertyChangeListener {
		
		// private
		
		private final WeakReference<FormPanel<?>> formPanelRef;

		// public

		public StaticHandler(final FormPanel<?> formPanel) {
			formPanelRef = new WeakReference<>(formPanel);
		}

		// PropertyChangeListener

		@Override
		public void propertyChange(final PropertyChangeEvent e) {
			if (e.getSource() instanceof FieldProperty) {
				FormPanel<?> formPanel = TK.get(formPanelRef);

				if (formPanel == null)
					return;

				FieldProperty p = (FieldProperty)e.getSource();
				if (p instanceof PasswordFieldProperty) {
					Object newValue = e.getNewValue();
					formPanel.setFieldValue(p.getField(), (newValue == null) ? null : newValue.toString().toCharArray());
				}
				else {
					formPanel.setFieldValue(p.getField(), e.getNewValue());
				}

				if (p.getField().getAnnotation(Field.class).required())
					formPanel.setCanAccept(p.canAccept());
			}
		}

	}

	private static final class StringFieldProperty extends StringProperty implements FieldProperty {

		// private

		private final boolean readOnly;
		private final java.lang.reflect.Field field;

		// public

		@Override
		public boolean canAccept() {
			return !isEmpty();
		}

		@Override
		public java.lang.reflect.Field getField() { return field; }

		@Override
		public boolean isReadOnly() { return readOnly; }

		// private

		private StringFieldProperty(final java.lang.reflect.Field field, final Object form) throws IllegalAccessException {
			super((String)FormPanel.getFieldValue(form, field));
			this.field = field;
			this.readOnly = field.getAnnotation(Field.class).readOnly();
		}

	}

}
