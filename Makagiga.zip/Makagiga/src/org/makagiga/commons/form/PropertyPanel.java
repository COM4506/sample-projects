// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.form;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.BeanInfo;
import java.beans.EventHandler;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyChangeListener;
import java.beans.PropertyDescriptor;
import java.lang.ref.WeakReference;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import javax.swing.AbstractButton;
import javax.swing.InputVerifier;
import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.text.JTextComponent;
import javax.swing.text.NumberFormatter;

import org.makagiga.commons.BeanProperty;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.NumberProperty;
import org.makagiga.commons.PathProperty;
import org.makagiga.commons.Property;
import org.makagiga.commons.TK;
import org.makagiga.commons.Tuple;
import org.makagiga.commons.UI;
import org.makagiga.commons.ValueEvent;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.color.ColorPalette;
import org.makagiga.commons.color.MSmallColorChooser;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.swing.ContainerIterator;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MCheckBox;
import org.makagiga.commons.swing.MComboBox;
import org.makagiga.commons.swing.MDateSpinner;
import org.makagiga.commons.swing.MFileChooser;
import org.makagiga.commons.swing.MFontButton;
import org.makagiga.commons.swing.MFormattedTextField;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MNumberSpinner;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MPasswordField;
import org.makagiga.commons.swing.MPlusMinusPanel;
import org.makagiga.commons.swing.MSlider;
import org.makagiga.commons.swing.MSmallButton;
import org.makagiga.commons.swing.MSpinnerPanel;
import org.makagiga.commons.swing.MTextField;
import org.makagiga.commons.swing.MWrapperPanel;
import org.makagiga.commons.swing.event.MDocumentAdapter;

/**
 * @since 2.4, 4.0 (org.makagiga.commons.form package)
 */
public class PropertyPanel extends MPanel {

	// public

	/**
	 * {@code false} - do not reset values on "Set Default Values" button click.
	 *
	 * @mg.default
	 * {@code true}
	 */
	public static final String RESTORE_DEFAULT_VALUES_PROPERTY = "org.makagiga.commons.form.PropertyPanel.RESTORE_DEFAULT_VALUES_PROPERTY";
	
	// private
	
	private boolean autoUpdateModel = true;
	private boolean highlightFocusedEditor;
	private final Map<Enum<?>, String> enumText = new HashMap<>(); // no EnumMap
	private static final String FILE_CHOOSER_HANDLER_PROPERTY = "org.makagiga.commons.form.PropertyPanel.fileChooserHandler";
	private static final String PROPERTY_PROPERTY = "org.makagiga.commons.form.PropertyPanel.property";
	
	// public

	/**
	 * @since 3.2
	 */
	public PropertyPanel() {
		this(0);
	}
	
	public PropertyPanel(final int margin) {
		super(UI.VERTICAL);
		setMargin(margin);
	}

	/**
	 * @since 3.2
	 */
	@Obsolete
	public MAction createDefaultsAction() {
		return createDefaultsAction(this);
	}

	/**
	 * @since 5.0
	 */
	public static MAction createDefaultsAction(final PropertyPanel propertyPanel) {
		MDataAction.Weak<PropertyPanel> action = new MDataAction.Weak<>(propertyPanel, MActionInfo.RESTORE_DEFAULT_VALUES,
			self -> self.get().restoreDefaultValues(self.getSourceWindow(), null)
		);
		action.setIcon(MActionInfo.RESTORE_DEFAULT_VALUES.getSmallIcon());
		
		return action;
	}

	/**
	 * @throws IllegalArgumentException If @p property type is unsupported
	 * @throws NullPointerException If @p property is @c null
	 * @throws SecurityException If no permission to access {@code property}
	 */
	public JComponent bind(final Property<?> property, final String text) {
		return bind(property, text, null);
	}

	/**
	 * @since 3.4
	 */
	@SuppressWarnings("unchecked")
	public JComponent bind(final Property<?> property, final String text, Class<? extends JComponent> editorClass) {
		Objects.requireNonNull(property);

		if (editorClass == null)
			editorClass = getPreferredEditorClass(property);

		JComponent result = null;

		// NOTE: sync. with "updateModel" and "updateView"
		if (property.isBooleanType()) {
			result = createBooleanPropertyEditor((Property<Boolean>)property, text);
		}
		else if (property.isColorType()) {
			result = createColorPropertyEditor((Property<Color>)property, text);
		}
		else if (property.isDateType()) {
			result = createDatePropertyEditor((Property<java.util.Date>)property, text);
		}
		else if (property.isDoubleType()) {
			result = createDoublePropertyEditor((Property<Double>)property, text);
		}
		else if (property.isEnumType()) {
			result = createEnumPropertyEditor((Property<Enum<?>>)property, text);
		}
		else if (property.isFloatType()) {
			result = createFloatPropertyEditor((Property<Float>)property, text);
		}
		else if (property.isFontType()) {
			result = createFontPropertyEditor((Property<Font>)property, text);
		}
		else if (property.isIntegerType()) {
			if (editorClass == MSlider.class) {
				result = createNumberPropertyEditor((Property<Integer>)property, text);
			}
			else {
				result = createNumberPropertyEditor(
					(Property<Integer>)property,
					text,
					MNumberSpinner.getColumnsForNumber(Integer.MAX_VALUE)
				);
			}
		}
		else if (property instanceof NumberProperty<?>) {
			result = createNumberPropertyEditor(
				(NumberProperty<?>)property,
				text,
				MNumberSpinner.getColumnsForNumber(Long.MAX_VALUE)
			);
		}
		else if (property.getType() == Path.class) {
			result = createPathPropertyEditor((Property<Path>)property, text);
		}
		else if (property.isStringType()) {
			if (editorClass == MPasswordField.class)
				result = createPasswordPropertyEditor((Property<String>)property, text);
			else
				result = createStringPropertyEditor((Property<String>)property, text);
		}

		if (result == null)
			result = createCustomEditor(property, text, editorClass);

		if (result == null) {
			throw new IllegalArgumentException("Unsupported property type: " + property.getClass().getName() + " (" + property + "; " + text + "; " + property.getType() + ")");
		}
		else {
			if (property.isReadOnly()) {
				JComponent c = MWrapperPanel.getWrappedView(result);
				if (c instanceof JTextComponent)
					JTextComponent.class.cast(c).setEditable(false);
				else if (c != null)
					c.setEnabled(false);
			}

			result.putClientProperty(PROPERTY_PROPERTY, property);
			if (getComponentCount() > 0) {
				if (
					(
						!(result instanceof MPanel) &&
						(getComponent(getComponentCount() - 1) instanceof MPanel)
					) ||
					(
						(result instanceof MPanel) &&
						!(getComponent(getComponentCount() - 1) instanceof MPanel)
					) ||
					(
						(result instanceof MPanel) &&
						(getComponent(getComponentCount() - 1) instanceof MPanel)
					)
				) {
					addGap();
				}
			}
			add(result);
			
			return result;
		}
	}

	/**
	 * @since 3.2
	 */
	public void bind(
		final Property<?> sourceProperty, final String sourcePropertyName,
		final Property<?> destinationProperty, final String destinationPropertyName
	) {
		JComponent sourceComponent = getEditorView(sourceProperty);
		JComponent destinationComponent = getEditorView(destinationProperty);

		if ((sourceComponent == null) || (destinationComponent == null))
			throw new IllegalArgumentException("Source or destination component not found");

		if (sourceComponent == destinationComponent)
			throw new IllegalArgumentException("Invalid source or destination property");

		if (sourceComponent instanceof AbstractButton) {
			AbstractButton ab = (AbstractButton)sourceComponent;
			ActionListener al = EventHandler.create(
				ActionListener.class,
				destinationComponent,
				destinationPropertyName,
				"source." + sourcePropertyName
			);

			// update component
			al.actionPerformed(new ActionEvent(sourceComponent, ActionEvent.ACTION_PERFORMED, null));

			ab.addActionListener(al);
		}
		else {
			throw new IllegalArgumentException("Unsupported source property component");
		}
	}

	/**
	 * @since 3.8.4
	 */
	public BeanInfo bindBean(final Object bean, final String... allowProperties) throws IntrospectionException {
		Set<String> allowPropertiesSet;
		if (TK.isEmpty(allowProperties))
			allowPropertiesSet = null;
		else
			allowPropertiesSet = TK.newHashSet(allowProperties);

		BeanInfo info = Introspector.getBeanInfo(bean.getClass());
		PropertyDescriptor[] propertyDescriptors = info.getPropertyDescriptors();

		LinkedHashMap<String, PropertyDescriptor> orderMap = new LinkedHashMap<>(propertyDescriptors.length);
		for (PropertyDescriptor i : propertyDescriptors)
			orderMap.put(i.getName(), i);
		
		for (PropertyDescriptor i : TK.order(orderMap, allowProperties)) {
			if (i.isHidden()) {
				if (allowPropertiesSet != null)
					allowPropertiesSet.remove(i.getName());

				continue; // for
			}

			if ((allowPropertiesSet != null) && !allowPropertiesSet.contains(i.getName()))
				continue; // for

			// convert "fooBar" to "Foo Bar"
			String text = i.getDisplayName();
			if (i.getName().equals(text)) {
				text = TK.identifierToDisplayString(text);
			}

			if (allowPropertiesSet != null)
				allowPropertiesSet.remove(i.getName());

			BeanProperty<Object> beanProperty = new BeanProperty<>(bean, i);
			bind(beanProperty, text);
		}

		if ((allowPropertiesSet != null) && !allowPropertiesSet.isEmpty()) {
			throw new IntrospectionException("Invalid properties: " + String.join(", ", allowPropertiesSet));
		}

		return info;
	}

	/**
	 * @since 5.0
	 */
	public MCheckBox bindCheckBox(final Property<Boolean> property, final String text) {
		return (MCheckBox)bind(property, text);
	}

	/**
	 * @since 4.8
	 */
	public Tuple.Two<MSmallColorChooser, MSmallColorChooser> bindColorPair(
		final Property<? extends Color> property1, final String text1,
		final Property<? extends Color> property2, final String text2
	) {
		MSmallColorChooser editor1 = bindSmallColorChooser(property1, text1);
		MSmallColorChooser editor2 = bindSmallColorChooser(property2, text2);
		editor1.makePair(editor2);

		return Tuple.of(editor1, editor2);
	}

	/**
	 * @since 5.4
	 */
	public MDateSpinner bindDateSpinner(final Property<? extends java.util.Date> property, final String text) {
		return MWrapperPanel.getWrappedView(bind(property, text));
	}

	/**
	 * @since 4.0
	 */
	public JComponent bindDouble(final Property<Double> property, final String text, final double minimum, final double maximum) {
		MFormattedTextField editor = MWrapperPanel.getWrappedView(bind(property, text));
		editor.setColumns(MNumberSpinner.getColumnsForNumber(maximum));
		editor.setInputVerifier(new InputVerifier() {
			@Override
			public boolean verify(final JComponent input) {
				if (input instanceof MFormattedTextField) {
					MFormattedTextField ftf = (MFormattedTextField)input;
					double value = (Double)ftf.getValue();
					
					return (value >= minimum) && (value <= maximum);
				}
				
				return true;
			}
		} );
		
		return editor;
	}

	/**
	 * @since 5.0
	 */
	public MComboBox<Enum<?>> bindEnumComboBox(final Property<? extends Enum<?>> property, final String text) {
		return MWrapperPanel.getWrappedView(bind(property, text));
	}

	public JComponent bindFloat(final Property<Float> property, final String text, final float minimum, final float maximum) {
		MFormattedTextField editor = MWrapperPanel.getWrappedView(bind(property, text));
		editor.setColumns(MNumberSpinner.getColumnsForNumber(maximum));
		editor.setInputVerifier(new InputVerifier() {
			@Override
			public boolean verify(final JComponent input) {
				if (input instanceof MFormattedTextField) {
					MFormattedTextField ftf = (MFormattedTextField)input;
					float value = (Float)ftf.getValue();
					
					return (value >= minimum) && (value <= maximum);
				}
				
				return true;
			}
		} );
		
		return editor;
	}

	/**
	 * @since 5.0
	 */
	public MFontButton bindFontButton(final Property<Font> property, final String text) {
		@SuppressWarnings("unchecked")
		MWrapperPanel.Horizontal<MFontButton> panel = (MWrapperPanel.Horizontal<MFontButton>)bind(property, text);

		return panel.getView();
	}

	public JComponent bindInteger(final Property<Integer> property, final String text, final int minimum, final int maximum) {
		return bindNumberSpinnerPanel(property, text, minimum, maximum)
			.getView();
	}

	/**
	 * @since 5.0
	 */
	public MNumberSpinner<Integer> bindNumberSpinner(final Property<Integer> property, final String text, final int minimum, final int maximum) {
		return bindNumberSpinnerPanel(property, text, minimum, maximum)
			.getSpinner();
	}

	/**
	 * @since 5.4
	 */
	@SuppressWarnings("unchecked")
	public MSpinnerPanel bindNumberSpinnerPanel(final Property<Integer> property, final String text, final int minimum, final int maximum) {
		MSpinnerPanel wrapper = (MSpinnerPanel)bind(property, text);
		MNumberSpinner<Integer> numberSpinner = MWrapperPanel.getWrappedView(wrapper);
		numberSpinner.setRange(minimum, maximum);

		return wrapper;
	}

	/**
	 * @since 5.0
	 */
	public MWrapperPanel<?> bindPanel(final Property<?> property, final String text) {
		return (MWrapperPanel<?>)bind(property, text);
	}

	/**
	 * @since 5.4
	 */
	public JComponent bindPath(final Property<Path> property, final String text, final Predicate<MFileChooser> handler) {
		MTextField editor = MWrapperPanel.getWrappedView(bind(property, text));
		editor.putClientProperty(FILE_CHOOSER_HANDLER_PROPERTY, handler);
		
		return editor;
	}

	/**
	 * @since 5.0
	 */
	public MSmallColorChooser bindSmallColorChooser(final Property<? extends Color> property, final String text) {
		return (MSmallColorChooser)bind(property, text);
	}

	/**
	 * @since 3.2
	 */
	public MTextField bindTextField(final Property<String> property, final String text) {
		return MWrapperPanel.getWrappedView(bind(property, text));
	}
	
	public boolean getAutoUpdateModel() { return autoUpdateModel; }
	
	public void setAutoUpdateModel(final boolean value) { autoUpdateModel = value; }

	/**
	 * Returns a text for @p e.
	 * Returns @c null if no text for @p e.
	 * 
	 * @since 3.0
	 */
	public String getEnumText(final Enum<?> e) {
		return enumText.get(e);
	}

	/**
	 * Sets a @p text for @p e. This text will be displayed in a combo box editor.
	 * 
	 * @since 3.0
	 */
	public void setEnumText(final Enum<?> e, final String text) {
		enumText.put(e, text);
	}

	/**
	 * @since 3.8.6
	 */
	public boolean getHighlightFocusedEditor() { return highlightFocusedEditor; }

	/**
	 * @since 3.8.6
	 */
	public void setHighlightFocusedEditor(final boolean value) { highlightFocusedEditor = value; }

	/**
	 * @since 4.0
	 */
	public boolean hasEditors() {
		for (Component i : getComponents()) {
			if (i instanceof JComponent) {
				Property<?> p = (Property<?>)JComponent.class.cast(i).getClientProperty(PROPERTY_PROPERTY);
			
				if (p != null)
					return true;
			}
		}

		return false;
	}
	
	/**
	 * @since 5.0
	 */
	public boolean restoreDefaultValues(final Window owner, String pageTitle) {
		pageTitle = TK.isEmpty(pageTitle) ? "" : (pageTitle + " - ");

		if (new MMessage.Builder()
			.icon(MActionInfo.RESTORE_DEFAULT_VALUES.getIcon())
			.ok(MActionInfo.RESTORE_DEFAULT_VALUES)
			.simpleText()
			.title(pageTitle + MActionInfo.RESTORE_DEFAULT_VALUES.getText())
			.exec(owner)
		) {
			restoreDefaultValues();
		
			return true;
		}
		
		return false;
	}

	public void restoreDefaultValues() {
		boolean needViewUpdate = false;
		for (Map.Entry<Property<?>, JComponent> i : getEditorList()) {
			if (!Boolean.FALSE.equals(i.getValue().getClientProperty(RESTORE_DEFAULT_VALUES_PROPERTY))) {
				needViewUpdate = true;
				i.getKey().reset();
			}
		}

		if (needViewUpdate)
			updateView();
	}
	
	public void setAllEnabled(final boolean enabled) {
		for (Map.Entry<Property<?>, JComponent> i : getEditorList())
			i.getValue().setEnabled(enabled);
	}
	
	@SuppressWarnings("unchecked")
	public void updateModel() {
		for (Map.Entry<Property<?>, JComponent> i : getEditorList()) {
			Property<?> p = i.getKey();
			JComponent c = i.getValue();

			if (updateCustomModel(p, c))
				continue; // for

			Property<Object> po = (Property<Object>)p;

			if (p.isBooleanType())
				po.set(MCheckBox.class.cast(c).isSelected());
			else if (p.isColorType())
				po.set(MSmallColorChooser.class.cast(c).getValue());
			else if (p.isDateType())
				po.set(MDateSpinner.class.cast(c).getDate());
			else if (p.isDoubleType())
				po.set((Double)MFormattedTextField.class.cast(c).getValue());
			else if (p.isEnumType()) {
				MComboBox<Enum<?>> source = (MComboBox<Enum<?>>)c;
				po.set(source.getSelectedItem());
			}
			else if (p.isFloatType())
				po.set((Float)MFormattedTextField.class.cast(c).getValue());
			else if (p.isFontType())
				po.set(MFontButton.class.cast(c).getValue());
			else if (p.isIntegerType()) {
				if (c instanceof MSlider)
					po.set(MSlider.class.cast(c).getValue());
				else
					po.set((Integer)MNumberSpinner.class.cast(c).getNumber());
			}
			else if (p instanceof NumberProperty<?>) {
				if (c instanceof MSlider)
					po.set(MSlider.class.cast(c).getValue());
				else
					po.set(MNumberSpinner.class.cast(c).getNumber());
			}
			else if (p.isStringType())
				po.set(MTextField.class.cast(c).getText());
		}
	}

	@SuppressWarnings("unchecked")
	public void updateView() {
		for (Map.Entry<Property<?>, JComponent> i : getEditorList()) {
			Property<?> p = i.getKey();
			JComponent c = i.getValue();

			if (updateCustomView(p, c))
				continue; // for

			if (p.isBooleanType()) {
				MCheckBox.class.cast(c).setSelected((Boolean)p.get());
			}
			else if (p.isColorType()) {
				MSmallColorChooser.class.cast(c).setValue((Color)p.get());
			}
			else if (p.isDateType()) {
				MDateSpinner.class.cast(c).setDate((java.util.Date)p.get());
			}
			else if (p.isDoubleType()) {
				MFormattedTextField.class.cast(c).setValue(p.get());
			}
			else if (p.isEnumType()) {
				MComboBox.class.cast(c).setSelectedItem(p.get());
			}
			else if (p.isFloatType()) {
				MFormattedTextField.class.cast(c).setValue(p.get());
			}
			else if (p.isFontType()) {
				MFontButton.class.cast(c).setValue((Font)p.get());
			}
			else if (p.isIntegerType()) {
				if (c instanceof MSlider)
					MSlider.class.cast(c).setValue((Integer)p.get());
				else
					MNumberSpinner.class.cast(c).setValue((Integer)p.get());
			}
			else if (p instanceof NumberProperty<?>) {
				NumberProperty<Number> np = (NumberProperty<Number>)p;
				if (c instanceof MSlider)
					MSlider.class.cast(c).setValue(np.get().intValue());
				else
					MNumberSpinner.class.cast(c).setNumber(np.get());
			}
			else if (p.isStringType()) {
				MTextField.class.cast(c).setText((String)p.get());
			}
		}
	}
	
	// protected

	/**
	 * @since 3.8.4
	 */
	protected JComponent createBooleanPropertyEditor(final Property<Boolean> property, final String text) {
		MCheckBox editor = new MCheckBox(text);
		editor.setSelected(property.get());
		editor.addActionListener(new StaticPropertyHandler<>(this, property));

		return editor;
	}

	/**
	 * @since 3.8.4
	 */
	protected JComponent createColorPropertyEditor(final Property<Color> property, final String text) {
		MSmallColorChooser editor = new MSmallColorChooser(null, createColorPalette());
		editor.setValue(property.get());
		editor.setDefaultValue(property.getDefaultValue());
		editor.setTitle(text);
		editor.addValueListener(new StaticPropertyHandler<>(this, property));

		return editor;
	}

	protected ColorPalette createColorPalette() {
		return ColorPalette.getApplicationPalette();
	}

	/**
	 * @since 3.8
	 */
	protected JComponent createCustomEditor(final Property<?> property, final String text, final Class<? extends JComponent> editorClass) { return null; }

	/**
	 * @since 3.8.6
	 */
	protected JComponent createDatePropertyEditor(final Property<java.util.Date> property, final String text) {
		MDateSpinner editor = new MDateSpinner();
		UI.setLargerInputFont(editor, false);
		editor.setDate(property.get());
		editor.addChangeListener(e -> handleEdit(property, editor.getDate()));

		MSpinnerPanel wrapper = new MSpinnerPanel(editor, text);
		wrapper.getButtonPanel()
			.add(new DatePropertyEditorButton(editor));

		return wrapper;
	}

	/**
	 * @since 4.0
	 */
	protected JComponent createDoublePropertyEditor(final Property<Double> property, final String text) {
		MFormattedTextField editor = new MFormattedTextField(property.get());
		editor.setColumns(10);
		setFormatToolTipText(editor, 0.5d);
		editor.getDocument().addDocumentListener(new StaticPropertyHandler<>(this, editor, property));
		
		MWrapperPanel.Horizontal<MFormattedTextField> wrapper = new MWrapperPanel.Horizontal<>(editor, text, true);
		wrapper.setCompactSize(true);
		
		return wrapper;
	}

	/**
	 * @since 3.8.6
	 */
	protected JComponent createEnumPropertyEditor(final Property<? extends Enum<?>> property, final String text) {
		MComboBox<Enum<?>> editor = new MComboBox<>();
		editor.setRenderer(new EnumRenderer(this));
		Enum<?>[] enums = property.getType().getEnumConstants();
		if (enums != null) {
			editor.addAllItems(enums);
			editor.setSelectedItem(property.get());
		}
		editor.addActionListener(e -> handleEdit(property, editor.getSelectedItem()));

		MWrapperPanel.Horizontal<JComponent> wrapper = new MWrapperPanel.Horizontal<>(editor, text, true);
		wrapper.setCompactSize(true);
		
		return wrapper;
	}

	/**
	 * @since 3.8.4
	 */
	protected JComponent createFloatPropertyEditor(final Property<Float> property, final String text) {
		MFormattedTextField editor = new MFormattedTextField(property.get());
		editor.setColumns(10);
		setFormatToolTipText(editor, 0.5f);
		editor.getDocument().addDocumentListener(new StaticPropertyHandler<>(this, editor, property));

		MWrapperPanel.Horizontal<MFormattedTextField> wrapper = new MWrapperPanel.Horizontal<>(editor, text, true);
		wrapper.setCompactSize(true);
		
		return wrapper;
	}

	/**
	 * @since 3.8.4
	 */
	protected JComponent createFontPropertyEditor(final Property<Font> property, final String text) {
		MPlusMinusPanel buttonPanel = new MPlusMinusPanel();

		MFontButton editor = new MFontButton(TK.isEmpty(text) ? null/* use default */ : MFontButton.NO_TEXT_LABEL, null);
		editor.setValue(property.get());
		editor.addValueListener(e -> {
			Font newValue = e.getNewValue();
			handleEdit(property, newValue);

			buttonPanel.getMinusButton()
				.setEnabled((newValue != null) && (newValue.getSize() > UI.getMinimumFontSize()));
		} );

		buttonPanel.getMinusButton()
			.addActionListener(e -> changeFontSize(editor, e, -1));
		buttonPanel.getPlusButton()
			.addActionListener(e -> changeFontSize(editor, e, 1));

		Font font = editor.getValue();
		buttonPanel.getMinusButton()
			.setEnabled((font != null) && (font.getSize() > UI.getMinimumFontSize()));

		MWrapperPanel.Horizontal<MFontButton> wrapper =
			new MWrapperPanel.Horizontal<>(editor, text, false);
		wrapper.addEast(buttonPanel);
		wrapper.setCompactSize(true);

		return wrapper;
	}

	/**
	 * @since 3.8.6
	 */
	protected <T extends Number> JComponent createNumberPropertyEditor(final Property<T> property, final String text) {
		MSlider editor = new MSlider();
		if (property.isPresent())
			editor.setValue(property.get().intValue());
		editor.addChangeListener(new StaticPropertyHandler<>(this, property));

		MWrapperPanel.Horizontal<MSlider> p = new MWrapperPanel.Horizontal<>(editor, null, false);
		p.setTitle(text);

		MLabel value = MLabel.createSmall(null, null);
		value.setName("value");
		if (property.isPresent())
			value.setNumber(property.get());
		value.setToolTipText(i18n("Value"));
		p.addEast(value);

		p.limitHeight();

		return p;
	}

	/**
	 * @since 3.8.4
	 */
	protected <T extends Number> JComponent createNumberPropertyEditor(final Property<T> property, final String text, final int columns) {
		MNumberSpinner<T> editor = new MNumberSpinner<>();
		editor.getTextField().setColumns(columns);
		editor.setNumber(property.get());
		editor.addChangeListener(new StaticPropertyHandler<>(this, property));

		MSpinnerPanel wrapper = new MSpinnerPanel(editor, text);
		wrapper.setCompactSize(true);
		
		return wrapper;
	}

	/**
	 * @since 4.0
	 */
	protected JComponent createPasswordPropertyEditor(final Property<String> property, final String text) {
		MPasswordField editor = new MPasswordField();
		editor.setText(property.get());
		editor.getDocument().addDocumentListener(new StaticPropertyHandler<>(this, editor, property));

		return new MWrapperPanel.Horizontal<>(editor, text, true);
	}

	/**
	 * @since 5.4
	 */
	protected JComponent createPathPropertyEditor(final Property<Path> property, final String text) {
		MTextField editor = new MTextField(property.toString());
		editor.onChange(e -> {
			try {
				handleEdit(property, PathProperty.parsePath(editor.getText()));
			}
			catch (ParseException exception) {
				MLogger.error("core", "Invalid path: %s", exception);
			}
		} );

		MWrapperPanel.Horizontal<MTextField> wrapper = new MWrapperPanel.Horizontal<>(editor, text, true);
		
		MButton browseButton = new MButton(MActionInfo.BROWSE.getText());
		if (UI.buttonIcons.get())
			browseButton.setIcon(MActionInfo.BROWSE.getSmallIcon());
		browseButton.addActionListener(e -> {
			MFileChooser fileChooser = new MFileChooser(UI.windowFor(editor));
			if (property.isPresent()) {
				Path path = property.get();
				if (Files.isDirectory(path)) {
					fileChooser.setCurrentDirectory(path.toFile());
				}
				else {
					Path parent = path.getParent();
					if (parent != null) {
						Optional.ofNullable(path.getFileName())
							.map(Path::toFile)
							.ifPresent(fileChooser::setSelectedFile);

						fileChooser.setCurrentDirectory(parent.toFile());
					}
					else {
						fileChooser.setSelectedFile(path.toFile());
					}
				}
			}

			Predicate<MFileChooser> handler = UI.getClientProperty(editor, FILE_CHOOSER_HANDLER_PROPERTY, null);
			if (handler != null) {
				if (handler.test(fileChooser))
					editor.setText(fileChooser.getSelectedFile().toString());
			}
		} );
		wrapper.addEast(browseButton);

		return wrapper;
	}

	/**
	 * @since 3.8.4
	 */
	protected JComponent createStringPropertyEditor(final Property<String> property, final String text) {
		MTextField editor = new MTextField(property.get());
		editor.getDocument().addDocumentListener(new StaticPropertyHandler<>(this, editor, property));

		return new MWrapperPanel.Horizontal<>(editor, text, true);
	}

	/**
	 * @since 4.0
	 */
	protected List<Map.Entry<Property<?>, JComponent>> getEditorList() {
		Component[] components = getComponents();
		List<Map.Entry<Property<?>, JComponent>> result = new MArrayList<>(components.length);
		for (Component i : components) {
			if (!(i instanceof JComponent))
				continue; // for
			
			JComponent c = (JComponent)i;
			Property<?> p = (Property<?>)c.getClientProperty(PROPERTY_PROPERTY);
			
			if (p == null)
				continue; // for

			result.add(Tuple.<Property<?>, JComponent>of(p, MWrapperPanel.getWrappedView(c)));
		}

		return result;
	}

	/**
	 * @since 3.8
	 */
	protected JComponent getEditorView(final Property<?> property) {
		for (Map.Entry<Property<?>, JComponent> i : getEditorList()) {
			if (i.getKey() == property)
				return i.getValue();
		}

		return null;
	}

	/**
	 * @since 3.8.6
	 */
	protected Class<? extends JComponent> getPreferredEditorClass(final Property<?> property) { return null; }

	/**
	 * @since 3.8.4
	 */
	protected void onUserPropertyChange(final Property<?> property) { }

	/**
	 * @since 3.8
	 */
	protected boolean updateCustomModel(final Property<?> p, final JComponent c) { return false; }

	/**
	 * @since 3.8
	 */
	protected boolean updateCustomView(final Property<?> p, final JComponent c) { return false; }

	// private

	private void changeFontSize(final MFontButton fontButton, final ActionEvent e, final int change) {
		if (!fontButton.isEnabled()) {
			UI.beep();
			
			return;
		}

		Font oldFont = fontButton.getValue();
		int newFontSize = TK.limit(oldFont.getSize() + change, UI.getMinimumFontSize(), Integer.MAX_VALUE);
		Font newFont = UI.deriveFontSize(oldFont, newFontSize);
		fontButton.setValue(newFont);
		fontButton.fireValueChanged(oldFont, newFont);
	}

	private void handleEdit(final Property<?> property, final Object newValue) {
		if (getAutoUpdateModel()) {
			@SuppressWarnings("unchecked")
			Property<Object> po = (Property<Object>)property;
			po.set(newValue);
			
			onUserPropertyChange(property);
		}
	}
	
	private void setFormatToolTipText(final MFormattedTextField field, final Object example) {
		MFormattedTextField.AbstractFormatter formatter = field.getFormatter();
		if (formatter instanceof NumberFormatter) {
			try {
				field.setToolTipText(i18n("Example: {0}", formatter.valueToString(example)));
			}
			catch (ParseException exception) {
				MLogger.exception(exception);
			}
		}
	}

	// package

	void uninstallPropertyChangeListeners(final PropertyChangeListener pcl) {
		for (Map.Entry<Property<?>, JComponent> i : getEditorList()) {
			i.getKey().removePropertyChangeListener(pcl);
		}
	}

	// private classes

	private static final class DatePropertyEditorButton extends MSmallButton {

		// private

		private final WeakReference<MDateSpinner> spinnerRef;

		// protected

		@Override
		protected MMenu onPopupMenu() {
			MDateSpinner spinner = spinnerRef.get();

			if (spinner == null)
				return null;

			MMenu menu = new MMenu();
			menu.add(spinner.createMenuCalendarPanel(menu));

			return menu;
		}

		// private

		private DatePropertyEditorButton(final MDateSpinner spinner) {
			super(MActionInfo.SET_DATE_TIME);
			spinnerRef = new WeakReference<>(spinner);
			setPopupMenuArrowPainted(false);
			setPopupMenuEnabled(true);
		}

	}

	private static final class EnumRenderer extends MRenderer<Enum<?>> {

		// private

		private final WeakReference<PropertyPanel> propertyPanelRef;

		// protected

		@Override
		protected void onRender(final Enum<?> e) {
			PropertyPanel propertyPanel = propertyPanelRef.get();
			String text = (propertyPanel == null) ? null : propertyPanel.getEnumText(e);
			setText((text == null) ? e.toString() : text);
		}

		// private

		private EnumRenderer(final PropertyPanel propertyPanel) {
			super(2);
			setHTMLEnabled(false);
			this.propertyPanelRef = new WeakReference<>(propertyPanel);
		}

	}

	private static final class StaticPropertyHandler<P extends Object> extends MDocumentAdapter<JTextComponent>
	implements
		ActionListener,
		ChangeListener,
		ValueListener<Color>
	{

		// private

		private final Property<P> property;
		private final WeakReference<PropertyPanel> propertyPanelRef;

		// public

		@Override
		public void actionPerformed(final ActionEvent e) {
			if (e.getSource() instanceof MCheckBox) {
				update(MCheckBox.class.cast(e.getSource()).isSelected());
			}
		}

		@Override
		public void stateChanged(final ChangeEvent e) {
			if (e.getSource() instanceof MNumberSpinner<?>) {
				update(MNumberSpinner.class.cast(e.getSource()).getNumber());
			}
			else if (e.getSource() instanceof MSlider) {
				MSlider slider = (MSlider)e.getSource();
				if (!slider.getValueIsAdjusting())
					update(slider.getValue());

				// update value label
				Container parent = slider.getParent();
				if (parent != null) {
					Component value = ContainerIterator.findName(parent, "value");
					if (value instanceof MLabel)
						MLabel.class.cast(value).setNumber(slider.getValue());
				}
			}
		}

		@Override
		public void valueChanged(final ValueEvent<Color> e) {
			if (e.getSource() instanceof MSmallColorChooser) {
				update(MSmallColorChooser.class.cast(e.getSource()).getValue());
			}
		}

		// protected

		@Override
		protected void onChange(final DocumentEvent e) {
			JTextComponent editor = getTextComponent();
			if (editor instanceof MFormattedTextField) {
				MFormattedTextField ftf = (MFormattedTextField)editor;
				try {
					ftf.commitEdit();
					update(ftf.getValue());
				}
				catch (ParseException exception) { // quiet
					//MLogger.developerException(exception);
				}
			}
			else if (editor != null) {
				update(editor.getText());
			}
		}

		// private

		private StaticPropertyHandler(final PropertyPanel propertyPanel, final JTextComponent editor, final Property<P> property) {
			super(editor);
			propertyPanelRef = new WeakReference<>(propertyPanel);
			this.property = property;
		}

		private StaticPropertyHandler(final PropertyPanel propertyPanel, final Property<P> property) {
			propertyPanelRef = new WeakReference<>(propertyPanel);
			this.property = property;
		}

		private void update(final Object value) {
			TK.getRef(propertyPanelRef)
				.ifPresent(propertyPanel -> propertyPanel.handleEdit(property, value));
		}

	}

}
