// Copyright 2012 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.Collection;

import org.makagiga.commons.annotation.DesignPattern;
import org.makagiga.commons.annotation.Important;

/**
 * @since 4.4
 */
@DesignPattern(DesignPattern.BUILDER)
public class MStringBuilder
implements
	Appendable,
	CharSequence,
	Serializable
{

	// private
	
	@SuppressWarnings("PMD.AvoidStringBufferField")
	private final StringBuilder buf;

	// public

	public MStringBuilder() {
		buf = new StringBuilder();
	}

	public MStringBuilder(final int initialCapacity) {
		buf = new StringBuilder(initialCapacity);
	}

	public MStringBuilder append(final int i) {
		buf.append(i);
	
		return this;
	}

	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public MStringBuilder append(final Collection<?> collection, final String delimeter) {
		buf.append(TK.toString(collection, delimeter));
		
		return this;
	}

	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public MStringBuilder append(final Object[] array, final String delimeter) {
		buf.append(TK.toString(array, delimeter));
		
		return this;
	}

	public MStringBuilder append(final Object o) {
		buf.append(o);
	
		return this;
	}

	public MStringBuilder append(final String s) {
		buf.append(s);
	
		return this;
	}
	
	public MStringBuilder appendLine(final String s) {
		buf.append(s);
		n();
	
		return this;
	}
	
	public MStringBuilder escapeXML(final String code) {
		TK.escapeXML(buf, code);
		
		return this;
	}
	
	public MStringBuilder fill(final char fill, final int length) {
		if (length < 0)
			throw new IllegalArgumentException("\"length\" cannot be less than zero");

		TK.append(buf, fill, length);

		return this;
	}

	public MStringBuilder format(final String format, final Object... args) {
		append(String.format(format, args));
	
		return this;
	}

	public MStringBuilder formatLine(final String format, final Object... args) {
		appendLine(String.format(format, args));
	
		return this;
	}
	
	public StringBuilder getBuffer() { return buf; }
	
	public boolean isEmpty() {
		return buf.length() == 0;
	}

	public MStringBuilder n() {
		buf.append('\n');
	
		return this;
	}
	
	/**
	 * Sets the buffer length to {@code 0} without reducing memory usage.
	 */
	public void reset() {
		buf.setLength(0);
	}

	public String toSwingHTML() {
		return UI.makeHTML(toString());
	}

	// Appendable

	@Override
	public MStringBuilder append(final char c) {
		buf.append(c);
	
		return this;
	}

	@Override
	public MStringBuilder append(final CharSequence cs) {
		buf.append(cs);
	
		return this;
	}

	@Override
	public MStringBuilder append(final CharSequence cs, final int start, final int end) {
		buf.append(cs, start, end);
	
		return this;
	}

	// CharSequence
	
	@Override
	public char charAt(final int index) {
		return buf.charAt(index);
	}
	
	@Override
	public int length() {
		return buf.length();
	}
	
	@Override
	public CharSequence subSequence(final int start, final int end) {
		return buf.subSequence(start, end);
	}

	@Important
	@Override
	public String toString() {
		return buf.toString();
	}
	
}
