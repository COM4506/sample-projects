// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import com.jhlabs.image.ColorizeFilter;
import com.jhlabs.image.GrayscaleColorizeFilter;
import com.jhlabs.image.GrayscaleFilter;
import com.jhlabs.image.HSBAdjustFilter;

import org.makagiga.commons.fx.Reflection;
import org.makagiga.commons.icons.DefaultIconLoader;
import org.makagiga.commons.security.MAccessController;

/**
 * @since 2.0
 */
public class MIcon extends ImageIcon {

	// public
	
	public enum Size { DEFAULT, SMALL, MEDIUM }

	/**
	 * Maximum icon size.
	 */
	public static final int MAX_SIZE = 64;

	/**
	 * Minimum icon size.
	 */
	public static final int MIN_SIZE = 16;
	
	// private
	
	private boolean stockLoadDone;
	private Color average;
	private static final Map<String, MIcon> cache = new ConcurrentHashMap<>();
	private Image overlay;
	private int stockSize;
	private String stockName;
	//private transient VolatileImage vi;
	
	// public

	/**
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public MIcon() { }
	
	/**
	 * @since 3.0
	 */
	public MIcon(final byte[] imageData) {
		super(imageData);
	}
	
	public MIcon(final File file) {
		Image image = Toolkit.getDefaultToolkit().getImage(file.getPath());
		if (image != null)
			setImage(image);
	}

	public MIcon(final Image image) {
		super(image);
	}

	public MIcon(final URL url) {
		Image image = Toolkit.getDefaultToolkit().getImage(url);
		if (image != null)
			setImage(image);
	}
	
	/**
	 * @since 4.0
	 */
	public static void flushCache() {
		cache.clear();
	}

	/**
	 * @throws NullPointerException If {@code dataURI} is {@code null}
	 *
	 * @since 3.0
	 */
	public static MIcon fromDataURI(String dataURI) throws IOException {
		Objects.requireNonNull(dataURI);
	
		try {
			dataURI = dataURI.trim();
			URI uri = new URI(dataURI);
			String scheme = uri.getScheme();
			if ("data".equals(scheme)) {
				String data = dataURI.substring("data:".length());
				int metaSep = data.indexOf(',');
				if (metaSep != -1) {
					String meta = data.substring(0, metaSep);
					List<String> properties = TK.fastSplit(meta, ';');
					if (
						properties.contains("image/vnd.microsoft.icon") || // registered
						properties.contains("image/x-icon") || // legacy
						properties.contains("image/png")
					) {
						String value = data.substring(metaSep + 1);
						byte[] imageBytes;
						if (properties.contains("base64")) {
							Base64.Decoder decoder = Base64.getDecoder();
							imageBytes = decoder.decode(value);
						}
						else {
							// decode escaped data
							ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
							boolean inEscape = false;
							StringBuilder sb = new StringBuilder(2);
							for (int i = 0; i < value.length(); i++) {
								char c = value.charAt(i);
								if (c == '%') {
									inEscape = true;
								}
								else {
									if (inEscape)
										sb.append(c);
									else
										out.write((int)c);
								}

								if (sb.length() == 2) {
// TODO: Integer.parseInt(CharSeq... #jdk9
									out.write(Integer.parseInt(sb.toString(), 16));
									sb.setLength(0);
									inEscape = false;
								}
							}
							imageBytes = out.toByteArray();
						}
						if (imageBytes != null) {
							// PNG
							if (
								(imageBytes.length > 4) &&
								(imageBytes[0] == 0xffffff89) && // -119/0x89
								(imageBytes[1] == 0x50) && // P
								(imageBytes[2] == 0x4E) && // N
								(imageBytes[3] == 0x47)    // G
							) {
								return new MIcon(imageBytes);
							}
							// GIF
							else if (
								(imageBytes.length > 3) &&
								(imageBytes[0] == 'G') &&
								(imageBytes[1] == 'I') &&
								(imageBytes[2] == 'F')
							) {
								return new MIcon(imageBytes);
							}
							// assume ICO
							else {
								Ico ico = new Ico(new ByteArrayInputStream(imageBytes));

								if (ico.getNumImages() > 0)
									return new MIcon(ico.getImage(0));
							}
						}
					}
				}
			}

			throw new IOException("Unsupported icon URI \"" + dataURI + '"');
		}
		catch (Ico.BadIcoResException | NumberFormatException | URISyntaxException exception) {
			throw new IOException(exception);
		}
	}

	/**
	 * @mg.note Since version 3.7 Beta the {@code size} parameter is handled correctly.
	 *
	 * @since 3.0
	 */
	public static MIcon fromFileURI(final String path, final int size) {
		if (path.startsWith("file:/")) { // do not use Net.isLocal
			try {
				MIcon result = new MIcon(new File(new URI(path)));
				
				if (result.isEmpty())
					return null;
				
				return (size == -1) ? result : result.scale(size, size, UI.Quality.HIGH);
			}
			catch (URISyntaxException exception) {
				MLogger.exception(exception);
				
				return null;
			}
		}
		else {
			return (size == -1) ? MIcon.unscaled(path) : MIcon.stock(path, size);
		}
	}

	/**
	 * Loads icon from the specified resource.
	 *
	 * @mg.note Returned icon is not cached.
	 *
	 * @param baseClass A base class for resource loader
	 * @param path A full icon path relative to @p baseClass (e.g. "images/icon.png")
	 * @param size An icon size (@c -1 - do not scale)
	 */
	public static MIcon get(final Class<?> baseClass, final String path, final int size) {
		URL url = baseClass.getResource(path);

		if (url == null)
			return null;

		MIcon result = new MIcon(url);
		
		return (size == -1) ? result : result.scale(size, size, UI.Quality.HIGH);
	}

	/**
	 * Loads icon from the specified file.
	 *
	 * @mg.note Custom icon is not cached.
	 *
	 * @param file The icon file (e.g. "images/icon.png")
	 * @param size The icon size (@c -1 - do not scale)
	 */
	public static MIcon get(final File file, final int size) {
		MIcon result = new MIcon(file);
		
		return (size == -1) ? result : result.scale(size, size, UI.Quality.HIGH);
	}
	
	/**
	 * @since 4.12
	 */
	public Color getAverageColor() {
		if (average == null) {
			Image image = getImage();
			if (image instanceof BufferedImage)
				average = MColor.getAverage((BufferedImage)image, 0);
		}

		return average;
	}

	/**
	 * @since 3.8.11
	 */
	public static MIcon getColorizedInstance(final Icon icon, final Color color) {
		return getFilteredInstance(icon, new ColorizeFilter(color));
	}

	/**
	 * @since 4.4
	 */
	public MIcon getColorizedInstance(final Color color) {
		return getColorizedInstance(this, color);
	}

	/**
	 * Returns the default icon size (24).
	 *
	 * @return 24
	 *
	 * @since 3.8.4
	 */
	public static int getDefaultSize() { return 24; }

	/**
	 * @since 3.0
	 */
	public MIcon getDisabledInstance() {
		GrayscaleColorizeFilter filter = new GrayscaleColorizeFilter();
		filter.setColor(new MColor(0xDDDDDD)); // light gray
	
		return getFilteredInstance(filter);
	}

	public MIcon getFilteredInstance(final BufferedImageOp filter) {
		return getFilteredInstance(this, filter);
	}

	/**
	 * @since 3.8.8
	 */
	public static MIcon getFilteredInstance(final Icon icon, final BufferedImageOp filter) {
		BufferedImage image;
		if (icon instanceof ImageIcon) {
			Image buf = ImageIcon.class.cast(icon).getImage();
			
			if (buf == null)
				return new MIcon(getName(icon), icon.getIconWidth());
			
			image = UI.toBufferedImage(buf, false);
		}
		else {
			image = UI.toBufferedImage(icon);
		}

		return new MIcon(filter.filter(image, null));
	}

	public MIcon getGrayscaleInstance() {
		return getFilteredInstance(new GrayscaleFilter());
	}
	
	/**
	 * @since 3.0
	 */
	public static List<Image> getIcoImages(final File file) throws IOException {
		try {
			Ico ico = new Ico(file);
			int count = ico.getNumImages();
			MArrayList<Image> result = new MArrayList<>(count);
			for (int i = 0; i < count; i++)
				result.add(ico.getImage(i));

			return result;
		}
		// HACK: it can sometimes catch java.lang.ArrayIndexOutOfBoundsException
		catch (/*Ico.BadIcoResException*/Exception exception) {
			throw new IOException(exception);
		}
	}

	/**
	 * @since 3.8.9
	 */
	public Dimension getIconSize() {
		return new Dimension(getIconWidth(), getIconHeight());
	}

	@Override
	public Image getImage() {
		loadOnDemand();
		
		return super.getImage();
	}
	
	@Override
	public void setImage(final Image value) {
		synchronized (this) {
			stockLoadDone = true; // do not load stock icon
		}
		super.setImage(value);
	}

	/**
	 * Reads an image from the cache or file.
	 * The icon size is @ref iconSize.
	 * @param name An image name without extension (e.g. "exit")
	 * @return An image if succsessfull; otherwise @c null
	 */
	public static Image getImage(final String name) {
		MIcon icon = unscaled(name);

		return (icon == null) ? null : icon.getImage();
	}

	/**
	 * Returns the <i>medium</i> size.
	 * 
	 * @since 2.4
	 */
	public static int getMediumSize() {
		return Math.min(getUISize(), DefaultIconLoader.getDefaultIconLoader().getMediumSize());
	}

	public String getName() { return stockName; }
	
	/**
	 * Returns the name of @p icon or @c null.
	 *
	 * @since 2.4
	 */
	public static String getName(final Icon icon) {
		if (icon instanceof MIcon)
			return MIcon.class.cast(icon).getName();
		
		return null;
	}
	
	/**
	 * @since 4.4
	 *
	 * @deprecated Since 4.8
	 */
	@Deprecated
	public static MIcon getNonDistractiveInstance(final Icon icon, final Color color) {
		return getColorizedInstance(icon, color);
	}

	/**
	 * @since 4.4
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static MIcon getNonDistractiveInstance(final Icon icon) {
		HSBAdjustFilter filter = new HSBAdjustFilter();
		filter.setBFactor(-0.1f);
		filter.setSFactor(-0.5f);

		return getFilteredInstance(icon, filter);
	}

	/**
	 * Returns the overlay image or @c null.
	 *
	 * @since 3.2
	 */
	public Image getOverlay() { return overlay; }

	/**
	 * Sets the overlay image to @p value (can be @c null).
	 *
	 * - Overlay image is painted "over" the actual icon image at right-bottom corner.
	 * - Overlay image with width less than 5 is not painted.
	 *
	 * @since 3.2
	 */
	public void setOverlay(final Image value) { overlay = value; }

	/**
	 * @since 4.10
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static MIcon getOxygenNonDistractiveInstance(final Icon icon) {
		if (!DefaultIconLoader.isOxygen())
			return new MIcon(getName(icon), icon.getIconWidth());
	
		return getNonDistractiveInstance(icon);
	}

	public MIcon getReflectionInstance() {
		return getReflectionInstance(new Reflection());
	}
	
	public MIcon getReflectionInstance(final Reflection r) {
		return r.createIcon(this);
	}
	
	/**
	 * Returns {@code 16}.
	 * 
	 * @since 2.4
	 */
	public static int getSmallSize() { return 16; }

	/**
	 * @since 5.0
	 */
	public static MIcon getSmallThrobber() {
		return unscaled("small/throbber.gif");
	}

	/**
	 * @since 4.4
	 *
	 * @see org.makagiga.commons.swing.MThrobber
	 */
	public static MIcon getThrobber() {
		return unscaled("ui/throbber.gif");
	}

	/**
	 * Returns the current <i>UI</i> icon size.
	 *
	 * @since 3.8.6
	 */
	public static int getUISize() {
		return UI.iconSize.get(MIN_SIZE, MAX_SIZE);
	}

	/**
	 * Returns @c true if this icon is empty (zero width or height).
	 */
	public boolean isEmpty() {
		return (getIconWidth() < 1) || (getIconHeight() < 1);
	}

	/**
	 * Returns @c true if @p icon is @c null or empty (zero width or height).
	 */
	public static boolean isEmpty(final Icon icon) {
		return (icon == null) || (icon.getIconWidth() < 1) || (icon.getIconHeight() < 1);
	}
	
	@Override
	public void loadImage(final Image value) {
		average = null;

		// HACK: avoid MediaTracker for already loaded icons
		if (value instanceof BufferedImage) {
			try {
				int w = value.getWidth(null);
				int h = value.getHeight(null);
				SecurityManager sm = System.getSecurityManager();
				if (sm == null) {
					finishMediaTracker(w, h);
				}
				else {
					AccessController.doPrivileged((PrivilegedExceptionAction<Void>)() -> {
						finishMediaTracker(w, h);

						return null;
					},
						null,
						MAccessController.ACCESS_DECLARED_MEMBERS_PERMISSION,
						MAccessController.SUPPRESS_ACCESS_CHECKS_PERMISSION
					);
				}
			}
			catch (Exception exception) {
				MLogger.exception(exception);
				super.loadImage(value);
			}
		}
		else {
			super.loadImage(value);
		}
	}

	public static MIcon medium(final String name) {
		return stock(name, getMediumSize());
	}

	public MIcon scale(final int w, final int h, final UI.Quality quality) {
		return new MIcon(UI.scaleImage(getImage(), w, h, quality));
	}
	
	public MIcon scaleSmall() {
		int size = getSmallSize();
	
		return scale(size, size, UI.Quality.HIGH);
	}

	public MIcon scaleUI() {
		int size = getUISize();
	
		return scale(size, size, UI.Quality.HIGH);
	}

	public static MIcon small(final String name) {
		return stock(name, getSmallSize());
	}

	public static MIcon stock(final String name) {
		return stock(name, getUISize());
	}
	
	/**
	 * @since 4.0
	 */
	public static MIcon stock(final String name, final MIcon.Size size) {
		switch (size) {
			case DEFAULT: return stock(name);
			case MEDIUM: return medium(name);
			case SMALL: return small(name);
			default: throw new WTFError(size);
		}
	}

	/**
	 * Reads an icon from the cache or a resource.
	 * The icon loaded from a resource is stored in the icon cache.
	 *
	 * @param name the icon name without extension (e.g. "ui/quit")
	 * @param aSize the icon size ({@code -1} - return unscaled version)
	 *
	 * @return An image icon; {@code null} if {@code name} is {@code null}
	 */
	public static MIcon stock(final String name, final int aSize) {
		if (name == null)
			return null;
		
		return new MIcon(name, aSize);
	}

	/**
	 * Loads an unscaled icon from the specified resource.
	 *
	 * @mg.note Returned icon is not cached.
	 *
	 * @param baseClass A base class for resource loader
	 * @param path A full icon path relative to @p baseClass (e.g. "images/icon.png")
	 */
	public static MIcon unscaled(final Class<?> baseClass, final String path) {
		return get(baseClass, path, -1);
	}

	/**
	 * Returns an image icon with default size (not scaled).
	 * @param name An icon name without extension
	 */
	public static MIcon unscaled(final String name) {
		return stock(name, -1);
	}

	// Icon

	@Override
	public int getIconHeight() {
		// use known icon size
		synchronized (this) {
			if (stockSize > 0)
				return stockSize;
		}
		
		loadOnDemand();
		
		return super.getIconHeight();
	}

	@Override
	public int getIconWidth() {
		// use known icon size
		synchronized (this) {
			if (stockSize > 0)
				return stockSize;
		}

		loadOnDemand();

		return super.getIconWidth();
	}

	@Override
	public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
		loadOnDemand();

		super.paintIcon(c, g, x, y);

		if (overlay != null) {
			int w = overlay.getWidth(null);
			if (w > 5) {
				g.drawImage(
					overlay,
					x + getIconWidth() - w - 1,
					y + getIconHeight() - overlay.getHeight(null) - 1,
					null
				);
			}
		}
/* TODO: 4.0: this is really fast for Transparency.OPAQUE,
but unfortunatelly Transparency.TRANSLUCENT is not accelerated
		if (c == null) {
			super.paintIcon(c, g, x, y);

			return;
		}

		Benchmark b = Benchmark.begin("paint icon: " + stockName);

		do {
			int code = (vi == null) ? VolatileImage.IMAGE_INCOMPATIBLE : vi.validate(c.getGraphicsConfiguration());

			if (code == VolatileImage.IMAGE_INCOMPATIBLE) {
				vi = UI.createCompatibleVolatileImage(getIconWidth(), getIconHeight(), Transparency.TRANSLUCENT);
			}

			if (code != VolatileImage.IMAGE_OK) {
				Graphics2D vg = vi.createGraphics();
				vg.drawImage(getImage(), 0, 0, null);
				vg.dispose();
			}

			g.drawImage(vi, x, y, null);
		} while (vi.contentsLost());

		b.end();
*/
	}

	// protected
	
	/**
	 * @since 5.2
	 */
	protected MIcon(final int stockSize) {
		this.stockSize = stockSize;
	}

	// private
	
	private MIcon(final String stockName, final int stockSize) {
		this.stockName = stockName;
		this.stockSize = stockSize;
	}

	private void finishMediaTracker(final int w, final int h) throws Exception {
		Field loadStatus = ImageIcon.class.getDeclaredField("loadStatus");
		Field width = ImageIcon.class.getDeclaredField("width");
		Field height = ImageIcon.class.getDeclaredField("height");
		try {
			loadStatus.setAccessible(true);
			loadStatus.set(this, MediaTracker.COMPLETE);
			width.setAccessible(true);
			width.set(this, w);
			height.setAccessible(true);
			height.set(this, h);
		}
		finally {
			width.setAccessible(false);
			height.setAccessible(false);
		}
	}
	
	private synchronized void loadOnDemand() {
		// use super to avoid StackOverflowError
		if (stockLoadDone || (stockName == null) || (super.getImage() != null))
			return;

		stockLoadDone = true;
		//MLogger.debug("core", "Load stock icon: %s", stockName);

		// fix icon size
		int size = (stockSize == -1) ? stockSize : TK.limit(stockSize, MIN_SIZE, MAX_SIZE);
		
		// read icon from the cache
		String cachePath = stockName + '-' + size;
		MIcon icon = cache.get(cachePath);
		if (icon == null) {
			MIcon originalIcon = null;
			int iconWidth = Integer.MIN_VALUE;
			int smallSize = getSmallSize();
			if (size == smallSize) {
				icon = DefaultIconLoader.findIcon(stockName, smallSize);
				if (icon != null) {
					// icon loader supports icon sizes
					iconWidth = icon.getIconWidth();
					if (iconWidth == smallSize) {
						cache.put(cachePath, icon);
						super.setImage(icon.getImage());

						return;
					}
					// icon loader does not support icon sizes
					else {
						originalIcon = icon;
					}
				}
			}

			if (originalIcon == null)
				originalIcon = cache.get(stockName);
			
			if (originalIcon == null) {
				// icon not found in the cache; read from the file
				originalIcon = DefaultIconLoader.findIcon(stockName, -1);

				if (originalIcon == null)
					return;
				
				iconWidth = originalIcon.getIconWidth();
				if (iconWidth < 1) {
					MLogger.error("core", "Could not load icon: \"%s\"", stockName);

					return;
				}
				// MLogger.debug("core", "Caching original icon: \"%s\"", stockName);
				cache.put(stockName, originalIcon);
			}
			else {
				if (iconWidth == Integer.MIN_VALUE)
					iconWidth = originalIcon.getIconWidth();
				//MLogger.debug("core", "Cached original icon: \"%s\"", stockName);
			}
			
			// scale icon to the specified size
			if ((size != -1) && (size != iconWidth))
				icon = originalIcon.scale(size, size, UI.Quality.HIGH);
			else
				icon = originalIcon;
			
			// add icon to the cache
			//MLogger.debug("core", "Caching scaled icon: \"%s\" as \"%s\"", stockName, cachePath);
			cache.put(cachePath, icon);
		}
/*
		else {
			MLogger.debug("core", "Cached scaled icon: \"%s\" (%s)", stockName, cachePath);
		}
*/

		super.setImage(icon.getImage());
	}

	/**
	 * @since 3.2
	 */
	public static interface Name {

		// public

		/**
		 * Returns the current <i>stock</i> icon name or {@code null}.
		 *
		 * @return the current <i>stock</i> icon name or {@code null}.
		 *
		 * @see #setIconName(String)
		 * @see MIcon#getName(Icon)
		 */
		public String getIconName();

		/**
		 * Sets <i>stock</i> icon to {@code value}.
		 * 
		 * Sets non-null, empty icon (with {@code null} image)
		 * if icon resource could not be found.
		 *
		 * @param value the icon name (example: {@code "ui/ok"})
		 *
		 * @see #getIconName()
		 * @see MIcon#stock(String)
		 */
		public void setIconName(final String value);

	}

}
