// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Color;
import java.awt.image.BufferedImage;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.swing.ComponentAnimation;

/**
 * A RGBA color object and various utilities.
 *
 * @since 2.0
 *
 * @see ColorProperty
 */
public class MColor extends Color {
	
	// public
	
	// getAverage options:
	
	/**
	 * @since 4.12
	 */
	public static final int AVERAGE_BRIGHT_ONLY = 1;

	/**
	 * @since 4.12
	 */
	public static final int AVERAGE_DARK_ONLY = 1 << 1;

	// Dark colors:
	
	/**
	 * @preview.color #00892c
	 *
	 * @since 3.0
	 */
	public static final Color DARK_GREEN = new Color(0x00892c); // forest green 5

	/**
	 * @preview.color #8c0000
	 *
	 * @since 3.0
	 */
	public static final Color DARK_RED = new Color(0x8c0000); // red 5

	// Oxygen Palette:

	/**
	 * @preview.color #f9ccca
	 * 
	 * @since 4.0
	 */
	public static final MColor BRICK_RED = new MColor(0xf9ccca);
	
	/**
	 * A default color with an undefined value.
	 *
	 * @since 4.2
	 */
	public static final MColor DEFAULT = new MColor(0x00_00_00_00, true);

	/**
	 * @preview.color #d8e8c2
	 * 
	 * @since 2.4
	 */
	public static final MColor FOREST_GREEN = new MColor(0xd8e8c2);

	/**
	 * @preview.color #ffd9b0
	 *
	 * @since 2.4
	 */
	public static final MColor HOT_ORANGE = new MColor(0xffd9b0);
	
	/**
	 * @preview.color #0000BF
	 *
	 * @since 5.0
	 */
	public static final MColor LINK = new MColor(0x0000BF);
	
	/**
	 * @preview.color #bfd9ff
	 * 
	 * @since 4.0
	 */
	public static final MColor OXYGEN_BLUE = new MColor(0xbfd9ff);
	
	/**
	 * @preview.color #a4c0e4
	 */
	public static final MColor SKY_BLUE = new MColor(0xa4c0e4);

	/**
	 * @preview.color #6193cf
	 *
	 * @since 5.0
	 */
	public static final MColor SKY_BLUE_2 = new MColor(0x6193cf);

	/**
	 * @preview.color #fff6c8
	 * 
	 * @since 4.0
	 */
	public static final MColor SUN_YELLOW = new MColor(0xfff6c8);

	/**
	 * @preview.color #fff299
	 * 
	 * @since 5.0
	 */
	public static final MColor SUN_YELLOW_2 = new MColor(0xfff299);

	// private
	
	private static final MColor HOVER_LINK = new MColor(0xBF0303);
	private static final MColor VISITED_LINK = new MColor(0x85026C);
	
	// public
	
	/**
	 * @since 4.2
	 */
	public MColor(final Color color) {
		super(color.getRGB(), hasAlpha(color));
	}
	
	public MColor(final int rgb) {
		super(rgb);
	}

	/**
	 * @since 4.2
	 */
	public MColor(final int argb, final boolean hasAlpha) {
		super(argb, hasAlpha);
	}
	
	/**
	 * @since 4.8
	 */
	public static int compare(final Color c1, final Color c2) {
		return Integer.compare(c1.getRGB(), c2.getRGB());
	}

	/**
	 * @since 2.4
	 */
	public Color deriveAlpha(final int alpha) {
		return deriveAlpha(this, alpha);
	}

	/**
	 * @since 2.4
	 */
	public static Color deriveAlpha(final Color color, final int alpha) {
		if (color.getAlpha() == alpha)
			return color;

		return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
	}

	/**
	 * @since 2.4
	 */
	public Color deriveColor(final float factor) {
		return deriveColor(this, factor);
	}

// FIXME: black, deprecate?
	/**
	 * @since 2.4
	 */
	public static Color deriveColor(final Color color, final float factor) {
		if (factor == 0.0f)
			return color;
		
		return new Color(
			Math.min(Math.max((int)(color.getRed() * factor), 0), 255),
			Math.min(Math.max((int)(color.getGreen() * factor), 0), 255),
			Math.min(Math.max((int)(color.getBlue() * factor), 0), 255)
		);
	}

	/**
	 * @since 4.4
	 */
	@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
	public static Color fromHSB(final float... hsb) {
		if (hsb.length != 3)
			throw new IllegalArgumentException("Expected 3 array elements (H, S, B)");
		
		return getHSBColor(hsb[0], hsb[1], hsb[2]);
	}

	/**
	 * @since 4.12
	 */
	public static Color getAverage(final BufferedImage image, final int options) {
		int w = image.getWidth();
		int h = image.getHeight();

		if ((w == 0) || (h == 0))
			return null;

		long totalPixels = 0;
		long totalR = 0;
		long totalG = 0;
		long totalB = 0;

		boolean brightOnly = (options & AVERAGE_BRIGHT_ONLY) != 0;
		boolean darkOnly = (options & AVERAGE_DARK_ONLY) != 0;

		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				int p = image.getRGB(x, y);
				int a = (p >> 24) & 0xff;

				if (a < 255)
					continue; // for

				boolean dark = isDark(p);

				if (
					(brightOnly && dark) ||
					(darkOnly && !dark)
				)
					continue; // for

				totalPixels++;
				totalR += (p >> 16) & 0xff;
				totalG += (p >> 8) & 0xff;
				totalB += p & 0xff;
			}
		}

		if (totalPixels == 0)
			return null;

		return new Color(
			(int)(totalR / totalPixels),
			(int)(totalG / totalPixels),
			(int)(totalB / totalPixels)
		);
	}

	/**
	 * @since 2.4
	 */
	public Color getBrighter() {
		return getBrighter(this);
	}

	/**
	 * @since 2.4
	 */
	public Color getBrighter(final int percent) {
		return getBrighter(this, percent);
	}

	/**
	 * @since 2.4
	 */
	public static Color getBrighter(final Color color) {
		return getBrighter(color, 25);
	}

	/**
	 * @since 2.4
	 */
	public static Color getBrighter(final Color color, final int percent) {
		final float FACTOR_1 = (100 - (float)percent) / 100;
		final float FACTOR_2 = ((float)percent / 100) * 255;

		return new Color(
			(int)((color.getRed() * FACTOR_1) + FACTOR_2), // r
			(int)((color.getGreen() * FACTOR_1) + FACTOR_2), // g
			(int)((color.getBlue() * FACTOR_1) + FACTOR_2) // b
		);
	}

	public Color getContrast() {
		return getContrast(this);
	}

	public static Color getContrast(final Color color) {
		return getContrast(color, 0.5f);
	}

	/**
	 * @since 5.0
	 */
	public static Color getContrast(final Color color, final float factor) {
		return
			isDark(color)
			? getBrighter(color, (int)(factor * 100f))
			: deriveColor(color, (1.0f - factor));
	}

	/**
	 * @since 4.6
	 */
	public Color getContrastBW() {
		return getContrastBW(this);
	}

	/**
	 * @mg.note
	 * Since version 5.1 Beta this method uses <a href="http://24ways.org/2010/calculating-color-contrast/">YIQ equation</a>
	 * to determine the returned color.
	 *
	 * @since 4.6
	 */
	public static Color getContrastBW(final Color color) {
		if (color == null)
			return BLACK;

		int r = color.getRed();
		int g = color.getGreen();
		int b = color.getBlue();
		int yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;

		return (yiq >= 128) ? BLACK : WHITE;
	}

	/**
	 * @since 2.4
	 */
	public Color getDarker() {
		return getDarker(this);
	}

	/**
	 * @since 2.4
	 */
	public static Color getDarker(final Color color) {
		return deriveColor(color, 0.94f);
	}

	public static Color getHoverLinkForeground(final Color background) {
		return isDark(background) ? getBrighter(HOVER_LINK, 50) : HOVER_LINK;
	}

	public static Color getLinkForeground(final Color background) {
		return isDark(background) ? getBrighter(LINK, 50) : LINK;
	}

	public static Color getVisitedLinkForeground(final Color background) {
		return isDark(background) ? getBrighter(VISITED_LINK, 50) : VISITED_LINK;
	}
	
	/**
	 * @since 4.2
	 */
	public static boolean hasAlpha(final Color color) {
		return color.getAlpha() < 255;
	}

	/**
	 * @since 5.6
	 */
	public static Color interpolate(final Color from, final Color to, final double fraction) {
		int fr = from.getRed();
		int fg = from.getGreen();
		int fb = from.getBlue();
		int fa = from.getAlpha();

		int r = ComponentAnimation.interpolate(fr, to.getRed(), fraction);
		int g = ComponentAnimation.interpolate(fg, to.getGreen(), fraction);
		int b = ComponentAnimation.interpolate(fb, to.getBlue(), fraction);
		int a = ComponentAnimation.interpolate(fa, to.getAlpha(), fraction);

		if ((r == fr) && (g == fg) && (b == fb) && (a == fa))
			return from;

		return new Color(r, g, b, a);
	}

	/**
	 * Returns @c true if @p color is <i>dark</i>.
	 */
	public boolean isDark() {
		return isDark(this);
	}
	
	/**
	 * Returns @c true if @p color is <i>dark</i>.
	 * Returns @c false if @p color is @c null.
	 */
	public static boolean isDark(final Color color) {
		if (color == null)
			return false;

		return isDark(color.getRGB());
	}
	
	/**
	 * @since 4.0
	 */
	public static float[] toHSB(final Color color) {
		return RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
	}
	
	// private

	private static boolean isDark(final int rgb) {//!!!new algo
		return rgb < 0xff7f7f7f;
	}

}
