// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static java.awt.event.KeyEvent.*;

// Enjoy scrolling! :)
import java.awt.AWTEvent;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Transparency;
import java.awt.Window;
import java.awt.event.AWTEventListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.VolatileImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.InputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.imageio.ImageIO;
import javax.imageio.stream.MemoryCacheImageInputStream;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.FocusManager;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLayer;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.LookAndFeel;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.ButtonUI;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.basic.BasicBorders;
import javax.swing.plaf.metal.MetalBorders;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.OceanTheme;
import javax.swing.plaf.synth.Region;
import javax.swing.plaf.synth.SynthLookAndFeel;
import javax.swing.plaf.synth.SynthStyle;
import javax.swing.plaf.synth.SynthStyleFactory;
import javax.swing.text.JTextComponent;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import makagiga.commons.DropShadowBorder;

import org.makagiga.commons.annotation.ConfigEntry;
import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.style.Style;
import org.makagiga.commons.swing.MLinkAction;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.MSimpleLayout;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.commons.swing.MainView;
import org.makagiga.commons.swing.border.MLineBorder;
import org.makagiga.commons.swing.event.MMouseAdapter;

/** User interface utils. */
public final class UI implements SwingConstants {

	// public

	/**
	 * @since 5.6
	 */
	@ConfigEntry(value = "Hack.standardDecorations")
	public static final BooleanProperty standardDecorations = new BooleanProperty(false);

	/**
	 * @since 3.8.6
	 */
	@ConfigEntry("UI.animations")
	@Obsolete // remove
	public static final BooleanProperty animations = new BooleanProperty(true);

	@ConfigEntry(value = "UI.buttonIcons", platform = true)
	public static final BooleanProperty buttonIcons = new BooleanProperty(false);

	/**
	 * @since 3.0
	 */
	@ConfigEntry(value = "UI.customFont", platform = true)
	public static final FontProperty customFont = new FontProperty();

	@ConfigEntry(value = "UI.hideMainWindowInTray", platform = true)
	public static final BooleanProperty hideMainWindowInTray = new BooleanProperty();

	/**
	 * The current icon size.
	 *
	 * @since 2.0
	 *
	 * @see MIcon#getUISize()
	 */
	@ConfigEntry("UI.iconSize")
	public static final IntegerProperty iconSize = new IntegerProperty(24/* init error: MIcon.getDefaultSize() */);

	@ConfigEntry("UI.mouseGestures")
	public static final BooleanProperty mouseGestures = new BooleanProperty(true);

	/**
	 * @since 3.8.4
	 */
	@ConfigEntry(value = "UI.okCancelLayout", platform = true)
	public static final EnumProperty<OKCancelLayout> okCancelLayout = new EnumProperty<>(OKCancelLayout.AUTO);

	@ConfigEntry(value = "UI.systemTray", platform = true)
	public static final BooleanProperty systemTray = new BooleanProperty(false);

	/**
	 * Unused.
	 *
	 * @deprecated Since 4.4
	 */
	@Deprecated
	public static final EnumProperty<MToolBar.TextPosition> toolBarTextPosition = new EnumProperty<>(MToolBar.TextPosition.UNDER_ICONS);

	/**
	 * @since 3.0
	 */
	@ConfigEntry(value = "UI.useCustomFont", platform = true)
	public static final BooleanProperty useCustomFont = new BooleanProperty();

	/**
	 * @since 3.0
	 */
	@ConfigEntry(value = "UI.notificationSnapRight", platform = true)
	public static final EnumProperty<HorizontalPosition> horizontalNotificationPosition = new EnumProperty<>(HorizontalPosition.RIGHT);

	@ConfigEntry(value = "UI.notificationSnapBottom", platform = true)
	public static final EnumProperty<VerticalPosition> verticalNotificationPosition = new EnumProperty<>(VerticalPosition.BOTTOM);

	/**
	 * @since 3.0
	 *
	 * @deprecated Since 4.8
	 */
	//@ConfigEntry(value = "UI.notificationX", platform = true)
	@Deprecated
	public static final IntegerProperty notificationX = new IntegerProperty(-1);

	/**
	 * @since 3.0
	 *
	 * @deprecated Since 4.8
	 */
	//@ConfigEntry(value = "UI.notificationY", platform = true)
	@Deprecated
	public static final IntegerProperty notificationY = new IntegerProperty(-1);

	/**
	 * @since 3.8
	 */
	@ConfigEntry(value = "UI.notificationTransparent", platform = true)
	public static final BooleanProperty notificationTransparent = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry(value = "UI.statusBarTimeout", description = "Status bar autohide timeout in seconds")
	public static final IntegerProperty statusBarTimeout = new IntegerProperty(10);

	/**
	 * The custom (base) color used by the <i>Nimbus Look And Feel</i>.
	 * 
	 * @since 3.8
	 */
	@ConfigEntry("UI.customColor")
	public static final ColorProperty customColor = new ColorProperty();

	/**
	 * Whether or not {@link #customColor} property is used.
	 *
	 * @since 3.8
	 */
	@ConfigEntry("UI.useCustomColor")
	public static final BooleanProperty useCustomColor = new BooleanProperty();

	// colors
	
	/**
	 * @since 2.0
	 *
	 * @preview.color rgba(255, 255, 255, 0)
	 */
	public static final Color INVISIBLE = new Color(255, 255, 255, 0);
	
	/**
	 * @since 4.4
	 */
	public static final Color NIMBUS_BASE = new Color(51, 98, 140);

	/**
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static final Color TOOL_TIP_BACKGROUND_COLOR = new Color(0xffffdc);

	/**
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static final Color TOOL_TIP_FOREGROUND_COLOR = Color.BLACK;
	
	/**
	 * @preview.color rgba(0, 0, 0, 0.5)
	 */
	public static final Color TRANSPARENT_BLACK = new Color(0, 0, 0, 127);

	/**
	 * @preview.color rgba(127, 127, 127, 0.5)
	 */
	public static final Color TRANSPARENT_GRAY = new Color(127, 127, 127, 127);

	/**
	 * @preview.color rgba(255, 255, 255, 0.5)
	 */
	public static final Color TRANSPARENT_WHITE = new Color(255, 255, 255, 127);

	/**
	 * @since 5.2
	 */
	public static final String BULLET = "\u2022";

	/**
	 * @since 5.2
	 */
	public static final String HORIZONTAL_ELLIPSIS = "\u2026";

	/**
	 * @since 5.2
	 */
	public static final String MULTIPLICATION_SIGN = "\u00D7";
	
	/**
	 * @see <a href="http://en.wikipedia.org/wiki/Specials_%28Unicode_block%29#Replacement_character">Wikipedia</a>
	 *
	 * @since 4.10
	 */
	public static final char REPLACEMENT_CHAR = '\uFFFD';

	/**
	 * @since 3.8.1
	 */
	public static final String DYNAMIC_TOOL_TIP_TEXT = "";
	
	public enum HorizontalPosition {

		LEFT, RIGHT,
		
		/**
		 * @since 5.0
		 */
		NONE

	}

	/**
	 * @since 3.8.4
	 */
	public enum OKCancelLayout {

		// public
		
		AUTO, OK_CANCEL, CANCEL_OK;

		// public

		@SuppressWarnings("deprecation")
		public static OKCancelLayout getDefault() {
			if (OS.isGNOME() || OS.isMac() || OS.isMATE() || OS.isXfce() || OS.isLXDE() || OS.isUnity() || OS.isCinnamon())
				return CANCEL_OK;

			return OK_CANCEL;
		}

		public static boolean isReversed() {
			if (OS.isWindows())
				return false;

			if (UI.okCancelLayout.get() == AUTO)
				return getDefault() == CANCEL_OK;

			return UI.okCancelLayout.get() == CANCEL_OK;
		}

		/**
		 * @since 3.8.6
		 */
		public static void setupUI(final UIDefaults defaults) {
			defaults.put("OptionPane.isYesLast", isReversed());
		}

		@Override
		public String toString() {
			switch (this) {
				case AUTO: return "(" + i18n("Default") + ")";
				case OK_CANCEL: return MActionInfo.OK.getText() + " - " + MActionInfo.CANCEL.getText();
				case CANCEL_OK: return MActionInfo.CANCEL.getText() + " - " + MActionInfo.OK.getText();
				default: throw new WTFError(this);
			}
		}

	}
	
	/**
	 * @since 2.0
	 */
	public enum Quality { LOW, MEDIUM, HIGH }
	
	/**
	 * @since 4.2
	 */
	public enum ToolTipLocationPolicy {
	
		// public
		
		DEFAULT,
		ALONGSIDE,
		ALONGSIDE_PARENT,
		ABOVE,
		UNDER,
		
		/**
		 * @since 4.4
		 */
		WINDOW_CENTER;
		
		// public
		
		public Point getLocation(final Component c, final MouseEvent e) {
			switch (this) {
				case DEFAULT: return null;
				case ALONGSIDE: return new Point(c.getWidth() + 5, 0);
				case ALONGSIDE_PARENT:
					Container parent = c.getParent();

					if (parent == null)
						return null;

					return new Point(parent.getWidth() - c.getX(), 0);
				case ABOVE:
					Font f = UI.getFont(c);
					
					return new Point(0, -(f.getSize() + 10));
				case UNDER: return new Point(0, c.getHeight() + 5);
				case WINDOW_CENTER:
					Window window = UI.windowFor(c);

					if (window == null)
						return null;
						
					Point p = new Point(window.getWidth() / 2, window.getHeight() / 2);
					
					return SwingUtilities.convertPoint(window, p, c);
				default: throw new WTFError(this);
			}
		}
	
	}

	private static final int SIZE_VARIANT_SUPPORTED = 1;
	private static final int HAS_ALTERNATE_LIST_ROW_COLOR = 1 << 1;
	private static final int HAS_ALTERNATE_TREE_ROW_COLOR = 1 << 2;
	private static final int HAS_ALTERNATE_TABLE_ROW_COLOR = 1 << 3;
	private static final int NO_CELL_TIP_SUPPORT = 1 << 4;
	private static final int CUSTOM_COLOR_SUPPORTED = 1 << 5;
	private static final int NO_BUTTON_ROLLOVER_EFFECT_SUPPORT = 1 << 6;
	
	/**
	 * @since 2.0
	 */
	public enum LookAndFeelType {
		
		// public

		UNKNOWN(0, ""),
		GTK(NO_CELL_TIP_SUPPORT /* HACK: performance issues */, "com.sun.java.swing.plaf.gtk.GTKLookAndFeel"),
		METAL(0, "javax.swing.plaf.metal.MetalLookAndFeel"),
		SUBSTANCE(NO_CELL_TIP_SUPPORT, ""),
		WINDOWS(NO_CELL_TIP_SUPPORT, ""),
		NIMBUS(SIZE_VARIANT_SUPPORTED | CUSTOM_COLOR_SUPPORTED, "javax.swing.plaf.nimbus.NimbusLookAndFeel"),
		
		/**
		 * @since 3.0
		 */
		LIPSTIK(NO_BUTTON_ROLLOVER_EFFECT_SUPPORT, ""),

		/**
		 * @since 3.0
		 */
		A03(HAS_ALTERNATE_LIST_ROW_COLOR | HAS_ALTERNATE_TABLE_ROW_COLOR | HAS_ALTERNATE_TREE_ROW_COLOR | CUSTOM_COLOR_SUPPORTED, ""),

		/**
		 * @since 3.8.2
		 */
		SEA_GLASS(HAS_ALTERNATE_TABLE_ROW_COLOR | SIZE_VARIANT_SUPPORTED, ""),

		/**
		 * @since 3.8.6
		 */
		RETRO(HAS_ALTERNATE_LIST_ROW_COLOR | HAS_ALTERNATE_TABLE_ROW_COLOR | HAS_ALTERNATE_TREE_ROW_COLOR | NO_BUTTON_ROLLOVER_EFFECT_SUPPORT | NO_CELL_TIP_SUPPORT, ""),
		
		/**
		 * @since 3.8.8
		 */
		QUAQUA(HAS_ALTERNATE_LIST_ROW_COLOR | HAS_ALTERNATE_TREE_ROW_COLOR | NO_CELL_TIP_SUPPORT, ""),
		
		/**
		 * @since 3.8.8
		 */
		MAC(SIZE_VARIANT_SUPPORTED, ""),
		
		/**
		 * @since 4.2
		 */
		PGS(0, ""),
		
		/**
		 * @since 4.4
		 */
		LOOKS(0, ""),
		
		/**
		 * @since 4.8
		 */
		MOTIF(0, "com.sun.java.swing.plaf.motif.MotifLookAndFeel"),
		
		/**
		 * @since 5.0
		 */
		WEB(0, "com.alee.laf.WebLookAndFeel");

		// private

		private final Flags flags;
		private final String className;
		
		// public
		
		/**
		 * @since 4.8
		 */
		public String getClassName() { return className; }

		/**
		 * @since 3.8.9
		 */
		public boolean hasAlternateListRowColor() { return flags.isSet(HAS_ALTERNATE_LIST_ROW_COLOR); }

		/**
		 * @since 3.8.9
		 */
		public boolean hasAlternateTableRowColor() { return flags.isSet(HAS_ALTERNATE_TABLE_ROW_COLOR); }

		/**
		 * @since 3.8.9
		 */
		public boolean hasAlternateTreeRowColor() { return flags.isSet(HAS_ALTERNATE_TREE_ROW_COLOR); }

		/**
		 * @since 5.2
		 */
		public boolean isButtonRolloverEffectSupported() { return flags.isClear(NO_BUTTON_ROLLOVER_EFFECT_SUPPORT); }

		/**
		 * @since 4.0
		 */
		public boolean isCellTipSupported() { return flags.isClear(NO_CELL_TIP_SUPPORT); }

		/**
		 * @since 4.4
		 */
		public boolean isCustomColorSupported() { return flags.isSet(CUSTOM_COLOR_SUPPORTED); }

		/**
		 * @since 3.8.9
		 */
		public boolean isSizeVariantSupported() { return flags.isSet(SIZE_VARIANT_SUPPORTED); }

		// private

		private LookAndFeelType(final int flags, final String className) {
			this.flags = Flags.valueOf(flags);
			this.className = className;
		}

	}
	
	/**
	 * @since 3.0
	 */
	public enum SizeVariant {
		
		// public

		NORMAL(null),
		
		MINI("mini"),

		SMALL("small"),
		
		LARGE("large");

		// private

		private final String value;

		// public

		/**
		 * @since 3.8.9
		 */
		public void apply(final JComponent c) {
			c.putClientProperty("JComponent.sizeVariant", value);
		}

		@Important
		@Override
		public String toString() { return value; }

		// private

		private SizeVariant(final String value) {
			this.value = value;
		}

	}

	public enum VerticalPosition {

		TOP, BOTTOM,

		/**
		 * @since 5.0
		 */
		NONE

	}

	/**
	 * @since 3.8.3
	 */
	public enum WindowSize {

		// public

		MEDIUM,
		LARGE,
		SCREEN,
		
		/**
		 * @since 4.0
		 *
		 * @deprecated Since 4.10
		 */
		@Deprecated
		SMALL;

		// public

		/**
		 * @since 3.8.9
		 */
		public Dimension getDimension() {
			Dimension d = new Dimension();
			Dimension screen = UI.getScreenSize();
			
			switch (this) {
				case MEDIUM:
					d.width = (int)(screen.width / 1.6f);
					d.height = (int)(screen.height / 1.6f);
					break;
				case LARGE:
					d.width = (int)(screen.width / 1.28);
					d.height = (int)(screen.height / 1.28);
					break;
				case SCREEN:
					d.setSize(screen);
					break;
				case SMALL:
					d.width = (int)(screen.width / 2.0f);
					d.height = (int)(screen.height / 2.0f);
					break;
				default:
					throw new WTFError(this);
			}

			return d;
		}

		/**
		 * @since 4.2
		 */
		public Dimension getDimensionForDialog() {
			Dimension d = getDimension();
			
			// Use LARGE size on small screens to avoid
			// very small window.
			int minWidth = 0;
			int minHeight = 0;
			Dimension screen = UI.getScreenSize();
			if (UI.isSmallScreen(screen)) {
				switch (this) {
					case MEDIUM: // map to LARGE
						minWidth = (int)(screen.width / 1.28);
						minHeight = (int)(screen.height / 1.28);
						break;
					case LARGE: // map to WORKSPACE
						Insets i = UI.getScreenInsets();
						d.width = screen.width - (i.left + i.right) - 20;
						d.height = screen.height - (i.top + i.bottom) - 20;
						break;
				}
			}

			// HACK: Math.min fixes crash on xinerama screens
			switch (this) {
				case MEDIUM:
					d.width = TK.limit(d.width, Math.min(minWidth, 800), 800);
					d.height = TK.limit(d.height, Math.min(minWidth, 600), 600);
					break;
				case LARGE:
					d.width = TK.limit(d.width, Math.min(minWidth, 1024), 1024);
					d.height = TK.limit(d.height, Math.min(minWidth, 768), 768);
					break;
				case SMALL:
					d.width = Math.min(d.width, 640);
					d.height = Math.min(d.height, 480);
					break;
			}
			
			return d;
		}

		/**
		 * @since 3.8.11
		 */
		public int getHeight() {
			return getDimension().height;
		}

		/**
		 * @since 3.8.11
		 */
		public int getWidth() {
			return getDimension().width;
		}

	}
	
	// paintText flags
	
	/**
	 * Trim every line before draw.
	 *
	 * @since 2.0
	 */
	public static final int PAINT_TEXT_TRIM_LINES = 1;

	/**
	 * HTML tags used internally.
	 */
	public static final String HTML_BEGIN = "<html><body>";

	/**
	 * HTML tags used internally.
	 */
	public static final String HTML_END = "</body></html>";

	// characters
	
	/**
	 * @since 3.0
	 */
	public static final String LEFT_POINTER = "\u25c4";
	
	public static final String RIGHT_POINTER = "\u25ba";
	public static final String TM = "\u2122";

	// private

	private static AWTEventListener metalAWTEventListener;
	private static BasicStroke basicFocusStroke;
	private static boolean synth;
	private static boolean textAAInitialized;
	private static boolean windowsClassic;
	private static Cursor invisibleCursor;
	private static Font customFontValue;
	private static Font _defaultFont;
	private static LookAndFeelType lookAndFeelType;
	private static Map<Object, Object> textAA;
	private static final Singleton<SimpleButtonUI> simpleButtonUISingleton = new Singleton<>(SimpleButtonUI::new);
	private static String monospacedFontName;

	// public

/* DEAD:
	 * @deprecated Since 4.10
	@Deprecated
	public static String _(final String id) {
		return Gettext.translate(id);
	}

	 * @deprecated Since 4.10
	@Deprecated
	public static String _(final String id, final Object... args) {
		return i18n(id, args);
	}
*/

	public static void addCenter(final Container parent, final JComponent component) {
		Object constraints =
			(parent.getLayout() instanceof MSimpleLayout)
			? MSimpleLayout.Position.CENTER
			: BorderLayout.CENTER;
		
		if (needScrollPane(component))
			parent.add(new MScrollPane(component), constraints);
		else
			parent.add(component, constraints);
	}

	/**
	 * Emits a system "beep" notification/sound.
	 * This feature depends on the current operating system configuration.
	 *
	 * @since 5.6
	 */
	public static void beep() {
		Toolkit.getDefaultToolkit().beep();
	}

	/**
	 * @mg.note
	 * Since version 4.2 the minimum value is #getMinimumFontSize().
	 *
	 * @since 3.8
	 */
	public static Font changeFontSize(final Component component, final int relativeSize) {
		return changeFontSize(component, relativeSize, getMinimumFontSize(), 40);
	}

	public static Font changeFontSize(final Component component, final int relativeSize, final int minimum, final int maximum) {
		Font oldFont = component.getFont();

		if (oldFont == null)
			return null;
		
		if (relativeSize == 0)
			return oldFont;
		
		int newSize = oldFont.getSize() + relativeSize;
		if (minimum != -1)
			newSize = Math.max(newSize, minimum);
		if (maximum != -1)
			newSize = Math.min(newSize, maximum);

		if (newSize == oldFont.getSize())
			return oldFont;

		Font newFont = oldFont.deriveFont((float)newSize);
		component.setFont(newFont);

		return newFont;
	}
	
	/**
	 * @since 2.0
	 */
	public synchronized static Font createDefaultFont() {
		if (_defaultFont == null)
			_defaultFont = new Font(Font.DIALOG, Font.PLAIN, getDefaultFontSize());

		return _defaultFont;
	}
	
	public static Border createDropShadowBorder() {
		return new DropShadowBorder();
	}

	public static Border createEmptyBorder(final int size) {
		return BorderFactory.createEmptyBorder(size, size, size, size);
	}
	
	/**
	 * @since 4.2
	 */
	public static JComponent createGap(final int w, final int h) {
		return (JComponent)Box.createRigidArea(new Dimension(w, h));
	}

	public static List<Object> createGradient(final Color color1, final Color color2) {
		return createGradient(1.0f, 0.0f, color1, color2);
	}
	
	// see the "Ocean Gradient Customizer"
	// http://weblogs.java.net/blog/zixle/archive/2005/09/customizing_oce_1.html
	// http://www.java.net/download/javadesktop/blogs/zixle/2005.09.15/gradients.jnlp
	public static List<Object> createGradient(final float firstGradient, final float filledRegion, final Color color1, final Color color2) {
		return new MArrayList<Object>(
			firstGradient,
			filledRegion,
			new ColorUIResource(color1),
			new ColorUIResource(color2),
			new ColorUIResource(color1)
		);
	}
	
	public static Insets createInsets(final int size) {
		return new Insets(size, size, size, size);
	}

	/**
	 * Creates and returns a fixed-width font
	 * (Consolas, Lucida Sans Typewriter, DejaVu Sans Mono, or generic {@code java.awt.Font.MONOSPACED})
	 * with {@code java.awt.Font.PLAIN} style.
	 *
	 * @param size the font size
	 *
	 * @since 3.8.5
	 *
	 * @deprecated As of 4.4, replaced by {@link #createMonospacedFont(int, int)}
	 */
	@Deprecated
	public static Font createMonospacedFont(final int size) {
		return createMonospacedFont(Font.PLAIN, size);
	}

	/**
	 * @since 4.4
	 */
	public static Font createMonospacedFont(final int style, final int size) {
		synchronized (UI.class) {
			if (monospacedFontName != null)
				return new Font(monospacedFontName, style, size);
		}
	
		Font font;
		if (OS.isWindows()) {
			font = new Font("Consolas", style, size);
			if (font.getFamily().equals(Font.DIALOG))
				font = new Font("Lucida Sans Typewriter", style, size);
		}
		else {
			font = new Font("DejaVu Sans Mono", style, size);
		}

		// fallback
		if (font.getFamily().equals(Font.DIALOG))
			font = new Font(Font.MONOSPACED, style, size);
	
		synchronized (UI.class) {
			monospacedFontName = font.getName();
		}
	
		return font;
	}
	
	/**
	 * @since 4.8
	 */
	public static Stroke createSeparatorStroke(final float size) {
		return new BasicStroke(
			size,
			BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER,
			1.0f, new float[] { 10.0f, 2.0f }, 1.0f
		);
	}

	/**
	 * @since 4.0
	 */
	public static Font deriveFontSize(final Font baseFont, final int newSize) {
		if (baseFont.getSize() == newSize)
			return baseFont;

		return baseFont.deriveFont((float)newSize);
	}

	/**
	 * @since 4.4
	 */
	public static Font deriveFontStyle(final Font baseFont, final int newStyle) {
		if (baseFont.getStyle() == newStyle)
			return baseFont;

		return baseFont.deriveFont(newStyle);
	}
	
	/**
	 * @since 4.8
	 */
	public static Font deriveMonospacedFont(final Font font) {
		return createMonospacedFont(font.getStyle(), font.getSize());
	}

	/**
	 * @since 3.8
	 */
	@Obsolete
	@SuppressWarnings("unchecked")
	public static <T extends Container> T getAncestorOfClass(final Class<T> containerClass, final Component c) {
		return (T)SwingUtilities.getAncestorOfClass(containerClass, c);
	}

	/**
	 * @since 5.0
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Container> Optional<T> getAncestorOfType(final Class<T> containerClass, final Component c) {
		return Optional.ofNullable((T)SwingUtilities.getAncestorOfClass(containerClass, c));
	}

	/**
	 * @since 2.0
	 */
	public static double getAutoScale(final Image image, final Dimension maxSize) {
		return getAutoScale(new Dimension(image.getWidth(null), image.getHeight(null)), maxSize);
	}
	
	public static double getAutoScale(final Dimension imageSize, final Dimension maxSize) {
		double result;
		
		if (imageSize.width > maxSize.width)
			result = (double)maxSize.width / (double)imageSize.width;
		else
			result = 1.0d;

		int height = (int)((double)imageSize.height * result);
		if (height > maxSize.height)
			result *= (double)maxSize.height / (double)height;
		
		return result;
	}

	/**
	 * @since 3.8.5
	 */
	public static Color getBackground(final Component c) {
		return TK.get(c.getBackground(), Color.WHITE);
	}
	
	/**
	 * An alias for {@link javax.swing.FocusManager#getFocusOwner()}.
	 *
	 * @since 4.4
	 */
	public static Component getFocusOwner() {
		return FocusManager.getCurrentManager().getFocusOwner();
	}

	/**
	 * @since 3.8.5
	 */
	public static Color getForeground(final Component c) {
		return TK.get(c.getForeground(), Color.BLACK);
	}

	/**
	 * @since 2.0
	 */
	public static Color getBrighter(final Color color, final int percent, final Color safeColor) {
		return (color == null) ? safeColor : MColor.getBrighter(color, percent);
	}

	@SuppressWarnings("unchecked")
	public static <T> T getClientProperty(final JComponent component, final String key, final T defaultValue) {
		Object value = component.getClientProperty(key);

		return (value == null) ? defaultValue : (T)value;
	}

	/**
	 * @deprecated Since 4.4
	 */
	@Deprecated
	public static Color getColor(final String key) {
		return UIManager.getColor(key);
	}
	
	/**
	 * @since 2.0
	 */
	public static Color getColor(final Color color, final float factor, final Color safeColor) {
		return (color == null) ? safeColor : MColor.deriveColor(color, factor);
	}
	
	/**
	 * @since 2.0
	 */
	public static Color getDarker(final Color color, final Color safeColor) {
		return (color == null) ? safeColor : MColor.getDarker(color);
	}

	/**
	 * Returns {@code 12}.
	 *
	 * @return {@code 12}
	 * 
	 * @since 2.0
	 */
	public static int getDefaultFontSize() { return 12; }

	/**
	 * @since 4.0
	 */
	public static int getDialogButtonSpacing() {
		return isWindows() ? 7 : 15;
	}
	
	/**
	 * @since 4.6
	 */
	public synchronized static Stroke getFocusStroke() {
		if (basicFocusStroke == null) {
			basicFocusStroke = new BasicStroke(
				1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND,
				1.0f, new float[] { 2.0f }, 1.0f
			);
		}
		
		return basicFocusStroke;
	}

	/**
	 * @since 3.8.8
	 */
	public static Font getFont(final Component c) {
		Font font = c.getFont();

		return (font != null) ? font : createDefaultFont();
	}

	/**
	 * @since 3.0
	 */
	public synchronized static Cursor getInvisibleCursor() {
		if (invisibleCursor == null) {
			invisibleCursor = Toolkit.getDefaultToolkit().createCustomCursor(
				createCompatibleImage(1, 1, true),
				new Point(),
				"invisible"
			);
		}

		return invisibleCursor;
	}

	/**
	 * @since 4.0
	 */
	public static String getLinkToolTipText(final String url) {
		if (url == null)
			return null;

		Color bg = isWeb() ? Color.BLACK : getColor("ToolTip.background");
		Color fg = isMetal() ? MColor.OXYGEN_BLUE : MColor.getLinkForeground(bg);

		String linkTag = String.format(
			"<a href=\"%s\" style=\"color: %s; text-decoration: none\">%s</a>",
			url,
			ColorProperty.toString(fg),
			TK.centerSqueeze(MLinkAction.simplifyURI(url), 128)
		);

		return makeHTML(i18n("Open {0}", linkTag));
	}

	private static LookAndFeelType detectLookAndFeelType() { // private
		windowsClassic = false;
		LookAndFeel laf = UIManager.getLookAndFeel();
		synth = (laf instanceof SynthLookAndFeel);
		String className = (laf == null) ? null : laf.getClass().getName();
		
		if (className == null)
			return LookAndFeelType.UNKNOWN;

		switch (className) {
			// standard
			case "com.sun.java.swing.plaf.windows.WindowsLookAndFeel":
				// CREDITS: http://stackoverflow.com/questions/3659055/cant-detect-that-windows-classic-theme-active
				windowsClassic = !Boolean.TRUE.equals(
					Toolkit.getDefaultToolkit().getDesktopProperty("win.xpstyle.themeActive")
				);

				return LookAndFeelType.WINDOWS;
			case "com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel":
				windowsClassic = true;
			
				return LookAndFeelType.WINDOWS;
			case "apple.laf.AquaLookAndFeel":
			case "com.apple.laf.AquaLookAndFeel":
			case "com.apple.mrj.swing.MacLookAndFeel":
				return LookAndFeelType.MAC;
			// plugins
			case "a03.swing.plaf.A03LookAndFeel":
				return LookAndFeelType.A03;
			case "ch.randelshofer.quaqua.QuaquaLookAndFeel":
				return LookAndFeelType.QUAQUA;
			case "com.lipstikLF.LipstikLookAndFeel":
				return LookAndFeelType.LIPSTIK;
			case "com.pagosoft.plaf.PgsLookAndFeel":
				return LookAndFeelType.PGS;
			case "com.seaglasslookandfeel.SeaGlassLookAndFeel":
				return LookAndFeelType.SEA_GLASS;
			case "org.makagiga.retro.RetroLookAndFeel":
				return LookAndFeelType.RETRO;
			default: {
				if (LookAndFeelType.NIMBUS.getClassName().equals(className))
					return LookAndFeelType.NIMBUS;

				if (LookAndFeelType.GTK.getClassName().equals(className))
					return LookAndFeelType.GTK;

				if (LookAndFeelType.MOTIF.getClassName().equals(className))
					return LookAndFeelType.MOTIF;

				if (LookAndFeelType.WEB.getClassName().equals(className))
					return LookAndFeelType.WEB;
			}
		}

		if (
			(laf instanceof MetalLookAndFeel) &&
			(MetalLookAndFeel.getCurrentTheme() instanceof OceanTheme)
		)
			return LookAndFeelType.METAL;
		
		if (
			className.startsWith("org.jvnet.substance.") ||
			((laf != null) && laf.getName().startsWith("Substance "))
		)
			return LookAndFeelType.SUBSTANCE;
		
		if (className.startsWith("com.jgoodies.looks."))
			return LookAndFeelType.LOOKS;

		return LookAndFeelType.UNKNOWN;
	}

	/**
	 * @since 2.0
	 */
	public static LookAndFeelType getLookAndFeelType() {
		synchronized (UI.class) {
			if (lookAndFeelType == null)
				lookAndFeelType = detectLookAndFeelType();
		}
		
		return lookAndFeelType;
	}

	/**
	 * @since 5.6
	 */
	public static int getMinimumFontSize() { return 10; }

	/**
	 * @since 4.8
	 */
	public static String getMonospacedFontName() {
		synchronized (UI.class) {
			if (monospacedFontName != null)
				return monospacedFontName;
		}

		createMonospacedFont(UI.getDefaultFontSize()); // init "monospacedFontName" field

		synchronized (UI.class) {
			return monospacedFontName;
		}
	}

	/**
	 * @since 3.0
	 */
	public static String getPreferredLookAndFeelClassName() {
		String laf = UIManager.getSystemLookAndFeelClassName();

		if (isBlacklisted(laf) || LookAndFeelType.GTK.getClassName().equals(laf))
			laf = LookAndFeelType.METAL.getClassName();

		// use Nimbus instead of Metal
		//if (LookAndFeelType.METAL.getClassName().equals(laf))
		//	laf = LookAndFeelType.NIMBUS.getClassName();
		
		return laf;
	}

	/**
	 * @since 4.6
	 */
	public static Insets getScreenInsets() {
		return Toolkit
			.getDefaultToolkit()
			.getScreenInsets(getDefaultConfiguration());
	}
	
	/**
	 * @since 2.0
	 */
	public static Dimension getScreenSize() {
		return Toolkit.getDefaultToolkit().getScreenSize();
	}
	
	/**
	 * Returns a generic, non-null <i>selection</i> background color
	 * that matches the current Look And Feel.
	 *
	 * @since 4.0
	 */
	public static Color getSelectionBackground() {
		Color c;
		// HACK: Nimbus/Sea Glass
		if (isNimbus() || isSeaGlass()) {
			c = getColor("textHighlight");
			if (c != null)
				c = new MColor(c);
		}
		else
			c = getColor("TextField.selectionBackground");
		
		return TK.get(c, MColor.SKY_BLUE);
	}

	/**
	 * Returns a generic, non-null <i>selection</i> foreground color
	 * that matches the current Look And Feel.
	 *
	 * @since 4.4
	 */
	public static Color getSelectionForeground() {
		Color c;
		// HACK: Nimbus/Sea Glass
		if (isNimbus() || isSeaGlass()) {
			c = getColor("textHighlightText");
			if (c != null)
				c = new MColor(c);
		}
		else
			c = getColor("TextField.selectionForeground");
		
		return TK.get(c, MColor.BLACK);
	}

	/**
	 * @since 2.0
	 */
	public static ButtonUI getSimpleButtonUI() {
		return simpleButtonUISingleton.get();
	}
	
	/**
	 * @since 2.0
	 */
	public static ButtonGroup group(final AbstractButton... buttons) {
		ButtonGroup buttonGroup = new ButtonGroup();
		for (AbstractButton i : buttons) {
			if (i != null)
				buttonGroup.add(i);
		}
		
		return buttonGroup;
	}

	/**
	 * @since 3.4
	 */
	public static void hideToolTip(final JComponent c) {
		if (c == null) {
			ToolTipManager manager = ToolTipManager.sharedInstance();
			if (manager.isEnabled()) {
				try {
					manager.setEnabled(false); // hide tool tip window
				}
				finally {
					manager.setEnabled(true); // restore option
				}
			}
			
			return;
		}

		ActionMap am = c.getActionMap();
		if (am != null) {
			Action hideAction = am.get("hideTip");
			if (hideAction != null)
				MAction.fire(hideAction, c);
		}
	}

	/**
	 * @since 4.6
	 */
	public static String i18n(final String id) {
		return Gettext.translate(id);
	}

	/**
	 * @since 4.6
	 */
	public static String i18n(final String id, final Object... args) {
		try {
			return MessageFormat.format(Gettext.translate(id), args);
		}
		catch (IllegalArgumentException exception) {
			MLogger.error("core", "Invalid text/message format: \"%s\"", id);
			MLogger.exception(exception);

			return MessageFormat.format(id, args);
		}
	}

	/**
	 * @since 4.0
	 */
	public static PropertyChangeListener installLookAndFeelListener(final Component c) {
		LookAndFeelListener lookAndFeelListener = new LookAndFeelListener(c);
		UIManager.addPropertyChangeListener(lookAndFeelListener);
		
		return lookAndFeelListener;
	}

	/**
	 * @since 2.4
	 */
	public static <T> T invokeAndWait(final Callable<T> c) throws Exception {
		if (EventQueue.isDispatchThread()) {
			return c.call();
		}
		else {
			final AtomicReference<Exception> exception = new AtomicReference<>();
			final AtomicReference<T> result = new AtomicReference<>();
			EventQueue.invokeAndWait(new Runnable() {
				@Override
				public void run() {
					try {
						result.set(c.call());
					}
					catch (Exception e) {
						exception.set(e);
					}
				}
			} );
			
			Exception e = exception.get();
			if (e != null)
				throw e;
			
			return result.get();
		}
	}

	/**
	 * @since 2.0
	 */
	public static void invokeAndWait(final Runnable r) throws InterruptedException, InvocationTargetException {
		if (EventQueue.isDispatchThread())
			r.run();
		else
			EventQueue.invokeAndWait(r);
	}

	/**
	 * @since 2.0
	 */
	public static void invokeLater(final Runnable r) {
		if (EventQueue.isDispatchThread())
			r.run();
		else
			EventQueue.invokeLater(r);
	}

	/**
	 * @since 3.0
	 */
	public static boolean isA03() {
		return getLookAndFeelType() == LookAndFeelType.A03;
	}

	/**
	 * Returns {@code true} for {@code com.sun.java.swing.plaf.motif.MotifLookAndFeel} class name.
	 *
	 * @since 3.8
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public static boolean isBlacklisted(final String lafClassName) {
		return LookAndFeelType.MOTIF.getClassName().equals(lafClassName);
	}

	/**
	 * @since 3.0
	 */
	public static boolean isLipstik() {
		return getLookAndFeelType() == LookAndFeelType.LIPSTIK;
	}

	/**
	 * @since 4.4
	 */
	public static boolean isLooks() {
		return getLookAndFeelType() == LookAndFeelType.LOOKS;
	}

	/**
	 * @since 3.8.8
	 */
	public static boolean isMac() {
		return getLookAndFeelType() == LookAndFeelType.MAC;
	}

	/**
	 * @since 2.0
	 */
	public static boolean isNimbus() {
		return getLookAndFeelType() == LookAndFeelType.NIMBUS;
	}
	
	/**
	 * @since 3.8.8
	 */
	public static boolean isQuaqua() {
		return getLookAndFeelType() == LookAndFeelType.QUAQUA;
	}
	
	/**
	 * @since 2.0
	 */
	public static boolean isRTL(final Component c) {
		return c.getComponentOrientation() == ComponentOrientation.RIGHT_TO_LEFT;
	}

	/**
	 * @since 4.10
	 */
	public static boolean isSmallScreen(final Dimension size) {
		return (size.width <= 800) || (size.height <= 600);
	}

	/**
	 * @since 2.4
	 */
	public static boolean isSynth() {
		getLookAndFeelType(); // init on demand
		synchronized (UI.class) {
			return synth;
		}
	}

	/**
	 * @since 5.0
	 */
	public static boolean isWeb() {
		return getLookAndFeelType() == LookAndFeelType.WEB;
	}

	/**
	 * @since 5.4
	 */
	public static <T> T lengthyOperation(final Supplier<T> supplier) {
		return lengthyOperation(MainView.getWindow(), supplier);
	}

	/**
	 * @since 5.4
	 */
	public static <T> T lengthyOperation(final Component component, final Supplier<T> supplier) {
		ElapsedTimer timer = new ElapsedTimer(true);
		try {
			if (component != null)
				setWaitCursor(component, true);
		
			return supplier.get();
		}
		finally {
			if (MLogger.isDeveloper()) {
				MLogger.debug(
					"core",
					"Lengthy operation \"%s\" took %s ms",
					supplier,
					MFormat.nano(timer.elapsedNano())
				);
			}

			if (component != null)
				setWaitCursor(component, false);
		}
	}

	/**
	 * @since 4.0
	 */
	public static void paintFocus(final Component c, final Graphics2D g, final Color color, final int insets) {
		int w = c.getWidth();
		int h = c.getHeight();
		g.setColor((color == null) ? getForeground(c) : color);
		Stroke oldStroke = g.getStroke();
		g.setStroke(getFocusStroke());
		g.drawRect(insets, insets, w - insets * 2 - 1, h - insets * 2 - 1);
		g.setStroke(oldStroke);
	}

	/**
	 * @since 3.4
	 */
	public static void setHTMLEnabled(final JComponent c, final boolean enabled) {
		c.putClientProperty("html.disable", enabled ? null : true);
	}

	/**
	 * @since 2.0
	 */
	public static void setStyle(final String style, final Component... components) {
		if (TK.isEmpty(style))
			return;
		
		try {
			//Benchmark b = Benchmark.begin("style");
			Style s = new Style(components[0].getFont(), style);
			for (Component i : components)
				s.apply(i);
			//b.end();
		}
		catch (ParseException exception) {
			MLogger.exception(exception);
		}
	}

	public static int getTypeForImageFormat(final String format) {
		if (format == null)
			return BufferedImage.TYPE_INT_ARGB;
		
		if (format.equalsIgnoreCase("BMP"))
			return BufferedImage.TYPE_3BYTE_BGR;

		if (format.equalsIgnoreCase("JPG") || format.equalsIgnoreCase("JPEG"))
			return BufferedImage.TYPE_INT_RGB;

		// GIF, PNG
		return BufferedImage.TYPE_INT_ARGB;
	}

	/**
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public static Color getXorColor(final Color color) {
		if (color == null)
			return null;

		return new Color(color.getRGB() ^ 0xffffff);
	}
	
	/**
	 * @since 2.0
	 */
	public static void init() {
		MLogger.debug("ui", "Current look and feel: %s", getLookAndFeelType());
		
		UIDefaults defaults = UIManager.getDefaults();

		// init color chooser
		defaults.put("ColorChooser.swatchesSwatchSize", new Dimension(MIcon.getSmallSize(), MIcon.getSmallSize()));

		// init option pane
		Icon cancelIcon = buttonIcons.booleanValue() ? MActionInfo.CANCEL.getIcon() : null;
		Icon okIcon = buttonIcons.booleanValue() ? MActionInfo.OK.getIcon() : null;
		defaults.put("OptionPane.cancelButtonText", MActionInfo.CANCEL.getText());
		defaults.put("OptionPane.cancelIcon", cancelIcon);
		defaults.put("OptionPane.errorIcon", MIcon.stock("ui/error"));
		defaults.put("OptionPane.informationIcon", MIcon.stock("ui/info"));
		defaults.put("OptionPane.noIcon", cancelIcon);
		defaults.put("OptionPane.okButtonText", MActionInfo.OK.getText());
		defaults.put("OptionPane.okIcon", okIcon);
		defaults.put("OptionPane.questionIcon", MIcon.stock("ui/question"));
		defaults.put("OptionPane.yesIcon", okIcon);
		defaults.put("OptionPane.warningIcon", MIcon.stock("ui/warning"));

		// match MButtonPanel/MDialog UI
		defaults.put("OptionPane.buttonOrientation", RIGHT);
		defaults.put("OptionPane.buttonPadding", getDialogButtonSpacing());
		defaults.put("OptionPane.sameSizeButtons", true);
		OKCancelLayout.setupUI(defaults);

		// init slider
		defaults.put("Slider.paintValue", false); // supported only by GTK+ - disable
		
		boolean needScrollBarMiddleButtonFix = false;

		// a03 specific

		if (isA03()) {
			needScrollBarMiddleButtonFix = true;
		}
		
		// gtk specific

		else if (isGTK()) {
			defaults.put("ComboBox.squareButton", false);

			// HACK: fix menu border and separators
			// CREDITS: http://www.ailis.de/~k/archives/67-Workaround-for-borderless-Java-Swing-menus-on-Linux.html
			// BUG: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6925412
			if (isSynth()) {
				try {
					SynthStyleFactory styleFactory = SynthLookAndFeel.getStyleFactory();

					SynthStyle popupMenuStyle = styleFactory.getStyle(new JPopupMenu(), Region.POPUP_MENU);
					fixGTKThickness(popupMenuStyle, "xThickness");
					fixGTKThickness(popupMenuStyle, "yThickness");

					SynthStyle separatorStyle = styleFactory.getStyle(new JPopupMenu.Separator(), Region.POPUP_MENU_SEPARATOR);
					fixGTKThickness(separatorStyle, "yThickness");
				}
				catch (Throwable throwable) { // <- just in case
					MLogger.developerException(throwable);
				}
			}
		}
		
		// metal specific

		else if (isMetal()) {

			// init accelerator font

			// use same font size instead of small 10
			Font acceleratorFont = defaults.getFont("MenuItem.font");
			if (acceleratorFont != null) {
				defaults.put("CheckBoxMenuItem.acceleratorFont", acceleratorFont);
				defaults.put("MenuItem.acceleratorFont", acceleratorFont);
				defaults.put("RadioButtonMenuItem.acceleratorFont", acceleratorFont);
			}
			
			// init check icons
			Icon checkIcon = new CheckIcon();
			defaults.put("CheckBox.icon", checkIcon);
			defaults.put("RadioButton.icon", checkIcon);
			defaults.put("CheckBoxMenuItem.checkIcon", checkIcon);
			defaults.put("RadioButtonMenuItem.checkIcon", checkIcon);
			
			// init gradients
			Object gradient = createGradient(new Color(0xDDE8F3), Color.WHITE);
			defaults.put("MenuBar.gradient", gradient);
			defaults.put("Slider.gradient", gradient);
			defaults.put("Slider.focusGradient", gradient);
			defaults.put("ScrollBar.gradient", gradient);
			defaults.put("CheckBoxMenuItem.gradient", gradient);
			defaults.put("RadioButtonMenuItem.gradient", gradient);
			defaults.put("Button.gradient", gradient);
			defaults.put("CheckBox.gradient", gradient);
			defaults.put("RadioButton.gradient", gradient);
			defaults.put("ToggleButton.gradient", gradient);

			// init menu
			defaults.put("CheckBoxMenuItem.background", Color.WHITE);
			defaults.put("Menu.background", Color.WHITE);
			defaults.put("MenuItem.background", Color.WHITE);
			defaults.put("PopupMenu.background", Color.WHITE);
			defaults.put("RadioButtonMenuItem.background", Color.WHITE);
			defaults.put("Separator.background", Color.WHITE);

			// increase menu height
			if (!Screen.getPrimary().isSmallHeight()) {
				Border menuItemBorder = BorderFactory.createCompoundBorder(
					new MetalBorders.MenuItemBorder(), // 2px insets
					BorderFactory.createEmptyBorder(2, 0, 2, 0) // add extra top/bottom padding
				);
				defaults.put("Menu.border", menuItemBorder);
				defaults.put("MenuItem.border", menuItemBorder);
				defaults.put("CheckBoxMenuItem.border", menuItemBorder);
				defaults.put("RadioButtonMenuItem.border", menuItemBorder);
			}

			Color menuSelectionBG = defaults.getColor("textHighlight");
			Color menuSelectionFG = defaults.getColor("textHighlightText");
			if ((menuSelectionBG != null) && (menuSelectionFG != null)) {
				defaults.put("Menu.selectionBackground", menuSelectionBG);
				defaults.put("Menu.selectionForeground", menuSelectionFG);
				defaults.put("MenuItem.selectionBackground", menuSelectionBG);
				defaults.put("MenuItem.selectionForeground", menuSelectionFG);
				defaults.put("CheckBoxMenuItem.selectionBackground", menuSelectionBG);
				defaults.put("CheckBoxMenuItem.selectionForeground", menuSelectionFG);
				defaults.put("RadioButtonMenuItem.selectionBackground", menuSelectionBG);
				defaults.put("RadioButtonMenuItem.selectionForeground", menuSelectionFG);

				defaults.put("ComboBox.selectionBackground", menuSelectionBG);
				defaults.put("ComboBox.selectionForeground", menuSelectionFG);
			}

			// init scroll pane

			ColorUIResource scrollBarColor = new ColorUIResource(MetalLookAndFeel.getControl());
			ColorUIResource scrollBarThumbBorderColor = new ColorUIResource(MetalLookAndFeel.getPrimaryControlShadow());

			defaults.put("ScrollBar.background", scrollBarColor);
			defaults.put("ScrollBar.highlight", scrollBarColor);

			defaults.put("ScrollBar.shadow", scrollBarColor);
			defaults.put("ScrollBar.darkShadow", scrollBarColor);

			defaults.put("ScrollBar.thumbShadow", scrollBarThumbBorderColor);
			defaults.put("ScrollBar.thumbHighlight", scrollBarColor);

/* DEAD:
			for (Object i : defaults.entrySet().toArray()) {
				@SuppressWarnings("unchecked")
				Map.Entry<Object, Object> entry = (Map.Entry<Object, Object>)i;
				if (entry.getKey().toString().endsWith(".selectionBackground") && (entry.getValue() instanceof Color))
					defaults.put(entry.getKey().toString(), lightBlue);
			}
*/

			// init tabbed pane
			defaults.put("TabbedPane.tabInsets", new Insets(3, 5, 2, 5));

			// init text components & scroll pane

			Color normalColor = MetalLookAndFeel.getInactiveControlTextColor();
			MLineBorder lineBorder = new MLineBorder();
			Color focusedColor = MetalLookAndFeel.getFocusColor();
			for (MLineBorder.Style i : lineBorder) {
				i.setDisabledColor(normalColor);
				i.setFocusedColor(focusedColor);
				i.setColor(normalColor);
			}
			MLineBorder.Style bottomStyle = lineBorder.getBottom();
			bottomStyle.setFocusedColor(MetalLookAndFeel.getControlShadow());
			bottomStyle.setSize(2);
			
			Border textBorder = new BorderUIResource.CompoundBorderUIResource(
				lineBorder,
				new BasicBorders.MarginBorder()
			);
			defaults.put("FormattedTextField.border", textBorder);
			defaults.put("TextField.border", textBorder);
			defaults.put("PasswordField.border", textBorder);
			defaults.put("Spinner.border", textBorder);

			MLineBorder scrollPaneBorder = new MLineBorder();
			for (MLineBorder.Style i : scrollPaneBorder) {
				i.setDisabledColor(normalColor);
				i.setFocusedColor(focusedColor);
				i.setColor(normalColor);
			}
			defaults.put("ScrollPane.border", scrollPaneBorder);
			
			// repaint border on focus change
			if (metalAWTEventListener == null) {
				metalAWTEventListener = new AWTEventListener() {
					@Override
					public void eventDispatched(final AWTEvent e) {
						if (UI.isMetal() && (e instanceof FocusEvent)) {
							FocusEvent fe = (FocusEvent)e;
							if ((fe.getID() == FocusEvent.FOCUS_GAINED) && !fe.isTemporary()) {
								repaint(fe.getComponent());
								repaint(fe.getOppositeComponent());
							}
						}
					}
					private void repaint(final Component c) {
						if (c instanceof JComponent) {
							JComponent jc = (JComponent)c;
							JScrollPane sp = MScrollPane.getScrollPane(jc);
							if ((sp != null) && (sp.getBorder() == scrollPaneBorder)) {
								sp.repaint();//!!!opt repaint
							}
							else {
								JSpinner spinner = UI.getAncestorOfClass(JSpinner.class, jc);
								if (spinner != null)
									jc = spinner; // resolve parent
							
								if (jc.getBorder() == textBorder)
									jc.repaint();
							}
						}
					}
				};
				Toolkit.getDefaultToolkit().addAWTEventListener(metalAWTEventListener, AWTEvent.FOCUS_EVENT_MASK);
			}
			
			// init tool tip
			Border border;
			ColorUIResource bg;
			ColorUIResource fg;
			if (OS.isMac() || OS.isWindows()) {
				bg = new ColorUIResource(SystemColor.info);
				fg = new ColorUIResource(SystemColor.infoText);
				border = new BorderUIResource.LineBorderUIResource(fg, 1);
			}
			else {
				bg = new ColorUIResource(new Color(0x555753));
				fg = new ColorUIResource(Color.WHITE);
				border = new BorderUIResource.LineBorderUIResource(bg, 1);
			}
			defaults.put("ToolTip.background", bg);
			defaults.put("ToolTip.backgroundInactive", bg);
			defaults.put("ToolTip.foreground", fg);
			defaults.put("ToolTip.foregroundInactive", fg);
			defaults.put("ToolTip.border", border);
			defaults.put("ToolTip.borderInactive", border);
			
			// init tabs
			defaults.put("TabbedPane.contentBorderInsets", createInsets(1));
			
			// init tree
			defaults.put("Tree.leafIcon", null);
		}
		
		// Substance/Insubstantial specific
		
		else if (isSubstance()) {
			defaults.put("substancelaf.buttonnominsize", true); // more compatible
			defaults.put("Spinner.editorAlignment", LEADING); // stick to left alignment
		}
		
		// synth specific
		
		else if (isSynth()) {
			needScrollBarMiddleButtonFix = true;
		}
		
		// easy horizontal mouse navigation
		defaults.put("Menu.submenuPopupOffsetY", -5);

		if (needScrollBarMiddleButtonFix)
			defaults.put("ScrollBar.allowsAbsolutePositioning", true); // middle click scroll

		if (useCustomColor.get())
			initCustomColor(defaults);
	}
	
	// private
	
	private static Color oldControl;
	private static Color oldNimbusFocus;
	private static Color oldNimbusSelectionBackground;

	/**
	 * @since 3.8
	 */
	@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
	public static void initCustomColor(final UIDefaults defaults) {
		Color color = customColor.get();

		if (color == null)
			return;

		if (isNimbus()) {
			float[] nimbusHSB = MColor.toHSB(NIMBUS_BASE);
			float[] customHSB = MColor.toHSB(color);
			// normalize
			customHSB[1] = nimbusHSB[1];
			customHSB[2] = nimbusHSB[2];
			color = MColor.fromHSB(customHSB);
			
			if (oldControl == null)
				oldControl = defaults.getColor("control");
			if (oldNimbusFocus == null)
				oldNimbusFocus = defaults.getColor("nimbusFocus");
			if (oldNimbusSelectionBackground == null)
				oldNimbusSelectionBackground = defaults.getColor("nimbusSelectionBackground");

			// DOC: http://docs.oracle.com/javase/tutorial/uiswing/lookandfeel/color.html
			defaults.put("nimbusBase", color);
			
			customColor.setDefaultValue(NIMBUS_BASE);
			if (customColor.isDefaultValue()) {
				if (oldNimbusSelectionBackground != null)
					defaults.put("nimbusSelectionBackground", oldNimbusSelectionBackground);
				if (oldNimbusFocus != null)
					defaults.put("nimbusFocus", oldNimbusFocus);
				if (oldControl != null)
					defaults.put("control", oldControl);
			}
			else {
				defaults.put("nimbusSelectionBackground", color);
				defaults.put("nimbusFocus", MColor.getBrighter(color, 25));
				defaults.put("control", MColor.getBrighter(color, 90));
			}
		}
	}

	/**
	 * Returns @c true if @p image is @c null or empty (zero width or height).
	 *
	 * @since 1.2
	 */
	public static boolean isEmpty(final Image image) {
		return (image == null) || (image.getWidth(null) < 1) || (image.getHeight(null) < 1);
	}

	/**
	 * @since 2.0
	 */
	public static boolean isGTK() {
		return getLookAndFeelType() == LookAndFeelType.GTK;
	}

	/**
	 * Returns @c true if <i>Ocean Theme</i>
	 * is set as the current look and feel theme.
	 */
	public static boolean isMetal() {
		return getLookAndFeelType() == LookAndFeelType.METAL;
	}

	/**
	 * @since 4.2
	 */
	public static boolean isPgs() {
		return getLookAndFeelType() == LookAndFeelType.PGS;
	}

	public static boolean isPopupTrigger(final KeyEvent e) {
		if (TK.isKeyStroke(e, VK_CONTEXT_MENU) || TK.isKeyStroke(e, VK_F10, SHIFT_MASK)) {
			e.consume();

			return true;
		}

		return false;
	}

	/**
	 * @since 3.8.6
	 */
	public static boolean isRetro() {
		return getLookAndFeelType() == LookAndFeelType.RETRO;
	}

	/**
	 * @since 3.8.2
	 */
	public static boolean isSeaGlass() {
		return getLookAndFeelType() == LookAndFeelType.SEA_GLASS;
	}

	public static boolean isSubstance() {
		return getLookAndFeelType() == LookAndFeelType.SUBSTANCE;
	}
	
	/**
	 * @since 2.0
	 */
	public static boolean isWindows() {
		return (getLookAndFeelType() == LookAndFeelType.WINDOWS);
	}

	/**
	 * @since 5.2
	 */
	public static boolean isWindowsClassic() { return windowsClassic; }

	/**
	 * Returns {@link #HTML_BEGIN} + {@code code} + {@link #HTML_END}.
	 *
	 * @param code the HTML code
	 */
	public static String makeHTML(final String code) {
		return HTML_BEGIN + code + HTML_END;
	}

	/**
	 * @since 5.4
	 */
	public static void onButtonClicked(final Component c, final Consumer<MouseEvent> l) {
		c.addMouseListener(new MMouseAdapter() {
			@Override
			public void buttonClicked(final MouseEvent e) {
				if (MMouseAdapter.isLeft(e)) {
					l.accept(e);
					e.consume();
				}
			}
		} );
	}

	/**
	 * @since 5.2
	 */
	public static void onComponentResized(final Component c, final UI.ComponentResizedListener l) {
		c.addComponentListener(l);
	}

	/**
	 * @since 5.0
	 */
	public static void onKeyPressed(final Component c, final UI.KeyPressedListener l) {
		c.addKeyListener(l);
	}

	/**
	 * @since 5.6
	 */
	public static void onKeyReleased(final Component c, final UI.KeyReleasedListener l) {
		c.addKeyListener(l);
	}

	/**
	 * @since 2.0
	 */
	public static void paintText(
		final int flags,
		final Graphics2D g,
		final Rectangle r,
		final Color background,
		final Color foreground,
		final String... lines
	) {
		if (TK.isEmpty(lines))
			return;

		Flags f = Flags.valueOf(flags);
		FontMetrics metrics = g.getFontMetrics();
		int textHeight = metrics.getHeight();

		if (background != null) {
			g.setColor(background);
			int h = textHeight * lines.length;
			g.fillRect(r.x, r.y, r.width, h + metrics.getDescent());
		}
		
		Shape oldClip = g.getClip();
		int y = r.y;
		g.setClip(r);
		g.setColor(foreground);
		for (String i : lines) {
			y += textHeight;
			if (f.isSet(PAINT_TEXT_TRIM_LINES))
				g.drawString(i.trim(), r.x + 4, y);
			else
				g.drawString(i, r.x + 4, y);
			
			if (y > r.x + r.height)
				break; // for
		}
		g.setClip(oldClip);
	}

	/**
	 * @since 5.0
	 */
	public static BufferedImage readImage(final InputStream input) throws IOException {
		BufferedImage result = null;
		MemoryCacheImageInputStream imageInput = null;
		try {
			imageInput = new MemoryCacheImageInputStream(input);
			result = ImageIO.read(imageInput);
		}
		finally {
			// NOTE: as specified in JavaDoc
			if ((result == null) && (imageInput != null))
				FS.close(imageInput);
		}
		
		return result;
	}

	public static BufferedImage createCompatibleImage(final int w, final int h, final boolean alpha) {
		if (alpha)
			return getDefaultConfiguration().createCompatibleImage(w, h, Transparency.TRANSLUCENT);

		return getDefaultConfiguration().createCompatibleImage(w, h);
	}

	/**
	 * @since 3.0
	 */
	public static VolatileImage createCompatibleVolatileImage(final int w, final int h, final int transparency) {
		return getDefaultConfiguration().createCompatibleVolatileImage(w, h, transparency);
	}
	
	/**
	 * @since 4.6
	 */
	public static String[] getAllFontNames() {
		return GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
	}

	/**
	 * @since 4.0
	 */
	public static boolean needScrollPane(final JComponent component) {
		if (
			(component instanceof Scrollable) &&
			!(component instanceof JScrollPane) &&
			!(component instanceof JTextField) &&
			!(component instanceof JLayer<?>)
		)
			return true;

		if (component instanceof JLayer) {
			Component view = JLayer.class.cast(component).getView();

			return
				(view instanceof Scrollable) &&
				!(view instanceof JScrollPane) &&
				!(view instanceof JTextField) &&
				!(view instanceof JLayer<?>);
		}

		return false;
	}

	/**
	 * CREDITS: http://today.java.net/pub/a/today/2007/04/03/perils-of-image-getscaledinstance.html
	 *
	 * @since 2.0
	 */
	public static Image scaleImage(final Image image, int targetWidth, int targetHeight, final Quality quality) {
		if ((targetWidth < 0) && (targetHeight < 0))
			return image;

		int w = image.getWidth(null);
		int h = image.getHeight(null);

		if (targetWidth < 0) {
			float f = (float)targetHeight / (float)h;
			targetWidth = (int)((float)w * f);
		}
		if (targetHeight < 0) {
			float f = (float)targetWidth / (float)w;
			targetHeight = (int)((float)h * f);
		}

		if ((w == targetWidth) && (h == targetHeight))
			return image;

		switch (quality) {
			case LOW:
				return doScale(image, targetWidth, targetHeight, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR, true);
				
			case MEDIUM:
				return doScale(image, targetWidth, targetHeight, RenderingHints.VALUE_INTERPOLATION_BILINEAR, true);

			case HIGH:
				if ((targetWidth < w) || (targetHeight < h)) {
					boolean done = false;
					float fw = w;
					float fh = h;
					BufferedImage result = null;
					while (!done) {
						if (fw > targetWidth) {
							fw /= 2f;
							if (fw < targetWidth)
								fw = targetWidth;
						}
						else if (fw < targetWidth) {
							fw *= 1.5f;
							if (fw > targetWidth)
								fw = targetWidth;
						}

						if (fh > targetHeight) {
							fh /= 2f;
							if (fh < targetHeight)
								fh = targetHeight;
						}
						else if (fh < targetHeight) {
							fh *= 1.5f;
							if (fh > targetHeight)
								fh = targetHeight;
						}

						w = (int)fw;
						h = (int)fh;

						done = (w == targetWidth) && (h == targetHeight);

						result = doScale(
							(result != null) ? result : image,
							w,
							h,
							RenderingHints.VALUE_INTERPOLATION_BILINEAR,
							done
						);
					}
					
					return result;
				}
				else {
					return doScale(image, targetWidth, targetHeight, RenderingHints.VALUE_INTERPOLATION_BICUBIC, true);
				}
				
			default:
				throw new WTFError(quality);
		}
	}

	/**
	 * @since 2.0
	 */
	public static Object setAntialiasing(final Graphics2D g, final boolean value) {
		RenderingHints.Key key = RenderingHints.KEY_ANTIALIASING;
		Object oldRenderingHint = g.getRenderingHint(key);
		g.setRenderingHint(key, value ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
		
		return oldRenderingHint;
	}

	public static void setHTMLHelp(final JComponent component, final String text) {
		component.setToolTipText((text == null) ? null : makeHTML(text));
	}

	/**
	 * @since 5.4
	 */
	public static Font setLargerInputFont(final Component component, final boolean bold) {
		Font oldFont = getFont(component);

		int maxSize = 24;

		if (oldFont.getSize() >= maxSize)
			return oldFont;

		Font newFont;
		float newSize = (float)Math.min(maxSize, oldFont.getSize() + 4);
		if (bold)
			newFont = oldFont.deriveFont(Font.BOLD, newSize);
		else
			newFont = oldFont.deriveFont(newSize);
		component.setFont(newFont);

		return newFont;
	}

	/**
	 * @since 2.0
	 */
	public static void setLookAndFeel(final LookAndFeel laf) throws Exception {
		synchronized (UI.class) {
			lookAndFeelType = null;
		}
		MLogger.info("core", "Setting look and feel: %s", laf.getName());
		
		initCustomFont();
		UIManager.setLookAndFeel(laf);
		init();
	}

	/**
	 * @since 2.0
	 */
	public static void setLookAndFeel(final String className) throws Exception {
		synchronized (UI.class) {
			lookAndFeelType = null;
		}
		MLogger.info("core", "Setting look and feel by class name: %s", className);

		initCustomFont();
		UIManager.setLookAndFeel(className);
		init();
	}

	/**
	 * @since 3.8
	 */
	public static void setTextAntialiasing(final Graphics2D g, final RenderingHints savedHints) {
		if (savedHints != null) {
			savedHints.clear();
			for (RenderingHints.Entry<Object, Object> i : g.getRenderingHints().entrySet())
				savedHints.put(i.getKey(), i.getValue());
		}

		synchronized (UI.class) {
			if (!textAAInitialized) {
				textAAInitialized = true;
				Toolkit toolkit = Toolkit.getDefaultToolkit();
				updateTextAA(toolkit);

				toolkit.addPropertyChangeListener("awt.font.desktophints", e -> {
					MLogger.debug("ui", "Text Antialiasing: Settings changed");
					synchronized (UI.class) {
						UI.updateTextAA(toolkit);
					}
				} );
			}
		}
		if (textAA == null) {
			setBasicTextAntialiasing(g, true);
		}
		else {
			g.addRenderingHints(textAA);
		}
	}

	/**
	 * @since 4.0
	 *
	 * @see #setTextAntialiasing(Graphics2D, RenderingHints)
	 */
	public static Object setBasicTextAntialiasing(final Graphics2D g, final boolean on) {
		RenderingHints.Key key = RenderingHints.KEY_TEXT_ANTIALIASING;
		Object oldRenderingHint = g.getRenderingHint(key);
		g.setRenderingHint(key, on ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		
		return oldRenderingHint;
	}

	/**
	 * @since 4.2
	 */
	public static void setHandCursor(final Component component, final boolean yes) {
		if (component != null)
			component.setCursor(Cursor.getPredefinedCursor(yes ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
	}

	public static void setWaitCursor(final Component component, final boolean wait) {
		if (component == null)
			return;

		if (!wait && (component instanceof JTextComponent)) {
			boolean editable = JTextComponent.class.cast(component).isEditable();
			component.setCursor(Cursor.getPredefinedCursor(editable ? Cursor.TEXT_CURSOR : Cursor.DEFAULT_CURSOR));
		
			return;
		}
		
		component.setCursor(Cursor.getPredefinedCursor(wait ? Cursor.WAIT_CURSOR : Cursor.DEFAULT_CURSOR));
	}

	public static void setWaitCursor(final boolean yes) {
		setWaitCursor(MainView.getWindow(), yes);
	}

	/**
	 * @since 2.0
	 */
	public static BufferedImage toBufferedImage(final Icon source) {
		BufferedImage result = createCompatibleImage(source.getIconWidth(), source.getIconHeight(), true);
		Graphics2D g = result.createGraphics();
		source.paintIcon(null, g, 0, 0);
		g.dispose();
		
		return result;
	}

	/**
	 * @since 2.0
	 */
	public static BufferedImage toBufferedImage(final Image source, final boolean useSource) {
		if (useSource && (source instanceof BufferedImage))
			return (BufferedImage)source;
		
		// NOTE: do not return original "source"
		BufferedImage result = createCompatibleImage(source.getWidth(null), source.getHeight(null), true);
		Graphics2D g = result.createGraphics();
		g.drawImage(source, 0, 0, null, null);
		g.dispose();
		
		return result;
	}

	/**
	 * Converts key code and modifiers to @c String.
	 *
	 * @param aKeyCode the key code
	 * @param aModifiers the modifiers
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * assert UI.toString(KeyEvent.VK_F1, KeyEvent.CTRL_MASK).equals("Ctrl+F1");
	 * assert UI.toString(KeyEvent.VK_F2, 0).equals("F2");
	 * </pre>
	 *
	 * @mg.note
	 * The returned String names are localized.
	 *
	 * @see #toString(KeyStroke)
	 *
	 * @since 5.6
	 */
	public static String toString(final int aKeyCode, final int aModifiers) {
		String keyCode = KeyEvent.getKeyText(aKeyCode);
		String modifiers = KeyEvent.getKeyModifiersText(aModifiers);

		if (TK.isEmpty(modifiers))
			return keyCode;

		if (TK.isEmpty(keyCode))
			return modifiers;

		return modifiers + '+' + keyCode;
	}

	/**
	 * Converts @p keyStroke to @c String.
	 *
	 * @throws NullPointerException If @p keyStroke is @c null
	 *
	 * @see #toString(int, int)
	 *
	 * @since 5.6
	 */
	public static String toString(final KeyStroke keyStroke) {
		return toString(keyStroke.getKeyCode(), keyStroke.getModifiers());
	}

	/**
	 * Update component tree UI for all windows and frames.
	 * 
	 * @since 3.8.2
	 */
	public static void update() {
		lengthyOperation(() -> {
			for (Window i : Window.getWindows())
				SwingUtilities.updateComponentTreeUI(i);
			
			return null;
		} );
	}
	
	/**
	 * Returns a window ancestor of {@code c} (may be {@code null}).
	 *
	 * @return the active and visible window if {@code c} is {@code null}
	 *
	 * @since 3.0
	 */
	public static Window windowFor(final Component c) {
		if (c == null) {
			Window w = FocusManager.getCurrentManager().getActiveWindow();
			// HACK: use "parent" window if active window is invisible
			if ((w != null) && !w.isVisible())
				w = w.getOwner();
			
			return w;
		}
	
		return SwingUtilities.getWindowAncestor(c);
	}

	// private

	@Uninstantiable
	private UI() {
		TK.uninstantiable();
	}
	
	private static BufferedImage doScale(final Image image, final int w, final int h, final Object hint, final boolean compatible) {
		BufferedImage result =
			compatible
			? createCompatibleImage(w, h, true)
			: new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = result.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
		g.drawImage(image, 0, 0, w, h, null);
		g.dispose();
		
		return result;
	}

	private static void fixGTKThickness(final SynthStyle style, final String fieldName) throws ReflectiveOperationException {
		Field field = style.getClass().getDeclaredField(fieldName);
		boolean oldAccessible = field.isAccessible();
		field.setAccessible(true);
		try {
			field.setInt(style, Math.max(1, field.getInt(style)));
		}
		finally {
			field.setAccessible(oldAccessible);
		}
	}

	private static GraphicsConfiguration getDefaultConfiguration() {
		return GraphicsEnvironment
			.getLocalGraphicsEnvironment()
			.getDefaultScreenDevice()
			.getDefaultConfiguration();
	}

	private static void initCustomFont() {
		if (useCustomFont.get()) {
			customFontValue = customFont.get();
			
			// limit font size
			int size = TK.limit(customFontValue.getSize(), getMinimumFontSize(), 64);
			customFontValue = deriveFontSize(customFontValue, size);

			// put before LAF initialization
			UIDefaults defaults = UIManager.getDefaults();
			defaults.put("defaultFont", customFontValue);
		
			for (Map.Entry<Object, Object> i : defaults.entrySet()) {
				String name = i.getKey().toString();
				putFont(defaults, name, ".font", customFontValue);
				putFont(defaults, name, ".acceleratorFont", customFontValue);
				putFont(defaults, name, "InternalFrame.titleFont", customFontValue);
			}
		}
		else {
			customFontValue = null;
		}
	}
	
	private static void putFont(final UIDefaults defaults, final String name, final String suffix, final Font font) {
		int i = name.lastIndexOf(suffix);
		if (i != -1) {
			defaults.put(name, font);
			String baseName = name.substring(0, i);
			defaults.put(baseName + "[Enabled]" + suffix, font);
			defaults.put(baseName + "[Disabled]" + suffix, font);
		}
	}

	@SuppressWarnings("unchecked")
	private static void updateTextAA(final Toolkit toolkit) {
		textAA = (Map<Object, Object>)toolkit.getDesktopProperty("awt.font.desktophints");
		if (textAA != null) {
			for (Map.Entry<Object, Object> i : textAA.entrySet()) {
				MLogger.debug("ui", "Text Antialiasing: %s = %s", i.getKey(), i.getValue());
			}
		}
	}
	
	// public classes

	/**
	 * @since 5.2
	 */
	@FunctionalInterface
	public static interface ComponentResizedListener extends ComponentListener {
	
		// public

		@Override
		public default void componentHidden(final ComponentEvent e) { }

		@Override
		public default void componentMoved(final ComponentEvent e) { }

		@Override
		public default void componentShown(final ComponentEvent e) { }

	}

	/**
	 * @since 5.2
	 */
	@FunctionalInterface
	public static interface ComponentShownListener extends ComponentListener {
	
		// public

		@Override
		public default void componentHidden(final ComponentEvent e) { }

		@Override
		public default void componentMoved(final ComponentEvent e) { }

		@Override
		public default void componentResized(final ComponentEvent e) { }

	}

	public static interface EventsControl {
		
		// public
		
		/**
		 * @since 2.0
		 */
		public boolean getEventsEnabled();
		
		public void setEventsEnabled(final boolean value);
		
	}

	/**
	 * @since 5.0
	 */
	@FunctionalInterface
	public static interface KeyPressedListener extends KeyListener {
	
		// public
		
		@Override
		public default void keyPressed(final KeyEvent e) {
			onKeyPressed(e);
		}

		@Override
		public default void keyReleased(final KeyEvent e) { }

		@Override
		public default void keyTyped(final KeyEvent e) { }
		
		public void onKeyPressed(final KeyEvent e);

	}

	/**
	 * @since 5.6
	 */
	@FunctionalInterface
	public static interface KeyReleasedListener extends KeyListener {
	
		// public

		@Override
		public default void keyPressed(final KeyEvent e) { }

		@Override
		public default void keyReleased(final KeyEvent e) {
			onKeyReleased(e);
		}

		@Override
		public default void keyTyped(final KeyEvent e) { }
		
		public void onKeyReleased(final KeyEvent e);

	}

	/**
	 * @since 2.0
	 */
	public static interface MouseWheelEventsControl {
		
		// public
		
		public boolean getMouseWheelEventsEnabled();
		
		public void setMouseWheelEventsEnabled(final boolean value);
		
	}

	/**
	 * @since 3.8.12
	 */
	public static class NimbusOverrides extends UIDefaults {

		// public

		public NimbusOverrides() { }

		public void install(final JComponent c, final boolean inheritDefaults) {
			c.putClientProperty("Nimbus.Overrides.InheritDefaults", inheritDefaults);
			c.putClientProperty("Nimbus.Overrides", this);
		}

	}

	// private classes
	
	private static final class LookAndFeelListener implements PropertyChangeListener {
	
		// private
		
		private final WeakReference<Component> componentRef;
	
		// public
		
		public LookAndFeelListener(final Component c) {
			componentRef = new WeakReference<>(c);
		}
		
		@Override
		public void propertyChange(final PropertyChangeEvent e) {
			switch (e.getPropertyName()) {
				case "lookAndFeel":
					TK.getRef(componentRef)
						.filter(c -> UI.windowFor(c) == null)
						.ifPresent(SwingUtilities::updateComponentTreeUI);
					break;
			}
		}
	
	}

}
