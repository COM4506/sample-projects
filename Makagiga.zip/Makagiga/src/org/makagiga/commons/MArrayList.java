// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.NoSuchElementException;

import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;

/**
 * An improved @c java.util.ArrayList.
 * 
 * @mg.example
 * <pre class="brush: java">
 * MArrayList&lt;String&gt; list = new MArrayList&lt;&gt;("foo", "bar");
 * list.sort();
 * assert list.getLast().equals("foo");
 * </pre>
 *
 * @mg.warning This class is <b>not</b> thread-safe.
 * 
 * @see StringList
 * 
 * @since 2.2
 */
public class MArrayList<E> extends ArrayList<E> implements Sortable<E> {
	
	// public
	
	/**
	 * Constructs an empty list with a default initial capacity.
	 */
	public MArrayList() { }

	/**
	 * Constructs a list with @p values.
	 * 
	 * @throws NullPointerException If @p values is @c null
	 * 
	 * @since 2.4
	 */
	public MArrayList(final Collection<? extends E> values) {
		super(values);
	}
	
	/**
	 * Constructs an empty list.
	 * 
	 * @param initialCapacity The initial capacity
	 * 
	 * @throws IllegalArgumentException If the @p initialCapacity is less than zero
	 */
	public MArrayList(final int initialCapacity) {
		super(initialCapacity);
	}
	
	/**
	 * Constructs a list with @p values.
	 * The array elements can be @c null.
	 * 
	 * @param values The array of values
	 * 
	 * @throws NullPointerException If @p values is @c null
	 */
	@SafeVarargs
	@SuppressWarnings("varargs")
	public MArrayList(final E... values) {
		super(values.length);
		addAll(values);
	}

	/**
	 * Adds all @p values to the list.
	 * The array elements can be @c null.
	 * 
	 * @throws NullPointerException If @p values is @c null
	 */
	@InvokedFromConstructor
	@SafeVarargs
	@SuppressWarnings("varargs")
	public final void addAll(final E... values) {
		Collections.addAll(this, values);
	}

	/**
	 * Returns the first list element (<code>get(0)</code>).
	 * 
	 * @throws NoSuchElementException If list is empty
	 */
	public E getFirst() {
		if (isEmpty())
			throw new NoSuchElementException();
		
		return get(0);
	}

	/**
	 * Returns the last list element (<code>get(size() - 1)</code>).
	 * 
	 * @throws NoSuchElementException If list is empty
	 */
	public E getLast() {
		if (isEmpty())
			throw new NoSuchElementException();
		
		return get(size() - 1);
	}

	/**
	 * @since 3.8
	 */
	public E[] toArray(final Class<E> type) {
		return TK.newArray(type, toArray());
	}

	/**
	 * Joins this list into one string.
	 * The values are separated using {@code delimeter}.
	 *
	 * @param delimeter the separator
	 *
	 * @return An empty {@code String} If {@code values} is {@code null} or empty
	 *
	 * @since 3.8
	 */
	@SuppressWarnings("deprecation")
	public String toString(final String delimeter) {
		return TK.toString(this, delimeter);
	}
	
	// Sortable

	/**
	 * @throws ClassCastException If the list contains elements that are not mutually comparable (for example, strings and integers)
	 * @throws NullPointerException If list contains both @c null and @c non-null elements
	 */
	@Obsolete // remove sort methods
	@Override
	public void sort() {
		super.sort(null);
	}

	/**
	 * @throws ClassCastException If the list contains elements that are not mutually comparable using the specified comparator (for example, strings and integers)
	 * @throws NullPointerException If list contains both @c null and @c non-null elements
	 */
	@Override
	public void sort(final Comparator<? super E> comparator) {
		super.sort(comparator);
	}

}
