// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mv;

import static org.makagiga.commons.UI.i18n;

import java.awt.Font;
import java.util.HashMap;
import javax.swing.Icon;
import javax.swing.JComponent;

import org.makagiga.commons.Attributes;
import org.makagiga.commons.UI;
import org.makagiga.commons.request.AbstractRequestManager;
import org.makagiga.commons.request.RequestInfo;
import org.makagiga.commons.request.RequestSource;
import org.makagiga.commons.swing.MLabel;

/**
 * @since 3.0
 */
public class FontRenderer extends MRenderer<String> {

	// private

	private boolean previewEnabled = true;
	private FontRequestManager frm;
	private MLabel normal;
	private MLabel preview;
	private RequestSource<Font> requestSource;

	// public

	public FontRenderer() {
		this(null);
	}

	public FontRenderer(final RequestSource<Font> requestSource) {
		this.requestSource = requestSource;
	}

	@Override
	public MLabel getLabel() { return normal; }

	public boolean isPreviewEnabled() { return previewEnabled; }

	public void setPreviewEnabled(final boolean value) { previewEnabled = value; }

	@Override
	public void setIcon(final Icon icon) {
		getLabel().setIcon(icon);
	}

	@Override
	public void setText(final String text) {
		getLabel().setText(text);
	}

	// protected

	@Override
	protected JComponent createView() {
		normal = new OptimizedLabel();
		preview = new OptimizedLabel();
		preview.setText(i18n("Preview"));
		preview.setTextAntialiasing(true);

		OptimizedPanel p = new OptimizedPanel(false);
		p.getGroupLayout()
			.addComponent(normal)
			.addContentGap()
			.addComponent(preview);

		return p;
	}

	@Override
	protected void onRender(final String value) {
		// use list's colors
		normal.setForeground(null);
		preview.setForeground(null);

		normal.setText(value);

		if (isPreviewEnabled()) {
			if (requestSource == null) {
				preview.setFont(createFont(value));
				preview.setVisible(true);
			}
			else {
				if (frm == null)
					frm = new FontRequestManager();
				Font font = frm.requestFont(requestSource, value);
				preview.setFont(font);
				preview.setVisible(font != null);
			}
		}
		else {
			preview.setFont(null);
			preview.setVisible(false);
		}
	}
	
	// private

	private static Font createFont(final String name) {
		Font font = new Font(name, Font.PLAIN, UI.getDefaultFontSize() + 2);

		return font.canDisplay('X') ? font : null;
	}

	// private classes
	
	private static final class FontRequestManager extends AbstractRequestManager<Font> {
		
		// private
		
		private final HashMap<String, Font> cache = new HashMap<>(50);
		
		// protected
		
		@Override
		protected Font getResult(final RequestInfo<Font> info) throws Exception {
			String name = info.getProperty("name", null);
			Font font = FontRenderer.createFont(name);
			synchronized (cache) {
				cache.put(name, font);
			}
			
			return font;
		}
		
		// private

		private FontRequestManager() {
			super(1);
			setThreadPriority(Thread.MIN_PRIORITY);
		}

		private Font requestFont(final RequestSource<Font> requestSource, final String name) {
			Font font;
			synchronized (cache) {
				font = cache.get(name);
			}
			
			if (font != null)
				return font;
			
			Attributes<String, String> attributes = new Attributes<>();
			attributes.set("name", name);
			startRequest(requestSource, attributes);
			
			return null; // requestSource will get the result later
		}
		
	}

}
