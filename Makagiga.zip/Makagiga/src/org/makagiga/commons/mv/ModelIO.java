// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mv;

import java.awt.Image;
import java.awt.image.RenderedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;
import javax.imageio.ImageIO;

import org.makagiga.commons.FS;

/**
 * @since 4.0
 *
 * @deprecated Since 5.4
 */
@Deprecated
public abstract class ModelIO<M>
implements
	Closeable,
	Serializable
{

	// private
	
	private Object source;
	private final String description;
	
	// public
	
	public String getDescription() { return description; }
	
	public Object getSource() { return source; }

	public boolean isReadOnly() {
		Path path = toPathSource();

		if (path != null)
			return !Files.isWritable(path);
		
		return true;
	}
	
	public InputStream newBufferedInputStream() throws IOException {
		Path path = toPathSource();
		
		if (path != null)
			return new BufferedInputStream(Files.newInputStream(path));
		
		Object s = getSource();
		
		if (s instanceof URI) {
			URI uri = (URI)s;

			return new BufferedInputStream(uri.toURL().openStream());
		}
		
		throw new IOException("Cannot create input stream for " + this + " (" + getClass().getName() + ")");
	}
	
	public OutputStream newBufferedOutputStream() throws IOException {
		Path path = toPathSource();
		
		if (path != null)
			return new BufferedOutputStream(Files.newOutputStream(path));

		throw new IOException("Cannot create output stream for " + this + " (" + getClass().getName() + ")");
	}

	public M read() throws IOException {
		try (InputStream input = newBufferedInputStream()) {
			return read(input);
		}
	}

	public abstract M read(final InputStream input) throws IOException;
	
	public void write(final M model) throws IOException {
		try (OutputStream output = newBufferedOutputStream()) {
			write(output, model);
		}
	}
	
	public abstract void write(final OutputStream output, final M model) throws IOException;

	public Path toPathSource() {
		Object s = getSource();
		
		if (s instanceof Path)
			return (Path)s;
		
		if (s instanceof File)
			return File.class.cast(s).toPath();

		if (s instanceof URI) {
			try {
				return Paths.get((URI)s);
			}
			catch (FileSystemNotFoundException exception) { } // quiet
		}

		return null;
	}

	@Override
	public String toString() {
		return getDescription() + " - " + getSource();
	}

	public URI toURISource() {
		Object s = getSource();

		if (s instanceof URI)
			return (URI)s;

		if (s instanceof File)
			return File.class.cast(s).toPath().toUri();

		if (s instanceof Path)
			return Path.class.cast(s).toUri();

		return null;
	}

	// Closeable
	
	@Override
	public void close() {
		source = null;
	}

	// protected
	
	protected ModelIO(final Object source, final String description) {
		this.source = Objects.requireNonNull(source);
		this.description = Objects.requireNonNull(description);
	}
	
	// public classes

	public static class ImageModelIO extends ModelIO<Image> {
	
		// private
		
		private final String format;

		// public

		public ImageModelIO(final Object source, final String format) {
			super(source, "Image");
			this.format = format;
		}

		@Override
		public Image read(final InputStream input) throws IOException {
			return ImageIO.read(input);
		}

		@Override
		public void write(final OutputStream output, final Image image) throws IOException {
			ImageIO.write((RenderedImage)image, format, output);
		}

	}

	public static class TextModelIO extends ModelIO<CharSequence> {
	
		// private
		
		private Charset charset;

		// public
		
		public TextModelIO(final Object source) {
			this(source, StandardCharsets.UTF_8);
		}

		public TextModelIO(final Object source, final Charset charset) {
			super(source, "Plain Text");
			this.charset = Objects.requireNonNull(charset);
		}

		@Override
		public CharSequence read(final InputStream input) throws IOException {
			return FS.read(input, charset.name());
		}

		@Override
		public void write(final OutputStream output, final CharSequence cs) throws IOException {
			FS.write(output, charset.name());
		}

	}

}
