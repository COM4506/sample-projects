// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mv;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;

import org.makagiga.commons.MColor;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.painters.AbstractPainter;
import org.makagiga.commons.painters.GradientPainter;
import org.makagiga.commons.painters.RoundedBackgroundPainter;
import org.makagiga.commons.swing.MLabel;

/**
 * The @c Color renderer.
 *
 * @since 2.0
 */
public class ColorRenderer<T> extends MRenderer<T> {

	// private
	
	private boolean flat;
	private Color color;
	private final GradientPainter gradientPainter;
	private final RoundedBackgroundPainter roundedBackgroundPainter;
	
	// public

	/**
	 * Constructs a color renderer.
	 */
	public ColorRenderer() {
		gradientPainter = new GradientPainter();
		roundedBackgroundPainter = new RoundedBackgroundPainter(null, 9, UI.createInsets(2));
	}
	
	public Color getColor() { return color; }
	
	public void setColor(final Color value) { color = value; }
	
	/**
	 * @since 3.0
	 */
	public boolean isFlat() { return flat; }

	/**
	 * @since 3.0
	 */
	public void setFlat(final boolean value) { flat = value; }

	// protected
	
	@Override
	protected JComponent createView() {
		OptimizedLabel l = new OptimizedLabel() {
			@Override
			protected void paintComponent(final Graphics g) {
				if (UI.isRetro()) {
					g.setColor((color == null) ? UI.getBackground(this) : color);
					g.fillRect(0, 0, getWidth(), getHeight());
					super.paintComponent(g); // paint text

					return;
				}

// TODO: rewrite
				if (!UI.isA03() && !UI.isSeaGlass()/* && !UI.isSubstance()*/) {
					g.setColor(getBackground());
					g.fillRect(0, 0, getWidth(), getHeight());
				}
				if (color != null) {
					AbstractPainter p =
						(flat || isPaintingForPrint() || ColorRenderer.this.isSelected())
						? roundedBackgroundPainter
						: gradientPainter;
					p.setPrimaryColor(color);
					p.paint(this, (Graphics2D)g);
				}
				super.paintComponent(g);
			}
		};
		l.setHorizontalAlignment(UI.CENTER);
		
		return l;
	}

	@Override
	protected void onRender(final T value) {
		MLabel label = getLabel();

		Color bg;
		if (color == null)
			bg = UI.getBackground(label); // use label.getBackground() for better look in dark color themes
		else
			bg = color;

		Color fg;
		// HACK: nicer colors
		if ((color == null) && isSelected() && (UI.isGTK() || UI.isWindows()) && (getTable() != null)) {
			bg = TK.get(getTable().getSelectionBackground(), Color.WHITE);
			label.setBackground(bg);

			fg = TK.get(getTable().getSelectionForeground(), Color.BLACK);
		}
		else {
			fg = MColor.getContrastBW(bg);
		}

		label.setForeground(fg);
		label.setOpaque(false);
	}

}
