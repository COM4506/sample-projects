// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mv;

import java.awt.Color;
import java.awt.Component;
import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;

import org.makagiga.commons.color.MColorButton;

/**
 * @since 2.0
 */
public class ColorEditor extends AbstractCellEditor implements TableCellEditor {
	
	// private
	
	private Color defaultValue;
	private Object value;
	
	// public
	
	public ColorEditor() { }

	@Override
	public Object getCellEditorValue() { return value; }

	/**
	 * Returns the default color or @c null.
	 *
	 * @since 4.0
	 */
	public Color getDefaultValue() { return defaultValue; }

	/**
	 * Sets the default color to @p value (can be @c null).
	 *
	 * @since 4.0
	 */
	public void setDefaultValue(final Color value) { defaultValue = value; }

	@Override
	public Component getTableCellEditorComponent(final JTable table, final Object value, final boolean isSelected, final int row, final int column) {
		this.value = value;
		
		MColorButton editorComponent = new MColorButton();
		editorComponent.setValue((Color)value);
		editorComponent.setDefaultValue(defaultValue);
		editorComponent.addValueListener(e -> {
			this.value = e.getNewValue();
			stopCellEditing();
		} );
		
		return editorComponent;
	}

}
