// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mv;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.beans.PropertyVetoException;
import java.io.Serializable;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListCellRenderer;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicHTML;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;

import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.style.StyleSupport;
import org.makagiga.commons.swing.MHighlighter;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MList;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MTable;
import org.makagiga.commons.swing.MTree;
import org.makagiga.commons.swing.MTreeItem;

/**
 * @since 3.0, 4.0 (org.makagiga.commons.mv package)
 *
 * @param <T> the type of the rendered value
 */
public class MRenderer<T>
implements
	ListCellRenderer<T>,
	Serializable,
	StyleSupport,
	TableCellRenderer,
	TreeCellRenderer
{
	private static final long serialVersionUID = 6853203006996886863L;
	
	// private

	private final BiConsumer<MRenderer<T>, T> renderHandler;
	private boolean cellTip;
	transient private boolean expanded;
	transient private boolean _focused;
	private boolean htmlEnabled = true;
	transient private boolean leaf;
	transient private boolean _selected;
	private boolean useAlternateRowColor = true;
	private static final Border EMPTY_BORDER = BorderFactory.createEmptyBorder(1, 1, 1, 1);
	private Border _paddingBorder;
	private static DefaultListCellRenderer defaultRenderer;
	transient private int column;
	private int padding = -1;
	transient private int row;
	private JComponent view;
	transient private JList<? extends T> list;
	transient private JTable table;
	transient private JTree tree;
	private static MRenderer<?> _instance;
	transient private Object mouseHoverPathComponent;
	private static String highlightBackground;
	transient private TreePath mouseHover;
	
	// public

	public MRenderer() {
		this.renderHandler = null;
		initView();
	}

	/**
	 * @since 5.0
	 */
	public MRenderer(final BiConsumer<MRenderer<T>, T> renderHandler) {
		this.renderHandler = renderHandler;
		initView();
	}

	public MRenderer(final int padding) {
		this.padding = padding;
		this.renderHandler = null;
		initView();
	}

	/**
	 * @since 5.0
	 */
	public MRenderer(final int padding, final BiConsumer<MRenderer<T>, T> renderHandler) {
		this.padding = padding;
		this.renderHandler = renderHandler;
		initView();
	}

	public MRenderer(final int padding, final JComponent view) {
		this.padding = padding;
		this.view = view;
		this.renderHandler = null;
	}

	public MRenderer(final JComponent view) {
		this.view = view;
		this.renderHandler = null;
	}
	
	/**
	 * @since 4.0
	 */
	public int getColumn() { return column; }

	public Font getFont() {
		if (view != null)
			return view.getFont();
		
		throw new UnsupportedOperationException();
	}

	public void setFont(final Font font) {
		if (view != null)
			view.setFont(font);
		else
			throw new UnsupportedOperationException();
	}
	
	/**
	 * @since 4.0
	 */
	public int getIndex() { return row; }

	public MLabel getLabel() {
		return (MLabel)view;
	}

	/**
	 * @since 4.0
	 */
	public JList<? extends T> getList() { return list; }

	/**
	 * @since 4.0
	 */
	public int getModelRow() {
		return table.convertRowIndexToModel(row);
	}

	/**
	 * @since 4.0
	 */
	public int getRow() { return row; }

	/**
	 * Returns a color for the specified {@code row}.
	 *
	 * @return a color for the specified {@code row}.
	 * 
	 * @param row the row index
	 * @param baseColor the base color for the returned value
	 */
	public static Color getRowColor(final int row, final Color baseColor) {
		if ((row % 2) != 0)
			return UI.getDarker(baseColor, Color.WHITE);
		
		return baseColor;
	}

	/**
	 * @since 5.2
	 */
	public int getSelectionCount() {
		if (list != null)
			return list.isSelectionEmpty() ? 0 : list.getSelectedIndices().length;

		if (table != null)
			return table.getSelectionModel().isSelectionEmpty() ? 0 : table.getSelectedRowCount();

		if (tree != null)
			return tree.isSelectionEmpty() ? 0 : tree.getSelectionCount();

		return 0;
	}

	@Obsolete
	@SuppressWarnings("unchecked")
	public synchronized static <T> MRenderer<T> getSharedInstance() {
		if (_instance == null) {
			_instance = new MRenderer<T>() {
				private Icon folderIcon = MIcon.small("ui/folder");
				private Icon leafIcon = MIcon.small("ui/file");
				@Override
				protected void onRender(final T value) {
					MLabel label = this.getLabel();
					// remembered from DefaultListCellRenderer ;)
					if (value instanceof Icon) {
						label.setIcon((Icon)value);
						label.setText("");
					}
					else {
						if (getTree() != null)
							label.setIcon(isLeaf() ? leafIcon : folderIcon);
						else
							label.setIcon(null);
						label.setText(Objects.toString(value, ""));
					}
				}
			};
			UI.installLookAndFeelListener(_instance.getView());
		}
		
		return (MRenderer<T>)_instance;
	}

	/**
	 * @since 4.0
	 */
	public JTable getTable() { return table; }

	/**
	 * @since 3.4
	 */
	public String getToolTipText() {
		if (view != null)
			return view.getToolTipText();

		throw new UnsupportedOperationException();
	}

	public void setToolTipText(final String text) {
		if (view != null)
			view.setToolTipText(text);
		else
			throw new UnsupportedOperationException();
	}

	/**
	 * @since 4.0
	 */
	public JTree getTree() { return tree; }

	/**
	 * @since 3.8.3
	 */
	public boolean getUseAlternateRowColor() { return useAlternateRowColor; }

	/**
	 * @since 3.8.3
	 */
	public void setUseAlternateRowColor(final boolean value) { useAlternateRowColor = value; }

	public JComponent getView() { return view; }

	/**
	 * @since 4.12
	 */
	public boolean isCellTip() { return cellTip; }

	/**
	 * @since 4.12
	 */
	public void setCellTip(final boolean value) { cellTip = value; }

	/**
	 * @since 4.4
	 */
	public boolean isPaintingForPrint() {
		if (list != null)
			return list.isPaintingForPrint();

		if (table != null)
			return table.isPaintingForPrint();

		if (tree != null)
			return tree.isPaintingForPrint();

		return false;
	}

	public void setIcon(final Icon icon) {
		if (view instanceof JLabel)
			JLabel.class.cast(view).setIcon(icon);
		else
			throw new UnsupportedOperationException();
	}

	/**
	 * @since 4.0
	 */
	public boolean isExpanded() { return expanded; }
	
	/**
	 * @since 4.0
	 */
	public boolean isFocused() { return _focused; }

	/**
	 * @since 3.4
	 */
	public boolean isHTMLEnabled() { return htmlEnabled; }

	/**
	 * @since 3.4
	 */
	public void setHTMLEnabled(final boolean value) {
		htmlEnabled = value;
		if (view != null)
			UI.setHTMLEnabled(view, value);
	}

	/**
	 * @since 4.0
	 */
	public boolean isLeaf() { return leaf; }

	/**
	 * @since 4.0
	 */
	public boolean isSelected() { return _selected; }

	public void setMouseHover(final MTree<?, ?> tree, final TreePath value) {
		Object newPathComponent = (value == null) ? null : value.getLastPathComponent();
		if (!Objects.equals(newPathComponent, mouseHoverPathComponent)) {
			mouseHoverPathComponent = newPathComponent;
			
			// repaint old item
			if (mouseHover != null)
				tree.repaint(mouseHover);
			
			mouseHover = value;
			
			// repaint new item
			if (mouseHover != null)
				tree.repaint(mouseHover);
		}
	}

	/**
	 * @since 4.10
	 */
	public static <T> MRenderer<T> newPlainTextInstance() {
		MRenderer<T> result = new MRenderer<>((renderer, value) -> {
			renderer.setText(Objects.toString(value, ""));
		} );
		result.setHTMLEnabled(false);
		
		return result;
	}

	public void setText(String text) {
		if (view instanceof JLabel) {
			JLabel l = (JLabel)view;

			Pattern highlightedText = null;
			if (
				(
					(getList() instanceof MList<?>) ||
					(getTable() instanceof MTable<?>)
				) &&
				!TK.isEmpty(text)
			) {
				if (getList() instanceof MList<?>)
					highlightedText = MList.class.cast(getList()).getHighlightedText();
				else if (getTable() instanceof MTable<?>)
					highlightedText = MTable.class.cast(getTable()).getHighlightedText();

				boolean htmlText = false;
				if (highlightedText != null) {
					Matcher matcher = highlightedText.matcher(text);
					if (highlightBackground == null)
						highlightBackground = ColorProperty.toString(MHighlighter.SEARCH_COLOR);

					if (matcher.find()) {
						htmlText = true;

						// HACK: a way to escape HTML chars w/o breaking syntax after replaceAll
						String spanStart = Character.toString((char)1);
						String spanEnd = Character.toString((char)2);

						text = matcher.replaceAll(spanStart + "$0" + spanEnd);

						StringBuilder buf = new StringBuilder(text.length() * 2);
						TK.escapeXML(buf, text);
						TK.fastReplace(buf, spanStart, "<span style=\"background-color: " + highlightBackground + "; color: black\">");
						TK.fastReplace(buf, spanEnd, "</span>");
						text = UI.makeHTML("<span style=\"white-space: nowrap\">" + buf + "</span>");
					}
				}
				UI.setHTMLEnabled(l, htmlText | htmlEnabled);
			}

			l.setText(text);
		}
		else
			throw new UnsupportedOperationException();
	}

	public static void setupTable(
		final JTable table,
		final JComponent view,
		final boolean selected,
		final boolean focused,
		final int row,
		final int column
	) {
		if (selected) {
			Color background = table.getSelectionBackground();
			Color foreground = table.getSelectionForeground();

			view.setBackground(background);

			if (view instanceof JLabel)
				view.setForeground(foreground);
		}
		else {
			boolean print = table.isPaintingForPrint();
			Color bg;
			if (print) {
				bg = Color.WHITE;
			}
			else {
				if (UI.getLookAndFeelType().hasAlternateTableRowColor()) {
					bg = table.getBackground();
					view.setOpaque(false);
				}
				else {
					bg = getRowColor(row, table.getBackground());
					if (UI.isNimbus())
						bg = UI.getColor(bg, 0.98f, MColor.WHITE);
				}
			}
			if (!print && MTable.isSortByColumn(table, column))
				bg = UI.getColor(bg, 0.96f, MColor.WHITE);
			view.setBackground(bg);

			if (view instanceof JLabel)
				view.setForeground(table.getForeground());
		}

		if (focused)
			view.setBorder(UIManager.getBorder("Table.focusCellHighlightBorder"));
		else
			view.setBorder(EMPTY_BORDER);
	}
	
	// ListCellRenderer
	
	@Override
	public final Component getListCellRendererComponent(
		final JList<? extends T> list,
		final T value,
		final int index,
		final boolean isSelected,
		final boolean cellHasFocus
	) {
		try {
			this.list = list;
			this.row = index;
			this._selected = isSelected;
			this._focused = cellHasFocus;

			setup(list, value);

			
			if (
				UI.isGTK() && (view instanceof JLabel) &&
				(list != null) && "ComboBox.list".equals(list.getName())
			) {
				// HACK: fix JComboBox border
				// exclude JComboBox used as JTable editor
				JPopupMenu popup = UI.getAncestorOfClass(JPopupMenu.class, list);
				if (
					(popup != null) &&
					(popup.getInvoker() instanceof JComboBox) &&
					(UI.getAncestorOfClass(JTable.class, popup.getInvoker()) != null)
				)
					return view;

				JLabel l = (JLabel)view;
				if (defaultRenderer == null)
					defaultRenderer = new DefaultListCellRenderer();
				defaultRenderer.setBackground(l.getBackground());
				defaultRenderer.setBorder(l.getBorder());
				defaultRenderer.setComponentOrientation(l.getComponentOrientation());
				defaultRenderer.setEnabled(l.isEnabled());
				defaultRenderer.setFont(l.getFont());
				defaultRenderer.setForeground(l.getForeground());
				defaultRenderer.setOpaque(l.isOpaque());
				defaultRenderer.setToolTipText(l.getToolTipText());
				
				UI.setHTMLEnabled(defaultRenderer, isHTMLEnabled());
				defaultRenderer.setIcon(l.getIcon());
				defaultRenderer.setText(l.getText());
			
				return defaultRenderer;
			}
		}
		finally {
			this.list = null;
		}
		
		return view;
	}
	
	// StyleSupport
	
	@Override
	public void setStyle(final String value) {
		if (view != null)
			UI.setStyle(value, view);
		else
			throw new UnsupportedOperationException();
	}
	
	// TableCellRenderer

	@Override
	@SuppressWarnings("unchecked")
	public Component getTableCellRendererComponent(
		final JTable table,
		final Object value,
		final boolean isSelected,
		final boolean hasFocus,
		final int row,
		final int column
	) {
		try {
			this.table = table;
			this._selected = isSelected;
			this._focused = hasFocus;
			this.row = row;
			this.column = column;

			setup(table, (T)value);
		}
		finally {
			this.table = null;
		}
		
		return view;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Component getTreeCellRendererComponent(
		final JTree tree,
		final Object value,
		final boolean selected,
		final boolean expanded,
		final boolean leaf,
		final int row,
		final boolean hasFocus
	) {
		try {
			this.tree = tree;
			this._selected = selected;
			this.expanded = expanded;
			this.leaf = leaf;
			this.row = row;
			this._focused = hasFocus;

			setup(tree, (T)value);
			
			// HACK: some LAFs need invalidate
			getView().invalidate();
		}
		finally {
			this.tree = null;
		}
		
		return view;
	}

	// protected
	
	protected JComponent createView() {
		return new OptimizedLabel();
	}
	
	protected Color getRowColor(final T value) { return null; }
	
	@InvokedFromConstructor
	protected void initView() {
		view = createView();
		view.setIgnoreRepaint(true);
	}

	/**
	 * By default, this method uses @ref Renderable interface
	 * (if @p value implements it).
	 *
	 * Override to customize rendered value.
	 *
	 * @param value the non-null value (e.g. list element)
	 */
	protected void onRender(final T value) {
		if (renderHandler != null)
			renderHandler.accept(this, value);
		if (value instanceof Renderable)
			Renderable.class.cast(value).setupRenderer(this);
	}
	
	protected void setup(final JComponent parent, final T value) {
		view.setComponentOrientation(parent.getComponentOrientation());
		view.setEnabled(parent.isEnabled());
		view.setFont(parent.getFont());
		view.setOpaque(true);

		// table
		
		if (table != null) {
			setupTable(table, view, isSelected(), isFocused(), row, column);
			if (value != null)
				onRender(value);
			else
				handleNullValue();
			
			return;
		}

		// list
		
		if (list != null) {
			if (isSelected()) {
				Color bg = list.getSelectionBackground();
				Color fg = list.getSelectionForeground();

				// HACK: the original Synth color for some reason does not work
				if (UI.isNimbus()) {
					bg = new Color(bg.getRGB());
					fg = new Color(fg.getRGB());
				}

				view.setBackground(bg);
				view.setForeground(fg);
			}
			else {
				Color bg;
				if (list.isPaintingForPrint()) {
					bg = Color.WHITE;
				}
				else {
					if (UI.getLookAndFeelType().hasAlternateListRowColor()) {
						bg = list.getBackground();
						view.setOpaque(false);
					}
					else if (useAlternateRowColor)
						bg = getRowColor(row, list.getBackground());
					else
						bg = list.getBackground();

					// HACK: the original Synth color for some reason does not work
					if (UI.isNimbus())
						bg = new Color(bg.getRGB());
				}
				view.setBackground(bg);
				view.setForeground(list.getForeground());
			}
		}
		
		// tree
		
		else if (tree != null) {
			Color background;
			Color color = (value == null) ? null : getRowColor(value);
			Color foreground;

			if ((tree instanceof MTree<?, ?>) && MTree.class.cast(tree).isDropZone(getRow())) {
				if (color == null)
					color = UIManager.getColor("Tree.selectionBackground");
				color = UI.getBrighter(color, 50, Color.WHITE);
				if (Color.WHITE.equals(color))
					color = MColor.getDarker(color);

				background = color;
				foreground = MColor.getContrastBW(color);
			}
			else if (isSelected()) {
				UIDefaults defaults = UIManager.getDefaults();
				background = defaults.getColor("Tree.selectionBackground");
				foreground = defaults.getColor("Tree.selectionForeground");
			}
			else {
				background = color;
				if (
					(value instanceof MTreeItem) &&
					!UI.isRetro() &&
					(mouseHover != null) &&
					(mouseHoverPathComponent == value)
				) {
					// use tree.getBackground() for better look in dark color themes
					Color bg = UI.getBackground(tree);
					foreground = MColor.getLinkForeground(bg);
				}
				else {
					foreground = MColor.getContrastBW((background == null) ? tree.getBackground() : background);
				}
				view.setOpaque(false);
			}
			
			view.setBackground(background);
			view.setForeground(foreground);
		}
			
		setupBorder();

		if (value != null)
			onRender(value);
		else
			handleNullValue();
	}

	// based on the DefaultListCellRenderer class
	protected void setupBorder() {
		if ((list != null) || (tree != null)) {
			Border border = null;

			if (isFocused() && !UI.isRetro() && !UI.isWeb()) {
				if (isSelected())
					border = UIManager.getBorder("List.focusSelectedCellHighlightBorder");
				if (border == null)
					border = UIManager.getBorder("List.focusCellHighlightBorder");
			}
			else {
				border = UIManager.getBorder("List.cellNoFocusBorder");
				if (border == null)
					border = EMPTY_BORDER;
			}
			view.setBorder(BorderFactory.createCompoundBorder(
				(border != null) ? (new FixedBorder(border)) : null,
				getPaddingBorder()
			));
		}
	}

	// private

	private Border getPaddingBorder() {
		if (_paddingBorder == null)
			_paddingBorder = (padding == -1) ? null : UI.createEmptyBorder(padding);

		return _paddingBorder;
	}

	private void handleNullValue() {
		if (view instanceof JLabel) {
			JLabel l = (JLabel)view;
			l.setIcon(null);
			l.setText("");
		}
	}
	
	// public classes

	/** Methods that should be overriden in renderers. */
	public static interface Optimized {
	
		// public

		/**
		 * Overriden for performance reasons.
		 */
		public void invalidate();

		/**
		 * Overriden for performance reasons.
		 */
		public void repaint();

		/**
		 * Overriden for performance reasons.
		 * @param r Not used
		 */
		public void repaint(final Rectangle r);

		/**
		 * Overriden for performance reasons.
		 * @param tm Not used
		 * @param x Not used
		 * @param y Not used
		 * @param width Not used
		 * @param height Not used
		 */
		public void repaint(final long tm, final int x, final int y, final int width, final int height);

		/**
		 * Overriden for performance reasons.
		 */
		public void revalidate();

		/**
		 * Overriden for performance reasons.
		 */
		public void validate();
		
		public void firePropertyChange(final String propertyName, final boolean oldValue, final boolean newValue);
		public void firePropertyChange(final String propertyName, final byte oldValue, final byte newValue);
		public void firePropertyChange(final String propertyName, final char oldValue, final char newValue);
		public void firePropertyChange(final String propertyName, final double oldValue, final double newValue);
		public void firePropertyChange(final String propertyName, final float oldValue, final float newValue);
		public void firePropertyChange(final String propertyName, final int oldValue, final int newValue);
		public void firePropertyChange(final String propertyName, final long oldValue, final long newValue);
		public void firePropertyChange(final String propertyName, final short oldValue, final short newValue);

	}
	
	public static class OptimizedLabel extends MLabel implements Optimized {
		
		// public

		@Override public void invalidate() { }
		@Override public void repaint() { }
		@Override public void repaint(final Rectangle r) { }
		@Override public void repaint(final long tm, final int x, final int y, final int width, final int height) { }
		@Override public void revalidate() { }
		@Override public void validate() { }
		@Override public void firePropertyChange(final String propertyName, final boolean oldValue, final boolean newValue) { }
		@Override public void firePropertyChange(final String propertyName, final byte oldValue, final byte newValue) { }
		@Override public void firePropertyChange(final String propertyName, final char oldValue, final char newValue) { }
		@Override public void firePropertyChange(final String propertyName, final double oldValue, final double newValue) { }
		@Override public void firePropertyChange(final String propertyName, final float oldValue, final float newValue) { }
		@Override public void firePropertyChange(final String propertyName, final int oldValue, final int newValue) { }
		@Override public void firePropertyChange(final String propertyName, final long oldValue, final long newValue) { }
		@Override public void firePropertyChange(final String propertyName, final short oldValue, final short newValue) { }
		
		// protected

		// based on the DefaultListCellRenderer class
		@Override protected void firePropertyChange(final String propertyName, final Object oldValue, final Object newValue) {
			if (
				"text".equals(propertyName) ||
				(
					("font".equals(propertyName) || "foreground".equals(propertyName)) &&
					!Objects.equals(oldValue, newValue) &&
					(getClientProperty(BasicHTML.propertyKey) != null)
				)
			) {
				super.firePropertyChange(propertyName, oldValue, newValue);
			}
		}
		@Override protected void fireVetoableChange(final String propertyName, final Object oldValue, final Object newValue) throws PropertyVetoException { }

	}
	
	public static class OptimizedPanel extends MPanel implements Optimized {
	
		// public
		
		public OptimizedPanel() { }
		
		public OptimizedPanel(final boolean autoCreatePadding) {
			super(autoCreatePadding);
		}
		
		public OptimizedPanel(final LayoutManager layout) {
			super(layout);
		}

		@Override
		public void invalidate() {
			// HACK: this is slow
			if (getLayout() instanceof GroupLayout)
				super.invalidate();
		}

		@Override public void repaint() { }
		@Override public void repaint(final Rectangle r) { }
		@Override public void repaint(final long tm, final int x, final int y, final int width, final int height) { }
		@Override public void revalidate() { }

		@Override
		public void validate() {
			// HACK: this is slow
			if (getLayout() instanceof GroupLayout)
				super.validate();
		}

		@Override public void firePropertyChange(final String propertyName, final boolean oldValue, final boolean newValue) { }
		@Override public void firePropertyChange(final String propertyName, final byte oldValue, final byte newValue) { }
		@Override public void firePropertyChange(final String propertyName, final char oldValue, final char newValue) { }
		@Override public void firePropertyChange(final String propertyName, final double oldValue, final double newValue) { }
		@Override public void firePropertyChange(final String propertyName, final float oldValue, final float newValue) { }
		@Override public void firePropertyChange(final String propertyName, final int oldValue, final int newValue) { }
		@Override public void firePropertyChange(final String propertyName, final long oldValue, final long newValue) { }
		@Override public void firePropertyChange(final String propertyName, final short oldValue, final short newValue) { }
		
		// protected
		
		@Override protected void firePropertyChange(final String propertyName, final Object oldValue, final Object newValue) { }
		@Override protected void fireVetoableChange(final String propertyName, final Object oldValue, final Object newValue) throws PropertyVetoException { }

	}

	/**
	 * @since 3.6
	 */
	public static interface Renderable {

		// public

		public void setupRenderer(final MRenderer<?> r);

	}

	// private classes

	private static final class FixedBorder implements Border {

		// private

		private final Border impl;

		// public

		@Override
		public Insets getBorderInsets(final Component c) {
			Insets i = impl.getBorderInsets(c);
			// HACK: OpenJDK/GTK+ may return null in some cases
			// http://sourceforge.net/p/makagiga/bugs/9/
			return (i == null) ? UI.createInsets(0) : i;
		}

		@Override
		public boolean isBorderOpaque() {
			return impl.isBorderOpaque();
		}

		@Override
		public void paintBorder(final Component c, final Graphics g, final int x, final int y, final int width, final int height) {
			impl.paintBorder(c, g, x, y, width, height);
		}

		// private

		private FixedBorder(final Border impl) {
			this.impl = impl;
		}

	}

}
