// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mv;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.beans.PropertyVetoException;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MCheckBox;

/**
 * A {@code java.lang.Boolean} data renderer.
 *
 * @since 2.0
 */
public class BooleanRenderer extends MCheckBox
implements
	MRenderer.Optimized,
	TableCellRenderer
{

	// private
	
	private boolean autoDisable;
	private Color useBackground;

	// public

	/**
	 * Constructs a {@code java.lang.Boolean} data renderer.
	 */
	public BooleanRenderer() {
		setBorderPainted(true);
		setHorizontalAlignment(CENTER);
	}
	
	/**
	 * @since 4.4
	 */
	public boolean getAutoDisable() { return autoDisable; }

	/**
	 * @since 4.4
	 */
	public void setAutoDisable(final boolean value) { autoDisable = value; }

	/**
	 * Returns the table cell renderer component.
	 * @param table A table
	 * @param value A value - @c true if task is completed
	 * @param isSelected {@code true} if cell is selected
	 * @param hasFocus {@code true} if cell has focus
	 * @param row A table row
	 * @param column A table column
	 */
	@Override
	public Component getTableCellRendererComponent(
		final JTable table,
		final Object value,
		final boolean isSelected,
		final boolean hasFocus,
		final int row,
		final int column
	) {
		MRenderer.setupTable(table, this, isSelected, hasFocus, row, column);
		setFont(UI.getFont(table));
		
		if (UI.isSubstance()) {
			useBackground = UI.getBackground(this);
			setBackground(null);
		}
		else {
			useBackground = null;
		}
		if (UI.isSeaGlass())
			setOpaque(isSelected);
		else
			setOpaque(!UI.isA03() && !UI.isSubstance());

		if (autoDisable)
			setEnabled(table.isEnabled() && table.isCellEditable(row, column));

		setSelected((value != null) && (Boolean)value);

		return this;
	}
	
	// MRenderer.Optimized

	@Override public void invalidate() { }
	@Override public void repaint() { }
	@Override public void repaint(final Rectangle r) { }
	@Override public void repaint(final long tm, final int x, final int y, final int width, final int height) { }
	@Override public void revalidate() { }
	@Override public void validate() { }
	@Override public void firePropertyChange(final String propertyName, final boolean oldValue, final boolean newValue) { }
	@Override public void firePropertyChange(final String propertyName, final byte oldValue, final byte newValue) { }
	@Override public void firePropertyChange(final String propertyName, final char oldValue, final char newValue) { }
	@Override public void firePropertyChange(final String propertyName, final double oldValue, final double newValue) { }
	@Override public void firePropertyChange(final String propertyName, final float oldValue, final float newValue) { }
	@Override public void firePropertyChange(final String propertyName, final int oldValue, final int newValue) { }
	@Override public void firePropertyChange(final String propertyName, final long oldValue, final long newValue) { }
	@Override public void firePropertyChange(final String propertyName, final short oldValue, final short newValue) { }
	@Override protected void firePropertyChange(final String propertyName, final Object oldValue, final Object newValue) { }
	@Override protected void fireVetoableChange(final String propertyName, final Object oldValue, final Object newValue) throws PropertyVetoException { }

	// protected

	@Override
	protected void paintComponent(final Graphics graphics) {
		if (isPaintingForPrint()) { // paint as simple text
			MGraphics2D g = new MGraphics2D(graphics);
			g.setColor(Color.BLACK);
			g.setFont(UI.deriveMonospacedFont(UI.getFont(this)));
			g.drawStringCentered(isSelected() ? "[X]" : "[ ]", this);
		}
		else {
			// HACK: no background color (?)
			if (UI.isSubstance() && (useBackground != null)) {
				graphics.setColor(useBackground);
				graphics.fillRect(0, 0, getWidth(), getHeight());
			}
			super.paintComponent(graphics);
		}
	}

}
