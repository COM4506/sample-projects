// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.mv;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.beans.PropertyVetoException;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MProgressBar;
import org.makagiga.commons.swing.SimpleProgressBar;

/**
 * @since 5.4
 */
public class ProgressRenderer extends MProgressBar
implements
	MRenderer.Optimized,
	TableCellRenderer
{

	// private

	private SimpleProgressBar simpleProgressBar;

	// public

	public ProgressRenderer() {
		setMaximum(100);
		setMinimum(0);
		setStringPainted(true);
	}

	@Override
	public Component getTableCellRendererComponent(
		final JTable table,
		final Object value,
		final boolean isSelected,
		final boolean hasFocus,
		final int row,
		final int column
	) {
		Color oldBG = UI.isSubstance() ? getBackground() : null;

		MRenderer.setupTable(table, this, isSelected, hasFocus, row, column);

		int complete = (Integer)value;

// FIXME: right vertical border line not painted
		if (UI.isA03()) {
			setBorder(null);
			setBorderPainted(false);
			setOpaque(false);
		}
		else if (UI.isMetal()) {
			setBorderPainted(hasFocus);
			setOpaque(true);
		}
		else if (UI.isSeaGlass()) {
			setOpaque(isSelected);
		}
		else if (UI.isSubstance()) {
			setBackground(oldBG);
			setOpaque(false);
		}
		else {
			setOpaque(true);
		}

		setString(formatString(complete));

		// HACK: 0% progress bar painted incorrectly
		// if there are other with 100% value
		if ((complete == 0) && UI.isSubstance())
			complete++;
		setValue(complete);

		return this;
	}
	
	@Override
	public void updateUI() {
		super.updateUI();
		if (UI.isA03())
			putClientProperty("A03.ProgressBar.shape", "rectangle");
	}

	// MRenderer.Optimized

	@Override public void invalidate() { }
	@Override public void repaint() { }
	@Override public void repaint(final Rectangle r) { }
	@Override public void repaint(final long tm, final int x, final int y, final int width, final int height) { }
	@Override public void revalidate() { }
	@Override public void validate() { }
	@Override public void firePropertyChange(final String propertyName, final boolean oldValue, final boolean newValue) { }
	@Override public void firePropertyChange(final String propertyName, final byte oldValue, final byte newValue) { }
	@Override public void firePropertyChange(final String propertyName, final char oldValue, final char newValue) { }
	@Override public void firePropertyChange(final String propertyName, final double oldValue, final double newValue) { }
	@Override public void firePropertyChange(final String propertyName, final float oldValue, final float newValue) { }
	@Override public void firePropertyChange(final String propertyName, final int oldValue, final int newValue) { }
	@Override public void firePropertyChange(final String propertyName, final long oldValue, final long newValue) { }
	
	@Override
	public void firePropertyChange(final String propertyName, final short oldValue, final short newValue) { }

	@Override protected void firePropertyChange(final String propertyName, final Object oldValue, final Object newValue) { }
	@Override protected void fireVetoableChange(final String propertyName, final Object oldValue, final Object newValue) throws PropertyVetoException { }

	// protected

	protected String formatString(final int value) {
		return value + "%";
	}

	@Override
	protected void paintComponent(final Graphics graphics) {
		if (isPaintingForPrint()) {
			if (simpleProgressBar == null) {
				simpleProgressBar = new SimpleProgressBar();
				simpleProgressBar.setForeground(Color.BLACK);
			}
			simpleProgressBar.setMaximum(getMaximum());
			simpleProgressBar.setValue(getValue());

			int w = getWidth();
			int h = getHeight();
			graphics.setColor(Color.WHITE);
			graphics.fillRect(0, 0, w, h);
			int margin = 4;
			simpleProgressBar.paint((Graphics2D)graphics, margin, margin, w - margin * 2, h - margin * 2);
		}
		else {
			super.paintComponent(graphics);
		}
	}

}
