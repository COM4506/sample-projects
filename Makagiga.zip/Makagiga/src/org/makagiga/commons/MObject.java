// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.util.Objects;

import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * A <code>java.lang.Object</code> utilities.
 * 
 * @since 3.0
 */
@Obsolete
public final class MObject {
	
	// public
	
	/**
	 * A result of the {@link #equalsFinal(Object, Object)} method.
	 */
	public enum Equals {
		
		/**
		 * The two objects are 100% equal.
		 */
		YES,

		/**
		 * The two objects are <b>not</b> equal.
		 */
		NO,

		/**
		 * Need further testing.
		 */
		MAYBE

	}
	
	// public

	/**
	 * Compares the two <strong>final</strong> objects ({@code thiz} and {@code other}).
	 *
	 * @mg.warning Use this method with {@code final} classes.
	 * 
	 * @mg.example
	 * <pre class="brush: java">
	 * {@literal @}Override
	 * public boolean equals(final Object other) {
	 *   switch (MObject.equalsFinal(this, other)) {
	 *     case YES: return true;
	 *     case NO: return false;
	 *     default: // MAYBE
	 *       Foo foo = (Foo)other;
	 *       return this.field == foo.field;
	 *   }
	 * }
	 * </pre>
	 * 
	 * @return Equals.YES If <code>thiz == other</code> (in this situation both {@code thiz} and {@code other} can be {@code null})
	 * @return Equals.NO If {@code other} is {@code null} or if <code>thiz.getClass() != other.getClass()</code>
	 * @return Equals.MAYBE The default result - compare the fields
	 * 
	 * @throws NullPointerException MAY throw this exception if @p thiz is @c null
	 *
	 * @since 4.0
	 */
	public static Equals equalsFinal(final Object thiz, final Object other) {
		if (thiz == other)
			return Equals.YES;
		
		if ((other == null) || (thiz.getClass() != other.getClass()))
			return Equals.NO;
		
		return Equals.MAYBE;
	}

	/**
	 * Returns a hash code for {@code value}
	 * compatible with {@link java.lang.Boolean#hashCode()}.
	 *
	 * @param value the value
	 *
	 * @since 4.0
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static int hashCode(final boolean value) {
		return Boolean.hashCode(value);
	}

	/**
	 * Returns a hash code for {@code value}
	 * compatible with {@link java.lang.Double#hashCode()}.
	 *
	 * @param value the value
	 *
	 * @since 4.0
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static int hashCode(final double value) {
		return Double.hashCode(value);
	}

	/**
	 * Returns a hash code for {@code value}
	 * compatible with {@link java.lang.Float#hashCode()}.
	 *
	 * @param value the value
	 *
	 * @since 4.0
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static int hashCode(final float value) {
		return Float.hashCode(value);
	}

	/**
	 * Returns a hash code for {@code value}
	 * compatible with {@link java.lang.Long#hashCode()}.
	 *
	 * @param value the value
	 *
	 * @since 4.0
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static int hashCode(final long value) {
		return Long.hashCode(value);
	}
	
	/**
	 * Returns a hash code for an array of @c int values.
	 * 
	 * @param values The array of @c int values.
	 * 
	 * @return Zero if @p values is @c null or empty
	 */
	public static int hashCode(final int... values) {
		if ((values == null) || (values.length == 0))
			return 0;
		
		int result = 1;
		for (int i : values)
			result = 31 * result + i;
		
		return result;
	}
	
	/**
	 * Returns a hash code for an array of @c java.lang.Object values.
	 * The @p values array can contain @c null elements.
	 * 
	 * @param values The array of @c java.lang.Object values.
	 * 
	 * @return Zero if @p values is @c null or empty
	 */
	public static int hashCode(final Object... values) {
		if ((values == null) || (values.length == 0))
			return 0;
		
		int result = 1;
		for (Object i : values)
			result = 31 * result + Objects.hashCode(i);
		
		return result;
	}
	
	// private
	
	@Uninstantiable
	private MObject() {
		TK.uninstantiable();
	}

}
