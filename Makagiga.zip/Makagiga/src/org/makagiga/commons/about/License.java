// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.about;

import java.io.Serializable;
import java.net.URI;
import java.util.Objects;

import org.makagiga.commons.TK;

/**
 * @since 3.8.8
 */
public final class License implements Serializable {

	// public

	public static final License APACHE_V2 = new License("Apache License, Version 2.0", URI.create("http://www.apache.org/licenses/LICENSE-2.0.html"));
	public static final License BSD = new License("BSD License", URI.create("http://www.opensource.org/licenses/bsd-license.php"));

	// private

	private final String name;
	private final URI uri;
	
	// public
	
	public License(final String name, final URI uri) {
		this.name = TK.checkNullOrEmpty(name);
		this.uri = Objects.requireNonNull(uri);
	}

	@Override
	public boolean equals(final Object o) {
		if (o == this)
			return true;

		if (!(o instanceof License))
			return false;

		License other = (License)o;

		return
			this.name.equals(other.name) &&
			this.uri.equals(other.uri);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, uri);
	}

	public String getName() { return name; }

	public URI getURI() { return uri; }

	@Override
	public String toString() { return name; }

}
