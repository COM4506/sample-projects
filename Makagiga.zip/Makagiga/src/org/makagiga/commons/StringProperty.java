// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.text.ParseException;

/** A @c String property. */
public class StringProperty extends Property<String> implements CharSequence {

	// public

	/**
	 * Constructs a {@code null} {@code String} property.
	 */
	public StringProperty() {
		super(null);
	}

	/**
	 * Constructs a @c String property with @p value (can be @c null).
	 */
	public StringProperty(final String value) {
		super(value);
	}

	/**
	 * @since 4.0
	 */
	public StringProperty(final String value, final int options) {
		super(value, options);
	}

	/**
	 * @since 2.4
	 */
	@Override
	public Class<String> getType() { return String.class; }

	/**
	 * Returns @c true if value is @c null or empty ("").
	 */
	public boolean isEmpty() {
		return TK.isEmpty(get());
	}
	
	@Override
	public boolean isStringType() { return true; }

	/**
	 * Simply sets property to @p value.
	 *
	 * @throws ParseException Declared for compatibility; not used
	 */
	@Override
	public void parse(final String value) throws ParseException {
		set(value); // nothing to parse ;)
	}

	@Override
	public void read(final Config config, final String key) {
		set(config.read(key, getDefaultValue()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, get());
	}
	
	// CharSequence

	/**
	 * @since 4.0
	 */
	@Override
	public char charAt(final int index) {
		String s = get();
	
		if (TK.isEmpty(s))
			throw new IndexOutOfBoundsException();
		
		return s.charAt(index);
	}

	/**
	 * @since 4.0
	 */
	@Override
	public int length() {
		String s = get();
		
		return TK.isEmpty(s) ? 0 : s.length();
	}

	/**
	 * @since 4.0
	 */
	@Override
	public CharSequence subSequence(final int start, final int end) {
		String s = get();
	
		if (TK.isEmpty(s))
			throw new IndexOutOfBoundsException();
		
		return s.subSequence(start, end);
	}

}
