// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.function.Supplier;

import org.makagiga.commons.annotation.Obsolete;

/**
 * @since 3.8.12, 4.0 (org.makagiga.commons package)
 */
@Obsolete
public class CollectionMap<K, T>
implements
	Iterable<Map.Entry<K, Collection<T>>>,
	Map<K, Collection<T>>
{

	// public

	@Obsolete
	public enum CollectionType { ARRAY_LIST, SYNCHRONIZED_ARRAY_LIST, HASH_SET, LINKED_HASH_SET, TREE_SET }

	@Obsolete
	public enum MapType { HASH_MAP, SYNCHRONIZED_HASH_MAP, LINKED_HASH_MAP, TREE_MAP }

	// private

	private final CollectionType collectionType;
	private final Map<K, Collection<T>> map;
	private final MapType mapType;
	private final Supplier<Collection<T>> collectionSupplier;
	
	// public

	/**
	 * @since 4.8
	 */
	@Obsolete
	public CollectionMap(final Map<K, Collection<T>> map, final CollectionType collectionType) {
		this.mapType = null;
		this.collectionType = Objects.requireNonNull(collectionType);
		this.map = map;
		this.collectionSupplier = null;
	}

	/**
	 * @since 5.4
	 */
	public CollectionMap(final Map<K, Collection<T>> map, final Supplier<Collection<T>> collectionSupplier) {
		this.mapType = null;
		this.collectionType = null;
		this.map = map;
		this.collectionSupplier = Objects.requireNonNull(collectionSupplier);
	}

	@Obsolete
	public CollectionMap(final MapType mapType, final CollectionType collectionType) {
		this.mapType = Objects.requireNonNull(mapType);
		this.collectionType = Objects.requireNonNull(collectionType);
		this.map = createMap();
		this.collectionSupplier = null;
	}

	public Collection<T> add(final K key, final T value) {
		Collection<T> c = createCollection(key);
		c.add(value);

		return c;
	}

	/**
	 * @since 4.8
	 */
	public Collection<T> createCollection(final K key) {
		Collection<T> c = map.get(key);
		if (c == null) {
			c = createCollection();
			map.put(key, c);
		}

		return c;
	}

	@Override
	public boolean equals(final Object o) {
		if (o == this)
			return true;

		return map.equals(o);
	}

	@Override
	public int hashCode() { return 0; }

	public Map<K, ? extends Collection<T>> getMap() { return map; }

	// Iterable

	@Override
	public Iterator<Entry<K, Collection<T>>> iterator() {
		return map.entrySet().iterator();
	}

	// Map

	@Override
	public void clear() { map.clear(); }

	@Override
	public boolean containsKey(final Object key) { return map.containsKey(key); }

	@Override
	public boolean containsValue(final Object value) { return map.containsValue(value); }

	@Override
	public Set<Entry<K, Collection<T>>> entrySet() { return map.entrySet(); }

	@Override
	public Collection<T> get(final Object key) { return map.get(key); }

	@Override
	public Collection<T> put(final K key, final Collection<T> value) { return map.put(key, value); }

	@Override
	public boolean isEmpty() { return map.isEmpty(); }

	@Override
	public int size() { return map.size(); }

	@Override
	public Set<K> keySet() { return map.keySet(); }

	@Override
	public void putAll(final Map<? extends K, ? extends Collection<T>> m) { map.putAll(m); }

	@Override
	public Collection<T> remove(final Object key) { return map.remove(key); }

	@Override
	public Collection<Collection<T>> values() { return map.values(); }

	// private

	private Collection<T> createCollection() {
		if (collectionSupplier != null)
			return collectionSupplier.get();

		switch (collectionType) {
			case ARRAY_LIST: return new MArrayList<>();
			case HASH_SET: return new HashSet<>();
			case LINKED_HASH_SET: return new LinkedHashSet<>();
			case TREE_SET: return new TreeSet<>();
			case SYNCHRONIZED_ARRAY_LIST: return new Vector<>();
			default: throw new WTFError(collectionType);
		}
	}

	private Map<K, Collection<T>> createMap() {
		switch (mapType) {
			case HASH_MAP: return new HashMap<>();
			case LINKED_HASH_MAP: return new LinkedHashMap<>();
			case SYNCHRONIZED_HASH_MAP: return new Hashtable<>();
			case TREE_MAP: return new TreeMap<>();
			default: throw new WTFError(mapType);
		}
	}

}
