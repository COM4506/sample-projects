// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static java.lang.System.err;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.IllegalFormatException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.LoggingPermission;
import java.util.logging.LogRecord;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.swing.MSmallButton;
import org.makagiga.commons.swing.MTimer;

/** A logger. */
public final class MLogger extends Logger {
	
	// public

	/**
	 * Enable/disable particular log messages.
	 *
	 * - +all - log all
	 * - +plugins - log plugin messages only
	 * - +all,-plugins,-foo - log all except plugin and foo messages
	 *
	 * @since 2.0
	 */
	public static final StringProperty debugLog = new StringProperty("+core", StringProperty.SECURE_WRITE);

	/**
	 * Enable "developer mode":
	 * 
	 * - verbose logging
	 * - show heap memory usage in menu bar
	 * - show console on unhandled runtime exception
	 * - and more...
	 *
	 * @since 2.0
	 */
	public static final BooleanProperty developer = new BooleanProperty(false, BooleanProperty.SECURE_WRITE);

	/**
	 * @since 4.0
	 */
	public static final BooleanProperty printStackTrace = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);

	// private

	private static boolean logAll;
	private static final LoggingPermission CONTROL_PERMISSION = new LoggingPermission("control", null);
	private static final Map<String, Boolean> logConfig = new ConcurrentHashMap<>();
	private static final Map<String, MLogger> loggerMap = new ConcurrentHashMap<>();
	private static MLogger _instance;
	private static final String DEFAULT_LOG = "log";

	// static

	/**
	 * Initializes the logger.
	 */
	static {
		synchronized (MLogger.class) {
			_instance = new MLogger();
		}
		debugLog.addChangeListener((e, value) -> doInitLogConfig());
		//MLogger.doInitLogConfig();
		// NOTE: sync. with MLogger default values
		logConfig.put("core", true);
	}

	/**
	 * @since 4.0
	 */
	@SuppressFBWarnings("DM_GC")
	public static MSmallButton createMemoryButton() {
		MSmallButton button = new MSmallButton();
		button.addActionListener(e -> System.gc());
		button.setFocusable(false);
		button.setStyle("font-size: smaller");
		button.setText("GC");
		button.setToolTipText(UI.makeHTML("Heap memory usage.<br>Click to run <i>Garbage Collector</i>."));
		MTimer timer = new MTimer(TimeUnit.SECONDS, 4) {
			private long max;
			private long oldUsed;
			@Override
			protected boolean onTimeout() {
				if (!MLogger.isDeveloper())
					return CONTINUE;
				
				Runtime rt = Runtime.getRuntime();
				long used = rt.totalMemory() - rt.freeMemory();
				long diff = used - oldUsed;
				oldUsed = used;
				max = Math.max(used, max);
				button.setForeground((diff <= 0) ? MColor.DARK_GREEN : MColor.DARK_RED);
				button.setText(String.format(
					"%1.2f / %1.2f MiB [%1.2f]",
					used / (float)MFormat.MB,
					max / (float)MFormat.MB,
					diff / (float)MFormat.MB
				));

				return CONTINUE;
			}
		};
		timer.setInitialDelay(TimeUnit.SECONDS, 10);
		timer.start();
		
		developer.addChangeListener((e, value) -> button.setVisible(value));
		
		return button;
	}

	// public

	/**
	 * @since 3.0
	 */
	public void debug(final String text) {
		if (isDebug())
			info("[" + text + "]");
	}

	/**
	 * @since 3.0
	 */
	public void debugFormat(final String text, final Object... args) {
		if (isDebug())
			info("[" + format(text, args) + "]");
	}

	/**
	 * Logs a debug info.
	 * @param id An ID
	 * @param text A text
	 */
	public static void debug(final String id, final String text) {
		if (isDebug(id))
			_instance.info(id + " [" + text + "]");
	}

	/**
	 * Logs a debug info.
	 * @param id An ID
	 * @param text A text
	 * @param args Arguments used to format text
	 */
	public static void debug(final String id, final String text, final Object... args) {
		if (isDebug(id))
			_instance.info(id + " [" + format(text, args) + "]");
	}
	
	/**
	 * @since 4.4
	 *
	 * @see #exception(Throwable)
	 * @see #isDeveloper()
	 */
	public static boolean developerException(final Throwable throwable) {
		if (isDeveloper()) {
			exception(throwable);
			
			return true;
		}
		
		return false;
	}

	/**
	 * @since 3.0
	 */
	public void error(final String text) {
		if (isDebug())
			severe(text);
	}

	/**
	 * @since 3.0
	 */
	public void errorFormat(final String text, final Object... args) {
		if (isDebug())
			severe(format(text, args));
	}

	/**
	 * Logs an error.
	 * @param id An ID
	 * @param text A text
	 */
	public static void error(final String id, final String text) {
		if (isDebug(id))
			_instance.severe(id + ": " + text);
	}

	/**
	 * Logs an error.
	 * @param id An ID
	 * @param text A text
	 * @param args Arguments used to format text
	 */
	public static void error(final String id, final String text, final Object... args) {
		if (isDebug(id))
			_instance.severe(id + ": " + format(text, args));
	}

	/**
	 * Logs an exception, and prints a stack trace to @b stderr.
	 * @param exception A throwable exception
	 */
	public static void exception(final Throwable exception) {
		if (exception == null)
			return;

		if (!printStackTrace.booleanValue())
			return;

		error("exception", exception.toString());
		err.println("Current Thread: " + Thread.currentThread());
		exception.printStackTrace(err);
	}
	
	/**
	 * @since 2.0
	 */
	public static String format(final String format, final Object... args) {
		if (format == null)
			return "null";
		
		try {
			return String.format(format, args);
		}
		catch (IllegalFormatException exception) {
			exception.printStackTrace(err);
			
			return format;
		}
	}

	/**
	 * @since 4.10
	 */
	public static String formatDebugString(final Object o) {
		String s = o.toString();
		boolean wasLeftBracket = false;
		int indent = 0;
		int len = s.length();
		MStringBuilder buf = new MStringBuilder(len + 256);
		for (int i = 0; i < len; i++) {
			char c = s.charAt(i);
			switch (c) {
				case '=':
					buf.append(" = ");
					break;
				case ',':
					if (!wasLeftBracket) {
						buf.n();
						buf.fill(' ', indent);
					}
					break;
				case '[':
					indent += 4;
					buf.append(c);
					buf.n();
					buf.fill(' ', indent);
					break;
				case ']':
					indent = Math.max(0, indent - 4);
					buf.n();
					buf.fill(' ', indent);
					buf.append(c);
					break;
				default:
					buf.append(c);
			}
			wasLeftBracket = (c == '[');
		}
		
		return buf.toString();
	}

	/**
	 * @since 3.4
	 */
	public static MLogger get(final String name) {
		MLogger log = loggerMap.get(name);
		if (log == null) {
			log = new MLogger(name);
			loggerMap.put(name, log);
		}
		//LogManager.getLogManager().addLogger(log);

		return log;
	}

	/**
	 * Returns the list of {@code MLogger}s registered using {@link #get(String)}.
	 *
	 * @since 3.8.1
	 */
	public static List<MLogger> getLogs() {
		return new MArrayList<>(loggerMap.values());
	}

	/**
	 * @since 3.0
	 */
	public void infoFormat(final String text, final Object... args) {
		if (isDebug())
			info(format(text, args));
	}

	/**
	 * Logs an info.
	 * @param id An ID
	 * @param text A text
	 */
	public static void info(final String id, final String text) {
		if (isDebug(id))
			_instance.info(id + ": " + text);
	}

	/**
	 * Logs an info.
	 * @param id An ID
	 * @param text A text
	 * @param args Arguments used to format text
	 */
	public static void info(final String id, final String text, final Object... args) {
		if (isDebug(id))
			_instance.info(id + ": " + format(text, args));
	}
	
	/**
	 * @since 3.0
	 */
	public boolean isDebug() {
		try {
			if (logAll || isDeveloper()) {
				if (Boolean.FALSE.equals(logConfig.get(getName())))
					return false;
				
				return true;
			}

			return Boolean.TRUE.equals(logConfig.get(getName()));
		}
		catch (SecurityException exception) {
			exception.printStackTrace();
			
			return false;
		}
	}

	public static boolean isDebug(final String id) {
		try {
			if (logAll || isDeveloper()) {
				if (Boolean.FALSE.equals(logConfig.get(id)))
					return false;
				
				return true;
			}

			return DEFAULT_LOG.equals(id) || Boolean.TRUE.equals(logConfig.get(id));
		}
		catch (SecurityException exception) {
			exception.printStackTrace();
			
			return false;
		}
	}

	/**
	 * Returns {@code true} if application is running in "developer" mode.
	 *
	 * @return {@code true} if application is running in "developer" mode.
	 *
	 * @see #developer
	 *
	 * @since 3.8.1
	 */
	public static boolean isDeveloper() {
		return developer.get();
	}

	/**
	 * @since 2.0
	 */
	public static void trace() {
		Thread.dumpStack();
	}
	
	/**
	 * @since 3.0
	 */
	public static void trace(final int maxElements) {
		StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
		for (int i = 2; i < stackTrace.length; i++) {
			if (i - 2 >= maxElements)
				break;

			err.println("\tat " + stackTrace[i]);
		}
	}

	@Override
	public void warning(final String text) {
		if (isDebug())
			super.warning(text);
	}

	/**
	 * @since 3.0
	 */
	public void warningFormat(final String text, final Object... args) {
		if (isDebug())
			super.warning(format(text, args));
	}

	/**
	 * Logs a warning.
	 * @param id An ID
	 * @param text A text
	 */
	public static void warning(final String id, final String text) {
		if (isDebug(id))
			_instance.superWarning(id + ": " + text);
	}

	/**
	 * Logs a warning.
	 * @param id An ID
	 * @param text A text
	 * @param args Arguments used to format text
	 */
	public static void warning(final String id, final String text, final Object... args) {
		if (isDebug(id))
			_instance.warning(id + ": " + format(text, args));
	}
	
	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
	public static void XXX() {
		StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
		if (stackTrace.length > 2)
			XXX("YOU ARE HERE: %s", stackTrace[2]);
		else
			XXX("YOU ARE HERE");
	}

	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static void XXX(final Object object) {
		if (object == null)
			_instance.finest("***: null");
		else
			_instance.finest("***: " + object.getClass().getName() + ": \"" + object + "\"");
	}

	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static void XXX(final String text) {
		_instance.finest("***: " + text);
	}

	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static void XXX(final String text, final Object... args) {
		XXX(format(text, args));
	}

	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static void XXXTrace() {
		XXX();
		trace();
	}

	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static void XXXTrace(final String text) {
		XXX(text);
		trace();
	}
	
	// private
	
	private MLogger() {
		this(DEFAULT_LOG);
		setUseParentHandlers(false);
	}

	/**
	 * @since 4.4
	 */
	public MLogger(final String name) { // public
		super(name, null);
		SecurityManager sm = System.getSecurityManager();
		if (sm == null) {
			doInit();
		}
		else {
			AccessController.doPrivileged((PrivilegedAction<Void>)() -> {
				doInit();

				return null;
			}, null, CONTROL_PERMISSION);
		}
	}

	private void doInit() {
		super.addHandler(new MHandler());
		super.setLevel(Level.ALL);
	}
	
	private synchronized static void doInitLogConfig() {
		try {
			String dl = debugLog.get();
			logAll = false;
			logConfig.clear();

			if (TK.isEmpty(dl))
				return;
			
			for (String i : TK.fastSplit(dl, ',')) {
				if ("+all".equals(i)) {
					logAll = true;
					
					continue; // for
				}

				if (i.length() > 1) {
					switch (i.charAt(0)) {
						case '+':
							logConfig.put(i.substring(1), true);
							break;
						case '-':
							logConfig.put(i.substring(1), false);
							break;
						default:
							err.println("MAKAGIGA: Invalid logger configuration (org.makagiga.commons.MLogger.debugLog): " + i);
					}
				}
				else {
					err.println("MAKAGIGA: Invalid logger configuration (org.makagiga.commons.MLogger.debugLog): " + i);
				}
			}
		}
		catch (SecurityException exception) {
			exception.printStackTrace();
		}
	}

	private void superWarning(final String text) {
		super.warning(text);
	}

	// private classes

	private static final class MFormatter extends Formatter {
	
		// private
		
		// ANSI escape
		private static final String BLUE = "\033[34m";
		//private static final String GREEN = "\033[32m";
		private static final String PURPLE = "\033[35m";
		private static final String RED = "\033[31m";
		private static final String RESET = "\033[0m";

		// public
		
		@Override
		public String format(final LogRecord record) {
			return format(record, false);
		}
		
		// private

		private String format(final LogRecord record, final boolean colors) {
			StringBuilder s = new StringBuilder(150);
			
			if (!FS.isRestricted()) {
				s
					.append(MApplication.getInternalName())
					.append(' ');
			}

			s
				.append('[')
				.append(record.getSequenceNumber())
				.append("] ");

			Level level = record.getLevel();
			if (colors) {
				if (level == Level.SEVERE)
					s.append(RED);
				else if (level == Level.WARNING)
					s.append(PURPLE);
				else
					s.append(BLUE);
			}
			s.append(level);

			if (colors)
				s.append(RESET);

			s.append(": ");

			String name = record.getLoggerName();
			if (!DEFAULT_LOG.equals(name)) {
				if (colors)
					s.append(BLUE);
				s.append(name);
				if (colors)
					s.append(RESET);
				s.append(": ");
			}

			s.append(record.getMessage());
			
			if (colors)
				s.append(RESET);

			return s.toString();
		}

	}

	private static final class MHandler extends Handler {

		// private

		private final MFormatter formatter = new MFormatter();

		// public

		@Override
		public void close() { }

		@Override
		public void flush() { }

		@Override
		public void publish(final LogRecord record) {
			err.println(formatter.format(record, !OS.isWindows()));
		}

	}

}
