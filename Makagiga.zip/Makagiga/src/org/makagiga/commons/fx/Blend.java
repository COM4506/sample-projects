// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.fx;

import java.awt.Color;
import java.lang.ref.WeakReference;
import javax.swing.JComponent;
import javax.swing.text.JTextComponent;

import org.pushingpixels.trident.Timeline;

import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * @since 2.0
 *
 * @deprecated Since 5.6
 */
@Deprecated
public final class Blend {
	
	// private

	private static final String BACKGROUND_TIMELINE_PROPERTY = "org.makagiga.commons.fx.Blend.backgroundTimeline";
	private static final String FOREGROUND_TIMELINE_PROPERTY = "org.makagiga.commons.fx.Blend.foregroundTimeline";

	// public

	/**
	 * @since 3.8.6
	 */
	public static Timeline animateBackground(final JComponent c, final Color from, final Color to) {
		// do not start new animation if the old one is still running
		WeakReference<Timeline> timelineRef = UI.getClientProperty(c, BACKGROUND_TIMELINE_PROPERTY, null);
		Timeline currentTimeline = TK.get(timelineRef);
		if (currentTimeline != null) {
			Timeline.TimelineState state = currentTimeline.getState();

			if (state != Timeline.TimelineState.IDLE)
				return currentTimeline;
		}
	
		MTimeline<JComponent> t = new MTimeline<>(c);
		t.addPropertyToInterpolate(
			"background",
			(from == null) ? UI.getBackground(c) : from,
			(to == null) ? UI.getBackground(c) : to
		);

		setup(c, t, BACKGROUND_TIMELINE_PROPERTY);
		
		return t;
	}

	/**
	 * @since 3.8.6
	 */
	public static Timeline animateForeground(final JComponent c, final Color from, final Color to) {
		MTimeline<JComponent> t = new MTimeline<>(c);
		t.addPropertyToInterpolate(
			"foreground",
			(from == null) ? UI.getForeground(c) : from,
			(to == null) ? UI.getForeground(c) : to
		);

		setup(c, t, FOREGROUND_TIMELINE_PROPERTY);
		
		return t;
	}

	/**
	 * @since 3.8.6
	 */
	@Obsolete // should return void
	public static Timeline stopAnimation(final JComponent c) {
		stopAnimation(c, BACKGROUND_TIMELINE_PROPERTY);

		return stopAnimation(c, FOREGROUND_TIMELINE_PROPERTY);
	}
	
	// private

	@Uninstantiable
	private Blend() {
		TK.uninstantiable();
	}

	private static void setup(final JComponent c, final Timeline t, final String property) {
		stopAnimation(c, property);
		if (c instanceof JTextComponent)
			t.setDuration(200);
		else
			t.setDuration(500);
		t.play();

		c.putClientProperty(property, new WeakReference<>(t));
	}
	
	private static Timeline stopAnimation(final JComponent c, final String property) {
		Timeline t = null;
		WeakReference<Timeline> timelineRef = UI.getClientProperty(c, property, null);
		if (timelineRef != null) {
			t = timelineRef.get();
			if (t != null) {
				timelineRef.clear();
				if (t instanceof MTimeline<?>)
					MTimeline.class.cast(t).setEnabled(false);
				t.cancel();
			}
			c.putClientProperty(property, null);
		}

		return t;
	}

}
