// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.fx;

import java.awt.Font;

import org.pushingpixels.trident.Timeline;
import org.pushingpixels.trident.TridentConfig;
import org.pushingpixels.trident.callback.UIThreadTimelineCallbackAdapter;
import org.pushingpixels.trident.ease.Linear;
import org.pushingpixels.trident.ease.Sine;
import org.pushingpixels.trident.interpolator.PropertyInterpolator;

import org.makagiga.commons.MDisposable;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;

/**
 * @see <a href="http://www.pushing-pixels.org/category/trident">Examples</a>
 *
 * @since 3.8.6, 4.0 (org.makagiga.commons.fx package)
 */
public class MTimeline<T> extends Timeline implements MDisposable {

	// public
	
	/**
	 * @since 5.2
	 */
	public enum Ease { LINEAR, SINE }

	// public

	static {
		TridentConfig config = TridentConfig.getInstance();
		config.addPropertyInterpolator(new BooleanPropertyInterpolator());
		config.addPropertyInterpolator(new FontPropertyInterpolator(config.getPropertyInterpolator(Integer.valueOf(0))));
	}

	/**
	 * @since 5.2
	 */
	public MTimeline() { }

	public MTimeline(final T mainObject) {
		this(mainObject, 500);
	}

	public MTimeline(final T mainObject, final long duration) {
		super(mainObject);
		setDuration(duration);
	}

	@Override
	@SuppressWarnings("unchecked")
	public T getMainObject() {
		return (T)super.getMainObject();
	}

	/**
	 * @since 3.8.11
	 */
	public boolean isEnabled() {
		return enabled.get();
	}

	/**
	 * @since 5.2
	 */
	public void setEase(final Ease value) {
		switch (value) {
			case LINEAR:
				setEase(new Linear());
				break;
			case SINE:
				setEase(new Sine());
				break;
			default:
				throw new WTFError(value);
		}
	}

	/**
	 * @since 3.8.11
	 */
	public void setEnabled(final boolean value) {
		enabled.set(value);
	}
	
	// MDisposable
	
	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		setEnabled(false);
		abort();
	}

	// public classes

	/**
	 * @since 4.6
	 */
	public static class UICallback extends UIThreadTimelineCallbackAdapter {

		// public
		
		public UICallback() { }
		
		public void onDone() { }

		@Override
		public void onTimelineStateChanged(final MTimeline.TimelineState oldState, final MTimeline.TimelineState newState, final float durationFraction, final float timelinePosition) {
			if (newState == MTimeline.TimelineState.DONE)
				onDone();
		}
	
	}

	// private classes

	private static final class BooleanPropertyInterpolator implements PropertyInterpolator<Boolean> {

		// public

		@Override
		public Class<?> getBasePropertyClass() { return Boolean.class; }

		@Override
		public Boolean interpolate(final Boolean from, final Boolean to, final float timelinePosition) {
			if (timelinePosition < 1.0f)
				return from;

			return to;
		}

		// private

		private BooleanPropertyInterpolator() { }

	}

	private static final class FontPropertyInterpolator implements PropertyInterpolator<Font> {

		// private

		private final PropertyInterpolator<Integer> intInt;

		// public

		@Override
		public Class<?> getBasePropertyClass() { return Font.class; }

		@Override
		public Font interpolate(final Font from, final Font to, final float timelinePosition) {
			if (timelinePosition == 0.0f)
				return from;

			if (timelinePosition == 1.0f)
				return to;

			int size = intInt.interpolate(from.getSize(), to.getSize(), timelinePosition);

			return UI.deriveFontSize(from, size);
		}

		// private

		@SuppressWarnings("unchecked")
		private FontPropertyInterpolator(final PropertyInterpolator<?> intInt) {
			this.intInt = (PropertyInterpolator<Integer>)intInt;
		}

	}

}
