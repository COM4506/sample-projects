// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.fx;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;

import com.jhlabs.image.GaussianFilter;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.UI;

// TODO: 2.0: optimize
/**
 * A reflection effect.
 * 
 * Based on the "Swing Glint" article by Romain Guy
 * http://jroller.com/page/gfx/?anchor=swing_glint
 * 
 * @since 2.0
 */
public class Reflection {
	
	// private
	
	private boolean blur;
	private float gradientAlpha = 0.8f;
	private float reflectionSize = 0.8f;
	private int gap;
	
	// public
	
	public Reflection() { }
	
	/**
	 * Creates a cool icon.
	 *
	 * @param icon The base icon
	 */
	public MIcon createIcon(final ImageIcon icon) {
		return new MIcon(createImage(icon.getImage()));
	}

	public BufferedImage createImage(final Image image) {
		int w = image.getWidth(null);
		int h = image.getHeight(null);
		BufferedImage gradient = createGradientMask(w, (int)(h * reflectionSize));
		BufferedImage buffer = createReflection(image, w, h);
		applyAlphaMask(gradient, buffer, h);
		
		return buffer;
	}
	
	public int getGap() { return gap; }
	
	public void setGap(final int value) { gap = value; }
	
	public float getGradientAlpha() { return gradientAlpha; }
	
	public void setGradientAlpha(final float value) { gradientAlpha = value; }
	
	public float getReflectionSize() { return reflectionSize; }
	
	public void setReflectionSize(final float value) {
		if ((value < 0.1f) || (value > 1.0f))
			throw new IllegalArgumentException("\"value\" must be in range 0.1..1.0f");
		
		reflectionSize = value;
	}
	
	/**
	 * @since 2.4
	 */
	public boolean isBlur() { return blur; }

	/**
	 * @since 2.4
	 */
	public void setBlur(final boolean value) { blur = value; }
	
	// private
	
	private void applyAlphaMask(final BufferedImage gradient, final BufferedImage buffer, final int h) {
		Graphics2D g = buffer.createGraphics();
		g.setComposite(AlphaComposite.DstOut);
		g.drawImage(gradient, null, 0, h + gap);
		g.dispose();
	}
	
	private BufferedImage createGradientMask(final int w, final int h) {
		BufferedImage gradient = UI.createCompatibleImage(w, h, true);
		Graphics2D g = gradient.createGraphics();
		GradientPaint painter = new GradientPaint(
			0.0f,
			0.0f,
			new Color(1.0f, 1.0f, 1.0f, gradientAlpha),
			0.0f,
			h / 1.2f,
			new Color(1.0f, 1.0f, 1.0f, 1.0f)
		);
		g.setPaint(painter);
		g.fill(new Rectangle2D.Double(0, 0, w, h));
		g.dispose();
		gradient.flush();
		
		return gradient;
	}
	
	private BufferedImage createReflection(final Image image, final int w, final int _h) {
		int height = _h + (int)(_h * reflectionSize) + gap;
		BufferedImage buffer = UI.createCompatibleImage(w, height, true);
		Graphics2D g = buffer.createGraphics();
		g.drawImage(image, null, null);
		g.translate(0, _h * 2 + gap);
		
		AffineTransform reflectTransform = AffineTransform.getScaleInstance(1.0, -1.0);
		if (blur) {
			BufferedImage blurImage = UI.createCompatibleImage(image.getWidth(null), image.getHeight(null), true);
			Graphics2D blurG = blurImage.createGraphics();
			blurG.drawImage(image, 0, 0, null);
			blurG.dispose();
			new GaussianFilter(5).filter(blurImage, blurImage);
			g.drawImage(blurImage, reflectTransform, null);
		}
		else {
			g.drawImage(image, reflectTransform, null);
		}
		g.dispose();
		
		return buffer;
	}

}
