// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;
import javax.swing.Icon;
import javax.swing.ListCellRenderer;

import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.mv.MRenderer;

/**
 * An object with value, text, and icon.
 *
 * @see ComparableItem
 */
public class Item<T>
implements
	MIcon.Name,
	MRenderer.Renderable,
	Serializable
{
	private static final long serialVersionUID = -6126164908015747257L;
	
	// private
	
	private Icon icon;
	private static Renderer<Item<?>> sharedRenderer;
	private String text;
	transient private T value;
	
	// public
	
	/**
	 * Constructs a new item with @c null text and value.
	 */
	public Item() { }
	
	/**
	 * @since 4.0
	 */
	@SuppressWarnings("OverridableMethodCallInConstructor")
	public Item(final Icon icon) {
		setIcon(icon);
	}

	/**
	 * Constructs a new item with @c null text.
	 * @param value A value
	 */
	public Item(final T value) {
		this.value = value;
	}

	/**
	 * Constructs a new item.
	 * @param value A value
	 * @param text A text
	 */
	public Item(final T value, final String text) {
		this.value = value;
		this.text = text;
	}
	
	/**
	 * Creates and return a shared list cell renderer
	 * designed to render an @c Item object.
	 *
	 * @see #setIcon(Icon)
	 * @see #setText(String)
	 *
	 * @since 2.0
	 */
	@Obsolete
	public synchronized static ListCellRenderer<Item<?>> createListCellRenderer() {
		if (sharedRenderer == null) {
			sharedRenderer = new Renderer<>();
			UI.installLookAndFeelListener(sharedRenderer.getView());
		}
		
		return sharedRenderer;
	}

	/**
	 * Returns an icon (can be @c null).
	 *
	 * @since 2.0
	 */
	public Icon getIcon() {
		if (icon == null)
			icon = createIcon();
		
		return icon;
	}
	
	/**
	 * Sets icon to @p value (can be @c null).
	 *
	 * @since 2.0
	 */
	@InvokedFromConstructor
	public void setIcon(final Icon value) { icon = value; }

	/**
	 * @since 2.4
	 */
	@Override
	public String getIconName() {
		return MIcon.getName(icon);
	}

	/**
	 * @since 2.4
	 */
	@Override
	public void setIconName(final String value) {
		icon = MIcon.stock(value);
	}

	/**
	 * Returns a text (can be @c null).
	 */
	public String getText() { return text; }

	/**
	 * Sets text to @p value.
	 */
	public void setText(final String value) { text = value; }

	/**
	 * Returns a value (can be @c null).
	 */
	public T getValue() { return value; }

	/**
	 * Sets value to @p value.
	 */
	public void setValue(final T value) { this.value = value; }
	
	/**
	 * Returns {@code true} if value is {@code null}.
	 */
	public boolean isNull() {
		return value == null;
	}

	/**
	 * Returns {@code true} if value is non-{@code null}.
	 *
	 * @since 4.6
	 */
	public boolean isPresent() {
		return value != null;
	}

	/**
	 * @since 5.0
	 */
	public Optional<T> toOptional() {
		return Optional.ofNullable(value);
	}

	/**
	 * Returns a @c String represenation of this item
	 * (@ref text or @ref value.toString() or empty string).
	 */
	@Important
	@Override
	public String toString() {
		String t = getText();

		if (t != null)
			return t;
		
		return Objects.toString(getValue(), "");
	}

	// MRenderer.Renderable

	/**
	 * @since 3.6
	 */
	@Override
	public void setupRenderer(final MRenderer<?> r) {
		r.setIcon(getIcon());
		r.setText(toString());
	}
	
	// protected
	
	/**
	 * @since 4.0
	 */
	protected Icon createIcon() { return null; }
	
	// private
	
	// Serializable

	@SuppressWarnings("unchecked")
	private void readObject(final ObjectInputStream input) throws ClassNotFoundException, IOException {
		input.defaultReadObject();
		Object o = TK.deserialize(input, "value");
		if (o != null)
			value = (T)o;
	}

	private void writeObject(final ObjectOutputStream output) throws IOException {
		output.defaultWriteObject();
		TK.serialize(output, "value", value);
	}
	
	// public classes
	
	/**
	 * @since 3.0
	 *
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public static class Renderer<I extends Item<?>> extends MRenderer<I> {
		
		// public
		
		public Renderer() { }
		
		public Renderer(final int padding) {
			super(padding);
		}
		
	}

}
