// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * A Gregorian Calendar.
 *
 * @see MDate
 *
 * @since 3.8.11
 */
public class MCalendar extends java.util.GregorianCalendar implements Copyable<MCalendar> {

	// public
	
	/**
	 * @since 4.4
	 */
	public enum FirstDayOfWeek {
	
		// public
	
		DEFAULT,
		MONDAY,
		SUNDAY;
		
		// private
		
		private static MCalendar _default;
		
		// public

		public int get() {
			switch (this) {
				case DEFAULT: return getDefault().getFirstDayOfWeek();
				case MONDAY: return MCalendar.MONDAY;
				case SUNDAY: return MCalendar.SUNDAY;
				default: throw new WTFError(this);
			}
		}

		public void set(final MCalendar calendar) {
			calendar.setFirstDayOfWeek(get());
		}
		
		// private
		
		private synchronized MCalendar getDefault() {
			if (_default == null)
				_default = MCalendar.now();
			
			return _default;
		}

	}

	// public

	public void addDay(final int amount) {
		add(DAY_OF_MONTH, amount);
	}

	public void addHour(final int amount) {
		add(HOUR_OF_DAY, amount);
	}

	public void addHour12(final int amount) {
		add(HOUR, amount);
	}

	/**
	 * @since 4.6
	 */
	public void addMinute(final int amount) {
		add(MINUTE, amount);
	}

	/**
	 * @since 4.4
	 */
	public void addMonth(final int amount) {
		add(MONTH, amount);
	}

	/**
	 * @since 4.4
	 */
	public void addYear(final int amount) {
		add(YEAR, amount);
	}

	/**
	 * Sets hour, minute, second and millisecond of this calendar to {@code 0}.
	 *
	 * @since 4.0
	 */
	public void clearTime() {
		setHour(0);
		set(MINUTE, 0);
		set(SECOND, 0);
		set(MILLISECOND, 0);
	}

	@Override
	public MCalendar copy() {
		return (MCalendar)clone();
	}

	/**
	 * @since 4.0
	 */
	public static MCalendar date(final int year, final int month, final int day) {
		MCalendar c = new MCalendar();
		c.set(year, month - 1, day);

		return c;
	}
	
	/**
	 * Returns the day of the month (1-31).
	 */
	public int getDay() {
		return get(DAY_OF_MONTH);
	}

	/**
	 * @since 4.4
	 */
	public void setDay(final int value) {
		set(DAY_OF_MONTH, value);
	}

	/**
	 * Returns the day of the week (example: {@code FRIDAY}).
	 *
	 * @since 4.2
	 */
	public int getDayOfWeek() {
		return get(DAY_OF_WEEK);
	}

	/**
	 * @since 4.4
	 */
	public void setDayOfWeek(final int value) {
		set(DAY_OF_WEEK, value);
	}

	/**
	 * @since 5.0
	 */
	public void setDayOfWeek(final DayOfWeek value) {
		setDayOfWeek((value == DayOfWeek.SUNDAY) ? SUNDAY : (value.getValue() + 1));
	}

	/**
	 * @since 5.0
	 */
	public static String getDisplayName(final DayOfWeek day, final boolean full) {
		Locale locale = Locale.getDefault(Locale.Category.FORMAT);
		String s = day.getDisplayName(full ? TextStyle.FULL_STANDALONE : TextStyle.SHORT_STANDALONE, locale);
		if (s.equals(Integer.toString(day.getValue())))
			s = day.getDisplayName(full ? TextStyle.FULL : TextStyle.SHORT, locale);

		return s;
	}

	/**
	 * @since 5.0
	 */
	public static String getDisplayName(final Month month, final boolean full) {
		Locale locale = Locale.getDefault(Locale.Category.FORMAT);
		String s = month.getDisplayName(full ? TextStyle.FULL_STANDALONE : TextStyle.SHORT_STANDALONE, locale);
		if (s.equals(Integer.toString(month.getValue())))
			s = month.getDisplayName(full ? TextStyle.FULL : TextStyle.SHORT, locale);

		return s;
	}

	/**
	 * Returns the hour of the day (0-23).
	 */
	public int getHour() {
		return get(HOUR_OF_DAY);
	}

	/**
	 * @since 4.4
	 */
	public void setHour(final int value) {
		set(HOUR_OF_DAY, value);
	}

	/**
	 * Returns the hour of the day (0-11).
	 */
	public int getHour12() {
		return get(HOUR);
	}

	/**
	 * @since 5.0
	 */
	public int getMillisecond() {
		return get(MILLISECOND);
	}

	/**
	 * @since 5.0
	 */
	public void setMillisecond(final int value) {
		set(MILLISECOND, value);
	}

	/**
	 * Returns the minute of the hour (0-59).
	 */
	public int getMinute() {
		return get(MINUTE);
	}

	/**
	 * @since 5.0
	 */
	public void setMinute(final int value) {
		set(MINUTE, value);
	}

	/**
	 * Returns the month of the year (1-12).
	 *
	 * @deprecated As of 5.2, replaced by #toMonth
	 */
	@Deprecated
	public int getMonth() {
		return get(MONTH) + 1;
	}

	/**
	 * Sets the month of the year (1-12).
	 *
	 * @deprecated As of 5.2, replaced by #setMonth(java.time.Month)
	 */
	@Deprecated
	public void setMonth(final int value) {
		set(MONTH, value - 1);
	}
	
	/**
	 * @since 5.0
	 */
	public void setMonth(final Month value) {
		set(MONTH, value.getValue() - 1);
	}

	/**
	 * Returns the second of the minute (0-59).
	 */
	public int getSecond() {
		return get(SECOND);
	}

	/**
	 * @since 5.0
	 */
	public void setSecond(final int value) {
		set(SECOND, value);
	}

	/**
	 * @since 4.0
	 */
	public int getWeek() {
		return get(WEEK_OF_YEAR);
	}

	public int getYear() {
		return get(YEAR);
	}

	/**
	 * @since 5.0
	 */
	public void setYear(final int value) {
		set(YEAR, value);
	}

	/**
	 * @since 3.8.12
	 */
	public boolean isSameField(final java.util.Calendar other, final int... fields) {
		for (int i : fields) {
			if (this.get(i) != other.get(i))
				return false;
		}
		
		return true;
	}

	/**
	 * @since 3.8.12
	 */
	public boolean isSameDate(final java.util.Calendar other) {
		return
			(getDay() == other.get(DAY_OF_MONTH)) &&
			(this.get(MONTH) == other.get(MONTH)) &&
			(this.get(YEAR) == other.get(YEAR));
	}

	/**
	 * @since 3.8.12
	 */
	public boolean isSameTime(final java.util.Calendar other, final boolean includeMillisecond) {
		return
			(getHour() == other.get(HOUR_OF_DAY)) &&
			(this.get(MINUTE) == other.get(MINUTE)) &&
			(this.get(SECOND) == other.get(SECOND)) &&
			(
				!includeMillisecond ||
				(this.get(MILLISECOND) == other.get(MILLISECOND))
			);
	}

	public static MCalendar of(final java.util.Date date) {
		return new MCalendar(date);
	}

	/**
	 * @since 5.4
	 */
	public static MCalendar of(final LocalDate date) {
		return MCalendar.date(date.getYear(), date.getMonthValue(), date.getDayOfMonth());
	}

	/**
	 * @since 4.4
	 */
	public static MCalendar of(final long time) {
		return new MCalendar(time);
	}

	/**
	 * Returns a calendar with the current date and time.
	 */
	public static MCalendar now() {
		return new MCalendar();
	}

	public void setDate(final java.util.Calendar from) {
		setDay(from.get(DAY_OF_MONTH));
		this.set(MONTH, from.get(MONTH));
		this.set(YEAR, from.get(YEAR));
	}
	
	public void setTime(final java.util.Calendar from) {
		setTime(from, 0);
	}

	public void setTime(final java.util.Calendar from, final int millisecond) {
		setHour(from.get(HOUR_OF_DAY));
		this.set(MINUTE, from.get(MINUTE));
		this.set(SECOND, from.get(SECOND));
		this.set(MILLISECOND, millisecond);
	}

	public MDate toDate() {
		return new MDate(this);
	}

	/**
	 * @since 5.0
	 */
	public DayOfWeek toDayOfWeek() {
		int dow = getDayOfWeek();

		return DayOfWeek.of((dow == SUNDAY) ? (dow + 6) : (dow - 1));
	}

	/**
	 * @since 5.0
	 */
	public Month toMonth() {
		return Month.of(getMonth());
	}

	/**
	 * Returns a calendar with the current date and time.
	 *
	 * @since 3.8.12
	 */
	public static MCalendar today() {
		return new MCalendar();
	}

	public static MCalendar tomorrow() {
		MCalendar c = now();
		c.addDay(1);

		return c;
	}

	/**
	 * @since 3.8.12
	 */
	public static MCalendar yesterday() {
		MCalendar c = now();
		c.addDay(-1);

		return c;
	}

	// protected

	protected MCalendar() { }
	
	protected MCalendar(final java.util.Date date) {
		setTime(date);
	}

	/**
	 * @since 4.4
	 */
	protected MCalendar(final long time) {
		setTimeInMillis(time);
	}

}
