// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.security;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.util.Objects;
import javax.swing.SwingUtilities;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.UI;

/**
 * The default password authenticator.
 *
 * @mg.example
 * <pre class="brush: java">
 * MAuthenticator.init();
 * </pre>
 * 
 * @see #init()
 * @see MLoginPanel
 * 
 * @since 4.0 (org.makagiga.commons.security package)
 */
public final class MAuthenticator extends Authenticator {
	
	// private

	private static final boolean TEST = false;
	private static MAuthenticator instance;
	
	// public
	
	/**
	 * Initializes the default authenticator
	 * to the singleton instance of this class.
	 *
	 * @see #getPasswordAuthentication()
	 */
	public synchronized static void init() {
		if (instance == null) {
			instance = new MAuthenticator();
			setDefault(instance);
			if (TEST) {
				PasswordAuthentication pa = instance.doGetPasswordAuthentication();
				if (pa != null)
					MLogger.debug("core", "User=\"%s\", Password=\"%s\"", pa.getUserName(), new String(pa.getPassword()));
				System.exit(0);
			}
		}
	}
	
	// protected
	
	/**
	 * Displays the password authentication dialog.
	 *
	 * @mg.note Don't forget to use {@link #init()} first.
	 *
	 * @return {@code PasswordAuthentication} object containing user name and password
	 * @return {@code null} if dialog has been cancelled
	 *
	 * @see #init()
	 */
	@Override
	protected PasswordAuthentication getPasswordAuthentication() {
		if (SwingUtilities.isEventDispatchThread())
			return doGetPasswordAuthentication();
		
		try {
			return UI.invokeAndWait(this::doGetPasswordAuthentication);
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return null;
		}
	}
	
	// private
	
	private MAuthenticator() { }
	
	private PasswordAuthentication doGetPasswordAuthentication() {
		String url;
		if (TEST) {
			url = "https://example.com";
		}
		else {
			URL requestingURL = getRequestingURL();
			url = Objects.toString(requestingURL, "");
		}

		return MLoginPanel.getPasswordAuthentication(
			null,
			getRequestingPrompt(),
			url
		);
	}

}
