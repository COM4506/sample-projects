// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.security;

import java.util.Objects;
import java.util.function.Supplier;

import org.makagiga.commons.TK;

/**
 * @since 3.0, 4.0 (org.makagiga.commons.security package)
 */
public final class MGuardedObject<T> implements Supplier<T> {
	
	// private

	private final MGuardedObject.Permission getPermission;
	private final PermissionInfo.ThreatLevel threatLevel;
	private final String description;
	private final String name;
	private T object;
	
	// public

	/**
	 * @since 3.2
	 */
	public MGuardedObject(final T object, final String name, final PermissionInfo.ThreatLevel threatLevel, final String description) {
		this.object = Objects.requireNonNull(object, "object");
		this.name = TK.checkNullOrEmpty(name, "name");
		this.threatLevel = Objects.requireNonNull(threatLevel);
		this.description = description;
		
		this.getPermission = new MGuardedObject.Permission(name, MGuardedObject.Permission.GET_ACTION, threatLevel, description);
	}
	
	public void clear() {
		if (object != null) {
			SecurityManager sm = System.getSecurityManager();
			if (sm != null)
				sm.checkPermission(new MGuardedObject.Permission(name, MGuardedObject.Permission.CLEAR_ACTION, threatLevel, description));

			object = null;
		}
	}
	
	@Override
	public T get() {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(getPermission);
		
		return object;
	}
	
	// public classes
	
	public static final class Permission extends MPermission {
		
		// public
		
		public static final String CLEAR_ACTION = "clear";
		public static final String GET_ACTION = "get";
		
		// private

		private Permission(final String name, final String actions, final ThreatLevel threatLevel, final String description) {
			super(name, threatLevel, description);
			setActions(actions);
		}
		
	}

}
