// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.security;

import static org.makagiga.commons.UI.i18n;

import org.makagiga.commons.WTFError;

/**
 * @since 3.2, 4.0 (org.makagiga.commons.security package)
 */
public interface PermissionInfo {

	// public

	public enum ThreatLevel {
		
		// public

		UNKNOWN("ui/security-medium"),
		LOW("ui/security-high"),
		MEDIUM("ui/security-medium"),
		HIGH("ui/security-low");
		
		// private
		
		private final String iconName;
		
		// public

		/**
		 * @since 3.8.10
		 */
		public String getIconName() { return iconName; }
		
		@Override
		public String toString() {
			switch (this) {
				case UNKNOWN: return i18n("Unknown");
				case LOW: return i18n("Low");
				case MEDIUM: return i18n("Medium");
				case HIGH: return i18n("High");
				default: throw new WTFError(this);
			}
		}
		
		// private
		
		private ThreatLevel(final String iconName) {
			this.iconName = iconName;
		}

	}

	// public

	/**
	 * Returns a short, single line permission description or @c null.
	 */
	public String getPermissionDescription();

	/**
	 * Returns a non-null threat level.
	 * For @c java.io.FilePermission it would be @c ThreatLevel.HIGH, etc.
	 */
	public ThreatLevel getThreatLevel();

}
