// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.security;

import static org.makagiga.commons.UI.i18n;

import java.awt.Window;
import java.net.PasswordAuthentication;

import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.Config;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MColor;
import org.makagiga.commons.OS;
import org.makagiga.commons.TK;
import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.form.DefaultFocus;
import org.makagiga.commons.form.Field;
import org.makagiga.commons.form.Form;
import org.makagiga.commons.form.FormPanel;
import org.makagiga.commons.form.Info;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MHighlighter;
import org.makagiga.commons.swing.MPasswordField;
import org.makagiga.commons.swing.MText;
import org.makagiga.commons.swing.MTextField;

/**
 * A login panel.
 * 
 * @mg.example
 * <pre class="brush: java">
 * java.net.PasswordAuthentication pa = MLoginPanel.getPasswordAuthentication(
 *   this, // owner window for the login dialog, or null
 *   "Matrix has you"
 * );
 * if (pa != null) {
 *   ...
 * }
 * </pre>
 * 
 * @see MAuthenticator
 * 
 * @since 2.2, 4.0 (org.makagiga.commons.security package)
 */
public class MLoginPanel extends FormPanel<MLoginPanel.PasswordForm> {
	
	// public
	
	public MLoginPanel(final String prompt, final String url) {
		super(new PasswordForm(prompt, url));

		if (TK.isEmpty(getForm().prompt))
			setVisible("prompt", false);
		if (TK.isEmpty(getForm().url))
			setVisible("url", false);
		setLabel("password", i18n("Password:"));
		setLabel("url", i18n("Address:"));
		setLabel("user", i18n("User Name:"));

		MTextField urlField = getWrappedComponent("url");
		urlField.setCaretPosition(0);
// TODO: 2.0: integrate safe browsing API
		if (!getForm().url.startsWith("https://")) {
			String bg = ColorProperty.toString(MHighlighter.WARNING_COLOR);
			String fg = ColorProperty.toString(MColor.getContrastBW(MHighlighter.WARNING_COLOR));
			urlField.setStyle("background-color: " + bg + "; color: " + fg);
		}
	}

	public static PasswordAuthentication getPasswordAuthentication(final Window parent, final String prompt) {
		return getPasswordAuthentication(parent, prompt, null);
	}
	
	public static PasswordAuthentication getPasswordAuthentication(final Window parent, final String prompt, final String url) {
		MLoginPanel loginPanel = new MLoginPanel(prompt, url);
		
		MPasswordField passwordField = loginPanel.getWrappedComponent("password");
		
		MTextField userField = loginPanel.getWrappedComponent("user");
		AutoCompletion ac = MText.getAutoCompletion(userField);
		ac.addStaticItem(OS.getUserName());
		ac.addStaticItem("admin");
		
		MDialog dialog = loginPanel.createDialog(parent, i18n("Enter Password and User Name") + " - " + MApplication.getFullName(), "ui/password");
		dialog.getOKButton().setActionInfoUI(MActionInfo.LOGIN);
		dialog.packFixed();
		if (dialog.exec()) {
			PasswordForm form = loginPanel.getForm();

			Config config = Config.getDefault();
			config.write("User.name", form.user);
			config.sync();
			
			if (form.password == null)
				form.password = TK.EMPTY_CHAR_ARRAY;
			
			PasswordAuthentication result = new PasswordAuthentication(form.user, form.password);
			passwordField.clear();

			return result;
		}

		passwordField.clear();
		
		return null;
	}

	// protected classes
	
	@Form(order = "prompt,url,user,password")
	protected static final class PasswordForm {
		
		// protected
		
		@Info(type = Info.TYPE_HEADER, html = false)
		protected String prompt;
		
		@Field(readOnly = true)
		protected String url;
		
		@DefaultFocus
		@Field(autoCompletion = "user", required = true)
		protected String user;
		
		@Field
		protected char[] password;

		// protected

		protected PasswordForm(final String prompt, final String url) {
			this.prompt = prompt;
			this.url = url;
			this.user = Config.getDefault().read("User.name", null);
			if (this.user == null)
				this.user = OS.getUserName();
		}
		
	}

}
