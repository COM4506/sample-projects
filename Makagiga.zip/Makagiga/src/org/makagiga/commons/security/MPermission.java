// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.security;

import java.security.BasicPermission;
import java.util.Objects;

/**
 * @since 3.8.10
 */
public abstract class MPermission extends BasicPermission implements PermissionInfo {

	// private

	private final PermissionInfo.ThreatLevel threatLevel;
	private String actions = "";
	private final String description;

	// public

	@Override
	public String getActions() { return actions; }

	/**
	 * @since 4.6
	 */
	public String getIconName() { return null; }

	// PermissionInfo

	@Override
	public String getPermissionDescription() { return description; }

	@Override
	public PermissionInfo.ThreatLevel getThreatLevel() { return threatLevel; }

	// protected
	
	protected MPermission(final String name, final PermissionInfo.ThreatLevel threatLevel, final String description) {
		super(name);
		this.threatLevel = Objects.requireNonNull(threatLevel);
		this.description = description;
	}

	/**
	 * @since 4.4
	 */
	protected MPermission(final String name, final PermissionInfo.ThreatLevel threatLevel) {
		this(name, threatLevel, null);
	}

	/**
	 * @since 4.2
	 */
	protected MPermission(final String name) {
		this(name, ThreatLevel.UNKNOWN, null);
	}

	protected void setActions(final String actions) {
		this.actions = Objects.requireNonNull(actions);
	}

}
