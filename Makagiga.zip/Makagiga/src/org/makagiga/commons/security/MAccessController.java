// Copyright 2012 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.security;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ReflectPermission;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.concurrent.atomic.AtomicReference;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * @since 4.4
 */
public final class MAccessController {

	// public

	/**
	 * @since 5.0
	 */
	public static final ReflectPermission SUPPRESS_ACCESS_CHECKS_PERMISSION = new ReflectPermission("suppressAccessChecks");
	
	/**
	 * @since 5.0
	 */
	public static final RuntimePermission ACCESS_DECLARED_MEMBERS_PERMISSION = new RuntimePermission("accessDeclaredMembers");

	// public

	/**
	 * @since 5.0
	 */
	public static <T> T doPrivileged(final PrivilegedAction<T> action) {
		return AccessController.doPrivileged(action);
	}

	/**
	 * @since 5.0
	 */
	public static <T> T doPrivilegedException(final PrivilegedExceptionAction<T> action) throws Exception {
		try {
			return AccessController.doPrivileged(action);
		}
		catch (PrivilegedActionException exception) {
			throw exception.getException();
		}
	}

	public static void invokeAndWait(final Runnable r, final AccessControlContext acc) throws InterruptedException, InvocationTargetException {
		final AtomicReference<Throwable> error = new AtomicReference<>();
		
		UI.invokeAndWait(new Runnable() {
			@Override
			public void run() {
				try {
					AccessController.doPrivileged(new PrivilegedExceptionAction<Void>() {
						@Override
						public Void run() throws Exception {
							r.run();
						
							return null;
						}
					}, acc);
				}
				catch (PrivilegedActionException exception) {
					Throwable cause = exception.getCause();
					if (
						(cause instanceof InterruptedException) ||
						(cause instanceof InvocationTargetException)
					)
						error.set(cause);
					else
						MLogger.exception(exception);
				}
			}
		} );

		if (error.get() instanceof InterruptedException)
			throw (InterruptedException)error.get();

		if (error.get() instanceof InvocationTargetException)
			throw (InvocationTargetException)error.get();
	}

	public static void invokeLater(final Runnable r, final AccessControlContext acc) {
		UI.invokeLater(new Runnable() {
			@Override
			public void run() {
				AccessController.doPrivileged(new PrivilegedAction<Void>() {
					@Override
					public Void run() {
						r.run();
					
						return null;
					}
				}, acc);
			}
		} );
	}
	
	// private
	
	@Uninstantiable
	private MAccessController() {
		TK.uninstantiable();
	}

}
