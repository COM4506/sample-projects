// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import org.makagiga.commons.annotation.Obsolete;

/**
 * An array/list iterator utilities.
 *
 * @mg.example
 * <pre class="brush: java">
 * for (Loop&lt;String&gt; i : Loop.each("foo", "bar"))
 *   System.out.printf("%d: %s\n", i.i(), i);
 * </pre>
 *
 * @mg.output
 * <pre>
 * 0: foo
 * 1: bar
 * </pre>
 *
 * @since 3.8.6, 4.0 (org.makagiga.commons.Loop name)
 */
@Obsolete
public final class Loop<T> {

	// private

	private int i = -1;
	private final int size;
	private T v;

	// public

	/**
	 * Returns the number of items that can be iterated (remaining items).
	 * This number decreases on every iteration.
	 *
	 * @since 5.0
	 */
	public int available() {
		return (i == -1) ? size : (size - i - 1);
	}

	/**
	 * Returns an {@code Iterable} for {@code list}.
	 *
	 * @param list the list of elements to iterate
	 *
	 * @throws NullPointerException If {@code list} is {@code null}
	 */
	public static <T> Loop.Each<T> each(final List<T> list) {
		return new Each<>(list);
	}

	/**
	 * Returns an {@code Iterable} for {@code array}.
	 *
	 * @param array the array of elements to iterate
	 *
	 * @throws NullPointerException If {@code array} is {@code null}
	 */
	@SafeVarargs
	@SuppressWarnings("varargs")
	public static <T> Loop.Each<T> each(final T... array) {
		return new Each<>(array);
	}

	/**
	 * Returns the current element index ({@code 0..size() - 1}).
	 */
	public int i() { return i; }

	/**
	 * Returns {@code true} if no elements.
	 */
	public boolean isEmpty() { return size == 0; }

	/**
	 * Returns {@code true} if this is the first element ({@code i() == 0}).
	 */
	public boolean isFirst() { return i == 0; }

	/**
	 * Returns {@code true} if this is the last element ({@code i() == size() - 1}).
	 */
	public boolean isLast() { return i == size - 1; }

	/**
	 * Returns the number of elements.
	 */
	public int size() { return size; }

	/**
	 * Returns the {@code String} representation of the current element ({@code String.valueOf(v())}).
	 */
	@Override
	public String toString() {
		return String.valueOf(v);
	}

	/**
	 * Returns the current element/value.
	 */
	public T v() { return v; }
	
	// private
	
	private Loop(final int size) {
		this.size = size;
	}

	// public classes

	/**
	 * An array/list iterator.
	 */
	public static final class Each<T>
	implements
		Iterable<Loop<T>>,
		Iterator<Loop<T>>
	{

		// private

		private boolean eof;
		private int index = -1;
		private int size;
		private final List<T> list;
		private Loop<T> next;
		private T value;
		private final T[] array;

		// public

		// Iterable

		/**
		 * Returns {@code this}.
		 */
		@Override
		public Iterator<Loop<T>> iterator() { return this; }

		// Iterator

		/**
		 * Returns {@code true} if has next element.
		 */
		@Override
		public boolean hasNext() {
			if (index == -1)
				findNext();

			return !eof;
		}

		/**
		 * Returns the next element.
		 *
		 * @throws NoSuchElementException If no more elements
		 */
		@Override
		public Loop<T> next() {
			if (!hasNext())
				throw new NoSuchElementException("EOF");

			next.v = value;
			next.i = index;
			findNext();

			return next;
		}

		/**
		 * Not supported.
		 *
		 * @throws UnsupportedOperationException Always
		 */
		@Obsolete
		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}

		// private

		private Each(final List<T> list) {
			this.array = null;
			this.list = list;
			init(list.size());
		}

		@SafeVarargs
		@SuppressWarnings("varargs")
		private Each(final T... array) {
			this.array = array;
			this.list = null;
			init(array.length);
		}

		private void findNext() {
			if ((size == 0) || (index + 1 > size - 1))
				eof = true;

			if (!eof) {
				if (list != null)
					value = list.get(++index);
				else
					value = array[++index];
				eof = index == size;
			}
		}

		private void init(final int size) {
			this.size = size;
			this.next = new Loop<>(size);
			findNext();
		}

	}

}
