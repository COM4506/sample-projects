// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.text.ParseException;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

/**
 * A @c boolean property.
 *
 * @mg.example
 * <pre class="brush: java">
 * public static final BooleanProperty myProperty = new BooleanProperty();
 * ...
 * if (myProperty.get()) {
 *   ...
 * }
 * </pre>
 * 
 * @mg.note This class is <b>not</b> thread-safe.
 */
public class BooleanProperty extends Property<Boolean> {

	// public

	/**
	 * Constructs a @c boolean property.
	 * The default value is @c false.
	 */
	public BooleanProperty() {
		super(false);
	}

	/**
	 * Constructs a @c boolean property with @p value.
	 */
	public BooleanProperty(final boolean value) {
		super(value);
	}

	/**
	 * @since 4.0
	 */
	public BooleanProperty(final boolean value, final int options) {
		super(value, options);
	}

	/**
	 * Constructs a @c boolean property with @p value.
	 *
	 * @see #parse(String)
	 *
	 * @throws ParseException If @p value is @c null
	 *
	 * @since 2.0
	 */
	public BooleanProperty(final String value) throws ParseException {
		parse(value);
		setDefaultValue(get());
	}

	/**
	 * Returns {@code true} if non-{@code null} value equals {@code Boolean.TRUE}.
	 *
	 * @since 3.8.5
	 */
	public boolean booleanValue() {
		return Boolean.TRUE.equals(get());
	}
	
	/**
	 * @since 2.4
	 */
	@Override
	public Class<Boolean> getType() { return Boolean.class; }
	
	@Override
	public boolean isBooleanType() { return true; }

	/**
	 * Sets property to @c false.
	 *
	 * @see #yes()
	 * @see #toggle()
	 */
	public void no() {
		set(false);
	}

	/**
	 * Converts a @c String @p value to @c boolean.
	 *
	 * EXAMPLES:
	 * - "1" = true
	 * - "true" = true
	 * - "0" = false
	 * - "false" = false
	 * - "foo" = false
	 * - "" = false
	 *
	 * @throws ParseException If @p value is @c null
	 */
	@Override
	public void parse(final String value) throws ParseException {
		set(parseBoolean(value));
	}

	/**
	 * Converts a @c String @p value to @c boolean.
	 *
	 * EXAMPLES:
	 * - "1" = true
	 * - "true" = true
	 * - "0" = false
	 * - "false" = false
	 * - "foo" = false
	 * - "" = false
	 *
	 * @throws ParseException If @p value is @c null
	 * 
	 * @since 2.4
	 */
	@SuppressFBWarnings("LSC_LITERAL_STRING_COMPARISON")
	public static boolean parseBoolean(final String value) throws ParseException {
		if (value == null)
			throw new ParseException("\"value\" is null", 0);

		return value.equals("1") || Boolean.parseBoolean(value);
	}

	@Override
	public void read(final Config config, final String key) {
		set(config.read(key, getDefaultValue()));
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, booleanValue());
	}

	/**
	 * Negates the current boolean value (<code>true -&gt; false, false -&gt; true</code>).
	 */
	public void toggle() {
		set(!get());
	}

	/**
	 * Sets property to @c true.
	 *
	 * @see #no()
	 * @see #toggle()
	 */
	public void yes() {
		set(true);
	}

}
