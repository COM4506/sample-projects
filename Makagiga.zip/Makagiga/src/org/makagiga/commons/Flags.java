// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

/**
 * A flags.
 *
 * @mg.example
 * <pre class="brush: java">
 * Flags flags = Flags.valueOf(FLAG_A);
 * flags.isSet(FLAG_A); // true
 *
 * flags.isClear(FLAG_B); // true
 * flags.isSet(FLAG_B); // false
 * </pre>
 */
public final class Flags extends Number {

	// public

	/**
	 * @since 4.0
	 */
	public static final Flags NONE = new Flags(0);
	
	// private
	
	private static final Flags ONE = new Flags(1 << 0);
	private static final Flags TWO = new Flags(1 << 1);
	private final long value;

	// public

	@Override
	public double doubleValue() {
		return (double)value;
	}

	@Override
	public boolean equals(final Object other) {
		if (this == other)
			return true;
		
		if ((other == null) || (this.getClass() != other.getClass()))
			return false;

		return this.value == Flags.class.cast(other).value;
	}
	
	@Override
	public int hashCode() {
		return Long.hashCode(value);
	}

	@Override
	public float floatValue() {
		return (float)value;
	}

	/**
	 * @since 3.2
	 */
	@Override
	public int intValue() { return (int)value; }

	/**
	 * Returns @c true if @p value flags are @b not set.
	 */
	public boolean isClear(final long value) {
		return (this.value & value) == 0;
	}

	/**
	 * Returns @c true if @p value flags are set.
	 */
	public boolean isSet(final long value) {
		return (this.value & value) != 0;
	}

	/**
	 * @since 3.2
	 */
	@Override
	public long longValue() { return value; }

	@Override
	public String toString() {
		return
			Long.toString(value) + "L|" +
			"0x" + Long.toString(value, 16) + "|" +
			"0b" + Long.toString(value, 2);
	}

	/**
	 * @since 3.8.4
	 */
	public static Flags valueOf(final long value) {
		if (value == 0)
			return NONE;

		if (value == 1)
			return ONE;

		if (value == 2)
			return TWO;

		return new Flags(value);
	}

	// private

	private Flags(final long value) {
		this.value = value;
	}

}
