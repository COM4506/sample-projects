// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.proxy;

import static org.makagiga.commons.UI.i18n;

import java.io.IOException;
import java.net.Proxy;
import javax.swing.DefaultCellEditor;
import javax.swing.RowFilter;
import javax.swing.table.TableCellEditor;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.mv.BooleanRenderer;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.script.ScriptYourself;
import org.makagiga.commons.swing.AbstractListTableModel;
import org.makagiga.commons.swing.ActionGroup;
import org.makagiga.commons.swing.MComboBox;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MRadioButton;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.MTable;
import org.makagiga.commons.swing.MTableFilterPanel;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.commons.swing.MUndoManager;

// TODO: 2.0: reordering
/**
 * @since 2.2
 */
public class ProxyPanel extends MPanel {
	
	// private
	
	private ActionGroup actionGroup;
	private MRadioButton useCustomProxy;
	private MRadioButton useSystemProxy;
	private final Model tableModel;
	private Table table;
	
	// package
	
	boolean modified;
	
	// public

	/**
	 * @since 4.0
	 */
	public ProxyPanel() {
		super(UI.VERTICAL);
		this.tableModel = new Model(ProxyManager.getModel());
	}
	
	public void apply() {
		ProxyModel proxyModel = ProxyManager.getModel();
		proxyModel.setEnabled(useCustomProxy.isSelected());
		proxyModel.setSystem(useSystemProxy.isSelected());
		
		try {
			proxyModel.set(tableModel);
			proxyModel.write(ProxyManager.getDefaultFile());
		}
		catch (IOException exception) {
			MMessage.error(getWindowAncestor(), exception);
		}
		ProxyManager.init();
		
		modified = false;
	}

	// protected
	
	protected void deleteProxy() {
		table.deleteSelected(getWindowAncestor(), null, Model.COLUMN_ADDRESS);
	}
	
	protected void init() {
// TODO: "Test" button
		actionGroup = new ActionGroup("proxy-panel", i18n("Connection Settings"));
		actionGroup.add("new", new MAction(MActionInfo.ADD, action -> newProxy()));
		actionGroup.addSeparator();
		actionGroup.add("delete", new MAction(MActionInfo.DELETE, action -> deleteProxy()));
		
		MRadioButton noProxy = new MRadioButton(i18n("No Proxy"));
		noProxy.addActionListener(e -> {
			modified = true;
			updateComponents();
		} );
		add(noProxy);
		
		addContentGap();
		
		add(new MLabel(i18n("Connect to the Internet using Proxy Servers:")));
		
		addGap();
		
		useSystemProxy = new MRadioButton(i18n("Use system configuration"));
		useSystemProxy.addActionListener(e -> {
			modified = true;
			updateComponents();
		} );
		add(useSystemProxy);
		
		addGap();
		
		useCustomProxy = new MRadioButton(i18n("Use custom configuration:"));
		useCustomProxy.addActionListener(e -> {
			modified = true;
			updateComponents();
			if (useCustomProxy.isSelected())
				table.requestFocusInWindow();
		} );
		add(useCustomProxy);
		
		MToolBar toolBar = new MToolBar(MIcon.Size.MEDIUM);
		toolBar.setTextPosition(MToolBar.TextPosition.ALONGSIDE_ICONS);
		tableModel.undoManager.updateToolBar(toolBar);
		toolBar.addSeparator();
		actionGroup.updateToolBar(toolBar);
		ScriptYourself.install(toolBar, "proxy");
		toolBar.addStretch();
		toolBar.setOpaque(false);
		add(toolBar);
		
		table = new Table(tableModel);
		table.setAutoCreateRowSorter(true);
		table.getSelectionModel().addListSelectionListener(e -> updateActions());

		actionGroup.installPopupMenu(table, true);
		
		add(MLabel.createFor(table, i18n("Proxy Servers:")));

		addGap();

		MScrollPane scrollPane = new MScrollPane(table);
		scrollPane.setMaximumHeight(100);
		add(scrollPane);

		UI.group(noProxy, useSystemProxy, useCustomProxy);

		ProxyModel proxyModel = ProxyManager.getModel();
		if (proxyModel.isSystem())
			useSystemProxy.setSelected(true);
		else if (proxyModel.isEnabled())
			useCustomProxy.setSelected(true);
		else
			noProxy.setSelected(true);

		MTableFilterPanel filterPanel = new MTableFilterPanel(table) {
			@Override
			protected RowFilter<?, ?> createFilter() {
				return this.createFilter(Model.COLUMN_ADDRESS, Model.COLUMN_PORT, Model.COLUMN_DESCRIPTION, Model.COLUMN_TYPE);
			}
		};
		toolBar.add(filterPanel);

		updateComponents();
	}
	
	protected void newProxy() {
		ProxyInfo info = new ProxyInfo();
		info.setEnabled(true);
		tableModel.addRow(info);
		table.selectRow(table.getRowCount() - 1, true);
	}
	
	protected void updateActions() {
		tableModel.undoManager.updateUndoRedoActions(table.isEnabled());
		actionGroup.setEnabled("new", useCustomProxy.isSelected());
		actionGroup.setEnabled("delete", useCustomProxy.isSelected() && table.isSelection());
	}
	
	protected void updateComponents() {
		//useSystemProxy.setEnabled(OS.isGNOME() || OS.isWindows());
		table.setEnabled(useCustomProxy.isSelected());
		updateActions();
	}
	
	// private classes

	private static final class Model extends AbstractListTableModel<ProxyInfo> {

		// private

		private static final int COLUMN_ENABLED = 0;
		private static final int COLUMN_ADDRESS = 1;
		private static final int COLUMN_PORT = 2;
		private static final int COLUMN_DESCRIPTION = 3;
		private static final int COLUMN_TYPE = 4;
		private final MUndoManager undoManager;

		// public

		public Model(final ProxyModel proxyModel) {
			super(
				new ColumnInfo(i18n("Enabled"), Boolean.class),
				new ColumnInfo(i18n("Address"), String.class),
				new ColumnInfo(i18n("Port"), Integer.class),
				new ColumnInfo(i18n("Description"), String.class),
				new ColumnInfo(i18n("Type"), Proxy.Type.class)
			);
			for (ProxyInfo i : proxyModel)
				addRow(i);

			undoManager = new MUndoManager();
			addUndoableEditListener(undoManager);
		}

		@Override
		@SuppressFBWarnings("URV_INHERITED_METHOD_WITH_RELATED_TYPES")
		public Object getValueAt(final int rowIndex, final int columnIndex) {
			ProxyInfo info = getRowAt(rowIndex);
			switch (columnIndex) {
				case COLUMN_ENABLED:
					return info.isEnabled();
				case COLUMN_ADDRESS:
					return info.getAddress();
				case COLUMN_PORT:
					return info.getPort();
				case COLUMN_DESCRIPTION:
					return info.getDescription();
				case COLUMN_TYPE:
					return info.getType();
				default:
					throw new WTFError("Unknown proxy model column: " + columnIndex);
			}
		}

		@Override
		public void setValueAt(final Object value, final int rowIndex, final int columnIndex) {
			ProxyInfo info = getRowAt(rowIndex);
			ProxyInfo before = createCopyForUndo(info);
			switch (columnIndex) {
				case COLUMN_ENABLED:
					info.setEnabled((Boolean)value);
					break;
				case COLUMN_ADDRESS:
					info.setAddress((String)value);
					break;
				case COLUMN_PORT:
					int port = (Integer)value;
					if ((port < ProxyInfo.MIN_PORT) || (port > ProxyInfo.MAX_PORT)) {
						MMessage.error(UI.windowFor(null), String.format("Port must by in range: %d..%d", ProxyInfo.MIN_PORT, ProxyInfo.MAX_PORT));
					}
					else {
						info.setPort(port);
					}
					break;
				case COLUMN_DESCRIPTION:
					info.setDescription((String)value);
					break;
				case COLUMN_TYPE:
					info.setType((Proxy.Type)value);
					break;
				default:
					throw new WTFError("Unknown proxy model column: " + columnIndex);
			}
			fireTableCellUpdated(rowIndex, columnIndex);
			fireUndoableEditHappened(new ChangeUndo(before, createCopyForUndo(info), rowIndex));
		}
		
		// protected
		
		@Override
		protected ProxyInfo createCopyForUndo(final ProxyInfo info) {
			return info.copy();
		}

	}

	private static final class Table extends MTable<Model> {

		// public
		
		@Override
		public TableCellEditor getCellEditor(final int row, final int column) {
			int modelColumn = convertColumnIndexToModel(column);
			if (modelColumn == Model.COLUMN_TYPE) {
				int modelRow = convertRowIndexToModel(row);
				Proxy.Type type = getModel().getRowAt(modelRow).getType();
				MComboBox<Proxy.Type> typeEditor = new MComboBox<>();
				typeEditor.addItem(Proxy.Type.HTTP);
				typeEditor.addItem(Proxy.Type.SOCKS);
				typeEditor.setSelectedItem(type);
				
				return new DefaultCellEditor(typeEditor);
			}

			return super.getCellEditor(row, column);
		}

		// private
		
		private Table(final Model model) {
			super(model);
			
			MRenderer<String> stringRenderer = MRenderer.newPlainTextInstance();
			getColumnModel().getColumn(Model.COLUMN_ADDRESS).setCellRenderer(stringRenderer);
			getColumnModel().getColumn(Model.COLUMN_DESCRIPTION).setCellRenderer(stringRenderer);
			
			BooleanRenderer enabledRenderer = new BooleanRenderer();
			enabledRenderer.setAutoDisable(true);
			getColumnModel().getColumn(Model.COLUMN_ENABLED).setCellRenderer(enabledRenderer);
		}
		
	}

}
