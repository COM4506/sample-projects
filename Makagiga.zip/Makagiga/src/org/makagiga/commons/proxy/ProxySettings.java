// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.proxy;

import static org.makagiga.commons.UI.i18n;

import org.makagiga.commons.MAction;
import org.makagiga.commons.swing.MSettingsPage;

/**
 * @since 2.2
 */
public class ProxySettings extends MSettingsPage {
	
	// private
	
	private ProxyPanel panel;
	
	// public
	
	public ProxySettings() {
		super(i18n("Connection Settings"), "ui/internet");
		panel = new ProxyPanel();
	}
	
	// protected
	
	@Override
	protected void onInit() {
		panel.init();
		addCenter(panel);
	}

	@Override
	protected void onOK() {
		if (panel != null) {
			// BUG: http://sourceforge.net/p/makagiga/bugs/14/
			if (panel.modified)
				setNeedRestart(true);

			panel.apply();
			panel = null;
		}
	}
	
	// public classes
	
	/**
	 * @since 3.0
	 */
	public static final class Action extends MAction {
		
		// public
		
		public Action() {
			super(i18n("Connection Settings..."), "ui/internet");
		}
		
		@Override
		public void onAction() {
			ProxySettings page = new ProxySettings();
			page.exec(getSourceWindow());
		}
		
	}

}
