// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.proxy;

import static org.makagiga.commons.UI.i18n;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.Collections;
import java.util.List;

import org.makagiga.commons.FS;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.security.MGuardedObject;
import org.makagiga.commons.security.PermissionInfo;

/**
 * An HTTP proxy manager.
 *
 * @mg.note
 * Currently FTP proxy is not supported.
 *
 * @see <a href="http://docs.oracle.com/javase/7/docs/technotes/guides/net/proxies.html">Java Networking and Proxies</a>
 * 
 * @since 2.2
 */
public final class ProxyManager {

	// private
	
	private static boolean initDone;
	private static MGuardedObject<ProxyModel> _guardedModel;
	private static ProxySelector defaultSelector;
	
	// public
	
	public static Proxy createProxy(final Proxy.Type type, final String address, final int port) {
		if (type == Proxy.Type.DIRECT)
			return Proxy.NO_PROXY;

		try {
			return new Proxy(type, InetSocketAddress.createUnresolved(address, port));
		}
		catch (IllegalArgumentException exception) {
			MLogger.exception(exception);
			
			return Proxy.NO_PROXY;
		}
	}

	public synchronized static void disableProxy() {
		//MLogger.debug("proxy", "Setting no proxy");
		
		setSelector(null);
		
		System.clearProperty("java.net.useSystemProxies");

		System.clearProperty("http.proxyHost");
		System.clearProperty("http.proxyPort");

		System.clearProperty("https.proxyHost");
		System.clearProperty("https.proxyPort");

		System.clearProperty("socksProxyHost");
		System.clearProperty("socksProxyPort");
	}
	
	public static File getDefaultFile() {
		return FS.makeConfigFile("proxy.xml");
	}
	
	public synchronized static ProxyModel getModel() {
		if (_guardedModel == null) {
			try {
				ProxyModel pm = new ProxyModel(getDefaultFile());
				_guardedModel = new MGuardedObject<>(pm, "org.makagiga.commons.proxy.ProxyModel", PermissionInfo.ThreatLevel.HIGH, i18n("Connection Settings"));
			}
			catch (IOException exception) {
				MLogger.exception(exception);
			}
		}
		
		return _guardedModel.get();
	}
	
	public synchronized static void init() {
		ProxyModel m = getModel();
		
		if (m.isSystem()) {
			disableProxy();
			System.setProperty("java.net.useSystemProxies", "true");
			
			return;
		}
		
		if (!m.isEnabled() || (m.size() == 0)) {
			disableProxy();
			
			return;
		}
		
		List<Proxy> list = new MArrayList<>(m.size());
		for (ProxyInfo i : m) {
			if (i.isEnabled())
				list.add(i.createProxy());
		}
		if (list.isEmpty()) {
			disableProxy();
			
			return;
		}
		setSelector(new Selector(list));
	}

	// private
	
	@Uninstantiable
	private ProxyManager() {
		TK.uninstantiable();
	}
	
	private static void setSelector(final ProxySelector ps) {
		if (!initDone) {
			initDone = true;
			defaultSelector = ProxySelector.getDefault();
		}
		ProxySelector.setDefault(ps);
	}

	// private classes
	
	private static final class Selector extends ProxySelector {

		// private
		
		private int failures;
		private Proxy current;
		private final List<Proxy> noProxy;
		private final List<Proxy> proxyList;
		private final MLogger log = MLogger.get("proxy-selector");
		
		// public
		
		@Override
		public synchronized void connectFailed(final URI uri, final SocketAddress sa, final IOException ioe) {
			if (uri == null)
				throw new IllegalArgumentException("\"uri\" is null");
			
			if (sa == null)
				throw new IllegalArgumentException("\"sa\" is null");
				
			if (ioe == null)
				throw new IllegalArgumentException("\"ioe\" is null");
			
			if (current != null) {
				failures++;
				if (failures >= 5) {
					failures = 0;
					MLogger.exception(ioe);
					log.debugFormat("Proxy failed; removing from the selector: %s (%s)", current, uri);
					proxyList.remove(current);
					current = null;
				}
			}
			else {
				if (defaultSelector != null)
					defaultSelector.connectFailed(uri, sa, ioe);
			}
		}

		@Override
		public synchronized List<Proxy> select(final URI uri) {
			if (uri == null)
				throw new IllegalArgumentException("\"uri\" is null");
			
			if (proxyList.isEmpty()) {
				log.debugFormat("No proxy found: %s", uri);

				return (defaultSelector == null) ? noProxy : defaultSelector.select(uri);
			}
			
			String protocol = uri.getScheme();
			if (
				"http".equalsIgnoreCase(protocol) ||
				"https".equalsIgnoreCase(protocol) ||
				"socket".equalsIgnoreCase(protocol)
			) {
				log.debugFormat("Returning proxy list: %d (%s)", proxyList.size(), uri);
				if (current == null)
					current = next();
				
				if (current != null) {
					return Collections.singletonList(current);
				}
				else {
					log.debugFormat("No proxy found (2): %s", uri);

					return (defaultSelector == null) ? noProxy : defaultSelector.select(uri);
				}
			}
			
			log.debugFormat("Unsupported protocol: %s", uri);
			
			return (defaultSelector == null) ? noProxy : defaultSelector.select(uri);
		}
		
		// private
		
		private Selector(final List<Proxy> proxyList) {
			this.proxyList = proxyList;

			noProxy = Collections.singletonList(Proxy.NO_PROXY);
		}
		
		private Proxy next() {
			failures = 0;
			if (proxyList.isEmpty())
				current = null;
			else
				current = proxyList.get(0);

			return current;
		}

	}

}
