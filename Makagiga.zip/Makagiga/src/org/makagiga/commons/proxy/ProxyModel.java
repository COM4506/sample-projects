// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.proxy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;

import org.makagiga.commons.Config;
import org.makagiga.commons.EnumProperty;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.TK;
import org.makagiga.commons.xml.SimpleXMLReader;
import org.makagiga.commons.xml.XMLBuilder;

/**
 * @since 2.2, 4.0 (extends Object)
 */
public class ProxyModel
implements
	Iterable<ProxyInfo>,
	Serializable
{
	
	// private
	
	private boolean enabled;
	private boolean system;
	private final MArrayList<ProxyInfo> list = new MArrayList<>();
	
	// public

	/**
	 * @since 4.0
	 */
	public ProxyModel(final File file) throws IOException {
		try {
			SimpleXMLReader reader = new SimpleXMLReader() {
				private boolean inItem;
				private boolean inProxy;
				private ProxyInfo info;
				@Override
				protected void onEnd(final String name) {
					if (inProxy) {
						if (inItem && "item".equals(name)) {
							inItem = false;
							ProxyModel.this.list.add(info);
							info = null;
						}
						else if ("proxy".equals(name)) {
							inProxy = false;
						}
					}
				}
				@Override
				protected void onStart(final String name) {
					if (inItem) {
						if ("address".equals(name)) {
							info.setAddress(getValue(info.getAddress()));
							info.setPort(getIntegerAttribute("port", info.getPort()));
						}
						else if ("description".equals(name)) {
							info.setDescription(getValue());
						}
					}
					else if (inProxy && "item".equals(name)) {
						inItem = true;
						info = new ProxyInfo();
						info.setEnabled(getBooleanAttribute("enabled", info.isEnabled()));
						info.setType(EnumProperty.parse(getStringAttribute("type"), info.getType()));
					}
					else if (!inProxy && "proxy".equals(name)) {
						inProxy = true;
						ProxyModel.this.setEnabled(getBooleanAttribute("enabled", ProxyModel.this.isEnabled()));
						ProxyModel.this.setSystem(getBooleanAttribute("system", ProxyModel.this.isSystem()));
					}
				}
			};
			reader.read(file);
		}
		catch (FileNotFoundException exception) {
			// add proxy samples
			list.add(new ProxyInfo(
				"localhost",
				3128,
				"Squid - proxy caching server for web clients"
			));
		}
	}
	
	public synchronized boolean isEnabled() { return enabled; }
	
	public synchronized void setEnabled(final boolean value) { enabled = value; }

	/**
	 * @since 3.0
	 */
	public synchronized boolean isSystem() { return system; }

	/**
	 * @since 3.0
	 */
	public synchronized void setSystem(final boolean value) { system = value; }

	/**
	 * @since 4.0
	 */
	public synchronized int size() {
		return list.size();
	}

	/**
	 * @since 4.0
	 */
	public synchronized void write(final File file) throws IOException {
		XMLBuilder xml = new XMLBuilder();
		xml
		.appendComment(Config.getDefaultComment())
		.beginTag(
			"proxy",
			"enabled", enabled,
			"system", system
		);
		for (ProxyInfo i : list) {
			xml.beginTag(
				"item",
				"enabled", i.isEnabled(),
				"type", i.getType()
				//"https", i.isHTTPS()
			)
				.doubleTag("address", xml.escape(i.getAddress()), "port", i.getPort())
				.doubleTag("description", xml.escape(i.getDescription()))
			.endTag("item");
		}
		xml
		.endTag("proxy")
		.write(file);
	}

	// Iterable

	/**
	 * @since 4.0
	 */
	@Override
	public synchronized Iterator<ProxyInfo> iterator() {
		return TK.unmodifiableIterator(list.iterator());
	}
	
	// package
	
	synchronized void set(final Iterable<ProxyInfo> it) {
		list.clear();
		for (ProxyInfo i : it)
			list.add(i);
	}

}
