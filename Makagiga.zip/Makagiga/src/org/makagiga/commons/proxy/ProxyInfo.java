// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.proxy;

import java.net.Proxy;
import java.util.Objects;

import org.makagiga.commons.Copyable;
import org.makagiga.commons.TK;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.InvokedFromConstructor;

/**
 * @since 2.2
 */
public class ProxyInfo
implements
	Cloneable,
	Copyable<ProxyInfo>
{

	// public
	
	public static final int DEFAULT_PORT = 8080;
	public static final int MAX_PORT = 65535;
	public static final int MIN_PORT = 0;

	// private
	
	private boolean enabled;
	private int port;
	private Proxy.Type type;
	private String address;
	private String description;
	
	// public
	
	public ProxyInfo() {
		this("localhost", DEFAULT_PORT, null, Proxy.Type.HTTP);
	}

	public ProxyInfo(final String address, final int port, final String description) {
		this(address, port, description, Proxy.Type.HTTP);
	}
	
	public ProxyInfo(final String address, final int port, final String description, final Proxy.Type type) {
		this.description = description;
		setAddress(address);
		setPort(port);
		setType(type);
	}

	/**
	 * @deprecated As of 4.4, replaced by {@link #copy()}
	 */
	@Deprecated
	@Override
	public Object clone() {
		try {
			return super.clone();
		}
		catch (CloneNotSupportedException exception) {
			throw new WTFError(exception);
		}
	}

	public Proxy createProxy() {
		return ProxyManager.createProxy(type, address, port);
	}

	public String getAddress() { return address; }

	@InvokedFromConstructor
	public void setAddress(final String value) {
		address = Objects.requireNonNull(value);
	}

	public String getDescription() { return description; }
	
	public void setDescription(final String value) { description = value; }
	
	public int getPort() { return port; }

	@InvokedFromConstructor
	public void setPort(final int value) {
		port = TK.limit(value, MIN_PORT, MAX_PORT);
	}
	
	public Proxy.Type getType() { return type; }

	@InvokedFromConstructor
	public void setType(final Proxy.Type value) {
		type = Objects.requireNonNull(value);
	}
	
	public boolean isEnabled() { return enabled; }
	
	public void setEnabled(final boolean value) { enabled = value; }

	// Copyable
	
	/**
	 * @since 4.4
	 */
	@Override
	public ProxyInfo copy() {
		return (ProxyInfo)clone();
	}

}
