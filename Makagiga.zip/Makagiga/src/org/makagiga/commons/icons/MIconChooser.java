// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.icons;

import static org.makagiga.commons.UI.i18n;

import java.awt.Window;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.List;

import org.makagiga.commons.FS;
import org.makagiga.commons.Flags;
import org.makagiga.commons.Item;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Property;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.swing.Input;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MList;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MSearchPanel;
import org.makagiga.commons.swing.MTimer;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.icons package)
 */
public class MIconChooser extends MPanel {
	
	// public
	
	/**
	 * @since 3.0
	 */
	public static final int SHOW_BROWSE_BUTTON = 1;
	
	/**
	 * @since 3.0
	 */
	public static final int SHOW_DEFAULT_ICON = 1 << 1;

	// private
	
	private static boolean precached;
	private final HashSet<String> initSet = new HashSet<>();
	private final List<Item<String>> allIcons;
	private final MList<Item<String>> iconList;
	private final MSearchPanel searchPanel;
	private MTimer initTimer;
	
	// public
	
	public MIconChooser(final List<Item<String>> icons) {
		super(5, 5);
		allIcons = icons;
		
		MIcon initIcon = MIcon.stock("ui/noimage").getGrayscaleInstance();
		
		iconList = new MList<>();
		iconList.onTrigger((self, item) -> onSelect());
		iconList.setLayoutOrientation(MList.HORIZONTAL_WRAP);
		iconList.setSingleSelectionMode();
		iconList.setVisibleRowCount(-1); // for HORIZONTAL_WRAP
		
		// HACK: Eclipse: Cannot infer type arguments for MRenderer<>
		iconList.setCellRenderer(new MRenderer<Item<String>>(5, (renderer, value) -> {
			renderer.setText(value.getText());
			renderer.setToolTipText(value.getText());

			// for "Default Icon"
			if (value.getIcon() == null) {
				renderer.setStyle("font-style: italic");
			}
			else {
				if (MIconChooser.precached || initSet.contains(value.getValue()))
					renderer.setIcon(value.getIcon());
				else
					renderer.setIcon(initIcon);
			}
		} ));

		int iconSize = MIcon.getUISize();
		iconList.setFixedCellHeight(iconSize + 10);
		iconList.setFixedCellWidth(iconSize * 4 + 10);

		searchPanel = new MSearchPanel();
		searchPanel.onChange(e -> updateIconList(searchPanel.getText()));
		searchPanel.setList(iconList);
		addNorth(searchPanel);

		addCenter(MPanel.createVLabelPanel(iconList, i18n("Icons:")));
		
		updateIconList(null);
	}
	
	@Override
	public void addNotify() {
		super.addNotify();
		if (!precached && (initTimer == null)) {
			initTimer = MTimer.milliseconds(5, timer -> {
				initIcons();
				
				return MTimer.CONTINUE;
			} );
			initTimer.start();
		}
	}

	@Override
	public void removeNotify() {
		super.removeNotify();
		initTimer = TK.dispose(initTimer);
	}

	public static Item<String> fromList(final Window parent, final List<Item<String>> icons) {
		return fromList(parent, icons, 0);
	}
		
	/**
	 * @since 3.0
	 */
	public static Item<String> fromList(final Window parent, final List<Item<String>> icons, final int flags) {
		Flags f = Flags.valueOf(flags);
		
		int dialogFlags = MDialog.STANDARD_DIALOG | MDialog.FORCE_STANDARD_BORDER;
		if (f.isSet(SHOW_BROWSE_BUTTON))
			dialogFlags |= MDialog.USER_BUTTON;
		
		final Property<Item<String>> resultValue = new Property<>();
		
		MDialog dialog = new MDialog(parent, i18n("Choose Icon"), dialogFlags);
		dialog.onUserClick(self -> {
			File file = Input.getImageFile(self, self.getTitle());
			if (file != null) {
				String path = FS.toURL(file).toString();
				MIcon icon = MIcon.fromFileURI(path, MIcon.getUISize());
				if (icon != null) {
					Item<String> item = new Item<>(icon);
					item.setValue(path);
					resultValue.set(item);
					dialog.reject();
				}
			}
		} );
		if (f.isSet(SHOW_BROWSE_BUTTON))
			dialog.getUserButton().setActionInfoUI(MActionInfo.BROWSE);
		
		MIconChooser chooser = new MIconChooser(icons) {
			@Override
			protected void onSelect() {
				this.getDialog()
					.ifPresent(MDialog::accept);
			}
		};

		if (f.isSet(SHOW_DEFAULT_ICON)) {
			Item<String> nullIcon = new Item<>(null, i18n("Default Icon"));
			chooser.allIcons.add(0, nullIcon);
			chooser.updateIconList(null);
		}
		
		dialog.addCenter(chooser);
		dialog.setSize(UI.WindowSize.MEDIUM);
		
		if (dialog.exec(chooser.searchPanel))
			return chooser.iconList.getSelectedItem();
		
		return resultValue.get();
	}

	/**
	 * @since 4.0
	 */
	public static List<Item<String>> getStandardLabels() {
		return new MArrayList<Item<String>>(
			new Item<>(MActionInfo.ADD_STAR.getIconName(), MActionInfo.ADD_STAR.getText()),
			new Item<>("labels/valuable", i18n("Valuable")),
			new Item<>("labels/important", i18n("Important")),
			new Item<>("labels/todo", i18n("Todo")),
			new Item<>("labels/emotion/happy", i18n("Happy"))
		);
	}

	public static List<Item<String>> getStockIcons() {
		List<Item<String>> icons = new MArrayList<>(150);
		InputStream stockIndex = MIconChooser.class.getResourceAsStream("/images/stock-index.txt");
		
		if (stockIndex == null)
			return icons;

		try (BufferedReader reader = FS.newBufferedReader(stockIndex)) {
			String line;
			while ((line = reader.readLine()) != null) {
				line = line.trim();
				
				if (line.isEmpty())
					continue; // for

				String path = TK.removePrefix(line, "./"); // it's always "/" separator
				Item<String> iconItem = new Item<>(MIcon.stock(path));
				iconItem.setValue(path);
				
				String text = path.substring(path.lastIndexOf('/') + 1);
				text = TK.removeSuffix(text, ".png");
				iconItem.setText(text);
					
				icons.add(iconItem);
			}
		}
		catch (IOException exception) {
			MLogger.exception(exception);
		}
		
		return icons;
	}
	
	// protected
	
	protected void onSelect() { }
	
	/**
	 * @since 2.2
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	protected void updateIconList(final String filterText) {
		iconList.filter(searchPanel, allIcons,
			(item, unusedFilterText) -> TK.containsIgnoreCase(item.getValue(), filterText)
		);
		if (!iconList.isEmpty())
			iconList.setSelectedIndex(0);
	}
	
	// private
	
	/**
	 * Lazily load all icon images.
	 */
	private void initIcons() {
		boolean allDone = true;

		for (Item<String> i : allIcons) {
			String path = i.getValue();
			if (!initSet.contains(path)) {
				initSet.add(path);
				iconList.repaintItem(i);
				allDone = false;
				
				break; // for
			}
		}
		
		if (allDone) {
			precached = true;
			initTimer = TK.dispose(initTimer);
		}
	}
	
}
