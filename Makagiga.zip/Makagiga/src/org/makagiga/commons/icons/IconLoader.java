// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.icons;

import java.awt.Image;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Objects;

import org.makagiga.commons.FS;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.UI;
import org.makagiga.commons.security.MAccessController;

/**
 * @since 3.8.4
 */
public abstract class IconLoader {

	// private

	private int baseSize = 32;
	private int smallSize = 16;
	private final String name;

	// public
	
	/**
	 * Returns the base (original unscaled) icon size.
	 */
	public int getBaseSize() { return baseSize; }

	/**
	 * @since 3.8.9
	 */
	public MIcon getExample(final int size) {
		return load("ui/folder", size);
	}

	/**
	 * @since 3.8.9
	 */
	public String getID() { return name; }

	public int getMediumSize() {
		return getSmallSize() + 8;
	}

	/**
	 * Returns a human readable icon theme name.
	 */
	public String getName() { return name; }

	/**
	 * Unused.
	 *
	 * @deprecated As of 4.0 (final), replaced by {@link org.makagiga.commons.MIcon#getSmallSize()}
	 */
	@Deprecated
	public int getSmallSize() { return smallSize; }
	
	public abstract MIcon load(final String name, final int size);

	@Override
	public String toString() {
		return getName();
	}

	// protected

	/**
	 * @since 4.0
	 */
	protected IconLoader(final String name) {
		this.name = Objects.requireNonNull(name);
	}

	protected MIcon readIcon(final Class<?> baseClass, final String baseDir, final String name) {
		if (name == null)
			return null;

		final StringBuilder filePath = new StringBuilder(baseDir);
		filePath
			.append('/')
			.append(name);
		String ext = FS.getFileExtension(name);
		if (ext.isEmpty())
			filePath.append(".png");

		InputStream input = null;
		try {
			// do not use ImageIO for GIF animations
			if ("gif".equals(ext)) {
				return MAccessController.doPrivileged(() -> {
					URL url = baseClass.getResource(filePath.toString());

					return (url == null) ? null : (new MIcon(url));
				} );
			}
			else {
				InputStream resourceStream;
				SecurityManager sm = System.getSecurityManager();
				if (sm == null)
					resourceStream = baseClass.getResourceAsStream(filePath.toString());
				else
					resourceStream = MAccessController.doPrivileged(() -> baseClass.getResourceAsStream(filePath.toString()));

				if (resourceStream == null)
					return null;

				input = new BufferedInputStream(resourceStream);
				Image image = UI.readImage(input);

				return (image == null) ? null : (new MIcon(image));
			}
		}
		catch (IOException exception) {
			MLogger.exception(exception);

			return null;
		}
		finally {
			FS.close(input);
		}
	}
	
	/**
	 * @since 4.0
	 */
	protected void setBaseSize(final int value) { baseSize = value; }

	/**
	 * Unused.
	 *
	 * @since 4.0
	 *
	 * @deprecated Since 4.0 (final)
	 */
	@Deprecated
	protected void setSmallSize(final int value) { smallSize = value; }

}
