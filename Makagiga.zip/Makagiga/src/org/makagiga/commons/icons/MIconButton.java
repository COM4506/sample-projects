// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.icons;

import static org.makagiga.commons.UI.i18n;

import javax.swing.Icon;

import org.makagiga.commons.Item;
import org.makagiga.commons.TK;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.swing.Input;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.ValueChooser;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.icons package)
 */
public class MIconButton extends MButton implements ValueChooser<Icon> {
	
	// private

	private int iconChooserFlags;
	private String iconName;
	
	// public
	
	public MIconButton() {
		this("ui/misc");
	}
	
	public MIconButton(final String iconName) {
		super(i18n("Choose Icon..."), iconName);
		setHorizontalAlignment(CENTER);
		setHorizontalTextPosition(CENTER);
		setVerticalTextPosition(BOTTOM);

		setIconName(iconName);
	}
	
	/**
	 * @since 2.4
	 */
	@Override
	public void addValueListener(final ValueListener<Icon> l) {
		listenerList.add(ValueListener.class, l);
	}

	/**
	 * @since 2.4
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ValueListener<Icon>[] getValueListeners() {
		return listenerList.getListeners(ValueListener.class);
	}

	/**
	 * @since 2.4
	 */
	@Override
	public void removeValueListener(final ValueListener<Icon> l) {
		listenerList.remove(ValueListener.class, l);
	}

	/**
	 * @since 3.0
	 */
	public int getIconChooserFlags() { return iconChooserFlags; }

	/**
	 * @since 3.0
	 */
	public void setIconChooserFlags(final int value) { iconChooserFlags = value; }

	@Override
	public String getIconName() { return iconName; }

	@InvokedFromConstructor
	@Override
	public void setIconName(final String value) {
		iconName = value;
		super.setIconName(value);
	}

	/**
	 * @since 4.0
	 */
	@Override
	public Icon getValue() {
		return getIcon();
	}

	/**
	 * @since 4.0
	 */
	@Override
	public void setValue(final Icon value) {
		setIcon(value);
	}

	// protected

	@Override
	protected final void onClick() {
		Icon oldIcon = getValue();
		Item<String> newIcon = Input.getStockIcon(getWindowAncestor(), iconChooserFlags);
		if (newIcon != null) {
			iconName = newIcon.getValue();
			setValue(newIcon.getIcon());
			TK.fireValueChanged(this, getValueListeners(), oldIcon, getValue());
		}
	}

}
