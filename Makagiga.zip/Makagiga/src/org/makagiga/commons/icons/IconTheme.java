// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.icons;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.makagiga.commons.CollectionMap;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * <pre>
 * Non-standard Icons (do not use in plugin or standalone application):
 * - crop
 * - emptytrashcan
 * - fulltrashcan
 * - makagiga
 * - notepad
 * - sourceforgenet
 *
 * Since version 2.2:
 * - player/pause
 * - player/start
 * - ui/font
 * 
 * Since version 2.4:
 * - ui/checkspelling
 * - ui/locale
 * 
 * Since version 3.0:
 * - designer -&gt; ui/wizard
 * - desktop -&gt; ui/desktop
 * - network -&gt; ui/internet
 * - text -&gt; ui/text
 * - todo -&gt; labels/todo
 * - ui/console
 * - ui/fliphorizontal
 * - ui/flipvertical
 * - ui/plugin
 * - ui/rotateleft
 * - ui/scale
 * - ui/upload
 *
 * Since version 3.6:
 * - labels/flag-*.png
 * - labels/folder-*.png
 *
 * Since version 3.8:
 * - ui/apply
 * - ui/tree
 *
 * Since version 3.8.1:
 * - ui/first
 * - ui/last
 *
 * Since version 3.8.3:
 * - ui/grid
 *
 * Since version 3.8.7:
 * - ui/complete
 * - ui/conversation
 *
 * Since version 3.8.8:
 * - ui/help
 *
 * Since version 4.0:
 * - Removed ui/findnext
 * - Removed ui/presentation
 * - Removed ui/*arrow, ui/minus, ui/plus
 *
 * Since version 4.2:
 * - labels/folder-black
 * - labels/folder-blue
 * - labels/folder-brown
 * - text/subscript
 * - text/superscript
 * - ui/color
 * - ui/feedback
 * - ui/filter
 * - ui/random
 * - ui/tags
 *
 * Since version 4.4:
 * - ui/history
 *
 * Since version 4.6:
 * - ui/add
 * - ui/colorpicker
 * - ui/remove
 * - ui/security-high
 * - ui/security-low
 * - ui/security-medium
 * - ui/today
 *
 * Since version 4.8:
 * - ui/noimage
 *
 * Since version 5.0:
 * - ui/run
 *
 * Since version 5.2:
 * - ui/birthday
 *
 * Since version 5.4:
 * - ui/code
 *
 * Since version 5.6:
 * - ui/experimental
 * </pre>
 *
 * Icon Naming Specification:
 * http://standards.freedesktop.org/icon-naming-spec/icon-naming-spec-latest.html
 * 
 * @since 2.0
 */
public final class IconTheme {
	
	// private
	
	private static CollectionMap<String, String> aliases = new CollectionMap<>(
		CollectionMap.MapType.HASH_MAP,
		CollectionMap.CollectionType.ARRAY_LIST
	);
	private static Map<String, String> _toFreeDesktopMap;
	private static Map<String, String> _toMakagigaMap;
	private static final MLogger LOG = MLogger.get("icon-theme");
	
	// public

	/**
	 * @see <a href="http://standards.freedesktop.org/icon-theme-spec/icon-theme-spec-0.11.html">Icon Theme Specification</a>
	 */
/*
	private static List<IconLoader> find() {//!!!
		if (!OS.isLinux())
			return Collections.emptyList();

		Benchmark b = Benchmark.begin("icon-theme");
		MArrayList<IconLoader> result = new MArrayList<>();
		LinkedHashSet<String> dataDirs = new LinkedHashSet<>();
		dataDirs.add("/usr/share");
		String XDG_DATA_DIRS = System.getenv("XDG_DATA_DIRS");
		if (XDG_DATA_DIRS != null)
			dataDirs.addAll(TK.fastSplit(XDG_DATA_DIRS, ':'));
		for (String dataDir : dataDirs)
			addThemes(result, new File(dataDir, "icons"));
		b.end();

		return result;
	}
*/

	@SuppressWarnings("unchecked")
	public static Map<String, List<String>> getAliases() {
		return (Map<String, List<String>>)aliases.getMap();
	}

	public static Map<String, String> getToFreeDesktopMap() {
		init();
		
		return _toFreeDesktopMap;
	}
	
	public static Map<String, String> getToMakagigaMap() {
		init();
		
		return _toMakagigaMap;
	}
	
	public static String toMakagiga(final String context, final String name) {
		init();
		
		String path = context + "/" + name;
		String result = _toMakagigaMap.get(path);
		
		if (result == null)
			LOG.warningFormat("No icon for \"%s\"", path);
		
		return result;
	}
	
	// private
	
	@Uninstantiable
	private IconTheme() {
		TK.uninstantiable();
	}

	private static void add(final String name1, final String name2) {
		_toFreeDesktopMap.put(name2, name1);
		
		String value = _toMakagigaMap.get(name1);
		if (value != null) {
			LOG.infoFormat("Creating alias for \"%s\": %s", name1, name2);
			aliases.add(name1, name2);
		}
		else {
			_toMakagigaMap.put(name1, name2);
		}
	}
	
	private static void addAction(final String name1, final String name2) {
		add("actions/" + name1, name2);
	}

	private static void addApp(final String name1, final String name2) {
		add("apps/" + name1, name2);
	}

	private static void addCategory(final String name1, final String name2) {
		add("categories/" + name1, name2);
	}

	private static void addEmblem(final String name1, final String name2) {
		add("emblems/" + name1, name2);
	}

	private static void addEmote(final String name1, final String name2) {
		add("emotes/" + name1, name2);
	}

	private static void addMimetype(final String name1, final String name2) {
		add("mimetypes/" + name1, name2);
	}

	private static void addPlace(final String name1, final String name2) {
		add("places/" + name1, name2);
	}

	private static void addStatus(final String name1, final String name2) {
		add("status/" + name1, name2);
	}

/*
	private static void addThemes(final List<IconLoader> themes, final File baseDir) {
		LOG.debugFormat("Searching in base directory: %s", baseDir);

		for (File themeDir : FS.listFiles(baseDir, FS.DIRECTORY_FILTER)) {
			File indexFile = new File(themeDir, "index.theme");
			if (indexFile.exists()) {
				LOG.debugFormat("\tFound index.theme file in directory: %s", themeDir.getName());
				ConfigFile indexConfig = new ConfigFile(ConfigFile.Format.DESKTOP);
				try {
					indexConfig.read(indexFile);

					ConfigFile.Group iconThemeGroup = indexConfig.get("Icon Theme");
					String name = iconThemeGroup.get("Name", null);

					if ("Oxygen".equals(name)) {
						LOG.debug("\tSkipping Oxygen Icon Theme (built-in)");

						continue; // for
					}

					String directories = iconThemeGroup.get("Directories", null);
					if (directories == null) {
						LOG.warningFormat("\tSkipping icon theme w/o \"Directories\" entry: %s", name);

						continue; // for
					}

					if (iconThemeGroup.getBoolean("Hidden", false)) {
						LOG.warningFormat("\tSkipping hidden icon theme: %s", name);

						continue; // for
					}

					themes.add(new Loader(themeDir, themeDir.getPath(), name, directories, indexConfig, iconThemeGroup));
				}
				catch (IOException exception) {
					MLogger.exception(exception);
				}
			}
		}
	}
*/
	
	private synchronized static void init() {
		if (_toMakagigaMap != null)
			return;
		
		_toFreeDesktopMap = new HashMap<>();
		_toMakagigaMap = new HashMap<>();

		// actions
		
		addAction("application-exit", "ui/quit");
		addAction("arrow-down", "ui/down");
		addAction("arrow-left", "ui/left");
		addAction("arrow-right", "ui/right");
		addAction("arrow-up", "ui/up");
		addAction("arrow-up-double", "ui/upload");
		addAction("bookmark-new", "ui/bookmark");
		addAction("code-context", "ui/code");
		addAction("color-picker", "ui/colorpicker");
		addAction("download", "ui/download");
		addAction("draw-text", "ui/text");
		addAction("go-first-view", "ui/first");
		addAction("go-last-view", "ui/last");
		addAction("go-next", "ui/next");
		addAction("go-previous", "ui/previous");
		addAction("configure", "ui/configure");
		addAction("dashboard-show", "ui/desktop");
		addAction("dialog-cancel", "ui/cancel");
		addAction("dialog-close", "ui/close");
		addAction("dialog-ok", "ui/ok");
		addAction("dialog-ok-apply", "ui/apply");
		addAction("document-new", "ui/newfile");
		addAction("document-open", "ui/open");
		addAction("document-print", "ui/print");
		addAction("document-properties", "ui/properties");
		addAction("document-revert", "ui/revert");
		addAction("document-save", "ui/save");
		addAction("edit-clear-locationbar-ltr", "ui/clearright");
		addAction("edit-clear-locationbar-rtl", "ui/clearleft");
		addAction("edit-copy", "ui/copy");
		addAction("edit-cut", "ui/cut");
		addAction("edit-delete", "ui/delete");
		addAction("edit-find", "ui/find");
		addAction("edit-paste", "ui/paste");
		addAction("edit-redo", "ui/redo");
		addAction("edit-undo", "ui/undo");
		addAction("flag-black", "labels/flag-black");
		addAction("flag-blue", "labels/flag-blue");
		addAction("flag-green", "labels/flag-green");
		addAction("flag-red", "labels/flag-red");
		addAction("flag-yellow", "labels/flag-yellow");
		addAction("folder-new", "ui/newfolder");
		addAction("format-text-bold", "text/bold");
		addAction("format-text-italic", "text/italic");
		addAction("format-text-strikethrough", "text/strikethrough");
		addAction("format-text-subscript", "text/subscript");
		addAction("format-text-superscript", "text/superscript");
		addAction("format-text-underline", "text/underline");
		addAction("go-jump-today", "ui/today");
		addAction("help-contents", "ui/help");
		addAction("help-feedback", "ui/feedback");
		addAction("list-add", "ui/add");
		addAction("list-remove", "ui/remove");
		addAction("media-playback-pause", "player/pause");
		addAction("media-playback-start", "player/start");
		addAction("object-flip-horizontal", "ui/fliphorizontal");
		addAction("object-flip-vertical", "ui/flipvertical");
		addAction("object-rotate-left", "ui/rotateleft");
		addAction("object-rotate-right", "ui/rotate");
		addAction("office-chart-pie", "ui/chart");
		addAction("process-stop", "ui/stop");
		addAction("rating", "ui/star");
		addAction("roll", "ui/random");
		addAction("system-run", "ui/run");
		addAction("tools-check-spelling", "ui/checkspelling");
		addAction("tools-wizard", "ui/wizard");
		addAction("transform-crop", "crop");
		addAction("transform-scale", "ui/scale");
		addAction("view-calendar-birthday", "ui/birthday");
		addAction("view-calendar-tasks", "labels/todo");
		addAction("view-conversation-balloon", "ui/conversation");
		addAction("view-file-columns", "ui/multicolumnview");
		addAction("view-filter", "ui/filter");
		addAction("view-fullscreen", "ui/fullscreen");
		addAction("view-grid", "ui/grid");
		addAction("view-history", "ui/history");
		addAction("view-list-text", "ui/detailedview");
		addAction("view-list-tree", "ui/tree");
		addAction("view-pim-calendar", "ui/calendar");
		addAction("view-refresh", "ui/refresh");
		addAction("zoom-in", "ui/zoomin");
		addAction("zoom-out", "ui/zoomout");
		
		// apps
		
		addApp("accessories-text-editor", "notepad");
		addApp("preferences-desktop-color", "ui/color");
		addApp("preferences-desktop-font", "ui/font");
		addApp("preferences-desktop-locale", "ui/locale");
		addApp("preferences-plugin", "ui/plugin");
		addApp("utilities-terminal", "ui/console");
		
		// categories

		addCategory("applications-internet", "ui/internet");
		addCategory("applications-science", "ui/experimental");
		addCategory("applications-system", "ui/misc");
		addCategory("system-help", "ui/question");
		
		// emblems
		
		addEmblem("emblem-favorite", "labels/valuable");

		// emote
		
		addEmote("face-smile", "labels/emotion/happy");

		// mimetypes
		
		addMimetype("application-rss+xml", "ui/feed");
		addMimetype("image-x-generic", "ui/image");
		addMimetype("unknown", "labels/unknown");
		addMimetype("x-office-document", "ui/file");
		
		// places
		
		addPlace("folder", "ui/folder");
		addPlace("folder-black", "labels/folder-black");
		addPlace("folder-blue", "labels/folder-blue");
		addPlace("folder-brown", "labels/folder-brown");
		addPlace("folder-cyan", "labels/folder-cyan");
		addPlace("folder-development", "labels/folder-development");
		addPlace("folder-downloads", "labels/folder-downloads");
		addPlace("folder-favorites", "labels/folder-favorites");
		addPlace("folder-green", "labels/folder-green");
		addPlace("folder-grey", "labels/folder-grey");
		addPlace("folder-image", "labels/folder-image");
		addPlace("folder-important", "labels/folder-important");
		addPlace("folder-locked", "labels/folder-locked");
		addPlace("folder-print", "labels/folder-print");
		addPlace("folder-red", "labels/folder-red");
		addPlace("folder-remote", "labels/folder-remote");
		addPlace("folder-sound", "labels/folder-sound");
		addPlace("folder-txt", "labels/folder-txt");
		addPlace("folder-violet", "labels/folder-violet");
		addPlace("folder-yellow", "labels/folder-yellow");
		addPlace("user-home", "ui/home");
		addPlace("user-trash", "emptytrashcan");
		
		// status
		
		addStatus("dialog-error", "ui/error");
		addStatus("dialog-information", "ui/info");
		addStatus("dialog-password", "ui/password");
		addStatus("dialog-warning", "ui/warning");
		addStatus("dialog-warning", "labels/important");
		addStatus("image-missing", "ui/noimage");
		addStatus("mail-tagged", "ui/tags");
		addStatus("object-locked", "ui/locked");
		addStatus("object-unlocked", "ui/unlocked");
		addStatus("security-high", "ui/security-high");
		addStatus("security-low", "ui/security-low");
		addStatus("security-medium", "ui/security-medium");
		addStatus("task-complete", "ui/complete");
		addStatus("user-trash-full", "fulltrashcan");
	}

	// private classes

/*
	private static final class Loader extends AbstractIconLoader {

		// private

		private final File baseDir;
		private final Map<String, String> sizeMap = new HashMap<>();
		private final String comment;
		private final String example;
		private final String id;

		// public

		@Override
		public MIcon getExample(final int size) {
			if (example == null)
				return super.getExample(size);

			return load(example, size);
		}

		@Override
		public String getID() { return id; }

		@Override
		public MIcon load(final String name, final int size) {
			String freeDesktopName = IconTheme.getToFreeDesktopMap().get(name);

			if (freeDesktopName == null)
				return null;

			String sizeAsString = Integer.toString(size);
			String dirName = sizeMap.get(sizeAsString);

			if (dirName == null) {
				System.out.println("NO MAP FOR SIZE: " + size);
				return null;
			}

			int i = freeDesktopName.indexOf('/');
			System.out.printf("\"%s\"=\"%s\"\n", dirName, freeDesktopName.substring(0, i));
			if (dirName.equals(freeDesktopName.substring(0, i))) {
				File path = new File(baseDir, dirName + "/" + sizeAsString + "/" + freeDesktopName.substring(i + 1) + ".png");
				System.out.println("PATH:"+path);
				try {
					return new MIcon(ImageIO.read(path));
				}
				catch (IOException exception) {
					MLogger.exception(exception);
				}
			}

			//IconTheme.LOG.infoFormat("\t\tFreeDesktop name: %s -> %s", name, freeDesktopName);

			return null;
			//throw new UnsupportedOperationException("Not supported yet.");
		}

		@Override
		public String toString() {
			StringBuilder buf = new StringBuilder(name);
			if (!TK.isEmpty(comment))
				buf.append(" - ").append(comment);

			return buf.toString();
		}

		// private

		private Loader(final File baseDir, final String id, final String name, final String directories, final ConfigFile indexConfig, final ConfigFile.Group iconThemeGroup) {
			super(name, 48, 16);
			this.baseDir = baseDir;
			this.id = id;
			comment = iconThemeGroup.get("Comment", null);
			example = iconThemeGroup.get("Example", null);

			for (String directory : TK.fastSplit(directories, ',')) {
				ConfigFile.Group directoryGroup = indexConfig.get(directory);
				if (directoryGroup != null) {
					int dirNameIndex = directory.indexOf('/');
					if (dirNameIndex != -1) {
						if ("Fixed".equals(directoryGroup.get("Type", null))) {
							String size = directoryGroup.get("Size", null);
							if (size != null) {
								String dirName = directory.substring(0, dirNameIndex);
								IconTheme.LOG.infoFormat("\tFound size map: %s=%s", size, dirName);
								sizeMap.put(size, dirName);
							}
						}
					}
					else {
						IconTheme.LOG.warningFormat("\tUnsupported directory name: %s", directory);
					}
				}
				else {
					IconTheme.LOG.warningFormat("\tDirectory group not found: %s", directory);
				}
			}
		}

	}
*/
}
