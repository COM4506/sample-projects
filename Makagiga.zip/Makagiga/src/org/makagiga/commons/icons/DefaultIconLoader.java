// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.icons;

import java.util.List;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.mods.Mods;

/** A default icon loader. */
public class DefaultIconLoader extends IconLoader {
	
	// public

	/**
	 * Invoked from the {@link #load(String, int)} method.
	 *
	 * <ul>
	 * <li>Arg 0: {@code MIcon} - the default icon or {@code null}</li>
	 * <li>Arg 1: {@code String} - the icon name (e.g. "ui/ok")</li>
	 * <li>Arg 2: {@code int} - the icon size</li>
	 * <li>Return: {@code MIcon} instance or {@code null}</li>
	 * </ul>
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.1
	 */
	public static final String MOD_LOAD = "load@org.makagiga.commons.icons.DefaultIconLoader";
	
	// private
	
	private static IconLoader defaultIconLoader = new DefaultIconLoader("Oxygen");
	private static final MArrayList<IconLoader> userIconLoaders = new MArrayList<>();
	private static final String OXYGEN_ID = "oxygen/makagiga";
	
	// public
	
	public DefaultIconLoader(final String name) {
		super(name);
		setBaseSize(48);
	}
	
	/**
	 * @since 2.0
	 */
	public synchronized static void addUserIconLoader(final IconLoader value) {
		userIconLoaders.add(0, value);
	}

	/**
	 * @since 3.8
	 */
	public static MIcon findIcon(final String stockName, final int size) {
		// 1. try user icon loader
		for (IconLoader iconLoader : getUserIconLoaders()) {
			MIcon icon = iconLoader.load(stockName, size);

			if (icon != null)
				return icon;
		}

		// 2. try default icon loader
		return getDefaultIconLoader().load(stockName, size);
	}

	@Override
	public String getID() { return OXYGEN_ID; }

	/**
	 * @since 2.0
	 */
	public synchronized static List<IconLoader> getUserIconLoaders() { return userIconLoaders; }
	
	/**
	 * @since 4.10
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public synchronized static boolean isOxygen() {
		if (!userIconLoaders.isEmpty() && !OXYGEN_ID.equals(userIconLoaders.getFirst().getID()))
			return false;
	
		return (defaultIconLoader != null) && OXYGEN_ID.equals(defaultIconLoader.getID());
	}

	/**
	 * @since 2.0
	 */
	public synchronized static void removeUserIconLoader(final IconLoader value) {
		userIconLoaders.remove(value);
	}

	/**
	 * @since 2.0
	 */
	public synchronized static IconLoader getDefaultIconLoader() { return defaultIconLoader; }

	/**
	 * @since 2.0
	 */
	public synchronized static void setDefaultIconLoader(final IconLoader value) { defaultIconLoader = value; }
	
	@Override
	public MIcon load(final String name, final int size) {
		MIcon icon;
		if (size == MIcon.getSmallSize())
			icon = readIcon(getClass(), "/images/small", name);
		else
			icon = readIcon(getClass(), "/images", name);

		Object modIcon = Mods.exec(this, MOD_LOAD, icon, name, size);

		if (modIcon instanceof MIcon)
			return (MIcon)modIcon;

		return icon;
	}
	
}
