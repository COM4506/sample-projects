// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.autocompletion;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.AWTEventListener;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusEvent;
import java.awt.event.MouseEvent;
import java.lang.ref.WeakReference;
import java.text.BreakIterator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import javax.swing.BorderFactory;
import javax.swing.JPasswordField;
import javax.swing.Popup;
import javax.swing.PopupFactory;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.Caret;
import javax.swing.text.JTextComponent;
import javax.swing.text.Utilities;

import org.makagiga.commons.BooleanProperty;
import org.makagiga.commons.EnumProperty;
import org.makagiga.commons.FS;
import org.makagiga.commons.IntegerProperty;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.ContainerIterator;
import org.makagiga.commons.swing.MComponent;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MFrame;
import org.makagiga.commons.swing.MList;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.MSearchPanel;
import org.makagiga.commons.swing.MText;
import org.makagiga.commons.swing.MWindow;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.commons.validator.ListSelectionValidator;

public class AutoCompletion {
	
	// public
	
	public final BooleanProperty caseSensitive = new BooleanProperty();
	public final BooleanProperty consumeEnter = new BooleanProperty(true);
	public final BooleanProperty enabled = new BooleanProperty(true);
	
	/**
	 * @since 4.6
	 */
	public final BooleanProperty sorted = new BooleanProperty(true, BooleanProperty.NON_NULL);

	/**
	 * @since 4.6
	 */
	public final EnumProperty<UI.VerticalPosition> verticalPosition = new EnumProperty<>(UI.VerticalPosition.BOTTOM);
	
	/**
	 * @since 3.0
	 */
	public final IntegerProperty limit = new IntegerProperty(100);

	/**
	 * @since 5.6
	 */
	public final IntegerProperty threshold = new IntegerProperty(1, IntegerProperty.NON_NULL);

	/**
	 * @since 4.0
	 */
	public final IntegerProperty yOffset = new IntegerProperty(0);

	/**
	 * @since 3.8.8
	 */
	public static final String TEXT_COMPONENT_IN_UPDATE_PROPERTY = "org.makagiga.commons.autocompletion.AutoCompletion.TEXT_COMPONENT_IN_UPDATE_PROPERTY";
	
	public enum Mode {

		CURRENT_WORD,
		
		/**
		 * @since 3.0
		 */
		ANY_TEXT
		
	}
	
	// private
	
	private AutoCompletionData data;
	private boolean modified;
	private boolean showPopupOnUpDownKeyPress = true;
	private BreakIterator wordIterator;
	private static CompletionWindow window;
	private MArrayList<AutoCompletionData.Item> staticItems;
	private Mode mode = Mode.ANY_TEXT;
	private Renderer userRenderer;
	private final String id;
	private final WeakReference<JTextComponent> textComponentRef;
	
	// public

	/**
	 * Constructs an auto completion.
	 * @param textComponent A text component to connect with this object
	 * @param id An auto completion ID (e.g. "newfilename")
	 * @throws IllegalArgumentException If @p id is invalid
	 * @throws NullPointerException If @p textComponent is @c null
	 */
	public AutoCompletion(final JTextComponent textComponent, final String id) {
		if (textComponent instanceof JPasswordField)
			throw new IllegalArgumentException("Cannot set text auto completion for password field");

		textComponentRef = new WeakReference<>(textComponent);
		this.id = TK.validateID(id);
		install();
	}

	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public void addItem(final String text) {
		init();
		int i = data.indexOf(text);
		if (i == -1)
			data.add(text);
		else
			data.getList().get(i).usage++;
		modified = true;
	}

	/**
	 * @since 4.6
	 */
	public AutoCompletionData.Item addStaticItem(final String text) {
		AutoCompletionData.Item item = new AutoCompletionData.Item(text);
		synchronized (this) {
			if (staticItems == null)
				staticItems = new MArrayList<>();
			staticItems.add(item);
		}
		
		return item;
	}

	/**
	 * @since 5.0
	 */
	public void addStaticItemsFromText(final String text) {
		if (TK.isEmpty(text))
			return;

		if (wordIterator == null)
			wordIterator = BreakIterator.getWordInstance();

		Iterator<String> it = TK.breakIterator(wordIterator, text);
		while (it.hasNext()) {
			String s = it.next();

			// skip empty tokens
			s = s.trim();

			if (s.isEmpty())
				continue; // for

			// skip punctuation marks, etc.
			if (!Character.isLetter(s.codePointAt(0)))
				continue; // for

			addStaticItem(s);
		}
	}

	/**
	 * @since 4.10
	 */
	public AutoCompletionData.Item removeStaticItem(final String text) {
		synchronized (this) {
			if (staticItems == null)
				return null;

			Iterator<AutoCompletionData.Item> it = staticItems.iterator();
			while (it.hasNext()) {
				AutoCompletionData.Item i = it.next();
				if (i.toString().equals(text)) {
					it.remove();
					
					return i;
				}
			}
		}
		
		return null;
	}

	/**
	 * @since 3.0
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public void clear() {
		if ((data != null) && !TK.isEmpty(data.getList())) {
			data.getList().clear();
			modified = true;
			save();
		}
	}
	
	/**
	 * @since 4.6
	 */
	public synchronized void clearStaticItems() {
		if (staticItems != null)
			staticItems.clear();
	}
	
	/**
	 * @since 2.4
	 */
	public static void deletePrivateData() {
		FS.deleteFiles(FS.makeConfigFile("autocompletion"), null);
		
		// clear all text fields
		for (Frame frame : Frame.getFrames()) {
			for (JTextComponent i : ContainerIterator.findAll(frame, JTextComponent.class)) {
				AutoCompletion ac = MText.getAutoCompletion(i);
				if (ac != null)
					ac.clear();
			}
		}
	}

	/**
	 * @since 3.8.6
	 */
	public static JTextComponent getCurrentTextComponent() {
		if (window == null)
			return null;

		return window.getTextComponent();
	}
	
	/**
	 * @since 4.0
	 */
	public String getID() { return id; }
	
	public Mode getMode() { return mode; }
	
	public void setMode(final Mode value) { mode = value; }

	/**
	 * @since 3.6
	 */
	public AutoCompletion.Renderer getRenderer() { return userRenderer; }

	/**
	 * @since 3.6
	 */
	public void setRenderer(final AutoCompletion.Renderer value) { userRenderer = value; }

	/**
	 * @since 3.8.6
	 */
	public static void hidePopupWindow() {
		if (window != null) {
			window.destroy();
			window = null;
		}
	}

	/**
	 * @since 3.8.9
	 */
	public boolean getShowPopupOnUpDownKeyPress() { return showPopupOnUpDownKeyPress; }

	/**
	 * @since 3.8.9
	 */
	public void setShowPopupOnUpDownKeyPress(final boolean value) { showPopupOnUpDownKeyPress = value; }

	/**
	 * @since 5.6
	 */
	public void invokeDisabled(final Runnable code) {
		boolean oldEnabled = enabled.get();
		try {
			enabled.no();

			code.run();
		}
		finally {
			enabled.set(oldEnabled);
		}
	}

	/**
	 * @since 5.0
	 */
	public static boolean isPopupWindowVisible() {
		return window != null;
	}

	@SuppressWarnings("deprecation")
	public void save() {
		if (modified && (data != null)) {
			modified = false;
			data.save();
		}
	}
	
	// private

	private void cancel() {
		// restore original text
		if ((window != null) && (window.originalText != null)) {
			updateText(window.originalText);
		}

		hidePopupWindow();
	}

// TODO: update keyword list dynamically
	private void complete(final boolean showAll) {
		// HACK: Quaqua: popup window steals input focus
		if (UI.isQuaqua())
			return;
	
		if (!enabled.get())
			return;
		
		JTextComponent textComponent = textComponentRef.get();

		if (textComponent == null)
			return;

		if (!textComponent.isEditable())
			return;

		if (window != null)
			window.originalText = MText.isMultiline(textComponent) ? null : textComponent.getText();

		String text = null;
		switch (mode) {
			case CURRENT_WORD:
				try {
					int begin = Utilities.getWordStart(textComponent, textComponent.getCaretPosition());
					int end = Utilities.getWordEnd(textComponent, begin);
					text = textComponent.getText(begin, end - begin);
				}
				catch (BadLocationException exception) { // quiet
					text = textComponent.getText();
				}
				break;
			case ANY_TEXT:
				text = textComponent.getText();
				break;
			default:
				throw new WTFError(mode);
		}

		if (text == null)
			return;
		
		if (
			(text.length() < threshold.get(1, Integer.MAX_VALUE)) &&
			!showAll
		)
			return;

		if (!caseSensitive.get())
			text = text.toUpperCase();

		init();
		
		synchronized (this) {
			if ((data.getList() == null) && (staticItems == null))
				return;
		}

		Set<AutoCompletionData.Item> allItems =
			sorted.booleanValue()
			? new TreeSet<>()
			: new LinkedHashSet<>();
		if (data.getList() != null)
			allItems.addAll(data.getList());
		synchronized (this) {
			if (staticItems != null)
				allItems.addAll(staticItems);
		}

		MArrayList<AutoCompletionData.Item> matchList = new MArrayList<>(allItems.size());
		if (showAll) {
			matchList.addAll(allItems);
		}
		else {
			for (AutoCompletionData.Item i : allItems) {
				if (i.matches(text, caseSensitive.get(), mode))
					matchList.add(i);
			}
		}
		
		if (matchList.isEmpty()) {
			hidePopupWindow();
		}
		else {
			if (window == null)
				window = new CompletionWindow();
			window.init(this, textComponent);
			window.show(matchList);
		}
	}

	private void init() {
		if (data == null) {
			data = AutoCompletionData.load(id);
			if (data == null)
				data = new AutoCompletionData(id);
			data.max = limit.get();
		}
	}

	private void install() {
		JTextComponent textComponent = textComponentRef.get();

		if (textComponent == null)
			return;
		
		if (MText.isMultiline(textComponent)) {
			setMode(Mode.CURRENT_WORD);
			setShowPopupOnUpDownKeyPress(false);
		}
		
		MText.onChange(textComponent, e -> {
			if (
				(e.getType() == DocumentEvent.EventType.INSERT) ||
				(e.getType() == DocumentEvent.EventType.REMOVE)
			) {
				complete(false);
			}
		} );

		UI.onKeyPressed(textComponent, e -> {
			// do nothing if Shift/etc is down
			if (e.getModifiers() != 0)
				return;

			// show popup window on up/down key press
			if (showPopupOnUpDownKeyPress && (window == null) && (e.getModifiers() == 0)) {
				switch (e.getKeyCode()) {
					case VK_UP:
					case VK_DOWN:
						complete(true);
						break;
				}
			}

			if (window == null)
				return;

			switch (e.getKeyCode()) {
				case VK_ENTER:
					AutoCompletionData.Item selection = window.list.getSelectedItem();
					setText(selection);
					if ((selection != null) && consumeEnter.get())
						e.consume();
					hidePopupWindow();
					break;
				case VK_ESCAPE:
					cancel();
					e.consume();
					break;
				case VK_UP:
					window.list.selectRelativeIndex(-1, true, true);
					e.consume();
					break;
				case VK_DOWN:
					window.list.selectRelativeIndex(+1, true, true);
					e.consume();
					break;
			}
		} );
		
		textComponent.addMouseListener(new MMouseAdapter() {
			@Override
			public void mousePressed(final MouseEvent e) {
				if (window != null) {
					hidePopupWindow();
					e.consume();
				}
			}
		} );
	}
	
	private void setText(final AutoCompletionData.Item value) {
		if (value == null)
			return;
		
		JTextComponent textComponent = textComponentRef.get();

		if (textComponent == null)
			return;
		
		String text = value.text;
		try {
			enabled.no();
			switch (mode) {
				case CURRENT_WORD:
					try {
						int pos = textComponent.getCaretPosition() - 1;
						int begin = Utilities.getWordStart(textComponent, Math.max(pos, 0));
						int end = Utilities.getWordEnd(textComponent, begin);
						String part1 = textComponent.getText(begin, end - begin);
						String part2 = text.substring(part1.length());
						textComponent.getDocument().insertString(pos + 1, part2, null);
					}
					catch (BadLocationException exception) {
						MLogger.exception(exception);
					}
					break;
				case ANY_TEXT:
					updateText(text);
					break;
				default:
					throw new WTFError(mode);
			}
		}
		finally {
			enabled.yes();
		}
	}

	private void updateText(final String text) {
		JTextComponent textComponent = textComponentRef.get();

		if (textComponent == null)
			return;

		try {
			textComponent.getDocument().putProperty(TEXT_COMPONENT_IN_UPDATE_PROPERTY, true);
			textComponent.setText(text);
		}
		finally {
			textComponent.getDocument().putProperty(TEXT_COMPONENT_IN_UPDATE_PROPERTY, null);
		}
	}

	// public classes

	/**
	 * @since 3.0
	 */
	public static final class HistoryAction extends MDataAction.Weak<JTextComponent> {

		// public

		public HistoryAction(final JTextComponent textComponent) {
			super(textComponent, MActionInfo.HISTORY);
			setAuthorizationProperty(Kiosk.textAutoCompletion);
		}

		@Override
		public void onAction() {
			JTextComponent textComponent = get();
			HistoryDialog dialog = new HistoryDialog(getSourceWindow(), textComponent);
			if (dialog.exec(dialog.filter)) {
				AutoCompletionData.Item item = dialog.list.getSelectedItem();
				if (item != null) {
					textComponent.setText(item.text);
				}
			}
		}

	}

	/**
	 * @since 3.6
	 */
	@Obsolete
	@FunctionalInterface
	public static interface Renderer {

		// public

		public void onRender(final MRenderer<AutoCompletionData.Item> listRenderer, final AutoCompletionData.Item value);

	}
	
	// private classes
	
	private static class CompletionList extends MList<AutoCompletionData.Item> {

		// private

		private WeakReference<AutoCompletion.Renderer> userRendererRef;
		
		// private
		
		private CompletionList() {
			MRenderer<AutoCompletionData.Item> renderer = new MRenderer<>(1, (self, value) -> {
				self.setText(value.toString());
				AutoCompletion.Renderer userRenderer = TK.get(userRendererRef);
				if (userRenderer != null)
					userRenderer.onRender(self, value);
			} );
			renderer.setHTMLEnabled(false);
			setCellRenderer(renderer, new AutoCompletionData.Item("X"));
			setSingleSelectionMode();
			setText(AUTO_TEXT);
		}
		
	}
	
	private static final class CompletionWindow {
		
		// private

		private AWTEventListener awtListener;
		private boolean visible;
		private final CompletionList list;
		private Popup popup;
		private String originalText;
		private WeakReference<AutoCompletion> autoCompletionRef;
		private WeakReference<JTextComponent> textComponentRef;

		// private
		
		private CompletionWindow() {
			list = new CompletionList();

			list.onTrigger((self, item) -> {
				AutoCompletion autoCompletion = getAutoCompletion();
				if (autoCompletion.mode == AutoCompletion.Mode.CURRENT_WORD)
					autoCompletion.setText(item);

				AutoCompletion.hidePopupWindow();
			} );

			list.onSelect(self -> {
				AutoCompletion autoCompletion = getAutoCompletion();
				if (autoCompletion.mode != AutoCompletion.Mode.CURRENT_WORD)
					autoCompletion.setText(self.getSelectedItem());
			} );

			UI.onKeyPressed(list, e -> {
				if (e.getKeyCode() == VK_ESCAPE) {
					getAutoCompletion().cancel();
					JTextComponent textComponent = getTextComponent();
					if (textComponent != null)
						textComponent.requestFocusInWindow();
				}
			} );

			awtListener = e -> {
				// focus event
				if (e instanceof FocusEvent) {
					FocusEvent fe = (FocusEvent)e;
					if (
						(fe.getID() == FocusEvent.FOCUS_GAINED) &&
						// ignore auto completion list
						(fe.getComponent() != list)
					)
						AutoCompletion.hidePopupWindow();
				}
				// component event
				else if (e instanceof ComponentEvent) {
					ComponentEvent ce = (ComponentEvent)e;
					Component c = ce.getComponent();
					if (
						((c instanceof MDialog) || (c instanceof MFrame) || (c instanceof MWindow)) &&
						(
							(ce.getID() == ComponentEvent.COMPONENT_HIDDEN) ||
							(ce.getID() == ComponentEvent.COMPONENT_MOVED)
						)
					) {
						AutoCompletion.hidePopupWindow();
					}
				}
			};
			
			MAccessController.doPrivileged(() -> {
				Toolkit.getDefaultToolkit().addAWTEventListener(
					awtListener,
					AWTEvent.COMPONENT_EVENT_MASK | AWTEvent.FOCUS_EVENT_MASK
				);

				return null;
			} );

		}
		
		private void destroy() {
			originalText = null;
			
			// hide popup window
			if (popup != null)
				popup.hide();

			if (awtListener != null) {
				MAccessController.doPrivileged(() -> {
					Toolkit.getDefaultToolkit().removeAWTEventListener(awtListener);
				
					return null;
				} );
				awtListener = null;
			}
		}

		private AutoCompletion getAutoCompletion() {
			return autoCompletionRef.get();
		}

		private JTextComponent getTextComponent() {
			return textComponentRef.get();
		}

		private void init(final AutoCompletion autoCompletion, final JTextComponent owner) {
			autoCompletionRef = new WeakReference<>(autoCompletion);
			textComponentRef = new WeakReference<>(owner);
			list.userRendererRef = new WeakReference<>(autoCompletion.userRenderer);
		}
		
		private void show(final List<AutoCompletionData.Item> items) {
			list.clear();
			list.addAllItems(items);

			if (!visible) {
				JTextComponent owner = getTextComponent();
				boolean multiline = MText.isMultiline(owner);

				originalText = multiline ? null : owner.getText();
				
				// set location relative to the associated text component
				Point location = SwingUtilities.convertPoint(owner, new Point(), list);
				Dimension size = new Dimension();
				size.height = list.getFixedCellHeight() * Math.min(10, Math.max(list.getItemCount(), 5)) + 4;

				int lineHeight = -1;
				int magicWidth = 200;
				Caret caret = owner.getCaret();
				if (multiline && (caret instanceof Rectangle)) {
					Rectangle r = (Rectangle)caret;
					lineHeight = r.height;
					location.x += r.x;
					location.y += (r.y + r.height);
					size.width = magicWidth;
				}
				else {
					location.y += owner.getHeight();
					size.width = Math.max(owner.getWidth(), magicWidth);
				}

				// create popup content
				MScrollPane content = new MScrollPane(list, MScrollPane.NO_BORDER);
				
				// HACK: GTK uses its own border
				if (!UI.isGTK() && !UI.isRetro()) {
					Color borderColor = MColor.getContrast(UI.getBackground(list));
					content.setBorder(BorderFactory.createLineBorder(borderColor, 1));
				}
				
				AutoCompletion ac = getAutoCompletion();

				// show popup window above "owner" if outside screen
				if (
					((location.y + size.height) > UI.getScreenSize().height) ||
					(
						(ac != null) &&
						ac.verticalPosition.equalsValue(UI.VerticalPosition.TOP)
					)
				) {
					if (multiline)
						location.y -= (size.height + lineHeight);
					else
						location.y -= (size.height + owner.getHeight());
				}
				else {
					if (ac != null)
						location.y += ac.yOffset.get();
				}

				// set popup size
				MComponent.setFixedSize(content, size);
				
				// create and show popup window
				popup = PopupFactory.getSharedInstance().getPopup(owner, content, location.x, location.y);
				popup.show();
				visible = true;
			}
		}

	}

	private static final class HistoryDialog extends MDialog {

		// private

		private final AutoCompletion autoCompletion;
		private final CompletionList list;
		private final MSearchPanel filter;
		
		// protected

		@Override
		protected void onUserClick() {
			autoCompletion.clear();
			list.clear();
		}

		// private

		private HistoryDialog(final Window owner, final JTextComponent textComponent) {
			super(owner, MActionInfo.HISTORY, STANDARD_DIALOG | USER_BUTTON);

			list = new CompletionList();
			list.onTrigger((self, item) -> accept()/* simulate OK click */);

			autoCompletion = MText.getAutoCompletion(textComponent);
			autoCompletion.init(); // init data list
			if (!TK.isEmpty(autoCompletion.data.getList())) {
				list.addAllItems(autoCompletion.data.getList());
				list.sort();
				list.setSelectedIndex(0);
			}

			filter = new MSearchPanel();
			filter.onChange(e -> {
				list.filter(filter, autoCompletion.data.getList(),
					(item, filterText) -> TK.containsIgnoreCase(item.text, filterText)
				);
			} );
			filter.setList(list);

			getOKButton().setText(i18n("Insert Selected Item"));
			if (list.isEmpty())
				getUserButton().setEnabled(false);
			getUserButton().setActionInfoUI(MActionInfo.CLEAR_HISTORY);
			getValidatorSupport().add(new ListSelectionValidator(list));

			addNorth(filter);
			addCenter(MPanel.createVLabelPanel(list, i18n("Items:")));
			packFixed(UI.WindowSize.MEDIUM);
		}

	}
	
}
