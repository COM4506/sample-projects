// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.autocompletion;

import java.io.File;
import java.io.FileNotFoundException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.List;
import java.util.Objects;
import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.makagiga.commons.FS;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.xml.XMLHelper;

@XmlRootElement(name = "autocompletion")
public class AutoCompletionData {
	
	// private

	@XmlElement(name = "item") private List<Item> list;
	private String id;
	
	// package private

	@XmlTransient
	int max = 100;
	
	// public
	
	public AutoCompletionData() { }
	
	public AutoCompletionData(final String id) {
		list = new MArrayList<>();
		this.id = id;
	}

	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public void add(final String text) {
		if (TK.isEmpty(text))
			return;
		
		if (list == null)
			list = new MArrayList<>();
		list.add(new Item(text));
	}
	
	public List<Item> getList() { return list; }

	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public int indexOf(final String text) {
		if (TK.isEmpty(list))
			return -1;
		
		int count = list.size();
		for (int i = 0; i < count; i++) {
			if (list.get(i).toString().equals(text))
				return i;
		}
		
		return -1;
	}
	
	public static AutoCompletionData load(final String id) {
		if (!Kiosk.textAutoCompletion.get() || FS.isRestricted())
			return null;

		try {
			AutoCompletionData data;
			final File file = createFile(id, false);
			SecurityManager sm = System.getSecurityManager();
			if (sm == null) {
				data = XMLHelper.unmarshal(AutoCompletionData.class, file);
			}
			else {
				data = AccessController.doPrivileged(new PrivilegedExceptionAction<AutoCompletionData>() {
					@Override
					public AutoCompletionData run() throws Exception {
						return XMLHelper.unmarshal(AutoCompletionData.class, file);
					}
				} );
			}

			data.id = id;
			
			return data;
		}
		catch (FileNotFoundException exception) { // quiet
			return null;
		}
		catch (JAXBException exception) {
			MLogger.exception(exception);
			
			return null;
		}
		catch (NumberFormatException exception) { // quiet; for backward compatibility
			return null;
		}
		catch (PrivilegedActionException exception) {
			if (exception.getCause() instanceof JAXBException)
				MLogger.exception(exception);

			return null;
		}
	}
	
	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public void save() {
		if (!Kiosk.textAutoCompletion.get() || FS.isRestricted())
			return;
		
		try {
			cleanUp();
			SecurityManager sm = System.getSecurityManager();
			if (sm == null) {
				XMLHelper.marshal(this, createFile(id, true));
			}
			else {
				AccessController.doPrivileged(new PrivilegedExceptionAction<Void>() {
					@Override
					public Void run() throws Exception {
						XMLHelper.marshal(AutoCompletionData.this, createFile(id, true));

						return null;
					}
				} );
			}
		}
		catch (FileNotFoundException | JAXBException exception) {
			MLogger.exception(exception);
		}
		catch (PrivilegedActionException exception) {
			MLogger.exception(exception.getCause());
		}
	}
	
	// private
	
	private void cleanUp() {
		if (TK.isEmpty(list))
			return;
		
		if (list.size() <= max)
			return;

		// sort by usage
		list.sort(null);

		// remove unused items
		int trim = max / 2;
		while (list.size() > trim) {
			list.remove(list.size() - 1);
		}
	}
	
	private static File createFile(final String id, final boolean createDir) {
		String filePath = FS.makeConfigPath("autocompletion", createDir ? FS.CREATE_DIR : 0);
		
		return new File(filePath, id + ".xml");
	}

	// public classes
	
	public static class Item implements Comparable<Item> {

		// protected
		
		@Obsolete // private
		protected int usage = 1;
		
		@XmlAttribute protected String text;
		
		// private
		
		private String textUpperCase;
		
		// public
		
		public Item() { }
		
		public Item(final String text) {
			this.text = text;
		}
		
		@Override
		public boolean equals(final Object o) {
			if (o == this)
				return true;
			
			if (!(o instanceof Item))
				return false;
			
			return toString().equals(o.toString());
		}
		
		@Override
		public int hashCode() {
			return Objects.hashCode(text);
		}
		
		/**
		 * @since 4.6
		 */
		@XmlAttribute
		public int getUsage() { return usage; }

		/**
		 * @since 4.6
		 */
		public void setUsage(final int value) { usage = value; }

		/**
		 * @since 3.0
		 */
		public boolean matches(String textToMatch, final boolean caseSensitive, final AutoCompletion.Mode mode) {
			String thisText;
			if (caseSensitive) {
				thisText = toString();
			}
			else {
				textToMatch = textToMatch.toUpperCase();
				if (textUpperCase == null)
					textUpperCase = toString().toUpperCase();
				thisText = textUpperCase;
			}

			if (mode == AutoCompletion.Mode.ANY_TEXT) {
				return
					thisText.contains(textToMatch)
					// do not popup window if only one exact match
					&& !thisText.equals(textToMatch);
			}

			return
				(thisText.length() > textToMatch.length()) &&
				thisText.startsWith(textToMatch);
		}
		
		@Important
		@Override
		public String toString() {
			return Objects.toString(text, "");
		}
		
		// Comparable

		/**
		 * @since 3.0
		 */
		@Override
		public int compareTo(final Item item) {
			int i = Integer.compare(usage, item.usage) * -1;

			return (i == 0) ? toString().compareToIgnoreCase(item.toString()) : i;
		}

	}
	
}
