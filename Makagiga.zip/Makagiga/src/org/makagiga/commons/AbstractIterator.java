// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.IntFunction;

import org.makagiga.commons.annotation.Obsolete;

/** An abstract iterator. */
public class AbstractIterator<I>
implements
	Iterable<I>,
	Iterator<I>,
	Serializable
{

	// private

	private final IntFunction<I> getter;
	private final int count;
	private int current;

	// public
	
	/**
	 * The default constructor.
	 */
	public AbstractIterator() {
		this(0);
	}

	/**
	 * @since 3.8
	 */
	public AbstractIterator(final int count) {
		this.count = count;
		this.getter = null;
	}

	/**
	 * @since 5.6
	 */
	public AbstractIterator(final int count, final IntFunction<I> getter) {
		this.count = count;
		this.getter = getter;
	}

	/**
	 * Returns an object at {@code index}.
	 */
	public I getObjectAt(final int index) {
		if (getter != null)
			return getter.apply(index);
		
		throw new UnsupportedOperationException();
	}

	/**
	 * Returns the total number of objects.
	 */
	public int getObjectCount() { return count; }

	// Iterator

	/**
	 * Returns @c true if the next object is available.
	 */
	@Override
	public boolean hasNext() {
		return (current < getObjectCount());
	}

	/**
	 * Returns the next object.
	 * 
	 * @throws NoSuchElementException If iteration has no more elements, or if exception occured
	 */
	@Override
	public I next() {
		try {
			return getObjectAt(current);
		}
		catch (Exception exception) {
			NoSuchElementException e = new NoSuchElementException();
			e.initCause(exception);

			throw e;
		}
		finally {
			current++;
		}
	}

	/**
	 * Not used in this class.
	 * @throws UnsupportedOperationException Always
	 */
	@Obsolete
	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	// Iterable

	/**
	 * Returns {@code this}.
	 *
	 * @since 3.8.6
	 */
	@Override
	public Iterator<I> iterator() { return this; }

}
