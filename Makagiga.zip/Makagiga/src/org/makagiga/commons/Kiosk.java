// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import org.makagiga.commons.annotation.ConfigEntry;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * @since 2.0
 */
public final class Kiosk {
	
	// public

	// Kiosk

	/**
	 * @since 4.4
	 */
	@ConfigEntry("Kiosk.Action.bookmark")
	public static final BooleanProperty actionBookmark = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.Action.dragDrop")
	public static final BooleanProperty actionDragDrop = new BooleanProperty(true);

	@ConfigEntry("Kiosk.Action.export")
	public static final BooleanProperty actionExport = new BooleanProperty(true);

	@ConfigEntry("Kiosk.Action.fullScreen")
	public static final BooleanProperty actionFullScreen = new BooleanProperty(true);

	/**
	 * @since 4.12
	 */
	@ConfigEntry("Kiosk.Action.help")
	public static final BooleanProperty actionHelp = new BooleanProperty(true, BooleanProperty.NON_NULL);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.Action.internetSearch")
	public static final BooleanProperty actionInternetSearch = new BooleanProperty(true);

	@ConfigEntry("Kiosk.Action.print")
	public static final BooleanProperty actionPrint = new BooleanProperty(true);

	@ConfigEntry("Kiosk.Action.quit")
	public static final BooleanProperty actionQuit = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);

	@ConfigEntry("Kiosk.Action.settings")
	public static final BooleanProperty actionSettings = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);

	/**
	 * @since 3.4
	 */
	@ConfigEntry("Kiosk.Action.whatsThis")
	public static final BooleanProperty actionWhatsThis = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.Action.zoom")
	public static final BooleanProperty actionZoom = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.Console.enabled")
	public static final BooleanProperty consoleEnabled = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);

	@ConfigEntry("Kiosk.Link.allowOpen")
	public static final BooleanProperty linkAllowOpen = new BooleanProperty(true);

	@ConfigEntry("Kiosk.Link.extraMenu")
	public static final BooleanProperty linkExtraMenu = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.MainWindow.showMenuBar")
	public static final BooleanProperty mainWindowShowMenuBar = new BooleanProperty(true);

	/**
	 * @since 3.8.10
	 */
	@ConfigEntry("Kiosk.Notification.locked")
	public static final BooleanProperty notificationLocked = new BooleanProperty(false);

	/**
	 * @since 3.8.10
	 */
	@ConfigEntry("Kiosk.Table.columnReorderingAllowed")
	public static final BooleanProperty tableColumnReorderingAllowed = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.Plugin.manager")
	public static final BooleanProperty pluginManager = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);

	@ConfigEntry("Kiosk.Text.autoCompletion")
	public static final BooleanProperty textAutoCompletion = new BooleanProperty(true);

	@ConfigEntry("Kiosk.Text.extraMenu")
	public static final BooleanProperty textExtraMenu = new BooleanProperty(true);
	
	@ConfigEntry("Kiosk.ToolBar.locked")
	public static final BooleanProperty toolBarLocked = new BooleanProperty();

	// Script

	/**
	 * Whether or not user scripts are enabled.
	 *
	 * @since 4.0
	 */
	@ConfigEntry("Script.user")
	public static final BooleanProperty userScript = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);

	// private
	
	@Uninstantiable
	private Kiosk() {
		TK.uninstantiable();
	}

}
