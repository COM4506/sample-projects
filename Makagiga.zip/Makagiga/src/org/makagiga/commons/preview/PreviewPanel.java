// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.preview;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Objects;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.MProperties;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MTaskPanel;
import org.makagiga.commons.swing.MThrobber;
import org.makagiga.commons.transition.Transition;

/**
 * @since 2.0
 */
public class PreviewPanel extends MTaskPanel<Image> {
	
	// public
	
	/**
	 * @since 2.2
	 */
	public static final int SMALL_WIDTH = 150;

	/**
	 * @since 2.2
	 */
	public static final int MEDIUM_WIDTH = 400;
	
	// private
	
	private boolean previewEnabled = true;
	private File file;
	private int maximumHeight;
	private int width;
	private MLabel previewImage;
	private Preview preview;
	
	// public
	
	public PreviewPanel() {
		this(DefaultPreview.getInstance(), SMALL_WIDTH);
	}

	public PreviewPanel(final int width) {
		this(DefaultPreview.getInstance(), width);
	}

	public PreviewPanel(final Preview preview, final int width) {
		this.preview = Objects.requireNonNull(preview);
		this.width = width;
		
		setOpaque(false);
		setTransition(Transition.NO_TRANSITION);
		
		MThrobber throbber = getThrobber();
		throbber.setBackground(Color.WHITE);
		throbber.setForeground(Color.BLACK);
		throbber.setOpaque(true);
		
		previewImage = new MLabel();
		previewImage.setHorizontalAlignment(MLabel.CENTER);
		previewImage.setPreferredSize(new Dimension(width, width));
		previewImage.setStyle("background-color: white; color: black");
		setMainComponent(previewImage);
		
		String tip = i18n("Preview");
		previewImage.setToolTipText(tip);
		setToolTipText(tip);
	}
	
	public void clear() {
		previewImage.setIcon(null);
	}
	
	/**
	 * @since 3.0
	 */
	public int getMaximumHeight() { return maximumHeight; }

	/**
	 * @since 3.0
	 */
	public void setMaximumHeight(final int value) { maximumHeight = value; }

	public boolean isPreviewEnabled() { return previewEnabled; }
	
	public void setPreviewEnabled(final boolean value) {
		if (previewEnabled == value)
			return;
		
		previewEnabled = value;
		setVisible(value);
		if (!previewEnabled)
			cancel(true);
	}

	public void update(final File file) {
		cancel(true);
		this.file = file;
		
		if (!previewEnabled || (file == null) || !file.exists() || !file.isFile()) {
			previewImage.setIcon(null);
			
			return;
		}

		start();
	}
	
	// protected

	@Override
	protected Image doInBackground() throws Exception {
		Image image = preview.getImage(file, width, new MProperties());

		// try alternate width (e.g. other existing thumbnail)
		if (image == null) {
			for (int i : Preview.getAlternateWidth()) {
				if ((i > 0) && (i < width)) {
					image = preview.getImage(file, i, new MProperties());
					
					if (image != null)
						break; // for
				}
			}
		}
		
		return image;
	}
	
	@Override
	protected void done() {
		if (isCancelled()) {
			error();
			
			return;
		}
		
		try {
			Image image = get();
			if (image == null) {
				error();
			}
			else {
				// limit image height
				if ((maximumHeight > 0) && (image.getHeight(null) > maximumHeight)) {
					BufferedImage bi = UI.createCompatibleImage(image.getWidth(null), maximumHeight, true);
					Graphics2D g = bi.createGraphics();
					g.drawImage(image, 0, 0, null);
					g.dispose();
					image = bi;
				}
				
				previewImage.setImage(image);
				previewImage.setText(null);
			}
		}
		catch (Exception exception) {
			MLogger.exception(exception);
			error();
		}
	}
	
	protected void error() {
		previewImage.setIcon(null);
		previewImage.setText(i18n("Preview not available"));
	}
	
}
