// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.preview;

import java.awt.Image;
import java.io.File;

import org.makagiga.commons.MProperties;
import org.makagiga.commons.TK;

/**
 * @since 2.0, 4.0 (abstract class instead of interface)
 */
public abstract class Preview {

	// common properties
	
	public static final String COMMENT_PROPERTY = "comment-property";
	public static final String ICON_PROPERTY = "icon-property";
	public static final String URL_PROPERTY = "url-property";
	
	public static final String IMAGE_BPP_PROPERTY = "image-width-bpp";
	public static final String IMAGE_HEIGHT_PROPERTY = "image-height-property";
	public static final String IMAGE_TYPE_PROPERTY = "image-type-property";
	public static final String IMAGE_WIDTH_PROPERTY = "image-width-property";
	
	// private
	
	private boolean shouldScale;
	private static int[] alternateWidth = TK.EMPTY_INT_ARRAY;

	// public
	
	/**
	 * @since 4.0
	 */
	public Preview(final boolean shouldScale) {
		this.shouldScale = shouldScale;
	}

	/**
	 * @since 4.8
	 */
	public static int[] getAlternateWidth() {
		return alternateWidth.clone();
	}

	/**
	 * @since 4.8
	 */
	public static void setAlternateWidth(final int... values) {
		alternateWidth = values.clone();
	}

// TODO: String getText
	public abstract Image getImage(final File file, final int width, final MProperties properties) throws Exception;

	/**
	 * @since 4.0
	 */
	public void setShouldScale(final boolean value) { shouldScale = value; }
	
	public boolean shouldScale(final File file) { return shouldScale; }
	
}
