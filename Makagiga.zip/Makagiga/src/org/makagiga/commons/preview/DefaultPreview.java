// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Image subsampling based on the
// "On the Fly Thumbnail Creation" blog entry
// by meverett, Lime Wire LLC. <http://blog.limewire.org/?p=337>

package org.makagiga.commons.preview;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicHTML;
import javax.swing.text.View;

import org.makagiga.commons.Attributes;
import org.makagiga.commons.FS;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.MProperties;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.cache.FileCache;
import org.makagiga.commons.io.MZip;
import org.makagiga.commons.request.AbstractRequestManager;
import org.makagiga.commons.request.RequestInfo;
import org.makagiga.commons.request.RequestSource;
import org.makagiga.commons.security.MGuardedObject;
import org.makagiga.commons.security.PermissionInfo;
import org.makagiga.commons.swing.MComponent;

/**
 * @since 2.0
 */
public final class DefaultPreview extends Preview {

	// private
	
	private final Manager manager;
	private final Map<String, Preview> handlers = new ConcurrentHashMap<>();
	private final MLogger log = MLogger.get("preview");
	
	// public

	public void addHandler(final String extension, final Preview preview) {
		Objects.requireNonNull(preview);
		handlers.put(normalizeType(extension), preview);
	}

	/**
	 * @mg.warning
	 * This method is <b>not</b> thread-safe.
	 *
	 * @since 4.2
	 */
	public static Image getHTMLImage(final File file, final int width) throws Exception {
		String html = FS.read(file, "UTF8");
		
		// remove HEAD and BODY for BasicHTML
		if (html != null) {
			// HACK: preview XHTML
			html = html.replace("<html xmlns=\"http://www.w3.org/1999/xhtml\">", "<html>");
				
			// StackOverflowError: html = html.replaceFirst("<head>(\\s|\\p{Graph})*</head>", "");
			int headBegin = html.indexOf("<head>");
			if (headBegin != -1) {
				int headEnd = html.indexOf("</head>");
				if ((headEnd != -1) && (headEnd > headBegin)) {
					html =
						html.substring(0, headBegin) +
						html.substring(headEnd + "</head>".length());
				}
			}
			html = html.replaceAll("<body>|</body>", "");
		}
		
		if (BasicHTML.isHTMLString(html)) {
			final int W = width;
			final int H = width;
			
			// NOTE: use JTextComponent to avoid class cast exception
			JTextField c = new JTextField();
			MComponent.setFixedSize(c, W, H);
			View view = BasicHTML.createHTMLView(c, html);
			view.setSize(W, H);
			
			BufferedImage image = UI.createCompatibleImage(W, H, false);
			Graphics2D g = image.createGraphics();
			
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, W, H);
			Rectangle shape = new Rectangle(0, 0, W, H);
			g.setClip(shape);
			try {
				view.paint(g, shape);
			}
			catch (Exception exception) {
				MLogger.exception(exception);
			}
			finally {
				g.dispose();
			}
			
			return image;
		}
		else {
			return getTextImage(html, width);
		}
	}

	@Override
	public Image getImage(final File file, final int width, final MProperties properties) throws Exception {
		return getImage(null, file, width, properties);
	}

	private synchronized Image getImage(final Preview preview, final File file, final int width, final MProperties properties) throws Exception { // private
		properties.clear();
		
		FileCache.Group cache = FileCache.getPreviewGroup();
		
		long lastModified = file.lastModified();
		String portablePath = FS.getPortableConfigPath(file.getPath());
		String imageCacheKey = portablePath + "-" + width;
		String propertiesCacheKey = portablePath + "-" + width + "-properties";

		File propertiesCacheFile = cache.getFile(propertiesCacheKey, lastModified);
		if (propertiesCacheFile != null) {
			try {
				properties.loadUTF8(propertiesCacheFile);
				log.infoFormat("Using cached properties: %s (%s)", propertiesCacheFile.getName(), file);
			}
			catch (IOException exception) { } // quiet
		}

		File cacheFile = cache.getFile(imageCacheKey, lastModified);
		if (cacheFile != null) {
			log.infoFormat("Using cached thumbnail: %s (%s)", cacheFile.getName(), file);
		
			try (FS.BufferedFileInput input = new FS.BufferedFileInput(cacheFile)) {
				return UI.readImage(input);
			}
			catch (Exception exception) {
				MLogger.exception(exception);

				cache.remove(imageCacheKey);
			}
		}

		Preview handler = (preview == null) ? getPreview(file.toPath()) : preview;
		
		if (handler == null)
			return null;
		
		if (file.length() == 0)
			return null;

		try {
			Image result = handler.getImage(file, width, properties);
			if (result != null) {
				if (handler.shouldScale(file)) {
					result = scale(result, width);
				}
				else if (result instanceof BufferedImage) {
					if (result.getWidth(null) > width) {
						BufferedImage i = (BufferedImage)result;
						result = i.getSubimage(0, 0, width, Math.min(i.getHeight(), width));
					}
				}

				// update cache
				cacheFile = cache.newPath(imageCacheKey, lastModified, ".png").toFile();
				ImageIO.write(UI.toBufferedImage(result, true), "png", cacheFile);
			}
			// update cache
			if (!properties.isEmpty()) {
				if (propertiesCacheFile == null)
					propertiesCacheFile = cache.newPath(propertiesCacheKey, lastModified, ".properties").toFile();
				properties.setSafeStore(true);
				properties.storeUTF8(propertiesCacheFile);
			}
			
			return result;
		}
		catch (Exception exception) {
			cache.remove(imageCacheKey);
			cache.remove(propertiesCacheKey);
			
			throw exception;
		}
	}

	public static DefaultPreview getInstance() {
		return LazyDefaultPreviewHolder.INSTANCE.get();
	}

	/**
	 * @since 4.4
	 */
	public Preview getPreview(final Path path) {
		Preview preview = getPreview(FS.getFileExtension(path));
		if (preview == null) {
			try {
				String type = Files.probeContentType(path);
				if (type != null) {
					if (type.startsWith("text/"))
						preview = getPreview("TXT");
					else
						preview = getPreview(type);
				}
			}
			catch (IOException exception) {
				MLogger.exception(exception);
			}
		}
		
		return preview;
	}

	/**
	 * @since 2.2
	 */
	public Preview getPreview(final String extension) {
		if (TK.isEmpty(extension))
			return null;

		Preview preview = handlers.get(normalizeType(extension));
		if (preview == null)
			preview = handlers.get("*");
		//log.debugFormat("Preview for type \"%s\" is: %s", extension, preview);
		
		return preview;
	}

	/**
	 * @since 4.2
	 */
	public void setPreview(final File file, final int width, final Image image) throws Exception {
		Preview preview = new Preview(false) {
			@Override
			public Image getImage(final File file, final int width, final MProperties properties) { return image; }
		};
		getImage(preview, file, width, new MProperties());
	}

	public synchronized static BufferedImage getTextImage(final File file, final int width) throws Exception {
		return getTextImage(FS.read(file, "UTF8"), width);
	}

	/**
	 * @since 4.2
	 */
	public synchronized static BufferedImage getTextImage(final File file, final int width, final Font textFont) throws Exception {
		return getTextImage(FS.read(file, "UTF8"), width, textFont);
	}

	public synchronized static BufferedImage getTextImage(final String text, final int width) {
		return getTextImage(text, width, null);
	}
	
	/**
	 * @since 4.2
	 */
	public synchronized static BufferedImage getTextImage(final String text, final int width, final Font textFont) {
		if (TK.isEmpty(text))
			return null;
		
		int w = width;
		int h = width;
		BufferedImage image = UI.createCompatibleImage(w, h, false);
		Graphics2D g = image.createGraphics();
		
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);
		
		g.setFont(
			(textFont == null)
			? new Font(Font.DIALOG_INPUT, Font.PLAIN, UI.getDefaultFontSize() - 1)
			: textFont
		);
		UI.setTextAntialiasing(g, null);
		UI.paintText(
			UI.PAINT_TEXT_TRIM_LINES,
			g,
			new Rectangle(0, 0, w, h),
			null,
			Color.BLACK,
			text.split("\n") // do not use TK.fastSplit
		);
		
		g.dispose();
		
		return image;
	}

	public void removeHandler(final String extension) {
		handlers.remove(normalizeType(extension));
	}

	/**
	 * @since 3.6
	 */
	public synchronized void removePreview(final File file) {
		FileCache.Group cache = FileCache.getPreviewGroup();

		String quotedPath = Pattern.quote(FS.getPortableConfigPath(file.getPath()));
		cache.remove(Pattern.compile(quotedPath + "\\-\\d+|" + quotedPath + "\\-\\d+\\-properties"));

		// also remove the old absolute path entries
		quotedPath = Pattern.quote(file.getPath());
		cache.remove(Pattern.compile(quotedPath + "\\-\\d+|" + quotedPath + "\\-\\d+\\-properties"));
	}
	
	public synchronized RequestInfo<DefaultPreview.Result> requestPreview(final RequestSource<DefaultPreview.Result> source, final File file, final int width) {
		log.infoFormat("\"%s\" requested preview of \"%s\" (%d)", source, file, width);
		
		Attributes<String, Object> properties = new Attributes<>();
		properties.set("file", file);
		properties.set("width", width);
		
		return manager.startRequest(source, properties);
	}
	
	public synchronized static Image scale(final Image image, final int width) {
		if (image == null)
			return null;
		
		// scale image
		if (image.getWidth(null) > width) {
			BufferedImage scaledImage = UI.createCompatibleImage(width, width, true);
			Graphics2D g = scaledImage.createGraphics();
			double scale = UI.getAutoScale(image, new Dimension(width, width));
			g.scale(scale, scale);
			g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
			g.drawImage(image, 0, 0, null);
			g.dispose();
			
			return scaledImage;
		}
		
		return image;
	}

	// private
	
	private DefaultPreview() {
		super(true);
		manager = new Manager();

/* HACK: causes deadlock
		Preview htmlPreview = new Preview(false) {
			@Override
			public Image getImage(final File file, final int width, final MProperties properties) throws Exception {
				// do not parse "large" HTML files on EDT
				if (file.length() > 16 * MFormat.KB)
					return DefaultPreview.getTextImage(file, width);

				// NOTE: the preview is generated using Swing, so run it on EDT
				return UI.invokeAndWait(new Callable<Image>() {
					@Override
					public Image call() throws Exception {
						return DefaultPreview.getHTMLImage(file, width);
					}
				} );
			}
		};
		addHandler("HTM", htmlPreview);
		addHandler("HTML", htmlPreview);
*/

		Preview imagePreview = new Preview(true) {
			@Override
			public Image getImage(final File file, final int width, final MProperties properties) throws Exception {
				String type = FS.getFileExtension(file);

				if (type.isEmpty())
					return null;

				Iterator<ImageReader> it = ImageIO.getImageReadersBySuffix(type);
				BufferedImage result = null;
				ImageReader reader = it.hasNext() ? it.next() : null;
				try (ImageInputStream input = ImageIO.createImageInputStream(file)) {
					// guess image type by content
					if (reader == null) {
						it = ImageIO.getImageReaders(input);
						if (it.hasNext())
							reader = it.next();
						else
							return null;
					}
					
					reader.setInput(input);

					float factor = width * 4.2f;
					int longEdge = Math.max(reader.getHeight(0), reader.getWidth(0));
					int subSample = (int)(longEdge / factor);
					ImageReadParam readParam = reader.getDefaultReadParam();
					// subSample the image
					if (subSample > 1)
						readParam.setSourceSubsampling(subSample, subSample, 0, 0);
					result = reader.read(0, readParam);
				}
				catch (IIOException exception) {
					MLogger.exception(exception);
					
					return null;
				}
				finally {
					if (reader != null)
						reader.dispose();
				}

				if (result != null) {
					properties.setPropertyValue(IMAGE_WIDTH_PROPERTY, result.getWidth(null));
					properties.setPropertyValue(IMAGE_HEIGHT_PROPERTY, result.getHeight(null));
					properties.setPropertyValue(IMAGE_BPP_PROPERTY, result.getColorModel().getPixelSize());
					properties.setProperty(IMAGE_TYPE_PROPERTY, TK.toUpperCase(type));
				}
				
				return result;
			}
		};
		addHandler("BMP", imagePreview);
		addHandler("GIF", imagePreview);
		addHandler("JPG", imagePreview);
		addHandler("JPEG", imagePreview);
		addHandler("PNG", imagePreview);
		
		Preview textPreview = new Preview(false) {
			@Override
			public Image getImage(final File file, final int width, final MProperties properties) throws Exception {
				return DefaultPreview.getTextImage(file, width);
			}
		};
		addHandler("HTM", textPreview);
		addHandler("HTML", textPreview);
		addHandler("TXT", textPreview);

		Preview zipPreview = new Preview(false) {
			@Override
			public Image getImage(final File file, final int width, final MProperties properties) throws Exception {
				try (MZip zip = MZip.read(file)) {
					StringBuilder buf = new StringBuilder(1024);
					int count = 0;
					for (ZipEntry i : zip) {
						if (count++ == 10) {
							buf.append("(...)");
							
							break; // for
						}
						buf.append(i.getName()).append('\n');
					}
					
					return DefaultPreview.getTextImage(buf.toString(), width);
				}
			}
		};
		addHandler("JAR", zipPreview);
		addHandler("ZIP", zipPreview);
	}
	
	private String normalizeType(final String type) {
		return type.contains("/")
			? type // mime
			: TK.toUpperCase(type); // extension
	}
	
	// public classes
	
	public static final class Result {
		
		// private
		
		private final Image image;
		private final MProperties properties;
		
		// public
		
		public Image getImage() { return image; }
		
		public MProperties getProperties() { return properties; }
		
		// private
		
		private Result(final Image image, final MProperties properties) {
			this.image = image;
			this.properties = properties;
		}
		
	}

	// private classes

	private static final class LazyDefaultPreviewHolder {

		// private

		private static final MGuardedObject<DefaultPreview> INSTANCE = new MGuardedObject<>(
			new DefaultPreview(),
			"org.makagiga.commons.preview.DefaultPreview",
			PermissionInfo.ThreatLevel.LOW,
			i18n("Preview")
		);

		// private

		private LazyDefaultPreviewHolder() { }

	}
	
	private final class Manager extends AbstractRequestManager<DefaultPreview.Result> {
	
		// protected

		@Override
		protected DefaultPreview.Result getResult(final RequestInfo<DefaultPreview.Result> info) throws Exception {
			log.infoFormat("Getting preview for \"%s\"...", info.getSource());
		
			this.sleep(50);

			try {
				MProperties properties = new MProperties();
				Image image = DefaultPreview.this.getImage(
					info.getProperty("file", (File)null),
					info.getProperty("width", 0),
					properties
				);

				return new DefaultPreview.Result(image, properties);
			}
			catch (Error error) {
				MLogger.exception(error);
			
				return null;
			}
		}

		// private
		
		private Manager() {
			super(1);
			this.setThreadPriority(Thread.MIN_PRIORITY);
		}
	
	}

}
