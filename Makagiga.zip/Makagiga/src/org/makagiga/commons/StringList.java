// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import org.makagiga.commons.annotation.Obsolete;

/**
 * A list of {@code java.lang.String}s.
 * 
 * @mg.example
 * <pre class="brush: java">
 * StringList list = new StringList("foo", "bar");
 * list.sort(null);
 * </pre>
 * 
 * @mg.note This class is <b>not</b> thread-safe.
 *
 * @see MArrayList
 * 
 * @since 2.0
 */
@Obsolete
public class StringList extends MArrayList<String> {
	
	// public
	
	/**
	 * Constructs an empty list with a default initial capacity.
	 */
	public StringList() { }
	
	/**
	 * Constructs an empty list.
	 * 
	 * @param initialCapacity The initial capacity
	 * 
	 * @throws IllegalArgumentException If the @p initialCapacity is less than zero
	 */
	public StringList(final int initialCapacity) {
		super(initialCapacity);
	}
	
	/**
	 * Constructs a list with @p values.
	 * The array elements can be @c null.
	 * 
	 * @param values The array of values
	 * 
	 * @throws NullPointerException If @p values is @c null
	 *
	 * @since 2.2
	 */
	public StringList(final String... values) {
		super(values.length);
		addAll(values);
	}
	
	/**
	 * Returns a new array of list elements.
	 */
	@Obsolete // https://bugs.openjdk.java.net/browse/JDK-6260652
	@Override
	public String[] toArray() {
		return super.toArray(new String[size()]);
	}

}
