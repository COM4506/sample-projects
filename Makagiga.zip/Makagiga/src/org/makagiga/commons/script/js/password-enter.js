var Input = Java.type("org.makagiga.commons.swing.Input");
var MMessage = Java.type("org.makagiga.commons.swing.MMessage");
var UI = Java.type("org.makagiga.commons.UI");

var owner = UI.windowFor(null);
var password = Input.getPassword(owner, "Enter password to login");
if (password) {
    MMessage.error(owner, "Access Denied ;)");
}
