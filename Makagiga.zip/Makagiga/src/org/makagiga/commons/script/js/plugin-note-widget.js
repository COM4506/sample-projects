var Desktop = Java.type("org.makagiga.desktop.Desktop");
var Input = Java.type("org.makagiga.commons.swing.Input");
var MainWindow = Java.type("org.makagiga.MainWindow");
var NoteWidget = Java.type("org.makagiga.desktop.note.NoteWidget");

var desktop = MainWindow.instance.desktop;
var widget = desktop.selectedWidget;
if (widget instanceof NoteWidget) {
	new Input.GetTextBuilder()
		.editable(false)
		.multiline(true)
		.text(widget.textComponent.selectedText)
		.title("Selected Text")
		.exec();
}
