var MDialog = Java.type("org.makagiga.commons.swing.MDialog");
var MLabel = Java.type("org.makagiga.commons.swing.MLabel");
var MMessage = Java.type("org.makagiga.commons.swing.MMessage");
var UI = Java.type("org.makagiga.commons.UI");

var owner = UI.windowFor(null);
var iconName = "ui/misc";
var dialog = new MDialog(owner, "Hello Dialog", iconName);
dialog.addCenter(new MLabel("Hello Label"));
dialog.pack();
if (dialog.exec()) {
	MMessage.info(owner, "OK button clicked");
}
else {
	MMessage.warning(owner, "Cancel button clicked");
}
