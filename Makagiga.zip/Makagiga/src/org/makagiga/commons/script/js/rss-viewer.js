var FeedComponent = Java.type("org.makagiga.feeds.FeedComponent");
var MDialog = Java.type("org.makagiga.commons.swing.MDialog");
var UI = Java.type("org.makagiga.commons.UI");

var owner = UI.windowFor(null);
var iconName = "ui/feed";
var dialog = new MDialog(owner, "RSS Viewer", iconName, MDialog.SIMPLE_DIALOG);

// API: http://makagiga.sourceforge.net/api/org/makagiga/feeds/FeedComponent.html
var feed = new FeedComponent(FeedComponent.Type.COMBO_BOX_AND_VIEWER);
dialog.addCenter(feed);

// Set your RSS URL...
feed.URL = "http://makagiga.blogspot.com/feeds/posts/default?alt=rss";

dialog.setSize(UI.WindowSize.MEDIUM);
dialog.exec();
