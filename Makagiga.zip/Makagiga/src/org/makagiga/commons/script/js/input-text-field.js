var Input = Java.type("org.makagiga.commons.swing.Input");
var MMessage = Java.type("org.makagiga.commons.swing.MMessage");
var UI = Java.type("org.makagiga.commons.UI");

var owner = UI.windowFor(null);
var name = new Input.GetTextBuilder()
	.label("Name:")
	.text("?")
	.title("Enter Your Name")
	.exec(owner);

if (name)
	MMessage.info(owner, "Hello, " + name);
