var Editor = Java.type("org.makagiga.editors.Editor");
var Input = Java.type("org.makagiga.commons.swing.Input");
var JTextComponent = Java.type("javax.swing.text.JTextComponent");

var core = Editor.currentCore;
if (core instanceof JTextComponent) {
	var text = core.text;
	//var text = core.selectedText;
	var out = java.lang.System.out;
	out.println(new Input.GetTextBuilder()
		.multiline(true)
		.text(text)
		.title("Text in the active Tab")
		.exec());
}
