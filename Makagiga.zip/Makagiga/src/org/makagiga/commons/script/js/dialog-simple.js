var MDialog = Java.type("org.makagiga.commons.swing.MDialog");
var MLabel = Java.type("org.makagiga.commons.swing.MLabel");
var UI = Java.type("org.makagiga.commons.UI");

var owner = UI.windowFor(null);
var dialog = new MDialog(owner, "Hello Dialog", MDialog.SIMPLE_DIALOG);
dialog.addCenter(new MLabel("Hello Label"));
dialog.pack();
dialog.exec();
