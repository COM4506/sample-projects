var Input = Java.type("org.makagiga.commons.swing.Input");
var MMessage = Java.type("org.makagiga.commons.swing.MMessage");
var UI = Java.type("org.makagiga.commons.UI");

var text = new Input.GetTextBuilder()
	.multiline(true)
	.text("Hello\nWorld!")
	.title("Enter Your Text")
	.exec();

if (text)
	MMessage.info(UI.windowFor(null), text);
