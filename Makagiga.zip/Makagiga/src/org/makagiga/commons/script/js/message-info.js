var MMessage = Java.type("org.makagiga.commons.swing.MMessage");
var UI = Java.type("org.makagiga.commons.UI");

MMessage.info(UI.windowFor(null), "Hello :)");
