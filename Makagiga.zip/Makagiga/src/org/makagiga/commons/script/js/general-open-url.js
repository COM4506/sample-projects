var MApplication = Java.type("org.makagiga.commons.MApplication");

MApplication.openURI("http://example.com");
