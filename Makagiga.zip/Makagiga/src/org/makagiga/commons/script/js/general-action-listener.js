var MButton = Java.type("org.makagiga.commons.swing.MButton");
var MDialog = Java.type("org.makagiga.commons.swing.MDialog");
var UI = Java.type("org.makagiga.commons.UI");

var owner = UI.windowFor(null);
var dialog = new MDialog(owner, "Test", MDialog.SIMPLE_DIALOG);

var clickCount = 0;
var button = new MButton("Click Me!");
button.addActionListener(function(e) {
	var text = "OK!";
	if (clickCount > 0) {
		for (var i = 0; i < clickCount; i++)
			text += '.';
	}
	else {
		e.source.iconName = "ui/ok";
	}

	e.source.text = text;
	clickCount++;
} );

dialog.addCenter(button);
dialog.pack();
dialog.exec();
