var MApplication = Java.type("org.makagiga.commons.MApplication");

var searchQuery = "Makagiga";
MApplication.openURI(
	"https://duckduckgo.com/?q={0}", // {1} = 2nd array element, etc.
	[searchQuery] // array with one element (mapped to {0})
);
