var MNotification = Java.type("org.makagiga.commons.swing.MNotification");

// custom message (autohide)
var message = new MNotification.Message("Title", "Autohide Test", "ui/ok");
message.setTimeout(5000);
message.show();

// custom message
MNotification.showMessage("Title", "A simple message with OK icon", "ui/ok");

// standard messages
MNotification.showError("Error Text");
MNotification.showInfo("Info Text");
MNotification.showWarning("Warning Text");
