var MMessage = Java.type("org.makagiga.commons.swing.MMessage");
var UI = Java.type("org.makagiga.commons.UI");
var URI = Java.type("java.net.URI");

try {
	URI.create("baduri:");
}
catch (exception) {
	MMessage.error(UI.windowFor(null), exception);
}
