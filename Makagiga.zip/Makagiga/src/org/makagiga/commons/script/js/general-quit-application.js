org.makagiga.commons.MApplication.quit();
