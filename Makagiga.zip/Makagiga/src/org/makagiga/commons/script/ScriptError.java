// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.script;

import static org.makagiga.commons.UI.i18n;

import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseEvent;
import javax.script.ScriptException;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.painters.GradientPainter;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MMessageLabel;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MStatusBar;
import org.makagiga.commons.swing.MainView;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @deprecated Since 5.0
 */
@Deprecated
public class ScriptError extends MMessageLabel {
	
	// private
	
	private boolean showFullText = true;
	private final boolean showStatusBarOnError;
	private static ScriptError _instance;
	private Throwable error;
	
	// public
	
	/**
	 * @since 1.2
	 */
	public ScriptError(final boolean showStatusBarOnError) {
		this.showStatusBarOnError = showStatusBarOnError;
		GradientPainter painter = new GradientPainter();
		painter.setReversed(true);
		setPainter(painter);

		Font font = UI.getFont(this);
		setFont(UI.createMonospacedFont(font.getStyle(), font.getSize() + 1));
		
		setStyle("margin: 0 5 0 5");
		setToolTipText(i18n("Error"));
		setVisible(false);
	}

	public synchronized static ScriptError getSharedInstance() {
		if (_instance == null) {
			ScriptError scriptError = new ScriptError(true);
			synchronized (scriptError) {
				scriptError.showFullText = false;
			}
			scriptError.setCursor(Cursor.HAND_CURSOR);
			scriptError.addMouseListener(new MMouseAdapter() {
				@Override
				public void buttonClicked/*mouseClicked*/(final MouseEvent e) {
					if (isLeft(e)) {
						ScriptError scriptError = (ScriptError)e.getSource();
						scriptError.doHide();
						if (scriptError.error != null) {
							MMessage.errorDetails(UI.windowFor(scriptError), scriptError.error, false);
							scriptError.error = null;
						}
					}
				}
			} );

			MStatusBar statusBar = MainView.getStatusBar();
			if (statusBar != null) {
				MPanel buttonPanel = statusBar.getButtonPanel();
				buttonPanel.add(scriptError);
				buttonPanel.validate();
			}

			_instance = scriptError;
		}
		
		return _instance;
	}
	
	public synchronized void showError(final Throwable error) {
		this.error = error;
		
		if (error == null)
			return;

		MLogger.exception(error);
		
		String message = makeMessage(error);
		setErrorMessage(showFullText ? UI.makeHTML(TK.escapeXML(message)) : null);
		setToolTipText(message);
		doShow(true);
	}
	
	public synchronized void showResult(final Object result) {
		String message = (result == null) ? i18n("OK") : result.toString();
		if (message.isEmpty())
			message = i18n("OK");
		setOKMessage(showFullText ? UI.makeHTML(TK.escapeXML(message)) : null);
		setToolTipText(message);
		doShow(false);
	}
	
	// private
	
	private void doHide() {
		setVisible(false);

		// shared instance - hide status bar
		if (showStatusBarOnError) {
			MStatusBar statusBar = MainView.getStatusBar();
			// restore status bar visibility on component hide
			if ((statusBar != null) && (statusBar.getButtonPanel().getComponentCount() == 0) && statusBar.isClosed())
				statusBar.setVisible(false);
		}
	}
	
	private void doShow(final boolean error) {
		setVisible(true);
		
		// shared instance - show status bar
		if (error && showStatusBarOnError) {
			MStatusBar statusBar = MainView.getStatusBar();
			if (statusBar != null)
				statusBar.setVisible(true);
		}
	}
	
	private static String getScriptErrorMessage(final ScriptException error) {
		String message = error.getMessage();
		int i = message.indexOf(':');
		if (i != -1)
			message = message.substring(i + 2);
		
		return error.getLineNumber() + ": " + message;
	}
	
	// package
	
	static String makeMessage(final Throwable error) {
		if (error instanceof ScriptException)
			return getScriptErrorMessage((ScriptException)error);

		Throwable cause = error.getCause();

		if (cause == null)
			return error.getMessage();

		if (cause instanceof ScriptException)
			return getScriptErrorMessage((ScriptException)cause);

		return cause.getMessage();
	}
	
}
