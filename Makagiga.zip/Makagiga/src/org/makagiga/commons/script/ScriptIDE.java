// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.script;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Font;
import java.awt.Window;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.security.PrivilegedActionException;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import javax.script.ScriptException;
import javax.swing.JComponent;

import org.makagiga.commons.Config;
import org.makagiga.commons.FS;
import org.makagiga.commons.Globals;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.help.HelpButton;
import org.makagiga.commons.help.HelpContext;
import org.makagiga.commons.mods.Mods;
import org.makagiga.commons.swing.ActionGroup;
import org.makagiga.commons.swing.Input;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MEditorPane;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MText;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.commons.syntax.SyntaxLayerUI;

public class ScriptIDE extends MDialog {

	// private

	private Editor editor;
	private final Path file;
	
	// public
	
	/**
	 * @since 4.0
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public ScriptIDE(final Window parent, final File file, final String name) {
		this(parent, file.toPath(), name);
	}

	/**
	 * @since 5.6
	 */
	public ScriptIDE(final Window owner, final Path file, final String name) {
		super(owner, (String)null, STANDARD_DIALOG | FORCE_STANDARD_BORDER | SIDE_BUTTONS);
		getOKButton().setActionInfoUI(MActionInfo.SAVE);
		getMainPanel().setMargin(0, 0, 0, MPanel.DEFAULT_CONTENT_MARGIN);

		HelpButton helpButton = new HelpButton();
		helpButton.setIconName(MActionInfo.HELP.getIconName());
		helpButton.addHelpContext(new HelpContext("makagiga", "http://sourceforge.net/p/makagiga/wiki/Scripting/", HelpContext.Type.URI, "Scripting Wiki"));
		helpButton.addHelpContext(new HelpContext("makagiga", "http://docs.oracle.com/javase/8/docs/technotes/guides/scripting/", HelpContext.Type.URI, "Scripting for the Java Platform"));
		helpButton.addHelpContext(new HelpContext("makagiga", "http://www.w3schools.com/js/", HelpContext.Type.URI, "JavaScript Tutorial"));
		helpButton.addHelpContext(new HelpContext("makagiga", "http://makagiga.sourceforge.net/api/", HelpContext.Type.URI, "Makagiga API"));
		helpButton.addHelpContext(new HelpContext("makagiga", "http://docs.oracle.com/javase/8/docs/api/", HelpContext.Type.URI, "Java" + UI.TM + " 8 SE API"));

		setSize(UI.WindowSize.LARGE);
		String ext = FS.getFileExtension(file);
		setTitle(i18n("Edit Script: {0}", (name + " (" + ext + ")")));
		this.file = file;
		
		editor = new Editor();

		SyntaxLayerUI syntaxLayer = new SyntaxLayerUI(editor);
		
		addCenter(syntaxLayer.wrap(editor));
		syntaxLayer.setSyntaxByType(ext);

		// load script
		try {
			if (Files.exists(file))
				MText.load(editor, file);
		}
		catch (NoSuchFileException exception) { } // quiet
		catch (IOException exception) {
			MMessage.error(this, exception, file);
		}

		MText.installAutoCompletion(editor, "script-ide");
		AutoCompletion ac = MText.getAutoCompletion(editor);
		ac.caseSensitive.yes();

		// DOC: https://wiki.openjdk.java.net/display/Nashorn/Nashorn+extensions
		// frequently used keywords and syntax:
		ac.addStaticItem("__DIR__");
		ac.addStaticItem("__FILE__");
		ac.addStaticItem("__LINE__");
		ac.addStaticItem("for each");
		ac.addStaticItem("function");
		ac.addStaticItem("instanceof");
		ac.addStaticItem("Packages.");
		ac.addStaticItem("print");
		ac.addStaticItem("return");

		ac.addStaticItem("Java.extend");
		ac.addStaticItem("Java.from");
		ac.addStaticItem("Java.super");
		ac.addStaticItem("Java.to");
		ac.addStaticItem("Java.type");

		// common packages:
		ac.addStaticItem("java.lang.");
		ac.addStaticItem("java.lang.System.err");
		ac.addStaticItem("java.lang.System.out");
		ac.addStaticItem("org.makagiga.commons.");
		ac.addStaticItem("org.makagiga.commons.swing.");

		// add items from user scripts:
		try (Stream<Path> s = Files.walk(ScriptExecutor.getScriptsDir(false))) {
			s.forEach(path -> {
				if (Files.isRegularFile(path) && FS.getFileExtension(path).equals(ext)) {
					try {
						ac.addStaticItemsFromText(FS.readAllText(path));
					}
					catch (IOException exception) {
						MLogger.exception(exception);
					}
				}
			} );
		}
		catch (IOException exception) {
			MLogger.exception(exception);
		}

		ActionGroup actionGroup = new ActionGroup();

		TestAction testAction = new TestAction();
		bind(JComponent.WHEN_IN_FOCUSED_WINDOW, testAction);
		actionGroup.add("test", testAction)
			.setShowTextInToolBar(true);
		
		MToolBar toolBar = new MToolBar();
		toolBar.setTextPosition(MToolBar.TextPosition.ALONGSIDE_ICONS);
		
		MText.updateActions(editor);
		MText.updateToolBar(editor, toolBar);
		
		toolBar.addGap();
		actionGroup.updateToolBar(toolBar);
		toolBar.addButton(new SnippetsButton(), MToolBar.SHOW_TEXT);

		toolBar.add(new MApplication.SettingsAction(action -> {
			Font newFont = Input.getFont(this, UI.getFont(editor));
			if (newFont != null) {
				editor.setFont(newFont);
			
				Config config = Config.getDefault();
				config.write("ScriptIDE.font", newFont);
				config.sync();
			}
		} ));

		toolBar.addButton(helpButton);

		setToolBar(toolBar);

		// mods

		Mods.exec(this, Globals.MOD_SCRIPT_IDE_INIT);
	}
	
	@Override
	public boolean exec() {
		return exec(editor);
	}

	public void save() {
		try {
			saveToFile();
		}
		catch (IOException exception) {
			MMessage.error(this, exception, file);
		}
	}

	// protected

	@Override
	protected boolean onAccept() {
		try {
			saveToFile();

			return true;
		}
		catch (IOException exception) {
			MMessage.error(this, exception, file);

			return false;
		}
	}

	@Override
	protected void onClose() {
		Mods.exec(this, Globals.MOD_SCRIPT_IDE_DISPOSE);

		if (editor != null) {
			MText.deinstallKit(editor);
			editor = null;
		}
	}

	@Override
	protected boolean onReject() {
		if (!editor.isModified())
			return true;
		
		return confirmReject();
	}
	
	// private
	
	private MMenu createSnippetsMenu() throws IOException {
		MMenu menu = new MMenu();

// TODO: add more general JavaScript examples; move from Wiki?

		MMenu dialogsMenu = new MMenu("Dialogs");
			dialogsMenu.add(new SnippetAction(this, "Modal Dialog", "dialog-modal"));
			dialogsMenu.add(new SnippetAction(this, "Simple Dialog", "dialog-simple"));
		menu.add(dialogsMenu);
		
		MMenu inputMenu = new MMenu("Input");
			inputMenu.add(new SnippetAction(this, "Text Field", "input-text-field"));
			inputMenu.add(new SnippetAction(this, "Text Area", "input-text-area"));
			inputMenu.add(new SnippetAction(this, "Password", "ui/password", "password-enter"));
		menu.add(inputMenu);

		MMenu messagesMenu = new MMenu("Messages");
			messagesMenu.add(new SnippetAction(this, "Error", "ui/error", "message-error"));
			messagesMenu.add(new SnippetAction(this, "Information", "ui/info", "message-info"));
			messagesMenu.add(new SnippetAction(this, "Warning", "ui/warning", "message-warning"));
			messagesMenu.addSeparator();
			messagesMenu.add(new SnippetAction(this, "Notifications", "ui/info", "notification"));
		menu.add(messagesMenu);

/* HACK: too many security warnings
		MMenu rssMenu = new MMenu("RSS");
			rssMenu.add(new SnippetAction(this, "A small RSS viewer", "ui/feed", "rss-viewer"));
		menu.add(rssMenu);
*/

		MMenu generalMenu = new MMenu("General");
			generalMenu.add(new SnippetAction(this, "Open URL", "general-open-url"));
			generalMenu.add(new SnippetAction(this, "Open URL (with parameters)", "general-open-url-params"));
			generalMenu.add(new SnippetAction(this, "Quit Application", "ui/quit", "general-quit-application"));
			generalMenu.addSeparator("Java Integration");
			generalMenu.add(new SnippetAction(this, "Handling Java Exception", "general-java-exception"));
			generalMenu.add(new SnippetAction(this, "Action Listener", "general-action-listener"));
		menu.add(generalMenu);
		
		menu.addSeparator();

		MMenu pluginMenu = new MMenu("Plugin");
			pluginMenu.add(new SnippetAction(this, "Get text from the active Tab", "plugin-get-text"));
			pluginMenu.add(new SnippetAction(this, "Get selected text from a Note widget", "plugin-note-widget"));
		menu.add(pluginMenu);

		return menu;
	}

	private void saveToFile() throws IOException {
		MText.save(editor, file);
		editor.setModified(false, null);
	}

	private void selectError(final ScriptException exception) {
		MText.goTo(editor, exception.getLineNumber(), exception.getColumnNumber());
	}
	
	private void test() {
		// save script before test
		save();
		
		try {
			ScriptExecutor.SecureExecutor executor = new ScriptExecutor.SecureExecutor() {
				@Override
				protected Object onEval() throws Exception {
					return ScriptExecutor.execute(file);
				}
			};
			Object result = executor.runPrivileged(ScriptExecutor.newSandbox(file));

// TODO: use fallback output if Console is not installed
			Mods.exec(this, Globals.MOD_SCRIPT_IDE_RESULT, result);
		}
		catch (PrivilegedActionException exception) {
			MMessage.error(this, exception);
		}
		catch (ScriptException exception) {
			selectError(exception);

			Mods.exec(this, Globals.MOD_SCRIPT_IDE_RESULT, exception);
		}
	}
	
	// private classes
	
	private static final class Editor extends MEditorPane {

		// public
		
		@Override
		public void paste() {
			super.paste();
			
			Config config = Config.getDefault();
			if (config.readOnce("ScriptIDE.pasteWarning", true)) {
				MMessage.warning(
					UI.windowFor(this),
					i18n(
						"Reminder: Pasting scripts from\n" +
						"\"untrusted\" sources may be dangerous."
					)
				);
			}
		}

		// private
		
		private Editor() {
			Config config = Config.getDefault();
			Font font = config.readFont("ScriptIDE.font", null);
			if (font != null)
				setFont(font);
			else
				MText.setupMonospacedFont(this);

			MText.setupMargin(this);
		}

	}
	
	private static final class SnippetAction extends MText.InsertAction {

		// private

		private static Pattern keywordPattern;
		
		// private
		
		private SnippetAction(final ScriptIDE ide, final String name, final String resource) throws IOException {
			this(ide, name, null, resource);
		}
		
		private SnippetAction(final ScriptIDE ide, final String name, final String iconName, final String resource) throws IOException {
			super(
				ide.editor,
				name,
				FS.read(ScriptIDE.class.getResourceAsStream("js/" + resource + ".js"), "UTF8")
			);
			
			setHTMLHelp(colorize());
			setSmallIcon(iconName);
		}
		
		private String colorize() {
			String html = TK.escapeXML(getString());
			
			if (keywordPattern == null) {
				keywordPattern = Pattern.compile(
					"\\bcatch|\\belse|\\bfor|\\bfunction|\\bif|\\binstanceof|\\bnew|\\bnull|\\btry|\\bvar"
				);
			}
			html = keywordPattern.matcher(html).replaceAll("<b>$0</b>");

			return "<pre>" + html + "</pre>";
		}
		
	}

	private static final class SnippetsButton extends MButton {

		// protected

		@Override
		protected MMenu onPopupMenu() {
			ScriptIDE ide = (ScriptIDE)getWindowAncestor();
			try {
				return ide.createSnippetsMenu();
			}
			catch (IOException exception) {
				MMessage.error(ide, exception);

				return null;
			}
		}

		// private

		private SnippetsButton() {
			super("Snippets"); // no i18n
			setIcon(MIcon.stock("ui/code"));
			setPopupMenuEnabled(true);
			setToolTipText("JavaScript");
		}

	}

	private static final class TestAction extends MAction {

		// public

		@Override
		public void onAction() {
			ScriptIDE ide = (ScriptIDE)getSourceWindow();
			ide.test();
		}

		// private

		private TestAction() {
			super(i18n("Test"), "ui/run", VK_F9);
		}

	}

}
