// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.script;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.PrivilegedActionException;
import java.util.Arrays;
import java.util.Objects;
import javax.script.ScriptException;
import javax.swing.JComponent;

import org.makagiga.commons.Config;
import org.makagiga.commons.FS;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.OS;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.icons.MIconButton;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MCheckBox;
import org.makagiga.commons.swing.MComponent;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MGroupLayout;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MTextField;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.commons.swing.event.PopupAdapter;

/**
 * Go ScriptYourself(tm) ;-)
 *
 * @since 2.0
 */
public final class ScriptYourself {

	// public

	/**
	 * @since 3.8.11
	 */
	public static final String CONTEXT_PROPERTY = "org.makagiga.commons.script.ScriptYourself.CONTEXT_PROPERTY";

	// private

	private static MouseListener toolBarMouseListener;
	private static PopupAdapter buttonMenuListener;
	private static final String ACTION_ID_PROPERTY = "org.makagiga.commons.script.ScriptYourself.ACTION_ID";
	private static final String TOOL_BAR_ID_PROPERTY = "org.makagiga.commons.script.ScriptYourself.TOOL_BAR_ID";
	
	// public

	public static void install(final MToolBar toolBar) {
		install(toolBar, toolBar.getID());
	}

	/**
	 * @since 3.8.7
	 */
	public static void install(final MToolBar toolBar, final String id) {
		TK.validateID(id);

		//Benchmark benchmark = Benchmark.begin("script installation - " + id);

		if (FS.isRestricted())
			return;

		MLogger.debug("script", "Installing \"%s\" tool bar scripts...", id);

		if (toolBar.getID() == null)
			toolBar.setID(id);

		final Path toolBarDir = getToolBarDirectory(id, false);
		String toolBarContext = (String)toolBar.getClientProperty(CONTEXT_PROPERTY);

		String[] names;
		try {
			names = MAccessController.doPrivileged(() -> {
				if (Files.exists(toolBarDir))
					return FS.listNames(toolBarDir.toFile());
					
				return TK.EMPTY_STRING_ARRAY;
			} );
		}
		catch (SecurityException exception) {
			MLogger.warning("core", "User script actions disabled by security manager: %s", id);

			return;
		}

		Arrays.sort(names);
		
		for (final String name : names) {
			if (!"properties".equals(FS.getFileExtension(name)))
				continue; // for

			Config config = MAccessController.doPrivileged(() ->
				new Config(toolBarDir.resolve(name))
			);
			ActionProperties ap = new ActionProperties(config);

			// Is valid context for this action?
			if (
				(toolBarContext != null) &&
				!TK.isEmpty(ap.context) &&
				!Objects.equals(toolBarContext, ap.context)
			) {
				MLogger.debug("script", "No valid context (%s) for action \"%s\"", ap.context, ap.name);

				continue; // for
			}

			String actionID = name.substring(0, name.lastIndexOf('.'));
			toolBar.addButton(
				createActionButton(id, actionID, ap),
				ap.showText ? MToolBar.SHOW_TEXT : 0
			);
		}

		toolBar.add(new Marker(id));
		
		if (toolBarMouseListener == null) {
			toolBarMouseListener = new MMouseAdapter() {
				@Override
				public void popupTrigger(final MouseEvent e) {
					if (!Kiosk.toolBarLocked.get() && Kiosk.userScript.get())
						ScriptYourself.showNewActionMenu((JComponent)e.getSource());
				}
			};
		}
		toolBar.addMouseListener(toolBarMouseListener);

		//benchmark.end();
	}
	
	public static void deleteAction(final MButton button) {
		if (MMessage.confirmDelete(button.getWindowAncestor(), i18n("Delete action?"), button.getText())) {
			// remove files
			String basePath = getActionBasePath((MAction)button.getAction(), false);
			ActionProperties ap = new ActionProperties(basePath);
			FS.deleteSilently(Paths.get(basePath + "." + ap.language));
			FS.deleteSilently(Paths.get(basePath + ".properties"));
			
			// remove component
			MComponent.removeFromParent(button, true);
		}
	}
	
	public static void editProperties(final MButton button) {
		MAction action = (MAction)button.getAction();
		MToolBar parent = (MToolBar)button.getParent();
		String basePath = getActionBasePath(action, false);
		ActionProperties ap = new ActionProperties(basePath);
		if (ap.showDialog(button.getWindowAncestor(), parent, false)) {
			action.setIconName(ap.getIconName());
			action.setName(ap.name);
			action.setToolTipText(ap.description);
			ap.save(basePath);

			if (parent.getIconSize() != MIcon.Size.DEFAULT)
				button.setIcon(MAction.getIcon(action, parent.getIconSize()));
			parent.setupButton(button, ap.showText ? MToolBar.SHOW_TEXT : 0);
		}
	}
	
	public static void editScript(final MButton button) {
		String basePath = getActionBasePath((MAction)button.getAction(), false);
		ActionProperties ap = new ActionProperties(basePath);
		new ScriptIDE(button.getWindowAncestor(), Paths.get(basePath + "." + ap.language), ap.name)
			.exec();
	}
	
	public static void newAction(final JComponent c) {
		if (!(c instanceof MToolBar)) {
			MLogger.error("script", "Unsupported component type: %s", (c == null) ? "null" : c.getClass().getName());
			
			return;
		}
	
		ActionProperties ap = new ActionProperties();
		Window parent = UI.windowFor(c);
		MToolBar toolBar = (MToolBar)c;
		
		if (!ap.showDialog(parent, toolBar, true))
			return;
		
		String actionID = TK.createRandomUUID();

		String toolBarID = toolBar.getID();
		MButton actionButton = createActionButton(toolBarID, actionID, ap);
		addButton(
			toolBar,
			toolBarID,
			actionButton,
			ap.showText ? MToolBar.SHOW_TEXT : 0
		);
		
		c.validate();
		c.repaint();
			
		String basePath = getActionBasePath(toolBar.getID(), actionID, true);
		File script = new File(basePath + "." + ap.language);

		ap.save(basePath);

		try {
			if (script.createNewFile()) {
				new ScriptIDE(parent, script.toPath(), ap.name)
					.exec();
			}
			else {
				MMessage.error(parent, i18n("Could not create a new file"));
			}
		}
		catch (IOException exception) {
			MMessage.error(parent, exception);
		}
		
		actionButton.requestFocusInWindow();
	}

// TODO: 2.0: import/export
	public static void showActionMenu(final MButton button) {
		MMenu menu = new MMenu();
		menu.add(new MAction(i18n("Edit Script..."), action -> editScript(button)));
		menu.addSeparator();
		menu.add(new MAction(i18n("Delete Action"), "ui/delete", action -> deleteAction(button)));
		menu.addSeparator();
		menu.add(new MAction(MActionInfo.PROPERTIES, ction -> editProperties(button)));
		menu.showPopup(button);
	}

	public static void showNewActionMenu(final JComponent c) {
		MMenu menu = new MMenu();
		menu.add(new MAction(i18n("New Action..."), "ui/add", action -> newAction(c)));
		menu.showPopup(c);
	}
	
	// private
	
	@Uninstantiable
	private ScriptYourself() {
		TK.uninstantiable();
	}

	private static void addButton(final MToolBar toolBar, final String id, final MButton button, final int buttonOptions) {
		int count = toolBar.getComponentCount();
		for (int markerIndex = 0; markerIndex < count; markerIndex++) {
			Component c = toolBar.getComponent(markerIndex);
			if (c instanceof Marker) {
				Marker marker = (Marker)c;
				// marker found; insert button before marker
				if (marker.id.equals(id)) {
					MLogger.debug("script", "Found marker \"%s\" at %d index", id, markerIndex);

					toolBar.addButtonAt(markerIndex, button, buttonOptions);

					return;
				}
			}
		}

		// no marker; add button at the end
		toolBar.addButton(button, buttonOptions);
	}
	
	private static MButton createActionButton(final String toolBarID, final String actionID, final ActionProperties ap) {
		MAction action = new MAction(ap.name, ap.getIconName()) {
			@Override
			public void onAction() {
				if (!Kiosk.userScript.get()) {
					TK.beep();
					
					return;
				}
				
				final String basePath = ScriptYourself.getActionBasePath(this, false);
				try {
					Path scriptFile = Paths.get(basePath + "." + ap.language);
					ScriptExecutor.SecureExecutor executor = new ScriptExecutor.SecureExecutor() {
						@Override
						protected Object onEval() throws Exception {
							return ScriptExecutor.execute(scriptFile);
						}
					};
					executor.runPrivileged(ScriptExecutor.newSandbox(scriptFile));
				}
				catch (PrivilegedActionException exception) {
					this.showErrorMessage(exception);
				}
				catch (ScriptException exception) {
					MMessage.errorDetails(this.getSourceWindow(), exception, false);
				}
			}
		};
		action.setEnabled(Kiosk.userScript.get());
		action.setToolTipText(ap.description);
		action.putValue(ACTION_ID_PROPERTY, actionID);
		action.putValue(TOOL_BAR_ID_PROPERTY, toolBarID);

		MButton button = new MButton(action);
		
		if (buttonMenuListener == null) {
			buttonMenuListener = new PopupAdapter(e -> {
				if (!Kiosk.toolBarLocked.get() && Kiosk.userScript.get())
					showActionMenu((MButton)e.getSource());
			} );
		}
		buttonMenuListener.install(button);

		//MLogger.debug("script", "Created action button: %s (actionID=%s, toolBarID=%s)", button.getText(), actionID, toolBarID);

		return button;
	}

	private static String getActionBasePath(final MAction action, final boolean mkdirs) {
		return getActionBasePath(
			(String)action.getValue(TOOL_BAR_ID_PROPERTY, null),
			(String)action.getValue(ACTION_ID_PROPERTY, null),
			mkdirs
		);
	}

	private static String getActionBasePath(final String toolBarID, final String actionID, final boolean mkdirs) {
		return getToolBarDirectory(toolBarID, mkdirs)
			.resolve(actionID)
			.toString();
	}

	private static Path getToolBarDirectory(final String toolBarID, final boolean mkdirs) {
		Path dir = ScriptExecutor.getScriptsDir(false)
			.resolve("actions")
			.resolve(toolBarID);

		if (mkdirs) {
			try {
				Files.createDirectories(dir);
			}
			catch (IOException exception) {
				MLogger.exception(exception);
			}
		}

		return dir;
	}
	
	// private classes
	
	private static final class ActionProperties {
		
		// private

		private boolean showText;
		private String context;
		private String description;
		private String iconName = "ui/misc";
		private String language;
		private String name;
		
		// private
		
		private ActionProperties() { }
		
		private ActionProperties(final Config config) {
			context = config.read("context", "");
			name = config.read("name", "");
			description = config.read("description", null);
			iconName = config.read("icon", null);
			language = config.read("language", "js");
			showText = config.read("showText", false);
		}
		
		private ActionProperties(final String basePath) {
			this(new Config(basePath + ".properties"));
		}
		
		private String getIconName() {
			return Objects.toString(iconName, "ui/misc");
		}
		
		private void save(final String basePath) {
			Config config = new Config(basePath + ".properties");
			config.write("context", context);
			config.write("icon", iconName);
			config.write("language", language);
			config.write("name", name);
			config.write("description", description);
			config.write("showText", showText);
			config.sync();
		}
		
		private boolean showDialog(final Window parent, final MToolBar toolBar, final boolean isNew) {
			ScriptComboBox script = new ScriptComboBox();
			
			if (script.isEmpty()) {
				String s = i18n("Script engine not found: {0}", "JavaScript (Nashorn)");
				// HACK: a temporary message
				if (OS.isLinux() && OS.isOpenJDK())
					s += "\n\nProbably your OpenJDK package is broken.";
				MMessage.error(parent, s);
				
				return false;
			}

			MIconButton iconField = new MIconButton(getIconName());

			MTextField nameField = new MTextField(name);
			nameField.setAutoCompletion("actionname");

			MTextField descriptionField = new MTextField(description);
			descriptionField.setAutoCompletion("actiondescription");

			String toolBarContext = (String)toolBar.getClientProperty(CONTEXT_PROPERTY);
			MCheckBox contextField = new MCheckBox(i18n("Show only in this context ({0})", Objects.toString(toolBarContext, i18n("None"))));
			contextField.setEnabled(toolBarContext != null);
			contextField.setSelected(!TK.isEmpty(context));

			MCheckBox showTextField = new MCheckBox(i18n("Show Button Text"));
			showTextField.setSelected(showText);

			MPanel p = new MPanel(true);
			MGroupLayout l = p.getGroupLayout();
			l
			.addComponent(iconField, MGroupLayout.Alignment.LEADING)
			.addLargeContentGap()
			.beginRows()
				.addComponent(nameField, i18n("Action Name:"))
				.addComponent(descriptionField, i18n("Description:"))
				.addLargeContentGap()
				.addComponent(contextField)
				.addComponent(showTextField);
				if (isNew) {
					l.addLargeContentGap();
					l.addComponent(script, i18n("Script Language:"));
				}
			l.end(); // rows

			MDialog dialog = new MDialog(
				parent,
				isNew ? i18n("New Action") : i18n("Properties"),
				isNew ? "ui/add" : MActionInfo.PROPERTIES.getIconName()
			);
			if (isNew)
				dialog.getOKButton().setText(i18n("Create"));
			dialog.addCenter(p);
			dialog.packFixed(UI.WindowSize.MEDIUM);
			if (dialog.exec(nameField)) {
				nameField.saveAutoCompletion();
				
				iconName = iconField.getIconName();
				if (isNew)
					language = script.getSelectedItem().getExtensions().get(0);
				name = nameField.getText();
				description = descriptionField.isEmpty() ? null : descriptionField.getText();
				context = contextField.isSelected() ? toolBarContext : null;
				showText = showTextField.isSelected();
				
				return true;
			}
			
			return false;
		}
		
	}

	private static final class Marker extends MComponent {

		// private

		private final String id;

		// public

		@Override
		public Dimension getMaximumSize() {
			return new Dimension();
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension();
		}

		// private

		private Marker(final String id) {
			this.id = id;
			setOpaque(false);
		}

	}
	
}
