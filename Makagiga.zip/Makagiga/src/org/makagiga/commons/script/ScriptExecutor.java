// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.script;

import static org.makagiga.commons.UI.i18n;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilePermission;
import java.io.InputStream;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.CodeSigner;
import java.security.CodeSource;
import java.security.Permission;
import java.security.Permissions;
import java.security.Policy;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.ProtectionDomain;
import java.util.EventListener;
import java.util.EventObject;
import java.util.Objects;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.event.EventListenerList;

import org.makagiga.commons.FS;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.swing.MNotification;

public final class ScriptExecutor {

	// private
	
	private static final EventListenerList listeners = new EventListenerList();
	
	// public
	
	/**
	 * @since 4.10
	 */
	public static void addScriptListener(final ScriptListener l) {
		listeners.add(ScriptListener.class, l);
	}

	/**
	 * @since 4.10
	 */
	public static void removeScriptListener(final ScriptListener l) {
		listeners.remove(ScriptListener.class, l);
	}

	/**
	 * @since 4.0
	 */
	public static void check(final ScriptEngine engine, final String message) throws ScriptException {
		if (engine == null)
			throw new ScriptException("Script Engine not found: " + message);
	}

	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public synchronized static Object execute(final File file) throws FileNotFoundException, ScriptException {
		checkSecurityManager();
	
		FS.TextReader reader = null;
		try {
			reader = FS.getUTF8Reader(file);
			ScriptEngine engine = getEngine(FS.getFileExtension(file));
			check(engine, file.getPath());

			return engine.eval(reader);
		}
		finally {
			FS.close(reader);
		}
	}

	/**
	 * @since 5.6
	 */
	public synchronized static Object execute(final Path file) throws IOException, ScriptException {
		checkSecurityManager();
	
		try (Reader reader = Files.newBufferedReader(file)) {
			ScriptEngine engine = getEngine(FS.getFileExtension(file));
			check(engine, file.toString());

			return engine.eval(reader);
		}
	}

	public synchronized static Object execute(final String extension, final InputStream stream) throws ScriptException {
		checkSecurityManager();
	
		ScriptEngine engine = getEngine(extension);
		check(engine, extension);

		return engine.eval(FS.getUTF8Reader(stream));
	}

	public synchronized static Object execute(final String extension, final String script) throws ScriptException {
		checkSecurityManager();
	
		ScriptEngine engine = getEngine(extension);
		check(engine, extension);

		return engine.eval(script);
	}

	/**
	 * Execute user script
	 * at [application configuration directory]/scripts/user.js.
	 *
	 * @since 3.8.1
	 */
	public synchronized static void executeUserScript() throws ScriptException {
		if (Kiosk.userScript.get()) {
			Path userScriptFile = getScriptsDir(false).resolve("user.js");
			if (Files.exists(userScriptFile)) {
				try {
					SecureExecutor executor = new SecureExecutor() {
						@Override
						protected Object onEval() throws Exception {
							return ScriptExecutor.execute(userScriptFile.toFile());
						}
					};
					executor.runPrivileged(newSandbox(userScriptFile));
				}
				catch (PrivilegedActionException exception) {
					if (!(exception.getCause() instanceof FileNotFoundException))
						MLogger.exception(exception);
				}
			}
		}
	}

	public synchronized static ScriptEngine getEngine(final String extension) {
		ScriptEngineManager manager = new ScriptEngineManager();
		
		return MAccessController.doPrivileged(() -> {
			if (TK.isEmpty(extension) || "js".equals(extension))
				return manager.getEngineByName("nashorn");

			return manager.getEngineByExtension(extension);
		} );
	}

	/**
	 * @since 5.0
	 */
	public static Path getScriptsDir(final boolean create) {
		return FS.newConfigPath("scripts", create ? FS.CREATE_DIR : 0);
	}

	/**
	 * @since 4.4
	 */
	public static AccessControlContext newSandbox(final Path scriptFile, final Permission... permissions) {
		MArrayList<Permission> list = new MArrayList<>();
		if (scriptFile != null)
			list.add(new FilePermission(scriptFile.toString(), "read"));
		if (permissions != null)
			list.addAll(permissions);
		
		CodeSource codeSource;
		if (scriptFile == null)
			codeSource = null;
		else
			codeSource = new CodeSource(FS.toURL(scriptFile), (CodeSigner[])null);

		Permissions allow = new Permissions();
		if (permissions != null) {
			for (Permission i : list)
				allow.add(i);
		}

		return new AccessControlContext(new ProtectionDomain[] {
			new ProtectionDomain(codeSource, allow) {
				@Override
				public boolean implies(final Permission p) {
					// examine "allow"
					if (super.implies(p))
						return true;

					// examine global security policy or ask user
					Policy policy = MAccessController.doPrivileged(Policy::getPolicy);

// FIXME: this does not work with Nashorn
					return (policy == null) || policy.implies(this, p);
				}
			}
		} );
	}

	/**
	 * @since 5.0
	 */
	@SuppressWarnings("deprecation")
	public static void showErrorNotification(final Throwable error, final String source) {
		MLogger.exception(error);

		String text = TK.escapeXML(ScriptError.makeMessage(error));
		if (source != null)
			text += "<br><br>" + TK.escapeXML(source);

		MNotification.showMessage(
			i18n("Script Error"),
			UI.makeHTML(text),
			"ui/error"
		);
	}

	// private
	
	@Uninstantiable
	private ScriptExecutor() {
		TK.uninstantiable();
	}
	
	private static void checkSecurityManager() {
		ScriptEvent e = new ScriptEvent(ScriptExecutor.class, ScriptEvent.ID.CHECK_SECURITY_MANAGER);
		for (ScriptListener i : listeners.getListeners(ScriptListener.class))
			i.handle(e);
	}
	
	// public classes
	
	/**
	 * @since 4.10
	 */
	public static class ScriptEvent extends EventObject {
	
		// public
		
		public enum ID { CHECK_SECURITY_MANAGER }
	
		// private
		
		private final ID id;
	
		// public
		
		public ScriptEvent(final Object source, final ID id) {
			super(source);
			this.id = Objects.requireNonNull(id);
		}
		
		public ID getID() { return id; }
	
	}
	
	/**
	 * @since 4.10
	 */
	@FunctionalInterface
	public static interface ScriptListener extends EventListener {
	
		// public
		
		public void handle(final ScriptEvent e);
	
	}
	
	/**
	 * @since 4.4
	 */
	public static abstract class SecureExecutor {
	
		// public
		
		public Object runPrivileged(final AccessControlContext acc) throws PrivilegedActionException, ScriptException {
			ScriptExecutor.checkSecurityManager();

			try {
				return AccessController.doPrivileged(new PrivilegedExceptionAction<Object>() {
					@Override
					public Object run() throws Exception {
						return onEval();
					}
				}, acc);
			}
			catch (PrivilegedActionException exception) {
				Throwable cause = exception.getCause();
				
				if (cause instanceof ScriptException)
					throw (ScriptException)cause;
				
				throw exception;
			}
		}
	
		// protected
		
		protected SecureExecutor() { }
		
		protected abstract Object onEval() throws Exception;
	
	}

}
