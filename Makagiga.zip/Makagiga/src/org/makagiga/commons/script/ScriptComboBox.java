// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.script;

import javax.script.ScriptEngineFactory;
import javax.script.ScriptEngineManager;

import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.swing.MComboBox;

final class ScriptComboBox extends MComboBox<ScriptEngineFactory> {
	
	// public
	
	public ScriptComboBox() {
		ScriptEngineManager manager = new ScriptEngineManager();
		addAllItems(manager.getEngineFactories());
		if (getItemCount() == 1)
			setEnabled(false);
		
		MRenderer<ScriptEngineFactory> renderer = new MRenderer<>((self, value) -> {
			self.setText(ScriptComboBox.getName(value) + " (" + value.getEngineName() + ")");
		} );
		renderer.setHTMLEnabled(false);
		setRenderer(renderer);
		
		sort((o1, o2) -> ScriptComboBox.getName(o1).compareToIgnoreCase(ScriptComboBox.getName(o2)));
	}
	
	// private
	
	private static String getName(final ScriptEngineFactory sef) {
		String name = sef.getLanguageName();

		// use a more commonly used name
		return name.equals("ECMAScript") ? "JavaScript" : name;
	}

}
