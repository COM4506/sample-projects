// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

import org.makagiga.commons.swing.MStatusBar;

/**
 * An abstract selection.
 * This class represents an object
 * that can be copied to the clipboard or transfered via drag and drop.
 *
 * @see ImageSelection Usage example
 */
public abstract class AbstractSelection<T>
implements
	ClipboardOwner,
	Transferable
{
	
	// private
	
	private final DataFlavor[] flavors;
	private T data;
	
	// public
	
	/**
	 * @since 4.2
	 */
	public boolean copyToClipboard() {
		try {
			MClipboard.setContents(this);
			
			return true;
		}
		catch (ClipboardException exception) {
			MStatusBar.error(exception);
			
			return false;
		}
	}
	
	public static DataFlavor createDataFlavor(final String mime, final String clazz) {
		try {
			return new DataFlavor(String.format("%s; class=%s", mime, clazz));
		}
		catch (ClassNotFoundException exception) {
			MLogger.exception(exception);
			
			return null;
		}
	}
	
	/**
	 * Returns the contents associated with this object of the {@code flavor} type.
	 */
	public abstract Object getContents(final DataFlavor flavor);

	/**
	 * Returns the data of this object.
	 */
	public synchronized T getData() { return data; }
	
	// ClipboardOwner
	
	/**
	 * Sets the data of this object to {@code null}.
	 *
	 * @see java.awt.datatransfer.ClipboardOwner
	 */
	@Override
	public synchronized void lostOwnership(final Clipboard clipboard, final Transferable transferable) { data = null; }
	
	// Transferable

	/**
	 * @see java.awt.datatransfer.Transferable
	 */
	@Override
	public synchronized Object getTransferData(final DataFlavor flavor) throws UnsupportedFlavorException {
		if (!isDataFlavorSupported(flavor))
			throw new UnsupportedFlavorException(flavor);
		
		if (data == null)
			return null;

		return getContents(flavor);
	}

	/**
	 * @see java.awt.datatransfer.Transferable
	 */
	@Override
	public synchronized DataFlavor[] getTransferDataFlavors() {
		return TK.copyOf(flavors);
	}

	/**
	 * @see java.awt.datatransfer.Transferable
	 */
	@Override
	public synchronized boolean isDataFlavorSupported(final DataFlavor flavor) {
		return TK.indexOf(flavors, flavor) != -1;
	}

	// protected

	/**
	 * @since 3.8
	 */
	protected AbstractSelection(final T data, final DataFlavor... flavors) {
		this.data = data;
		this.flavors = TK.copyOf(flavors);
	}

}
