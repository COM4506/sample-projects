// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static java.lang.System.out;

import static org.makagiga.commons.UI.i18n;

import java.awt.GraphicsEnvironment;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.TreeMap;

import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.html.MHTMLViewer;
import org.makagiga.commons.security.MPermission;
import org.makagiga.commons.swing.MDialog;

/**
 * A command line arguments manager.
 *
 * @mg.example
 * <pre class="brush: java">
 * public static final void main(String[] args) {
 *   Args.init(args); // Note that this method is invoked automatically by MApplication
 *   Args.add("foo", i18n("Do foo and exit"));
 *   Args.add("verbose", i18n("Enable verbose mode"));
 *   if (Args.check()) // check for "--help" and "--version" arguments
 *     System.exit(0);
 *
 *   if (Args.isSet("foo")) // check for "--foo" or "-foo" argument
 *     doFoo();
 * </pre>
 *
 * @see CommandOptions A general purpose command options manager
 */
public final class Args {

	// private

	private static final CommandOptions commandOptions = new CommandOptions();

	// public

	/**
	 * Registers a new item in the list of valid command line arguments.
	 * 
	 * Do not add "help" and "version" arguments.
	 * These arguments will be added automatically by the @ref init(final String[]) function.
	 * 
	 * @param name the argument name (e.g. "foo")
	 * @param description the argument description (e.g. "Do foo and exit")
	 * 
	 * @see #getAdded()
	 */
	public synchronized static void add(final String name, final String description) {
		checkPermission(name + " (" + description + ")", "add");

		if (name != null)
			commandOptions.registerOption(null, name, description);
	}

	/**
	 * Checks for the internal command line arguments.
	 * 
	 * Internal arguments are:
	 * - "--help" - show application help/version and exit
	 * - "--version" - show application version and exit
	 * 
	 * @since 3.0
	 */
	public synchronized static boolean check() {
		if (isSet("help")) {
			if (GraphicsEnvironment.isHeadless())
				helpCLI();
			else
				helpGUI();
			
			return true;
		}
		else if (isSet("version")) {
			if (GraphicsEnvironment.isHeadless())
				versionCLI();
			else
				versionGUI();
			
			return true;
		}
		
		return false;
	}

	/**
	 * Returns the number of command line arguments.
	 * 
	 * @since 2.0
	 */
	public static int count() {
		return commandOptions.size();
	}
	
	/**
	 * @since 2.0
	 */
	public static String get(final int index) {
		return commandOptions.getRaw(index);
	}

	/**
	 * Returns a read only, sorted by key, map of all registered arguments/descriptions.
	 * 
	 * @see #add(String, String)
	 * 
	 * @since 3.0
	 */
	public static Map<String, String> getAdded() {
		Map<String, String> map = new TreeMap<>();
		for (CommandOptions.Option i : commandOptions.getRegisteredOptions()) {
			if (i.getLongName() != null)
				map.put(i.getLongName(), i.getDescription());
			if (i.getShortName() != null)
				map.put(i.getShortName(), i.getDescription());
		}

		return map;
	}

	public static String getOption(final String name) {
		if (TK.isEmpty(name))
			return null;

		return commandOptions.getOption(name);
	}

	/**
	 * Prints command line help to the @b stdout.
	 * Arguments are sorted by its name.
	 * 
	 * @see #helpGUI()
	 * 
	 * @since 2.4
	 */
	public synchronized static void helpCLI() {
		out.println();
		out.printf("%s%n", MApplication.getTitleAndCodename());
		out.printf("%s%n", MApplication.getCopyright());
		out.println();
		out.println(toText());
		out.println();
	}

	/**
	 * Displays command line help in a window.
	 * Arguments are sorted by its name.
	 * 
	 * @see #helpCLI()
	 * 
	 * @since 2.4
	 */
	public synchronized static void helpGUI() {
		HTMLBuilder html = new HTMLBuilder();
		html.addHeader(1, html.escape(MApplication.getTitleAndCodename()));
		html.addHeader(2, html.escape(MApplication.getCopyright()));
		html.addHeader(2, html.escape(i18n("Command line options:")));

		Map<String, String> sortedMap = getAdded();
		html.beginTag("table");
		String nameStyle = "font-family: monospace; font-weight: bold";
		for (Map.Entry<String, String> i : sortedMap.entrySet()) {
			html.beginTag("tr");
				html.doubleTag("td", html.escape("--" + i.getKey()), "style", nameStyle);
				html.doubleTag("td", html.escape(i.getValue()));
			html.endTag("tr");
		}
		html.endTag("table");

		showWindow(MActionInfo.HELP.getDialogTitle(), html);
	}

	/**
	 * Initializes this class and registers the standard options ({@code --version}, etc.).
	 * Call it from the {@code static void main} method on application startup.
	 *
	 * @mg.note
	 * This method is invoked automatically by {@link MApplication}.
	 *
	 * @param args the array of the command line arguments
	 */
	public synchronized static void init(final String[] args) {
		checkPermission("init");

		commandOptions.set(args);
		if (OS.isWindows())
			add("at", i18n("Enable Screen Reader"));
		add("help", i18n("Help"));
		add("portable", i18n("Use this option if application is stored on a writeable and removable storage device (USB flash drive or flash card)"));
		add("profile", i18n("Start with profile. Example: {0}", ("--profile \"" + i18n("Profile Name") + "\"")));
		add("rtl", i18n("Use right-to-left layout"));
		add("safe-mode", i18n("Safe mode"));
		add("user-files", i18n("Directory with configuration and data files. Example: {0}", "--user-files \"/home/foo/Makagiga\""));
		add("version", i18n("Show version info and exit"));

		commandOptions.setErrorMode(CommandOptions.ErrorMode.WARNING);
	}

	/**
	 * Returns @c true if @p arg has been passed to the command line arguments.
	 * @param arg An argument name without leading "--" or "-" (e.g. "foo")
	 */
	public static boolean isSet(final String arg) {
		if (TK.isEmpty(arg))
			return false;

		return commandOptions.isSet(arg);
	}
	
	/**
	 * @since 4.4
	 */
	public static Path toPath(final int index) {
		return Paths.get(get(index));
	}

	/**
	 * @since 5.0
	 */
	public synchronized static String toText() {
		return commandOptions.toString();
	}

	/**
	 * Prints version info to the @b stdout.
	 * 
	 * @since 2.4
	 */
	public synchronized static void versionCLI() {
		out.print(OS.getSummary(false));
	}

	/**
	 * Displays version info in a window.
	 * 
	 * @since 2.4
	 */
	public synchronized static void versionGUI() {
		HTMLBuilder html = new HTMLBuilder();
		html.doubleTag("pre", html.escape(OS.getSummary(false)));
		
		showWindow(i18n("Version"), html);
	}

	// private
	
	@Uninstantiable
	private Args() {
		TK.uninstantiable();
	}
	
	private static void checkPermission(final String name) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new Args.Permission(name));
	}

	private static void checkPermission(final String name, final String actions) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new Args.Permission(name, actions));
	}

	private static void showWindow(final String title, final HTMLBuilder html) {
		MDialog dialog = new MDialog(null, title, MDialog.SIMPLE_DIALOG | MDialog.HEADER_BAR | MDialog.COMPACT_HEADER);
		MHTMLViewer help = new MHTMLViewer();
		help.setHTML(html);
		help.setToolTipText(title);
		dialog.addCenter(help);
		dialog.pack();
		dialog.exec(help);
	}
	
	// public classes
	
	/**
	 * @since 3.0
	 */
	public static final class Permission extends MPermission {
	
		// public

		@Override
		public String getIconName() { return "ui/console"; }

		@Override
		public String getPermissionDescription() {
			return i18n("Command Line Options");
		}
		
		// private

		private Permission(final String name) {
			super(name, ThreatLevel.MEDIUM);
		}

		private Permission(final String name, final String actions) {
			super(name, ThreatLevel.MEDIUM);
			setActions(actions);
		}
		
	}

}
