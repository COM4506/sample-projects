// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.concurrent.TimeUnit;

/**
 * @since 4.10
 */
public final class ElapsedTimer implements Serializable {
	
	// private
	
	private long nanoStart;
	
	// public

	public ElapsedTimer(final boolean start) {
		if (start)
			start();
	}
	
	public long elapsedMS() {
		return elapsedNano() / 1000000L;
	}

	public long elapsedNano() {
		return Math.abs(System.nanoTime() - nanoStart);
	}

	public long elapsedSeconds() {
		return elapsedMS() / 1000L;
	}

	/**
	 * @deprecated As of 5.2, replaced by {@link MFormat#nano(long)}
	 */
	@Deprecated
	public static String formatNano(final long value) {
		return MFormat.nano(value);
	}
	
	public boolean isExpired(final TimeUnit unit, final long value) {
		return unit.convert(elapsedNano(), TimeUnit.NANOSECONDS) >= value;
	}
	
	public void start() {
		nanoStart = System.nanoTime();
	}

}
