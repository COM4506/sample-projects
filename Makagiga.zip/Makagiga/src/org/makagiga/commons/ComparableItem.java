// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.util.Objects;
import javax.swing.Icon;

/**
 * @mg.note
 * This class has a natural ordering ("compareTo") that is inconsistent with "equals".
 *
 * @mg.warning
 * This object is mutable and should not be used as {@code HashMap} key
 * or in {@code HashSet} collection.
 *
 * @since 4.6
 */
public class ComparableItem<T> extends Item<T> implements Comparable<Item<T>> {

	// public
	
	public enum CompareTo { TEXT, TEXT_IGNORE_CASE, VALUE }
	
	// private
	
	private CompareTo compareTo = CompareTo.TEXT;
	
	// public
	
	public ComparableItem() { }
	
	public ComparableItem(final Icon icon) {
		super(icon);
	}

	public ComparableItem(final T value) {
		super(value);
	}

	public ComparableItem(final T value, final String text) {
		super(value, text);
	}
	
	/**
	 * Returns {@code true} if text, value, and icon matches.
	 *
	 * @mg.note
	 * This class has a natural ordering that is inconsistent with "equals".
	 */
	@Override
	public boolean equals(final Object o) {
		if (o == this)
			return true;
		
		if (!(o instanceof ComparableItem<?>))
			return false;
		
		ComparableItem<?> ci = (ComparableItem<?>)o;
	
		return
			Objects.equals(this.getText(), ci.getText()) &&
			Objects.equals(this.getValue(), ci.getValue()) &&
			Objects.equals(this.getIcon(), ci.getIcon());
	}
	
	/**
	 * Returns a hash code for text, value, and icon.
	 */
	@Override
	public int hashCode() {
		return Objects.hash(getText(), getValue(), getIcon());
	}
	
	public CompareTo getCompareTo() { return compareTo; }
	
	public void setCompareTo(final CompareTo value) {
		compareTo = Objects.requireNonNull(value);
	}

	// Comparable
		
	/**
	 * @mg.note
	 * This class has a natural ordering that is inconsistent with "equals".
	 */
	@Override
	@SuppressWarnings("unchecked")
	public int compareTo(final Item<T> o) {
		if (compareTo == CompareTo.TEXT)
			return this.getText().compareTo(o.getText());

		if (compareTo == CompareTo.TEXT_IGNORE_CASE)
			return this.getText().compareToIgnoreCase(o.getText());

		// VALUE

		T v = getValue();

		if (v instanceof Comparable<?>)
			return Comparable.class.cast(v).compareTo(o.getValue());

		throw new UnsupportedOperationException("Item value does not implement \"Comparable\" interface");
	}

}
