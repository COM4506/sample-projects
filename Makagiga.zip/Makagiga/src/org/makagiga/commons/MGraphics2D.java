// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import javax.swing.Icon;

/**
 * @since 3.8.6
 */
public class MGraphics2D
implements
	AutoCloseable,
	MDisposable
{

	// private

	private Graphics2D g;
	private final Dimension _size;

	// public

	/**
	 * @since 3.8.7
	 */
	public MGraphics2D(final BufferedImage image) {
		this.g = image.createGraphics();
		_size = new Dimension(image.getWidth(), image.getHeight());
	}

	/**
	 * @param g the {@code java.awt.Graphics2D} object
	 */
	public MGraphics2D(final Graphics g) {
		this.g = (Graphics2D)g;
		_size = null;
	}
	
	/**
	 * @since 3.8.11
	 */
	public static MGraphics2D copy(final Graphics g) {
		return new MGraphics2D(g.create());
	}

	/**
	 * @since 3.8.7
	 */
	public static Shape createTriangle(final int x1, final int y1, final int x2, final int y2, final int x3, final int y3) {
		Path2D.Float triangle = new Path2D.Float();
		triangle.moveTo(x1, y1);
		triangle.lineTo(x2, y2);
		triangle.lineTo(x3, y3);

		return triangle;
	}

	/**
	 * @since 3.8.7
	 */
	public void drawHLine(final int x1, final int y, final int x2) {
		g.drawLine(x1, y, x2, y);
	}

	/**
	 * @since 3.8.7
	 */
	public void drawVLine(final int x, final int y1, final int y2) {
		g.drawLine(x, y1, x, y2);
	}

	/**
	 * @since 3.8.11
	 */
	public void drawIcon(final Component c, final Icon icon, final int x, final int y) {
		icon.paintIcon(c, g, x, y);
	}

	/**
	 * @since 3.8.11
	 */
	public void drawIcon(final Icon icon, final int x, final int y) {
		icon.paintIcon(null, g, x, y);
	}

	public void drawImage(final Image image, final int x, final int y) {
		g.drawImage(image, x, y, null);
	}

	/**
	 * @since 3.8.7
	 */
	public void drawPoint(final int x, final int y) {
		g.drawLine(x, y, x, y);
	}

	/**
	 * @since 3.8.7
	 */
	public void drawPoint(final Point p) {
		drawPoint(p.x, p.y);
	}

	/**
	 * @since 3.8.7
	 */
	public static void drawPoint(final Graphics g, final int x, final int y) {
		g.drawLine(x, y, x, y);
	}
	
	/**
	 * @since 3.8.11
	 */
	public void drawString(final String s, final int x, final int y) {
		g.drawString(s, x, y);
	}

	public void drawStringCentered(final String s, final int x, final int y, final int w, final int h) {
		drawStringCentered(s, x, y, w, h, g.getFontMetrics());
	}

	/**
	 * @since 4.10
	 */
	public void drawStringCentered(final String s, final int x, final int y, final int w, final int h, final FontMetrics fm) {
		g.drawString(
			s,
			x + (w / 2) - (fm.stringWidth(s) / 2),
			y + (h / 2) - (fm.getHeight() / 2) + fm.getAscent()
		);
	}

	public void drawStringCentered(final String s, final Component c) {
		drawStringCentered(s, 0, 0, c.getWidth(), c.getHeight());
	}
	
	/**
	 * @since 4.0
	 */
	public void fill(final Shape shape) {
		g.fill(shape);
	}

	/**
	 * @since 3.8.7
	 */
	public void fillRect() {
		if (_size != null)
			g.fillRect(0, 0, _size.width, _size.height);
	}

	/**
	 * @since 4.0
	 */
	public void fillRect(final Component c) {
		g.fillRect(0, 0, c.getWidth(), c.getHeight());
	}

	public static void fillRect(final Graphics g, final Component c) {
		g.fillRect(0, 0, c.getWidth(), c.getHeight());
	}

	/**
	 * @since 3.8.11
	 */
	public void fillRoundRect(final int x, final int y, final int w, final int h, final int arc) {
		g.fillRoundRect(x, y, w, h, arc, arc);
	}

	/**
	 * @since 3.8.11
	 */
	public FontMetrics getFontMetrics() {
		return g.getFontMetrics();
	}

	/**
	 * @since 3.8.7
	 */
	public Graphics2D getGraphics2D() { return g; }

	public void setAlpha(final float value) {
		g.setComposite(AlphaComposite.SrcOver.derive(value));
	}

	public void setAntialiasing(final boolean value) {
		UI.setAntialiasing(g, value);
	}

	public void setColor(final Color value) {
		g.setColor(value);
	}

	public void setFont(final Font value) {
		g.setFont(value);
	}

	public void setFont(final String name, final int style, final int size) {
		g.setFont(new Font(name, style, size));
	}

	/**
	 * @since 3.8.7
	 */
	public void setLineWidth(final int width) {
		g.setStroke(new BasicStroke(width));
	}

	public void setTextAntialiasing(final RenderingHints saveHints) {
		UI.setTextAntialiasing(g, saveHints);
	}
	
	// AutoCloseable
	
	/**
	 * @since 4.4
	 */
	@Override
	public void close() {
		dispose();
	}

	// MDisposable

	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		if (g != null) {
			g.dispose();
			g = null;
		}
	}

}
