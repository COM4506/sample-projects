// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicButtonUI;

import org.makagiga.commons.swing.MSmallButton;

final class SimpleButtonUI extends BasicButtonUI {

	// public
	
	@Override
	public void installUI(final JComponent c) {
		super.installUI(c);
		
		// HACK: NPE in HTML renderer with custom component view
		if (UI.isSeaGlass() && !c.isFontSet()) {
			c.setFont(UI.createDefaultFont());
		}
	}

	// protected

	@Override
	protected void paintFocus(
		final Graphics g,
		final AbstractButton b,
		final Rectangle viewRect,
		final Rectangle textRect,
		final Rectangle iconRect
	) {
		if (b instanceof MSmallButton)
			MSmallButton.class.cast(b).paintFocus((Graphics2D)g);
		else
			UI.paintFocus(b, (Graphics2D)g, null, 1);
	}

	@Override
	protected void paintText(final Graphics g, final AbstractButton b, final Rectangle textRect, final String text) {
		UI.setTextAntialiasing((Graphics2D)g, null);
		super.paintText(g, b, textRect, text);
	}

}
