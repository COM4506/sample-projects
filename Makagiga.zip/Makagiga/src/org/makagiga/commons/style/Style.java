// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.style;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Insets;
import java.awt.font.TextAttribute;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.text.JTextComponent;

import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.TriBoolean;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;

/**
 * @since 2.0
 */
public class Style {
	
	// private

	private boolean marginSingleValueSet;
	private boolean paddingSingleValueSet;
	private Border border;
	private Color backgroundColor;
	private Color borderColor;
	private Color color;
	private Cursor cursor;
	private Insets margin;
	private Insets padding;
	private int borderWidth = Integer.MIN_VALUE;
	private int fontSize;
	private int fontStyle;
	private int marginBottom = Integer.MIN_VALUE;
	private int marginLeft = Integer.MIN_VALUE;
	private int marginRight = Integer.MIN_VALUE;
	private int marginTop = Integer.MIN_VALUE;
	private int paddingBottom = Integer.MIN_VALUE;
	private int paddingLeft = Integer.MIN_VALUE;
	private int paddingRight = Integer.MIN_VALUE;
	private int paddingTop = Integer.MIN_VALUE;
	private Integer underlineValue;
	private static volatile Map<String, Color> colorNames;
	private static Map<String, Parser<Object>> parsers = TK.newHashMap(
		"cursor", new CursorParser(),
		"font-family", new FontFamilyParser()
	);
	private String fontName;
	private TriBoolean lineThrough = TriBoolean.UNDEFINED;
	
	// public

	/**
	 * Constructs and parses a new style.
	 *
	 * @param baseFont the base font for <i>name</i>, <i>size</i>, and <i>style</i> (can be @c null)
	 * @param style the style to parse
	 *
	 * @throws NullPointerException If @p style is @c null
	 * @throws ParseException If @p style is invalid
	 */
	public Style(final Font baseFont, final String style) throws ParseException {
		if (baseFont != null) {
			fontName = baseFont.getName();
			fontSize = baseFont.getSize();
			fontStyle = baseFont.getStyle();
		}
		parse(style);
	}
	
	public void apply(final Component c) throws ParseException {
		// border
		if (border != null) {
			if (c instanceof JComponent)
				JComponent.class.cast(c).setBorder(border);
			else
				MLogger.warning("style", "Ignoring \"border\" property for \"%s\" component", c);
		}
		
		// colors
		if (backgroundColor != null) {
			c.setBackground(backgroundColor);
			if (c instanceof JLabel)
				JLabel.class.cast(c).setOpaque(true);
		}
		if (color != null)
			c.setForeground(color);
		
		// cursor
		if (cursor != null)
			c.setCursor(cursor);
		
		// font
		Font oldFont = c.getFont();
		if (
			(oldFont != null) &&
			(
				lineThrough.isTrue() ||
				(underlineValue != null) ||
				(oldFont.getSize() != fontSize) ||
				(oldFont.getStyle() != fontStyle) ||
				(!oldFont.getName().equals(fontName))
			)
		) {
			Font newFont = new Font(fontName, fontStyle, TK.limit(fontSize, UI.getMinimumFontSize(), Integer.MAX_VALUE));
			Map<TextAttribute, Object> attr = null;

			if (lineThrough.isTrue()) {
				if (attr == null)
					attr = new HashMap<>();
				attr.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);
			}
			else if (underlineValue != null) {
				if (attr == null)
					attr = new HashMap<>();
				attr.put(TextAttribute.UNDERLINE, underlineValue);
			}

			if (attr != null)
				newFont = newFont.deriveFont(attr);
			c.setFont(newFont);
			//MLogger.debug("style", "FONT: %s -> %s", oldFont, newFont);
		}

		// margin
		if (marginSingleValueSet && (margin == null)) {
			if (c instanceof JComponent) {
				JComponent jc = (JComponent)c;
				Border b = jc.getBorder();
				if (b != null)
					margin = b.getBorderInsets(c);
				else
					margin = UI.createInsets(0);
			}
			else
				MLogger.warning("style", "Ignoring \"margin\" property for \"%s\" component", c);
		}
		if (margin != null) {
			if (marginSingleValueSet) {
				if (marginBottom != Integer.MIN_VALUE)
					margin.bottom = marginBottom;
				if (marginLeft != Integer.MIN_VALUE)
					margin.left = marginLeft;
				if (marginRight != Integer.MIN_VALUE)
					margin.right = marginRight;
				if (marginTop != Integer.MIN_VALUE)
					margin.top = marginTop;
			}

			if (c instanceof JComponent) {
				JComponent jc = (JComponent)c;
				jc.setBorder(BorderFactory.createEmptyBorder(margin.top, margin.left, margin.bottom, margin.right));
				//MLogger.debug("style", "BORDER: %s", jc.getBorder());
			}
			else
				MLogger.warning("style", "Ignoring \"margin\" property for \"%s\" component", c);
		}

		// padding
		if (paddingSingleValueSet && (padding == null)) {
			if (c instanceof AbstractButton) {
				AbstractButton ab = (AbstractButton)c;
				padding = ab.getMargin();
			}
			else if (c instanceof JTextComponent) {
				JTextComponent tc = (JTextComponent)c;
				padding = tc.getMargin();
			}
			else
				MLogger.warning("style", "Ignoring \"padding\" property for \"%s\" component", c);
		}
		if (padding != null) {
			if (paddingSingleValueSet) {
				if (paddingBottom != Integer.MIN_VALUE)
					padding.bottom = paddingBottom;
				if (paddingLeft != Integer.MIN_VALUE)
					padding.left = paddingLeft;
				if (paddingRight != Integer.MIN_VALUE)
					padding.right = paddingRight;
				if (paddingTop != Integer.MIN_VALUE)
					padding.top = paddingTop;
			}

			if (c instanceof AbstractButton) {
				AbstractButton ab = (AbstractButton)c;
				ab.setMargin(padding);
			}
			else if (c instanceof JTextComponent) {
				JTextComponent tc = (JTextComponent)c;
				tc.setMargin(padding);
			}
			else {
				if (!setBorder(c, padding))
					MLogger.warning("style", "Ignoring \"padding\" property for \"%s\" component", c);
			}
		}
		else {
			setBorder(c, null);
		}
	}

	public Color getBackgroundColor() { return backgroundColor; }
	
	public void setBackgroundColor(final Color value) { backgroundColor = value; }

	public Border getBorder() { return border; }
	
	public void setBorder(final Border value) { border = value; }
	
	public Color getColor() { return color; }
	
	public void setColor(final Color value) { color = value; }

	/**
	 * Returns the cursor or @c null.
	 */
	public Cursor getCursor() { return cursor; }

	/**
	 * Sets the cursor to @p value (can be @c null).
	 */
	public void setCursor(final Cursor value) { cursor = value; }

	/**
	 * Sets the cursor to @p value (example: @c Cursor.CROSSHAIR_CURSOR).
	 *
	 * @throws IllegalArgumentException If @p value is invalid
	 */
	public void setCursor(final int value) {
		cursor = Cursor.getPredefinedCursor(value);
	}
	
	public String getFontName() { return fontName; }
	
	public void setFontName(final String value) { fontName = value; }
	
	public int getFontSize() { return fontSize; }
	
	public void setFontSize(final int value) { fontSize = value; }
	
	public int getFontStyle() { return fontStyle; }
	
	public void setFontStyle(final int value) { fontStyle = value; }
	
	public Insets getMargin() { return margin; }
	
	public void setMargin(final Insets value) { margin = value; }
	
	public Insets getPadding() { return padding; }
	
	public void setPadding(final Insets value) { padding = value; }

	@InvokedFromConstructor
	public void parse(final String style) throws ParseException {
		if (fastPath(style))
			return;
	
		for (String token : TK.fastSplit(style, ';')) {
			token = token.trim();
			
			if (token.isEmpty())
				continue; // for
		
			String[] pair = TK.splitPair(
				token,
				':',
				TK.SPLIT_PAIR_NULL_ERROR | TK.SPLIT_PAIR_TRIM
			);
			if (pair == null)
				error("\":\" expected");
			
			String property = pair[0];
			String value = pair[1];

			Parser<Object> p = parsers.get(property);
			if (p != null) {
				p.update(this, p.parse(value));

				continue; // for
			}
			
			switch (property) {
			
			case "background-color":
				backgroundColor = parseColor(value);
				break;
			
			case "border":
				parseBorder(value);
				break;
			
			case "border-style":
				border = parseBorderStyle(value);
				break;

			case "color":
				color = parseColor(value);
				break;
			
			case "font-size":
				parseFontSize(value);
				break;
			
			case "font-style":
				parseFontStyle(value);
				break;
			
			case "font-weight":
				parseFontWeight(value);
				break;
			
			case "margin":
				parseMargin(value);
				break;

			case "margin-bottom":
				marginBottom = parseSize(value);
				marginSingleValueSet = true;
				break;

			case "margin-left":
				marginLeft = parseSize(value);
				marginSingleValueSet = true;
				break;

			case "margin-right":
				marginRight = parseSize(value);
				marginSingleValueSet = true;
				break;

			case "margin-top":
				marginTop = parseSize(value);
				marginSingleValueSet = true;
				break;

			case "padding":
				parsePadding(value);
				break;

			case "padding-bottom":
				paddingBottom = parseSize(value);
				paddingSingleValueSet = true;
				break;

			case "padding-left":
				paddingLeft = parseSize(value);
				paddingSingleValueSet = true;
				break;

			case "padding-right":
				paddingRight = parseSize(value);
				paddingSingleValueSet = true;
				break;

			case "padding-top":
				paddingTop = parseSize(value);
				paddingSingleValueSet = true;
				break;
			
			case "text-decoration":
				parseTextDecoration(value);
				break;

			default:
				error("Unknown property: " + property);
			
			} // switch
			
			//MLogger.debug("style", "\"%s\"=\"%s\"", property, value);
		}
	}
	
	// private
	
	private void error(final String message) throws ParseException {
		throw new ParseException(message, 0);
	}
	
	private boolean fastPath(final String style) {
		// shortcuts for frequently used styles
		switch (style) {
			case "font-style: italic":
				fontStyle |= Font.ITALIC;
			
				return true;
			case "font-style: normal":
				fontStyle &= ~Font.ITALIC;
				
				return true;
			case "font-weight: normal":
				fontStyle &= ~Font.BOLD;
			
				return true;
			case "font-weight: bold":
				fontStyle |= Font.BOLD;
	
				return true;
		}
		
		return false;
	}
	
	private void parseBorder(final String value) throws ParseException {
		List<String> args = TK.fastSplit(value, ' ');
				
		if (args.size() != 3)
			error("\"<width> solid <color>\" expected");
				
		String borderStyle = args.get(1);
				
		if (!"solid".equals(borderStyle))
			error("Invalid border style value: " + value);
				
		borderWidth = parseSize(args.get(0));
		borderColor = parseColor(args.get(2));
	}
	
	private Border parseBorderStyle(final String value) throws ParseException {
		switch (value) {
			case "inset": return BorderFactory.createLoweredBevelBorder();
			case "outset": return BorderFactory.createRaisedBevelBorder();
			default: throw new ParseException("Invalid \"border-style\" value: " + value, 0);
		}
	}

	/**
	 * Color Names:
	 * http://www.w3schools.com/css/css_colornames.asp
	 */
	private Color parseColor(final String value) throws ParseException {
		if (TK.isEmpty(value))
			error("Color value is null or empty");

		if (value.charAt(0) == '#')
			return ColorProperty.parseColor(value);
		
		Color result;
		synchronized (Style.class) {
			if (colorNames == null) {
				colorNames = TK.newHashMap(
					"aqua", Color.CYAN,
					"black", Color.BLACK,
					"blue", Color.BLUE,
					"fuchsia", Color.MAGENTA,
					"gray", Color.GRAY,
					"green", new Color(0x008000),
					"lime", Color.GREEN,
					"maroon", new Color(0x800000),
					"navy", new Color(0x000080),
					"olive", new Color(0x808000),
					"purple", new Color(0x800080),
					"red", Color.RED,
					"silver", new Color(0xC0C0C0),
					"teal", new Color(0x008080),
					"white", Color.WHITE,
					"yellow", Color.YELLOW
				);
			}
			result = colorNames.get(value);
		}
		
		if (result == null)
			result = UIManager.getColor(value);
		
		return result;
	}

	private void parseFontSize(final String value) throws ParseException {
		switch (value) {
			case "smaller":
				fontSize--;
				break;
			case "larger":
				fontSize++;
				break;
			case "x-large":
				fontSize += 2;
				break;
			case "xx-large":
				fontSize += 10;
				break;
			default:
				fontSize = parseSize(value);
				break;
		}
	}
	
	private void parseFontStyle(final String value) throws ParseException {
		switch (value) {
			case "italic":
				fontStyle |= Font.ITALIC;
				break;
			case "normal":
				fontStyle &= ~Font.ITALIC;
				break;
			default:
				error("Invalid \"font-style\" value: " + value);
		}
	}
	
	private void parseFontWeight(final String value) throws ParseException {
		switch (value) {
			case "bold":
				fontStyle |= Font.BOLD;
				break;
			case "normal":
				fontStyle &= ~Font.BOLD;
				break;
			default:
				error("Invalid \"font-weight\" value: " + value);
				break;
		}
	}

	private Insets parseInsets(final String value) throws ParseException {
		if (!value.contains(" "))
			return null;
		
		List<String> values = TK.fastSplit(value, ' ');

		if (values.size() != 4)
			error("Expected 4, space-separated values: " + value);
		
		Insets insets = UI.createInsets(0);
		insets.top = parseSize(values.get(0));
		insets.right = parseSize(values.get(1));
		insets.bottom = parseSize(values.get(2));
		insets.left = parseSize(values.get(3));
		
		return insets;
	}

	private void parseMargin(final String value) throws ParseException {
		Insets insets = parseInsets(value);
		if (insets != null) {
			margin = insets;
			marginSingleValueSet = false;
		}
		else {
			int i = parseSize(value);
			margin = UI.createInsets(i);
			marginSingleValueSet = false;
		}
	}
	
	private void parsePadding(final String value) throws ParseException {
		Insets insets = parseInsets(value);
		if (insets != null) {
			padding = insets;
			paddingSingleValueSet = false;
		}
		else {
			int i = parseSize(value);
			padding = UI.createInsets(i);
			paddingSingleValueSet = false;
		}
	}

	private int parseSize(final String value) throws ParseException {
		try {
			return Integer.parseInt(TK.removeSuffix(value, "px"));
		}
		catch (NumberFormatException exception) {
			error("Invalid size value: " + value);
			
			return -1;
		}
	}
	
	private void parseTextDecoration(final String value) throws ParseException {
		switch (value) {
			case "line-through":
				lineThrough = TriBoolean.TRUE;
				underlineValue = -1;
				break;
			case "none":
				lineThrough = TriBoolean.FALSE;
				underlineValue = -1;
				break;
			case "underline":
				lineThrough = TriBoolean.FALSE;
				underlineValue = TextAttribute.UNDERLINE_ON;
				break;
			default:
				error("Invalid \"text-decoration\" value: " + value);
				break;
		}
	}
	
	private boolean setBorder(final Component component, final Insets padding) {
		if ((borderColor == null) || (borderWidth == Integer.MIN_VALUE))
			return false;
	
		if (!(component instanceof JComponent)) {
			MLogger.warning("style", "Ignoring \"border\" property for \"%s\" component", component);
		
			return false;
		}
		
		JComponent c = (JComponent)component;
		Border b = BorderFactory.createLineBorder(borderColor, borderWidth);
		if (padding == null) {
			c.setBorder(b);
		}
		else {
			c.setBorder(BorderFactory.createCompoundBorder(
				b,
				BorderFactory.createEmptyBorder(padding.top, padding.left, padding.bottom, padding.right)
			));
		}
		
		return true;
	}

	// private classes

	private static final class CursorParser implements Parser<Integer> {

		// private

		private final Map<String, Integer> map = TK.newHashMap(
			"crosshair", Cursor.CROSSHAIR_CURSOR,
			"default", Cursor.DEFAULT_CURSOR,
			"move", Cursor.MOVE_CURSOR,
			"hand", Cursor.HAND_CURSOR,
			"pointer", Cursor.HAND_CURSOR,
			"text", Cursor.TEXT_CURSOR,
			"wait", Cursor.WAIT_CURSOR
		);

		// public

		@Override
		public Integer parse(final String value) throws ParseException {
			Integer result = map.get(value);
			
			if (result == null)
				throw new ParseException("Invalid \"cursor\" value: " + value, 0);

			return result;
		}

		@Override
		public void update(final Style style, final Integer value) {
			style.setCursor(value);
		}

	}

	private static final class FontFamilyParser implements Parser<String> {

		// public

		@Override
		public String parse(final String value) throws ParseException {
			if ("monospace".equals(value))
				return UI.getMonospacedFontName();

			return value;
		}

		@Override
		public void update(final Style style, final String value) {
			style.setFontName(value);
		}

	}

	private static interface Parser<T> {

		// public

		public T parse(final String value) throws ParseException;

		public void update(final Style style, final T value);

	}
	
}
