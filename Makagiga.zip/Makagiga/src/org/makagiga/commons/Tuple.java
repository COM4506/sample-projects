// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;
import java.util.function.BiConsumer;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.annotation.Important;

/**
 * @since 3.8.4
 */
public abstract class Tuple implements Serializable {

	// protected

	protected Object[] array;

	// private

	private transient int hash;
	
	// public

	@Override
	public final boolean equals(final Object o) {
		if (o == this)
			return true;

		if (!(o instanceof Tuple))
			return false;

		return Arrays.equals(this.array, Tuple.class.cast(o).array);
	}

	@Override
	public final int hashCode() {
		if (hash == 0)
			hash = Arrays.hashCode(array);

		return hash;
	}

	public final Object get(final int index) { return array[index]; }

	public static <T1, T2> Tuple.Two<T1, T2> of(final T1 o1, final T2 o2) {
		return new Two<>(o1, o2);
	}

	public static <T1, T2, T3> Tuple.Three<T1, T2, T3> of(final T1 o1, final T2 o2, final T3 o3) {
		return new Three<>(o1, o2, o3);
	}

	public static <T1, T2, T3, T4> Tuple.Four<T1, T2, T3, T4> of(final T1 o1, final T2 o2, final T3 o3, final T4 o4) {
		return new Four<>(o1, o2, o3, o4);
	}
	
	/**
	 * @since 4.4
	 *
	 * @see TK#splitPair(String, char, int)
	 */
	public static Tuple.Two<String, String> split(final String s, final char separator, final int splitPairOptions) {
		String[] pair = TK.splitPair(s, separator, splitPairOptions);
		
		if (pair == null)
			return null;
		
		return new Tuple.Two<>(pair);
	}

	/**
	 * @since 4.4
	 *
	 * @see TK#splitPair(String, char, int)
	 */
	public static Tuple.Two<String, String> split(final String s, final char separator) {
		return split(s, separator, 0);
	}

	public final int size() { return array.length; }

	@Important
	@Override
	public final String toString() {
		return toString(", ");
	}

	/**
	 * @since 4.0
	 */
	@SuppressWarnings("deprecation")
	public final String toString(final String separator) {
		return TK.toString(array, separator);
	}

	public final Object[] values() { return array.clone(); }

	// private

	@SuppressWarnings("PMD.ArrayIsStoredDirectly")
	private Tuple(final Object[] arrayRef) {
		array = arrayRef;
	}

	private Tuple(final int size) {
		this.array = new Object[size];
	}

	// public classes

	@SuppressWarnings("unchecked")
	public static final class Two<T1, T2> extends Tuple implements Map.Entry<T1, T2> {
	
		// public

		/**
		 * @since 5.0
		 */
		public void accept(final BiConsumer<T1, T2> consumer) {
			consumer.accept(get1(), get2());
		}

		public T1 get1() { return (T1)array[0]; }
		
		@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
		public T2 get2() { return (T2)array[1]; }
		
		// Map.Entry
		
		/**
		 * @since 4.6
		 */
		@Override
		public T1 getKey() { return get1(); }

		/**
		 * @since 4.6
		 */
		@Override
		public T2 getValue() { return get2(); }
		
		/**
		 * Unsupported (read only).
		 *
		 * @throws UnsupportedOperationException Always
		 *
		 * @since 4.6
		 */
		@Override
		public T2 setValue(final T2 value) {
			throw new UnsupportedOperationException();
		}
		
		// private
		
		private Two(final Object[] arrayRef) {
			super(arrayRef);
		}
		private Two(final T1 o1, final T2 o2) {
			super(2);
			array[0] = o1;
			array[1] = o2;
		}
	}

	@SuppressWarnings("unchecked")
	public static final class Three<T1, T2, T3> extends Tuple {

		// public

		/**
		 * @since 5.0
		 */
		public void accept(final Consumer<T1, T2, T3> consumer) {
			consumer.accept(get1(), get2(), get3());
		}

		public T1 get1() { return (T1)array[0]; }
		
		@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
		public T2 get2() { return (T2)array[1]; }
		
		@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
		public T3 get3() { return (T3)array[2]; }
		
		// private
		
		private Three(final T1 o1, final T2 o2, final T3 o3) {
			super(3);
			array[0] = o1;
			array[1] = o2;
			array[2] = o3;
		}

		// public classes
		
		/**
		 * @since 5.0
		 */
		@FunctionalInterface
		public static interface Consumer<T1, T2, T3> {

			// public
			
			public void accept(final T1 t1, final T2 t2, final T3 t3);

		}

	}

	@SuppressWarnings("unchecked")
	public static final class Four<T1, T2, T3, T4> extends Tuple {
		public T1 get1() { return (T1)array[0]; }
		
		@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
		public T2 get2() { return (T2)array[1]; }
		
		@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
		public T3 get3() { return (T3)array[2]; }
		
		@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
		public T4 get4() { return (T4)array[3]; }
		
		private Four(final T1 o1, final T2 o2, final T3 o3, final T4 o4) {
			super(4);
			array[0] = o1;
			array[1] = o2;
			array[2] = o3;
			array[3] = o4;
		}
	}

}
