// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.makagiga.commons.annotation.InvokedFromConstructor;

/**
 * A low-level configuration file support.
 *
 * @mg.threadSafe
 *
 * @since 3.0
 */
public class ConfigFile
implements
	ElementList,
	Iterable<ConfigFile.Element>,
	Serializable
{
	
	// public
	
	public static final String APPLICATION_TYPE_VALUE = "Application";
	public static final String DIRECTORY_TYPE_VALUE = "Directory";
	public static final String LINK_TYPE_VALUE = "Link";
	
	/**
	 * A configuration format.
	 */
	public enum Format {
		
		// public
	
// TODO: 3.0: Desktop Entry/Exec key
		/**
		 * @see <a href="http://standards.freedesktop.org/desktop-entry-spec/latest/index.html">Desktop Entry format, version 1.1-draft (2008/10/21)</a>
		 */
		DESKTOP(true, ".desktop", "\n", "#", "[A-Za-z0-9\\-]+"),
		
		/**
		 * @see <a href="http://en.wikipedia.org/wiki/INI_file">Windows INI format</a>
		 */
		INI(false, ".ini", "\r\n", ";", null);
				
		// private
		
		private final boolean caseSensitive;
		private final Pattern keyPattern;
		private final String comment;
		private final String eol;
		private final String suffix;
		
		// public
		
		public boolean equals(final String s1, final String s2) {
			if (caseSensitive)
				return s1.equals(s2);
			
			return s1.equalsIgnoreCase(s2);
		}

		public static String escape(final String value) {
			if (value == null)
				return null;

			int len = value.length();

			if (len == 0)
				return value;

			StringBuilder buf = new StringBuilder(len + (len / 2));
			for (int index = 0; index < len; index++) {
				char i = value.charAt(index);
				switch (i) {
					case ' ':
						buf.append("\\s");
						break;
					case '\n':
						buf.append("\\n");
						break;
					case '\r':
						buf.append("\\r");
						break;
					case '\t':
						buf.append("\\t");
						break;
					case '\\':
						buf.append("\\\\");
						break;
/* TODO: "Some keys can have multiple values.
In such a case, the value of the key is specified as a plural: for example, string(s).
The multiple values should be separated by a semicolon,
and the value of the key should have a semicolon as trailing character.
Semicolons in these values need to be escaped using \;."
					case ';':
						buf.append("\\;");
						break;
*/
					default:
						buf.append(i);
				}
			}

			return buf.toString();
		}

		public String escapeValue(final String value) {
			switch (this) {
				case DESKTOP:
					return escape(value);
				case INI:
					return value;
				default:
					throw new WTFError(this);
			}
		}

		/**
		 * @since 4.0
		 */
		public static String unescape(final String value) {
			if (value == null)
				return null;

			int len = value.length();

			if (len == 0)
				return value;

			boolean inEscape = false;
			StringBuilder buf = new StringBuilder(len);
			for (int index = 0; index < len; index++) {
				char i = value.charAt(index);
				switch (i) {
					case '\\':
						if (inEscape) {
							buf.append('\\');
							inEscape = false;
						}
						else {
							inEscape = true;
						}
						break;
					default:
						if (inEscape) {
							switch (i) {
								case 's':
									buf.append(' ');
									break;
								case 'n':
									buf.append('\n');
									break;
								case 'r':
									buf.append('\r');
									break;
								case 't':
									buf.append('\t');
									break;
								case '\\':
									buf.append('\\');
									break;
							}
							inEscape = false;
						}
						else {
							buf.append(i);
						}
				}
			}

			return buf.toString();
		}

		public String unescapeValue(final String value) {
			switch (this) {
				case DESKTOP:
					return unescape(value);
				case INI:
					return value;
				default:
					throw new WTFError(this);
			}
		}

		/**
		 * Returns the comment identifier (e.g. "#").
		 */
		public String getComment() { return comment; }

		/**
		 * Returns the EOL (e.g. "\n").
		 */
		public String getEOL() { return eol; }

		/**
		 * Returns the preferred file name suffix/extension (e.g. ".desktop").
		 */
		public String getSuffix() { return suffix; }
		
		public boolean isCaseSensitive() { return caseSensitive; }

		/**
		 * Check if @p group is valid.
		 * 
		 * @throws IllegalArgumentException If @p group is invalid
		 */
		public String validateGroup(final String group) {
			TK.checkNullOrEmpty(group);
			
			// SPEC: "Group names may contain all ASCII characters except for [ and ] and control characters."
			if (this == DESKTOP) {
				for (int i = 0; i < group.length(); i++) {
					char c = group.charAt(i);

					if ((c == '[') || (c == ']'))
						throw new IllegalArgumentException("Group name contains \"[\" or \"]\" character: " + group);

					if (Character.isISOControl(c))
						throw new IllegalArgumentException("Group name contains a \"control character\": 0x" + Integer.toHexString(c));
				}
			}

/* DEAD:
			if ((groupPattern != null) && !groupPattern.matcher(group).matches())
				throw new IllegalArgumentException("Group \"" + group + "\" does not match a valid pattern: " + groupPattern);
*/

			return group;
		}

		/**
		 * Check if @p key is valid.
		 * 
		 * @throws IllegalArgumentException If @p key is invalid
		 */
		public String validateKey(final String key) {
			TK.checkNullOrEmpty(key);
			
			// SPEC: "Only the characters A-Za-z0-9- may be used in key names."
			if ((keyPattern != null) && !keyPattern.matcher(key).matches())
				throw new IllegalArgumentException("Key \"" + key + "\" does not match a valid pattern: " + keyPattern);
			
			return key;
		}

		// private
		
		private Format(final boolean caseSensitive, final String suffix, final String eol, final String comment, final String keyPattern) {
			this.caseSensitive = caseSensitive;
			this.suffix = suffix;
			this.eol = eol;
			this.comment = comment;
			//this.groupPattern = (groupPattern == null) ? null : Pattern.compile(groupPattern);
			this.keyPattern = (keyPattern == null) ? null : Pattern.compile(keyPattern);
		}
	
	}
	
	// private
	
	private Charset encoding = StandardCharsets.UTF_8;
	private final Format format;
	private final MArrayList<Element> elements = new MArrayList<>(32);
	
	// public
	
	/**
	 * Constructs a new empty configuration with @c DESKTOP format.
	 */
	public ConfigFile() {
		this(Format.DESKTOP);
	}

	/**
	 * Constructs a new empty configuration with @p format.
	 * 
	 * @throws NullPointerException If @p format is @c null
	 */
	public ConfigFile(final ConfigFile.Format format) {
		this.format = Objects.requireNonNull(format);
	}
	
	@Override
	public synchronized void add(final ConfigFile.Element e) {
		elements.add(e);
	}

	public synchronized List<ConfigFile.Element> get() { return elements; }

	public synchronized ConfigFile.Group get(final String name) {
		Group group = null;
		for (Element i : this) {
			if (i instanceof Group) {
				group = (Group)i;
				if (format.equals(group.getValue(), name)) {
					break; // for
				}
				else {
					group = null;
				}
			}
		}
		
		if (group == null) {
			group = new Group(getFormat(), name);
			add(group);
		}
		
		return group;
	}

	/**
	 * Returns the configuration read/write encoding.
	 * The default encoding is "UTF-8".
	 */
	public String getEncoding() {
		return encoding.name();
	}

	/**
	 * Sets the reader/writer encoding to {@code value}.
	 */
	public void setEncoding(final String value) {
		try {
			encoding = Charset.forName(value);
		}
		catch (UnsupportedCharsetException exception) {
			MLogger.exception(exception);
		}
	}

	/**
	 * Returns the configuration format.
	 */
	public ConfigFile.Format getFormat() { return format; }

	/**
	 * @since 4.0
	 */
	public BufferedReader newReader(final InputStream input) throws IOException {
		return new FS.TextReader(input, encoding);
	}

	/**
	 * @since 4.0
	 */
	public Writer newWriter(final OutputStream output) throws IOException {
		return new FS.TextWriter(output, encoding);
	}

	public ConfigFile.Group setDesktopEntry(final String type, final String name) {
		Group group = get("Desktop Entry");
		group.set("Version", "1.0");
		group.set("Type", type);
		group.set("Name", name);
		// NOTE: Encoding=UTF-8 is deprecated

		return group;
	}
	
	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder(1024);
		synchronized (this) {
			for (Element i : this)
				buf.append(i);
		}
		
		return buf.toString();
	}
	
	public void read(final BufferedReader reader) throws IOException {
		ElementList elementList = this;
		String line;
		while ((line = reader.readLine()) != null) {
			String trimLine = line.trim();
			
			// empty line
			
			if (trimLine.isEmpty()) {
				elementList.add(new Unknown(format, line));
				
				continue; // while
			}
			
			// comment
			
			if (trimLine.startsWith(format.getComment())) {
				elementList.add(new Comment(format, line));
				
				continue; // while
			}
			
			// group
			
			if (
				(trimLine.length() > 2) &&
				(trimLine.charAt(0) == '[') &&
				(trimLine.charAt(trimLine.length() - 1) == ']')
			) {
				Group group = new Group(format, trimLine.substring(1, trimLine.length() - 1).trim());
				elementList = group;
				add(group);
				
				continue; // while
			}
			
			// key
			
			int sepIndex = trimLine.indexOf('=');
			if (sepIndex != -1) {
				String key = trimLine.substring(0, sepIndex).trim();

				int localeIndex1 = key.indexOf('[');
				String locale = null;
				if (localeIndex1 != -1) {
					int localeIndex2 = key.indexOf(']', localeIndex1);
					if (localeIndex2 > localeIndex1) {
						locale = key.substring(localeIndex1 + 1, localeIndex2);
						key = key.substring(0, localeIndex1);
					}
				}

				String value = trimLine.substring(sepIndex + 1).trim();
				elementList.add(new Entry(format, key, format.unescapeValue(value), locale));
				
				continue; // while
			}
			
			elementList.add(new Unknown(format, line));
		}
	}

	public void read(final File file) throws IOException {
		try (BufferedReader reader = new FS.TextReader(new FileInputStream(file), encoding)) {
			read(reader);
		}
	}

	public void write(final File file) throws IOException {
		try (Writer writer = new FS.TextWriter(new FileOutputStream(file), encoding)) {
			write(writer);
		}
	}

	public void write(final Writer writer) throws IOException {
		writer.write(toString());
	}

	// Iterable

	/**
	 * Returns all elements.
	 */
	@Override
	public synchronized Iterator<ConfigFile.Element> iterator() {
		return elements.iterator();
	}

	// public classes

	/**
	 * An immutable comment element.
	 */
	public static final class Comment extends Element {
		
		// public

		/**
		 * Constructs a new comment.
		 * 
		 * @param format the comment format
		 * @param value the comment value
		 * 
		 * @throws NullPointerException If @p format or @p value is @c null
		 */
		public Comment(final ConfigFile.Format format, final String value) {
			super(format, value);
		}

	}
	
	/**
	 * An abstract element.
	 */
	public static abstract class Element implements Serializable {
	
		// private
		
		private final Format format;
		private String _value;
		
		// public

		/**
		 * Constructs a new element.
		 * 
		 * @param format the element format
		 * @param value the element value
		 * 
		 * @throws NullPointerException If @p format or @p value is @c null
		 */
		public Element(final ConfigFile.Format format, final String value) {
			this.format = Objects.requireNonNull(format);
			setValue(value);
		}
		
		@Override
		public boolean equals(final Object o) {
			if (this == o)
				return true;

			if (!(o instanceof Element))
				return false;

			return this.getValue().equals(Element.class.cast(o).getValue());
		}
		
		/**
		 * Returns the element format.
		 */
		public ConfigFile.Format getFormat() { return format; }

		/**
		 * Returns a non-null value.
		 */
		public synchronized String getValue() { return _value; }

		@Override
		public int hashCode() {
			return Objects.hashCode(getValue());
		}

		/**
		 * Returns a non-null value suffixed with "EOL" character.
		 */
		@Override
		public String toString() {
			return getValue().concat(getFormat().getEOL());
		}
		
		// protected

		/**
		 * @throws NullPointerException If @p value is @c null
		 */
		@InvokedFromConstructor
		protected synchronized void setValue(final String value) {
			this._value = Objects.requireNonNull(value);
		}

	}

	public static final class Entry extends Element {

		// private
		
		private final String key;
		private final String locale;
		
		// public

		/**
		 * Constructs a new entry element.
		 * 
		 * @param format the element format
		 * 
		 * @throws IllegalArgumentException If @p key is invalid
		 * @throws NullPointerException If @p format is @c null
		 * @throws NullPointerException If @p value is @c null
		 */
		public Entry(final ConfigFile.Format format, final String key, final String value) {
			this(format, key, value, null);
		}

		/**
		 * @since 3.8.4
		 */
		public Entry(final ConfigFile.Format format, final String key, final String value, final String locale) {
			super(format, value);
			this.key = format.validateKey(key);
			this.locale = locale;
		}

		@Override
		public boolean equals(final Object o) {
			if (this == o)
				return true;

			if ((o == null) || (this.getClass() != o.getClass()))
				return false;

			Entry other = (Entry)o;

			return
				getFormat().equals(this.key, other.key) &&
				Objects.equals(this.locale, other.locale) &&
				this.getValue().equals(other.getValue());
		}

		public String getKey() { return key; }

		/**
		 * @since 3.8.4
		 */
		public String getLocale() { return locale; }
		
		@Override
		public synchronized int hashCode() {
			return Objects.hash(key, locale, getValue());
		}

		@Override
		public String toString() {
			StringBuilder buf = new StringBuilder(64);
			
			buf
				.append(key);

			if (locale != null) {
				buf.append('[').append(locale).append(']');
			}

			buf
				.append('=')
				.append(getFormat().escapeValue(getValue()))
				.append(getFormat().getEOL());
			
			return buf.toString();
		}

	}

	public static final class Group extends Element
	implements
		ElementList,
		Iterable<ConfigFile.Element>
	{
		
		// private
		
		private final MArrayList<Element> elements = new MArrayList<>(16);
		
		// public

		/**
		 * @throws IllegalArgumentException If @p value is invalid
		 */
		public Group(final ConfigFile.Format format, final String value) {
			super(format, format.validateGroup(value));
		}

		@Override
		public synchronized void add(final ConfigFile.Element e) {
			elements.add(e);
		}

		public synchronized List<ConfigFile.Element> get() { return elements; }

		public String get(final String key, final String defaultValue) {
			synchronized (this) {
				for (Element i : this) {
					if (i instanceof Entry) {
						Entry entry = (Entry)i;

						if (entry.getKey().equals(key))//!!!
							return entry.getValue();
					}
				}
			}
			
			return defaultValue;
		}
		
		public boolean getBoolean(final String key, final boolean defaultValue) {
			String value = get(key, null);
			
			if (value == null)
				return defaultValue;
				
			try {
				return BooleanProperty.parseBoolean(value);
			}
			catch (ParseException exception) {
				return defaultValue;
			}
		}

		/**
		 * @since 4.0
		 */
		public float getFloat(final String key, final float defaultValue) {
			try {
				String value = get(key, null);

				if (value == null)
					return defaultValue;

				return Float.parseFloat(value);
			}
			catch (Exception exception) {
				MLogger.exception(exception);
			
				return defaultValue;
			}
		}

		/**
		 * @since 3.8.12
		 */
		public int getInteger(final String key, final int defaultValue) {
			try {
				String value = get(key, null);

				if (value == null)
					return defaultValue;

				return Integer.parseInt(value);
			}
			catch (Exception exception) {
				MLogger.exception(exception);
			
				return defaultValue;
			}
		}

		public void set(final String key, final boolean value) {
			set(key, Boolean.toString(value));
		}

		/**
		 * @since 4.0
		 */
		public void set(final String key, final float value) {
			set(key, Float.toString(value));
		}

		/**
		 * @since 3.8.12
		 */
		public void set(final String key, final int value) {
			set(key, Integer.toString(value));
		}

		/**
		 * @throws NullPointerException If @p value is @c null
		 */
		public void set(final String key, final String value) {
			Entry entry = null;
			synchronized (this) {
				for (Element i : this) {
					if (i instanceof Entry) {
						entry = (Entry)i;
						if (entry.getKey().equals(key)) {//!!!
							entry.setValue(value);

							return;
						}
						else {
							entry = null;
						}
					}
				}
			}

			if (entry == null)
				add(new Entry(getFormat(), key, value));
		}

		@Override
		public String toString() {
			StringBuilder buf = new StringBuilder(1024);
			
			buf
				.append('[')
				.append(getValue())
				.append(']')
				.append(getFormat().getEOL());
			synchronized (this) {
				for (Element i : this)
					buf.append(i);
			}
			
			return buf.toString();
		}
		
		// Iterable

		/**
		 * Returns all group elements.
		 */
		@Override
		public synchronized Iterator<ConfigFile.Element> iterator() {
			return elements.iterator();
		}
		
	}
	
	public static final class Unknown extends Element {
		
		// public

		/**
		 * Constructs a new unknown element.
		 * 
		 * @param format the comment format
		 * @param value the comment value
		 * 
		 * @throws NullPointerException If @p format or @p value is @c null
		 */
		public Unknown(final ConfigFile.Format format, final String value) {
			super(format, value);
		}

	}

}

// package private classes

interface ElementList {
	
	// public
	
	public void add(final ConfigFile.Element e);
	
}
