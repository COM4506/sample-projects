// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.net.URI;
import java.util.Objects;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.Net;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.sb.SecureOpen;

/**
 * @since 3.8.3, 4.0 (org.makagiga.commons.swing package)
 */
public class MLinkAction extends MAction implements SecureOpen {

	// private

	private boolean secureOpen;
	private String lazyURI;
	private URI uri;

	// public

	/**
	 * @since 3.8.7
	 */
	public MLinkAction() { }
	
	public MLinkAction(final URI uri) {
		this(uri, TK.centerSqueeze(simplifyURI(uri.toString()), 100));
	}

	public MLinkAction(final URI uri, final String text) {
		super(text);
		setURI(uri);
	}

	/**
	 * @since 4.0
	 */
	public URI getURI() {
		if (uri == null) {
			uri = Net.fixURI(lazyURI);
			lazyURI = null;
		}

		return uri;
	}
	
	/**
	 * @since 4.0
	 */
	public void setURI(final String value) {
		lazyURI = Objects.requireNonNull(value);
		uri = null;
		setHelpText(UI.getLinkToolTipText(lazyURI));
	}

	/**
	 * @since 4.0
	 */
	@InvokedFromConstructor
	public void setURI(final URI value) {
		uri = Objects.requireNonNull(value);
		lazyURI = null;
		setHelpText(UI.getLinkToolTipText(uri.toString()));
	}

	@Override
	public void onAction() {
		try {
			MApplication.openURI(getURI(), this);
		}
		catch (IllegalArgumentException exception) { // malformed lazy URI
			showErrorMessage(exception);
		}
	}

	/**
	 * @since 4.2
	 */
	public static String simplifyURI(final String uri) {
		String s = uri;
		s = TK.removePrefix(s, "http://www.");
		s = TK.removePrefix(s, "http://");

		s = TK.removePrefix(s, "https://www.");
		s = TK.removePrefix(s, "https://");

		return TK.removeSuffix(s, '/');
	}

	// SecureOpen

	/**
	 * @mg.default {@code false} since 3.8.6
	 */
	@Override
	public boolean isSecureOpen() { return secureOpen; }

	@Override
	public void setSecureOpen(final boolean value) { secureOpen = value; }

}
