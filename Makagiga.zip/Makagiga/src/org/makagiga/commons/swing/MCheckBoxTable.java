// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Window;
import java.util.Collection;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.mv.BooleanRenderer;
import org.makagiga.commons.mv.MRenderer;

/**
 * A simple table with check box/value colums.
 *
 * The "check box" column can be selected (set to {@code false} or {@code true}) by user.
 * The "value" column is read only.
 *
 * @since 3.8.4, 4.0 (org.makagiga.commons.swing package)
 */
public class MCheckBoxTable<T> extends MTable<MCheckBoxTable.CheckBoxModel<T>> {
	
	// public
	
	public MCheckBoxTable(final String checkBoxColumnName, final String valueColumnName, final boolean selectAll, final Collection<T> collection) {
		super(new CheckBoxModel<>(checkBoxColumnName, valueColumnName, selectAll, collection));
		setAutoCreateRowSorter(true);
		getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		setGridVisible(false);

		JTableHeader h = getTableHeader();
		h.setReorderingAllowed(false);
		h.setResizingAllowed(false);

		TableColumnModel tcm = getColumnModel();
		TableColumn checkBoxColumn = tcm.getColumn(CheckBoxModel.CHECK_BOX_COLUMN);
		checkBoxColumn.sizeWidthToFit();
		checkBoxColumn.setMaxWidth(checkBoxColumn.getWidth() + 30);

		BooleanRenderer checkBoxRenderer = new BooleanRenderer();
		checkBoxRenderer.setAutoDisable(true);
		checkBoxColumn.setCellRenderer(checkBoxRenderer);
		
		MRenderer<T> renderer = new MRenderer<T>(
			(self, value) -> self.setText(String.valueOf(value))
		);
		renderer.setHTMLEnabled(false);
		tcm.getColumn(CheckBoxModel.VALUE_COLUMN).setCellRenderer(renderer);
	}

	/**
	 * @since 3.8.8
	 */
	public MDialog createDialog(final Window owner, final String title, final String tableLabel, final MActionInfo okActionInfo) {
		MDialog dialog = new MDialog(owner, title, MDialog.SIDE_BUTTONS | MDialog.STANDARD_DIALOG);
		dialog.setDefaultFocus(this);
		dialog.getOKButton().setActionInfoUI(okActionInfo);

		dialog.addNorth(MLabel.createFor(this, tableLabel));
		dialog.addCenter(this);

		MPanel p = MPanel.createSimplePanel();
		p.getSimpleLayout()
			.setContentGap();
		
		MTableFilterPanel filterPanel = new MTableFilterPanel(this) {
			@Override
			protected RowFilter<?, ?> createFilter() {
				return this.createFilter(CheckBoxModel.VALUE_COLUMN);
			}
		};
		p.add(filterPanel);

		MButton selectAllButton = new MButton(MActionInfo.SELECT_ALL.getText());
		selectAllButton.addActionListener(e -> setAllSelected(true));
		p.add(selectAllButton);

		MButton unselectAllButton = new MButton(MActionInfo.UNSELECT_ALL.getText());
		unselectAllButton.addActionListener(e -> setAllSelected(false));
		p.add(unselectAllButton);

		dialog.getButtonsPanel().add(p);

		dialog.setSize(UI.WindowSize.LARGE);

		return dialog;
	}

	public boolean isCheckBoxSelected(final int viewRow) {
		return getModel().isSelected(convertRowIndexToModel(viewRow));
	}

	public void setCheckBoxSelected(final int viewRow, final boolean value) {
		getModel().setSelected(convertRowIndexToModel(viewRow), value);
	}

	/**
	 * @since 3.8.8
	 */
	public void setAllSelected(final boolean selected) {
		for (CheckBoxItem<T> i : getModel())
			i.setSelected(selected);
		getModel().fireTableDataChanged();
	}

	// public

	public static final class CheckBoxItem<T> {

		// private

		private boolean selected;
		private final T value;
		
		// public
		
		public T getValue() { return value; }
		
		public boolean isSelected() { return selected; }
		
		public void setSelected(final boolean value) { selected = value; }
		
		// private
		
		private CheckBoxItem(final T value, final boolean selected) {
			this.value = value;
			this.selected = selected;
		}

	}

	public static final class CheckBoxModel<T> extends AbstractListTableModel<CheckBoxItem<T>> {
	
		// public
		
		/**
		 * @since 4.8
		 */
		public static final int CHECK_BOX_COLUMN = 0;
		
		/**
		 * @since 4.8
		 */
		public static final int VALUE_COLUMN = 1;

		// public

		@Override
		public Object getValueAt(final int rowIndex, final int columnIndex) {
			switch (columnIndex) {
				case CHECK_BOX_COLUMN: return isSelected(rowIndex);
				case VALUE_COLUMN: return getRowAt(rowIndex).getValue();
				default: throw new WTFError("Bad column: " + columnIndex);
			}
		}

		@Override
		public void setValueAt(final Object value, final int rowIndex, final int columnIndex) {
			switch (columnIndex) {
				case CHECK_BOX_COLUMN:
					setSelected(rowIndex, (Boolean)value);
					fireTableRowsUpdated(rowIndex, rowIndex);
					break;
				case VALUE_COLUMN:
					break;
				default:
					throw new WTFError("Bad column: " + columnIndex);
			}
		}

		public boolean isSelected(final int rowIndex) {
			return getRowAt(rowIndex).isSelected();
		}

		public void setSelected(final int rowIndex, final boolean value) {
			getRowAt(rowIndex).setSelected(value);
		}

		// private

		private CheckBoxModel(final String checkBoxColumnName, final String valueColumnName, final boolean selectAll, final Collection<T> collection) {
			super(
				new ColumnInfo(checkBoxColumnName, Boolean.class, true),
				new ColumnInfo(valueColumnName, Object.class, false)
			);
			try {
				setEventsEnabled(false);
				for (T i : collection)
					addRow(new CheckBoxItem<>(i, selectAll));
			}
			finally {
				setEventsEnabled(true);
			}
		}

	}

}
