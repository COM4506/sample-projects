// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Consumer;
import java.util.function.DoubleUnaryOperator;
import java.util.function.ObjDoubleConsumer;
import java.util.function.Supplier;
import javax.swing.JComponent;
import javax.swing.text.JTextComponent;

import org.makagiga.commons.MColor;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;

/**
 * @since 5.6
 */
public final class ComponentAnimation implements MDisposable {

	// public

	public static final DoubleUnaryOperator LINEAR = DoubleUnaryOperator.identity();
	//public static final DoubleUnaryOperator EASE_OUT_SINE = progress -> Math.sin(progress * Math.PI / 2d);

	// private
	
	// concurrent

	private volatile boolean threadActive = true;
	private boolean updated;
	private double progress;
	private static ExecutorService threadPool;
	private long startTime;
	private static final LongAdder nextNumber = new LongAdder();
	private final Object lock = new Object();
	private Runnable runnable;

	// event handlers

	private Consumer<ComponentAnimation> onDone;
	private ObjDoubleConsumer<ComponentAnimation> onProgress;
	
	// properties

	private boolean autoRepaint;
	private Component component;
	private DoubleUnaryOperator ease = LINEAR;
	private long duration = 500;
	private final Map<String, Updater<?>> updaters = new LinkedHashMap<>();
	private String clientProperty;
	private static final String BACKGROUND_ANIMATION_PROPERTY = "org.makagiga.commons.swing.ComponentAnimation.background";
	private static final String FOREGROUND_ANIMATION_PROPERTY = "org.makagiga.commons.swing.ComponentAnimation.foreground";

	// public
	
	public ComponentAnimation(final Component component) {
		this.component = Objects.requireNonNull(component);

		Runnable runnableEDT = () -> {
			if (!threadActive) {
				//System.err.println("Exit EDT (not active)");

				return;
			}
			
			//System.err.println("Enter EDT");
			
			double progress;
			synchronized (lock) {
				progress = this.progress;
			}

			updateEDT(progress);

			if (progress >= 1.0d)
				dispose();

			//System.err.println("Exit EDT");

			synchronized (lock) {
				updated = true;
				lock.notifyAll();
			}
		};

		runnable = () -> {
			//System.err.println("Start Thread: " + Thread.currentThread());
			while (threadActive) {
				long time = System.nanoTime() / 1000000L;
				synchronized (lock) {
					long elapsed = (time - startTime);
					progress = Math.max(0.0d, Math.min(1.0d, ease.applyAsDouble((double)elapsed / (double)duration)));
				}

				synchronized (lock) {
					updated = false;
				}

				UI.invokeLater(runnableEDT);

				synchronized (lock) { // wait for EDT thread
					while (!updated) {
						try {
							//System.err.println("Waiting for EDT... " + component.getClass());
							lock.wait();
							//System.err.println("EDT unlock: " + component.getClass());
						}
						catch (InterruptedException exception) {
							MLogger.exception(exception);
						}
					}
				}
			}
			//System.err.println("End Thread: " + Thread.currentThread());
		};
	}

	public ComponentAnimation autoRepaint(final boolean value) {
		autoRepaint = value;
		
		return this;
	}

	public ComponentAnimation backgroundProperty(final Color from, final Color to) {
		return colorProperty(
			"background",
			from, (to == null) ? UI.getBackground(component) : to,
			() -> UI.getBackground(component), component::setBackground
		);
	}

	public static ComponentAnimation blendBackgroundProperty(final JComponent c, final Color from, final Color to) {
		ComponentAnimation animation = UI.getClientProperty(c, BACKGROUND_ANIMATION_PROPERTY, null);

		if ((animation != null) && animation.isActive()) {
			ColorUpdater u = (ColorUpdater)animation.updaters.get("background");
			u.merge(from, to);

			return animation;
		}

		return new ComponentAnimation(c)
			.backgroundProperty(from, to)
			.clientProperty(BACKGROUND_ANIMATION_PROPERTY)
			.duration((c instanceof JTextComponent) ? 200 : 500)
			.play();
	}

	public static ComponentAnimation blendForegroundProperty(final JComponent c, final Color from, final Color to) {
		ComponentAnimation animation = UI.getClientProperty(c, FOREGROUND_ANIMATION_PROPERTY, null);

		if ((animation != null) && animation.isActive()) {
			ColorUpdater u = (ColorUpdater)animation.updaters.get("foreground");
			u.merge(from, to);

			return animation;
		}

		return new ComponentAnimation(c)
			.foregroundProperty(from, to)
			.clientProperty(FOREGROUND_ANIMATION_PROPERTY)
			.duration((c instanceof JTextComponent) ? 200 : 500)
			.play();
	}

	public ComponentAnimation colorProperty(final String name, final Color from, final Color to, final Supplier<Color> getter, final Consumer<Color> setter) {
		TK.checkNullOrEmpty(name);

		updaters.put(name, new ColorUpdater(from, to, getter, setter));
	
		return this;
	}

	public static void debug() {
		System.err.println("Thread Pool = " + threadPool);
	}

	public ComponentAnimation dimensionProperty(final String name, final Dimension from, final Dimension to, final Supplier<Dimension> getter, final Consumer<Dimension> setter) {
		TK.checkNullOrEmpty(name);

		updaters.put(name, new DimensionUpdater(from, to, getter, setter));
	
		return this;
	}

	public ComponentAnimation doubleProperty(
		final String name,
		final double from, final double to,
		final Supplier<Double> getter, final Consumer<Double> setter
	) {
		TK.checkNullOrEmpty(name);

		updaters.put(name, new DoubleUpdater(from, to, getter, setter));

		return this;
	}

	public ComponentAnimation duration(final long duration) {
		if (duration < 0)
			throw new IllegalArgumentException("Duration cannot be less than zero: " + duration);

		this.duration = duration;
		
		return this;
	}

	public ComponentAnimation ease(final DoubleUnaryOperator ease) {
		synchronized (lock) {
			this.ease = Objects.requireNonNull(ease);
		}
		
		return this;
	}

	public void end() {
		//System.err.println("End " + component.getClass());
		updateEDT(1.0d);
	}

	public ComponentAnimation foregroundProperty(final Color from, final Color to) {
		return colorProperty(
			"foreground",
			from, (to == null) ? UI.getForeground(component) : to,
			() -> UI.getForeground(component), component::setForeground
		);
	}

	public ComponentAnimation integerProperty(
		final String name,
		final int from, final int to,
		final Supplier<Integer> getter, final Consumer<Integer> setter
	) {
		TK.checkNullOrEmpty(name);

		updaters.put(name, new IntegerUpdater(from, to, getter, setter));

		return this;
	}

	public static int interpolate(final int from, final int to, final double progress) {
		return (int)(((double)from * (1.0d - progress)) + ((double)to * progress));
	}

	public boolean isActive() {
		return component != null;
	}

	public ComponentAnimation locationProperty(final Point from, final Point to) {
		return pointProperty("location", from, to, component::getLocation, component::setLocation);
	}

	public ComponentAnimation onDone(final Consumer<ComponentAnimation> handler) {
		onDone = handler;
		
		return this;
	}

	public ComponentAnimation onProgress(final ObjDoubleConsumer<ComponentAnimation> handler) {
		onProgress = handler;
		
		return this;
	}

	public ComponentAnimation play() {
		synchronized (lock) {
			startTime = System.nanoTime() / 1000000L;
		}

		synchronized (ComponentAnimation.class) {
			if (threadPool == null) {
				threadPool = Executors.newCachedThreadPool(r -> {
					nextNumber.increment();
					Thread thread = new Thread(r, "Animation #" + nextNumber.longValue());
					thread.setDaemon(true);
				
					return thread;
				} );
				//System.err.println("Init " + threadPool);
			}
			threadPool.submit(runnable);
		}

		return this;
	}

	public ComponentAnimation pointProperty(final String name, final Point from, final Point to, final Supplier<Point> getter, final Consumer<Point> setter) {
		TK.checkNullOrEmpty(name);

		updaters.put(name, new PointUpdater(from, to, getter, setter));
	
		return this;
	}

	public static void shutDown() {
		synchronized (ComponentAnimation.class) {
			//System.err.println("Shut down " + threadPool);
			if (threadPool != null) {
				threadPool.shutdown();
				threadPool = null;
			}
		}
	}

	public ComponentAnimation sizeProperty(final Dimension from, final Dimension to) {
		return dimensionProperty("size", from, to, component::getSize, size -> {
			component.setSize(size);
			// HACK: sync. new size with component.getSize()
			if (component instanceof Window)
				component.validate();
		} );
	}

	// MDisposable
	
	@Override
	public void dispose() {
		threadActive = false;
		runnable = null;
		onDone = null;
		onProgress = null;
		updaters.clear();

		if ((clientProperty != null) && (component instanceof JComponent))
			JComponent.class.cast(component).putClientProperty(clientProperty, null);

		component = null;
	}

	// private

	private ComponentAnimation clientProperty(final String clientProperty) {
		this.clientProperty = TK.checkNullOrEmpty(clientProperty);
		JComponent.class.cast(component)
			.putClientProperty(clientProperty, this);
		
		return this;
	}

	private void updateEDT(final double progress) {
		for (Updater<?> i : updaters.values())
			i.update(progress);
		
		if (onProgress != null)
			onProgress.accept(this, progress);

		// save it here because it may be disposed in "onDone"
		Component toRepaint = autoRepaint ? component : null;

		if (progress >= 1.0d) {
			if (onDone != null)
				onDone.accept(this);
		}

		if (toRepaint != null)
			toRepaint.repaint();
	}

	// package

	static void stopBackgroundBlend(final JComponent c) {
		ComponentAnimation animation = UI.getClientProperty(c, FOREGROUND_ANIMATION_PROPERTY, null);
		if (animation != null)
			animation.dispose();
	}

	static void stopForegroundBlend(final JComponent c) {
		ComponentAnimation animation = UI.getClientProperty(c, FOREGROUND_ANIMATION_PROPERTY, null);
		if (animation != null)
			animation.dispose();
	}

	// private classes

	private static abstract class Updater<T> {
	
		// protected
		
		protected T from;
		protected T to;
		protected final Consumer<T> setter;

		// public
		
		public Updater(final T from, final T to, final Supplier<T> getter, final Consumer<T> setter) {
			Objects.requireNonNull(getter);
			this.setter = Objects.requireNonNull(setter);
			
			this.from = Objects.requireNonNull((from == null) ? getter.get() : from);
			this.to = Objects.requireNonNull(to);
		}

		// protected

		protected abstract void update(final double progress);

	}

	private static final class ColorUpdater extends Updater<Color> {
	
		// private
		
		private final Color originalFrom;
		private final Color originalTo;
	
		// public
		
		public ColorUpdater(final Color from, final Color to, final Supplier<Color> getter, final Consumer<Color> setter) {
			super(from, to, getter, setter);
			this.originalFrom = this.from;
			this.originalTo = this.to;
		}

		public void merge(final Color from, final Color to) {
			this.from = (from == null) ? originalFrom : from;
			this.to = (to == null) ? originalTo : to;
		}

		// protected
		
		@Override
		protected void update(final double progress) {
			setter.accept(MColor.interpolate(from, to, progress));
		}
	
	}

	private static final class DimensionUpdater extends Updater<Dimension> {
	
		// public
		
		public DimensionUpdater(final Dimension from, final Dimension to, final Supplier<Dimension> getter, final Consumer<Dimension> setter) {
			super(
				(from == null) ? null : new Dimension(from),
				(to == null) ? null : new Dimension(to),
				getter, setter
			);
		}
	
		// protected
		
		@Override
		protected void update(final double progress) {
			setter.accept(new Dimension(
				ComponentAnimation.interpolate(from.width, to.width, progress),
				ComponentAnimation.interpolate(from.height, to.height, progress)
			));
		}
	
	}

	private static final class DoubleUpdater extends Updater<Double> {
	
		// public
		
		public DoubleUpdater(final double from, final double to, final Supplier<Double> getter, final Consumer<Double> setter) {
			super(from, to, getter, setter);
		}
	
		// protected
		
		@Override
		protected void update(final double progress) {
			setter.accept((from * (1.0d - progress)) + (to * progress));
		}
	
	}

	private static final class IntegerUpdater extends Updater<Integer> {
	
		// public
		
		public IntegerUpdater(final int from, final int to, final Supplier<Integer> getter, final Consumer<Integer> setter) {
			super(from, to, getter, setter);
		}
	
		// protected
		
		@Override
		protected void update(final double progress) {
			setter.accept(ComponentAnimation.interpolate(from, to, progress));
		}
	
	}

	private static final class PointUpdater extends Updater<Point> {
	
		// public
		
		public PointUpdater(final Point from, final Point to, final Supplier<Point> getter, final Consumer<Point> setter) {
			super(
				(from == null) ? null : new Point(from),
				(to == null) ? null : new Point(to),
				getter, setter
			);
		}
	
		// protected
		
		@Override
		protected void update(final double progress) {
			setter.accept(new Point(
				ComponentAnimation.interpolate(from.x, to.x, progress),
				ComponentAnimation.interpolate(from.y, to.y, progress)
			));
		}
	
	}

}
