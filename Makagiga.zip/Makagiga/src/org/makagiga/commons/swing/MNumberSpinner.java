// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.beans.ConstructorProperties;
import java.text.DecimalFormat;
import java.util.Objects;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import org.makagiga.commons.MColor;
import org.makagiga.commons.UI;

/**
 * A number spinner (number input).
 * 
 * @mg.default
 * <ul>
 * <li>model = javax.swing.SpinnerNumberModel</li>
 * <li>format.groupingSize = 0</li>
 * </ul>
 *
 * @mg.screenshot
 * <img alt="MNumberSpinner example" src="../doc-files/MNumberSpinner.png">
 *
 * @mg.example
 * <pre class="brush: java">
 * MNumberSpinner&lt;Integer&gt; month = new MNumberSpinner&lt;&gt;();
 *
 * // set minimum and maximum
 * month.setRange(1, 12);
 *
 * // set value
 * month.setNumber(7);
 *
 * // listen for value change
 * month.addChangeListener(new ChangeListener() {
 *   {@literal @}Override
 *   public void stateChanged(ChangeEvent e) {
 *     Number n = MNumberSpinner.class.cast(e.getSource()).getNumber();
 *     System.out.println(n);
 *   }
 * } );
 * </pre>
 *
 * @param <N> the number type
 *
 * @see #MNumberSpinner()
 * @see #getNumber()
 * @see #setNumber(Number)
 * @see #setRange(Comparable, Comparable)
 *
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MNumberSpinner<N extends Number> extends AbstractSpinner<SpinnerNumberModel, N> {

	// private
	
	private static final int PROGRESS_BAR_SIZE = 2;
	private final Rectangle progressBarRect = new Rectangle();
	private final SimpleProgressBar progressBar;

	// public

	/**
	 * Constructs a number spinner with default value.
	 *
	 * @mg.warning
	 * The default model values are stored as {@code java.lang.Integer}.
	 * Use {@link #setNumber(Number)} to convert it to {@code N} type.
	 */
	public MNumberSpinner() {
		super(new SpinnerNumberModel());
		setupEditor();
		getFormat().setGroupingSize(0);

		// repaint progress bar
		addChangeListener(e -> {
			progressBarRect.width = getWidth();
			progressBarRect.y = getHeight() - PROGRESS_BAR_SIZE;
			repaint(progressBarRect);
		} );

		progressBarRect.x = 0;
		progressBarRect.height = PROGRESS_BAR_SIZE;

		progressBar = new SimpleProgressBar();
		progressBar.setBorderPainted(false);
		
		JTextField textField = getTextField();
		if (textField != null)
			textField.addFocusListener(new StaticFocusHandler());
	}

	/**
	 * @since 4.2
	 */
	@ConstructorProperties("number")
	public MNumberSpinner(final N number) {
		this();
		setNumber(number);
	}

	/**
	 * @since 5.4
	 */
	public static int getColumnsForNumber(final Number number) {
		Objects.requireNonNull(number);

		return number.toString().length() + 1;
	}

	/**
	 * @since 5.4
	 */
	public void setColumnsForNumber(final Number number) {
		Objects.requireNonNull(number);

		getTextField()
			.setColumns(getColumnsForNumber(number));
	}

	/**
	 * Returns decimal format used by this number editor.
	 *
	 * @return decimal format used by this number editor.
	 */
	public DecimalFormat getFormat() {
		return NumberEditor.class.cast(getEditor()).getFormat();
	}

	/**
	 * Returns the current number value.
	 *
	 * @return the current number value.
	 *
	 * @mg.default
	 * {@code 0}
	 *
	 * @see #setNumber(Number)
	 *
	 * @since 3.8
	 */
	@SuppressWarnings("unchecked")
	public N getNumber() {
		return (N)getModel().getNumber();
	}

	@Override
	public void paint(final Graphics graphics) {
		super.paint(graphics);
		
		if (UI.isGTK())
			return;
		
		if (progressBar == null)
			return;
		
		JTextField textField = getTextField();
		
		if ((textField == null) || !textField.isFocusOwner())
			return;
		
		SpinnerNumberModel model = getModel();

		if (model == null)
			return;
			
		Number min = (Number)model.getMinimum();
		Number max = (Number)model.getMaximum();
		Number value = getNumber();
		if ((min != null) && (max != null) && (value != null)) {
			boolean isMin = value.equals(min);
			Color color;
			if (isMin || value.equals(max))
				color = MColor.DARK_RED;
			else
				color = MColor.DARK_GREEN;
			progressBar.setForeground(color);

			if (isMin) {
				// paint something for a minimal value
				progressBar.setMaximum(100);
				progressBar.setMinimum(0);
				progressBar.setValue(10);
			}
			else {
				progressBar.setMaximum(max.intValue());
				progressBar.setMinimum(min.intValue());
				progressBar.setValue(value.intValue());
			}

			progressBarRect.width = getWidth();
			progressBarRect.y = getHeight() - PROGRESS_BAR_SIZE;
			progressBar.paint(
				(Graphics2D)graphics,
				progressBarRect.x, progressBarRect.y,
				progressBarRect.width, progressBarRect.height
			);
		}
	}

	/**
	 * Sets the current number value.
	 *
	 * @param value the new number value
	 *
	 * @throws IllegalArgumentException If {@code value} is {@code null}
	 *
	 * @see #getNumber()
	 *
	 * @since 3.8
	 */
	public void setNumber(final N value) {
		getModel().setValue(value);
	}

	/**
	 * Sets both minimum and maximum allowed value.
	 *
	 * @param minimum the new minimum value
	 * @param maximum the new maximum value
	 *
	 * @since 3.8
	 */
	public void setRange(final Comparable<N> minimum, final Comparable<N> maximum) {
		SpinnerNumberModel model = getModel();
		model.setMinimum(minimum);
		model.setMaximum(maximum);

		// set minimum text field width
		if (maximum instanceof Number)
			setColumnsForNumber((Number)maximum);
	}

	// private classes

	private static final class StaticFocusHandler extends FocusAdapter {

		// public

		public StaticFocusHandler() { }

		@Override
		public void focusGained(final FocusEvent e) {
			repaint(e);
		}

		@Override
		public void focusLost(final FocusEvent e) {
			repaint(e);
		}
		
		// private
		
		private void repaint(final FocusEvent e) {
			UI.getAncestorOfType(MNumberSpinner.class, e.getComponent())
				.ifPresent(spinner -> spinner.repaint());
		}

	}

}
