// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Window;
import java.util.Objects;
import java.util.Optional;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.Tuple;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.mods.Mods;
import org.makagiga.commons.painters.AbstractPainter;
import org.makagiga.commons.painters.Painter;
import org.makagiga.commons.style.StyleSupport;

/**
 * A panel.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MPanel extends JPanel
implements
	MBorderLayout,
	StyleSupport
{

	// public

	/**
	 * @since 3.4
	 */
	public static final int DEFAULT_CONTENT_MARGIN = 10;

	/**
	 * Invoked from the {@link #addNotify()} method.
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.1
	 */
	public static final String MOD_ADD_NOTIFY = "addNotify@org.makagiga.commons.swing.MPanel";

	/**
	 * Invoked from the {@link #removeNotify()} method.
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.1
	 */
	public static final String MOD_REMOVE_NOTIFY = "removeNotify@org.makagiga.commons.swing.MPanel";

	// private

	private boolean painterVisible = true;
	private int boxLayoutAxis;
	private Painter painter;
	private Size maxSize;
	private Size prefSize;

	// package private

	static final String HEADER_FONT_STYLE = "font-size: x-large; font-weight: bold";

	// public

	/**
	 * Constructs a panel with "border" layout.
	 */
	public MPanel() {
		super(new BorderLayout());
	}

	/**
	 * @since 2.4
	 */
	public MPanel(final boolean autoCreatePadding) {
		super(null);
		setGroupLayout(autoCreatePadding);
	}

	/**
	 * @since 2.4
	 */
	public MPanel(final int orientation) {
		super(null);
		switch (orientation) {
			case UI.HORIZONTAL:
				setHBoxLayout();
				break;
			case UI.VERTICAL:
				setVBoxLayout();
				break;
			default:
				throw new IllegalArgumentException("\"orientation\" must be \"UI.HORIZONTAL\" or \"UI.VERTICAL\": " + orientation);
		}
	}

	/**
	 * Constructs a panel with @b border layout.
	 * @param hgap A horizontal gap
	 * @param vgap A vertical gap
	 */
	public MPanel(final int hgap, final int vgap) {
		this(new BorderLayout(hgap, vgap));
	}

	/**
	 * Constructs a panel with @b grid layout.
	 * @param rows A number of rows
	 * @param cols A number of columns
	 * @param hgap A horizontal gap
	 * @param vgap A vertical gap
	 */
	public MPanel(final int rows, final int cols, final int hgap, final int vgap) {
		this(new GridLayout(rows, cols, hgap, vgap));
	}

	/**
	 * Constructs a panel with @p layout.
	 */
	public MPanel(final LayoutManager layout) {
		super(layout);
	}

	/**
	 * Adds @p component to the panel.
	 *
	 * @mg.note If vertical box layout is set, the @p component will be left aligned.
	 */
	public void add(final JComponent component) {
		if (component != null) {
			if ((boxLayoutAxis == BoxLayout.PAGE_AXIS) && (getLayout() instanceof BoxLayout))
				component.setAlignmentX(LEFT_ALIGNMENT);
			super.add(component);
		}
	}

	/**
	 * @since 3.8.6
	 */
	public void addCenter(final JComponent component, final int scrollPaneFlags) {
		addCenter(new MScrollPane(component, scrollPaneFlags));
	}

	/**
	 * @since 3.4
	 */
	public Component addContentGap() {
		return addGap(getContentMargin());
	}

	public MMessageLabel addCoolHeader(final String text) {
		MMessageLabel h = new MMessageLabel(text);
		MPanel p = createBorderPanel();
		p.addCenter(h);
		add(p);
		
		return h;
	}

	/**
	 * Adds a horizontal or vertical gap of size @c 5.
	 *
	 * @mg.note This works only with vertical/horizontal box layout.
	 */
	public Component addGap() {
		return addGap(5);
	}

	/**
	 * Adds a horizontal or vertical gap.
	 *
	 * @mg.note This works only with vertical/horizontal box layout.
	 *
	 * @param size A gap size
	 */
	public Component addGap(final int size) {
		Component c =
			(boxLayoutAxis == BoxLayout.LINE_AXIS)
			? UI.createGap(size, 0)
			: UI.createGap(0, size);
		add(c);
		
		return c;
	}
	
	public MLabel addHeader(final String text) {
		MLabel l = createHeaderLabel(text);
		add(l);
		
		return l;
	}

	@Override
	public void addNotify() {
		super.addNotify();
		Mods.exec(this, MOD_ADD_NOTIFY);
	}

	@Override
	public void removeNotify() {
		super.removeNotify();
		Mods.exec(this, MOD_REMOVE_NOTIFY);
	}

	/**
	 * @since 3.4
	 */
	public MLabel addSeparator(final String text) {
		return addSeparator(text, null);
	}

	/**
	 * @since 5.4
	 */
	public MLabel addSeparator(final String text, final Color lineColor) {
		MLabel l = createHeaderLabel(text);

		MSeparator separator = MSeparator.newHorizontalLine(lineColor);
		separator.putClientProperty(MSeparator.LABEL_PROPERTY, l);

		MPanel p = createBorderPanel(5);
		p.setOpaque(false);
		p.addWest(l);
		p.addCenter(separator);
		p.limitHeight();
		add(p);

		return l;
	}

	/**
	 * Adds a horizontal or vertical stretch.
	 *
	 * @mg.note This works only with vertical/horizontal box layout.
	 */
	public Component addStretch() {
		Component c =
			(boxLayoutAxis == BoxLayout.LINE_AXIS)
			? Box.createHorizontalGlue()
			: Box.createVerticalGlue();
		add(c);
		
		return c;
	}

	/**
	 * @since 3.0
	 */
	public void alignLabels() {
		int max = 0;
		Component[] components = getComponents();
		MArrayList<Tuple.Two<MWrapperPanel<?>, Dimension>> all = new MArrayList<>(components.length);
		
		for (Component i : components) {
			if (i instanceof MWrapperPanel<?>) {
				MWrapperPanel<?> w = (MWrapperPanel<?>)i;
				
				if (w.getOrientation() != UI.HORIZONTAL)
					continue; // for
				
				MLabel l = w.getLabel();
				if (l != null) {
					if (l.isPreferredSizeSet())
						l.setPreferredSize(null); // re-align
					Dimension d = l.getPreferredSize();
					max = Math.max(max, d.width);
					all.add(Tuple.<MWrapperPanel<?>, Dimension>of(w, d));
				}
			}
		}
		
		if (all.size() < 2)
			return;
		
		for (Tuple.Two<MWrapperPanel<?>, Dimension> i : all) {
			MLabel l = i.get1().getLabel();
			l.setHorizontalAlignment(UI.TRAILING);
			Dimension d = new Dimension(max, i.get2().height);
			//l.setMinimumSize(d);
			l.setPreferredSize(d);
		}
	}

	/**
	 * Constructs and returns a new panel with @b border layout.
	 */
	public static MPanel createBorderPanel() {
		return new MPanel();
	}

	/**
	 * Constructs and returns a new panel with @b border layout.
	 * @param gap A horizontal and vertical gap
	 */
	public static MPanel createBorderPanel(final int gap) {
		return new MPanel(gap, gap);
	}
	
	public static MPanel createCardPanel() {
		return new MPanel(new MCardLayout());
	}

	/**
	 * Constructs and returns a new panel with @b grid layout.
	 * Horizontal and vertical gap size is @c 0.
	 * @param rows A number of rows
	 * @param cols A number of columns
	 */
	public static MPanel createGridPanel(final int rows, final int cols) {
		return new MPanel(rows, cols, 0, 0);
	}

	/**
	 * Constructs and returns a new panel with @b grid layout.
	 * @param rows A number of rows
	 * @param cols A number of columns
	 * @param hgap A horizontal gap
	 * @param vgap A vertical gap
	 */
	public static MPanel createGridPanel(final int rows, final int cols, final int hgap, final int vgap) {
		return new MPanel(rows, cols, hgap, vgap);
	}
	
	/**
	 * @since 2.0
	 */
	public static MPanel createGroupPanel(final boolean autoCreatePadding) {
		return new MPanel(autoCreatePadding);
	}

	/**
	 * Constructs and returns a new panel with <b>horizontal box</b> layout.
	 */
	public static MPanel createHBoxPanel() {
		return new MPanel(UI.HORIZONTAL);
	}

	/**
	 * @since 2.0
	 */
	public static <C extends JComponent> MWrapperPanel<C> createHLabelPanel(final C c, final String label) {
		MWrapperPanel<C> p = new MWrapperPanel<>(DEFAULT_CONTENT_MARGIN, 5, UI.HORIZONTAL, c, label);
		p.setMargin(0);

		return p;
	}

	/**
	 * @since 3.8.8
	 */
	public static MPanel createPuzzlePanel(final String text, final JComponent c) {
		MPanel p = createHBoxPanel();

		String delimeter = "{0}";

		int i = text.indexOf(delimeter);
		if (i == -1) {
			p.add(MLabel.createFor(c, text));
			p.addGap();
			p.add(c);

			return p;
		}

		String s1 = text.substring(0, i - 1);
		String s2 =
			(i == text.length() - delimeter.length())
			? ""
			: text.substring(i + delimeter.length() + 1);

		p.add(MLabel.createFor(c, s1));
		p.addGap();
		p.add(c);
		if (!s2.isEmpty()) {
			p.addGap();
			p.add(new MLabel(s2));
		}

		return p;
	}
	
	/**
	 * @since 4.10
	 */
	public static MPanel createSimplePanel() {
		return new MPanel(new MSimpleLayout());
	}

	/**
	 * Constructs and returns a new panel with <b>vertical box</b> layout.
	 */
	public static MPanel createVBoxPanel() {
		MPanel p = new MPanel(UI.VERTICAL);
		p.setAlignmentY(TOP_ALIGNMENT);

		return p;
	}

	/**
	 * @since 2.0
	 */
	public static <C extends JComponent> MWrapperPanel<C> createVLabelPanel(final C c, final String label) {
		MWrapperPanel<C> p = new MWrapperPanel<>(UI.VERTICAL, c, label);
		p.setMargin(0);

		return p;
	}

	/**
	 * @since 4.2
	 */
	public MCardLayout getCardLayout() {
		return (MCardLayout)getLayout();
	}

	/**
	 * @since 3.4
	 */
	public int getContentMargin() { return DEFAULT_CONTENT_MARGIN; }
	
	/**
	 * @since 5.4
	 */
	public Optional<MDialog> getDialog() {
		return Optional.ofNullable(MDialog.of(this));
	}
	
	/**
	 * @since 2.4
	 */
	public MGroupLayout getGroupLayout() {
		return (MGroupLayout)getLayout();
	}

	@Override
	public Dimension getMaximumSize() {
		Dimension d = super.getMaximumSize();
		
		if (maxSize != null)
			return maxSize.apply(this, d);
		
		return d;
	}

	/**
	 * @since 5.6
	 */
	public void setMaximumSize(final Size size) { maxSize = size; }

	/**
	 * Returns the painter (may be @c null).
	 *
	 * @since 2.0
	 */
	public Painter getPainter() { return painter; }
	
	/**
	 * Sets painter to @p value (can be @c null).
	 *
	 * @since 2.0
	 */
	public void setPainter(final Painter value) {
		if (!Objects.equals(painter, value)) {
			painter = value;
			repaint();
		}
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension d = super.getPreferredSize();
		
		if (prefSize != null)
			return prefSize.apply(this, d);
		
		return d;
	}

	/**
	 * @since 5.6
	 */
	public void setPreferredSize(final Size size) { prefSize = size; }

	/**
	 * @since 4.10
	 */
	public MSimpleLayout getSimpleLayout() {
		return (MSimpleLayout)getLayout();
	}

	/**
	 * @since 3.0
	 */
	public Window getWindowAncestor() {
		return SwingUtilities.getWindowAncestor(this);
	}

	@Override
	public boolean isOpaque() {
		if (!isPainterVisible())
			return super.isOpaque();

		if (
			(painter instanceof AbstractPainter) &&
			AbstractPainter.class.cast(painter).isOpaque()
		)
			return true;
		
		return super.isOpaque();
	}

	/**
	 * @since 2.2
	 */
	@Obsolete
	public Dimension limitHeight() {
		return limitHeight(this);
	}

	/**
	 * @since 2.2
	 */
	@Obsolete
	public Dimension limitHeight(final Component preferredSize) {
		Dimension size = new Dimension(
			Integer.MAX_VALUE,
			preferredSize.getPreferredSize().height
		);
		setMaximumSize(size);
		
		return size;
	}
	
	public void setContentMargin() {
		setMargin(getContentMargin());
	}

	/**
	 * @since 2.0
	 */
	@InvokedFromConstructor
	public MGroupLayout setGroupLayout(final boolean autoCreatePadding) {
		MGroupLayout layout = new MGroupLayout(this, autoCreatePadding);
		setLayout(layout);
		
		return layout;
	}

	/**
	 * Sets layout to <b>horizontal box</b>.
	 */
	@InvokedFromConstructor
	public BoxLayout setHBoxLayout() {
		boxLayoutAxis = BoxLayout.LINE_AXIS;
		BoxLayout l = new BoxLayout(this, boxLayoutAxis);
		setLayout(l);
		
		return l;
	}

	/**
	 * Sets margin border with @p margin size.
	 */
	public void setMargin(final int margin) {
		setMargin(margin, margin, margin, margin);
	}

	/**
	 * Sets margin border.
	 * @param topMargin A top margin
	 * @param leftMargin A left margin
	 * @param bottomMargin A bottom margin
	 * @param rightMargin A right margin
	 */
	public void setMargin(
		final int topMargin,
		final int leftMargin,
		final int bottomMargin,
		final int rightMargin
	) {
		setBorder(BorderFactory.createEmptyBorder(topMargin, leftMargin, bottomMargin, rightMargin));
	}

	/**
	 * @since 4.10
	 */
	public MSimpleLayout setSimpleLayout() {
		MSimpleLayout l = new MSimpleLayout();
		setLayout(l);
		
		return l;
	}

	/**
	 * The default implementation returns a title from {@code TitledBorder} (if set) or {@code null}.
	 *
	 * @see #setTitle(String)
	 *
	 * @since 3.8
	 */
	public String getTitle() {
		Border border = getBorder();

		if (border instanceof TitledBorder)
			return TitledBorder.class.cast(border).getTitle();

		return null;
	}

	/**
	 * The default implementation sets {@code TitledBorder} with {@code value}.
	 *
	 * @see #getTitle()
	 */
	public void setTitle(final String value) {
		setBorder(BorderFactory.createTitledBorder(value));
	}
	
	/**
	 * @since 5.0
	 */
	public boolean isPainterVisible() { return painterVisible; }

	/**
	 * @since 5.0
	 */
	public void setPainterVisible(final boolean value) {
		if (value != painterVisible) {
			painterVisible = value;

			if (painter != null)
				repaint();
		}
	}

	/**
	 * Sets layout to <b>vertical box</b>.
	 */
	@InvokedFromConstructor
	public BoxLayout setVBoxLayout() {
		boxLayoutAxis = BoxLayout.PAGE_AXIS;
		BoxLayout l = new BoxLayout(this, boxLayoutAxis);
		setLayout(l);
		
		return l;
	}
	
	public void showCard(final String name) {
		LayoutManager layout = getLayout();
		
		if (!(layout instanceof CardLayout))
			throw new IllegalStateException("\"java.awt.CardLayout\" is not set");
		
		CardLayout.class.cast(layout).show(this, name);
	}

	@Override
	public void updateUI() {
		super.updateUI();
		if (painter instanceof AbstractPainter)
			AbstractPainter.class.cast(painter).invalidate();
	}

	// MBorderLayout

	@Override
	public void addCenter(final JComponent component) {
		UI.addCenter(this, component);
	}

	@Override
	public void addEast(final JComponent component) {
		add(component, BorderLayout.LINE_END);
	}

	@Override
	public void addNorth(final JComponent component) {
		add(component, BorderLayout.PAGE_START);
	}

	@Override
	public void addSouth(final JComponent component) {
		add(component, BorderLayout.PAGE_END);
	}

	@Override
	public void addWest(final JComponent component) {
		add(component, BorderLayout.LINE_START);
	}
	
	// StyleSupport

	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	/**
	 * @since 4.0
	 */
	protected MLabel createHeaderLabel(final String text) {
		MLabel l = new MLabel(text);
		int topMargin = (getComponentCount() == 0) ? 0 : (getContentMargin() * 2);
		if (UI.isRetro())
			l.setStyle("margin-top: " + topMargin + "; margin-bottom: 5");
		else
			l.setStyle(HEADER_FONT_STYLE + "; margin-top: " + topMargin + "; margin-bottom: 5");

		return l;
	}

	@Override
	protected void paintComponent(final Graphics g) {
		if ((painter != null) && isPainterVisible())
			painter.paint(this, (Graphics2D)g);
		else
			super.paintComponent(g);
	}

}
