// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.Insets;
import java.awt.Window;
import javax.swing.JComponent;
import javax.swing.JWindow;

import org.makagiga.commons.MApplication;
import org.makagiga.commons.UI;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MWindow extends JWindow implements MBorderLayout {
	
	// private
	
	private boolean respectScreenInsets = true;
	private UI.HorizontalPosition horizontalPosition;
	private UI.VerticalPosition verticalPosition;
	
	// public
	
	public MWindow() {
		this(null);
	}
	
	public MWindow(final Window owner) {
		super(owner);
	}

	public UI.HorizontalPosition getHorizontalPosition() { return horizontalPosition; }
	
	public void setHorizontalPosition(final UI.HorizontalPosition value) {
		horizontalPosition = value;
		setLocation(getNewXPosition(), getLocation().y);
	}
	
	/**
	 * @since 4.8
	 */
	public boolean getRespectScreenInsets() { return respectScreenInsets; }

	/**
	 * @since 4.8
	 */
	public void setRespectScreenInsets(final boolean value) { respectScreenInsets = value; }

	public UI.VerticalPosition getVerticalPosition() { return verticalPosition; }
	
	public void setVerticalPosition(final UI.VerticalPosition value) {
		verticalPosition = value;
		setLocation(getLocation().x, getNewYPosition());
	}
	
	@Override
	public void setVisible(final boolean value) {
		if (value && MApplication.getForceRTL() && !isVisible())
			applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

		super.setVisible(value);
	}
	
	public void showAtPosition(final UI.VerticalPosition v, final UI.HorizontalPosition h) {
		showAtPosition(v, h, true);
	}

	/**
	 * @since 4.8
	 */
	public void showAtPosition(final UI.VerticalPosition v, final UI.HorizontalPosition h, final boolean pack) {
		horizontalPosition = h;
		verticalPosition = v;
		
		if (pack)
			pack();
		
		setLocation(getNewXPosition(), getNewYPosition());
		setVisible(true);
	}
	
	// MBorderLayout

	/**
	 * @since 1.2
	 */
	@Override
	public void addCenter(final JComponent component) {
		UI.addCenter(this, component);
	}

	/**
	 * @since 1.2
	 */
	@Override
	public void addEast(final JComponent component) {
		add(component, BorderLayout.LINE_END);
	}

	/**
	 * @since 1.2
	 */
	@Override
	public void addNorth(final JComponent component) {
		add(component, BorderLayout.PAGE_START);
	}

	/**
	 * @since 1.2
	 */
	@Override
	public void addSouth(final JComponent component) {
		add(component, BorderLayout.PAGE_END);
	}

	/**
	 * @since 1.2
	 */
	@Override
	public void addWest(final JComponent component) {
		add(component, BorderLayout.LINE_START);
	}

	// private
	
	private int getNewXPosition() {
		Insets i = getScreenInsets();
	
		return
			(horizontalPosition == UI.HorizontalPosition.LEFT)
			? i.left // left
			: UI.getScreenSize().width - getWidth() - i.right; // right
	}

	private int getNewYPosition() {
		Insets i = getScreenInsets();
	
		return
			(verticalPosition == UI.VerticalPosition.BOTTOM)
			? UI.getScreenSize().height - getHeight() - i.bottom // bottom
			: i.top; // top
	}
	
	private Insets getScreenInsets() {
		if (respectScreenInsets)
			return UI.getScreenInsets();
		
		return new Insets(0, 0, 0, 0);
	}

}
