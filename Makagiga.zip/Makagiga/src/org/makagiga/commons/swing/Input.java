// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Objects;
import java.util.Optional;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.filechooser.FileFilter;

import org.makagiga.commons.FS;
import org.makagiga.commons.Item;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MCalendar;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MDate;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.color.MColorChooserDialog;
import org.makagiga.commons.icons.MIconChooser;
import org.makagiga.commons.script.ScriptYourself;
import org.makagiga.commons.validator.ListSelectionValidator;
import org.makagiga.commons.validator.NotEmptyValidator;

/**
 * @since 3.8.12
 */
public final class Input {

	// private
	
	private static SoftReference<DateTimeDialog> dateTimeDialogRef;
	
	// public

	// Character

	/**
	 * @since 5.2
	 */
	public static int getCharacter(final Window owner, final Font characterFont) {
		MCharacterChooser chooser = new MCharacterChooser(characterFont);
		
		MDialog dialog = new MDialog(owner, i18n("Choose Character"), MDialog.STANDARD_DIALOG | MDialog.FORCE_STANDARD_BORDER);
		dialog.addCenter(chooser);
		dialog.setSize(UI.WindowSize.LARGE);

		dialog.getValidatorSupport()
			.add(new ListSelectionValidator(chooser.charListView));

		int result;
		if (dialog.exec(chooser))
			result = chooser.getValue();
		else
			result = -1;
		chooser.writeConfig();
		chooser.dispose();
		
		return result;
	}

	/**
	 * @since 5.2
	 */
	public static String getCharacterAsString(final Window owner, final Font characterFont) {
		int character = getCharacter(owner, characterFont);
		
		if (character == -1)
			return null;
		
		return MCharacterChooser.toString(character);
	}

	// Color

	/**
	 * @since 4.2
	 */
	public static Color getColor(final Window owner, final Color initialValue) {
		return getColor(owner, initialValue, null, initialValue);
	}

	public static Color getColor(final Window owner, final Color initialValue, final String title) {
		return getColor(owner, initialValue, title, initialValue);
	}

	public static Color getColor(final Window owner, final Color initialValue, final String title, final Color defaultColor) {
		MColorChooserDialog colorChooser = new MColorChooserDialog(owner, title, initialValue, defaultColor);

		if (colorChooser.exec())
			return colorChooser.getValue();

		return null;
	}

	// Date

	public static MCalendar getDateTime(final Window owner, final java.util.Calendar initialValue, final String title, final String simpleFormat) {
		return getDateTime(owner, initialValue, title, simpleFormat, -1, -1);
	}

	public static MCalendar getDateTime(final Window owner, final java.util.Calendar initialValue, final String title, final int dateStyle, final int timeStyle) {
		return getDateTime(owner, initialValue, title, null, dateStyle, timeStyle);
	}

	// File

	/**
	 * @deprecated As of 4.4, replaced by {@link GetDirectoryBuilder}
	 */
	@Deprecated
	public static File getDirectory(final Window owner, final String title, final String configKey) {
		return getDirectory(owner, title, configKey, null);
	}

	/**
	 * @deprecated As of 4.4, replaced by {@link GetDirectoryBuilder}
	 *
	 * @since 4.2
	 */
	@Deprecated
	public static File getDirectory(final Window owner, final String title, final String configKey, final MActionInfo approveButtonInfo) {
		MFileChooser fileChooser = MFileChooser.createDirectoryChooser(owner, title);
		fileChooser.setConfigKey(configKey);

		if (approveButtonInfo != null)
			fileChooser.setApproveText(approveButtonInfo.getText());

		if (fileChooser.openDialog())
			return fileChooser.getSelectedFile();

		return null;
	}

	public static File getImageFile(final Window owner) {
		return getImageFile(owner, i18n("Choose Image"));
	}

	public static File getImageFile(final Window owner, final String title) {
		MFileChooser fileChooser = MFileChooser.createFileChooser(owner, title);
		fileChooser.setFileFilter(
			fileChooser.addImageIOReaderFilter()
		);
		fileChooser.setConfigKey("image");

		if (fileChooser.openDialog())
			return fileChooser.getSelectedFile();

		return null;
	}

	// Font

	public static Font getFont(final Window owner, final Font initialValue) {
		return MFontChooser.getFont(owner, initialValue, null);
	}

	public static Font getFont(final Window owner, final Font initialValue, final JComponent previewComponent) {
		return MFontChooser.getFont(owner, initialValue, previewComponent);
	}
	
	// Icon

	/**
	 * @since 4.0
	 */
	public static Item<String> getStockIcon(final Window owner) {
		return MIconChooser.fromList(owner, MIconChooser.getStockIcons(), 0);
	}

	/**
	 * @since 4.0
	 */
	public static Item<String> getStockIcon(final Window owner, final int flags) {
		return MIconChooser.fromList(owner, MIconChooser.getStockIcons(), flags);
	}

	// Image
	
	/**
	 * @since 5.0
	 */
	public static Path saveImage(final Window owner, final String name, final BufferedImage image, final String type) throws IOException {
		MFileChooser chooser = MFileChooser.createFileChooser(
			owner,
			MActionInfo.SAVE_AS.getDialogTitle()
		);
		FileFilter imageFilter = chooser.addFilter(TK.toUpperCase(type), type);
		chooser.setAutoAddExtension(true);
		chooser.setConfigKey("image");
		chooser.setFileFilter(imageFilter);
		chooser.setSelectedFile(new File(FS.replaceUnsafeCharacters(name) + "." + type));

		if (!chooser.saveDialog())
			return null;

		File output = chooser.getSelectedFile();
		ImageIO.write(image, type, output);
		
		return output.toPath();
	}

	// Password

	public static char[] getPassword(final Window owner, final String prompt) {
		return getPassword(owner, prompt, 0);
	}

	public static char[] getPassword(final Window owner, final String prompt, final int passwordPanelFlags) {
		MPasswordPanel passwordPanel = new MPasswordPanel(MPasswordPanel.ENTER_PASSWORD_MODE | passwordPanelFlags, prompt);

		MMessage<MPasswordPanel> base = new MMessage<>(
			owner,
			null,
			i18n("Enter Password") + " - " + MApplication.getFullName(),
			"ui/password",
			passwordPanel,
			MDialog.STANDARD_DIALOG
		);

		if ((passwordPanelFlags & MPasswordPanel.ALLOW_EMPTY_PASSWORD) == 0)
			base.getValidatorSupport().add(new NotEmptyValidator(passwordPanel.getNewPasswordField()));

		base.setResizable(false);

		char[] result = null;
		if (base.exec())
			result = passwordPanel.getPasswordInfo().getNewPassword();
		passwordPanel.dispose();

		return result;
	}

	/**
	 * @since 4.0
	 */
	public static MPasswordPanel.Info newPassword(final Window owner, final String prompt, final int passwordPanelFlags) {
		NewPasswordDialog dialog = new NewPasswordDialog(
			owner,
			prompt,
			passwordPanelFlags
		);
		dialog.packFixed(UI.WindowSize.MEDIUM);

		boolean ok = dialog.exec();
		MPasswordPanel.Info result = ok ? dialog.getPasswordPanel().getPasswordInfo() : null;
		dialog.getPasswordPanel().dispose();

		return result;
	}

	// Text

	/**
	 * @deprecated As of 4.4, replaced by {@link GetTextBuilder}
	 *
	 * @since 4.0
	 */
	@Deprecated
	public static MMessage<MTextFieldPanel> createMessage(final Window owner, final String initialValue, final String label, final String title, final String iconName, final String autoCompletionID) {
		MTextFieldPanel view = new MTextFieldPanel(initialValue);
		view.getMenuButton().setVisible(false);
		if (autoCompletionID != null)
			view.setAutoCompletion(autoCompletionID);
		MMessage<MTextFieldPanel> base = new MMessage<MTextFieldPanel>(
			owner,
			label,
			title,
			iconName,
			view,
			MDialog.STANDARD_DIALOG
		) {
			@Override
			protected boolean onAccept() {
				this.getView().saveAutoCompletion();

				return true;
			}
		};
		base.packFixed(UI.WindowSize.MEDIUM);

		base.getValidatorSupport().add(new NotEmptyValidator(view.getTextField()));

		return base;
	}

	/**
	 * @deprecated As of 4.4, replaced by {@link GetTextBuilder}
	 *
	 * @since 4.0
	 */
	@Deprecated
	public static String getLargeText(final Window owner, final String initialValue, final String title) {
		return getLargeText(owner, initialValue, title, true);
	}

	/**
	 * @deprecated As of 4.4, replaced by {@link GetTextBuilder}
	 *
	 * @since 4.0
	 */
	@Deprecated
	public static String getLargeText(final Window owner, final String initialValue, final String title, final boolean editable) {
		MEditorPane editor = MEditorPane.newPlainText(initialValue, editable);
		editor.setModified(false, null);

		int flags = MDialog.FORCE_STANDARD_BORDER;
		flags |= (editable ? MDialog.STANDARD_DIALOG : MDialog.SIMPLE_DIALOG);
		MDialog dialog = new MDialog(owner, title, flags) {
			@Override
			protected boolean onReject() {
				if (!editor.isModified())
					return true;

				return this.confirmReject();
			}
		};

		if (editable) {
			MText.installAutoCompletion(editor, "input");
			MText.getAutoCompletion(editor)
				.addStaticItemsFromText(initialValue);
		}

		MText.setupMonospacedFont(editor);
		dialog.getMainPanel()
			.setMargin(0);
		dialog.addCenter(editor);

		MText.updateActions(editor);
		MToolBar toolBar = new MToolBar();
		toolBar.setTextPosition(MToolBar.TextPosition.ALONGSIDE_ICONS);
		MText.updateToolBar(editor, toolBar);
		ScriptYourself.install(toolBar, "message-text-editor");
		dialog.setToolBar(toolBar);

		dialog.setSize(UI.WindowSize.MEDIUM);

		return dialog.exec(editor) ? editor.getText() : null;
	}

	/**
	 * @deprecated As of 4.4, replaced by {@link GetTextBuilder}
	 */
	@Deprecated
	public static String getText(final Window owner, final String initialValue, final String prompt, final String title, final String iconName, final String autoCompletionID) {
		MMessage<MTextFieldPanel> base = createMessage(owner, initialValue, prompt, title, iconName, autoCompletionID);

		if (base.exec(base.getView()))
			return base.getView().getText();

		return null;
	}

	/**
	 * @deprecated As of 4.4, replaced by {@link GetTextBuilder}
	 */
	@Deprecated
	public static String getText(final Window owner, final String initialValue, final String prompt, final String title) {
		return getText(owner, initialValue, prompt, title, null, "input");
	}

	// private

	@Uninstantiable
	private Input() {
		TK.uninstantiable();
	}

	private static MCalendar getDateTime(final Window owner, final java.util.Calendar initialValue, final String title, final String simpleFormat, final int dateStyle, final int timeStyle) {
		DateTimeDialog dialog = TK.get(dateTimeDialogRef);
		if (dialog == null) {
			dialog = new DateTimeDialog(owner, MDialog.STANDARD_DIALOG | MDialog.USER_BUTTON | MDialog.CACHED | MDialog.SIDE_BUTTONS);
			dateTimeDialogRef = new SoftReference<>(dialog);
		}
		dialog.setup(
			title,
			initialValue,
			simpleFormat,
			dateStyle,
			timeStyle
		);

		if (!dialog.exec())
			return null;

		return dialog.result;
	}

	// public classes

	/**
	 * @since 4.0
	 */
	public static class DateTimeDialog extends MDialog {

		// private

		private MCalendar result;
		private MCalendarPanel calendarPanel;

		// public

		public DateTimeDialog(final Window owner, final String title, final int dialogFlags, final java.util.Calendar initialValue, final String simpleFormat) {
			this(owner, dialogFlags);
			setup(title, initialValue, simpleFormat, -1, -1);
		}

		public DateTimeDialog(final Window owner, final String title, final int dialogFlags, final java.util.Calendar initialValue, final int dateStyle, final int timeStyle) {
			this(owner, dialogFlags);
			setup(title, initialValue, null, dateStyle, timeStyle);
		}
		
		@Override
		public boolean exec() {
			return super.exec(calendarPanel.getDateSpinner());
		}
		
		public MCalendarPanel getCalendarPanel() { return calendarPanel; }
		
		public void setup(final String title, final java.util.Calendar initialValue, final String simpleFormat, final int dateStyle, final int timeStyle) {
			setTitle(title);
			calendarPanel.setValue(new MDate(initialValue));
			MDateSpinner spinner = calendarPanel.getDateSpinner();
			if (simpleFormat == null)
				spinner.setDateTimeFormat(dateStyle, timeStyle);
			else
				spinner.setSimpleFormat(simpleFormat);
		}

		// protected
		
		@Override
		protected boolean onAccept() {
			try {
				calendarPanel.getDateSpinner().commitEdit();
			
				return true;
			}
			catch (ParseException exception) { // quiet
				return false;
			}
		}
		
		@Override
		protected void onClose() {
			result = calendarPanel.getDateSpinner().toCalendar();
			
			if (getFlags().isClear(CACHED)) {
				calendarPanel = TK.dispose(calendarPanel);
			}
		}

		@Override
		protected void onUserClick() {
			calendarPanel.setValue(MDate.invalid());
			accept();
		}
		
		// private

		private DateTimeDialog(final Window owner, final int dialogFlags) {
			super(
				owner,
				MActionInfo.SET_DATE_TIME.withDialogTitle(),
				dialogFlags
			);
			getUserButton().setActionInfoUI(MActionInfo.NO_DATE_TIME);

// TODO: separate date and time edit
			calendarPanel = new MCalendarPanel();

			// HACK: too slow
			calendarPanel.setAnimationEnabled(false);

			calendarPanel.setClearTime(false);
			calendarPanel.setShowInfo(false);

			addCenter(calendarPanel);
			
			MButton nextHourButton = new MButton(new SetDateAction(calendarPanel, i18n("Next Hour"), MCalendar.HOUR_OF_DAY, 1));
			MButton nextDayButton = new MButton(new SetDateAction(calendarPanel, i18n("Next Day"), MCalendar.DAY_OF_MONTH, 1));
			MButton nextWeekButton = new MButton(new SetDateAction(calendarPanel, i18n("Next Week"), MCalendar.DAY_OF_MONTH, 7));
			
			MPanel p = new MPanel(false);
			p.getGroupLayout()
			.beginRows()
				.addComponent(new MLabel(MActionInfo.SET_DATE_TIME.toString()))
				.addButtonGap()
				.addComponent(getUserButton())
				.addButtonGap()
				.addComponent(nextHourButton)
				.addButtonGap()
				.addComponent(nextDayButton)
				.addButtonGap()
				.addComponent(nextWeekButton)
			.end()
			.linkSize(getUserButton(), nextHourButton, nextDayButton, nextWeekButton);
			
			getButtonsPanel().add(p);
			
			setMinimumSize(UI.WindowSize.MEDIUM.getDimensionForDialog());
			setSize(UI.WindowSize.LARGE);
		}

	}

	/**
	 * @since 4.4
	 */
	public static final class GetDirectoryBuilder {
	
		// private
		
		private MActionInfo ok;
		private String configKey;
		private String title;
	
		// public
		
		public GetDirectoryBuilder() { }

		public GetDirectoryBuilder configKey(final String configKey) {
			this.configKey = configKey;
			
			return this;
		}
		
		public File exec(final Component owner) {
			Window window = (owner instanceof Window) ? (Window)owner : UI.windowFor(owner);
			
			return Input.getDirectory(window, title, configKey, ok);
		}

		public File exec(final MAction owner) {
			return exec(owner.getSourceWindow());
		}

		public GetDirectoryBuilder ok(final MActionInfo ok) {
			this.ok = ok;
			
			return this;
		}

		public GetDirectoryBuilder title(final String title) {
			this.title = title;
			
			return this;
		}

	}

	/**
	 * @since 5.6
	 */
	public static final class GetNumberBuilder<T extends Number> {

		// private
		
		private Comparable<T> maximum;
		private Comparable<T> minimum;
		private T number;
		private String label = i18n("Value:");
		private String title = i18n("Enter Value");
		
		// public
		
		public GetNumberBuilder() { }

		public Optional<T> exec(final MAction owner) {
			return exec(owner.getSourceWindow());
		}

		public Optional<T> exec(final Component owner) {
			Objects.requireNonNull(number, "\"number\" value not set");

			MNumberSpinner<T> numberField = new MNumberSpinner<>();
			UI.setLargerInputFont(numberField, false);
			numberField.setNumber(number); // convert Integer to T

			if ((minimum != null) && (maximum != null))
				numberField.setRange(minimum, maximum);

			Window window = (owner instanceof Window) ? (Window)owner : UI.windowFor(owner);
			MDialog dialog = new MDialog(window, title, MDialog.STANDARD_DIALOG);
			dialog.addCenter(new MSpinnerPanel(numberField, label));
			dialog.packFixed();

			if (dialog.exec(numberField))
				return Optional.of(numberField.getNumber());

			return Optional.empty();
		}

		public GetNumberBuilder<T> label(final String value) {
			label = Objects.requireNonNull(value);

			return this;
		}

		public GetNumberBuilder<T> number(final T value) {
			number = Objects.requireNonNull(value);

			return this;
		}

		public GetNumberBuilder<T> range(final Comparable<T> minimum, final Comparable<T> maximum) {
			this.maximum = Objects.requireNonNull(maximum);
			this.minimum = Objects.requireNonNull(minimum);

			return this;
		}

		public GetNumberBuilder<T> title(final String value) {
			title = Objects.requireNonNull(value);

			return this;
		}

	}

	/**
	 * @since 4.4
	 */
	public static final class GetTextBuilder {
	
		// private
		
		private boolean allowEmptyText;
		private boolean editable = true;
		private boolean multiline;
		private String autoCompletion = "input";
		private String icon;
		private String label;
		private String text;
		private String title;
	
		// public
		
		public GetTextBuilder() { }

		/**
		 * @since 4.4
		 */
		public GetTextBuilder allowEmptyText(final boolean allowEmptyText) {
			this.allowEmptyText = allowEmptyText;
			
			return this;
		}

		public GetTextBuilder autoCompletion(final String autoCompletion) {
			this.autoCompletion = autoCompletion;
			
			return this;
		}
		
		public MMessage<MTextFieldPanel> build(final Component owner) {
			return Input.createMessage(
				(owner instanceof Window) ? (Window)owner : UI.windowFor(owner),
				text,
				label,
				title,
				icon,
				autoCompletion
			);
		}

		public GetTextBuilder editable(final boolean editable) {
			this.editable = editable;
			
			return this;
		}
		
		public String exec(final Component owner) {
			Window window = (owner instanceof Window) ? (Window)owner : UI.windowFor(owner);
			
			if (multiline)
				return Input.getLargeText(window, text, title, editable);

			MMessage<MTextFieldPanel> base = Input.createMessage(window, text, label, title, icon, autoCompletion);
			
			if (allowEmptyText) {
				base.getValidatorSupport().getAll()
					.removeIf(i -> (i instanceof NotEmptyValidator));
			}

			if (base.exec(base.getView()))
				return base.getView().getText();

			return null;
		}
		
		public String exec(final MAction owner) {
			return exec(owner.getSourceWindow());
		}
		
		public String exec() {
			return exec(UI.windowFor(null));
		}
		
		public GetTextBuilder icon(final String icon) {
			this.icon = icon;
			
			return this;
		}

		public GetTextBuilder label(final String label) {
			this.label = label;
			
			return this;
		}

		public GetTextBuilder multiline(final boolean multiline) {
			this.multiline = multiline;
			
			return this;
		}

		public GetTextBuilder text(final String text) {
			this.text = text;
			
			return this;
		}

		public GetTextBuilder title(final MActionInfo title) {
			this.icon = title.getIconName();
			this.title = title.getDialogTitle();
			
			return this;
		}

		public GetTextBuilder title(final String title) {
			this.title = title;
			
			return this;
		}

	}
	
	/**
	 * @mg.note
	 * The initial window size is undefined.
	 *
	 * @since 4.0
	 */
	public static class NewPasswordDialog extends MDialog {
	
		// private
		
		private MPasswordPanel passwordPanel;
	
		// public
		
		public NewPasswordDialog(final Window owner, final String prompt, final int passwordPanelFlags) {
			this(owner, prompt, passwordPanelFlags, STANDARD_DIALOG);
		}
		
		/**
		 * @since 4.10
		 */
		public NewPasswordDialog(final Window owner, final String prompt, final int passwordPanelFlags, final int dialogFlags) {
			super(
				owner,
				i18n("New Password"),
				"ui/password",
				dialogFlags
			);
			passwordPanel = new MPasswordPanel(passwordPanelFlags, prompt);
			addCenter(passwordPanel);
			
			if ((passwordPanelFlags & MPasswordPanel.ENCRYPT_BUTTON) != 0) {
				getOKButton().setText(i18n("Encrypt"));
				getOKButton().setIconNameUI("ui/password");
			}
		
			passwordPanel.installValidators(getValidatorSupport());
			installValidatorMessage();
		}
		
		public MPasswordPanel getPasswordPanel() { return passwordPanel; }
		
		// protected
		
		@Override
		protected void onClose() {
			super.onClose();
			passwordPanel.uninstallValidators(getValidatorSupport());
		}
	
	}
	
	// private classes
	
	private static final class SetDateAction extends MDataAction.Weak<MCalendarPanel> {
	
		// private
		
		private final int change;
		private final int field;
	
		// public
		
		public SetDateAction(final MCalendarPanel calendarPanel, final String name, final int field, final int change) {
			super(calendarPanel, name);
			this.field = field;
			this.change = change;
		}
		
		@Override
		public void onAction() {
			get().addCalendarField(field, change);
		}
	
	}

}
