// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.event;

import java.lang.ref.WeakReference;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;

import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Obsolete;

/**
 * @since 4.0 (org.makagiga.commons.swing.event package)
 */
@Obsolete
public class MDocumentAdapter<T extends JTextComponent> implements DocumentListener {

	// private

	private WeakReference<T> textComponentRef;
	
	// public
	
	public MDocumentAdapter() { }

	/**
	 * @since 3.4
	 */
	public MDocumentAdapter(final T textComponent) {
		textComponentRef = new WeakReference<>(textComponent);
	}
	
	@Override
	public void changedUpdate(final DocumentEvent e) {
		onChange(e);
	}
	
	@Override
	public void insertUpdate(final DocumentEvent e) {
		onChange(e);
	}
	
	@Override
	public void removeUpdate(final DocumentEvent e) {
		onChange(e);
	}

	// protected

	/**
	 * @since 3.4
	 */
	protected T getTextComponent() {
		return TK.get(textComponentRef);
	}
	
	protected void onChange(final DocumentEvent e) { }
	
}
