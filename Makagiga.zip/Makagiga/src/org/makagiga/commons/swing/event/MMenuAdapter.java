// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.event;

import javax.swing.JMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import org.makagiga.commons.swing.MMenu;

/**
 * An adapter for receiving menu events.
 * 
 * @since 4.0 (org.makagiga.commons.swing.event package)
 *
 * @deprecated Since 5.4
 */
@Deprecated
public class MMenuAdapter implements MenuListener {
	
	// private
	
	private boolean removeAllOnDeselect;

	// public
	
	public MMenuAdapter() {
		this(false);
	}

	public MMenuAdapter(final boolean removeAllOnDeselect) {
		this.removeAllOnDeselect = removeAllOnDeselect;
	}

	/**
	 * Invoked when the menu is canceled.
	 * By default this function does nothing.
	 * @param e A menu event
	 */
	@Override
	public void menuCanceled(final MenuEvent e) { }

	/**
	 * Invoked when the menu is deselected.
	 * By default this function does nothing.
	 * @param e A menu event
	 */
	@Override
	public void menuDeselected(final MenuEvent e) {
		if (removeAllOnDeselect && (e.getSource() instanceof JMenu))
			JMenu.class.cast(e.getSource()).removeAll();
	}

	/**
	 * Invoked when the menu is selected.
	 * By default this function does nothing.
	 * @param e A menu event
	 */
	@Override
	public final void menuSelected(final MenuEvent e) {
		onSelect((MMenu)e.getSource());
	}
	
	// protected
	
	protected void onSelect(final MMenu menu) { }

}
