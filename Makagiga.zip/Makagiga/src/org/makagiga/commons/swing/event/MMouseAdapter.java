// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.event;

import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragSource;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.TransferHandler;

import org.makagiga.commons.UI;

/**
 * A mouse adapter.
 *
 * @mg.example
 * <pre class="brush: java">
 * addMouseListener(new MMouseAdapter() {
 *   {@literal @}Override
 *   public void mouseClicked(final MouseEvent e) {
 *     if (isLeft(e) &amp;&amp; isDoubleClick(e)) {
 *       // left button double clicked
 *     }
 *   }
 *   {@literal @}Override
 *   public void popupTrigger(final MouseEvent e) {
 *     // show context menu here
 *   }
 * } );
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.swing.event package)
 */
public class MMouseAdapter extends MouseAdapter {

	// private
	
	private transient long lastPopupTriggerTime = System.currentTimeMillis();
	private final Point pressedPoint = new Point(-1, -1);

	// public
	
	public MMouseAdapter() { }

	/**
	 * @since 5.0
	 */
	public void buttonClicked(final MouseEvent e) { }

	/**
	 * @since 5.0
	 */
	public static boolean isButtonClick(final MouseEvent e, final Point pressedPoint) {
		int i =
			((pressedPoint.x == -1) && (pressedPoint.y == -1))
			? 0
			: (int)pressedPoint.distance(e.getX(), e.getY());

		// DOC: http://docs.oracle.com/javase/7/docs/api/java/awt/dnd/MouseDragGestureRecognizer.html
		return i <= DragSource.getDragThreshold();
	}

	/**
	 * Returns @c true if is <i>double click</i>.
	 */
	public static boolean isDoubleClick(final MouseEvent e) {
		return e.getClickCount() == 2;
	}

	/**
	 * Returns @c true if left mouse button is pressed.
	 * @param e A mouse event
	 */
	public static boolean isLeft(final MouseEvent e) {
		return (e.getModifiers() & MouseEvent.BUTTON1_MASK) != 0;
	}

	/**
	 * Returns @c true if middle mouse button is pressed.
	 * @param e A mouse event
	 */
	public static boolean isMiddle(final MouseEvent e) {
		return (e.getModifiers() & MouseEvent.BUTTON2_MASK) != 0;
	}

	public static boolean isRight(final MouseEvent e) {
		return (e.getModifiers() & MouseEvent.BUTTON3_MASK) != 0;
	}

	public static boolean isSingleClick(final MouseEvent e) {
		return e.getClickCount() == 1;
	}

	/**
	 * Overriden to call @ref popupTrigger.
	 * @param e A mouse event
	 */
	@Override
	public void mousePressed(final MouseEvent e) {
		doPopupTrigger(e, false);
		pressedPoint.setLocation(e.getX(), e.getY());
	}

	/**
	 * Overriden to call @ref popupTrigger.
	 * @param e A mouse event
	 */
	@Override
	public void mouseReleased(final MouseEvent e) {
		doPopupTrigger(e, true);

		// A button-style mouse handling where "click" (buttonClicked method) event
		// is performed even if mouse was dragged/moved after an initial press.
		if (!e.isConsumed() && (e.getComponent() != null) && isButtonClick(e, pressedPoint)) {
			buttonClicked(new MouseEvent(
				e.getComponent(), // source
				MouseEvent.MOUSE_CLICKED, // fake id
				e.getWhen(),
				e.getModifiers(),
				e.getX(), e.getY(),
				1, // fake click count
				false // popup trigger
			));
		}
	}

	/**
	 * Override if you want to display a context popup menu.
	 * By default this function does nothing.
	 * @param e A mouse event
	 */
	public void popupTrigger(final MouseEvent e) { }
	
	// private
	
	private void doPopupTrigger(final MouseEvent e, final boolean released) {
		if (
			(UI.mouseGestures.get() && isRight(e) && released) ||
			(!UI.mouseGestures.get() && e.isPopupTrigger())
		) {
			// HACK: Discard duplicated popup event
			// to avoid two popupTrigger calls.
			if (e.getWhen() != lastPopupTriggerTime) {
				lastPopupTriggerTime = e.getWhen();
				popupTrigger(e);
				e.consume();
			}
		}
	}
	
	// public classes
	
	/**
	 * @since 3.0
	 */
	public static abstract class Drag extends MouseMotionAdapter {
		
		// private
		
		private final int sourceActions;
		
		// public
		
		public Drag(final int sourceActions) {
			this.sourceActions = sourceActions;
		}
		
		public Drag(final JComponent c, final int sourceActions) {
			this.sourceActions = sourceActions;
			c.addMouseMotionListener(this);
		}
		
		@Override
		public final void mouseDragged(final MouseEvent e) {
			if (!MMouseAdapter.isLeft(e))
				return;

			if (!canDrag(e))
				return;

			TransferHandler handler = new TransferHandler() {
				@Override
				public Transferable createTransferable(final JComponent c) {
					this.setDragImage(MMouseAdapter.Drag.this.createDragImage(e));
				
					return MMouseAdapter.Drag.this.createTransferable(e);
				}
				@Override
				public int getSourceActions(final JComponent c) {
					return MMouseAdapter.Drag.this.sourceActions;
				}
			};
			JComponent c = (JComponent)e.getSource();
			c.setTransferHandler(handler);
			handler.exportAsDrag(c, e, sourceActions);
			
			// HACK: do not fire action event on focus lost
			if (c instanceof AbstractButton)
				AbstractButton.class.cast(c).getModel().setArmed(false);
		}

		// protected
		
		protected boolean canDrag(final MouseEvent e) { return true; }
		
		/**
		 * @since 4.6
		 */
		protected Image createDragImage(final MouseEvent e) { return null; }
		
		protected abstract Transferable createTransferable(final MouseEvent e);
		
	}

}
