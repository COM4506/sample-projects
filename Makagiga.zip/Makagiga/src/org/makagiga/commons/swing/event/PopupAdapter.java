// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.event;

import java.awt.Component;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.Objects;
import java.util.function.Consumer;

import org.makagiga.commons.UI;

/**
 * @since 5.0
 */
public class PopupAdapter extends MMouseAdapter implements KeyListener {

	// private

	private final Consumer<InputEvent> onPopup;

	// public

	public PopupAdapter(final Consumer<InputEvent> onPopup) {
		this.onPopup = Objects.requireNonNull(onPopup);
	}

	public void install(final Component component) {
		component.addKeyListener(this);
		component.addMouseListener(this);
	}

	public void uninstall(final Component component) {
		component.removeKeyListener(this);
		component.removeMouseListener(this);
	}

	@Override
	public void popupTrigger(final MouseEvent e) {
		onPopup.accept(e);
	}

	// KeyListener

	@Override
	public void keyPressed(final KeyEvent e) {
		if (UI.isPopupTrigger(e))
			onPopup.accept(e);
	}

	@Override
	public void keyReleased(final KeyEvent e) { }

	@Override
	public void keyTyped(final KeyEvent e) { }

}
