// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.util.Comparator;
import java.util.Objects;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

import org.makagiga.commons.TK;
import org.makagiga.commons.mv.MV;

/**
 * A tree model.
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MTreeModel<I extends MTreeItem> extends DefaultTreeModel {

	// private
	
	private MV filterMode = MV.VIEW;
	
	// public

	/**
	 * Constructs a tree model with @c null root node.
	 */
	public MTreeModel() {
		this(null);
	}

	/**
	 * Constructs a tree model.
	 *
	 * @param root The root node
	 */
	public MTreeModel(final TreeNode root) {
		super(root);
	}

	@Override
	public Object getChild(final Object parent, final int index) {
		return MTreeItem.class.cast(parent).getChildAt(index, filterMode);
	}

	@Override
	public int getChildCount(final Object parent) {
		return MTreeItem.class.cast(parent).getChildCount(filterMode);
	}
	
	/**
	 * @since 4.2
	 */
	public MV getFilterMode() { return filterMode; }
	
	/**
	 * @since 4.2
	 */
	public void setFilterMode(final MV modelView) {
		filterMode = Objects.requireNonNull(modelView);
	}
	
	@Override
	public int getIndexOfChild(final Object parent, final Object child) {
		if ((parent == null) || (child == null))
			return -1;
		
		return MTreeItem.class.cast(parent).getIndex((TreeNode)child, filterMode);
	}

	@SuppressWarnings("unchecked")
	public I getRootItem() {
		return (I)getRoot();
	}

	public void setRootItem(final I value) {
		setRoot(value);
	}
	
	@Override
	public void nodeChanged(final TreeNode node) {
		if ((listenerList == null) || (node == null))
			return;
		
		if (node == getRoot()) {
			super.nodeChanged(node);
			
			return;
		}
		
		TreeNode parent = node.getParent();
		if (parent != null) {
			int i = MTreeItem.class.cast(parent).getIndex(node, filterMode);
			if (i != -1)
				nodesChanged(parent, new int[] { i });
		}
	}

	/**
	 * @since 3.0
	 */
	public void setAllVisible(final boolean visible) {
		new MTreeScanner<I>(getRootItem()) {
			@Override
			public void processItem(final I item) {
				item.setVisible(visible);
			}
			@Override
			public void processParent(final I item) {
				item.setVisible(visible);
			}
		};
		reload();
	}
	
	/**
	 * @since 3.0
	 */
	public void sort(final I item) {
		sort(item, null);
	}

	/**
	 * @since 3.0
	 */
	public void sort(final I item, final Comparator<MutableTreeNode> comparator) {
		if (!TK.isEmpty(item.children) && !item.isLeaf()) {
			item.children.sort(comparator);
			reload(item);
		}
	}

}
