// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.AWTEvent;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.StringJoiner;
import java.util.TreeMap;
import javax.swing.Action;
import javax.swing.JLayeredPane;
import javax.swing.MenuSelectionManager;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.commons.validator.Validator;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MouseGestures implements AWTEventListener {
	
	// private

	private boolean initDone;
	private final Map<String, Action> gestureMap;
	private MMessageLabel help;
	private Point oldPoint;
	private String moves;
	private WeakReference<Window> ownerRef;
	
	// public
	
	public MouseGestures() {
		this(null);
	}
	
	public MouseGestures(final Window owner) {
		gestureMap = new TreeMap<>();
		setOwner(owner);
		
		reset();
		Toolkit.getDefaultToolkit().addAWTEventListener(this, AWTEvent.MOUSE_EVENT_MASK | AWTEvent.MOUSE_MOTION_EVENT_MASK);
	}

	/**
	 * @since 3.8
	 */
	public void add(final Action action) {
		String gesture = MAction.getValue(action, MAction.MOUSE_GESTURE_KEY, null);
		add(gesture, action);
	}

	/**
	 * @since 4.0
	 */
	public void add(final String gesture, final Action action) {
		TK.checkNullOrEmpty(gesture);
		gestureMap.put(gesture, action);
	}

	@Override
	public void eventDispatched(final AWTEvent awtEvent) {
		if ((awtEvent.getID() & AWTEvent.MOUSE_EVENT_MASK) != 0) {
			MouseEvent e = (MouseEvent)awtEvent;
			switch (e.getID()) {
				case MouseEvent.MOUSE_CLICKED:
				case MouseEvent.MOUSE_RELEASED:
					if (!TK.isEmpty(moves)) {
						if (canShowMessage() && (help != null)) {
							help.setVisible(false);
							MComponent.removeFromParent(help, false);
						}
							
						if (canProcess()) {
							Action action = findGestureAction(e);
							if (action != null) {
								Window window = getOwner();
								MAction.fire(
									action,
									(window instanceof MFrame)
										? MFrame.class.cast(window).getJMenuBar()
										: null
								);
							}
							onGestureEnd();
							e.consume();
						}
						reset();
					}
					break;
				case MouseEvent.MOUSE_DRAGGED:
					if (MMouseAdapter.isRight(e) && recognizeGesture(e)) {
						if (moves.length() == 1) {
							init();
							onGestureStart();
						}
							
						if (gestureMap.isEmpty())
							return;

						if (canShowMessage()) {
							Action action = findGestureAction(e);
							String displayGesture = toDisplayString(moves + getModifiers(e));
							String gestureTag = "<span style=\"font-size: larger; font-weight: bold\">";
							String message;
							Validator.MessageType messageType;
							if (action == null) {
								message = i18n("Unknown Mouse Gesture (see Help): {0}", gestureTag + displayGesture + "</span>");
								messageType = Validator.MessageType.ERROR;
							}
							else {
								String name = (String)action.getValue(Action.NAME);
								if (action.isEnabled()) {
									message = i18n("Mouse Gesture: {0}", String.format(gestureTag + "%s</span> (%s)", displayGesture, TK.escapeXML(name)));
									messageType = Validator.MessageType.INFO;
								}
								else {
									message = String.format("%s: " + gestureTag + "%s</span> (%s)", i18n("Action Not Available"), displayGesture, TK.escapeXML(name));
									messageType = Validator.MessageType.WARNING;
								}
							}
							
							HTMLBuilder html = HTMLBuilder.newSwingDoc();
							
							html.doubleTag("p", message/*, "style", "margin-bottom: 5px"*/);
							
							html.singleTag("hr");

							html.beginTag("table");
							for (Map.Entry<String, Action> i : getMap().entrySet()) {
								String key = i.getKey();
								
								if (key.equals(moves) || !key.startsWith(moves) || (i.getValue() == action))
									continue; // for
							
								String name = (String)i.getValue().getValue(Action.NAME); // uh
								html.beginTag("tr");
								html.doubleTag(
									"td",
									gestureTag + html.escape(toDisplayString(key)) + "</span>"
								);
								html.doubleTag("td", html.escape(name));
								html.endTag("tr");
							}
							html.endTag("table");

							html.endSwingDoc();
							
							showHelp(html.toString(), messageType);
						}
						onGesture();
						e.consume();
					}
					break;
				case MouseEvent.MOUSE_PRESSED:
					reset();
					break;
			}

		}
	}

	/**
	 * @since 4.0
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public String formatGesture(final String gesture, final boolean includeModifiers) {
		return toDisplayString(gesture);
	}

	/**
	 * @since 4.0
	 */
	public Map<String, Action> getMap() {
		init();

		return gestureMap;
	}

	/**
	 * @since 4.0
	 */
	public Window getOwner() {
		return ownerRef.get();
	}

	/**
	 * @since 4.0
	 */
	@InvokedFromConstructor
	public void setOwner(final Window value) {
		ownerRef = new WeakReference<>(value);
	}

	/**
	 * @since 5.6
	 */
	public static String toDisplayString(final String gesture) {
		int modifiers = 0;
		StringJoiner result = new StringJoiner(" ");

		for (int i = 0; i < gesture.length(); i++) {
			char c = gesture.charAt(i);
			switch (c) {
				case 'c':
					modifiers |= KeyEvent.CTRL_MASK;
					break;
				case 's':
					modifiers |= KeyEvent.SHIFT_MASK;
					break;
				case 'L':
					result.add("\u2190");
					break;
				case 'R':
					result.add("\u2192");
					break;
				case 'U':
					result.add("\u2191");
					break;
				case 'D':
					result.add("\u2193");
					break;
				default:
					MLogger.error("gesture", "Unknown element \"%s\" in gesture \"%s\"", c, gesture);
			}
		}

		if (modifiers != 0)
			return KeyEvent.getKeyModifiersText(modifiers) + " " + result;

		return result.toString();
	}

	// protected

	/**
	 * @since 3.0
	 */
	protected boolean canShowMessage() { return true; }

	protected void onGesture() { }
	
	protected void onGestureEnd() { }
	
	protected void onGestureStart() { }

	/**
	 * @since 4.0
	 */
	protected void onInit() { }

	// private
	
	private void appendMove(final char move) {
		if (moves.isEmpty())
			moves += move;
		else if (moves.charAt(moves.length() - 1) != move)
			moves += move;
	}
	
	private boolean canProcess() {
		if (!UI.mouseGestures.get())
			return false;
		
		// popup menu?
		if (MenuSelectionManager.defaultManager().getSelectedPath().length > 0)
			return false;

		Window window = getOwner();

		return (window != null) && window.isActive();
	}
	
	private Action findGestureAction(final MouseEvent e) {
		String modifiers = getModifiers(e);
		Action action = gestureMap.get(moves + modifiers);
		
		// ignore modifiers
		if ((action == null) && !modifiers.isEmpty())
			action = gestureMap.get(moves);
		
		return action;
	}

	private String getModifiers(final MouseEvent e) {
		String modifiers = "";
		// no Alt
		if (e.isControlDown())
			modifiers += "c";
		if (e.isShiftDown())
			modifiers += "s";

		return modifiers;
	}

	private synchronized void init() {
		if (initDone)
			return;

		initDone = true;
		onInit();
	}

	private boolean recognizeGesture(final MouseEvent e) {
		if (oldPoint == null) {
			oldPoint = e.getLocationOnScreen();
			
			return false;
		}
		
		if (!canProcess())
			return false;
		
		int grid = 32;
		
		if (Math.abs(e.getXOnScreen() - oldPoint.x) >= grid) {
			if (e.getXOnScreen() < oldPoint.x)
				appendMove('L');
			else
				appendMove('R');
			oldPoint = e.getLocationOnScreen();
			
			return true;
		}

		if (Math.abs(e.getYOnScreen() - oldPoint.y) >= grid) {
			if (e.getYOnScreen() < oldPoint.y)
				appendMove('U');
			else
				appendMove('D');
			oldPoint = e.getLocationOnScreen();
			
			return true;
		}
		
		return false;
	}
	
	private void reset() {
		oldPoint = null;
		moves = "";
	}
	
	private void showHelp(final String text, final Validator.MessageType type) {
		Window owner = getOwner();
		
		if (owner == null)
			return;
		
		JLayeredPane lp = (owner instanceof MFrame) ? MFrame.class.cast(owner).getLayeredPane() : null;
		
		if (lp == null)
			return;
		
		if (help == null) {
			help = new MMessageLabel();
			// NOTE: need Font.DIALOG font to display correctly some Unicode characters
			help.setStyle("font-family: " + Font.DIALOG + "; font-size: larger");
		}
		switch (type) {
			case ERROR:
				help.setErrorMessage(text);
				break;
			case INFO:
				help.setOKMessage(text);
				break;
			case WARNING:
				help.setWarningMessage(text);
				break;
			default: throw new WTFError(type);
		}
	
		help.setSize(help.getPreferredSize());
		// center
		help.setLocation(
			lp.getWidth() / 2 - help.getWidth() / 2,
			lp.getHeight() / 2 - help.getHeight() / 2
		);
		if (help.getParent() != lp)
			lp.add(help, JLayeredPane.POPUP_LAYER);
		help.setVisible(true);
	}

}
