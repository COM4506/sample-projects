// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.swing.event.UndoableEditListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoableEdit;
import javax.swing.undo.UndoableEditSupport;

import org.makagiga.commons.Lockable;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public abstract class AbstractListTableModel<T> extends AbstractTableModel
implements
	Iterable<T>,
	Lockable,
	UI.EventsControl
{
	
	// private

	private boolean eventsEnabled = true;
	private boolean locked;
	private boolean undoInProgress;
	private ColumnInfo[] columnInfo;
	private int columnCount;
	private List<T> backend;
	private UndoableEditSupport undoSupport;
	
	// public
	
	/**
	 * @throws NullPointerException If @p backend is @c null
	 */
	public AbstractListTableModel(final int columnCount, final List<T> backend) {
		this.columnCount = columnCount;
		this.backend = Objects.requireNonNull(backend, "backend");
	}

	/**
	 * @throws IllegalArgumentException If @p columnInfo length is zero
	 * @throws NullPointerException If @p columnInfo is @c null
	 * 
	 * @since 2.2
	 */
	public AbstractListTableModel(final ColumnInfo... columnInfo) {
		this(new MArrayList<T>(100), columnInfo);
	}

	/**
	 * @throws IllegalArgumentException If @p columnInfo length is zero
	 * @throws NullPointerException If @p backend or @p columnInfo is @c null
	 * 
	 * @since 2.4
	 */
	public AbstractListTableModel(final List<T> backend, final ColumnInfo... columnInfo) {
		this(columnInfo.length, backend);
		setColumnInfo(columnInfo);
	}

	public void addRow(final T row) {
		backend.add(row);
		if (eventsEnabled) {
			int i = backend.size() - 1;
			T copy = createCopyForUndo(row);
			fireTableRowsInserted(i, i);
			if (copy != null)
				fireUndoableEditHappened(new InsertUndo(copy, i));
		}
	}

	public void addUndoableEditListener(final UndoableEditListener l) {
		if (undoSupport == null)
			undoSupport = new UndoableEditSupport();
		undoSupport.addUndoableEditListener(l);
	}
	
	/**
	 * @since 3.0
	 */
	public UndoableEditListener[] getUndoableEditListeners() {
		if (undoSupport != null)
			return undoSupport.getUndoableEditListeners();
		
		return MUndoManager.EMPTY_UNDOABLE_EDIT_LISTENER_ARRAY;
	}
		
	public void removeUndoableEditListener(final UndoableEditListener l) {
		if (undoSupport != null)
			undoSupport.removeUndoableEditListener(l);
	}

	public void clear() {
		if (backend.isEmpty())
			return;

		int size = backend.size();
		List<T> copy = eventsEnabled ? createCopyForUndo(0, size) : null;
		backend.clear();
		if (eventsEnabled) {
			fireTableRowsDeleted(0, size - 1);
			if (copy != null)
				fireUndoableEditHappened(new RemoveUndo(copy, 0));
		}
	}

	@Override
	public Class<?> getColumnClass(final int column) {
		return
			(columnInfo == null)
			? super.getColumnClass(column)
			: columnInfo[column].getColumnClass();
	}

	@Override
	public int getColumnCount() { return columnCount; }

	/**
	 * @since 3.8
	 */
	public ColumnInfo[] getColumnInfo() {
		if (columnInfo == null)
			return new ColumnInfo[0];

		return columnInfo.clone();
	}

	@Override
	public String getColumnName(final int column) {
		return
			(columnInfo == null)
			? super.getColumnName(column)
			: columnInfo[column].getName();
	}

	@Override
	public boolean getEventsEnabled() { return eventsEnabled; }
		
	@Override
	public void setEventsEnabled(final boolean value) { eventsEnabled = value; }
	
	public T getRowAt(final int index) {
		return backend.get(index);
	}

	@Override
	public int getRowCount() {
		return backend.size();
	}

	public List<T> getRows() { return backend; }

	public void insertRow(final int index, final T row) {
		backend.add(index, row);
		if (eventsEnabled) {
			T copy = createCopyForUndo(row);
			fireTableRowsInserted(index, index);
			if (copy != null)
				fireUndoableEditHappened(new InsertUndo(copy, index));
		}
	}

	@Override
	public boolean isCellEditable(final int row, final int column) {
		if (locked)
			return false;
		
		return
			(columnInfo == null)
			? true
			: columnInfo[column].isEditable();
	}

	public boolean isEmpty() {
		return backend.isEmpty();
	}
	
	public void removeRow(final int index) {
		List<T> copy = eventsEnabled ? createCopyForUndo(index, 1) : null;
		backend.remove(index);
		if (eventsEnabled) {
			fireTableRowsDeleted(index, index);
			if (copy != null)
				fireUndoableEditHappened(new RemoveUndo(copy, index));
		}
	}
	
	// Iterable
	
	@Override
	public Iterator<T> iterator() {
		return backend.iterator();
	}
	
	// Lockable
	
	@Override
	public boolean isLocked() { return locked; }
	
	@Override
	public void setLocked(final boolean value) { locked = value; }

	// protected

	protected T createCopyForUndo(final T original) { return original; }
	
	protected void fireUndoableEditHappened(final UndoableEdit edit) {
		if (undoInProgress)
			return;
		
		if (undoSupport != null)
			undoSupport.postEdit(edit);
	}
	
	/**
	 * @since 3.0
	 */
	@InvokedFromConstructor
	protected void setColumnInfo(final ColumnInfo... columnInfo) {
		if (columnInfo.length == 0)
			throw new IllegalArgumentException("Empty \"columnInfo\" array");

		this.columnCount = columnInfo.length;
		this.columnInfo = columnInfo.clone();
	}
	
	// private
	
	private List<T> createCopyForUndo(final int startRow, final int count) {
		List<T> result = new MArrayList<>(count);
		int index = startRow;
		for (int i = 0; i < count; i++) {
			result.add(createCopyForUndo(backend.get(index)));
			index++;
		}
		
		return result;
	}

	private void doRedoChange(final Runnable action) {
		try {
			undoInProgress = true;
			action.run();
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			CannotRedoException e = new CannotRedoException();
			e.initCause(exception);

			throw e;
		}
		finally {
			undoInProgress = false;
		}
	}

	private void doUndoChange(final Runnable action) {
		try {
			undoInProgress = true;
			action.run();
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			CannotUndoException e = new CannotUndoException();
			e.initCause(exception);

			throw e;
		}
		finally {
			undoInProgress = false;
		}
	}
	
	// public classes
	
	/**
	 * @since 2.2, 4.0 (extends Object)
	 */
	public static class ColumnInfo {
// TODO: ColumnInfo<T>, functional interface for value getter/setter
		
		// private
		
		private final boolean editable;
		private final Class<?> columnClass;
		private int defaultWidth = -1;
		private final String id;
		private final String name;
		
		// public

		/**
		 * @since 3.8
		 */
		public ColumnInfo(final String name, final boolean editable, final String id) {
			this(name, Object.class, editable, id);
		}

		public ColumnInfo(final String name, final Class<?> columnClass) {
			this(name, columnClass, true, null);
		}
		
		public ColumnInfo(final String name, final Class<?> columnClass, final boolean editable) {
			this(name, columnClass, editable, null);
		}

		/**
		 * @since 3.8
		 */
		public ColumnInfo(final String name, final Class<?> columnClass, final boolean editable, final String id) {
			this.name = name;
			this.columnClass = Objects.requireNonNull(columnClass, "columnClass");
			this.editable = editable;
			this.id = id;
		}

		public Class<?> getColumnClass() { return columnClass; }

		/**
		 * @since 4.0
		 */
		public int getDefaultWidth() { return defaultWidth; }

		/**
		 * @since 4.0
		 */
		public void setDefaultWidth(final int value) { defaultWidth = value; }

		/**
		 * @since 4.0
		 */
		public String getID() { return id; }
		
		public String getName() { return name; }

		public boolean isEditable() { return editable; }
		
	}

	public final class ChangeUndo extends AbstractUndoableEdit {

		// private
		
		private final int row;
		private final T after;
		private final T before;
		
		// public

		public ChangeUndo(final T before, final T after, final int row) {
			this.before = before;
			this.after = after;
			this.row = row;
		}

		@Override
		public void redo() {
			super.redo();
			AbstractListTableModel.this.doRedoChange(() -> {
				AbstractListTableModel.this.backend.set(row, after);
				AbstractListTableModel.this.fireTableRowsUpdated(row, row);
			} );
		}

		@Override
		public void undo() {
			super.undo();
			AbstractListTableModel.this.doUndoChange(() -> {
				AbstractListTableModel.this.backend.set(row, before);
				AbstractListTableModel.this.fireTableRowsUpdated(row, row);
			} );
		}
		
	}
	
	public final class InsertUndo extends AbstractUndoableEdit {
		
		// private
		
		private final int row;
		private final T data;

		// public

		public InsertUndo(final T data, final int row) {
			this.data = data;
			this.row = row;
		}

		@Override
		public void redo() {
			super.redo();
			AbstractListTableModel.this.doRedoChange(() -> {
				AbstractListTableModel.this.insertRow(row, data);
			} );
		}

		@Override
		public void undo() {
			super.undo();
			AbstractListTableModel.this.doUndoChange(() -> {
				AbstractListTableModel.this.removeRow(row);
			} );
		}

	}

	public final class RemoveUndo extends AbstractUndoableEdit {
		
		// private

		private final int row;
		private final List<T> data;

		// public

		public RemoveUndo(final List<T> data, final int row) {
			this.data = data;
			this.row = row;
		}

		@Override
		public void redo() {
			super.redo();
			AbstractListTableModel.this.doRedoChange(() -> {
				int count = data.size();
				for (int i = row + count - 1; i >= row; --i)
					AbstractListTableModel.this.removeRow(i);
			} );
		}

		@Override
		public void undo() {
			super.undo();
			AbstractListTableModel.this.doUndoChange(() -> {
				int insertRow = row;
				for (T i : data) {
					AbstractListTableModel.this.insertRow(insertRow, i);
					insertRow++;
				}
			} );
		}

	}

}
