// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.text.Format;
import java.util.Arrays;
import java.util.List;
import javax.swing.JFormattedTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.InternationalFormatter;
import javax.swing.text.JTextComponent;
import javax.swing.text.Position;
import javax.swing.text.View;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.event.MDocumentAdapter;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MHighlighter<T extends JTextComponent> extends DefaultHighlighter {
	
	// public
	
	/**
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static final Color DEFAULT_COLOR = MColor.SUN_YELLOW_2;

	/**
	 * @see org.makagiga.commons.MColor#BRICK_RED
	 */
	public static final Color ERROR_COLOR = MColor.BRICK_RED;

	/**
	 * @see org.makagiga.commons.MColor#OXYGEN_BLUE
	 *
	 * @since 5.0
	 */
	public static final Color INFO_COLOR = MColor.OXYGEN_BLUE;

	/**
	 * @see org.makagiga.commons.MColor#FOREST_GREEN
	 */
	public static final Color OK_COLOR = MColor.FOREST_GREEN;

	/**
	 * @preview.color #fff299
	 */
	public static final Color SEARCH_COLOR = DEFAULT_COLOR;

	/**
	 * @see org.makagiga.commons.MColor#HOT_ORANGE
	 */
	public static final Color WARNING_COLOR = MColor.HOT_ORANGE;
	
	// private
	
	private boolean disableIfSelection = true;
	private boolean highlightFields;
	private final Insets padding = UI.createInsets(0);
	private List<Object> userHighlights;
	
	// public
	
	public HighlightPainter addHighlight(final int start, final Color color) {
		return addHighlight(start, start + 1, color, false);
	}
	
	public HighlightPainter addHighlight(final int start, final Color color, final boolean rounded) {
		return addHighlight(start, start + 1, color, rounded);
	}
	
	public HighlightPainter addHighlight(final int start, final int end, final Color color) {
		return addHighlight(start, end, color, false);
	}
	
	public HighlightPainter addHighlight(final int start, final int end, final Color color, final boolean rounded) {
		try {
			HighlightPainter highlightPainter;
			if (rounded) {
				RoundedPainter roundedPainter = new RoundedPainter(color);
				roundedPainter.padding = padding;
				highlightPainter = roundedPainter;
			}
			else {
				highlightPainter = new DefaultHighlightPainter(color);
			}
			if (userHighlights == null)
				userHighlights = new MArrayList<>();
			userHighlights.add(addHighlight(start, end, highlightPainter));
			
			return highlightPainter;
		}
		catch (BadLocationException exception) {
			MLogger.exception(exception);
			
			return null;
		}
	}
	
	public boolean getDisableIfSelection() { return disableIfSelection; }
	
	public void setDisableIfSelection(final boolean value) { disableIfSelection = value; }
	
	/**
	 * @since 4.12
	 */
	public boolean getHighlightFields() { return highlightFields; }

	/**
	 * @since 4.12
	 */
	public void setHighlightFields(final boolean value) { highlightFields = value; }

	public static <T extends JTextComponent> MHighlighter<T> install(final T textComponent, final UserHighlight<T> userHighlight) {
		MHighlighter<T> h = new MHighlighter<>();

		StaticHandler<T> handler = new StaticHandler<>(textComponent, userHighlight);
		textComponent.addCaretListener(handler);
		textComponent.getDocument().addDocumentListener(handler);
		
		textComponent.setHighlighter(h);
		update(textComponent, userHighlight);
		
		return h;
	}

	public void removeUserHighlights() {
		if (userHighlights != null) {
			for (Object i : userHighlights)
				removeHighlight(i);
			userHighlights = null;
		}
	}

	public static boolean removeUserHighlights(final JTextComponent textComponent) {
		Highlighter h = textComponent.getHighlighter();
		if (h instanceof MHighlighter<?>) {
			MHighlighter<?> mh = (MHighlighter<?>)h;
			mh.removeUserHighlights();
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * Sets padding for rounded painter.
	 * The default value is zero.
	 * 
	 * @since 3.0
	 */
	public void setPadding(final int value) {
		padding.set(value, value, value, value);
	}

	public static <T extends JTextComponent> void update(final T textComponent, final UserHighlight<T> userHighlight) {
		if (removeUserHighlights(textComponent)) {
			@SuppressWarnings("unchecked")
			MHighlighter<T> h = (MHighlighter<T>)textComponent.getHighlighter();
			
			if (h.disableIfSelection && MText.hasSelection(textComponent))
				return;

			// NOTE: textComponent.getText() may return HTML tags
			String text = MText.getPlainText(textComponent);
			
			if (TK.isEmpty(text))
				return;

			// highlight active spinner fields
			if (h.highlightFields && (textComponent instanceof JFormattedTextField) && textComponent.isFocusOwner()) {
				JFormattedTextField.AbstractFormatter abstractFormatter =
					JFormattedTextField.class.cast(textComponent).getFormatter();
				if (abstractFormatter instanceof InternationalFormatter) {
					InternationalFormatter formatter = (InternationalFormatter)abstractFormatter;
					int currentPosition = textComponent.getCaretPosition();
					Format.Field[] currentFields = formatter.getFields(currentPosition);

					int start = -1;
					int end = -1;
					int len = textComponent.getDocument().getLength();

					if (currentFields.length > 0) {
						for (int i = 0; i < len; i++) {
							Format.Field[] f =
								(i == currentPosition)
								? currentFields
								: formatter.getFields(i);
							if ((start == -1) && Arrays.equals(f, currentFields))
								start = i;
							if ((end == -1) && (start != -1) && !Arrays.equals(f, currentFields)) {
								end = i;
								
								break; // for
							}
						}

						if (end == -1)
							end = len;
					}
/*
					else {
						start = 0;
						
						currentFields = formatter.getFields(0);
						
						for (int i = 1; i < len; i++) {
							Format.Field[] f = formatter.getFields(i);
							if (!Arrays.equals(f, currentFields)) {
								end = i;
								
								break; // for
							}
						}
					}
*/

					if ((start != -1) && (end != -1) && (end > start)) {
						Color bg =
							UI.isNimbus()
							? Color.WHITE
							: UI.getBackground(textComponent);
						bg = MColor.deriveColor(bg, 0.95f);

						h.addHighlight(start, end, bg);
					}
				}
			}

			userHighlight.highlight(h, textComponent, text);
		}
	}
	
	// public classes
	
	public static class RoundedPainter extends DefaultHighlightPainter {
		
		// private
		
		private Insets padding;
		
		// public
		
		public RoundedPainter(final Color color) {
			super(color);
		}
		
		@Override
		public Shape paintLayer(final Graphics graphics, final int offs0, final int offs1, final Shape bounds, final JTextComponent c, final View view) {
			try {
				Shape s = view.modelToView(offs0, Position.Bias.Forward, offs1, Position.Bias.Backward, bounds);
				if (s instanceof Rectangle) {
					Color color = getColor();
					
					// fix background color for dark look and feel themes
					Color bg = c.getBackground();
					if (MColor.isDark(bg))
						color = MColor.deriveColor(color, 0.6f);
					
					Graphics2D g = (Graphics2D)graphics;
					Rectangle r = new Rectangle((Rectangle)s);
					final int ARC = 8;
					Object oldAA = UI.setAntialiasing(g, true);

					// HACK: add left padding
					if (r.x > 5)
						r.x--;
					else
						r.width--;
					r.height--;
					
					if (padding != null)
						r.grow(padding.left, padding.top);
					
					g.setColor(color);
					g.fillRoundRect(r.x, r.y, r.width, r.height, ARC, ARC);
					
					g.setColor(MColor.deriveColor(color, 0.95f));
					g.drawRoundRect(r.x, r.y, r.width, r.height, ARC, ARC);
					
					g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, oldAA);
					
					return r;
				}
				else {
					return null;
				}
			}
			catch (BadLocationException exception) {
				MLogger.exception(exception);
				
				return null;
			}
		}
		
	}
	
	@FunctionalInterface
	public static interface UserHighlight<T extends JTextComponent> {
		
		// public
		
		public void highlight(final MHighlighter<T> h, final T textComponent, final String text);
		
	}

	// private classes

	private static final class StaticHandler<T extends JTextComponent> extends MDocumentAdapter<T> implements CaretListener {

		// private

		private final UserHighlight<T> userHighlight;

		// public

		@Override
		public void caretUpdate(final CaretEvent e) {
			doUpdate();
		}

		// protected

		@Override
		protected void onChange(final DocumentEvent e) {
			doUpdate();
		}

		// private

		private StaticHandler(final T textComponent, final UserHighlight<T> userHighlight) {
			super(textComponent);
			this.userHighlight = userHighlight;
		}

		private void doUpdate() {
			T textComponent = getTextComponent();
			if (textComponent != null)
				MHighlighter.update(textComponent, userHighlight);
		}

	}
	
}
