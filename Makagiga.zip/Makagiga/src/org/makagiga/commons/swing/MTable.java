// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.EventObject;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import javax.swing.CellEditor;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

import org.makagiga.commons.AbstractIterator;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.mv.MV;
import org.makagiga.commons.style.StyleSupport;
import org.makagiga.commons.swing.event.MMouseAdapter;

// TODO: 2.0: double click on the header should autoresize column (like in Qt or OO.org Calc)
/**
 * A table.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTable<M extends TableModel> extends JTable
implements
	Iterable<Integer>,
	MDisposable,
	MouseWheelListener,
	StyleSupport
{

	// public
	
	/**
	 * @since 4.4
	 */
	public static final int SELECTION_TEXT_ALL = Integer.MAX_VALUE;

	// private

	private boolean firstScrollHack = true;
	private ColumnManager<M> columnManager;
	private static final FixScrollRectToVisible fixScrollRectToVisible = new FixScrollRectToVisible();
	private int needScrollHack = -1;
	private Pattern highlightedText;

	// public

	@SuppressWarnings("unchecked")
	public MTable() {
		this((M)new DefaultTableModel());
	}
	
	/**
	 * Constructs a table.
	 *
	 * @param model the table model
	 *
	 * Defaults:
	 * <ul>
	 * <li>cursor: HAND_CURSOR</li>
	 * <li>fillsViewportHeight: true</li>
	 * <li>rowHeight: font size + 12</li>
	 * </ul>
	 */
	public MTable(final M model) {
		super(model);
		setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		setFillsViewportHeight(true);
		setRowHeight(UI.getFont(this));

		addAncestorListener(fixScrollRectToVisible);
		addMouseWheelListener(this);

		MCellTip.getInstance().install(this);
	}

	/**
	 * @since 4.12
	 */
	public static boolean adjustSelection(final MouseEvent e) {
		if (!(e.getComponent() instanceof JTable))
			return false;
		
		if (!MMouseAdapter.isRight(e))
			return false;
		
		JTable table = (JTable)e.getComponent();
		
		if (!table.isEnabled())
			return false;
		
		int[] selection = table.getSelectedRows();
		
		if (selection.length > 1)
			return false;
		
		int row = table.rowAtPoint(e.getPoint());
		
		if (row == -1)
			return false;
		
		table.clearSelection();
		table.addRowSelectionInterval(row, row);
		
		return true;
	}

	/**
	 * @since 3.4
	 */
	public boolean canCancelEdit(final Window owner, final String actionName) {
		if (!isEditing())
			return true;

		int ec = getEditingColumn();
		int er = getEditingRow();

		if ((ec == -1) || (er == -1))
			return true;

		return new MMessage.Builder()
			.icon("ui/warning")
			.ok(i18n("Stop Editing"), "ui/stop")
			.cancel(i18n("Continue Editing"), "ui/next")
			.html(i18n("In order to perform this action<br>you must <b>stop cell editing</b>."))
			.list(
				new HTMLBuilder.TableColumn(), new HTMLBuilder.TableColumn(),
				i18n("Action:"), actionName,
				i18n("Column:"), getColumnName(ec),
				i18n("Row:"), (er + 1)
			)
		.exec(owner);
	}

	/**
	 * (MODEL)
	 *
	 * @since 2.0
	 */
	public static boolean canStartEdit(final EventObject e, final boolean singleClickEdit) {
		if (e instanceof InputEvent) {
			InputEvent ie = (InputEvent)e;
			
			if (ie.isAltDown() || ie.isControlDown() || ie.isShiftDown())
				return false;
		}

		if (e instanceof KeyEvent) {
			KeyEvent ke = (KeyEvent)e;

			switch (ke.getKeyCode()) {
				case VK_DELETE:
				case VK_ESCAPE:
				case VK_F1:
				case VK_F3:
				case VK_F4:
				case VK_F5:
				case VK_F6:
				case VK_F7:
				case VK_F8:
				case VK_F9:
				case VK_F10:
				case VK_F11:
				case VK_F12:
				case VK_INSERT:
				
				case VK_CAPS_LOCK:
				case VK_NUM_LOCK:
				case VK_SCROLL_LOCK:
				
				// HACK: Xfce only?
				case VK_CONTEXT_MENU:
				case VK_WINDOWS:
					return false;
				default: // VK_F2, etc.
					return true;
			}
		}
		
		if (!singleClickEdit && (e instanceof MouseEvent))
			return MMouseAdapter.isDoubleClick((MouseEvent)e);

		return true;
	}

	/**
	 * (MODEL) Deletes all items.
	 *
	 * @throws UnsupportedOperationException If table does not support this operation
	 */
	public void deleteAll() {
		doneEdit();
		removeAllRows();
	}

	/**
	 * (VIEW) Deletes all the selected items.
	 *
	 * @throws UnsupportedOperationException If table does not support this operation
	 * 
	 * @see #removeRow(int)
	 */
	public void deleteSelected() {
		doneEdit();
		TableModel m = getModel();
		// quickly remove all
		if ((m instanceof AbstractListTableModel<?>) && (getSelectedRowCount() == m.getRowCount())) {
			AbstractListTableModel.class.cast(m).clear();
			//clearSelection(); // fire selection event
		}
		// remove selected
		else {
			int selectedRow = getSelectedRow();
			try {
				for (int row = m.getRowCount() - 1; row >= 0; --row) {
					if (isRowSelected(convertRowIndexToView(row)))
						removeRow(row);
				}
			}
			catch (ArrayIndexOutOfBoundsException exception) {
				MLogger.exception(exception);
			}
			selectRow(selectedRow);
		}
	}

	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	public boolean deleteSelected(final Window parent, final String text, final int listColumn) {
		return deleteSelected(parent, text, null, listColumn);
	}

	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	public boolean deleteSelected(final Window parent, final String text, final Object[] list) {
		return deleteSelected(parent, text, list, -1);
	}

	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	public boolean deleteSelected(final Window parent, final String text, Object[] list, final int listColumn) {
		if ((list == null) && (listColumn != -1)) {
			int[] selectedIndex = getSelectedRows();
			list = new Object[selectedIndex.length];
			for (int i = 0; i < selectedIndex.length; i++) {
				int modelIndex = convertRowIndexToModel(selectedIndex[i]);
				list[i] = getModel().getValueAt(modelIndex, listColumn);
			}
		}

		if (!canCancelEdit(parent, i18n("Delete Selected")))
			return false;

		if (new MMessage.Builder()
			.icon("ui/delete")
			.ok(i18n("Delete Selected"), "ui/delete")
			.text((text == null) ? MMessage.getSimpleConfirmMessage() : text)
			.list(list)
			.exec(parent)
		) {
			deleteSelected();
			
			return true;
		}
		
		return false;
	}

	/**
	 * (MODEL) Stops (or cancels if stop failed) the current cell edition.
	 */
	public void doneEdit() {
		if (!isEditing())
			return;

		CellEditor ce = getCellEditor();
		if ((ce != null) && !ce.stopCellEditing())
			ce.cancelCellEditing();
	}
	
	@Override
	public boolean editCellAt(final int row, final int column, final EventObject e) {
		if (!canStartEdit(e, true))
			return false;
			
		return super.editCellAt(row, column, e);
	}
	
	/**
	 * Returns a column manager for this model.
	 * 
	 * @since 2.4
	 */
	public ColumnManager<M> getColumnManager() { return columnManager; }

	/**
	 * @since 5.0
	 */
	public Pattern getHighlightedText() { return highlightedText; }

	/**
	 * @since 5.0
	 */
	public void setHighlightedText(final Pattern value) { highlightedText = value; }

	/**
	 * @since 5.0
	 */
	public void setHighlightedText(final String regex) {
		if (TK.isEmpty(regex))
			setHighlightedText((Pattern)null);
		else
			setHighlightedText(Pattern.compile(Pattern.quote(regex), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE));
	}

	/**
	 * @since 2.0
	 */
	@Override
	@SuppressWarnings("unchecked")
	public M getModel() {
		return (M)super.getModel();
	}
	
	@Override
	public void setModel(final TableModel model) {
		super.setModel(model);
		columnManager = new ColumnManager<>(this);
	}

	/**
	 * Returns a textual information based on the current row selection.
	 * 
	 * @see #getSelectedRowCount()
	 * @see #getSelectionText(int)
	 * 
	 * @since 3.0
	 */
	public String getSelectionText() {
		int count = getSelectedRowCount();

		if (count == getModel().getRowCount())
			return getSelectionText(SELECTION_TEXT_ALL) + " (" + count + ")";

		return getSelectionText(count);
	}

	/**
	 * Returns a textual information based on @p selectionCount.
	 * 
	 * @see #getSelectionText()
	 * 
	 * @since 3.0
	 */
	public static String getSelectionText(final int selectionCount) {
		switch (selectionCount) {
			case 0:
				return i18n("No selection");
			case 1:
				return i18n("One selected item");
			default:
				if (selectionCount < 0)
					return i18n("No selection");
				
				if (selectionCount == SELECTION_TEXT_ALL)
					return i18n("Selected items: {0}", i18n("All"));

				return i18n("Selected items: {0}", selectionCount);
		}
	}

	/**
	 * (VIEW)
	 *
	 * @since 2.0
	 */
	public SortOrder getSortOrder() {
		RowSorter<? extends TableModel> sorter = getRowSorter();
		
		if (sorter == null)
			return SortOrder.UNSORTED;
		
		List<? extends RowSorter.SortKey> sortKeys = sorter.getSortKeys();
		RowSorter.SortKey sortKey = sortKeys.isEmpty() ? null : sortKeys.get(0);
		
		return (sortKey == null) ? SortOrder.UNSORTED : sortKey.getSortOrder();
	}

	/**
	 * (VIEW) Returns @c true if cell tip is enabled for @p row and @p column.
	 * The default implementation returns @c true.
	 *
	 * @see MCellTip
	 *
	 * @since 3.4
	 */
	public boolean isCellTipEnabled(final int row, final int column) { return true; }

	/**
	 * (MODEL/VIEW) Returns @c true if table has no rows.
	 */
	public boolean isEmpty(final MV mv) {
		switch (mv) {
			case MODEL:
				return getModel().getRowCount() == 0;
			case VIEW:
				return getRowCount() == 0;
			default:
				throw new WTFError(mv);
		}
	}

	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	public boolean isGridVisible() {
		return getShowHorizontalLines() || getShowVerticalLines();
	}

	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	public void setGridVisible(final boolean value) {
		setIntercellSpacing(value ? new Dimension(1, 1) : new Dimension());
		setShowGrid(value);
	}

	/**
	 * (VIEW) Returns @c true if is selection.
	 */
	public boolean isSelection() {
		return getSelectedRow() != -1;
	}

	/**
	 * (MODEL)
	 *
	 * @since 1.2
	 */
	public boolean isSortByColumn(final int column) {
		return isSortByColumn(this, column);
	}

	/**
	 * (MODEL)
	 *
	 * @since 1.2
	 */
	public static boolean isSortByColumn(final JTable table, final int column) {
		RowSorter<? extends TableModel> sorter = table.getRowSorter();
		
		if (sorter == null)
			return false;
			
		List<? extends RowSorter.SortKey> sortKeys = sorter.getSortKeys();
		
		return
			!sortKeys.isEmpty() &&
			(sortKeys.get(0).getColumn() == table.convertColumnIndexToModel(column));
	}

	/**
	 * (MODEL) Returns the default iterator.
	 */
	@Override
	public Iterator<Integer> iterator() {
		return rowIterator(MV.MODEL);
	}

	/**
	 * (VIEW) Mouse wheel event handler.
	 * Scrolls table vertically or horizontally.
	 * @param e A mouse wheel event
	 * @see MScrollPane#mouseWheelScroll(JComponent, MouseWheelEvent)
	 */
	@Override
	public void mouseWheelMoved(final MouseWheelEvent e) {
		if (!e.isControlDown()) {
			MScrollPane.mouseWheelScroll(this, e);
			e.consume();
		}
	}

	/**
	 * (MODEL) Removes all rows.
	 *
	 * @throws UnsupportedOperationException If table does not support this operation
	 *
	 * @since 2.0
	 */
	public void removeAllRows() {
		if (!(getModel() instanceof AbstractListTableModel<?>))
			throw new UnsupportedOperationException("Table does not support this operation (hint: override \"removeAllRows\" method)");
			
		AbstractListTableModel.class.cast(getModel()).clear();
	}

	/**
	 * (MODEL) Removes row at @p modelRow index.
	 *
	 * @throws UnsupportedOperationException If table does not support this operation
	 *
	 * @since 2.0
	 */
	public void removeRow(final int modelRow) {
		if (!(getModel() instanceof AbstractListTableModel<?>))
			throw new UnsupportedOperationException("Table does not support this operation (hint: override \"removeRow\" method)");
		
		AbstractListTableModel.class.cast(getModel()).removeRow(modelRow);
	}

	/**
	 * (MODEL/VIEW) Returns the row iterator.
	 */
	public RowIterator rowIterator(final MV mv) {
		return new RowIterator(mv);
	}
	
	/**
	 * (VIEW)
	 *
	 * @since 1.2
	 */
	public void scrollToRow(final int row) {
		scrollToRow(row, false);
	}

	/**
	 * (VIEW)
	 *
	 * @since 5.0
	 */
	public void scrollToRow(final int row, final boolean animation) {
		Rectangle r = getCellRect(row, 0, true);
		if (r != null) {
			if (animation)
				MScrollPane.scrollToVisible(this, r);
			else
				scrollRectToVisible(r);
		}
	}

	/**
	 * (VIEW) Selects a single row at {@code index}.
	 */
	public void selectRow(final int index) {
		selectRow(index, false);
	}

	/**
	 * (VIEW) Selects a single row at {@code index}.
	 *
	 * @since 5.0
	 */
	public void selectRow(final int index, final boolean animation) {
		if (isEmpty(MV.VIEW))
			return;

		try {
			setRowSelectionInterval(index, index);
			if (animation) {
				scrollToRow(index, true);
			}
			else {
				scrollToRow(index);
				needScrollHack = index;
			}
		}
		catch (IllegalArgumentException exception) { } // quiet
	}

	/**
	 * (VIEW)
	 *
	 * @since 2.0
	 */
	public void setDefaultSortOrder() {
		sortBy(-1, false); // unsorted
	}
	
	/**
	 * @since 4.4
	 */
	public void setRowHeight(final Font font) {
		setRowHeight(font.getSize() + 12);
	}

	/**
	 * @since 3.8.11
	 */
	public static JPopupMenu showPopupMenu(final JTable table, final int viewRow, final int viewColumn, final MMenu menu) {
		Rectangle r = table.getCellRect(viewRow, viewColumn, true);

		return menu.showPopup(table, r.x, r.y + r.height);
	}

	/**
	 * (VIEW)
	 *
	 * @since 2.0
	 */
	public void sortBy(final int column, final boolean toggleSortOrder) {
		RowSorter<? extends TableModel> sorter = getRowSorter();
		
		if (sorter == null)
			return;
		
		if (column == -1) {
			sorter.setSortKeys(null); // unsorted
		}
		else {
			SortOrder sortOrder = getSortOrder();
			boolean ascending = (sortOrder == SortOrder.ASCENDING) || (sortOrder == SortOrder.UNSORTED);
			List<RowSorter.SortKey> sortKeys = new MArrayList<>();
			sortKeys.add(new RowSorter.SortKey(column, ascending ? SortOrder.ASCENDING : SortOrder.DESCENDING));
			sorter.setSortKeys(sortKeys);
			if (toggleSortOrder)
				sorter.toggleSortOrder(column);
		}
		doneEdit();
	}
	
	@Override
	public void tableChanged(final TableModelEvent e) {
		super.tableChanged(e);
		onChange(e);
	}

	// MDisposable

	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		removeMouseWheelListener(this);

		MCellTip.getInstance().uninstall(this);

		JScrollPane scrollPane = MScrollPane.getScrollPane(this);
		if (scrollPane != null)
			scrollPane.setCorner(JScrollPane.UPPER_TRAILING_CORNER, null);
	}

	// StyleSupport
	
	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	@Override
	protected void configureEnclosingScrollPane() {
		JScrollPane scrollPane = MScrollPane.getScrollPane(this);

		if ((columnManager != null) && (scrollPane != null)) {
			scrollPane.setCorner(MScrollPane.UPPER_TRAILING_CORNER, columnManager.createCornerComponent());
			scrollPane.setVerticalScrollBarPolicy(MScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		}

		super.configureEnclosingScrollPane();

		// no scroll pane border
		if (UI.isMetal() && (scrollPane != null))
			scrollPane.setBorder(null);
	}

	@Override
	protected JTableHeader createDefaultTableHeader() {
		return new MTableHeader(getColumnModel());
	}

	protected void onChange(final TableModelEvent e) { }

	/**
	 * @since 4.4
	 */
	protected boolean onEnterPress(final KeyEvent e) { return false; }
	
	@Override
	protected boolean processKeyBinding(final KeyStroke ks, final KeyEvent e, final int condition, final boolean pressed) {
		if (pressed &&/* (condition == WHEN_FOCUSED) &&*/ TK.isKeyStroke(e, VK_ENTER)) {
			if (onEnterPress(e))
				return true;
		}

		return super.processKeyBinding(ks, e, condition, pressed);
	}

	// public classes

	public final class RowIterator extends AbstractIterator<Integer> {
		
		// private
		
		private final MV mv;

		// public
		
		public RowIterator(final MV mv) {
			this.mv = mv;
		}

		/**
		 * (MODEL/VIEW) Returns a row index.
		 */
		@Override
		public Integer getObjectAt(final int index) { return index; }

		/**
		 * (MODEL/VIEW)
		 */
		@Override
		public int getObjectCount() {
			// model
			if (mv == MV.MODEL)
				return MTable.this.getModel().getRowCount();
			
			// view
			return MTable.this.getRowCount();
		}

	}

	// private classes

	/**
	 * CREDITS: http://forums.sun.com/thread.jspa?threadID=530578
	 */
	private static final class FixScrollRectToVisible implements AncestorListener {

		// public

		@Override
		public void ancestorAdded(final AncestorEvent e) {
			// HACK: ensure the selected row is visible after component add/show
			MTable<?> t = (MTable<?>)e.getComponent();
			
			if (t.needScrollHack == -1)
				return;
			
			int[] selection = t.getSelectedRows();
			if ((selection.length == 1) && (selection[0] == t.needScrollHack)) {
				t.scrollToRow(selection[0]);
				t.firstScrollHack = false;
				t.needScrollHack = -1;
			}
		}

		@Override
		public void ancestorRemoved(final AncestorEvent e) {
			// other tab selected, etc.
			MTable<?> t = (MTable<?>)e.getComponent();
			if (!t.firstScrollHack) // do not change user scroll...
				t.needScrollHack = -1;
		}

		@Override
		public void ancestorMoved(final AncestorEvent e) { }

		// private

		private FixScrollRectToVisible() { }

	}

}
