// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Collections;
import java.util.Iterator;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.plaf.basic.BasicMenuBarUI;

import org.makagiga.commons.AbstractIterator;
import org.makagiga.commons.UI;
import org.makagiga.commons.mods.Mods;

/**
 * A menu bar.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MMenuBar extends JMenuBar implements Iterable<JMenu> {

	// public

	/**
	 * Invoked from the {@link #add(JMenu)} method; after menu add.
	 *
	 * <ul>
	 * <li>Arg 0: {@code javax.swing.JMenu} - the menu</li>
	 * </ul>
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.6
	 */
	public static final String MOD_ADD_MENU = "add_JMenu@org.makagiga.commons.swing.MMenuBar";

	// private

	private boolean minimized;

	// public
	
	/**
	 * Constructs a menu bar.
	 */
	public MMenuBar() { }

	@Override
	public JMenu add(final JMenu c) {
		JMenu result = super.add(c);
		if (result != null)
			Mods.exec(this, MOD_ADD_MENU, result);

		return result;
	}
	
	/**
	 * @since 3.8.8
	 */
	public JComponent addGap() {
		return (JComponent)add(UI.createGap(5, 0));
	}

	@Override
	public Dimension getPreferredSize() {
		if (minimized)
			return new Dimension();

		Dimension d = super.getPreferredSize();
		
		return new Dimension(d.width, Math.max(d.height, 24));
	}

	/**
	 * @since 3.8.3
	 */
	public boolean isMinimized() { return minimized; }

	/**
	 * @since 3.8.3
	 */
	public void setMinimized(final boolean value) {
		if (value != minimized) {
			minimized = value;
			updateUI();
			revalidate();
		}
	}

	/**
	 * @since 1.2
	 */
	@Override
	public Iterator<JMenu> iterator() {
		int count = getMenuCount();
	
		if (count == 0)
			return Collections.emptyIterator();

		return new AbstractIterator<>(count, this::getMenu);
	}

	@Override
	public void paint(final Graphics g) {
		if (!minimized)
			super.paint(g);
	}

	@Override
	public void updateUI() {
		if (minimized)
			setUI(new MinimizedUI());
		else
			super.updateUI();

		if (UI.isMetal() || UI.isNimbus()) {
			setBorder(null);
			setBorderPainted(false);
		}
	}

	// private classes

	private static final class MinimizedUI extends BasicMenuBarUI {

		// public

		@Override
		public Dimension getMaximumSize(final JComponent c) {
			return new Dimension();
		}

		@Override
		public Dimension getPreferredSize(final JComponent c) {
			int of = 0;
			int the_doomed = 0;
			
			return new Dimension(of, the_doomed);
		}

		@Override
		public void paint(final Graphics g, final JComponent c) { }

		@Override
		public void update(final Graphics g, final JComponent c) { }

	}

}
