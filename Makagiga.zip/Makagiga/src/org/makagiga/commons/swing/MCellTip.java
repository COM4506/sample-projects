// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.lang.ref.WeakReference;
import javax.swing.CellRendererPane;
import javax.swing.JComponent;
import javax.swing.JLayer;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.UI;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.commons.swing.layer.ListActionsLayerUI;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public final class MCellTip {
	
	// private
	
	private boolean visible;
	private static MCellTip _instance;
	private PopupContent _content;
	private static final String MOUSE_LISTENER = "org.makagiga.commons.swing.MCellTip.mouseListener";
	
	// public
	
	public synchronized static MCellTip getInstance() {
		if (_instance == null)
			_instance = new MCellTip();
		
		return _instance;
	}

	public void install(final JComponent component) {
		if (
			!(component instanceof JList<?>) &&
			!(component instanceof JTable) &&
			!(component instanceof JTree)
		)
			throw new IllegalArgumentException("Component of \"" + component.getClass().getName() + "\" type is not supported");
		
		//MLogger.debug("cell", "Install: %s", component.getClass().getName());

		StaticHandler handler = new StaticHandler();
		component.addMouseListener(handler);
		component.addMouseMotionListener(handler);
		component.putClientProperty(MOUSE_LISTENER, handler);
	}
	
	/**
	 * @since 2.4
	 */
	public void uninstall(final JComponent component) {
		//MLogger.debug("cell", "Uninstall: %s", component.getClass().getName());
		
		MMouseAdapter mouseAdapter = UI.getClientProperty(component, MOUSE_LISTENER, null);
		if (mouseAdapter != null) {
			component.removeMouseListener(mouseAdapter);
			component.removeMouseMotionListener(mouseAdapter);
			component.putClientProperty(MOUSE_LISTENER, null);
		}
	}
	
	public boolean isVisible() { return visible; }
	
	public void setVisible(final boolean value) {
		if (value == visible)
			return;
		
		visible = value;
		//MLogger.debug("cell", "Visible: %s", visible);
		
		// show
		if (value) {
			getContent().setVisible(true);
		}
		// hide
		else {
			if (_content != null) {
				getContent().setup(null, null);
				getContent().setVisible(false);
			}
		}
	}
	
	// private
	
	private MCellTip() {
		Toolkit.getDefaultToolkit().addAWTEventListener(e -> {
			if (e.getID() == MouseWheelEvent.MOUSE_WHEEL)
				setVisible(false);
		}, AWTEvent.MOUSE_WHEEL_EVENT_MASK);
	}
	
	private PopupContent getContent() {
		if (_content == null)
			_content = new PopupContent();
		
		return _content;
	}
	
	private static boolean isAllVisible(final JComponent c, final Rectangle cell) {
// TODO: detect scrolling (JViewport.addChangeListener?)
		JViewport v = MScrollPane.getViewport(c);
		Rectangle bounds;
		if (v == null) {
			bounds = c.getBounds();
		}
		else {
			bounds = v.getBounds();
			Point offset = v.getViewPosition();
			bounds.translate(offset.x, offset.y);
		}

		// HACK: ignore margin/border/insets/whatever (?)
		int offset = UI.isNimbus() ? 3 : 1;
		Rectangle r = new Rectangle(cell);
		if (c instanceof JTable) {
			JTable table = (JTable)c;
			JTableHeader header = table.getTableHeader();
			r.translate(offset, (header == null) ? offset : (header.getHeight() + offset));
		}
		else {
			r.translate(offset, offset);
		}

		return bounds.contains(r);
	}
	
	private void processList(final JList<?> list, final MouseEvent e) {
		Point p = e.getPoint();
		int index = list.locationToIndex(p);
		
		if (index == -1) {
			setVisible(false);
			
			return;
		}
		
		Rectangle r = list.getCellBounds(index, index);
		if ((r == null) || !r.contains(p)) {
			setVisible(false);
			
			return;
		}

		if (isAllVisible(list, r)) {
			setVisible(false);
			
			return;
		}
		
		Object value = list.getModel().getElementAt(index);
		if ((_content == null) || (value == null) || !value.equals(getContent().currentValue)) {
			PopupContent pc = getContent();
			pc.currentRow = index;
			pc.currentValue = value;
			pc.setup(list, r);
			setVisible(true);
		}
	}
	
	private void processMouseMove(final MouseEvent e) {
		if (!UI.getLookAndFeelType().isCellTipSupported())
			return;

		if (MMenu.getCurrentPopup() != null) {
			setVisible(false);
			
			return;
		}
		
		JComponent c = (JComponent)e.getSource();
		
		if ((c != null) && (c.getParent() instanceof JLayer<?>)) {
			JLayer<?> l = JLayer.class.cast(c.getParent());
			if (l.getUI() instanceof ListActionsLayerUI) { // clash
				setVisible(false);
		
				return;
			}
		}
		
		if (c instanceof JList<?>)
			processList((JList<?>)c, e);
		else if (c instanceof JTable)
			processTable((JTable)c, e);
		else if (c instanceof JTree)
			processTree((JTree)c, e);
	}

	private void processTable(final JTable table, final MouseEvent e) {
		Point p = e.getPoint();
		int column = table.columnAtPoint(p);
		int row = table.rowAtPoint(p);
		
		if ((column == -1) || (row == -1)) {
			setVisible(false);
			
			return;
		}

		int editingColumn = table.getEditingColumn();
		int editingRow = table.getEditingRow();
		if ((editingColumn == column) && (editingRow == row)) {
			setVisible(false);
			
			return;
		}

		int modelColumn = table.convertColumnIndexToModel(column);
		int modelRow = table.convertRowIndexToModel(row);
		
		if ((_content == null) || (modelColumn != getContent().currentColumn) || (modelRow != getContent().currentRow)) {
			Rectangle r = table.getCellRect(row, column, true);
			PopupContent pc = getContent();
			pc.currentColumn = modelColumn;
			pc.currentRow = modelRow;
			pc.setup(table, r);
			setVisible(true);
		}
	}
	
	private void processTree(final JTree tree, final MouseEvent e) {
		if (tree.isEditing()) {
			setVisible(false);
			
			return;
		}

		TreePath path = tree.getPathForLocation(e.getX(), e.getY());
		
		if (path == null) {
			setVisible(false);
			
			return;
		}

		Rectangle r = tree.getPathBounds(path);
		if (r == null) {
			setVisible(false);
			
			return;
		}

		if (isAllVisible(tree, r)) {
			setVisible(false);
			
			return;
		}
		
		if ((_content == null) || !path.equals(getContent().currentTreePath)) {
			PopupContent pc = getContent();
			pc.currentRow = tree.getRowForPath(path);
			pc.currentTreePath = path;
			pc.setup(tree, r);
			setVisible(true);
		}
	}

	// private classes
	
	private static final class PopupContent extends MComponent {

		// private

		private int currentColumn = -1;
		private int currentRow = -1;
		private Object currentValue;
		private Rectangle cellBounds = new Rectangle();
		private TreePath currentTreePath;
		private final WeakReference<CellRendererPane> cellPaneRef;
		private WeakReference<JComponent> componentRef;
		private transient WeakReference<Window> oldParentWindowRef;

		// protected
	
		@Override
		protected void paintComponent(final Graphics graphics) {
			if (!UI.getLookAndFeelType().isCellTipSupported())
				return;

			JComponent component = componentRef.get();

			if (component == null)
				return;

			Graphics2D g = (Graphics2D)graphics;
			RenderingHints savedHints = new RenderingHints(null);
			UI.setTextAntialiasing(g, savedHints);

			Component rendererComponent = null;
			if (component instanceof JList<?>) {
				@SuppressWarnings("unchecked")
				JList<Object> list = (JList<Object>)component;
				boolean selected = list.isSelectedIndex(currentRow);
				rendererComponent = list.getCellRenderer().getListCellRendererComponent(
					list,
					currentValue,
					currentRow,
					selected,
					false
				);
				rendererComponent.setSize(rendererComponent.getPreferredSize());
				paint(g, rendererComponent, true, null);
			}
			else if (component instanceof JTable) {
				JTable table = (JTable)component;
				int viewColumn = table.convertColumnIndexToView(currentColumn);

				int viewRow;
				try {
					viewRow = table.convertRowIndexToView(currentRow);
				}
				catch (IndexOutOfBoundsException exception) {
					MLogger.exception(exception);

					return;
				}

				// -1 if table row was filtered
				if (viewRow == -1)
					return;

				boolean selected = table.isCellSelected(viewRow, viewColumn);
				TableCellRenderer tableCellRenderer = table.getCellRenderer(viewRow, viewColumn);
				rendererComponent = tableCellRenderer.getTableCellRendererComponent(
					table,
					table.getModel().getValueAt(currentRow, currentColumn),
					selected,
					false,
					viewRow,
					viewColumn
				);
				
				// reset previous values
				rendererComponent.setMinimumSize(null);
				rendererComponent.setPreferredSize(null);
				rendererComponent.setSize(1, 1);

				rendererComponent.validate();
				Rectangle cellRect = table.getCellRect(viewRow, viewColumn, true);

				boolean allVisible = MCellTip.isAllVisible(table, cellRect);

				if (
					allVisible &&
					(table instanceof MTable<?>) &&
					!MTable.class.cast(table).isCellTipEnabled(viewRow, viewColumn)
				)
					return;

				cellBounds.width = Math.max(cellRect.width, rendererComponent.getPreferredSize().width);
				cellBounds.height = cellRect.height;
				Dimension cellSize = cellBounds.getSize(); // 1.
				if (rendererComponent instanceof JComponent) { // 2.
					Border b = JComponent.class.cast(rendererComponent).getBorder();
					if (b != null) {
						Insets i = b.getBorderInsets(rendererComponent);
						if (i != null)
							cellBounds.width += (i.left + i.right);
					}
				}

				if (table.getShowHorizontalLines()) {
					cellBounds.height--;
				}

				if (table.getShowVerticalLines()) {
					cellBounds.width--;

					// HACK: too many stupid hacks
					if (!UI.isNimbus() && !table.getShowHorizontalLines()) {
						cellBounds.height--;
						cellBounds.width--;
					}
				}

				if (
					(cellSize.width == cellRect.width) &&
					(cellSize.height == cellRect.height) &&
					allVisible
				)
					return;

				Dimension d = cellBounds.getSize();
				rendererComponent.setMinimumSize(d);
				rendererComponent.setPreferredSize(d);
				paint(g, rendererComponent, false, tableCellRenderer);
			}
			else if (component instanceof JTree) {
				JTree tree = (JTree)component;
				boolean selected = tree.isRowSelected(currentRow);
				TreeNode node = (TreeNode)currentTreePath.getLastPathComponent();
				rendererComponent = tree.getCellRenderer().getTreeCellRendererComponent(
					tree,
					node,
					selected,
					tree.isExpanded(currentTreePath),
					node.isLeaf(),
					currentRow,
					false
				);
				paint(g, rendererComponent, true, null);
			}

			g.addRenderingHints(savedHints);
		}
		
		// private
		
		private PopupContent() {
			super(new BorderLayout());
			//MLogger.debug("cell", "Creating popup content...");
			setOpaque(false);
			
			CellRendererPane cellPane = new CellRendererPane();
			cellPaneRef = new WeakReference<>(cellPane);
			add(cellPane, BorderLayout.CENTER);
		}

		private void paint(final Graphics g, final Component rendererComponent, final boolean validate, final Object renderer) {
			JComponent component = componentRef.get();

			if (component == null)
				return;

			// background
			Color bg = UI.getBackground(component);
			g.setColor(bg);
			g.fillRect(cellBounds.x + 1, cellBounds.y + 1, cellBounds.width - 2, cellBounds.height - 2);

			// cell
			CellRendererPane crp = cellPaneRef.get();

			if (crp == null)
				return;

			MRenderer<?> makagigaRenderer =
				(renderer instanceof MRenderer<?>)
				? (MRenderer<?>)renderer
				: null;
			if (makagigaRenderer != null)
				makagigaRenderer.setCellTip(true);
			try {
				crp.paintComponent(
					g, rendererComponent, null,
					cellBounds.x, cellBounds.y,
					cellBounds.width, cellBounds.height,
					validate
				);
			}
			finally {
				if (makagigaRenderer != null)
					makagigaRenderer.setCellTip(false);
			}
		}
		
		private void setup(final JComponent component, final Rectangle r) {
			componentRef = new WeakReference<>(component);
			if (component == null) {
				currentColumn = -1;
				currentRow = -1;
				currentTreePath = null;
				currentValue = null;
			}
			else {
				setCursor(component.getCursor());
				setupGlassPane();
				
				Point p = r.getLocation();
				SwingUtilities.convertPointToScreen(p, component);
				SwingUtilities.convertPointFromScreen(p, this);
				
				cellBounds.setLocation(Math.max(p.x, 0), p.y);
				cellBounds.setSize(r.width, r.height);
				
				setBackground(component.getBackground());
				setForeground(component.getForeground());

// TODO: optimize repaint; enable support in GTK+
				repaint(); // required
			}
		}
		
		private void setupGlassPane() {
			JComponent component = componentRef.get();

			if (component == null)
				return;

			Window newWindow = UI.windowFor(component);
			
			// clear previous glass pane
			if (oldParentWindowRef != null) {
				Window oldWindow = oldParentWindowRef.get();
				if ((oldWindow != null) && (oldWindow != newWindow)) {
					MFrame.clearGlassPane((RootPaneContainer)oldWindow);
					oldParentWindowRef.clear();
					oldParentWindowRef = null;
				}
			}
			
			// setup glass pane
			if (newWindow instanceof RootPaneContainer) {
				oldParentWindowRef = new WeakReference<>(newWindow);
				
				RootPaneContainer rpc = (RootPaneContainer)newWindow;
				if ((rpc.getGlassPane() != this) && !rpc.getGlassPane().isVisible()) {
					//MLogger.debug("cell", "Set glass pane");
					rpc.setGlassPane(this);
				}
			}
		}
		
	}

	private static final class StaticHandler extends MMouseAdapter {

		// public

		@Override
		public void mouseDragged(final MouseEvent e) {
			if (MCellTip._instance != null)
				MCellTip._instance.setVisible(false);
		}

		@Override
		public void mouseExited(final MouseEvent e) {
			if (MCellTip._instance != null)
				MCellTip._instance.setVisible(false);
		}

		@Override
		public void mouseMoved(final MouseEvent e) {
			if (MCellTip._instance != null)
				MCellTip._instance.processMouseMove(e);
		}

		@Override
		public void mousePressed(final MouseEvent e) {
			if (MCellTip._instance != null)
				MCellTip._instance.setVisible(false);
		}

	}

}
