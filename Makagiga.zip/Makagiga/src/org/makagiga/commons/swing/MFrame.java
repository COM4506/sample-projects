// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.EventListener;
import java.util.EventObject;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JRootPane;
import javax.swing.RootPaneContainer;
import javax.swing.event.EventListenerList;

import org.makagiga.commons.Config;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.TK;
import org.makagiga.commons.OS;
import org.makagiga.commons.UI;

/**
 * A frame.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MFrame extends JFrame implements MBorderLayout {

	// private

	private boolean oldAlwaysOnTop;
	private boolean fullScreen;
	private EventListenerList ell;
	private static final int MIN_WIDTH = 320;
	private static final int MIN_HEIGHT = 200;
	private MouseGestures mouseGestures;
	private Rectangle oldFrameBounds;

	// public

	/**
	 * Constructs a frame.
	 */
	public MFrame() {
		this(null);
	}

	/**
	 * Constructs a frame.
	 * @param title A frame title
	 */
	public MFrame(final String title) {
		super(title);
		if (UI.isSeaGlass()) {
			getRootPane().setWindowDecorationStyle(JRootPane.NONE);
			setUndecorated(false);
		}
	}

	/**
	 * @since 3.0
	 */
	public void addFullScreenListener(final FullScreenListener l) {
		if (l != null) {
			if (ell == null)
				ell = new EventListenerList();
			ell.add(FullScreenListener.class, l);
		}
	}

	/**
	 * @since 3.0
	 */
	public FullScreenListener[] getFullScreenListeners() {
		return
			(ell == null)
			? new FullScreenListener[0]
			: ell.getListeners(FullScreenListener.class);
	}

	/**
	 * @since 3.0
	 */
	public void removeFullScreenListener(final FullScreenListener l) {
		if (ell != null)
			ell.remove(FullScreenListener.class, l);
	}
	
	/**
	 * Sets an empty and hidden glass pane.
	 *
	 * @since 2.0
	 */
	public static void clearGlassPane(final RootPaneContainer rpc) {
		rpc.getGlassPane().setVisible(false);
		rpc.setGlassPane(new MComponent());
	}
	
	/**
	 * @since 3.8.12
	 */
	public MMenuBar getMMenuBar() {
		return (MMenuBar)getJMenuBar();
	}

	/**
	 * Returns the mouse gestures associated with this frame or @c null.
	 */
	public MouseGestures getMouseGestures() { return mouseGestures; }

	/**
	 * Sets mouse gestures to @p value.
	 */
	public void setMouseGestures(final MouseGestures value) {
		mouseGestures = value;
		mouseGestures.setOwner(this);
	}
	
	public boolean isFullScreen() { return fullScreen; }
	
	public void setFullScreen(final boolean value) {
		if (value == fullScreen)
			return;

		FullScreenEvent e = new FullScreenEvent(this, fullScreen);
		FullScreenListener[] fsl = getFullScreenListeners();
		for (FullScreenListener i : fsl) {
			// listener can veto full screen change
			if (!i.isFullScreenSupported(e)) {
				MStatusBar.warning(i18n("Full screen view is not supported"));

				return;
			}
		}
		
		// save focus
		Component focusOwner = UI.getFocusOwner();
		
		fullScreen = value;
		dispose();
		setResizable(!fullScreen);
		if (!UI.isSeaGlass())
			setUndecorated(fullScreen);
		if (fullScreen) {
			// HACK: JRootPane.NONE
			if (UI.isSeaGlass())
				getRootPane().setWindowDecorationStyle(JRootPane.NONE);
			oldFrameBounds = getBounds(); // save location and size
			oldAlwaysOnTop = isAlwaysOnTop();

			if (OS.isXfce()) {
				// HACK: In Xfce frame may be hovered by the panels.
				Dimension screenSize = UI.getScreenSize();
				Insets i = UI.getScreenInsets();
				screenSize.width -= (i.left + i.right);
				screenSize.height -= (i.top + i.bottom);

				// use workspace size
				setLocation(i.left, i.top);
				setSize(screenSize);
			}
			else {
				// HACK: show on top of task bar/panel
				if (OS.isLinux())
					setAlwaysOnTop(true);

				setLocation(0, 0);
				setSize(UI.WindowSize.SCREEN);
			}
			validate();
		}
		else {
			if (UI.isSeaGlass())
				getRootPane().setWindowDecorationStyle(JRootPane.NONE);
			if (OS.isLinux())
				setAlwaysOnTop(oldAlwaysOnTop);
			if (oldFrameBounds != null) {
				setBounds(oldFrameBounds); // restore location and size
				oldFrameBounds = null;
			}
		}

		for (FullScreenListener i : fsl)
			i.fullScreenChange(e);

		setVisible(true);
		
		// restore focus
		if (
			(focusOwner != null) && focusOwner.isDisplayable()
			&& focusOwner.isFocusable() && focusOwner.isVisible()
		)
			focusOwner.requestFocusInWindow();
		
		repaint();
		toFront();
	}
	
	/**
	 * @since 3.0
	 */
	public void readConfig(final Config config, final String id) {
		Dimension screenSize = UI.getScreenSize();
		String key = (id == null) ? "Window" : (id + ".Window");
		String screenKey = Config.getScreenKey(key, screenSize);
		final int UNDEFINED = Integer.MAX_VALUE;

		Dimension size = config.readDimension(screenKey, UNDEFINED, UNDEFINED);
		if ((size.width == UNDEFINED) || (size.height == UNDEFINED))
			size = UI.WindowSize.LARGE.getDimension();
		int w = Math.max(MIN_WIDTH, size.width);
		int h = Math.max(MIN_HEIGHT, size.height);
		setSize(w, h);
		
		boolean maximized = config.read(screenKey + ".maximized", false);
		if (
			maximized ||
			(OS.isWindows() && (w > screenSize.width)) // HACK: fix window size
		)
			setExtendedState(MAXIMIZED_BOTH);

		if (MApplication.isFirstRun()) {
			setLocationRelativeTo(null);
		}
		else {
			Point p = config.readPoint(screenKey, UNDEFINED, UNDEFINED);
			if ((p.x == UNDEFINED) || (p.y == UNDEFINED)) {
				// screen size changed - show centered
				setLocationRelativeTo(null);
			}
			else {
				// use previous location
				p.x = TK.limit(p.x, 0, Math.max(screenSize.width - size.width, 0));
				p.y = TK.limit(p.y, 0, Math.max(screenSize.height - size.height, 0));
				setLocation(p);
			}
		}
	}

	/**
	 * @since 3.8.3
	 */
	public void setSize(final UI.WindowSize size) {
		setSize(size.getDimension());
	}

	@Override
	public void setTitle(final String value) {
		super.setTitle(fixWindowTitle(value));
	}

	@Override
	public void setVisible(final boolean value) {
		if (value && MApplication.getForceRTL() && !isVisible())
			applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

		super.setVisible(value);
	}

	public void toggleFullScreen() {
		setFullScreen(!fullScreen);
	}
	
	/**
	 * @since 3.0
	 */
	public void writeConfig(final Config config, final String id) {
		String key = (id == null) ? "Window" : (id + ".Window");
		String screenKey = Config.getScreenKey(key);

		config.write(screenKey, getLocation());
		config.write(screenKey, getSize());
		config.write(screenKey + ".maximized", (getExtendedState() & MAXIMIZED_BOTH) != 0);
	}

	// MBorderLayout

	@Override
	public void addCenter(final JComponent component) {
		UI.addCenter(this, component);
	}

	@Override
	public void addEast(final JComponent component) {
		add(component, BorderLayout.LINE_END);
	}

	@Override
	public void addNorth(final JComponent component) {
		add(component, BorderLayout.PAGE_START);
	}

	@Override
	public void addSouth(final JComponent component) {
		add(component, BorderLayout.PAGE_END);
	}

	@Override
	public void addWest(final JComponent component) {
		add(component, BorderLayout.LINE_START);
	}
	
	// package
	
	static String fixWindowTitle(final String title) {
		if (TK.isEmpty(title))
			return title;
		
		return title
			.replace('\n', ' ')
			.replace('\r', ' ');
	}

	// public classes

	/**
	 * @since 3.0
	 */
	public static final class FullScreenEvent extends EventObject {

		// private

		private final boolean fullScreen;

		// public

		public FullScreenEvent(final Object source, final boolean fullScreen) {
			super(source);
			this.fullScreen = fullScreen;
		}

		public boolean isFullScreen() { return fullScreen; }

	}

	/**
	 * @since 3.0
	 */
	@FunctionalInterface
	public static interface FullScreenListener extends EventListener {

		// public

		public default boolean isFullScreenSupported(final FullScreenEvent e) { return true; }

		public void fullScreenChange(final FullScreenEvent e);

	}

}
