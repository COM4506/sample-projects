// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;

import org.makagiga.commons.UI;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 4.10
 */
public class ComponentDragAdapter extends MMouseAdapter {
	
	// private
	
	private boolean moveCursor = true;
	private Point startDrag = new Point();
	
	// public
	
	public ComponentDragAdapter() { }

	public void install(final Component component) {
		component.addMouseListener(this);
		component.addMouseMotionListener(this);
	}

	public void uninstall(final Component component) {
		if (component != null) {
			if (moveCursor)
				setCursor(component, Cursor.DEFAULT_CURSOR);
			component.removeMouseListener(this);
			component.removeMouseMotionListener(this);
		}
	}
	
	public boolean isMoveCursor() { return moveCursor; }
	
	public void setMoveCursor(final boolean value) { moveCursor = value; }

	@Override
	public void mouseDragged(final MouseEvent e) {
		if (e.isConsumed() || !isLeft(e))
			return;
	
		Component root = getRoot(e.getComponent());
		
		Point p = e.getLocationOnScreen();
		p.translate(-startDrag.x, -startDrag.y);
		adjustNewLocation(p);
		root.setLocation(p);
		e.consume();
	}
	
	@Override
	public void mousePressed(final MouseEvent e) {
		super.mousePressed(e);
		
		if (e.isConsumed() || !isLeft(e))
			return;

		Component c = e.getComponent();
		Component root = getRoot(c);
		
		if (moveCursor)
			setCursor(c, Cursor.MOVE_CURSOR);
		startDrag = SwingUtilities.convertPoint(c, e.getPoint(), root);
	}

	@Override
	public void mouseReleased(final MouseEvent e) {
		super.mouseReleased(e);
	
		if (e.isConsumed() || !isLeft(e))
			return;

		if (moveCursor)
			setCursor(e.getComponent(), Cursor.DEFAULT_CURSOR);
		startDrag.setLocation(0, 0);
	}
	
	// protected
	
	protected void adjustNewLocation(final Point p) { }
	
	protected Component getRoot(final Component c) {
		return UI.windowFor(c);
	}
	
	// private
	
	private void setCursor(final Component component, final int cursor) {
		component.setCursor(Cursor.getPredefinedCursor(cursor));
	}

}
