// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.beans.ConstructorProperties;
import java.util.Objects;
import javax.swing.Icon;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;

import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.style.StyleSupport;
import org.makagiga.commons.swing.event.MDocumentAdapter;

/**
 * A text field.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTextField extends JTextField
implements
	MText.TextFieldExtensions,
	StyleSupport
{

	// private

	private transient Font promptTextFontCache;
	private Icon promptIcon;
	private String promptText;
	private UI.ToolTipLocationPolicy toolTipLocationPolicy = UI.ToolTipLocationPolicy.DEFAULT;

	// public

	/**
	 * Constructs a text field.
	 */
	public MTextField() {
		this(null);
	}
	
	/**
	 * @since 3.8.2
	 */
	public MTextField(final int columns) {
		super(columns);
		init();
	}

	/**
	 * Constructs a text field.
	 * @param text A text
	 */
	@ConstructorProperties("text")
	public MTextField(final String text) {
		super(text);
		init();
	}
	
	/**
	 * Overriden to limit component height to its preferred size.
	 */
	@Override
	public Dimension getMaximumSize() {
		return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
	}
	
	/**
	 * @since 3.8.2
	 */
	public String getPromptText() { return promptText; }

	/**
	 * @since 3.8.2
	 */
	public void setPromptText(final String value) {
		if (!Objects.equals(promptText, value)) {
			promptText = value;
			repaint();
		}
		if (getToolTipText() == null)
			setToolTipText(value);
	}

	@Override
	public Point getToolTipLocation(final MouseEvent e) {
		return
			(toolTipLocationPolicy == UI.ToolTipLocationPolicy.DEFAULT)
			? super.getToolTipLocation(e)
			: toolTipLocationPolicy.getLocation(this, e);
	}

	/**
	 * @since 4.4
	 */
	public UI.ToolTipLocationPolicy getToolTipLocationPolicy() { return toolTipLocationPolicy; }
	
	/**
	 * @since 4.4
	 */
	public void setToolTipLocationPolicy(final UI.ToolTipLocationPolicy value) {
		toolTipLocationPolicy = Objects.requireNonNull(value);
	}
	
	@Override
	public void setFont(final Font font) {
		promptTextFontCache = null;
		super.setFont(font);
	}

	@Override
	public void setText(final String value) {
		AutoCompletion autoCompletion = MText.getAutoCompletion(this);
		if (autoCompletion == null)
			super.setText(value);
		else
			autoCompletion.invokeDisabled(() -> super.setText(value));
	}

	// common extensions
	
	@Override
	public void clear() {
		setText(null);
	}

	@Override
	public boolean isEmpty() {
		return MText.isEmpty(this);
	}

	@Override
	public void makeDefault() {
		MText.makeDefault(this);
	}

	// text completion
	
	@Override
	public String getAutoCompletion() {
		return MText.getAutoCompletionID(this);
	}
	
	@Override
	public void saveAutoCompletion() {
		MText.saveAutoCompletion(this);
	}
	
	@Override
	public void setAutoCompletion(final String id) {
		MText.installAutoCompletion(this, id);
	}

	// StyleSupport
	
	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	/**
	 * Invoked when text field is changed.
	 * By default this method does nothing.
	 * @param e A document event
	 */
	@Obsolete
	protected void onChange(final DocumentEvent e) { }

	@Override
	protected void paintComponent(final Graphics g) {
		super.paintComponent(g);

		if (UI.isSeaGlass() && (getClientProperty("JTextField.Search.PlaceholderText") != null))
			return;
			
		if (TK.isEmpty(getPromptText()) || !isEmpty())
			return;

		Color fg = UI.getForeground(this);
		boolean focused = isFocusOwner();
		fg = UI.getBrighter(fg, focused ? 55 : 45, Color.BLACK);
		if (promptIcon != null)
			putClientProperty(ShapeIcon.FOREGROUND_PROPERTY, fg);

		Insets i = getInsets();
		if (i == null)
			i = UI.createInsets(0);

		int h = getHeight() - (i.top + i.bottom);

		g.setColor(fg);
		Font currentFont = UI.getFont(this);
		int style = 0;
		if ((currentFont.getStyle() & Font.BOLD) != 0)
			style |= Font.BOLD;
		if (focused && !UI.isRetro())
			style |= Font.ITALIC;
		if (style == 0)
			style = Font.PLAIN;
		
		if (currentFont.getStyle() != style) {
			if (promptTextFontCache == null)
				promptTextFontCache = UI.deriveFontStyle(currentFont, style);
			g.setFont(promptTextFontCache);
		}
		else {
			g.setFont(currentFont);
		}

		FontMetrics fm = g.getFontMetrics();

		int x = i.left;
		if (!focused && (promptIcon != null)) {
			promptIcon.paintIcon(this, g, x, i.top + (h / 2) - (promptIcon.getIconHeight() / 2));
			x += promptIcon.getIconWidth() + 5;
		}

		int y = i.top + (h / 2) - (fm.getHeight() / 2) + fm.getAscent();

		//RenderingHints savedHints = new RenderingHints(null);
		UI.setTextAntialiasing((Graphics2D)g, null);
/*
		for (RenderingHints.Entry<Object, Object> entry : savedHints.entrySet()) {
			MLogger.debug("core", "Saved AA: %s = %s", entry.getKey(), entry.getValue());
		}
*/
		g.drawString(promptText, x, y);
	}
	
	// private
	
	private void init() {
		MText.commonSetup(this);

		StaticHandler handler = new StaticHandler(this);
		addFocusListener(handler);
		getDocument().addDocumentListener(handler);
	}

	// package
	
	void setPromptIcon(final Icon value) {
		if (value != promptIcon) {
			promptIcon = value;
			repaint();
		}
	}

	// private classes

	private static final class StaticHandler extends MDocumentAdapter<MTextField> implements FocusListener {

		// FocusListener

		@Override
		public void focusGained(final FocusEvent e) {
			MTextField textField = (MTextField)e.getSource();
			if (!TK.isEmpty(textField.getPromptText()))
				textField.repaint();
		}

		@Override
		public void focusLost(final FocusEvent e) {
			MTextField textField = (MTextField)e.getSource();
			if (!TK.isEmpty(textField.getPromptText()))
				textField.repaint();
		}
		
		// protected

		@Override
		protected void onChange(final DocumentEvent e) {
			MTextField textField = getTextComponent();
			if (textField != null)
				textField.onChange(e);
		}

		// private

		private StaticHandler(final MTextField textField) {
			super(textField);
		}

	}

}
