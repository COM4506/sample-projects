// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Window;
import java.lang.ref.WeakReference;
import java.security.SecureRandom;
import javax.swing.event.ChangeListener;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.crypto.CryptoUtils;
import org.makagiga.commons.security.MPermission;
import org.makagiga.commons.validator.TextComponentValidator;
import org.makagiga.commons.validator.ValidatorSupport;

/**
 * @since 2.4, 4.0 (org.makagiga.commons.swing package)
 */
public class MPasswordPanel extends MPanel implements MDisposable {
	
	// public

	public static final int OLD_PASSWORD_FIELD = 1;
	public static final int NEW_PASSWORD_FIELD = 1 << 1;
	public static final int PASSWORD_GENERATOR = 1 << 2;
	public static final int ALLOW_EMPTY_PASSWORD = 1 << 3;
	
	/**
	 * @since 3.4
	 */
	public static final int ENTER_PASSWORD_FIELD = 1 << 4;

	/**
	 * @since 3.8
	 */
	public static final int ENCRYPT_BUTTON = 1 << 5;

	/**
	 * @since 3.4
	 */
	public static final int ENTER_PASSWORD_MODE = ENTER_PASSWORD_FIELD;

	/**
	 * @since 3.4
	 */
	public static final int NEW_PASSWORD_MODE = OLD_PASSWORD_FIELD | NEW_PASSWORD_FIELD | PASSWORD_GENERATOR;

	// private

	private boolean canShowPasswordText = true;
	private char oldEchoChar = MPasswordField.NONE_ECHO_CHAR;
	private final Flags flags;
	private MCheckBox togglePasswordText;
	private final MPasswordField confirmedNewPassword;
	private final MPasswordField newPassword;
	private final MPasswordField oldPassword;
	private PasswordValidator confirmedNewPasswordValidator;
	private PasswordValidator newPasswordValidator;
	
	// public
	
	public MPasswordPanel(final int flags, final String prompt) {
		super(true);
		this.flags = Flags.valueOf(flags);

		oldPassword = new MPasswordField();
		newPassword = new MPasswordField();
		confirmedNewPassword = new MPasswordField();

		MGroupLayout l = getGroupLayout();
		l.setAutoCreateContainerGaps(true);
		l.beginRows();
				
		if (prompt != null) {
			l.addComponent(new MLabel(prompt));
			l.addHorizontalSeparator();
		}
		
		MArrayList<MPasswordField> linkSizeList = new MArrayList<>();
		
		if (this.flags.isSet(OLD_PASSWORD_FIELD)) {
			if (this.flags.isSet(ENTER_PASSWORD_FIELD))
				throw new IllegalArgumentException("\"ENTER_PASSWORD_FIELD\" flag cannot be used with \"OLD_PASSWORD_FIELD\"");

			linkSizeList.add(oldPassword);

			l.beginColumns();
				l.addComponent(oldPassword, i18n("Old Password:"));
			l.end();

			l.addHorizontalSeparator();
		}
				
		if (this.flags.isSet(NEW_PASSWORD_FIELD)) {
			if (this.flags.isSet(ENTER_PASSWORD_FIELD))
				throw new IllegalArgumentException("\"ENTER_PASSWORD_FIELD\" flag cannot be used with \"NEW_PASSWORD_FIELD\"");

			linkSizeList.add(newPassword);
			linkSizeList.add(confirmedNewPassword);

			l.beginColumns();
				l.addComponent(newPassword, i18n("New Password:"));
			l.end();
			l.beginColumns();
				l.addComponent(confirmedNewPassword, i18n("Confirm New Password:"));
			l.end();
			
			oldEchoChar = confirmedNewPassword.getEchoChar();
			togglePasswordText = new MCheckBox(i18n("Show Password Text"));
			togglePasswordText.addActionListener(e -> setPasswordTextVisible(togglePasswordText.isSelected()));
			l.addGap();
			l.addComponent(togglePasswordText);
		}

		if (this.flags.isSet(ENTER_PASSWORD_FIELD)) {
			l.addComponent(newPassword, i18n("Password:"));
		}

		l.end();

		if (this.flags.isSet(PASSWORD_GENERATOR)) {
			if (this.flags.isSet(ENTER_PASSWORD_FIELD))
				throw new IllegalArgumentException("\"ENTER_PASSWORD_FIELD\" flag cannot be used with \"PASSWORD_GENERATOR\"");

			MButton generatorButton = new MButton();
			generatorButton.setIconName("ui/random");
			generatorButton.setToolTipText(i18n("Generate Random Password..."));
			generatorButton.addActionListener(e -> generateRandomPassword());
			l.addContentGap();
			l.addComponent(generatorButton);
		}

		confirmedNewPassword.setConfirmation(newPassword);
		newPassword.setConfirmation(confirmedNewPassword);
		
		l.linkLabelSize(linkSizeList);
	}

	/**
	 * @since 3.4
	 */
	public void generateRandomPassword() {
		RandomPasswordGeneratorDialog dialog = new RandomPasswordGeneratorDialog(
			getWindowAncestor(),
			newPassword.getMinimumPasswordLength()
		);

		if (dialog.exec(dialog.randomPassword)) {
			String password = dialog.randomPassword.getText();
			newPassword.setText(password);
			confirmedNewPassword.setText(password);
		}
	}

	public char[] getConfirmedNewPassword() {
		return confirmedNewPassword.getPassword();
	}

	public MPasswordField getConfirmedNewPasswordField() { return confirmedNewPassword; }
	
	/**
	 * @since 4.8
	 */
	public boolean getCanShowPasswordText() { return canShowPasswordText; }

	/**
	 * @since 4.8
	 */
	public void setCanShowPasswordText(final boolean value) {
		checkPermission("accessPassword");
	
		canShowPasswordText = value;

		if (togglePasswordText != null)
			togglePasswordText.setEnabled(value);
			
		if (!value)
			setPasswordTextVisible(false);
	}

	public char[] getNewPassword() {
		return newPassword.getPassword();
	}

	public MPasswordField getNewPasswordField() { return newPassword; }

	public char[] getOldPassword() {
		return oldPassword.getPassword();
	}

	public MPasswordField getOldPasswordField() { return oldPassword; }
	
	public Info getPasswordInfo() {
		return new Info(getOldPassword(), getNewPassword());
	}

	/**
	 * @since 3.4
	 */
	public void installValidators(final ValidatorSupport validatorSupport) {
		if (newPassword != null) {
			newPasswordValidator = new PasswordValidator(this, newPassword);
			validatorSupport.add(newPasswordValidator);
		}

		if (confirmedNewPassword != null) {
			confirmedNewPasswordValidator = new PasswordValidator(this, confirmedNewPassword);
			validatorSupport.add(confirmedNewPasswordValidator);
		}
	}

	/**
	 * @since 3.4
	 */
	public void uninstallValidators(final ValidatorSupport validatorSupport) {
		if (confirmedNewPasswordValidator != null) {
			validatorSupport.remove(confirmedNewPasswordValidator);
			confirmedNewPasswordValidator = null;
		}

		if (newPasswordValidator != null) {
			validatorSupport.remove(newPasswordValidator);
			newPasswordValidator = null;
		}
	}

	/**
	 * @since 3.8
	 */
	public boolean isPasswordTextVisible() {
		return
			(oldEchoChar != MPasswordField.NONE_ECHO_CHAR) &&
			(confirmedNewPassword != null) &&
			(confirmedNewPassword.getEchoChar() == MPasswordField.NONE_ECHO_CHAR);
	}

	/**
	 * @since 3.8
	 */
	public void setPasswordTextVisible(final boolean visible) {
		if (visible && !canShowPasswordText)
			return;
	
		if ((confirmedNewPassword != null) && (newPassword != null)) {
			char echoChar = visible ? MPasswordField.NONE_ECHO_CHAR : oldEchoChar;
			confirmedNewPassword.setEchoChar(echoChar);
			newPassword.setEchoChar(echoChar);
		}
	}

	// MDisposable

	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		oldPassword.clear();
		newPassword.clear();
		confirmedNewPassword.clear();
	}

	// private

	private static void checkPermission(final String name) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new MPasswordPanel.Permission(name));
	}

	// public classes
	
	public static final class Info {
		
		// private
		
		private final char[] newPassword;
		private final char[] oldPassword;
		
		// public
		
		public void clear() {
			MPasswordPanel.checkPermission("accessPassword");

			CryptoUtils.clear(newPassword);
			CryptoUtils.clear(oldPassword);
		}
		
		public char[] getNewPassword() {
			MPasswordPanel.checkPermission("accessPassword");

			return (newPassword == null) ? null : newPassword.clone();
		}

		public char[] getOldPassword() {
			MPasswordPanel.checkPermission("accessPassword");

			return (oldPassword == null) ? null : oldPassword.clone();
		}
		
		// private
		
		private Info(final char[] oldPassword, final char[] newPassword) {
			this.oldPassword = oldPassword;
			this.newPassword = newPassword;
		}
		
	}

	/**
	 * @since 3.8.10
	 */
	public static final class Permission extends MPermission {

		// public

		@Override
		public String getIconName() { return "ui/password"; }

		// private

		private Permission(final String name) {
			super(name, ThreatLevel.HIGH, "Password Dialog Window");
		}

	}

	// private classes

	private static final class PasswordValidator extends TextComponentValidator {

		// private

		private final WeakReference<MPasswordPanel> panelRef;

		// protected

		@Override
		protected boolean isValid() throws Exception {
			MPasswordPanel panel = panelRef.get();

			if (panel == null)
				return true;

			MPasswordField passwordField = (MPasswordField)getComponent();
			MPasswordField.Status status = passwordField.getPasswordStatus();

			boolean ok;
			
			if (
				(status == MPasswordField.Status.NOT_EQUAL) &&
				// show validator message for confirmation field only
				(passwordField == panel.getNewPasswordField())
			) {
				ok = true;
			}
			else if ((status == MPasswordField.Status.EMPTY) && panel.flags.isSet(ALLOW_EMPTY_PASSWORD)) {
				ok = true;
			}
			else {
				ok = (status == MPasswordField.Status.OK);
			}

			if (!ok) {
				if (status == MPasswordField.Status.TOO_SHORT) {
					char[] password = passwordField.getPassword();
					CryptoUtils.clear(password);

					throw new Exception(status + " - " + (i18n("length: {0}, minimum: {1}", password.length, passwordField.getMinimumPasswordLength())));
				}

				throw new Exception(status.toString());
			}

			return true;
		}

		// private

		private PasswordValidator(final MPasswordPanel panel, final MPasswordField passwordField) {
			super(passwordField);
			panelRef = new WeakReference<>(panel);
		}

	}

	private static final class RandomPasswordGeneratorDialog extends MDialog {
		
		// private

		private char[] randomPasswordChars = new char[32];
		private ChangeListener passwordLengthChangeListener;
		private final MCheckBox remember;
		private final MNumberSpinner<Integer> passwordLength;
		private final MTextField randomPassword;

		// protected

		@Override
		protected void onClose() {
			CryptoUtils.clear(randomPasswordChars);
			if (passwordLengthChangeListener != null) {
				passwordLength.removeChangeListener(passwordLengthChangeListener);
				passwordLengthChangeListener = null;
			}
			super.onClose();
		}

		// private

		private RandomPasswordGeneratorDialog(final Window owner, final int minimumPasswordLength) {
			super(owner, i18n("Generate Random Password"), "ui/random", STANDARD_DIALOG | LINK_BUTTON);

			resetRandomPassword(true);
			final int maximumPasswordLength = randomPasswordChars.length;

			getOKButton().setEnabled(false);
			getOKButton().setText(i18n("Use Random Password"));

			getLinkButton().setText(i18n("Password Generator (Online)"));

			randomPassword = new MTextField(createRandomPassword(minimumPasswordLength));
			randomPassword.setColumns(maximumPasswordLength);
			randomPassword.setStyle("font-family: monospace; font-size: xx-large; font-weight: bold");

			remember = new MCheckBox(i18n("Remember or copy the above password and click here"));
			remember.addActionListener(e -> getOKButton().setEnabled(remember.isSelected()));

			passwordLength = new MNumberSpinner<>();
			passwordLength.setRange(minimumPasswordLength, maximumPasswordLength);
			passwordLength.setNumber(minimumPasswordLength);
			passwordLengthChangeListener = e -> updateComponents();
			passwordLength.addChangeListener(passwordLengthChangeListener);

			MSpinnerPanel passwordLengthPanel = new MSpinnerPanel(passwordLength);
			passwordLengthPanel.setCompactSize(true);

			MCheckBox symbolsCheckBox = new MCheckBox(i18n("Include Symbols"));
			symbolsCheckBox.setSelected(true);
			symbolsCheckBox.addActionListener(e -> {
				resetRandomPassword(symbolsCheckBox.isSelected());
				updateComponents();
			} );

			MButton resetButton = new MButton(MActionInfo.REFRESH, false);
			resetButton.addActionListener(e -> {
				resetRandomPassword(symbolsCheckBox.isSelected());
				updateComponents();
			} );

			MPanel p = new MPanel(false);
			p.getGroupLayout()
				.beginRows()
					.beginColumns()
						.addComponent(passwordLengthPanel, i18n("Password Length:"))
					.end()
					.addGap()
					.addComponent(symbolsCheckBox)
					.addLargeContentGap()
					.beginColumns()
						.addComponent(randomPassword, i18n("Random Password:"))
						.addContentGap()
						.addComponent(resetButton)
					.end()
					.addLargeContentGap()
					.addComponent(remember)
					.addLargeContentGap() // HACK: fix Substance LAF
				.end()
				.linkLabelSize(passwordLengthPanel, randomPassword);

			updateComponents();

			addCenter(p);
			packFixed();
		}

		private String createRandomPassword(final int minimumLength) {
			return new String(randomPasswordChars, 0, minimumLength);
		}
		
		private void resetRandomPassword(final boolean includeSymbols) {
			// HACK: exclude upper case "O" and "0" because it's visually identical
			String chars =
				"abcdefghijklmnopqrstuvwxyz" +
				"ABCDEFGHIJKLMNPQRSTUVWXYZ" +
				"123456789";
			if (includeSymbols)
				chars += "!@#$%^&*+-=";
			SecureRandom random = new SecureRandom();
			for (int i = 0; i < randomPasswordChars.length; i++)
				randomPasswordChars[i] = chars.charAt(random.nextInt(chars.length()));
		}
		
		private void updateComponents() {
			randomPassword.setText(createRandomPassword(passwordLength.getNumber()));
			remember.setSelected(false);
			getOKButton().setEnabled(false);
			getLinkButton().setURI("https://www.wolframalpha.com/input/?i=" + passwordLength.getNumber() + "%20characters%20password");
		}

	}

}
