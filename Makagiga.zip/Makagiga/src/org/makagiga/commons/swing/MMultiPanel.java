// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.lang.ref.WeakReference;
import java.util.EnumSet;
import java.util.List;
import javax.swing.Box;

import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.painters.GradientPainter;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MMultiPanel<I extends MMultiPanel.PanelItem> extends MPanel {

	// public

	/**
	 * @since 3.8.3
	 */
	public enum Button { ADD, COPY, REMOVE }

	// private

	private boolean confirmRemove;
	private final EnumSet<Button> visibleButtons = EnumSet.of(Button.ADD, Button.REMOVE);
	
	// public
	
	public MMultiPanel() {
		super(UI.VERTICAL);
		add(Box.createVerticalGlue());
	}
	
	public void addItem(final I item) {
		addItem(item, false);
	}
	
	public void addItem(final I item, final boolean effects) {
		addItem(item, getComponentCount() - 1, effects);
	}
	
	public void addItem(final I item, final int index, final boolean effects) {
		if (!containsItem(item)) {
			ItemWrapper<I> iw = new ItemWrapper<>(this, item);
			add(iw, index);
			revalidate();
			repaint();
			if (effects)
				ComponentAnimation.blendBackgroundProperty(iw, MHighlighter.OK_COLOR, null);
			
			if (item instanceof Focusable) {
				Focusable.class.cast(item).focus();
			}
			else {
				// focus first component
				if (item.getComponentCount() > 0)
					MComponent.requestFocus(item.getComponent(0));
			}

			updateCloseButtons();
		}
	}
	
	public boolean containsItem(final I item) {
		return getItems().contains(item);
	}
	
	public boolean getConfirmRemove() { return confirmRemove; }
	
	public void setConfirmRemove(final boolean value) { confirmRemove = value; }

	public int getItemCount() {
		return getItems().size();
	}
	
	@SuppressWarnings("unchecked")
	public List<I> getItems() {
		List<I> result = new MArrayList<>();
		for (ItemWrapper<I> i : new ContainerIterator<>(this, ItemWrapper.class))
			result.add(i.getView());

		return result;
	}

	/**
	 * @since 3.8.3
	 */
	public boolean isButtonVisible(final Button button) {
		return visibleButtons.contains(button);
	}

	/**
	 * @since 3.8.3
	 */
	public void setButtonVisible(final Button button, final boolean visible) {
		boolean changed;
		if (visible)
			changed = visibleButtons.add(button);
		else
			changed = visibleButtons.remove(button);

		if (changed) {
			for (ItemWrapper<?> i : new ContainerIterator<>(this, ItemWrapper.class)) {
				MButton b = i.getView().getButton(button);
				b.setVisible(visible);
			}
		}
	}

	public boolean isEmpty() {
		return getItems().isEmpty();
	}
	
	public void removeItem(final I item) {
		boolean needValidate = false;
		for (ItemWrapper<?> i : new ContainerIterator<>(this, ItemWrapper.class)) {
			if (i.getView() == item) {
				remove(i);
				needValidate = true;
			}
		}
		if (needValidate) {
			updateCloseButtons();
			revalidate();
			repaint();
		}
	}
	
	// protected
	
	protected I onAddItem(final MButton source) { return null; }

	/**
	 * @since 3.8.3
	 */
	protected I onCopyItem(final I item) { return null; }
	
	protected boolean onRemoveItem(final I item) { return true; }
	
	/**
	 * @since 4.10
	 */
	protected void onUpdateLayout(final MButton source, final I item) { }

	// private

	private void addItemAfter(final ButtonPanel<I> panel, final MButton button, final I item) {
		int afterThisIndex = getComponentZOrder(UI.getAncestorOfClass(ItemWrapper.class, panel)) + 1;
		addItem(item, afterThisIndex, true);

		if (MScrollPane.getScrollPane(this) != null) {
			// HACK: force layout update; MScrollPane need this
			validate();
			MScrollPane.scrollToVisible(this, UI.getAncestorOfClass(ItemWrapper.class, item).getBounds());
		}

		onUpdateLayout(button, item);
	}

	private void updateCloseButtons() {
		boolean enabled = getItemCount() > 1;
		for (ItemWrapper<?> i : new ContainerIterator<>(this, ItemWrapper.class)) {
			MButton removeButton = i.getView().getButton(MMultiPanel.Button.REMOVE);
			removeButton.setEnabled(enabled);
		}
	}
	
	// public classes
	
	public static class PanelItem extends MPanel {

		// public
		
		public PanelItem() {
			this(5, 5);
		}
		
		public PanelItem(final int hgap, final int vgap) {
			super(hgap, vgap);
		}
		
		public PanelItem(final LayoutManager layout) {
			super(layout);
		}

		/**
		 * @since 3.8.3
		 */
		public MButton getButton(final MMultiPanel.Button button) {
			ItemWrapper<?> iw = (ItemWrapper<?>)getParent();
			ButtonPanel<?> buttonPanel = iw.getButtonPanel();
			switch (button) {
				case ADD: return buttonPanel.addButtonRef.get();
				case COPY: return buttonPanel.copyButtonRef.get();
				case REMOVE: return buttonPanel.removeButtonRef.get();
				default: throw new WTFError(button);
			}
		}

	}
	
	// private classes
	
	private static final class ButtonPanel<I extends PanelItem> extends MPanel {

		// private
		
		private final WeakReference<MSmallButton> addButtonRef;
		private final WeakReference<MSmallButton> copyButtonRef;
		private final WeakReference<MSmallButton> removeButtonRef;

		// private
		
		private ButtonPanel(final MMultiPanel<I> parent, final I item) {
			super(UI.HORIZONTAL);
			setMargin(1);
			setPainter(new GradientPainter(MDialog.getSecondaryBackground(UI.getBackground(this))));
			
			MSmallButton addButton = new MSmallButton(MActionInfo.ADD);
			addButton.addActionListener(e -> {
				I i = parent.onAddItem(addButton);
				if (i != null)
					parent.addItemAfter(this, addButton, i);
				else
					UI.beep();
			} );
			add(addButton);

			MSmallButton copyButton = new MSmallButton(MActionInfo.DUPLICATE);
			copyButton.addActionListener(e -> {
				I copy = parent.onCopyItem(item);
				if ((copy != null) && (copy != item))
					parent.addItemAfter(this, copyButton, copy);
				else
					UI.beep();
			} );
			add(copyButton);

			MSmallButton removeButton = new MSmallButton(MActionInfo.REMOVE);
			removeButton.addActionListener(e -> {
				if (parent.getItemCount() == 1) {
					UI.beep();
				}
				else {
					if (
						!parent.confirmRemove ||
						MMessage.simpleConfirm(removeButton.getWindowAncestor(), MActionInfo.REMOVE)
					) {
						if (parent.onRemoveItem(item)) {
							parent.removeItem(item);
							parent.onUpdateLayout(removeButton, item);
						}
					}
				}
			} );
			addContentGap();
			add(removeButton);

			addButton.setVisible(parent.isButtonVisible(MMultiPanel.Button.ADD));
			copyButton.setVisible(parent.isButtonVisible(MMultiPanel.Button.COPY));
			removeButton.setVisible(parent.isButtonVisible(MMultiPanel.Button.REMOVE));

			addButtonRef = new WeakReference<>(addButton);
			copyButtonRef = new WeakReference<>(copyButton);
			removeButtonRef = new WeakReference<>(removeButton);
		}

	}
	
	private static final class ItemWrapper<I extends PanelItem> extends MWrapperPanel<I> {
		
		// private
		
		private ItemWrapper(final MMultiPanel<I> parent, final I item) {
			super(5, 0, UI.HORIZONTAL, item, null);
			setMargin(5);
			addEast(new ButtonPanel<>(parent, item));
			getLabel().setVisible(false); // no label
			limitHeight(item);
		}

		@SuppressWarnings("unchecked")
		private ButtonPanel<I> getButtonPanel() {
			BorderLayout l = (BorderLayout)getLayout();

			return (ButtonPanel<I>)l.getLayoutComponent(BorderLayout.LINE_END);
		}
		
	}
	
}
