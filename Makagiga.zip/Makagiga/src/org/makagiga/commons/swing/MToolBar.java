// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.LayoutManager2;
import java.awt.LinearGradientPaint;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.border.Border;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.mods.Mods;
import org.makagiga.commons.swing.border.MLineBorder;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * A tool bar.
 *
 * @mg.example
 * <pre class="brush: java">
 * MToolBar toolBar = new MToolBar();
 * toolBar.setTextPosition(MToolBar.TextPosition.ALONGSIDE_ICONS);
 *
 * // icon and text
 * toolBar.add(
 *   new MAction("Hello", "ui/ok") {
 *     {@literal @}Override
 *     public void onAction() {
 *       // tool bar button clicked
 *     }
 *   },
 *   MToolBar.SHOW_TEXT // show button text
 * );
 *
 * toolBar.addSeparator();
 *
 * // icon only
 * toolBar.add(
 *   new MAction("World", "ui/ok") {
 *     {@literal @}Override
 *     public void onAction() {
 *       // tool bar button clicked
 *     }
 *   }
 * );
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MToolBar extends JToolBar {
	
	// public
		
	public enum TextPosition {
		
		// public
		
		ALONGSIDE_ICONS,
		UNDER_ICONS,

		/**
		 * Unused.
		 *
		 * @deprecated Since 4.4
		 */
		@Deprecated
		USER;
	
		@Override
		public String toString() {
			switch (this) {
				case ALONGSIDE_ICONS:
					return i18n("Alongside Icons");
				case UNDER_ICONS:
					return i18n("Under Icons");
				case USER:
					return "(Old/Unused Option)";
				default:
					throw new WTFError(this);
			}
		}

	}

	/**
	 * Show button text.
	 */
	public static final int SHOW_TEXT = 1;
	
	/**
	 * Do not show button text.
	 *
	 * @since 1.2
	 */
	public static final int NO_TEXT = 1 << 1;

	/**
	 * @since 5.4
	 */
	public static final int PRESERVE_TEXT_POSITION = 1 << 2;

	/**
	 * @since 5.6
	 */
	public static final int FILL_HEIGHT = 1 << 3;

	/**
	 * Invoked from the {@link #addNotify()} method.
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.6
	 */
	public static final String MOD_ADD_NOTIFY = "addNotify@org.makagiga.commons.swing.MToolBar";

	/**
	 * Invoked from the {@link #removeNotify()} method.
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.6
	 */
	public static final String MOD_REMOVE_NOTIFY = "removeNotify@org.makagiga.commons.swing.MToolBar";

	// private

	private transient boolean allVisible = true;
	private boolean lineBorderSet;
	private static final int gradientWidth = 15;
	private MIcon.Size iconSize;
	private MLineBorder.Position lineBorderPosition;
	private static final StaticToolBarHandler staticToolBarHandler = new StaticToolBarHandler();
	private String id;
	private TextPosition textPosition = TextPosition.UNDER_ICONS;

	// public

	/**
	 * Constructs a horizontal tool bar.
	 *
	 * Defaults:
	 * - Not floatable
	 * - Rollovers are enabled
	 * - Border is not painted (Metal Look and Feel)
	 */
	public MToolBar() {
		this(HORIZONTAL, MIcon.Size.DEFAULT);
	}

	/**
	 * @since 2.2
	 */
	public MToolBar(final int orientation) {
		this(orientation, MIcon.Size.DEFAULT);
	}

	/**
	 * @since 2.0
	 */
	public MToolBar(final int orientation, final MIcon.Size iconSize) {
		super(orientation);
		this.iconSize = iconSize;
// TODO: 2.0: configurable
		if (UI.isMetal()) {
			setBorder(null);
			setBorderPainted(false);
		}
		setFloatable(false);
		setRollover(true);
		addPropertyChangeListener(staticToolBarHandler);
		
		UI.onComponentResized(this, e -> {
			boolean newAllVisible = true;
			for (Component i : getComponents()) {
				if ((i.getX() + i.getWidth() > getWidth()) && (i instanceof AbstractButton)) {
					newAllVisible = false;

					break; // for
				}
			}
		
			if (allVisible != newAllVisible) {
				allVisible = newAllVisible;
				if (!UI.isRetro())
					repaint(getWidth() - gradientWidth, 0, gradientWidth, getHeight());
			}
		} );
	}

	/**
	 * @since 2.2
	 */
	public MToolBar(final MIcon.Size iconSize) {
		this(HORIZONTAL, iconSize);
	}

	/**
	 * Adds a new action to this tool bar.
	 * @param action An action
	 * @return A new button associated with @p action
	 *
	 * @throws NullPointerException If @p action is @c null
	 */
	@Override
	public JButton add(final Action action) {
		return add(action, 0);
	}

	/**
	 * Adds a new action to this tool bar.
	 * @param action An action
	 * @param flags Flags (e.g. @ref SHOW_TEXT)
	 * @return A new button associated with @p action
	 *
	 * @throws NullPointerException If @p action is @c null
	 */
	public JButton add(final Action action, final int flags) {
		MButton b = new MButton(action);
		addButton(b, flags);
		
		return b;
	}
	
	/**
	 * @since 2.0
	 */
	public void addButton(final AbstractButton b) {
		addButton(b, 0);
	}

	/**
	 * @since 2.0
	 */
	public void addButton(final AbstractButton b, final int flags) {
		addButtonAt(-1, b, flags);
	}

	/**
	 * @since 3.8.11
	 */
	public void addButtonAt(final int index, final AbstractButton b, final int flags) {
		b.setRequestFocusEnabled(false);

		if (UI.isMetal()) {
			b.addMouseListener(staticToolBarHandler);
			b.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(MColor.getDarker(UI.getSelectionBackground())),
				UI.createEmptyBorder(2)
			));
			staticToolBarHandler.setupButton(b, false);
		}

		setupButton(b, flags);

		add(b, index);
	}

	/**
	 * @since 3.8.5
	 */
	public Component addContentGap() {
		return addGap(MPanel.DEFAULT_CONTENT_MARGIN);
	}

	/**
	 * Adds the default "line" separator.
	 *
	 * @since 4.0
	 */
	public void addDefaultSeparator() {
		super.addSeparator();
	}

	/**
	 * Adds and returns a vertical/horizontal gap (rigid area).
	 */
	public Component addGap() {
		return addGap(5);
	}

	/**
	 * @since 3.8.5
	 */
	public Component addGap(final int size) {
		Component gap =
			(getOrientation() == VERTICAL)
			? UI.createGap(0, size)
			: UI.createGap(size, 0);
		add(gap);

		return gap;
	}

	@Override
	public void addNotify() {
		super.addNotify();
		Mods.exec(this, MOD_ADD_NOTIFY);
	}

	@Override
	public void removeNotify() {
		super.removeNotify();
		Mods.exec(this, MOD_REMOVE_NOTIFY);
	}

	/**
	 * Adds a separator using the @ref addGap method.
	 */
	@Override
	public void addSeparator() {
		addGap();
	}

	/**
	 * Adds and returns a vertical/horizontal stretch (glue).
	 */
	public Component addStretch() {
		Component stretch =
			(getOrientation() == VERTICAL)
			? Box.createVerticalGlue()
			: Box.createHorizontalGlue();
		
		add(stretch);
		
		return stretch;
	}
	
	/**
	 * @since 2.0
	 */
	public MIcon.Size getIconSize() { return iconSize; }

	/**
	 * @since 3.0
	 */
	public void setIconSize(final MIcon.Size value) { iconSize = value; }

	/**
	 * @since 2.0
	 */
	public String getID() { return id; }

	/**
	 * @since 3.8.11
	 */
	public void setID(final String value) {
		this.id = TK.validateID(value);
	}

	@Override
	public Dimension getMinimumSize() {
		return new Dimension(0, super.getMinimumSize().height);
	}

	public TextPosition getTextPosition() { return textPosition; }
	
	public void setTextPosition(final TextPosition value) { textPosition = value; }

	@Override
	public void paint(final Graphics graphics) {
		super.paint(graphics);

		if (UI.isRetro())
			return;

		if (!allVisible) {
			Graphics2D g = (Graphics2D)graphics;

			int w = getWidth();
			int h = getHeight();
			int x1 = w - gradientWidth;
			int x2 = w - 1;

			Color c;
			if (UI.isNimbus())
				c = UIManager.getColor("nimbusBlueGrey");
			else
				c = UIManager.getColor("controlShadow");
			if (c == null)
				c = UI.getForeground(this);
			c = MColor.deriveAlpha(c, 200);

			g.setPaint(new LinearGradientPaint(
				(float)x1, 0f,
				(float)x2, 0f,
				new float[] { 0.0f, 1.0f },
				new Color[] { UI.INVISIBLE, c }
			));
			//g.setColor(Color.RED);
			g.fillRect(x1, 0, gradientWidth, h);
		}
	}

	@InvokedFromConstructor
	@Override
	public void setBorder(final Border value) {
		super.setBorder(value);
		lineBorderPosition = null;
		lineBorderSet = false;
	}

	@InvokedFromConstructor
	@Override
	public void setBorderPainted(final boolean value) {
		super.setBorderPainted(value);
		lineBorderPosition = null;
		lineBorderSet = false;
	}

/*
	@Override
	public void setLayout(final LayoutManager lm) {
		if (UI.isWeb() && !(lm instanceof Layout))
			super.setLayout(new Layout(this));
		else
			super.setLayout(lm);
	}
*/

	@Override
	public void setOpaque(final boolean value) {
		if (UI.isSubstance())
			super.setOpaque(true);
		else
			super.setOpaque(value);
	}

	/**
	 * @since 3.8.7
	 */
	public void showLineBorder(final MLineBorder.Position position) {
		MLineBorder lineBorder = new MLineBorder(position);
		for (MLineBorder.Position i : MLineBorder.Position.values()) {
			MLineBorder.Style s = lineBorder.getStyle(i);
			if (i == position)
				s.setColor(UI.getDarker(getBackground(), Color.WHITE));
			else
				s.setColor(null);
		}
		setBorder(lineBorder);
		setBorderPainted(true);
		lineBorderPosition = position;
		lineBorderSet = true;
	}

	@Override
	public void updateUI() {
		super.updateUI();
		
		// HACK: Synth (Nimbus, GTK+, etc.) tool bar layout is incompatible with Metal LAF.
		// BUG: http://bugs.sun.com/view_bug.do?bug_id=6745689
		if (UI.isSynth())
			setLayout(new Layout(this));

		// update colors
		if (lineBorderSet) {
			if (lineBorderPosition != null) {
				showLineBorder(lineBorderPosition);
			}
			else {
				setBorder(BorderFactory.createLineBorder(UI.getDarker(getBackground(), Color.WHITE), 1));
				setBorderPainted(true);
				lineBorderPosition = null;
				lineBorderSet = true;
			}
		}
	}

	// private
	
	/**
	 * @since 4.4
	 */
	public void setupButton(final AbstractButton b, final int flags) { // public
		setupButton(b, Flags.valueOf(flags));
	}
	
	private void setupButton(final AbstractButton b, final Flags f) {
		Action a = b.getAction();
		String text = (a == null) ? b.getText() : MAction.getValue(a, Action.NAME, (String)null);
		
		TextPosition useTextPosition;

		// force TextPosition.ALONGSIDE_ICONS for small icons
		if (
			(textPosition == TextPosition.UNDER_ICONS) &&
			(
				(iconSize == MIcon.Size.SMALL) ||
				(MIcon.getUISize() == MIcon.getSmallSize())
			)
		) {
			useTextPosition = TextPosition.ALONGSIDE_ICONS;
		}
		else {
			useTextPosition = textPosition;
		}

		if (
			(b instanceof MButton) &&
			!(b instanceof MSmallButton) &&
			(getOrientation() == HORIZONTAL) &&
			(useTextPosition == TextPosition.UNDER_ICONS)
		) {
			// does not work with tool bar layout
			//MButton.class.cast(b).setMinimumWidth(uiIconSize + 20);
			MButton.class.cast(b).setMargin(new Insets(0, 5, 0, 5));
		}

		if ((a != null) && (iconSize != MIcon.Size.DEFAULT)) {
			Icon icon = MAction.getIcon(a, iconSize);
			if ((icon != null) && (icon != b.getIcon()))
				b.setIcon(icon);
		}

		boolean isIcon = (b.getIcon() != null);

/* UNUSED: smaller font size:
		if (isIcon && !UI.isA03() && !UI.isWindows()) {
			Font baseFont = getFont();
			int minFontSize = (baseFont == null) ? UI.getDefaultFontSize() : baseFont.getSize();
			minFontSize--;
			UI.changeFontSize(b, -1, minFontSize, Integer.MAX_VALUE);
		}
*/

		// text under icons
		if (useTextPosition == TextPosition.UNDER_ICONS) {
			b.setHorizontalAlignment(CENTER);
			b.setHorizontalTextPosition(CENTER);
			b.setVerticalTextPosition(BOTTOM);
			if (f.isSet(NO_TEXT) && isIcon) {
				b.setText(null);
				if (b.getToolTipText() == null)
					b.setToolTipText(text);
			}
			else {
				b.setText(text);
			}
		}
		// text alongside icons
		else {
			if ((f.isSet(SHOW_TEXT) && f.isClear(NO_TEXT)) || !isIcon) {
				if (f.isClear(PRESERVE_TEXT_POSITION)) {
					b.setHorizontalTextPosition(RIGHT);
					b.setVerticalTextPosition(CENTER);
				}
				b.setText(text);
			}
			else {
				b.setHideActionText(true);
				b.setHorizontalTextPosition(CENTER);
				b.setVerticalTextPosition(BOTTOM);
				b.setText(null);
				if (b.getToolTipText() == null)
					b.setToolTipText(text);
			}
			
			if (f.isSet(FILL_HEIGHT)) {
				// HACK: force button height by setting an invisble icon on top of text
				b.setHorizontalAlignment(CENTER);
				b.setHorizontalTextPosition(CENTER);
				b.setVerticalAlignment(CENTER);
				b.setVerticalTextPosition(CENTER);
				b.setIcon(ShapeIcon.EMPTY.resized(getIconSize()));
				b.setIconTextGap(0);
			}
		}

		// handled by MButton.getToolTipText(MouseEvent)
		if (b.getToolTipText() == null)
			b.setToolTipText((text == null) ? UI.DYNAMIC_TOOL_TIP_TEXT : text);
	}

	// private classes

	/**
	 * A tool bar layout compatible with Metal LAF.
	 */
	private static final class Layout implements LayoutManager2 {

		// private

		private BoxLayout impl;

		// public

		public Layout(final MToolBar toolBar) {
			updateOrientation(toolBar);
		}

		@Override
		public void addLayoutComponent(final Component c, final Object constraints) { impl.addLayoutComponent(c, constraints); }

		@Override
		public void addLayoutComponent(final String name, final Component c) { impl.addLayoutComponent(name, c); }

		@Override
		public float getLayoutAlignmentX(final Container c) { return impl.getLayoutAlignmentX(c); }

		@Override
		public float getLayoutAlignmentY(final Container c) { return impl.getLayoutAlignmentY(c); }

		@Override
		public void invalidateLayout(final Container c) { impl.invalidateLayout(c); }

		@Override
		public void layoutContainer(final Container c) { impl.layoutContainer(c); }

		@Override
		public Dimension maximumLayoutSize(final Container c) { return impl.maximumLayoutSize(c); }

		@Override
		public Dimension minimumLayoutSize(final Container c) { return impl.minimumLayoutSize(c); }

		@Override
		public Dimension preferredLayoutSize(final Container c) { return impl.preferredLayoutSize(c); }

		@Override
		public void removeLayoutComponent(final Component c) { impl.removeLayoutComponent(c); }

		// private

		private void updateOrientation(final MToolBar toolBar) {
			impl = new BoxLayout(
				toolBar,
				(toolBar.getOrientation() == MToolBar.HORIZONTAL) ? BoxLayout.LINE_AXIS : BoxLayout.PAGE_AXIS
			);
		}

	}

	private static final class StaticToolBarHandler extends MMouseAdapter implements PropertyChangeListener {

		// public

		@Override
		public void mouseEntered(final MouseEvent e) {
			AbstractButton button = (AbstractButton)e.getSource();
			if (button.isEnabled())
				setupButton(button, true);
		}

		@Override
		public void mouseExited(final MouseEvent e) {
			AbstractButton button = (AbstractButton)e.getSource();
			setupButton(button, false);
		}

		// PropertyChangeListener

		@Override
		public void propertyChange(final PropertyChangeEvent e) {
			if (
				(e.getSource() instanceof MToolBar) &&
				"orientation".equals(e.getPropertyName())
			) {
				MToolBar toolBar = (MToolBar)e.getSource();
				LayoutManager l = toolBar.getLayout();
				if (l instanceof MToolBar.Layout)
					MToolBar.Layout.class.cast(l).updateOrientation(toolBar);
			}
		}

		// private

		private void setupButton(final AbstractButton button, final boolean hovered) {
			if (!(button instanceof JToggleButton) && !(button instanceof MSmallButton)) {
				button.setBorderPainted(hovered);
				button.setContentAreaFilled(hovered);
			}
		}

	}

}
