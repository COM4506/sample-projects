// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLayeredPane;
import javax.swing.JRootPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import org.makagiga.commons.Flags;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.OS;
import org.makagiga.commons.ReferenceCount;
import org.makagiga.commons.TK;
import org.makagiga.commons.TriBoolean;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.fx.Reflection;
import org.makagiga.commons.help.HelpButton;
import org.makagiga.commons.help.HelpContext;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.mods.Mods;
import org.makagiga.commons.validator.ValidatorMessage;
import org.makagiga.commons.validator.ValidatorSupport;

/**
 * A dialog base.
 *
 * @mg.example
 * <pre class="brush: java">
 * MDialog dialog = new MDialog(null, "Dialog Title");
 * dialog.getOKButton().setText("Do It!");
 * MTextField text = new MTextField();
 * dialog.addCenter(MPanel.createHLabelPanel(text, "Enter Text:"));
 * dialog.pack();
 * if (dialog.exec(text)) {
 *   // "Do It!" clicked
 *   System.out.println(text.getText());
 * }
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MDialog extends JDialog implements MBorderLayout {

	// public

	/**
	 * Show @b Cancel button.
	 */
	public static final int CANCEL_BUTTON = 1;

	/**
	 * Show @b OK button.
	 */
	public static final int OK_BUTTON = 1 << 1;

	/**
	 * Modal dialog.
	 */
	public static final int MODAL = 1 << 2;

	/**
	 * Show @b User button.
	 */
	public static final int USER_BUTTON = 1 << 3;

	/**
	 * Show the <i>link</i> button.
	 *
	 * @see #getLinkButton()
	 *
	 * @since 3.8.3
	 */
	public static final int LINK_BUTTON = 1 << 4;

	/**
	 * Show "Close" button instead of "OK".
	 */
	public static final int CLOSE_BUTTON = 1 << 5;

	/**
	 * @since 3.8
	 */
	@Obsolete
	public static final int FORCE_STANDARD_BORDER = 1 << 6;
	
	/**
	 * @since 2.0
	 */
	public static final int SIDE_BUTTONS = 1 << 7;

	/**
	 * @since 3.4
	 */
	public static final int HELP_BUTTON = 1 << 8;

	/**
	 * @since 3.8
	 */
	public static final int APPLY_BUTTON = 1 << 10;

	/**
	 * Do not dispose (destroy) dialog and its components on close.
	 *
	 * @since 3.8.6
	 */
	public static final int CACHED = 1 << 11;

	/**
	 * Do not print debug messages and stack traces.
	 *
	 * @since 3.8.10
	 */
	public static final int NO_DEBUG = 1 << 12;

	/**
	 * @since 4.2
	 */
	public static final int DETAILS_BUTTON = 1 << 13;

	/**
	 * @since 4.10
	 */
	public static final int LOCATION_BY_PLATFORM = 1 << 14;

	/**
	 * @since 4.12
	 */
	@Obsolete
	public static final int HEADER_BAR = 1 << 15;

	/**
	 * @since 5.2
	 */
	@Obsolete
	public static final int COMPACT_HEADER = 1 << 16;

	/**
	 * A modal dialog with @b Close button.
	 */
	public static final int SIMPLE_DIALOG = CLOSE_BUTTON | MODAL;
	
	/**
	 * A modal dialog with @b OK and @b Cancel buttons.
	 */
	public static final int STANDARD_DIALOG = OK_BUTTON | CANCEL_BUTTON | MODAL;

	/**
	 * Invoked after {@link #onClose()} and before {@link #dispose()}.
	 *
	 * @mg.note
	 * You can use {@link org.makagiga.commons.mods.Mods#DIALOG_CLOSE}
	 * to avoid {@code MDialog} class loading.
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.1 (MOD_CLOSE), 3.8 (MOD)
	 */
	public static final String MOD_CLOSE = Mods.DIALOG_CLOSE;

	/**
	 * Invoked from the {@link #exec(JComponent)} method; before {@code setVisible(true)}.
	 *
	 * @mg.note
	 * You can use {@link org.makagiga.commons.mods.Mods#DIALOG_EXEC}
	 * to avoid {@code MDialog} class loading.
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.1
	 */
	public static final String MOD_EXEC = Mods.DIALOG_EXEC;

	// private

	private boolean animationEnabled = true;
	private boolean closed;
	private boolean code;
	private boolean customBorder;
	private ComponentAnimation resizeAnimation;
	private ComponentDragAdapter titleDragAdapter;
	private ComponentDragAdapter toolBarDragAdapter;
	private Consumer<MDialog> onUserClickHandler;
	private final Dimension screenSize;
	private Flags flags;
	private HelpButton helpButton;
	private MAction acceptAction;
	private MAction helpAction;
	private MAction rejectAction;
	private MButton applyButton;
	private MButton cancelButton;
	private MButton okButton;
	private MButton userButton;
	private MButtonPanel okCancelPanel;
	private MLabel titleLabel;
	private MLinkButton linkButton;
	private MPanel bottomPanel;
	private MPanel buttonsPanel;
	private MPanel contentPane;
	private MPanel mainPanel;
	private MPanel titlePanel;
	private MSizeGrip sizeGrip;
	private MToggleButton detailsButton;
	private MWhatsThis whatsThis;
	private final Mnemonic mnemonic = new Mnemonic();
	private Point defaultLocation;
	private PropertyChangeListener lookAndFeelListener;
	private static final ReferenceCount<Class<? extends MDialog>> dialogStats = new ReferenceCount<>();
	private StaticButtonHandler staticButtonHandler;
	private StaticDialogHandler staticDialogHandler;
	private ValidatorMessage validatorMessage;
	private final ValidatorSupport validatorSupport = new ValidatorSupport();
	private WeakReference<JComponent> defaultFocusRef;
	private WeakReference<MToolBar> toolBarRef;

	// public

	/**
	 * Constructs a standard dialog with border layout.
	 * @param parent A parent window (or @c null)
	 * @param title A dialog title
	 */
	public MDialog(final Window parent, final String title) {
		this(parent, title, (Icon)null, STANDARD_DIALOG);
	}

	public MDialog(final Window parent, final String title, final int flags) {
		this(parent, title, (Icon)null, flags);
	}

	/**
	 * Constructs a standard dialog with border layout.
	 * @param parent A parent window (or @c null)
	 * @param title A dialog title
	 * @param icon A dialog icon
	 */
	public MDialog(final Window parent, final String title, final Icon icon) {
		this(parent, title, icon, STANDARD_DIALOG);
	}

	public MDialog(final Window parent, final String title, final String iconName) {
		this(parent, title, MIcon.stock(iconName), STANDARD_DIALOG);
	}

	/**
	 * Constructs a dialog with border layout.
	 * @param parent A parent window (or @c null)
	 * @param title A dialog title
	 * @param icon A dialog icon
	 * @param flags A dialog flags
	 */
	public MDialog(final Window parent, final String title, final Icon icon, int flags) {
		super(checkOwner(parent));
		if ((flags & CLOSE_BUTTON) != 0)
			flags |= OK_BUTTON;

		if (UI.standardDecorations.get() || OS.isGNOME() || UI.isRetro()) {
			flags |= FORCE_STANDARD_BORDER;
			flags &= ~HEADER_BAR;
		}

		this.flags = Flags.valueOf(flags);

		boolean developer = MLogger.isDeveloper() && this.flags.isClear(NO_DEBUG);
		if (developer) {
			boolean showTrace = false;

			boolean canIHazOwnr = false;
			for (Window i : Window.getWindows()) {
				if (i != this) {
					canIHazOwnr = true;

					break;
				}
			}

			if ((parent == null) && canIHazOwnr) {
				MLogger.warning("core", "No window ancestor for \"%s\" dialog", title);
				showTrace = true;
			}

			if (!SwingUtilities.isEventDispatchThread()) {
				MLogger.warning("core", "EDT rule violation: \"%s\"", title);
				showTrace = true;
			}

			if (showTrace)
				MLogger.trace(15);
		}

		screenSize = UI.getScreenSize();
		init(title, icon);
		
		if (developer && getFlags().isClear(CACHED) && (getClass() != MDialog.class)) {
			int count = dialogStats.addReference(getClass());
			if (count == 10)
				MLogger.debug("core", "Cache this window? (title=%s, class=%s)", getTitle(), getClass());
		}
	}
	
	public MDialog(final Window parent, final String title, final String iconName, final int flags) {
		this(parent, title, MIcon.stock(iconName), flags);
	}

	/**
	 * @since 3.8.1
	 */
	public MDialog(final Window owner, final MActionInfo info, final int flags) {
		this(owner, info.getDialogTitle(), info.getIcon(), flags);
	}

	public final boolean accept() {
		return done(true);
	}
	
	/**
	 * @since 4.4
	 */
	public void animatedResize(final Dimension size) {
		if (!isAnimationEnabled() || !UI.animations.get()) {
			setSize(size);
		
			return;
		}
	
		if ((resizeAnimation != null) && resizeAnimation.isActive()) {
			resizeAnimation.sizeProperty(null, size);
			
			return;
		}
		
		resizeAnimation = new ComponentAnimation(this)
			.duration(100)
			.sizeProperty(null, size)
			.play();
	}

	/**
	 * @since 3.0
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public void changeButton(final AbstractButton button, final MActionInfo info) {
		changeButton(button, info.getText(), info.getIconName());
	}

	/**
	 * @since 2.0
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public void changeButton(final AbstractButton button, final String text) {
		button.setText(text);
	}

	/**
	 * @since 1.2
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public void changeButton(final AbstractButton button, final String text, final Icon icon) {
		if (UI.buttonIcons.get())
			button.setIcon(icon);
		button.setText(text);
	}

	/**
	 * @since 2.0
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public void changeButton(final AbstractButton button, final String text, final String iconName) {
		changeButton(button, text, MIcon.stock(iconName));
	}
	
	public boolean exec() {
		return exec(null);
	}

	/**
	 * Executes the modal or non-modal dialog.
	 * The window position is relative to the parent window,
	 * or centered on the screen if parent is @c null.
	 * @return {@code true} if user clicked "OK"; otherwise {@code false}
	 */
	public boolean exec(final JComponent defaultFocus) {
		if (defaultFocusRef == null)
			defaultFocusRef = (defaultFocus == null) ? null : (new WeakReference<>(defaultFocus));
		MMenu.hideCurrentPopup();
		MSplashScreen.close();
		
		// HACK: A03 LAF
		UI.hideToolTip(null);

		Dimension currentSize = getSize();
		
		Container parent = getParent();
		if (defaultLocation != null) {
			setLocation(defaultLocation);
		}
		else if (flags.isSet(LOCATION_BY_PLATFORM)) {
			setLocationByPlatform(true);
		}
		else if ((parent != null) && parent.getSize().equals(currentSize)) {
			// ensure the parent window is visible
			setLocation(parent.getX() + 10, parent.getY() + 10);
		}
		else {
			setLocationRelativeTo(parent);
		}

		// limit width and height
		Dimension newSize = new Dimension(
			Math.min(screenSize.width, currentSize.width),
			Math.min(screenSize.height, currentSize.height)
		);
		if (!newSize.equals(currentSize)) {
			setSize(newSize);
			if (defaultLocation == null)
				setLocationRelativeTo(parent);
		}

		// warn if non-resizable dialog is larger than 800x600
		if (
			!isResizable() &&
			MLogger.isDeveloper() &&
			getFlags().isClear(NO_DEBUG) &&
			customBorder &&
			(
				(getWidth() > 800) ||
				(getHeight() > 600)
			)
		) {
			MLogger.warning("core", "Non-resizable dialog is larger than 800x600: \"%s\"", getTitle());
		}

		Mods.exec(this, MOD_EXEC);

		validatorSupport.validate(this);

		if (isModal() && (parent instanceof MDialog)) {
			MDialog parentDialog = (MDialog)parent;
		
			// remember current focus
			Component oldParentFocus = parentDialog.getFocusOwner();
			// HACK: this happens if dialog was invoked via JPopupMenu
			if (oldParentFocus instanceof JRootPane)
				oldParentFocus = null;
	
			// disable parent buttons
			TriBoolean isApplyEnabled = disableButton(parentDialog.getApplyButton());
			TriBoolean isCancelEnabled = disableButton(parentDialog.getCancelButton());
			TriBoolean isDetailsEnabled = disableButton(parentDialog.getDetailsButton());
			TriBoolean isHelpEnabled = disableButton(parentDialog.getHelpButton());
			TriBoolean isOKEnabled = disableButton(parentDialog.getOKButton());
			TriBoolean isLinkEnabled = disableButton(parentDialog.getLinkButton());
			TriBoolean isUserEnabled = disableButton(parentDialog.getUserButton());
			
			// show dialog
			try {
				setVisible(true);
			}
			finally {
				// enable parent buttons
				enableButton(parentDialog.getApplyButton(), isApplyEnabled);
				enableButton(parentDialog.getCancelButton(), isCancelEnabled);
				enableButton(parentDialog.getDetailsButton(), isDetailsEnabled);
				enableButton(parentDialog.getHelpButton(), isHelpEnabled);
				enableButton(parentDialog.getOKButton(), isOKEnabled);
				enableButton(parentDialog.getLinkButton(), isLinkEnabled);
				enableButton(parentDialog.getUserButton(), isUserEnabled);
				
				// restore old focus
				if (oldParentFocus != null)
					oldParentFocus.requestFocusInWindow();
			}
		}
		else {
			setVisible(true);
		}

		return code;
	}

	/**
	 * Returns the <i>Apply</i> button or {@code null}.
	 *
	 * @since 3.8
	 */
	public MButton getApplyButton() { return applyButton; }

	/**
	 * @since 5.0
	 */
	@Obsolete
	public MPanel getBottomPanel() { return bottomPanel; }

	/**
	 * @since 2.0
	 */
	public MPanel getButtonsPanel() { return buttonsPanel; }

	/**
	 * Returns the @b Cancel button.
	 */
	public MButton getCancelButton() { return cancelButton; }

	/**
	 * @since 4.2
	 */
	public AbstractButton getDetailsButton() { return detailsButton; }

	/**
	 * @since 4.0
	 */
	public Flags getFlags() { return flags; }

	/**
	 * @since 3.8.6
	 */
	public MPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = MPanel.createBorderPanel(5);
			if (customBorder) {
				int top = UI.isSubstance() ? MPanel.DEFAULT_CONTENT_MARGIN : 0;
				mainPanel.setMargin(top, MPanel.DEFAULT_CONTENT_MARGIN, MPanel.DEFAULT_CONTENT_MARGIN, MPanel.DEFAULT_CONTENT_MARGIN);
			}
			else
				mainPanel.setContentMargin();
			mainPanel.setOpaque(false);
			add(mainPanel, BorderLayout.CENTER);
		}

		return mainPanel;
	}

	/**
	 * Returns the @b Help button or @c null.
	 *
	 * @since 3.4
	 */
	public MButton getHelpButton() { return helpButton; }

	/**
	 * Returns the primary help context for this dialog (may be {@code null}).
	 *
	 * @since 3.8
	 */
	public HelpContext getHelpContext() {
		if (helpButton != null)
			return helpButton.getHelpContext();

		return null;
	}

	/**
	 * Sets the primary help context for this dialog to {@code value} (can be {@code null}).
	 *
	 * @since 3.8
	 */
	public void setHelpContext(final HelpContext value) {
		if (helpButton == null) {
			MLogger.warning("core", "Cannot set help context without MDialog.HELP_BUTTON option");

			return;
		}

		helpButton.setHelpContext(value);
	}
	
	/**
	 * @since 4.2
	 */
	public MSizeGrip getSizeGrip() { return sizeGrip; }

	/**
	 * Returns the @b OK button.
	 */
	public MButton getOKButton() { return okButton; }
	
	/**
	 * Returns the icon/title label or @c null.
	 * 
	 * @since 3.0
	 */
	public MLabel getTitleLabel() { return titleLabel; }

	/**
	 * @since 3.8.2
	 */
	public MPanel getTitlePanel() { return titlePanel; }

	/**
	 * @since 2.2
	 */
	public MToolBar getToolBar() {
		return TK.get(toolBarRef);
	}
	
	/**
	 * Sets tool bar to @p value.
	 *
	 * @since 1.2
	 */
	public void setToolBar(final MToolBar toolBar) {
		MToolBar oldToolBar = getToolBar();
		if (toolBarDragAdapter != null)
			toolBarDragAdapter.uninstall(oldToolBar);
	
		toolBarDragAdapter = new ComponentDragAdapter();
		toolBarDragAdapter.install(toolBar);
		toolBarRef = new WeakReference<>(toolBar);
		
		toolBar.setOpaque(false);
		if (toolBar.getOrientation() == MToolBar.HORIZONTAL) {
			if (titlePanel != null) {
				if (customBorder)
					titlePanel.setMargin(0, 0, MPanel.DEFAULT_CONTENT_MARGIN, 0); // bottom margin
				titlePanel.addSouth(toolBar);
			}
			else
				addNorth(toolBar);
		}
		else { // VERTICAL
			addEast(toolBar);
		}
	}

	/**
	 * Returns the <i>link</i> button, or {@code null}.
	 *
	 * @since 3.8.3
	 */
	public MLinkButton getLinkButton() { return linkButton; }

	/**
	 * @since 5.6
	 */
	public static Color getSecondaryBackground(final Color color) {
		return MColor.getContrast(color, 0.03f);
	}

	/**
	 * Returns the @b User button.
	 */
	public MButton getUserButton() { return userButton; }

	/**
	 * @since 3.4
	 */
	public ValidatorMessage getValidatorMessage() { return validatorMessage; }

	/**
	 * @since 3.4
	 */
	public void setValidatorMessage(final ValidatorMessage validatorMessage) {
		this.validatorMessage = validatorMessage;
		if (validatorMessage != null)
			validatorMessage.setVisible(false);
	}

	/**
	 * @since 3.4
	 */
	public ValidatorSupport getValidatorSupport() { return validatorSupport; }

	/**
	 * @since 3.8.6
	 */
	public ValidatorMessage installValidatorMessage() {
		ValidatorMessage message = new ValidatorMessage();
		setValidatorMessage(message);

		getLayeredPane().add(message, JLayeredPane.POPUP_LAYER);

		return validatorMessage;
	}

	/**
	 * @since 4.4
	 */
	public boolean isAnimationEnabled() { return animationEnabled; }

	/**
	 * @since 4.4
	 */
	public void setAnimationEnabled(final boolean value) { animationEnabled = value; }

	/**
	 * @since 3.8
	 */
	public boolean isClosed() { return closed; }
	
	/**
	 * @since 4.10
	 */
	public static MDialog of(final Component c) {
		Window window = UI.windowFor(c);
		
		return (window instanceof MDialog) ? (MDialog)window : null;
	}
	
	/**
	 * @since 5.4
	 */
	public void onUserClick(final Consumer<MDialog> handler) {
		if (onUserClickHandler != null)
			MLogger.warning("core", "Replacing old onUserClick handler: %s -> %s", onUserClickHandler, handler);
		
		onUserClickHandler = handler;
	}

	/**
	 * @since 5.4
	 */
	public void pack(final UI.WindowSize width) {
		Dimension size = new Dimension(width.getDimensionForDialog().width, getHeight());
		Dimension oldMinimumSize = isMinimumSizeSet() ? getMinimumSize() : null;
		setMinimumSize(size); // for "pack"
		pack();
		setMinimumSize(oldMinimumSize); // allow free resizing
	}

	/**
	 * @since 2.0
	 */
	public void packFixed() {
		pack();
		setResizable(false);
	}

	/**
	 * @since 3.8.6
	 */
	public void packFixed(final UI.WindowSize width) {
		Dimension size = new Dimension(width.getDimensionForDialog().width, getHeight());
		setMaximumSize(size);
		setMinimumSize(size);
		packFixed();
	}

	public final void reject() {
		done(false);
	}

	/**
	 * @since 3.8.2
	 */
	public void removeContentMargin() {
		MPanel p = getMainPanel();
		// no top/left/right margin
		if (
			(customBorder || UI.isSeaGlass()) &&
			flags.isClear(SIDE_BUTTONS) &&
			(UI.isNimbus() || UI.isSeaGlass() || UI.isSubstance())
		) {
			int top = UI.isSubstance() ? MPanel.DEFAULT_CONTENT_MARGIN : 0;
			p.setMargin(top, 0, MPanel.DEFAULT_CONTENT_MARGIN, 0);
		}
	}

	/**
	 * @since 5.0
	 */
	public void setAutoSize(final boolean animation) {
		Dimension to = getPreferredSize();
		to.width = Math.max(getWidth(), to.width);

		Point fixedLocation = getLocation();
		if (getFixedScreenYLocation(fixedLocation, to.height))
			setLocation(fixedLocation);
		
		if (animation)
			animatedResize(to);
		else
			setSize(to);
	}

	/**
	 * @since 2.0
	 */
	public void setDefault(final JButton b) {
		b.setDefaultCapable(true);
		getRootPane().setDefaultButton(b);
	}

	/**
	 * @since 3.8.12
	 */
	public void setDefaultFocus(final JComponent c) {
		defaultFocusRef = new WeakReference<>(c);
	}

	/**
	 * @since 3.8.10
	 */
	public void setDefaultLocation(final Point location) {
		defaultLocation = (location == null) ? null : (new Point(location));
	}

	/**
	 * @since 3.4
	 */
	public void setHeight(final int height) {
		setSize(getWidth(), height);
	}

	/**
	 * @since 4.4
	 */
	public void setMainPanelMargin(final int margin) {
		MPanel main = getMainPanel();
		if (main != null) {
			int top = (flags.isSet(FORCE_STANDARD_BORDER) || UI.isRetro() || UI.isSubstance()) ? margin : 0;
			main.setMargin(top, margin, margin, margin);
		}
	}

	@Override
	public void setResizable(final boolean value) {
		super.setResizable(value);

		if (sizeGrip != null)
			sizeGrip.setVisible(isResizable());
	}

	/**
	 * @since 3.8.3
	 */
	public void setSize(final UI.WindowSize size) {
		setSize(size.getDimensionForDialog());
	}
	
	@Override
	public void setTitle(final String value) {
		super.setTitle(MFrame.fixWindowTitle(value));
	}

	@Override
	public void setVisible(final boolean value) {
		if (value && MApplication.getForceRTL() && !isVisible())
			applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

		super.setVisible(value);
	}

	/**
	 * @since 3.4
	 */
	public void setWidth(final int width) {
		setSize(width, getHeight());
	}

	/**
	 * @since 3.0
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public void updateMnemonic(final AbstractButton b) {
		mnemonic.update(b);
	}
	
	/**
	 * @since 4.4
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public void updateMnemonic(final boolean reset) {
		if (reset)
			mnemonic.reset();
		mnemonic.apply(this);
	}

	// MBorderLayout

	@Override
	public void addCenter(final JComponent component) {
		if (component instanceof JTabbedPane)
			removeContentMargin();
		UI.addCenter(getMainPanel(), component);
	}

	@Override
	public void addEast(final JComponent component) {
		getMainPanel().add(component, BorderLayout.LINE_END);
	}

	@Override
	public void addNorth(final JComponent component) {
		getMainPanel().add(component, BorderLayout.PAGE_START);
	}

	@Override
	public void addSouth(final JComponent component) {
		getMainPanel().add(component, BorderLayout.PAGE_END);
	}

	@Override
	public void addWest(final JComponent component) {
		getMainPanel().add(component, BorderLayout.LINE_START);
	}

	// protected

	/**
	 * @since 2.0
	 */
	protected void applyMnemonic(final Container c) {
		mnemonic.apply(c);
	}

	/**
	 * @throws IllegalArgumentException If @p action name is @c null or empty
	 */
	protected void bind(final int condition, final Action action) {
		MAction.connect(contentPane, condition, action);
	}

	/**
	 * @throws IllegalArgumentException If @p action name is @c null or empty
	 */
	protected void bind(final int condition, final int keyCode, final Action action) {
		MAction.connect(contentPane, condition, keyCode, action);
	}

	/**
	 * @since 5.4
	 */
	protected boolean confirmReject() {
		while (true) {
			MActionInfo doNotSave = new MActionInfo(i18n("Do Not Save"));

			MActionInfo result = MMessage.getAction(
				this,
				i18n("Save changes?"),
				MIcon.stock("ui/question"),
				new MArrayList<>(MActionInfo.SAVE, doNotSave)
			);
			
			if (result == MActionInfo.SAVE)
				return accept();
			
			if (result == doNotSave)
				return true;
			
			return false; // cancel
		}
	}

	/**
	 * Sets return code to @p value, and disposes the dialog.
	 */
	protected boolean done(final boolean value) {
		code = value;
		// accepted
		if (code) {
			if (!onAccept())
				return false; // do not dispose window
		}
		// rejected
		else {
			if ((cancelButton != null) && !cancelButton.isEnabled())
				return false;

			if (!onReject())
				return false; // do not dispose window
		}
		onClose();
		closed = true;

		Mods.exec(this, MOD_CLOSE);

		dispose();
		
		// do not destroy/shut down
		if (flags.isSet(CACHED))
			return true;
		
		resizeAnimation = TK.dispose(resizeAnimation);
		validatorSupport.removeAll();

		uninstallComponents();
		
		return true;
	}

	/**
	 * @since 5.0
	 */
	protected boolean getFixedScreenYLocation(final Point location, final int newHeight) {
		Dimension screenSize = UI.getScreenSize();
		Insets screenInsets = UI.getScreenInsets();

		int dialogBottom = location.y + newHeight;
		int screenBottom = screenSize.height - screenInsets.bottom;
		if (dialogBottom > screenBottom) {
			location.y -= (dialogBottom - screenBottom);
			
			return true;
		}
		
		return false;
	}

	/**
	 * @since 4.0
	 */
	public/*protected*/ Mnemonic getMnemonic() { return mnemonic; }

	/**
	 * Invoked when user pressed the <i>Enter</i> key,
	 * or clicked the <i>OK/Apply</i> button.
	 *
	 * The default impementation does nothing, and returns {@code true}.
	 */
	protected boolean onAccept() { return true; }

	protected void onClose() { }
	
	/**
	 * @since 4.2
	 */
	protected void onDetailsClick(final boolean visible) { }

	/**
	 * Invoked when the <i>Help</i> button is clicked.
	 *
	 * @since 3.4
	 */
	protected void onHelpClick() {
		if (whatsThis == null) {
			List<MWhatsThis.Info> all = MWhatsThis.getAll(this);

			if (all.isEmpty())
				return; // nothing to show
		
			whatsThis = new MWhatsThis(this);
			setGlassPane(whatsThis);
			whatsThis.setVisible(true);
		}
		else {
			MFrame.clearGlassPane(this);
			whatsThis = null;
		}
	}

	/**
	 * Invoked when the <i>link</i> button is clicked.
	 *
	 * By default this method opens the URI associated with the <i>link</i> button.
	 *
	 * @since 3.8.3
	 */
	protected void onLinkClick() {
		if (linkButton != null)
			linkButton.doOpen();
	}

	/**
	 * Invoked when user pressed the @b Esc key,
	 * or clicked the @b Cancel button.
	 * By default this method does nothing, and returns @c true.
	 */
	protected boolean onReject() { return true; }

	/**
	 * Invoked when the @b User button is clicked.
	 * By default this method does nothing.
	 */
	protected void onUserClick() { }

	/**
	 * @since 4.2
	 */
	protected void setDetailsVisible(final Component c, final boolean visible) {
		// ensure the height is set correctly
		if ((resizeAnimation != null) && resizeAnimation.isActive())
			resizeAnimation.end();

		c.setVisible(visible);
		Dimension newSize;
		if (visible) {
			Dimension detailsPref = c.getPreferredSize();
			newSize = new Dimension(
				getWidth() + Math.max(0, (detailsPref.width - getWidth())),
				getHeight() + detailsPref.height
			);
		}
		else {
			newSize = new Dimension(getWidth(), getHeight() - c.getHeight());
		}

		animatedResize(newSize);
	}

	// private

	/**
	 * Returns @c null to avoid @c IllegalArgumentException if @p owner window is "wrong".
	 */
	private static Window checkOwner(final Window owner) {
		return
			((owner instanceof Dialog) || (owner instanceof Frame))
			? owner
			: null;
	}
	
	private TriBoolean disableButton(final AbstractButton button) {
		TriBoolean state =
			(button == null)
			? TriBoolean.UNDEFINED
			: TriBoolean.of(button.isEnabled());
		
		if (state.isTrue())
			button.setEnabled(false);
		
		return state;
	}

	private void doCancel() {
		if ((cancelButton != null) && cancelButton.isEnabled() && cancelButton.isVisible())
			cancelButton.doClick();
		else
			reject();
	}

	private boolean doClick(final AbstractButton b) {
		if ((b != null) && b.hasFocus() && b.isEnabled() && b.isVisible()) {
			b.doClick();

			return true;
		}

		return false;
	}

	private void enableButton(final AbstractButton button, final TriBoolean state) {
		if (state.isTrue())
			button.setEnabled(true);
	}

	private void init(final String title, final Icon icon) {
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

		setModal(flags.isSet(MODAL));

		Dimension defaultSize = new Dimension(64, 64);
		setMinimumSize(defaultSize);
		setSize(defaultSize);
		
		setTitle(title);

		// set custom content pane
		contentPane = MPanel.createBorderPanel();
		setBackground(contentPane.getBackground());
		setContentPane(contentPane);

		// init buttons
		
		if (flags.isSet(OK_BUTTON) || flags.isSet(CANCEL_BUTTON) || flags.isSet(APPLY_BUTTON)) {
			if (flags.isSet(SIDE_BUTTONS))
				buttonsPanel = MPanel.createVBoxPanel();
			else
				buttonsPanel = MPanel.createHBoxPanel();
			buttonsPanel.setOpaque(false);

			boolean helpButtonVisible = false;

			// add help button
			if (flags.isSet(HELP_BUTTON)) {
				helpButtonVisible = Kiosk.actionHelp.get();

				helpButton = new HelpButton() {
					@Override
					protected void onClick() {
						if (this.getHelpContextList().isEmpty())
							MDialog.of(this).onHelpClick();
						else
							super.onClick();
					}
				};
				helpButton.setVisible(helpButtonVisible);

				buttonsPanel.add(helpButton);
			}

			// add details button
			if (flags.isSet(DETAILS_BUTTON)) {
				detailsButton = new MToggleButton(i18n("Details"));
				detailsButton.addActionListener(e -> onDetailsClick(detailsButton.isSelected()));
				detailsButton.setIcon(
					UI.buttonIcons.get() ? ShapeIcon.RIGHT_ARROW.resized(UI.iconSize.get()) : ShapeIcon.RIGHT_ARROW
				);
				detailsButton.setRolloverIcon(
					UI.buttonIcons.get() ? ShapeIcon.RIGHT_ARROW.resized(UI.iconSize.get()) : ShapeIcon.RIGHT_ARROW
				);
				detailsButton.setSelectedIcon(
					UI.buttonIcons.get() ? ShapeIcon.DOWN_ARROW.resized(UI.iconSize.get()) : ShapeIcon.DOWN_ARROW
				);
				if (helpButtonVisible)
					buttonsPanel.addContentGap();
				buttonsPanel.add(detailsButton);
			}

			// add user button
			if (flags.isSet(USER_BUTTON)) {
				userButton = new MButton();
				userButton.addActionListener(e -> {
					onUserClick();
					if (onUserClickHandler != null)
						onUserClickHandler.accept(this);
				} );
				if (flags.isSet(DETAILS_BUTTON) || helpButtonVisible)
					buttonsPanel.addContentGap();
				buttonsPanel.add(userButton);
			}

			// add link button
			if (flags.isSet(LINK_BUTTON)) {
				linkButton = new MLinkButton() {
					@Override
					protected void onClick() {
						MDialog.of(this).onLinkClick();
					}
				};
				// BUG: linkButton.addActionListener(e -> onLinkClick());
				if (helpButtonVisible || flags.isSet(USER_BUTTON))
					buttonsPanel.addContentGap();
				buttonsPanel.add(linkButton);
			}
			
			// create buttons
			if (flags.isSet(OK_BUTTON)) {
				if (isHeaderBarCloseButton()) {
					okButton = new MSmallButton(MActionInfo.CLOSE.getIcon(), MActionInfo.CLOSE.getText());
					okButton.setFocusable(false);
				}
				else {
					okButton = new MButton();
					okButton.setMinimumWidth(75);
					if (flags.isSet(CLOSE_BUTTON)) {
						okButton.setIconNameUI("ui/close");
						okButton.setText(mnemonic.apply(okButton, i18n("&Close")));
					}
					else {
						okButton.setIconNameUI("ui/ok");
						okButton.setText(mnemonic.apply(okButton, i18n("&OK")));
					}
				}
				okButton.addActionListener(e -> accept());
			}
			if (flags.isSet(CANCEL_BUTTON)) {
				// normal UI
				if (UI.isGTK() || UI.isMac() || UI.isRetro() || UI.isWindows()) {
					cancelButton = new MButton();
					cancelButton.setIconNameUI("ui/cancel");
				}
				// web-like UI
				else {
					cancelButton = new MLinkButton();
					cancelButton.setHorizontalAlignment(MLinkButton.CENTER);
				}
				cancelButton.setText(mnemonic.apply(cancelButton, i18n("&Cancel")));
				cancelButton.addActionListener(e -> reject());
			}
			if (flags.isSet(APPLY_BUTTON)) {
				applyButton = new MButton();
				applyButton.addActionListener(e -> onAccept());
				applyButton.setIconNameUI("ui/apply");
				applyButton.setText(mnemonic.apply(applyButton, i18n("&Apply")));
			}

			// add buttons
			int okCancelPanelFlags = MButtonPanel.NO_PAINTER;
			if (flags.isSet(SIDE_BUTTONS))
				okCancelPanelFlags |= MButtonPanel.VERTICAL;
			else
				okCancelPanelFlags |= MButtonPanel.HORIZONTAL;
			if (OS.isWindows())
				okCancelPanel = new MButtonPanel(okCancelPanelFlags, okButton, cancelButton, applyButton);
			else
				okCancelPanel = new MButtonPanel(okCancelPanelFlags, okButton, applyButton, cancelButton);

			bottomPanel = new MPanel(MPanel.DEFAULT_CONTENT_MARGIN, MPanel.DEFAULT_CONTENT_MARGIN) {
				@Override
				public void setVisible(final boolean value) {
					MDialog dialog = MDialog.of(this);
					if (!value && (dialog != null) && dialog.flags.isSet(MDialog.FORCE_STANDARD_BORDER))
						super.setVisible(true);
					else
						super.setVisible(value);
				}
			};
			if (flags.isSet(SIDE_BUTTONS)) {
				int topMargin =
					flags.isSet(FORCE_STANDARD_BORDER) || UI.isSubstance()
					? MPanel.DEFAULT_CONTENT_MARGIN
					: 0;
				bottomPanel.setMargin(topMargin, 0, MPanel.DEFAULT_CONTENT_MARGIN, MPanel.DEFAULT_CONTENT_MARGIN);

				bottomPanel.setOpaque(false);
			}
			else {
				bottomPanel.setMargin(MPanel.DEFAULT_CONTENT_MARGIN);
				if (UI.isRetro()) {
					bottomPanel.setOpaque(false);
				}
				else {
					bottomPanel.setOpaque(true);
					bottomPanel.setBackground(getSecondaryBackground(UI.getBackground(contentPane)));
				}
			}

			if (flags.isSet(SIDE_BUTTONS)) {
				bottomPanel.addNorth(buttonsPanel);
				bottomPanel.addSouth(okCancelPanel);
			}
			else {
				bottomPanel.addWest(buttonsPanel);
				bottomPanel.addEast(okCancelPanel);
			}
			add(
				bottomPanel,
				flags.isSet(SIDE_BUTTONS)
				? BorderLayout.LINE_END // east
				: BorderLayout.PAGE_END // south
			);

			// set default button
			if (flags.isSet(OK_BUTTON))
				setDefault(okButton);
		}
		
		installComponents();

		titlePanel = MPanel.createBorderPanel();
		titlePanel.setOpaque(false);
		add(titlePanel, BorderLayout.PAGE_START); // no "addNorth"

		// custom border

		if (flags.isClear(FORCE_STANDARD_BORDER)) {
			customBorder = true;
			if (UI.isRetro()) {
				getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
			}
			else {
				UI.setStyle("border-style: outset", getRootPane());
				if (UI.isSeaGlass())
					getRootPane().setWindowDecorationStyle(JRootPane.NONE);
			}
			setUndecorated(true);
			
			initTitle(icon);
			titlePanel.addNorth(titleLabel);

			if (isHeaderBarCloseButton()) {
				MPanel p = MPanel.createVBoxPanel();
				p.setMargin(flags.isSet(COMPACT_HEADER) ? 5 : p.getContentMargin());
				p.setOpaque(false); // fixes Substance LAF
				p.add(okButton);
				titlePanel.addEast(p);
				titlePanel.addCenter(titleLabel);
			}
			else {
				titlePanel.addNorth(titleLabel);
			}

			sizeGrip = new MSizeGrip(this);
			sizeGrip.setVisible(isResizable());
			getLayeredPane().add(sizeGrip, JLayeredPane.DEFAULT_LAYER + 1);
			moveToCorner(sizeGrip);
		}
		else {
			if (UI.isSeaGlass()) {
				getRootPane().setWindowDecorationStyle(JRootPane.NONE);
				setUndecorated(false);
			}
		}
	}

	private void initTitle(final Icon icon) {
		boolean smallScreen = screenSize.height < 768;
		titleLabel = new MLabel(getTitle());
		titleLabel.setIconTextGap(MPanel.DEFAULT_CONTENT_MARGIN);
		
		boolean compactTitle = flags.isSet(COMPACT_HEADER) || smallScreen;
		
		if (icon != null) {
			if (!compactTitle && (icon instanceof ImageIcon) && (ImageIcon.class.cast(icon).getImage() != null)) {
				Reflection r = new Reflection();
				r.setBlur(true);
				r.setGradientAlpha(0.6f);
				r.setReflectionSize(0.5f);

				// preserve "overlay" icon
				if ((icon instanceof MIcon) && (MIcon.class.cast(icon).getOverlay() != null))
					titleLabel.setImage(r.createImage(UI.toBufferedImage(icon)));
				else
					titleLabel.setIcon(r.createIcon((ImageIcon)icon));
			}
			else {
				titleLabel.setIcon(icon);
			}
		}

		String style = MPanel.HEADER_FONT_STYLE;
		style += ("; margin: " + (compactTitle ? 5 : MPanel.DEFAULT_CONTENT_MARGIN));
		titleLabel.setStyle(style);

		// window dragging
		titleDragAdapter = new ComponentDragAdapter();
		titleDragAdapter.install(titleLabel);
	}

	private void installComponents() {
		acceptAction = new MAction("MDialog.accept") {
			@Override
			public void onAction() {
				MDialog dialog = (MDialog)this.getSourceWindow();

				if (dialog.doClick(dialog.applyButton))
					return;

				if (dialog.doClick(dialog.cancelButton))
					return;

				if (dialog.doClick(dialog.okButton))
					return;

				if (dialog.doClick(dialog.userButton))
					return;

				if (dialog.doClick(dialog.linkButton))
					return;

				if (dialog.doClick(dialog.helpButton))
					return;

				if (dialog.doClick(dialog.detailsButton))
					return;

				if (dialog.okButton == null) {
					JButton defaultButton = getRootPane().getDefaultButton();
					if ((defaultButton != null) && defaultButton.isDefaultCapable())
						defaultButton.doClick();
					else
						dialog.accept();
				}
				else
					dialog.okButton.doClick();
			}
		};
		bind(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT, VK_ENTER, acceptAction);
		
		rejectAction = new MAction("MDialog.reject", action -> doCancel());
		bind(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT, VK_ESCAPE, rejectAction);

		helpAction = new MAction("MDialog.help", action -> {
			if (helpButton != null)
				helpButton.doClick();
			else
				onHelpClick();
		} );
		bind(JComponent.WHEN_IN_FOCUSED_WINDOW, VK_F1, helpAction);

		staticButtonHandler = new StaticButtonHandler();
		if (cancelButton != null)
			cancelButton.addPropertyChangeListener(staticButtonHandler);
		if (detailsButton != null)
			detailsButton.addPropertyChangeListener(staticButtonHandler);
		if (linkButton != null)
			linkButton.addPropertyChangeListener(staticButtonHandler);
		if (okButton != null)
			okButton.addPropertyChangeListener(staticButtonHandler);
		if (userButton != null)
			userButton.addPropertyChangeListener(staticButtonHandler);

		staticDialogHandler = new StaticDialogHandler();
		addComponentListener(staticDialogHandler);
		addPropertyChangeListener(staticDialogHandler);
		addWindowListener(staticDialogHandler);
		
		if (flags.isSet(CACHED)) {
			lookAndFeelListener = UI.installLookAndFeelListener(this);
		}
	}

	private boolean isHeaderBarCloseButton() {
		return flags.isSet(HEADER_BAR) && flags.isSet(CLOSE_BUTTON) && flags.isSet(OK_BUTTON) &&
			!flags.isSet(CANCEL_BUTTON) && !flags.isSet(APPLY_BUTTON);
	}

	private void moveToCorner(final MSizeGrip sizeGrip) {
		Container parent = sizeGrip.getParent();
		if (parent != null) {
			sizeGrip.setLocation(
				parent.getWidth() - sizeGrip.getWidth(),
				parent.getHeight() - sizeGrip.getHeight()
			);
		}
	}

	private void uninstallComponents() {
		defaultFocusRef = TK.dispose(defaultFocusRef);

		if (toolBarRef != null) {
			if (toolBarDragAdapter != null)
				toolBarDragAdapter.uninstall(toolBarRef.get());
			toolBarRef = TK.dispose(toolBarRef);
		}
		toolBarDragAdapter = null;

		if (contentPane != null) {
			if (acceptAction != null) {
				acceptAction.disconnect(contentPane, JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
				acceptAction = null;
			}
			if (rejectAction != null) {
				rejectAction.disconnect(contentPane, JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
				rejectAction = null;
			}
			if (helpAction != null) {
				helpAction.disconnect(contentPane, JComponent.WHEN_IN_FOCUSED_WINDOW);
				helpAction = null;
			}

			contentPane.removeAll();
			contentPane = null;
		}
		if (bottomPanel != null) {
			bottomPanel.removeAll();
			bottomPanel = null;
		}
		if (buttonsPanel != null) {
			buttonsPanel.removeAll();
			buttonsPanel = null;
		}
		if (mainPanel != null) {
			mainPanel.removeAll();
			mainPanel = null;
		}
		sizeGrip = null;
		
		if (titlePanel != null) {
			if (titleDragAdapter != null)
				titleDragAdapter.uninstall(titlePanel);
			titlePanel = null;
		}
		titleDragAdapter = null;

		if (staticButtonHandler != null) {
			if (cancelButton != null)
				cancelButton.removePropertyChangeListener(staticButtonHandler);
			if (detailsButton != null)
				detailsButton.removePropertyChangeListener(staticButtonHandler);
			if (linkButton != null)
				linkButton.removePropertyChangeListener(staticButtonHandler);
			if (okButton != null)
				okButton.removePropertyChangeListener(staticButtonHandler);
			if (userButton != null)
				userButton.removePropertyChangeListener(staticButtonHandler);
			staticButtonHandler = null;
		}

		if (staticDialogHandler != null) {
			removeComponentListener(staticDialogHandler);
			removePropertyChangeListener(staticDialogHandler);
			removeWindowListener(staticDialogHandler);
			staticDialogHandler = null;
		}

		if (okCancelPanel != null) {
			okCancelPanel.removeAll();
			okCancelPanel = null;
		}

		applyButton = null;
		cancelButton = null;
		detailsButton = null;
		helpButton = null;
		linkButton = null;
		okButton = null;
		userButton = null;

		if (whatsThis != null) {
			MFrame.clearGlassPane(this);
			whatsThis = null;
		}
		
		if (lookAndFeelListener != null) {
			UIManager.removePropertyChangeListener(lookAndFeelListener);
			lookAndFeelListener = null;
		}
	}

	// package

	void setCancelButton(final MButton value) {
		if (cancelButton != null)
			cancelButton.removePropertyChangeListener(staticButtonHandler);

		cancelButton = value;
	}

	void setOKButton(final MButton value) {
		if (okButton != null)
			okButton.removePropertyChangeListener(staticButtonHandler);

		okButton = value;
	}

	// private classes

	private static final class StaticButtonHandler implements PropertyChangeListener {

		// public

		// automatically update mnemonic on button text change
		@Override
		public void propertyChange(final PropertyChangeEvent e) {
			if (!"text".equals(e.getPropertyName()))
				return;

			AbstractButton button = (AbstractButton)e.getSource();
			MDialog dialog = MDialog.of(button);
			if ((dialog != null) && !dialog.isClosed())
				dialog.updateMnemonic(button);
		}

	}

	private static final class StaticDialogHandler extends WindowAdapter
	implements
		ComponentListener,
		PropertyChangeListener
	{

		// public

		@Override
		public void componentHidden(final ComponentEvent e) { }

		@Override
		public void componentMoved(final ComponentEvent e) { }

		@Override
		public void componentResized(final ComponentEvent e) {
			MDialog dialog = (MDialog)e.getSource();
			if (dialog.sizeGrip != null)
				dialog.moveToCorner(dialog.sizeGrip);
		}

		@Override
		public void componentShown(final ComponentEvent e) {
			MDialog dialog = (MDialog)e.getSource();
			dialog.updateMnemonic(false);
		}

		@Override
		public void propertyChange(final PropertyChangeEvent e) {
			MDialog dialog = (MDialog)e.getSource();
			if ((dialog.titleLabel != null) && "title".equals(e.getPropertyName())) {
				dialog.titleLabel.setText(Objects.toString(e.getNewValue(), null));
			}
		}

		@Override
		public void windowActivated(final WindowEvent e) {
			MDialog dialog = (MDialog)e.getSource();
			if (dialog.defaultFocusRef != null) {
				JComponent defaultFocus = dialog.defaultFocusRef.get();
				if (defaultFocus != null)
					MComponent.requestFocus(defaultFocus);
				dialog.defaultFocusRef = TK.dispose(dialog.defaultFocusRef);
			}
		}

		@Override
		public void windowClosing(final WindowEvent e) {
			MDialog dialog = (MDialog)e.getSource();
			dialog.doCancel();
		}

	}

}
