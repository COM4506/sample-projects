// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.border;

import java.awt.Component;
import java.awt.Insets;
import javax.swing.border.AbstractBorder;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

/**
 * @since 3.8.8, 4.0 (org.makagiga.commons.swing.border package)
 */
public abstract class MBorder extends AbstractBorder {

	// private

	private final boolean opaque;
	private final Insets insets;
	
	// public

	@Override
	public Insets getBorderInsets(final Component c) {
		return getBorderInsets(c, insets);
	}

	@Override
	@SuppressFBWarnings("CFS_CONFUSING_FUNCTION_SEMANTICS")
	public Insets getBorderInsets(final Component c, final Insets insets) {
		insets.set(this.insets.top, this.insets.left, this.insets.bottom, this.insets.right);
		
		return insets;
	}

	@Override
	public boolean isBorderOpaque() { return opaque; }
	
	// protected
	
	protected MBorder(final boolean opaque, final Insets insets) {
		this.opaque = opaque;
		this.insets = (Insets)insets.clone();
	}

	protected MBorder(final boolean opaque, final int top, final int left, final int bottom, final int right) {
		this.opaque = opaque;
		this.insets = new Insets(top, left, bottom, right);
	}

}
