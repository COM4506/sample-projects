// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.border;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JViewport;
import javax.swing.text.JTextComponent;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.swing.AbstractSpinner;

/**
 * @since 3.8.7, 4.0 (org.makagiga.commons.swing.border package)
 */
public class MLineBorder extends MBorder implements Iterable<MLineBorder.Style> {

	// public

	public enum Position { TOP, LEFT, BOTTOM, RIGHT }

	// private

	private final List<Style> styleList;
	private final Style bottom;
	private final Style left;
	private final Style right;
	private final Style top;
	
	// public
	
	public MLineBorder() {
		super(false, 0, 0, 0, 0);

		top = new Style(Position.TOP);
		left = new Style(Position.LEFT);
		bottom = new Style(Position.BOTTOM);
		right = new Style(Position.RIGHT);
		styleList = Collections.unmodifiableList(new MArrayList<Style/*ECJ need this*/>(top, left, bottom, right));
	}

	public MLineBorder(final Position... visibleLines) {
		this();

		for (Style i : styleList)
			i.setVisible(false);
		for (Position i : visibleLines)
			getStyle(i).setVisible(true);
	}

	@Override
	@SuppressFBWarnings("CFS_CONFUSING_FUNCTION_SEMANTICS")
	public Insets getBorderInsets(final Component c, final Insets insets) {
		insets.top = top.getInset();
		insets.bottom = bottom.getInset();

		boolean rtl = (c != null) && UI.isRTL(c);
		insets.left = (rtl ? right : left).getInset();
		insets.right = (rtl ? left : right).getInset();

		return insets;
	}

	public Style getStyle(final Position position) {
		switch (position) {
			case TOP: return top;
			case LEFT: return left;
			case BOTTOM: return bottom;
			case RIGHT: return right;
			default: throw new WTFError(position);
		}
	}
	
	/**
	 * @since 4.2
	 */
	public Style getLeft() { return left; }

	/**
	 * @since 4.2
	 */
	public Style getRight() { return right; }

	/**
	 * @since 4.2
	 */
	public Style getTop() { return top; }

	/**
	 * @since 4.2
	 */
	public Style getBottom() { return bottom; }

	@Override
	public void paintBorder(final Component c, final Graphics graphics, final int x, final int y, final int w, final int h) {
		MGraphics2D g = MGraphics2D.copy(graphics);

		if (top.setup(c, g))
			g.drawHLine(x, y + top.getSize() / 2, x + w - 1);

		if (bottom.setup(c, g))
			g.drawHLine(x, y + h - Math.max(1, bottom.getSize() / 2), x + w - 1);

		boolean rtl = (c != null) && UI.isRTL(c);

		// leading

		Style s = rtl ? right : left;
		if (s.setup(c, g)) {
			g.drawVLine(x + s.getSize() / 2, y, y + h - 1);
		}

		// trailing

		s = rtl ? left : right;
		if (s.setup(c, g)) {
			g.drawVLine(x + w - Math.max(1, s.getSize() / 2), y, y + h - 1);
		}
		
		g.dispose();
	}
	
	// Iterable
	
	/**
	 * @since 5.0
	 */
	@Override
	public Iterator<MLineBorder.Style> iterator() {
		return styleList.iterator();
	}
	
	// public

	public static class Style implements Serializable {

		// private

		private boolean visible = true;
		private Color color = Color.BLACK;
		private Color disabledColor;
		private Color focusedColor;
		private int padding;
		private int size = 1;
		private final Position position;

		// public

		public Color getColor() { return color; }

		public void setColor(final Color value) { color = value; }

		/**
		 * @since 5.0
		 */
		public Color getDisabledColor() { return disabledColor; }

		/**
		 * @since 5.0
		 */
		public void setDisabledColor(final Color value) { disabledColor = value; }

		/**
		 * @since 5.0
		 */
		public Color getFocusedColor() { return focusedColor; }

		/**
		 * @since 5.0
		 */
		public void setFocusedColor(final Color value) { focusedColor = value; }

		/**
		 * @since 4.4
		 */
		public int getPadding() { return padding; }

		/**
		 * @since 4.4
		 */
		public void setPadding(final int value) { padding = value; }

		public Position getPosition() { return position; }

		public int getSize() { return size; }

		public void setSize(final int value) { size = value; }

		public boolean isVisible() { return visible; }

		public void setVisible(final boolean value) { visible = value; }

		// protected

		protected Style(final Position position) {
			this.position = position;
		}

		// private

		private int getInset() {
			return visible ? (size + padding) : 0;
		}
		
		private boolean isDisabled(final Component c) {
			if (c == null)
				return false;
		
			if (!c.isEnabled())
				return true;
				
			if ((c instanceof JTextComponent) && !JTextComponent.class.cast(c).isEditable())
				return true;
			
			if (c instanceof JSpinner)
				return isDisabled(AbstractSpinner.getTextField((JSpinner)c));
			
			return false;
		}
		
		private boolean isFocused(final Component c) {
			if (c == null)
				return false;

			if (c.isFocusOwner())
				return true;
			
			if (c instanceof JSpinner)
				return isFocused(AbstractSpinner.getTextField((JSpinner)c));
			
// TODO: common code
			if (c instanceof JScrollPane) {
				JViewport v = JScrollPane.class.cast(c).getViewport();

				if (v != null)
					return isFocused(v.getView());
			}
			
			return false;
		}

		private boolean setup(final Component c, final MGraphics2D g) {
			if (color == null)
				return false;

			if (visible) {
				if ((focusedColor != null) && isFocused(c))
					g.setColor(focusedColor);
				else if ((disabledColor != null) && isDisabled(c))
					g.setColor(disabledColor);
				else
					g.setColor(color);
				g.setLineWidth(size);
			}

			return visible;
		}

	}

}
