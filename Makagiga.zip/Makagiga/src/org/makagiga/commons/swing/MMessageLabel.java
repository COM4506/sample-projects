// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Objects;
import javax.swing.Icon;
import javax.swing.UIManager;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.painters.AbstractPainter;
import org.makagiga.commons.painters.GlassPainter;
import org.makagiga.commons.painters.Painter;

/**
 * @since 4.0 (org.makagiga.commons.swing.MMessageLabel name)
 */
public class MMessageLabel extends MLabel {

	// public
	
	public enum Direction { NONE, TOP, LEFT, BOTTOM, RIGHT }

	// private

	private boolean animationEnabled = true;
	private boolean backgroundPainted = true;
	private transient boolean forceNonOpaque;
	private Direction direction = Direction.NONE;
	private static final FocusListener focusListener = new StaticFocusHandler();
	private MIcon.Size iconSize = MIcon.Size.MEDIUM;
	private Painter painter = new GlassPainter();
	
	// public
	
	public MMessageLabel() {
		this(null, null);
	}

	public MMessageLabel(final Icon icon) {
		this(null, icon);
	}

	public MMessageLabel(final String text) {
		this(text, null);
	}
	
	public MMessageLabel(final String text, final Icon icon) {
		super(text, icon);
		setBorder(UI.createEmptyBorder(5));
		setIconTextGap(5);
	}

	public Color getColor() {
		return getBackground();
	}

	/**
	 * Sets both background and foreground color without animation.
	 *
	 * @since 1.2
	 */
	public void setColor(final Color background, final Color foreground) {
		setColor(background, foreground, false);
	}

	/**
	 * @since 1.2
	 */
	public void setColor(final Color background, final Color foreground, final boolean animation) {
		if (animation)
			ComponentAnimation.blendBackgroundProperty(this, null, (background == null) ? UIManager.getColor("Label.background") : background);
		else
			setBackground(background);
		setForeground(foreground);
	}
	
	public Direction getDirection() { return direction; }
	
	public void setDirection(final Direction value) {
		if (value != direction) {
			direction = value;
			switch (direction) {
				case NONE:
					setIcon(null);
					break;
				case TOP:
					setIcon(ShapeIcon.UP_ARROW);
					break;
				case LEFT:
					setIcon(ShapeIcon.LEFT_ARROW);
					break;
				case BOTTOM:
					setIcon(ShapeIcon.DOWN_ARROW);
					break;
				case RIGHT:
					setIcon(ShapeIcon.RIGHT_ARROW);
					break;
			}
		}
	}

	/**
	 * @since 5.2
	 */
	public MIcon.Size getIconSize() { return iconSize; }

	/**
	 * @since 5.2
	 */
	public void setIconSize(final MIcon.Size value) {
		iconSize = Objects.requireNonNull(value);
	}

	/**
	 * @since 3.8.8
	 */
	public Painter getPainter() { return painter; }
	
	/**
	 * @since 4.0
	 */
	public void setPainter(final Painter value) {
		painter = Objects.requireNonNull(value);
	}

	/**
	 * @since 2.0
	 */
	public GlassPainter.RoundType getRoundType() {
		return AbstractPainter.getRoundType(painter);
	}

	/**
	 * @since 2.0
	 */
	public void setRoundType(final GlassPainter.RoundType value) {
		AbstractPainter.setRoundType(this, painter, value);
	}

	/**
	 * @since 4.2
	 */
	public boolean isAnimationEnabled() { return animationEnabled; }

	/**
	 * @since 4.2
	 */
	public void setAnimationEnabled(final boolean value) { animationEnabled = value; }

	/**
	 * @since 2.0
	 */
	public boolean isBackgroundPainted() { return backgroundPainted; }
	
	/**
	 * @since 2.0
	 */
	public void setBackgroundPainted(final boolean value) {
		if (value != backgroundPainted) {
			backgroundPainted = value;
			repaint();
		}
	}
	
	@Override
	public boolean isOpaque() {
		if (forceNonOpaque)
			return false;

		return
			super.isOpaque() ||
			(
				backgroundPainted &&
				(painter instanceof AbstractPainter) &&
				AbstractPainter.class.cast(painter).isOpaque()
			);
	}
	
	/**
	 * @since 3.0
	 */
	public void setErrorMessage(final String text) {
		setMessage(text, MIcon.stock("ui/error", iconSize), MHighlighter.ERROR_COLOR);
	}

	@Override
	public void setFocusable(final boolean value) {
		super.setFocusable(value);

		if (value) {
			if (TK.indexOf(getFocusListeners(), focusListener) == -1)
				addFocusListener(focusListener);
		}
		else {
			removeFocusListener(focusListener);
		}
	}

	/**
	 * @since 3.0
	 */
	public void setInfoMessage(final String text) {
		setMessage(text, MIcon.stock("ui/info", iconSize), MHighlighter.INFO_COLOR);
	}

	public void setMessage(final String text, final Icon icon, final Color color) {
		setColor(color, Color.BLACK, animationEnabled);
		setIcon(icon);
		setText(text);
		if ((getToolTipText() == null) && !TK.isEmpty(text))
			setToolTipText(text);
	}
	
	/**
	 * @since 3.0
	 */
	public void setOKMessage(final String text) {
		setMessage(text, MIcon.stock("ui/ok", iconSize), MHighlighter.OK_COLOR);
	}

	/**
	 * @since 3.0
	 */
	public void setWarningMessage(final String text) {
		setMessage(text, MIcon.stock("ui/warning", iconSize), MHighlighter.WARNING_COLOR);
	}

	// protected

	@Override
	protected void paintComponent(final Graphics graphics) {
		forceNonOpaque = false;
		Graphics2D g = (Graphics2D)graphics;

		// paint background
		if (backgroundPainted) {
			if (painter instanceof AbstractPainter) {
				AbstractPainter ap = (AbstractPainter)painter;
				ap.setPrimaryColor(getBackground());

				// Temporarily disable background painting in super.paintComponent
				// because it's already provided by painter.
				if (ap.isOpaque())
					forceNonOpaque = true;
			}
			painter.paint(this, g);
		}

		// paint component
		try {
			super.paintComponent(g);
		}
		finally {
			forceNonOpaque = false;
		}

		// paint focus
		if (isFocusOwner())
			UI.paintFocus(this, g, null, 1);
	}

	// private classes

	private static final class StaticFocusHandler implements FocusListener {

		// public

		@Override
		public void focusGained(final FocusEvent e) {
			e.getComponent().repaint();
		}

		@Override
		public void focusLost(final FocusEvent e) {
			e.getComponent().repaint();
		}

	}

}
