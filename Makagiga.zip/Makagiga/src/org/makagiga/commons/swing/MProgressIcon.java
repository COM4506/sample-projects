// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.ImageObserver;
import java.lang.ref.WeakReference;
import java.util.Objects;
import javax.swing.Icon;

/**
 * @since 3.4, 4.0 (org.makagiga.commons.swing package)
 */
public class MProgressIcon implements Icon {

	// private

	private boolean stringPainted = true;
	private Color barForegroundColor = Color.RED;
	private Color textColor = Color.WHITE;
	private float alpha = 0.5f;
	private final Icon impl;
	private int arcAngle;
	private int maximum;
	private int percent;
	private int value;
	private final WeakReference<ImageObserver> observerRef;

	// public
	
	public MProgressIcon(final ImageObserver observer, final Icon impl) {
		if (observer == null)
			throw new IllegalArgumentException("Null observer");

		observerRef = new WeakReference<>(observer);
		this.impl = impl;
	}

	public float getAlpha() { return alpha; }

	public void setAlpha(final float alpha) {
		if (Float.compare(alpha, this.alpha) != 0) {
			this.alpha = alpha;
			repaint();
		}
	}

	public Color getBarForeground() { return barForegroundColor; }

	public void setBarForeground(final Color barForegroundColor) {
		Objects.requireNonNull(barForegroundColor, "barForegroundColor");

		if (!barForegroundColor.equals(this.barForegroundColor)) {
			this.barForegroundColor = barForegroundColor;
			repaint();
		}
	}

	public int getMaximum() { return maximum; }

	public void setMaximum(final int maximum) {
		if (maximum != this.maximum) {
			this.maximum = maximum;
			if (recalc())
				repaint();
		}
	}

	public Color getTextColor() { return textColor; }

	public void setTextColor(final Color textColor) {
		Objects.requireNonNull(textColor, "textColor");

		if (!textColor.equals(this.textColor)) {
			this.textColor = textColor;
			repaint();
		}
	}

	public int getValue() { return value; }

	public void setValue(final int value) {
		int newValue = Math.min(maximum, value);
		if (newValue != this.value) {
			this.value = newValue;
			if (recalc())
				repaint();
		}
	}

	public boolean isStringPainted() { return stringPainted; }

	public void setStringPainted(final boolean stringPainted) {
		if (stringPainted != this.stringPainted) {
			this.stringPainted = stringPainted;
			repaint();
		}
	}

	// Icon

	@Override
	public int getIconWidth() {
		return (impl == null) ? 32 : impl.getIconWidth();
	}

	@Override
	public int getIconHeight() {
		return (impl == null) ? 32 : impl.getIconHeight();
	}

	@Override
	public void paintIcon(final Component c, final Graphics graphics, final int x, final int y) {
		if (impl != null)
			impl.paintIcon(c, graphics, x, y);

		Graphics2D g = (Graphics2D)graphics.create();
		g.setComposite(AlphaComposite.SrcOver.derive(alpha));
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		int w = getIconWidth();
		int h = getIconHeight();
		g.setColor(barForegroundColor);
		g.fillArc(x, y, w, h, -270, arcAngle);

		if (stringPainted) {
			g.setColor(textColor);
			g.setFont(new Font(Font.DIALOG, Font.BOLD, Math.max(12, h / 4)));
			FontMetrics fm = g.getFontMetrics();
			String text = percent + "%";
			g.drawString(
				text,
				x + w / 2 - fm.stringWidth(text) / 2,
				y + h / 2 - fm.getHeight() / 2 + fm.getAscent()
			);
		}

		g.dispose();
	}

	// private

	private boolean recalc() {
		int newPercent = (int)(SimpleProgressBar.calcProgress(value, 0, maximum) * 100f);
		int newArcAngle = -(int)((float)newPercent * 3.6f);
		if ((newArcAngle != arcAngle) || (newPercent != percent)) {
			arcAngle = newArcAngle;
			percent = newPercent;

			return true; // repaint
		}

		return false; // skip repaint
	}

	private void repaint() {
		ImageObserver observer = observerRef.get();
		if (observer instanceof Component) {
			Component.class.cast(observer).repaint();
		}
/*
		else if ((observer != null) && (impl instanceof ImageIcon)) {
			Image i = ImageIcon.class.cast(impl).getImage();
			if (i != null) {
				observer.imageUpdate(i, ImageObserver.ALLBITS, 0, 0, getIconWidth(), getIconHeight());
			}
		}
*/
	}

}
