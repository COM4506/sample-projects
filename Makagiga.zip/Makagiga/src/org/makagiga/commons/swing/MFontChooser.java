// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Font;
import java.awt.Window;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.HashSet;
import javax.swing.JComponent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionListener;

import org.makagiga.commons.ClipboardException;
import org.makagiga.commons.Config;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MClipboard;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.StringList;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.mv.FontRenderer;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.request.RequestSource;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.layer.ListActionsLayerUI;
import org.makagiga.commons.validator.ListSelectionValidator;
import org.makagiga.commons.validator.ValidatorSupport;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 * 
 * @see Input
 */
public class MFontChooser extends MPanel implements ValueChooser<Font> {
	
	// private

	private boolean inUpdatePreview;
	private Font lastFont;
// TODO: #hashtags
	private final HashSet<String> starredSet = new HashSet<>();
	private JComponent preview;
	private MAction toggleStarAction;
	private final MList<Integer> fontSize;
	private final MList<Integer> fontStyle;
	private final MList<String> fontName;
	private final MNumberSpinner<Integer> fontSizeSpinner;
	private MSearchPanel filter;
	private static String filterText;
	private final StringList allFontNames;
	
	// public
	
	public MFontChooser(final Font defaultFont, final JComponent userPreview) {
		super(10, 10);
		allFontNames = new StringList(UI.getAllFontNames());
	
		Config config = MAccessController.doPrivileged(Config::getDefault);
		String starredConfig = config.read("FontChooser.starred", "");
		starredSet.addAll(TK.fastSplit(starredConfig, ','));
		
		fontName = new MList<>();
		fontName.addActionListener(e -> {
			if (fontName.getActionType() == MList.ActionType.ITEM_POPUP_MENU)
				showFontNameMenu();
		} );

		RequestSource<Font> requestSource = (info, font) -> {
			if (font != null)
				fontName.repaintItem(font.getName());
		};
		FontRenderer renderer = new FontRenderer(requestSource) {
			@Override
			protected void onRender(final String value) {
				super.onRender(value);
				if (MFontChooser.this.starredSet.contains(value))
					this.setIcon(MActionInfo.SHOW_STARRED.getSmallIcon());
				else
					this.setIcon(null);
			}
		};
		
		// renderer optimization
		fontName.setCellRenderer(renderer);
		fontName.setFixedCellHeight(renderer.getFont().getSize() + 8);
		fontName.setFixedCellWidth(200);
		
		fontName.setSingleSelectionMode();
		
		fontStyle = new MList<>();
		fontStyle.setCellRenderer(new MRenderer<Integer>(5) {
			private final HashMap<Integer, Font> cache = new HashMap<>();
			@Override
			protected void onRender(final Integer style) {
				Font f = this.cache.get(style);
				if (f == null) {
					f = UI.deriveFontStyle(this.getFont(), style);
					this.cache.put(style, f);
				}
				this.setFont(f);
				
				switch (style) {
					case Font.PLAIN:
						this.setText(i18n("Normal"));
						break;
					case Font.ITALIC:
						this.setText(i18n("Italic"));
						break;
					case Font.BOLD:
						this.setText(i18n("Bold"));
						break;
					case Font.BOLD + Font.ITALIC:
						this.setText(i18n("Bold") + " + " + i18n("Italic"));
						break;
					default:
						this.setText("?");
				}
			}
		} );
		fontStyle.setSingleSelectionMode();
		fontStyle.addItem(Font.PLAIN);
		fontStyle.addItem(Font.ITALIC);
		fontStyle.addItem(Font.BOLD);
		fontStyle.addItem(Font.BOLD + Font.ITALIC);

		// based on the OpenOffice.org Writer
		final int[] FONT_SIZES = {
			6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			18, 20, 22, 24, 26, 28,
			32, 36, 40, 44, 48,
			54, 60, 66, 72,
			80, 88, 96,
			106, 116,
			128
		};

		fontSizeSpinner = new MNumberSpinner<>();
		fontSizeSpinner.setRange(FONT_SIZES[0], /*FONT_SIZES[FONT_SIZES.length - 1]*/999);

		fontSize = new MList<>();
		fontSize.setCellRenderer(new MRenderer<Integer>() {
			private final HashMap<Integer, Font> cache = new HashMap<>();
			@Override
			protected void onRender(final Integer size) {
				Font f = this.cache.get(size);
				
				int maxSize = 72;
				int minSize = 10;
				
				if (f == null) {
					// limit min/max font size
					int fontSize = TK.limit(size, minSize, maxSize);
					f = UI.deriveFontSize(this.getFont(), fontSize);
					this.cache.put(size, f);
				}
				this.setFont(f);

				String suffix;
				if (size > maxSize)
					suffix = "+";
				else if (size < minSize)
					suffix = "-";
				else
					suffix = "";
				this.setText(size + suffix);
			}
		} );
		fontSize.setSingleSelectionMode();
		fontSize.setToolTipText(i18n("Size"));
		
		for (int i : FONT_SIZES)
			fontSize.addItem(i);

		MPanel p = MPanel.createHBoxPanel();
		p.add(createFontNamePanel());
		p.addContentGap();
		p.add(MPanel.createVLabelPanel(fontStyle, i18n("Font Style:")));
		p.addContentGap();

		MPanel fontSizePanel = MPanel.createBorderPanel(5);
		fontSizePanel.addNorth(new MSpinnerPanel(fontSizeSpinner, i18n("Size:")));
		fontSizePanel.addCenter(fontSize);
		p.add(fontSizePanel);

		addCenter(p);
		
		if (userPreview == null) {
// TODO: color preview
			MTextPreviewPanel textPreview = new MTextPreviewPanel();
			textPreview.setTextEditable(true);
			preview = textPreview;
		}
		else {
			preview = userPreview;
		}
		addSouth(preview);
		
		updateFontList();
		setValue(defaultFont);
		
		ListSelectionListener selectionListener = e -> {
			if (!inUpdatePreview && !e.getValueIsAdjusting()) {
				try {
					inUpdatePreview = true;
					Integer size = fontSize.getSelectedItem();
					if (size != null)
						fontSizeSpinner.setNumber(size);
				}
				finally {
					inUpdatePreview = false;
				}
				updatePreview();
			}
		};
		fontName.addListSelectionListener(selectionListener);
		fontStyle.addListSelectionListener(selectionListener);
		fontSize.addListSelectionListener(selectionListener);

		ChangeListener changeListener = e -> {
			if (!inUpdatePreview) {
				try {
					inUpdatePreview = true;
					Integer size = fontSizeSpinner.getNumber();
					if (fontSize.getDefaultModel().contains(size))
						fontSize.setSelectedItem(size, true);
					else
						fontSize.clearSelection();
				}
				finally {
					inUpdatePreview = false;
				}
				updatePreview();
			}
		};
		fontSizeSpinner.addChangeListener(changeListener);
	}
	
	// ValueChooser

	/**
	 * @since 3.8.12
	 */
	@Override
	public void addValueListener(final ValueListener<Font> l) {
		listenerList.add(ValueListener.class, l);
	}

	/**
	 * @since 3.8.12
	 */
	@Override
	public void removeValueListener(final ValueListener<Font> l) {
		listenerList.remove(ValueListener.class, l);
	}

	/**
	 * @since 3.8.12
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ValueListener<Font>[] getValueListeners() {
		return listenerList.getListeners(ValueListener.class);
	}

	/**
	 * @since 3.8.12
	 */
	@Override
	public Font getValue() {
		String name = fontName.getSelectedItem();
		Integer style = fontStyle.getSelectedItem();
		Integer size = fontSizeSpinner.getNumber();
		
		if ((name == null) || (style == null) || (size == null))
			return null;
		
		lastFont = new Font(name, style, size);
		
		return lastFont;
	}

	/**
	 * @since 3.8.12
	 */
	@Override
	public void setValue(final Font value) {
		Font font = (value == null) ? getFont() : value;
		fontName.setSelectedItem(font.getName(), true);

		// clear filter and try to select again
		if (fontName.isSelectionEmpty() && !TK.isEmpty(filterText)) {
			filter.setText(null);
			fontName.setSelectedItem(font.getName(), true);
		}

		fontStyle.setSelectedItem(font.getStyle(), true);

		int size = font.getSize();
		try {
			inUpdatePreview = true;
			fontSize.setSelectedItem(size, true);
			fontSizeSpinner.setNumber(size);
			updatePreview();
		}
		finally {
			inUpdatePreview = false;
		}
	}

	// protected
	
	protected void updatePreview() {
		if (lastFont != null) {
			try {
				inUpdatePreview = true;
				if (fontName.isSelectionEmpty())
					fontName.setSelectedItem(lastFont.getName());
				if (fontStyle.isSelectionEmpty())
					fontStyle.setSelectedItem(lastFont.getStyle());
				if (fontSize.isSelectionEmpty())
					fontSize.setSelectedItem(lastFont.getSize());
			}
			finally {
				inUpdatePreview = false;
			}
		}
		
		Font font = getValue();
		if (font != null) {
			if (preview instanceof MTextPreviewPanel)
				MTextPreviewPanel.class.cast(preview).setTextFont(font);
			else
				preview.setFont(font);

			// ensure the selected name is still visible
			int i = fontName.getSelectedIndex();
			if (i != -1)
				fontName.ensureIndexIsVisible(i);
		}
	}
	
	// private
	
	private MPanel createFontNamePanel() {
		toggleStarAction = new MAction(
			action -> {
				int index = action.getValue(ListActionsLayerUI.INDEX_PROPERTY, -1);
				String selectedFontName =
					(index == -1)
					? fontName.getSelectedItem()
					: fontName.getItemAt(index);
				
				if (starredSet.contains(selectedFontName))
					starredSet.remove(selectedFontName);
				else
					starredSet.add(selectedFontName);
				updateActions(selectedFontName);

				String starredString = String.join(",", starredSet);
				MAccessController.doPrivileged(() -> {
					Config config = Config.getDefault();
					config.write("FontChooser.starred", starredString);
					config.sync();
						
					return null;
				} );
				
				fontName.repaintItem(selectedFontName);
			}
		);

		ListActionsLayerUI listActions = new ListActionsLayerUI(MAction.SMALL_ICON) {
			@Override
			protected void currentIndexChanged(final MouseEvent e) {
				int index = this.getCurrentIndex();
				String name = MFontChooser.this.fontName.getItemAt(index);
				MFontChooser.this.updateActions(name);
			}
		};
		listActions.addAction(toggleStarAction);

		MPanel p = MPanel.createVLabelPanel(listActions.wrap(fontName), i18n("Font:"));
		
		if (TK.isEmpty(filterText))
			filterText = null;
		filter = new MSearchPanel();
		filter.setText(filterText);
		filter.onChange(e -> {
			filterText = filter.getText();
			updateFontList();
		} );
		filter.setAutoCompletion("font-name-filter");
		filter.setChangeEventDelay(0);
		filter.setList(fontName);
		
		MSmallButton menuButton = filter.getMenuButton();
		menuButton.setIcon(MIcon.small("ui/filter"));
		menuButton.setPopupMenuEnabled(true);
		menuButton.setToolTipText(i18n("Bookmarks"));
		menuButton.setVisible(true);

		ActionGroup actionGroup = new ActionGroup();

		actionGroup.add("starred", new MAction(MActionInfo.SHOW_STARRED,
			action -> filter.setText("*")
		));

		actionGroup.installPopupMenu(menuButton);

		p.addSouth(filter);
		
		return p;
	}

	private void showFontNameMenu() {
		String selectedFontName = fontName.getSelectedItem();
		
		if (selectedFontName == null)
			return;
		
		MMenu menu = new MMenu();

		updateActions(selectedFontName);

		menu.add(new MAction(i18n("Copy Name"), "ui/copy", action -> {
			try {
				String name = fontName.getSelectedItem();
				if (name != null)
					MClipboard.setString(name);
			}
			catch (ClipboardException exception) {
				action.showErrorMessage(exception);
			}
		} ));

		menu.add(toggleStarAction);
		
		menu.showPopup(fontName.getActionEvent());
	}
	
	private void updateActions(final String selectedFontName) {
		boolean isStar = starredSet.contains(selectedFontName);

		toggleStarAction.setEnabled(Kiosk.actionBookmark.get());
		toggleStarAction.setName((isStar ? MActionInfo.REMOVE_STAR : MActionInfo.ADD_STAR).getText());
		toggleStarAction.setSmallIcon(isStar ? "ui/remove" : "ui/add");
	}
	
	private void updateFontList() {
		fontName.filter(filter, allFontNames, (item, filterText) -> {
			return
				("*".equals(filterText) && starredSet.contains(item)) ||
				TK.containsIgnoreCase(item, filterText);
		} );
	}
	
	// package

	static Font getFont(final Window parent, final Font defaultFont, final JComponent userPreview) {
		MDialog dialog = new MDialog(
			parent,
			MActionInfo.CHOOSE_FONT,
			MDialog.STANDARD_DIALOG | MDialog.COMPACT_HEADER
		);
		MFontChooser chooser = UI.lengthyOperation(parent, () -> new MFontChooser(defaultFont, userPreview));

		ValidatorSupport vs = dialog.getValidatorSupport();
		vs.add(new ListSelectionValidator(chooser.fontName));
		vs.add(new ListSelectionValidator(chooser.fontStyle));
		
		dialog.addCenter(chooser);
		dialog.setSize(UI.WindowSize.MEDIUM);
		
		if (dialog.exec()) {
			chooser.filter.saveAutoCompletion();
		
/* TODO: remember last preview text
			if (chooser.preview instanceof JTextComponent)
				previewText = JTextComponent.class.cast(chooser.preview).getText();
*/

			return chooser.getValue();
		}
		
		return null;
	}

}
