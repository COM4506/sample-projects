// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.Objects;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MColor;
import org.makagiga.commons.UI;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.swing.event.PopupAdapter;

/**
 * A table header.
 *
 * @mg.example
 * <pre class="brush: java">
 * class Table extends JTable {
 * ...
 * {@literal @}Override
 * protected JTableHeader createDefaultTableHeader() {
 *   return new MTableHeader(getColumnModel());
 * }
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTableHeader extends JTableHeader {
	
	// private
	
	private PrintTableCellRenderer printTableCellRenderer;
	
	// public
	
	/**
	 * Constructs a table header.
	 *
	 * @param model the table column model
	 */
	public MTableHeader(final TableColumnModel model) {
		super(model);
		setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		PopupAdapter handler = new PopupAdapter(e -> {
			if (!Kiosk.actionSettings.get())
				return;

			if (getTable() instanceof MTable<?>) {
				MTable.class.cast(getTable())
					.getColumnManager()
					.createMenu()
					.showPopup(e);
			}
		} );
		handler.install(this);
	}

	@Override
	public TableCellRenderer getDefaultRenderer() {
		if (isPaintingForPrint()) {
			if (printTableCellRenderer == null)
				printTableCellRenderer = new PrintTableCellRenderer();

			return printTableCellRenderer;
		}

		return super.getDefaultRenderer();
	}

	@Override
	public Point getToolTipLocation(final MouseEvent e) {
		Point p = UI.ToolTipLocationPolicy.ABOVE.getLocation(this, e);
		p.x = e.getX();
		
		return p;
	}

	/**
	 * Returns the tool tip text for the hovered table column, or {@code null}.
	 *
	 * @param e the mouse event
	 */
	@Override
	public String getToolTipText(final MouseEvent e) {
		int index = columnAtPoint(e.getPoint());
		if (index != -1) {
			TableColumn column = columnModel.getColumn(index);
			if (column != null)
				return Objects.toString(column.getHeaderValue(), null);
		}

		return null;
	}

	// protected

	@Override
	protected void initializeLocalVars() {
		super.initializeLocalVars();
		reorderingAllowed = Kiosk.tableColumnReorderingAllowed.booleanValue();
		resizingAllowed = Kiosk.tableColumnReorderingAllowed.booleanValue();
	}
	
	// private classes

	private static final class PrintTableCellRenderer extends MRenderer<Object> {

		// protected

		@Override
		protected void onRender(final Object value) {
			MLabel l = getLabel();
			l.setBackground(MColor.WHITE);
			l.setForeground(MColor.BLACK);
			l.setOpaque(true);
			l.setStyle("font-weight: bold");
			l.setText(Objects.toString(value, null));
		}

		// private

		private PrintTableCellRenderer() { }

	}

}
