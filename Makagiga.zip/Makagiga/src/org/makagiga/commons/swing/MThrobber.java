// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.beans.Beans;
import javax.swing.Icon;

import org.makagiga.commons.MIcon;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 *
 * @see org.makagiga.commons.MIcon#getThrobber()
 */
public class MThrobber extends MLabel {
	
	// private
	
	private boolean active;
	private boolean userAnimation;
	private Icon _animationIcon;
	
	// public
	
	public MThrobber() {
		if (Beans.isDesignTime())
			setIcon(MIcon.getThrobber().getGrayscaleInstance());
		
		setHorizontalAlignment(CENTER);
		setVerticalAlignment(CENTER);
	}
	
	/**
	 * @since 2.0
	 */
	public Icon getAnimationIcon() {
		// init on demand
		if (!userAnimation && (_animationIcon == null))
			_animationIcon = MIcon.getThrobber();
		
		return _animationIcon;
	}

	/**
	 * @since 2.0
	 */
	public void setAnimationIcon(final Icon value) {
		userAnimation = true;
		_animationIcon = value;
	}

	/**
	 * @since 2.0
	 */
	public boolean isActive() { return active; }

	/**
	 * @since 2.0
	 */
	public void setActive(final boolean value) {
		if (value != active) {
			active = value;
			if (active) {
				setIcon(getAnimationIcon());
			}
			else {
				if (Beans.isDesignTime())
					setIcon(MIcon.getThrobber().getGrayscaleInstance());
				else
					setIcon(null);
			}
		}
	}

}
