// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Point;
import java.awt.SecondaryLoop;
import java.awt.Toolkit;
import java.awt.Window;
import java.io.IOException;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import javax.swing.JComponent;
import javax.swing.SwingWorker;

import org.makagiga.commons.FS;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MFormat;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.Net;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.cache.FileCache;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MDownloadDialog extends MDialog implements FS.ProgressListener {
	
	// private

	private boolean cancelled;
	private boolean toSet;
	private IOException error;
	private long lastProgressUpdate = System.currentTimeMillis();
	private long startTime;
	private final MLabel descriptionLabel;
	private final MPanel filePanel;
	private final MProgressBar progressBar;
	private final MTextLabel toTextLabel;
	private final Net.DownloadInfo info;
	private volatile SecondaryLoop secondaryLoop;
	private volatile transient SwingWorker<Object, Object> worker;
	
	// public

	/**
	 * @since 3.4
	 */
	public MDownloadDialog(final Window owner, final Net.DownloadInfo info) throws IOException {
		super(
			info.isModal() ? owner : null,
			i18n("Downloading...") + " - " + MApplication.getFullName(),
			"ui/download",
			CANCEL_BUTTON | (info.isModal() ? MODAL : (FORCE_STANDARD_BORDER | LOCATION_BY_PLATFORM))
		);
		setAutoRequestFocus(info.isAutoRequestFocus());
		
		if (!info.isModal())
			setIconImage(MIcon.getImage("ui/download"));
		
		this.info = info;

		filePanel = MPanel.createVBoxPanel();

		descriptionLabel = new MLabel();
		descriptionLabel.setStyle("margin-bottom: 5");
		setDescription(info.getDescription());
		filePanel.add(descriptionLabel);
		
		String from = info.getURL().toString();
		MTextLabel fromTextLabel = new MTextLabel(from);
		fromTextLabel.setToolTipText(from);
		filePanel.add(MPanel.createHLabelPanel(fromTextLabel, i18n("From:")));
		
		filePanel.addGap();
		
		toTextLabel = new MTextLabel(i18n("<unknown>"));
		filePanel.add(MPanel.createHLabelPanel(toTextLabel, i18n("To:")));

		addNorth(filePanel);

		progressBar = new MProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setString("");
		progressBar.setStringPainted(true);
		addCenter(progressBar);
		
		worker = new SwingWorker<Object, Object>() {
			@Override
			public Object doInBackground() throws Exception {
				MDownloadDialog self = MDownloadDialog.this;
				try {
/* TEST:
					if (true) {
						TK.sleep(15000);
				
						throw new IOException("Test Fail");
					}
*/
					self.info.setProgressListener(self);
					self.info.startDownload();

					return null;
				}
				finally {
					if (self.secondaryLoop != null)
						self.secondaryLoop.exit();
				}
			}
			@Override
			protected void done() {
				MDownloadDialog self = MDownloadDialog.this;
				self.worker = null;
				
				if (this.isCancelled()) {
					self.cancelled = true;
					self.info.cancelDownload();
					self.reject();
				}
				else {
					try {
						this.get();
						self.accept();
					}
					catch (ExecutionException | InterruptedException exception) {
						if (exception.getCause() instanceof IOException)
							self.error = (IOException)exception.getCause();
						else
							MMessage.error(self, exception);

						FileCache.getDownloadGroup().remove(self.info.getURL());
						self.reject();
					}
					finally {
						if (!self.info.isModal()) {
							try {
								self.finishDownload();
	
								long totalTime = System.currentTimeMillis() - self.startTime;
								if (TimeUnit.MILLISECONDS.toSeconds(totalTime) > 15) {
									String text = self.info.getDescription();
									if (!text.isEmpty())
										text += " - ";
									text += self.info.getURL().toString();
									MNotification.Message message = new MNotification.Message(
										i18n("Download Finished"),
										text,
										"ui/download"
									);
									message.setTimeout(-1);
									message.show();
								}
							}
							catch (IOException exception) {
								MMessage.error(self, exception);
							}
						}
					}
				}
			}
		};
	}

	/**
	 * @since 3.4
	 */
	public static void download(final Window owner, final Net.DownloadInfo info) throws IOException {
		MDownloadDialog dialog = new MDownloadDialog(owner, info);
		// show centered
		if (info.isAutoRequestFocus()) {
			dialog.packFixed();
		}
		// move to the edge of the screen
		else {
			dialog.setSize(dialog.getPreferredSize());
			dialog.setDefaultLocation(new Point(
				UI.getScreenSize().width - dialog.getWidth() - UI.getScreenInsets().right,
				dialog.getHeight()
			));
		}
		
		dialog.exec();

		if (info.isModal()) {
			dialog.finishDownload();
		}
		else {
			dialog.secondaryLoop = Toolkit.getDefaultToolkit()
				.getSystemEventQueue()
				.createSecondaryLoop();
			dialog.secondaryLoop.enter(); // wait for worker to finish
		}
	}

	@Override
	public boolean exec(final JComponent defaultFocus) {
		filePanel.alignLabels();
	
		if (worker != null) {
			startTime = System.currentTimeMillis();
			worker.execute();
		}

		return super.exec(defaultFocus);
	}
	
	public void setDescription(final String value) {
		descriptionLabel.setText(value);
		descriptionLabel.setVisible(!TK.isEmpty(value));
	}

	// FS.ProgressListener
	
	@Override
	public boolean updateProgress(final long complete, final long length) {
		long now = System.currentTimeMillis();

		if ((now - lastProgressUpdate) < 1000)
			return true; // reduce the number of repaints/updates
		
		lastProgressUpdate = now;

		UI.invokeLater(
			() -> {
				String progressText;
				if (length == -1) { // unknown size
					progressBar.setIndeterminate(true);
					progressText = i18n("Downloading...");
				}
				else if (complete > length) { // packed stream (or bug ;)
					progressBar.setIndeterminate(true);
					progressText = i18n("Unpacking...");
					progressBar.setString(progressText);
				}
				else {
					long elapsedSec = (System.currentTimeMillis() - startTime) / 1000;
					String elapsed;
					if (elapsedSec > 0)
						elapsed = MFormat.toAutoSize(complete / elapsedSec);
					else
						elapsed = MFormat.toAutoSize(-1);
				
					progressBar.setIndeterminate(false);
					progressBar.setMaximum((int)length);
					progressBar.setValue((int)complete);
					progressText =
						MFormat.toAutoSize(complete) + " / " + MFormat.toAutoSize(length) +
						" (" + elapsed + "/s) - " +
						i18n("Downloading...");
					progressBar.setString(progressText);
				}
				setTitle(progressText + " - " + MApplication.getFullName());
				
				if (!toSet) {
					toSet = true;
					String to;
					if (info.getDestinationFile() == null)
						to = info.getFile().getPath();
					else
						to = info.getDestinationFile().getPath();
					toTextLabel.setText(to);
					toTextLabel.setToolTipText(to);
				}
			}
		);
		
		return true;
	}

	// protected
	
	@Override
	protected void onClose() {
		disposeWorker();
	}
	
	@Override
	protected boolean onReject() {
		disposeWorker();
		
		return true;
	}
	
	// private
	
	private void disposeWorker() {
		if (worker != null) {
			worker.cancel(true);
			worker = null;
		}
	}
	
	private void finishDownload() throws IOException {
		if (error != null)
			throw error;

		if (cancelled)
			throw new CancellationException(i18n("Download cancelled"));

		if (info.getFile() == null)
			throw new IOException(i18n("Download failed"));
	}
	
}
