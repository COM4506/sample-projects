// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.InputMethodListener;
import java.awt.event.KeyListener;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.crypto.CryptoUtils;
import org.makagiga.commons.security.MPermission;
import org.makagiga.commons.style.StyleSupport;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MPasswordField extends JPasswordField
implements
	MText.TextFieldExtensions,
	StyleSupport
{
	
	// public

	/**
	 * @since 5.2
	 */
	public static final char NONE_ECHO_CHAR = '\u0000';

	public enum Status {

		// public

		EMPTY(i18n("Password is empty")),
		NOT_ASCII(i18n("Password contains invalid characters")),
		NOT_EQUAL(i18n("Confirmation password is different")),
		OK(i18n("OK")),
		TOO_SHORT(i18n("Password is too short"));

		// private

		private final String text;

		// public

		@Override
		public String toString() { return text; }

		// private

		private Status(final String text) {
			this.text = text;
		}

	}
	
	// private

	private int minimumPasswordLength;
	private static MNotification.Message capsLockMessage;
	private WeakReference<MPasswordField> confirmationRef;
	
	// public
	
	public MPasswordField() {
		minimumPasswordLength = MLogger.isDeveloper() ? 3 : 12;
		MText.commonSetup(this);

		UI.onKeyReleased/*Pressed*/(this, e -> {
			if (e.getKeyCode() == VK_CAPS_LOCK)
				showCapsLockWarning();
		} );
		
		showCapsLockWarning();
	}

	@Override
	public void addInputMethodListener(final InputMethodListener l) {
		checkPermission("accessPassword");

		super.addInputMethodListener(l);
	}

	@InvokedFromConstructor
	@Override
	public void addKeyListener(final KeyListener l) {
		checkPermission("accessPassword");

		super.addKeyListener(l);
	}

	/**
	 * @since 4.0
	 */
	public static boolean equalPassword(final JPasswordField field1, final JPasswordField field2) {
		char[] p1 = field1.getPassword();
		char[] p2 = field2.getPassword();
		boolean equal = Arrays.equals(p1, p2);
		CryptoUtils.clear(p1);
		CryptoUtils.clear(p2);
		
		return equal;
	}

	/**
	 * @since 4.0
	 */
	public MPasswordField getConfirmation() {
		checkPermission("accessPassword");

		return TK.get(confirmationRef);
	}

	/**
	 * @since 4.0
	 */
	public void setConfirmation(final MPasswordField value) {
		checkPermission("accessPassword");

		if (confirmationRef != null)
			confirmationRef.clear(); // clear old
		confirmationRef = new WeakReference<>(value);
	}

	@Override
	public Document getDocument() {
		checkPermission("accessPassword");

		return super.getDocument();
	}

	@Override
	public void setDocument(final Document doc) {
		checkPermission("accessPassword");

		super.setDocument(doc);
	}

	@Override
	public void setEchoChar(final char c) {
		if (c == NONE_ECHO_CHAR)
			checkPermission("accessPassword");

		super.setEchoChar(c);
	}

	/**
	 * Overriden to limit component height to its preferred size.
	 */
	@Override
	public Dimension getMaximumSize() {
		return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
	}

	/**
	 * @since 2.4
	 */
	public int getMinimumPasswordLength() {
		checkPermission("accessPassword");

		return minimumPasswordLength;
	}

	/**
	 * @since 2.4
	 */
	public void setMinimumPasswordLength(final int value) {
		if (value < 0)
			throw new IllegalArgumentException("Minimum password length must be greater than zero");
		
		minimumPasswordLength = value;
	}

	@Override
	public char[] getPassword() {
		checkPermission("accessPassword");

		return super.getPassword();
	}

	public Status getPasswordStatus() {
		checkPermission("accessPassword");

		char[] password = getPassword();
		Status status;

		if (password.length == 0) {
			status = Status.EMPTY;
		}
		else if (!isASCII(password)) {
			status = Status.NOT_ASCII;
		}
		else if (password.length < minimumPasswordLength) {
			status = Status.TOO_SHORT;
		}
		else if ((getConfirmation() != null) && !equalPassword(this, getConfirmation())) {
			status = Status.NOT_EQUAL;
		}
		else {
			status = Status.OK;
		}

		CryptoUtils.clear(password);

		return status;
	}

	@Deprecated
	@Override
	public String getText() {
		checkPermission("accessPassword");

		return super.getText();
	}

	@Override
	public void setText(final String value) {
		checkPermission("accessPassword");

		super.setText(value);
	}

	@Deprecated
	@Override
	public String getText(final int offset, final int len) throws BadLocationException {
		checkPermission("accessPassword");

		return super.getText(offset, len);
	}

	/**
	 * @since 5.6
	 */
	public static boolean isCapsLock() {
		try {
			return Toolkit.getDefaultToolkit()
				.getLockingKeyState(VK_CAPS_LOCK);
		}
		catch (UnsupportedOperationException exception) {
			MLogger.developerException(exception);

			return false;
		}
	}

	// common extensions
	
	@Override
	public void clear() {
		checkPermission("accessPassword");

		char[] password = getPassword();
		int len = password.length;
		CryptoUtils.clear(password);
		// overwrite old password data array
		setText(TK.filler(' ', len));
		setText(null);
	}

	/**
	 * Returns @c true if password is @c null or empty.
	 */
	@Override
	public boolean isEmpty() {
		char[] password = getPassword();
		
		boolean empty = TK.isEmpty(password);
		CryptoUtils.clear(password);
		
		return empty;
	}
	
	@Override
	public void makeDefault() {
		MText.makeDefault(this);
	}

	// text completion
	
	/**
	 * Always returns {@code null}.
	 */
	@Override
	public String getAutoCompletion() { return null; }

	/**
	 * Always does nothing.
	 */
	@Override
	public void saveAutoCompletion() { }
	
	/**
	 * Does nothing if {@code id} is {@code null} or empty.
	 *
	 * @throws IllegalArgumentException Otherwise
	 */
	@Override
	public void setAutoCompletion(final String id) {
		if (!TK.isEmpty(id))
			MText.installAutoCompletion(this, id);
	}

	// StyleSupport
	
	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}
	
	// private

	private void checkPermission(final String name) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			String componentName = null;
			
			JLabel label = MLabel.getLabel(this);
			if (label != null)
				componentName = label.getText();

			if (TK.isEmpty(componentName))
				componentName = getToolTipText();

			if (TK.isEmpty(componentName))
				componentName = i18n("Unknown");

			sm.checkPermission(new MPasswordField.Permission(name, componentName));
		}
	}

	private static boolean isASCII(final char[] password) {
		for (char i : password) {
			if (i > 127)
				return false;
		}

		return true;
	}

	private synchronized static void showCapsLockWarning() {
		if (isCapsLock()) {
			if (capsLockMessage == null) {
				String title = UI.toString(VK_CAPS_LOCK, 0);
				String text = i18n("{0} key is turned on", "<" + title + ">");
				capsLockMessage = new MNotification.Message(title, text, "ui/warning") {
					@Override
					protected void onClose() {
						synchronized (MPasswordField.class) {
							MPasswordField.capsLockMessage = null;
						}
					}
				};
				capsLockMessage.setTimeout(MNotification.getDefaultTimeout());
				capsLockMessage.show();
			}
		}
		else {
			if (!MNotification.isEmpty() && (capsLockMessage != null)) {
				capsLockMessage.hide();
				capsLockMessage = null;
			}
		}
	}

	// public

	/**
	 * @since 3.8.10
	 */
	public static final class Permission extends MPermission {

		// public

		@Override
		public String getIconName() { return "ui/password"; }

		// private

		private Permission(final String name, final String componentName) {
			super(name, ThreatLevel.HIGH, "Password Field: " + componentName);
		}

	}

}
