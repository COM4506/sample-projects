// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import javax.swing.Icon;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.Config;
import org.makagiga.commons.FS;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MDate;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Net;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.painters.GradientPainter;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.commons.xml.SimpleXMLReader;

/**
 * @mg.example
 * <pre class="brush: java">
 * MTip tip = new MTip("context name");
 * tip.showNextTip();
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTip extends MMessageLabel {

	// public
	
	/**
	 * @since 4.2
	 */
	public static final String NO_CONTEXT = "no-context";
	
	/**
	 * @since 1.2
	 */
	public enum Visible { ALWAYS, OFTEN, SELDOM }
	
	// private

	private static Database database;
	private Direction oldDirection;
	private String context;
	private TipInfo currentTip;
	private Visible visible;
	
	// public
	
	/**
	 * Constructs a tip with {@link #NO_CONTEXT} and {@code null} suffix.
	 * 
	 * @param direction the arrow direction
	 * 
	 * @since 2.0
	 */
	public MTip(final Direction direction) {
		this(direction, NO_CONTEXT, null);
	}

	public MTip(final String context) {
		this(Direction.TOP, context, null);
	}

	/**
	 * @since 3.0
	 */
	public MTip(final String context, final String suffix) {
		this(Direction.TOP, context, suffix);
	}

	/**
	 * @since 3.0
	 */
	public MTip(final Direction direction, final String context) {
		this(direction, context, null);
	}

	public MTip(final Direction direction, final String context, final String suffix) {
		this.context = context;
		if (!TK.isEmpty(suffix))
			this.context += "-" + suffix;
		
		setDirection(direction);
		setFocusable(true);

		if (UI.isRetro()) {
			setBackgroundPainted(false); // use default painting
			setOpaque(true);
		}
		else {
			GradientPainter painter = new GradientPainter();
			painter.setReversed(true);
			setPainter(painter);
		}

		StaticHandler handler = new StaticHandler();
		addKeyListener(handler);
		addMouseListener(handler);
	}
	
	@Override
	public Dimension getMinimumSize() {
		Dimension d = super.getMinimumSize();

		return new Dimension(0, d.height);
	}
	
	/**
	 * @since 4.2
	 */
	public String getTipContext() { return context; }

	/**
	 * @since 3.8
	 */
	public synchronized static void load() {
		if (database == null) {
			database = new Database();
			Thread thread = new Thread(database, "Tip Preloader");
			thread.setDaemon(true);
			thread.setPriority(Thread.MIN_PRIORITY);
			thread.start();
		}
	}
	
	/**
	 * @since 4.0
	 */
	public static void reset() {
		Config config = Config.getDefault();
		config.removeAllValues(key -> key.startsWith("Boolean.Tip.disabled."));
		config.removeAllValues(key -> key.startsWith("Date.Tip.lastVisible."));
		config.sync();
	}

	public void showNextTip() {
		showNextTip(Visible.ALWAYS);
	}
	
	/**
	 * @since 1.2
	 */
	public void showNextTip(final Visible visible) {
		this.visible = visible;
		currentTip = getNextTip();
		if (currentTip == null) {
			setText(null);
			setVisible(false);
		}
		else {
			if (!canShow(visible)) {
				setText(null);
				setVisible(false);
				
				return;
			}
			
			if (currentTip.text.icon == null) {
				if (oldDirection != null)
					setDirection(oldDirection);
			}
			else {
				Icon icon = MIcon.small(currentTip.text.icon);
				if (icon == null) {
					if (oldDirection != null)
						setDirection(oldDirection);
				}
				else {
					Direction currentDirection = getDirection();
					if (currentDirection != Direction.NONE) {
						oldDirection = currentDirection;
						setDirection(Direction.NONE);
					}
					setIcon(icon);
				}
			}
			setTipText(currentTip.text.value);
			if (currentTip.text.isHTTP()) {
				setCursor(Cursor.HAND_CURSOR);
				setToolTipText(UI.getLinkToolTipText(currentTip.text.more));
			}
			else {
				setCursor(Cursor.DEFAULT_CURSOR);
				setToolTipText(currentTip.text.value);
			}
		}
	}
	
	public void setTipText(final String value) {
		if (TK.isEmpty(value))
			setText(null);
		else
			setText(i18n("Tip: {0}", value));
	}

	@Override
	public void updateUI() {
		super.updateUI();
		Color bg, fg;
		UIDefaults defaults = UIManager.getDefaults();
		if (UI.isRetro()) {
			bg = TK.get(defaults.getColor("Retro.Tip.background"), Color.BLACK);
			fg = TK.get(defaults.getColor("Retro.Tip.foreground"), Color.WHITE);
		}
		else {
			bg = TK.get(defaults.getColor("control"), Color.WHITE);
			bg = MDialog.getSecondaryBackground(bg);
			fg = MColor.getContrastBW(bg);
		}
		setColor(bg, fg);
	}
	
	// private
	
	private boolean canShow(final Visible visible) {
		if (visible == Visible.ALWAYS)
			return true;
		
		if (NO_CONTEXT.equals(context))
			return true;
		
		Config config = getConfigPrivileged();

		if (config.read("Tip.disabled." + context, false))
			return false;

		long now = MDate.currentTime();

		String configKey = "Tip.lastVisible." + context;
		long lastVisible = config.readDateValue(configKey, 0);
		
		// not expired yet
		if (now < lastVisible)
			return true;
		
		int maxDays =
			(visible == Visible.OFTEN)
			? 2 // OFTEN
			: 7; // SELDOM
		
		if (TimeUnit.MILLISECONDS.toDays(now - lastVisible) >= maxDays) {
			long nextTime = now + TimeUnit.HOURS.toMillis(1);
			MAccessController.doPrivileged(() -> {
				config.writeDate(configKey, nextTime);
					
				return null;
			} );
			
			return true;
		}
		else {
			return false;
		}
	}

	private Config getConfigPrivileged() {
		SecurityManager sm = System.getSecurityManager();

		if (sm == null)
			return Config.getDefault();

		return MAccessController.doPrivileged(Config::getDefault);
	}

	private TipInfo getNextTip() {
		synchronized (MTip.class) {
			if (database == null) {
				database = new Database();
				database.run();
			}
			else {
				try {
					synchronized (database) {
						while (!database.loaded) {
							database.wait();
						}
					}
				}
				catch (InterruptedException exception) {
					MLogger.exception(exception);
				}
			}

			return database.getTipText(context);
		}
	}
	
	// private classes

// TODO: startup optimization: defer XML load until it is actually needed
	private static final class Database extends MArrayList<Tips> implements Runnable {

		// private

		private boolean loaded;
		private final MLogger log = MLogger.get("tip");

		// public

		@Override
		public void run() {
			if (!load(Locale.getDefault(Locale.Category.DISPLAY).getLanguage())) {
				if (!load("en"))
					log.warning("Tips database not found");
			}
			synchronized (this) {
				loaded = true;
				notifyAll();
			}
		}
		
		// private
		
		private Database() { }
		
		@SuppressFBWarnings("MDM_RANDOM_SEED")
		private TipInfo getTipText(final String context) {
			// database empty?
			if (isEmpty())
				return null;
			
			// get a list of tips for given context
			Tips tips = null;
			for (Tips i : this) {
				if (i.context.equals(context)) {
					tips = i;
					
					break; // for
				}
			}
			
			// no tips?
			if ((tips == null) || TK.isEmpty(tips.texts)) {
				log.warningFormat("No tips for \"%s\"", context);
				
				return null;
			}

			// return a random tip from the list
			Random randomTip = new Random();

			return new TipInfo(tips.texts.get(randomTip.nextInt(tips.texts.size())));
		}

		private boolean load(final String language) {
			clear();

			InputStream input = null;
			try {
				final String path = MApplication.getResourcesPath(false) + "/tips/" + language + ".xml";
				log.infoFormat("Loading tips: \"%s\"", path);
				
				InputStream resourceStream = getClass().getResourceAsStream(path);
				
				if (resourceStream == null)
					return false;

				SimpleXMLReader reader = new SimpleXMLReader() {
					private Tips tips;
					@Override
					protected void onEnd(final String name) {
						if ((tips != null) && "tips".equals(name)) {
							if (TK.isEmpty(tips.texts)) {
								log.warningFormat("No tips for \"%s\" context", tips.context);
								tips = null;
							}
							else {
								log.debugFormat(
									"Adding tips for \"%s\" context (%d)",
									tips.context,
									tips.texts.size()
								);
								add(tips);
								tips = null;
							}
						}
					}
					@Override
					protected void onStart(final String name) {
						if ((tips != null) && "text".equals(name)) {
							Text text = new Text();
							text.icon = getStringAttribute("icon");
							text.more = getStringAttribute("more");
							text.value = getValue();
							if (TK.isEmpty(text.value))
								log.warningFormat("Empty tip for \"%s\" context", tips.context);
							else
								tips.texts.add(text);
						}
						else if ((tips == null) && "tips".equals(name)) {
							tips = new Tips();
							tips.context = getStringAttribute("context");
							if (TK.isEmpty(tips.context)) {
								log.errorFormat("Empty context in \"%s\"", path);
								cancel();
							}
						}
					}
				};
				input = new BufferedInputStream(resourceStream);
				reader.read(input);
				
				return true;
			}
			catch (IOException exception) {
				MLogger.exception(exception);
				
				return false;
			}
			finally {
				FS.close(input);
			}
		}
		
	}

	private static final class StaticHandler extends MMouseAdapter implements KeyListener {

		// public

		@Override
		public void buttonClicked/*mouseClicked*/(final MouseEvent e) {
			if (isLeft(e)) {
				MTip tip = (MTip)e.getSource();
				if ((tip.currentTip != null) && tip.currentTip.text.isHTTP())
					MApplication.openURI(tip.currentTip.text.more);
				e.consume();
			}
		}

		@Override
		public void popupTrigger(final MouseEvent e) {
			doPopup(e);
		}
		
		// KeyListener
		
		@Override
		public void keyPressed(final KeyEvent e) {
			if (UI.isPopupTrigger(e))
				doPopup(e);
		}

		@Override
		public void keyReleased(final KeyEvent e) { }

		@Override
		public void keyTyped(final KeyEvent e) { }
		
		// private
		
		private void doPopup(final InputEvent e) {
			MTip tip = (MTip)e.getSource();
			
			if (MTip.NO_CONTEXT.equals(tip.getTipContext()))
				return;

			MMenu menu = new MMenu();
			MAction closeAction = new MAction(i18n("Do not show this message again"), "ui/close", self -> {
				tip.setVisible(false);

				String key = "Tip.disabled." + tip.context;
				MAccessController.doPrivileged(() -> {
					Config config = Config.getDefault();
					config.write(key, true);
					config.sync();
							
					return null;
				} );
			} );
			// no "Close" action for always visible tips
			closeAction.setEnabled(tip.visible != Visible.ALWAYS);
			menu.add(closeAction);
			menu.showPopup(e);
		}

	}
	
	private static final class Text {

		// private

		private String icon;
		private String more;
		private String value;
		
		// private
		
		private boolean isHTTP() {
			return (more != null) && Net.isHTTP(more);
		}

	}
	
	private static final class TipInfo {
		
		// private
		
		private final Text text;
		
		// private
		
		private TipInfo(final Text text) {
			this.text = text;
		}
		
	}
	
	private static final class Tips {
		
		// private

		private final List<Text> texts = new MArrayList<>();
		private String context;
		
		// private
		
		private Tips() { }
		
	}

}
