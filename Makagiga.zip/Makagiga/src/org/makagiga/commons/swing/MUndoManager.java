// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.event.ActionEvent;
import java.lang.ref.WeakReference;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.JTextComponent;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.TriBoolean;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.autocompletion.AutoCompletion;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MUndoManager extends UndoManager implements MDisposable {
	
	// public
	
	/**
	 * An empty @c UndoableEditListener array.
	 * 
	 * @since 3.0
	 */
	public static final UndoableEditListener[] EMPTY_UNDOABLE_EDIT_LISTENER_ARRAY = new UndoableEditListener[0];

	public static final int NO_LIMIT = -1;
	
	// private
	
	private StaticRedoAction redoAction;
	private StaticUndoAction undoAction;
	private WeakReference<JComponent> ownerRef;
	
	// public

	/**
	 * @since 3.4
	 */
	public MUndoManager() {
		this(128);
	}

	/**
	 * @since 3.0
	 */
	public MUndoManager(final int limit) {
		this(null, limit);
	}

	/**
	 * @since 3.4
	 */
	public MUndoManager(final JComponent owner) {
		this(owner, 128);
	}
	
	public MUndoManager(final JComponent owner, final int limit) {
		setOwner(owner);
		setLimit(limit);
		
		undoAction = new StaticUndoAction(this);
		redoAction = new StaticRedoAction(this);
	}
	
	/**
	 * @since 4.6
	 */
	public void clear(final boolean editable) {
		discardAllEdits();
		updateUndoRedoActions(editable);
	}
	
	public MAction getRedoAction() { return redoAction; }
	
	public MAction getUndoAction() { return undoAction; }

	/**
	 * @since 3.8.9
	 */
	@InvokedFromConstructor
	public void setOwner(final JComponent owner) {
		if (ownerRef != null)
			ownerRef.clear();
		
		ownerRef = (owner == null) ? null : new WeakReference<>(owner);
	}
	
	@Override
	public void undoableEditHappened(final UndoableEditEvent e) {
		super.undoableEditHappened(e);
		updateUserActions();
	}

	public void updateMenu(final MMenu menu) {
		menu.add(getUndoAction());
		menu.add(getRedoAction());
	}

	public void updateToolBar(final MToolBar toolBar) {
		toolBar.add(getUndoAction(), MToolBar.SHOW_TEXT);
		toolBar.add(getRedoAction());
	}

	public void updateUndoRedoActions(final boolean editable) {
		undoAction.setEnabled(editable && canUndo());
		redoAction.setEnabled(editable && canRedo());
	}

	public void updateUserActions() {
		updateUndoRedoActions(true);
	}
	
	// MDisposable
	
	/**
	 * @since 4.4
	 */
	@Override
	public void dispose() {
		discardAllEdits();
	}
	
	// protected
	
	protected JComponent getOwner() {
		return TK.get(ownerRef);
	}
	
	// HACK: kill forwarded key stroke
	protected boolean isValidEvent(final ActionEvent e) {
		if (e.getSource() instanceof JMenuItem) {
			JComponent c = getOwner();
			boolean isCtrlOrShift = (e.getModifiers() & (MAction.getMenuMask() | ActionEvent.SHIFT_MASK)) != 0;
			if ((c != null) && !c.isFocusOwner() && isCtrlOrShift) {
				TK.beep();
				
				return false;
			}
		}
		
		return true;
	}
	
	// private
	
	private TriBoolean setAutoCompletionEnabled(final ActionEvent e, final boolean value) {
		if (!(e.getSource() instanceof JMenuItem))
			return TriBoolean.UNDEFINED;
		
		JComponent c = getOwner();
		if (c instanceof JTextComponent) {
			AutoCompletion autoCompletion = MText.getAutoCompletion((JTextComponent)c);
			if (autoCompletion != null) {
				boolean enabled = autoCompletion.enabled.get();
				autoCompletion.enabled.set(value);
			
				return TriBoolean.of(enabled);
			}
		}
		
		return TriBoolean.UNDEFINED;
	}

	// private classes
	
	private static abstract class StaticAction extends MDataAction.Weak<MUndoManager> {

		// public
		
		public StaticAction(final MUndoManager undoManager, final String text, final String iconName) {
			super(undoManager, text, iconName);
		}
		
		@Override
		public final void onAction() {
			MUndoManager undoManager = get();

			if (undoManager == null)
				return;

			if (!undoManager.isValidEvent(getActionEvent()))
				return;

			// temp. disable auto completion to avoid popup window
			TriBoolean acEnabled = undoManager.setAutoCompletionEnabled(getActionEvent(), false);

			try {
				onAction(undoManager);
			}
			catch (CannotRedoException | CannotUndoException exception) {
				MLogger.exception(exception);
			}
			finally {
				if (acEnabled.isDefined())
					undoManager.setAutoCompletionEnabled(getActionEvent(), acEnabled.isTrue());
				undoManager.updateUserActions();
			}
		}
		
		public abstract void onAction(final MUndoManager undoManager);

	}

	private static final class StaticRedoAction extends StaticAction {

		// public

		@Override
		public void onAction(final MUndoManager undoManager) {
			undoManager.redo();
		}

		// private

		private StaticRedoAction(final MUndoManager undoManager) {
			super(undoManager, i18n("Redo"), "ui/redo");
			setAcceleratorKey(getRedoKeyStroke());
			setAlternateAcceleratorKey(VK_Y, getMenuMask());
			setHTMLHelp(i18n("Redoes the last operation."));
		}

	}

	private static final class StaticUndoAction extends StaticAction {

		// public

		@Override
		public void onAction(final MUndoManager undoManager) {
			undoManager.undo();
		}

		// private

		private StaticUndoAction(final MUndoManager undoManager) {
			super(undoManager, i18n("Undo"), "ui/undo");
			setAcceleratorKey(VK_Z, getMenuMask());
			setHTMLHelp(i18n("Undoes the last operation."));
		}

	}

}
