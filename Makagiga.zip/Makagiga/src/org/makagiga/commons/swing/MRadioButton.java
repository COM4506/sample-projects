// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.event.ActionListener;
import java.beans.EventHandler;
import javax.swing.JRadioButton;

import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;

/**
 * A radio button.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MRadioButton extends JRadioButton {

	// public

	/**
	 * Constructs a radio button.
	 */
	public MRadioButton() {
		this(null);
	}

	/**
	 * Constructs a radio button.
	 * @param text A text
	 */
	public MRadioButton(final String text) {
		super(text);
		addActionListener(e -> onClick());
	}

	/**
	 * @since 4.0
	 */
	public MRadioButton(final String text, final boolean selected) {
		super(text, selected);
		addActionListener(e -> onClick());
	}

	/**
	 * @since 3.0, 4.0 (returns {@code java.awt.event.ActionListener})
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public ActionListener onClick(final Object target, final String action) {
		ActionListener l = EventHandler.create(ActionListener.class, target, action);
		addActionListener(l);

		return l;
	}

	/**
	 * @since 3.0, 4.0 (returns {@code java.awt.event.ActionListener})
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public ActionListener onSelect(final Object target, final String targetPropertyName) {
		ActionListener l = EventHandler.create(ActionListener.class, target, targetPropertyName, "source.selected");
		addActionListener(l);

		return l;
	}

	@Override
	public void updateUI() {
		super.updateUI();
		if (UI.isMetal())
			setIconTextGap(8);
	}

	// protected

	/**
	 * Invoked when radio button is clicked.
	 * By default this method does nothing.
	 */
	@Obsolete
	protected void onClick() { }

}
