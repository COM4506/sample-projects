// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.lang.ref.WeakReference;
import java.util.Objects;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.text.JTextComponent;

import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.form.PropertyPanel;
import org.makagiga.commons.painters.FlatPainter;

/**
 * @since 4.0
 */
public class MWrapperPanel<C extends JComponent> extends MPanel {

	// public

	public enum State { NORMAL, ERROR, FOCUSED }
	
	/**
	 * @since 4.4
	 */
	public static final String AUTO_SELECT_ALL_PROPERTY = "org.makagiga.commons.swing.MWrapperPanel.autoSelectAll";
		
	// private

	private boolean compactSize;
	private final int orientation;
	private State state = State.NORMAL;
	private final WeakReference<C> view;
	private final WeakReference<MLabel> label;
		
	// public

	public MWrapperPanel(final int orientation, final C view, final String label) {
		this(5, 5, orientation, view, label);
	}

	public MWrapperPanel(final int hGap, final int vGap, final int orientation, final C view, final String label) {
		this(new BorderLayout(hGap, vGap), orientation, view, label);
	}
				
	public MWrapperPanel(final LayoutManager layout, final int orientation, final C view, final String label) {
		super(layout);
		setMargin(0, 2, 0, 2);

		MLabel labelComponent = new MLabel(label) {
			@Override
			public void setText(final String text) {
				super.setText(text);
				this.setVisible(!TK.isEmpty(text));
			}
		};
		if (MLabel.getLabel(view) == null) // do not change existing "labelFor"
			labelComponent.setLabelFor(view);
			
		switch (orientation) {
			case UI.HORIZONTAL:
				addWest(labelComponent);
				break;
			case UI.VERTICAL:
				addNorth(labelComponent);
				break;
			default:
				throw new IllegalArgumentException("\"orientation\" must be \"UI.HORIZONTAL\" or \"UI.VERTICAL\": " + orientation);
		}
		
		addCenter(view);

		this.orientation = orientation;
		this.view = new WeakReference<>(view);
		this.label = new WeakReference<>(labelComponent);
	}

	public MLabel getLabel() {
		return label.get();
	}
	
	@Override
	public Dimension getMaximumSize() {
		Dimension max = super.getMaximumSize();

		if (!compactSize)
			return max;

		Dimension pref = super.getPreferredSize();
		// HACK: add extra width to fix layout in some languages
		int extraWidth = (getView() instanceof JComboBox) ? 24 : 0;

		return new Dimension(
			Math.min(pref.width + extraWidth, max.width),
			pref.height
		);
	}

	public int getOrientation() { return orientation; }

	public State getState() { return state; }

	public void setState(final State value) {
		Objects.requireNonNull(value);

		if (value != state) {
			state = value;
			switch (state) {
				case NORMAL:
					setPainter(null);
					break;
				case ERROR:
					setPainter(new FlatPainter(MHighlighter.ERROR_COLOR));
					break;
				case FOCUSED:
					setPainter(new FlatPainter(this));
					break;
				default:
					throw new WTFError(state);
			}
		}
	}

	public C getView() {
		return view.get();
	}

	@SuppressWarnings("unchecked")
	public static <T extends JComponent> T getWrappedView(final JComponent c) {
		if (c instanceof MWrapperPanel<?>)
			return (T)MWrapperPanel.class.cast(c).getView();

		return (T)c;
	}

	/**
	 * @since 5.4
	 */
	public boolean isCompactSize() { return compactSize; }

	/**
	 * @since 5.4
	 */
	public void setCompactSize(final boolean value) { compactSize = value; }

	// public classes

	public static class Horizontal<T extends JComponent> extends MWrapperPanel<T> {
	
		// public

		public Horizontal(final T component, final String text, final boolean limitHeight) {
			super(DEFAULT_CONTENT_MARGIN, 5, UI.HORIZONTAL, component, text);
			if (limitHeight)
				limitHeight(component);

			new StaticFocusHandler(component);
		}

	}

	public static class Vertical<T extends JComponent> extends MWrapperPanel<T> {

		// public

		public Vertical(final T component, final String text) {
			super(DEFAULT_CONTENT_MARGIN, 5, UI.VERTICAL, component, text);

			new StaticFocusHandler(component);
		}

	}

	// private classes

	private static final class StaticFocusHandler implements FocusListener {

		// public

		@Override
		public void focusGained(final FocusEvent e) {
			if (e.isTemporary())
				return;
		
			MWrapperPanel<?> p = getWrapper(e);
			if (p != null) {
				// do not select all on popup menu close
				if (p.getState() == MWrapperPanel.State.FOCUSED)
					return;
			
				p.setState(MWrapperPanel.State.FOCUSED);
				
				// auto select all
				
				Component view = p.getView();
				final JTextComponent textComponent;
				if (view instanceof AbstractSpinner<?, ?>)
					textComponent = AbstractSpinner.class.cast(view).getTextField();
				else if (view instanceof JTextComponent)
					textComponent = (JTextComponent)view;
				else
					textComponent = null;
				
				if (
					(textComponent != null) &&
					Boolean.TRUE.equals(textComponent.getClientProperty(MWrapperPanel.AUTO_SELECT_ALL_PROPERTY)) &&
					!MText.isMultiline(textComponent)
				) {
					// HACK: http://stackoverflow.com/questions/1178312/how-to-select-all-text-in-a-jformattedtextfield-when-it-gets-focus
					/*UI.*/SwingUtilities.invokeLater(() -> textComponent.selectAll());
				}
			}
		}

		@Override
		public void focusLost(final FocusEvent e) {
			if (e.isTemporary())
				return;

			MWrapperPanel<?> p = getWrapper(e);
			if (p != null)
				p.setState(MWrapperPanel.State.NORMAL);
		}

		// private

		private StaticFocusHandler(final JComponent component) {
			JComponent focusable = null;
			if (component instanceof AbstractSpinner) {
				focusable = AbstractSpinner.class.cast(component).getTextField();
			}
			else if (component instanceof JScrollPane) {
				Component view = SwingUtilities.getUnwrappedView(JScrollPane.class.cast(component).getViewport());
				if (view instanceof JComponent)
					focusable = (JComponent)view;
			}

			if (focusable == null)
				focusable = component;
			focusable.addFocusListener(this);
		}

		private boolean getHighlightFocusedEditor(final MWrapperPanel<?> wrapper) {
			PropertyPanel p = UI.getAncestorOfClass(PropertyPanel.class, wrapper);

			if (p == null) {
				// show background highlight only if spinner panel has visible side components
				if (wrapper instanceof MSpinnerPanel) {
					MSpinnerPanel spinnerPanel = (MSpinnerPanel)wrapper;

					if (
						spinnerPanel.getLabel().isVisible() &&
						!TK.isEmpty(spinnerPanel.getLabel().getText())
					)
						return true;

					if (!spinnerPanel.getButtonPanel().isVisible())
						return false;

					for (Component i : spinnerPanel.getButtonPanel().getComponents()) {
						if (i.isVisible())
							return true;
					}

					return false;
				}

				return true;
			}
			
			return p.getHighlightFocusedEditor();
		}

		private MWrapperPanel<?> getWrapper(final FocusEvent e) {
			if (e.getSource() instanceof JComponent) {
				MWrapperPanel<?> wrapper = UI.getAncestorOfClass(MWrapperPanel.class, e.getComponent());

				if (wrapper == null)
					return null;

				if (
					(e.getID() == FocusEvent.FOCUS_GAINED) &&
					!getHighlightFocusedEditor(wrapper)
				)
					return null;

				return wrapper;
			}

			return null;
		}

	}

}
