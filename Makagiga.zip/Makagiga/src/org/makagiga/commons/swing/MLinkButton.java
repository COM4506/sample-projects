// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.datatransfer.Transferable;
import java.awt.event.MouseEvent;
import java.beans.Beans;
import java.net.URI;
import java.util.Objects;
import javax.swing.Action;
import javax.swing.TransferHandler;

import org.makagiga.commons.Globals;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MColor;
import org.makagiga.commons.Net;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.html.HTMLSelection;
import org.makagiga.commons.sb.SecureOpen;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 3.8.3, 4.0 (org.makagiga.commons.swing package)
 *
 * @mg.warning
 * {@link #getText()} may not work as you expected.
 * Use {@link #getURI()} to get the actual URI value.
 */
public class MLinkButton extends MButton implements SecureOpen {

	// public
	
	/**
	 * @since 4.8
	 */
	public enum LinkColorStyle {
		
		DEFAULT,
		INHERIT,
		
		/**
		 * @since 4.10
		 */
		SIMPLE
	
	}
	
	// private
	
	private boolean dragEnabled;
	private boolean secureOpen;
	private boolean showLinkActions = true;
	private Color linkColor;
	private Color linkHoverColor;
	private LinkColorStyle linkColorStyle;
	private String uriAsString = Net.ABOUT_BLANK.toString();
	private String title;
	private URI _uri = Net.ABOUT_BLANK;
	
	// public

	public MLinkButton() {
		// HACK: disable; too small default drag threshold (2px) on Windows
		// starts drag operation instead of regular click.
		// dragEnabled = Kiosk.actionDragDrop.get();
		
		setContentAreaFilled(false);
		setCursor(Cursor.HAND_CURSOR);
		setHorizontalAlignment(LEADING);
		setOpaque(false);
		setRequestFocusEnabled(false);
		setStyle("margin: 2; padding: 0");

		new StaticDragHandler(this);
		UI.onKeyPressed(this, e -> {
			if (UI.isPopupTrigger(e))
				showLinkMenu();
		} );
		addMouseListener(new StaticMouseHandler());

		if (Beans.isDesignTime())
			setText(MLinkAction.simplifyURI(uriAsString));
	}
	
	/**
	 * @since 4.10
	 */
	public MLinkButton(final Action action) {
		this();
		setAction(action);
	}

	/**
	 * @since 5.4
	 */
	public MLinkButton(final String text) {
		this();
		setText(text);
	}

	public MLinkButton(final URI uri) {
		this();
		setURIAndText(uri);
	}

	public MLinkButton(final URI uri, final String text) {
		this();
		setURI(uri);
		setText(text);
	}

	@Override
	public void addNotify() {
		super.addNotify();
		// get color from parent
		updateLinkColor(false);
	}

	/**
	 * Opens the current URI.
	 * 
	 * @since 3.0
	 */
	public void doOpen() {
		if (!isBlankURI()) {
			// mark as visited
			setVisited(true);
			try {
				MApplication.openURI(getURI(), this);
			}
			catch (IllegalArgumentException exception) {
				MMessage.error(UI.windowFor(this), exception);
			}
		}
	}

	/**
	 * @since 3.8.7
	 */
	public Color getHoverLinkColor() {
		if (getLinkColorStyle() == LinkColorStyle.SIMPLE)
			return UI.getForeground(this);

		if (isVisited())
			return MColor.getVisitedLinkForeground(getParentBackground());

		if (linkHoverColor != null)
			return linkHoverColor;

		return MColor.getHoverLinkForeground(getParentBackground());
	}

	/**
	 * @since 3.8.7
	 */
	public void setHoverLinkColor(final Color value) { linkHoverColor = value; }

	/**
	 * @since 3.8.6
	 */
	public Color getLinkColor() {
		if (isVisited())
			return MColor.getVisitedLinkForeground(getParentBackground());

		// user color
		if (linkColor != null)
			return linkColor;

		switch (getLinkColorStyle()) {
			case DEFAULT: return MColor.getLinkForeground(getParentBackground());
			case INHERIT:
				Container parent = getParent();
			
				return (parent == null) ? Color.BLACK : UI.getForeground(parent);
			case SIMPLE: return UI.getForeground(this);
			default: throw new WTFError(getLinkColorStyle());
		}
	}

	/**
	 * @since 3.8.6
	 */
	public void setLinkColor(final Color value) {
		if (!Objects.equals(value, linkColor)) {
			linkColor = value;
			updateLinkColor(true);
		}
	}
	
	/**
	 * @since 4.8
	 */
	public LinkColorStyle getLinkColorStyle() {
		return TK.get(linkColorStyle, LinkColorStyle.DEFAULT);
	}

	/**
	 * @since 4.8
	 */
	public void setLinkColorStyle(final LinkColorStyle value) {
		Objects.requireNonNull(value);
	
		if (value != linkColorStyle) {
			linkColorStyle = value;
			updateLinkColor(true);
		}
	}

	public boolean getShowLinkActions() { return showLinkActions; }
	
	public void setShowLinkActions(final boolean value) { showLinkActions = value; }

	/**
	 * @since 2.0
	 */
	public String getTitle() { return title; }

	/**
	 * @since 2.0
	 */
	public void setTitle(final String value) { title = value; }
	
	/**
	 * @since 4.0
	 */
	public URI getURI() { return _uri; }

	/**
	 * @since 4.0
	 */
	public void setURI(final String value) {
		setURI((value == null) ? Net.ABOUT_BLANK : Net.fixURI(value));
	}

	/**
	 * @since 4.0
	 */
	public void setURI(final URI value) {
		if (!Objects.equals(getURI(), value)) {
			_uri = (value == null) ? Net.ABOUT_BLANK : value;
			uriAsString = _uri.toString();
			setToolTipText(UI.getLinkToolTipText(uriAsString));
			updateLinkColor(true);
		}
	}

	/**
	 * @since 4.0
	 */
	public void setURIAndText(final URI value) {
		setURI(value);
		String s = TK.centerSqueeze(MLinkAction.simplifyURI(uriAsString), 128);
		if (UI.isRetro())
			setText("<" + s + ">");
		else
			setText(s);
	}
	
	/**
	 * @since 4.0
	 */
	public boolean isBlankURI() {
		return (_uri == null) || _uri.equals(Net.ABOUT_BLANK);
	}

	/**
	 * @since 2.0
	 */
	public boolean isDragEnabled() { return dragEnabled; }
	
	/**
	 * @since 2.0
	 */
	public void setDragEnabled(final boolean value) { dragEnabled = value; }

	/**
	 * @mg.default {@code false} since 3.8.6
	 *
	 * @since 2.0
	 */
	@Override
	public boolean isSecureOpen() { return secureOpen; }

	/**
	 * @since 2.0
	 */
	@Override
	public void setSecureOpen(final boolean value) { secureOpen = value; }

	/**
	 * @since 2.0
	 */
	public boolean isVisited() {
		if (isBlankURI())
			return false;

		return MAccessController.doPrivileged(() -> Globals.isLinkVisited(uriAsString));
	}

	/**
	 * @since 2.0
	 */
	public void setVisited(final boolean value) {
		if (value != isVisited()) {
			MAccessController.doPrivileged(() -> {
				Globals.setLinkVisited(uriAsString, value);
					
				return null;
			} );
			updateLinkColor(true);
		}
	}

	public void showLinkMenu() {
		if (isBlankURI())
			return;
	
		MMenu menu = new MMenu();
		Globals.updateLinkMenu(
			menu,
			getURI(),
			showLinkActions,
			TK.get(title, getText())
		);
		if (!menu.isEmpty())
			menu.showPopup(this);
	}
	
	@Override
	public void updateUI() {
		setUI(UI.getSimpleButtonUI());
		updateLinkColor(false);
	}
	
	// protected

	/**
	 * Overriden to handle action or mouse click event.
	 * By default this method opens the current URL in a web browser.
	 */
	@Override
	protected void onClick() {
		setStyle("text-decoration: none");
		doOpen();
	}
	
	// private

	private Color getParentBackground() {
		Component parent = getParent();

		// HACK: fix link foreground color for dark toolbar backgrounds
		if (
			UI.isSubstance() &&
			(parent != null) &&
			(
				(UI.getAncestorOfClass(MToolBar.class, this) != null) ||
				(UI.getAncestorOfClass(MMenuBar.class, this) != null)
			) &&
			Boolean.getBoolean("org.makagiga.plugins.substance.Plugin.isDarkToolBarBackground")
		) {
			return Color.BLACK;
		}
		
		return (parent == null) ? getBackground() : parent.getBackground();
	}

	private void updateLinkColor(final boolean stopAnimation) {
		if (stopAnimation)
			ComponentAnimation.stopForegroundBlend(this);
		setForeground(getLinkColor());
	}

	// private classes

	private static final class StaticDragHandler extends MMouseAdapter.Drag {

		// protected

		@Override
		protected boolean canDrag(final MouseEvent e) {
			MLinkButton c = (MLinkButton)e.getSource();

			return c.dragEnabled && !c.isBlankURI();
		}
		
		@Override
		protected Image createDragImage(final MouseEvent e) {
			MLinkButton c = (MLinkButton)e.getSource();
			
			return MComponent.createScreenshot(c, null);
		}

		@Override
		protected Transferable createTransferable(final MouseEvent e) {
			MLinkButton c = (MLinkButton)e.getSource();

			if (c.isBlankURI())
				return null;
			
			return HTMLSelection.fromURI(c.uriAsString);
		}

		// private

		private StaticDragHandler(final MLinkButton button) {
// TODO: 2.0: uri-list
// TODO: 2.6: LINK
			super(button, TransferHandler.COPY);
		}

	}

	private static final class StaticMouseHandler extends MMouseAdapter {

		// public

		public StaticMouseHandler() { }

		@Override
		public void mouseEntered(final MouseEvent e) {
			MLinkButton c = (MLinkButton)e.getSource();
			if (c.isEnabled()) {
				if (UI.isRetro()) {
					c.setForeground(c.getHoverLinkColor());
				}
				else {
					c.setStyle("text-decoration: underline");
					ComponentAnimation.blendForegroundProperty(c, c.getLinkColor(), c.getHoverLinkColor());
				}
			}
		}

		@Override
		public void mouseExited(final MouseEvent e) {
			MLinkButton c = (MLinkButton)e.getSource();
			if (c.isEnabled()) {
				if (UI.isRetro()) {
					c.setForeground(c.getLinkColor());
				}
				else {
					c.setStyle("text-decoration: none");
					ComponentAnimation.blendForegroundProperty(c, c.getHoverLinkColor(), c.getLinkColor());
				}
			}
		}

		@Override
		public void popupTrigger(final MouseEvent e) {
			MLinkButton c = (MLinkButton)e.getSource();
			c.showLinkMenu();
		}

	}

}
