// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.lang.ref.WeakReference;
import javax.swing.DefaultRowSorter;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.event.DocumentEvent;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import org.makagiga.commons.TK;
import org.makagiga.commons.mv.MV;

/**
 * @since 4.8
 */
public class MTableFilterPanel extends MSearchPanel {

	// private
	
	private WeakReference<MTable<TableModel>> tableRef;

	// public
	
	public MTableFilterPanel() { }
	
	public MTableFilterPanel(final MTable<?> table) {
		this();
		setTable(table);
	}
	
	@SuppressWarnings("unchecked")
	public void doFilter() {
		MTable<?> table = getTable();
		
		if (table == null)
			return;
		
		table.setHighlightedText("");
		
		RowFilter<?, ?> filter = createFilter();
		RowSorter<? extends TableModel> sorter = table.getRowSorter();
		if (sorter == null) {
			sorter = createSorter();
			table.setRowSorter(sorter);
		}
		if (sorter instanceof DefaultRowSorter<?, ?>)
			DefaultRowSorter.class.cast(sorter).setRowFilter(filter);

		State state = onPostFilter(filter);

		if (isEmpty()) {
			// scroll to selected row
			int row = table.getSelectedRow();
			if (row != -1)
				table.scrollToRow(row);
			
			if (state == null)
				state = State.NORMAL;
		}
		else {
			if (state == null) {
				if (table.isEmpty(MV.VIEW))
					state = State.ERROR;
				else {
					state = State.OK;
					table.setHighlightedText(getText());
				}
			}
		}

		setState(state);
	}
	
	public MTable<?> getTable() {
		return TK.get(tableRef);
	}
	
	@SuppressWarnings("unchecked")
	public void setTable(final MTable<?> table) {
		tableRef = new WeakReference<>((MTable<TableModel>)table);
	}
	
	// protected
	
	protected RowFilter<?, ?> createFilter() {
		return new SimpleTableFilter<>(getText());
	}
	
	protected RowFilter<?, ?> createFilter(final int... columns) {
		return new SimpleTableFilter<>(getText(), columns);
	}
	
	protected RowSorter<? extends TableModel> createSorter() {
		return new SimpleTableSorter<>(getTable().getModel());
	}
	
	@Override
	protected void onChange(final DocumentEvent e) {
		doFilter();
	}
	
	protected State onPostFilter(final RowFilter<?, ?> filter) { return null; }

	// public classes

	public static class SimpleTableFilter<M extends TableModel> extends RowFilter<M, Integer> {
	
		// private
		
		private final int[] columns;
		private final String text;
	
		// public
	
		public SimpleTableFilter(final String text, final int... columns) {
			this.text = text;
			this.columns = (columns == null) ? null : columns.clone();
		}

		@Override
		public boolean include(final RowFilter.Entry<? extends M, ? extends Integer> entry) {
			if (TK.isEmpty(text))
				return true;
		
			if ((columns == null) || (columns.length == 0)) {
				int count = entry.getValueCount();
				for (int i = 0; i < count; i++) {
					if (matches(entry, i))
						return true;
				}
			}
			else {
				for (int i : columns) {
					if (matches(entry, i))
						return true;
				}
			}
			
			return false;
		}
		
		// private
		
		private boolean matches(final RowFilter.Entry<? extends M, ? extends Integer> entry, final int column) {
			String s = entry.getStringValue(column);

			return TK.containsIgnoreCase(s, text);
		}
	
	}
	
	public static class SimpleTableSorter<M extends TableModel> extends TableRowSorter<M> {

		// public

		public SimpleTableSorter(final M model) {
			super(model);
			setSortsOnUpdates(false);
		}

	}

}
