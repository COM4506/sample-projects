// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import javax.swing.JTabbedPane;

import org.makagiga.commons.UI;

/**
 * @since 3.8.8, 4.0 (org.makagiga.commons.swing package)
 */
public class MTab extends MPanel {

	// private
	
	private boolean reorderingAllowed;

	// package

	String tabTitle;
	
	// public

	public MTab() {
		this(null);
	}
	
	public MTab(final String tabTitle) {
		this.tabTitle = tabTitle;
	}

	public JTabbedPane getTabbedPane() {
		return UI.getAncestorOfClass(JTabbedPane.class, this);
	}

	/**
	 * @since 3.8.9
	 */
	public int getTabIndex() {
		JTabbedPane tabs = getTabbedPane();
		
		return (tabs != null) ? tabs.indexOfComponent(this) : -1;
	}

	/**
	 * @since 3.8.9
	 */
	public void setTabTitle(final String value) {
		JTabbedPane tabs = getTabbedPane();

		if (tabs == null)
			return;

		int i = tabs.indexOfComponent(this);

		if (i == -1)
			return;

		tabs.setTitleAt(i, value);
		Component tabComponent = tabs.getTabComponentAt(i);
		if (tabComponent instanceof MTabbedPane.TabComponent)
			MTabbedPane.TabComponent.class.cast(tabComponent).setText(value);
	}
	
	/**
	 * @since 4.8
	 */
	public boolean isReorderingAllowed() { return reorderingAllowed; }

	/**
	 * @since 4.8
	 */
	public void setReorderingAllowed(final boolean value) { reorderingAllowed = value; }

	public boolean isTabSelected() {
		JTabbedPane tabs = getTabbedPane();

		if (tabs == null)
			return false;

		return tabs.getSelectedComponent() == this;
	}

}
