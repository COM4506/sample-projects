// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import javax.swing.AbstractButton;
import javax.swing.JFormattedTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;

import org.makagiga.commons.MAction;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;

/**
 * @since 5.4
 */
public final class MSpinnerPanel extends MWrapperPanel.Horizontal<JSpinner> {

	// private
	
	private final MLabel suffixLabel;
	private final MPlusMinusPanel buttonPanel;
	
	// public
	
	public MSpinnerPanel(final JSpinner spinner) {
		this(spinner, null);
	}
	
	public MSpinnerPanel(final JSpinner spinner, final String text) {
		super(spinner, text, true);

		boolean buttonsHidden =
			hideButton("Spinner.nextButton") &&
			hideButton("Spinner.previousButton");

// CREDITS: layout based on GTK+ 3.x spinner
		buttonPanel = new MPlusMinusPanel();
		suffixLabel = MLabel.createSmall(null);
		suffixLabel.setStyle("margin-right: 5");
		suffixLabel.setVisible(false);
		buttonPanel.add(suffixLabel, 0);
		addEast(buttonPanel);

		MSmallButton decButton = buttonPanel.getMinusButton();
		decButton.addActionListener(e -> fire("decrement"));
		decButton.setVisible(buttonsHidden);

		MSmallButton incButton = buttonPanel.getPlusButton();
		incButton.addActionListener(e -> fire("increment"));
		incButton.setVisible(buttonsHidden);

		spinner.addChangeListener(e -> updateButtons());
		updateButtons();
	}

	public MPanel getButtonPanel() { return buttonPanel; }

	@SuppressWarnings("unchecked")
	public <T extends JSpinner> T getSpinner() {
		return (T)getView();
	}

	public MLabel getSuffixLabel() { return suffixLabel; }

	public String getSuffixText() {
		return suffixLabel.getText();
	}
	
	public void setSuffixText(final String text) {
		setSuffixText(text, null);
	}

	public void setSuffixText(final String text, final String toolTipText) {
		suffixLabel.setText(text);
		suffixLabel.setToolTipText(toolTipText);
		suffixLabel.setVisible(!TK.isEmpty(text));
	}

	// private

	private void fire(final String action) {
		JSpinner spinner = getSpinner();

		if (!spinner.isEnabled()) {
			UI.beep();

			return;
		}

		JFormattedTextField textField = AbstractSpinner.getTextField(spinner);
		if ((textField != null) && textField.isEditable()) {
			textField.requestFocusInWindow();
			MAction.fire(action, spinner);
		}
		else
			UI.beep();
	}

	private boolean hideButton(final String name) {
		if (!UI.isMetal())
			return false;
	
		Component c = ContainerIterator.findName(getView(), name);
		if (c instanceof AbstractButton) {
			MComponent.removeFromParent(c, false);
			
			return true;
		}
		
		return false;
	}
	
	private void updateButtons() {
		SpinnerModel model = getSpinner().getModel();
		buttonPanel.getMinusButton()
			.setEnabled(model.getPreviousValue() != null);
		buttonPanel.getPlusButton()
			.setEnabled(model.getNextValue() != null);
	}

}
