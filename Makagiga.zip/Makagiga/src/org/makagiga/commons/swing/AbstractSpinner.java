// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Dimension;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SwingUtilities;

import org.makagiga.commons.MAction;
import org.makagiga.commons.UI;
import org.makagiga.commons.autocompletion.AutoCompletion;

/**
 * An abstract spinner.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public abstract class AbstractSpinner<M extends SpinnerModel, T> extends JSpinner
implements
	MText.TextFieldExtensions,
	UI.MouseWheelEventsControl
{
	
	// private
	
	private boolean mouseWheelEventsEnabled = true;
	private int maximumWidth = -1;
	private JTextField textField;

	// public

	/**
	 * @since 3.8
	 */
	public AbstractSpinner(final M model) {
		super(model);
		addMouseWheelListener(e -> {
			if (getMouseWheelEventsEnabled() && isEnabled())
				MAction.fire(e, "increment", "decrement", this);
		} );
	}

	/**
	 * @since 2.2
	 */
	public int getMaximumWidth() { return maximumWidth; }

	/**
	 * @since 2.2
	 */
	public void setMaximumWidth(final int value) {
		if (value != maximumWidth) {
			maximumWidth = value;
			revalidate();
		}
	}

	@Override
	public Dimension getMaximumSize() {
		int w = (maximumWidth == -1) ? super.getMaximumSize().width : maximumWidth;
		
		return new Dimension(w, getPreferredSize().height + (MText.MARGIN * 2));
	}

	@Override
	@SuppressWarnings("unchecked")
	public M getModel() {
		return (M)super.getModel();
	}

	/**
	 * @since 2.0
	 */
	@Override
	public boolean getMouseWheelEventsEnabled() { return mouseWheelEventsEnabled; }
		
	/**
	 * @since 2.0
	 */
	@Override
	public void setMouseWheelEventsEnabled(final boolean value) { mouseWheelEventsEnabled = value; }

	/**
	 * Returns the text field associated with this spinner. It never returns {@code null}.
	 */
	public JTextField getTextField() {
		if (textField == null) {
			textField = getTextField(this);
			if (textField == null)
				textField = new JTextField(); // dummy
		}

		return textField;
	}
	
	/**
	 * @since 5.0
	 */
	public static JFormattedTextField getTextField(final JSpinner spinner) {
		JComponent editor = spinner.getEditor();

		return
			(editor instanceof DefaultEditor)
			? DefaultEditor.class.cast(editor).getTextField()
			: null;
	}
	
	/**
	 * @since 4.8
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public void makeLargeFont() {
		UI.setLargerInputFont(this, false);
	}
	
	@Override
	public void requestFocus() {
		getTextField().requestFocus();
	}

	@Override
	public boolean requestFocusInWindow() {
		return getTextField().requestFocusInWindow();
	}

	@Override
	public void setValue(final Object value) {
		AutoCompletion autoCompletion = MText.getAutoCompletion(getTextField());
		if (autoCompletion == null)
			super.setValue(value);
		else
			autoCompletion.invokeDisabled(() -> super.setValue(value));
	}

	// common extensions
	
	@Override
	public void clear() {
		setText(null);
	}

	@Override
	public boolean isEmpty() {
		return MText.isEmpty(getTextField());
	}

	@Override
	public void makeDefault() {
		requestFocusInWindow();
	
		// HACK: http://stackoverflow.com/questions/1178312/how-to-select-all-text-in-a-jformattedtextfield-when-it-gets-focus
		/*UI.*/SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JTextField textField = getTextField();
				if (textField != null)
					textField.selectAll();
			}
		} );
	}

	// text completion
	
	@Override
	public String getAutoCompletion() {
		return MText.getAutoCompletionID(getTextField());
	}
	
	@Override
	public void saveAutoCompletion() {
		MText.saveAutoCompletion(getTextField());
	}
	
	@Override
	public void setAutoCompletion(final String id) {
		JTextField tf = getTextField();
		MText.installAutoCompletion(tf, id);
		MText.getAutoCompletion(tf).setShowPopupOnUpDownKeyPress(false);
	}

	/**
	 * @throws NullPointerException If no default editor
	 *
	 * @since 2.0
	 */
	@Override
	public String getText() {
		return getTextField().getText();
	}
	
	/**
	 * @throws NullPointerException If no default editor
	 *
	 * @since 2.0
	 */
	@Override
	public void setText(final String value) {
		getTextField().setText(value);
	}

	// protected

	/**
	 * Installs @ref MText on this text field editor.
	 */
	protected void setupEditor() {
		JTextField tf = getTextField();
		MText.commonSetup(tf);
		// add padding
		if (UI.isMetal())
			tf.setBorder(UI.createEmptyBorder(MText.MARGIN - 1));
	}

}
