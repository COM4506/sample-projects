// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Window;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JMenuBar;
import javax.swing.KeyStroke;
import javax.swing.RootPaneContainer;
import javax.swing.event.ChangeListener;

import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;

/**
 * A "What's This?" tool tips.
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public final class MWhatsThis extends MComponent {
	
	// private

	private boolean hintVisible = true;
	private static final Color DEFAULT_BG = new Color(50, 50, 50, 127);
	private static final Color DEFAULT_FG = Color.WHITE;
	private static final Font FONT = new Font(Font.DIALOG, Font.BOLD, UI.getDefaultFontSize());
	private static MTimer hintTimer;
	private static final String INFO_PROPERTY = "org.makagiga.commons.swing.MWhatsThis.info";
	private final WeakReference<Window> windowRef;

	// public

	/**
	 * @since 3.4
	 */
	public MWhatsThis(final Window window) {
		windowRef = new WeakReference<>(window);
	}

	/**
	 * @since 3.8
	 */
	public static List<MWhatsThis.Info> getAll(final Container container) {
		final List<MWhatsThis.Info> result = new MArrayList<>();

		new ContainerScanner(container) {
			@Override
			public void processComponent(final Container container, final Component component) {
				if (component instanceof JComponent) {
					JComponent c = (JComponent)component;
					Info i = UI.getClientProperty(c, INFO_PROPERTY, null);
					if (i != null)
						result.add(i);
				}
			}
		};

		return result;
	}
	
	public static Info set(final JComponent c, final String text) {
		return set(c, text, DEFAULT_BG, DEFAULT_FG);
	}
	
	public static Info set(final JComponent c, final String text, final Color background, final Color foreground) {
		if (text == null) {
			c.putClientProperty(INFO_PROPERTY, null);
			
			return null;
		}
		
		Info info = new Info(c, text, background, foreground);
		c.putClientProperty(INFO_PROPERTY, info);
		
		return info;
	}

	// protected

	/**
	 * Paints the "what's this?" info over the main window.
	 * 
	 * @param graphics the 2D graphics
	 */
	@Override
	protected void paintComponent(final Graphics graphics) {
		Graphics2D g = (Graphics2D)graphics;
		Window window = windowRef.get();
		
		if (window == null)
			return;

		UI.setAntialiasing(g, true);
		UI.setTextAntialiasing(g, null);

		for (Info i : getAll(window))
			i.draw(this, g);

		if (hintVisible) {
			String hint = i18n("Press {0} to return...", "<" + UI.toString(MActionInfo.WHATS_THIS.getKeyStroke()) + ">");

			g.setFont(FONT);
				
			FontMetrics fm = g.getFontMetrics();
			Rectangle r = fm.getStringBounds(hint, g).getBounds();
			r.width += 20;
			r.height += 20;
			r.x = getWidth() / 2 - r.width / 2;
			r.y = getHeight() / 2 - r.height / 2;

			// background
			g.setColor(Color.WHITE);
			g.fillRoundRect(r.x, r.y, r.width, r.height, 10, 10);

			// text
			g.setColor(Color.BLACK);
			g.drawString(
				hint,
				r.x + 10,
				r.y + 10 + fm.getAscent()
			);
		}
	}

	// private
	
	private static void uninstall(final RootPaneContainer rpc) {
		MFrame.clearGlassPane(rpc);
		hintTimer = TK.dispose(hintTimer);
	}

	// public classes
	
	/**
	 * @since 4.0
	 */
	public static final class Action extends MDataAction.Weak<Window> {
		
		// private
		
		private ChangeListener menuChangeListener;
		
		// public
		
		public Action(final Window window) {
			super(window, MActionInfo.WHATS_THIS);
			setAuthorizationProperty(Kiosk.actionWhatsThis);
		}
		
		@Override
		public void onAction() {
			final Window window = get();
			
			if (window instanceof RootPaneContainer) {
				RootPaneContainer rpc = (RootPaneContainer)window;
				JMenuBar menuBar = rpc.getRootPane().getJMenuBar();

				// deactivate
				if (rpc.getGlassPane() instanceof MWhatsThis) {
					uninstall(rpc, menuBar);

					return;
				}

				// activate
				if (menuBar != null) {
					menuBar.getSelectionModel().clearSelection();
					// hide "What's This?" on menu bar activation
					menuChangeListener = e -> uninstall(rpc, menuBar);
					menuBar.getSelectionModel().addChangeListener(menuChangeListener);
				}

				// show "what's this?"
				MWhatsThis wt = new MWhatsThis(window);
				rpc.setGlassPane(wt);
				wt.setVisible(true);

				// auto hide hint after 4 seconds
				hintTimer = MTimer.seconds(4, timer -> {
					if (wt.isVisible()) {
						wt.hintVisible = false;
						wt.repaint();
					}

					return MTimer.STOP;
				} );
				hintTimer.start();
			}
		}
		
		// private
		
		private void uninstall(final RootPaneContainer rpc, final JMenuBar menuBar) {
			MWhatsThis.uninstall(rpc);
			if (menuBar != null)
				menuBar.getSelectionModel().removeChangeListener(menuChangeListener);
			menuChangeListener = null;
		}
		
	}

	public static final class Info implements Serializable {

		// private

		private static final BasicStroke BORDER_STROKE = new BasicStroke(1);
		private final Color background;
		private final Color foreground;
		private static final Font KEYSTROKE_FONT = new Font(Font.DIALOG, Font.BOLD, UI.getDefaultFontSize() + 2);
		private KeyStroke keyStroke;
		private final String text;
		private final WeakReference<JComponent> componentRef;

		// public

		public void draw(final MWhatsThis whatsThisComponent, final Graphics2D g) {
			JComponent c = componentRef.get();
			
			if (c == null)
				return;
			
			if (
				!c.isVisible() ||
				!c.isShowing() ||
				((c instanceof MMenuBar) && MMenuBar.class.cast(c).isMinimized())
			)
				return;

			Rectangle r = MScrollPane.convertRectangle(whatsThisComponent, c);
			int margin = 2;
			r.x += margin;
			r.y += margin;
			r.width -= margin * 2;
			r.height -= margin * 2;

			// background
			g.setColor(background);
			g.fillRoundRect(r.x, r.y, r.width, r.height, 5, 5);

			// text
			g.setFont(FONT);
			UI.paintText(0, g, r, null, foreground, text.split("\n")); // do not use TK.fastSplit
			
			// border
			g.setColor(foreground);
			g.setStroke(BORDER_STROKE);
			g.drawRoundRect(r.x, r.y, r.width, r.height, 5, 5);

			// key stroke
			if (keyStroke != null) {
				int padding = 2;
				g.setFont(KEYSTROKE_FONT);
				FontMetrics fm = g.getFontMetrics();
				String keyStrokeText = UI.toString(keyStroke);
				Rectangle bounds = fm.getStringBounds(keyStrokeText, g).getBounds();
				bounds.x = r.x + r.width - bounds.width - 6;
				bounds.y = r.y + 3;

				g.setColor(Color.WHITE);
				g.fill3DRect(bounds.x, bounds.y, bounds.width + padding * 2, bounds.height + padding * 2, true);

				g.setColor(Color.BLACK);
				g.drawString(keyStrokeText, bounds.x + padding, bounds.y + fm.getAscent() + padding);
			}
		}

		/**
		 * Returns the associated keyboard shortcut or @c null.
		 *
		 * @since 3.8
		 */
		public KeyStroke getKeyStroke() { return keyStroke; }

		/**
		 * @since 3.2
		 */
		public void setKeyStroke(final int keyCode) {
			setKeyStroke(keyCode, 0);
		}

		/**
		 * @since 3.2
		 */
		public void setKeyStroke(final int keyCode, final int modifiers) {
			keyStroke = KeyStroke.getKeyStroke(keyCode, modifiers);
		}

		/**
		 * @since 5.2
		 */
		public void setKeyStroke(final KeyStroke value) { keyStroke = value; }

		/**
		 * @since 3.8
		 */
		public String getText() { return text; }

		// private
		
		private Info(final JComponent component, final String text, final Color background, final Color foreground) {
			componentRef = new WeakReference<>(component);
			this.text = text;
			this.background = background;
			this.foreground = foreground;
		}

	}

}
