// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Window;
import java.lang.ref.WeakReference;
import javax.swing.Icon;
import javax.swing.JComponent;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.form.PropertyPanel;
import org.makagiga.commons.mv.MRenderer;

/**
 * A settings page.
 * 
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MSettingsPage extends PropertyPanel implements MRenderer.Renderable {
	
	// package protected
	
	boolean initDone;
	
	// private
	
	private boolean needRestart;
	private Icon icon;
	private int dialogFlags = MDialog.STANDARD_DIALOG;
	private String text;
	private WeakReference<Window> parentWindowRef;

	// public

	/**
	 * Constructs a settings page.
	 */
	public MSettingsPage() {
		this(i18n("Settings"), MIcon.stock("ui/configure"));
	}

	/**
	 * @since 4.2
	 */
	public MSettingsPage(final MSettingsPage parent) {
		this(parent.getText(), parent.getIcon());
	}

	/**
	 * Constructs a settings page.
	 * 
	 * @param text The page title (e.g. "My Settings")
	 */
	public MSettingsPage(final String text) {
		this(text, (Icon)null);
	}

	/**
	 * Constructs a settings page.
	 * 
	 * @param text The page title (e.g. "My Settings")
	 * @param icon The icon (can be @c null)
	 */
	public MSettingsPage(final String text, final Icon icon) {
		super(DEFAULT_CONTENT_MARGIN);
		setAutoUpdateModel(false);
		setIcon(icon);
		setText(text);
	}

	/**
	 * Constructs a settings page.
	 * 
	 * @param text The page title (e.g. "My Settings")
	 * @param iconName The icon name (e.g. "ui/misc")
	 */
	public MSettingsPage(final String text, final String iconName) {
		this(text, MIcon.stock(iconName));
	}

	/**
	 * Returns a page with <i>advanced</i> settings.
	 *
	 * @mg.default {@code null}
	 *
	 * @since 4.2
	 */
	public MSettingsPage createAdvancedPage() { return null; }

	/**
	 * @since 5.0
	 */
	public MSettingsDialog createDialog(final Window owner) {
		return MSettingsDialog.createDialog(owner, this);
	}

	/**
	 * @since 3.2
	 */
	public boolean exec(final Window owner) {
		return MSettingsDialog.execPage(owner, this, null);
	}

	/**
	 * @since 3.4
	 */
	public boolean exec(final Window owner, final JComponent defaultFocus) {
		return MSettingsDialog.execPage(owner, this, defaultFocus);
	}
	
	/**
	 * @since 3.8.12
	 */
	public int getDialogFlags() { return dialogFlags; }

	/**
	 * @since 3.8
	 */
	public void setDialogFlags(final int value) { dialogFlags = value; }

	public Icon getIcon() { return icon; }

	/**
	 * @since 4.2
	 */
	public void setIcon(final Icon icon) {
		this.icon = (icon == null) ? MIcon.stock("ui/configure") : icon;
	}

	public boolean getNeedRestart() { return needRestart; }
	
	public void setNeedRestart(final boolean value) { needRestart = value; }
	
	public String getText() { return text; }
	
	/**
	 * @since 4.2
	 */
	public void setText(final String value) { text = value; }

	/**
	 * Overriden to return the page title.
	 * 
	 * @see #getText()
	 */
	@Important
	@Override
	public String toString() { return text; }

	// MRenderer.Renderable

	/**
	 * @since 3.6
	 */
	@Override
	public void setupRenderer(final MRenderer<?> r) {
		r.setIcon(getIcon());
		r.setText(getText());
	}

	// protected

	protected Window getParentWindow() {
		return TK.get(parentWindowRef);
	}

	protected void setParentWindow(final Window value) {
		parentWindowRef = (value == null) ? null : (new WeakReference<>(value));
	}

	/**
	 * Invoked on dialog close.
	 *
	 * @since 3.8
	 */
	protected void onClose() { }

	/**
	 * Invoked when the settings page is added to the settings dialog.
	 * Read settings from a configuration file and assign them to the components.
	 */
	protected void onInit() { }

	/**
	 * Invoked when the user clicked on the "OK" button.
	 * Read values from components and write them to a configuration file.
	 */
	protected void onOK() { }
	
	// package protected
	
	PropertyPanel getMainPropertyPanel() {
		if (
			// HACK: support for plugin options panel...
			(getComponentCount() == 1) &&
			(getComponent(0) instanceof PropertyPanel)
		)
			return (PropertyPanel)getComponent(0);

		return this;
	}
	
	void initOnDemand() {
		if (initDone)
			return;
		
		initDone = true;
		onInit();
		
		PropertyPanel mainPanel = getMainPropertyPanel();
		mainPanel.alignLabels();
/*
		if (mainPanel.hasEditors()) {
			mainPanel.addGap();
			
			MSmallButton revertButton = new MSmallButton(mainPanel.createDefaultsAction(), false);
			MPanel revertPanel = MPanel.createBorderPanel();
			revertPanel.addEast(revertButton);
			mainPanel.add(revertPanel);
		}
*/
	}

}
