// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.TK;

/**
 * @since 4.10
 */
public abstract class MTaskAction<T> extends MAction implements MDisposable {

	// private
	
	private MSwingWorker<T> worker;

	// public
	
	public MTaskAction(final String name, final String iconName) {
		super(name, iconName);
	}
	
	public MSwingWorker<T> getWorker() { return worker; }
	
	@Override
	public void onAction() {
		worker = TK.dispose(worker);
		
		worker = new MSwingWorker<T>(getSourceWindow(), getName(), MSwingWorker.Option.STATUS_ICON) {
			@Override
			protected T doInBackground() throws Exception {
				return MTaskAction.this.doInBackground();
			}
			@Override
			protected void onEnd() {
				MTaskAction.this.onEnd();
			}
			@Override
			protected void onSuccess(final T result) {
				MTaskAction.this.onSuccess(result);
			}
		};
		worker.start();
	}
	
	// MDisposable
	
	@Override
	public void dispose() {
		worker = TK.dispose(worker);
	}

	// protected
	
	protected abstract T doInBackground() throws Exception;

	protected void onEnd() { }

	protected void onSuccess(final T result) { }

}
