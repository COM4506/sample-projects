// Copyright 2012 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.lang.ref.WeakReference;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JRootPane;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;

import org.makagiga.commons.UI;

/**
 * A panel that can be used in a menu.
 *
 * @since 4.4
 */
public class MMenuElement extends MPanel implements MenuElement {

	// private
	
	private static final MenuElement[] NO_MENU_ELEMENTS = new MenuElement[0];

	// public
	
	public MMenuElement() { }
	
	public static MenuElement newMenuElement(final Component c) {
		return new Wrapper(c);
	}
	
	// MenuElement

	@Override
	public Component getComponent() { return this; }

	@Override
	public MenuElement[] getSubElements() { return NO_MENU_ELEMENTS; }

	@Override
	public void menuSelectionChanged(final boolean included) {
		menuSelectionChanged(this, included);
	}

	@Override
	public void processKeyEvent(final KeyEvent e, final MenuElement[] path, final MenuSelectionManager manager) { }

	@Override
	public void processMouseEvent(final MouseEvent e, final MenuElement[] path, final MenuSelectionManager manager) { }
	
	// private
	
	private static void menuSelectionChanged(final MenuElement element, final boolean included) {
		Component component = element.getComponent();

		// focus the first component
		if (included) {
			if (!(component instanceof Container))
				return;
			
			Container container = (Container)component;
			Component[] children = container.getComponents();
			if (children.length == 0) {
				if (container.isFocusable())
					container.requestFocus();
			}
			else {
				for (Component i : children) {
					if (i.isFocusable() && !(i instanceof JLabel) && !(i instanceof Box.Filler)) {
						i.requestFocus();
					
						break; // for
					}
				}
			}
		}
		// restore menu keyboard navigation
		else {
			JRootPane root = UI.getAncestorOfClass(JRootPane.class, component);
			if (root != null)
				root.requestFocus();
		}
	}

	// private classes

	private static final class Wrapper implements MenuElement {
	
		// private
		
		private final WeakReference<Component> componentRef;
	
		// public
		
		public Wrapper(final Component component) {
			componentRef = new WeakReference<>(component);
		}
	
		@Override
		public Component getComponent() {
			return componentRef.get();
		}
		
		@Override
		public MenuElement[] getSubElements() { return MMenuElement.NO_MENU_ELEMENTS; }
		
		@Override
		public void menuSelectionChanged(final boolean included) {
			MMenuElement.menuSelectionChanged(this, included);
		}
		
		@Override
		public void processKeyEvent(final KeyEvent e, final MenuElement[] path, final MenuSelectionManager manager) { }

		@Override
		public void processMouseEvent(final MouseEvent e, final MenuElement[] path, final MenuSelectionManager manager) { }

	}

}
