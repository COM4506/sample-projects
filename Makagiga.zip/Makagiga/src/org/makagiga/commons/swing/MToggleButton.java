// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.beans.ConstructorProperties;
import java.beans.EventHandler;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.style.StyleSupport;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MToggleButton extends JToggleButton
implements
	MIcon.Name,
	StyleSupport
{

	// private

	private UI.ToolTipLocationPolicy toolTipLocationPolicy = UI.ToolTipLocationPolicy.DEFAULT;
	
	// public
	
	public MToggleButton() {
		this(null, null);
	}
	
	/**
	 * @since 2.0
	 */
	public MToggleButton(final Action action) {
		super(action);
	}
	
	public MToggleButton(final Icon icon) {
		this(null, icon);
	}

	@ConstructorProperties("text")
	public MToggleButton(final String text) {
		this(text, null);
	}
	
	public MToggleButton(final String text, final Icon icon) {
		super(text, icon);
		addActionListener(e -> onClick());
// TODO: 2.0: MButton.installRolloverEffect(this);
	}

	@Override
	public Point getToolTipLocation(final MouseEvent e) {
		return
			(toolTipLocationPolicy == UI.ToolTipLocationPolicy.DEFAULT)
			? super.getToolTipLocation(e)
			: toolTipLocationPolicy.getLocation(this, e);
	}
	
	/**
	 * @since 4.2
	 */
	public UI.ToolTipLocationPolicy getToolTipLocationPolicy() { return toolTipLocationPolicy; }
	
	/**
	 * @since 4.2
	 */
	public void setToolTipLocationPolicy(final UI.ToolTipLocationPolicy value) {
		toolTipLocationPolicy = Objects.requireNonNull(value);
	}

	/**
	 * @since 3.0
	 */
	public Window getWindowAncestor() {
		return SwingUtilities.getWindowAncestor(this);
	}

	/**
	 * @since 3.0, 4.0 (returns {@code java.awt.event.ActionListener})
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public ActionListener onClick(final Object target, final String action) {
		ActionListener l = EventHandler.create(ActionListener.class, target, action);
		addActionListener(l);

		return l;
	}

	/**
	 * @since 3.4
	 */
	public void setCursor(final int type) {
		setCursor(Cursor.getPredefinedCursor(type));
	}

	/**
	 * @since 3.0, 4.0 (returns {@code java.awt.event.ActionListener})
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public ActionListener onSelect(final Object target, final String targetPropertyName) {
		ActionListener l = EventHandler.create(ActionListener.class, target, targetPropertyName, "source.selected");
		addActionListener(l);

		return l;
	}
	
	/**
	 * @since 4.4
	 */
	public void setSegmentPosition(final int position) {
		if (UI.isQuaqua() || UI.isSeaGlass()) {
			if (UI.isSeaGlass())
				putClientProperty("JButton.buttonType", "segmented");
		
			switch (position) {
				case LEFT:
					putClientProperty("JButton.segmentPosition", "first");
					break;
				case CENTER:
					putClientProperty("JButton.segmentPosition", "middle");
					break;
				case RIGHT:
					putClientProperty("JButton.segmentPosition", "last");
					break;
			}
		}
		else if (UI.isSubstance()) {
			try {
				// NOTE: The API is provided via external plugin so
				// it cannot be accessed directly.
				// http://insubstantial.github.io/insubstantial/substance/docs/clientprops/ButtonSideProperty.html
				Class<?> sideClass = Class.forName("org.pushingpixels.substance.api.SubstanceConstants$Side");
				Enum<?>[] enums = (Enum<?>[])sideClass.getEnumConstants();
				
				if (enums == null)
					return;
				
				Set<Enum<?>> openSideSet = new HashSet<>();
				Set<Enum<?>> sideSet = new HashSet<>();
				switch (position) {
					case LEFT:
						for (Enum<?> i : enums) {
							if (i.name().equals("RIGHT")) {
								openSideSet.add(i);
								sideSet.add(i);
								
								break; // for
							}
						}
						break;
					case CENTER:
						for (Enum<?> i : enums) {
							if (i.name().equals("LEFT")) {
								sideSet.add(i);
							}
							else if (i.name().equals("RIGHT")) {
								openSideSet.add(i);
								sideSet.add(i);
							}
						}
						break;
					case RIGHT:
						for (Enum<?> i : enums) {
							if (i.name().equals("LEFT")) {
								sideSet.add(i);
								
								break; // for
							}
						}
						break;
				}
				putClientProperty("substancelaf.buttonopenSide", openSideSet);
				putClientProperty("substancelaf.buttonside", sideSet);
			}
			catch (Exception exception) { // catch all
				MLogger.exception(exception);
			}
		}
	}

	// MIcon.Name

	/**
	 * @since 2.4
	 */
	@Override
	public String getIconName() {
		return MIcon.getName(getIcon());
	}

	/**
	 * @since 2.4
	 */
	@Override
	public void setIconName(final String value) {
		setIcon(MIcon.stock(value));
	}

	// StyleSupport

	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	@Obsolete
	protected void onClick() { }

}
