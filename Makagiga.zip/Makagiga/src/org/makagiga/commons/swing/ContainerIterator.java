// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Container;
import java.util.List;

import org.makagiga.commons.AbstractIterator;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.Property;

/**
 * A container iterator.
 * 
 * @mg.example
 * <pre class="brush: java">
 * // hide all buttons in this container
 * for (MButton button : new ContainerIterator&lt;&gt;(this, MButton.class))
 *   button.setVisible(false);
 * </pre>
 * 
 * @mg.note This class is <b>not</b> thread-safe.
 * 
 * @see ContainerScanner
 * @see java.awt.Container#getComponents()
 * 
 * @since 2.2, 4.0 (org.makagiga.commons.swing package)
 */
public class ContainerIterator<T extends Component> extends AbstractIterator<T> {
	
	// private
	
	private final List<T> list;
	
	// public
	
	/**
	 * Constructs a container iterator.
	 * 
	 * @param container The container to iterate
	 * @param clazz The type of component to list (@c null - list all)
	 * 
	 * @throws NullPointerException If @p container is @c null
	 */
	@SuppressWarnings("unchecked")
	public ContainerIterator(final Container container, final Class<T> clazz) {
		int count = container.getComponentCount();
		list = new MArrayList<>(count);
		if (count > 0) {
			for (int i = 0; i < count; i++) {
				Component c = container.getComponent(i);
				if ((clazz == null) || clazz.isInstance(c))
					list.add((T)c);
			}
		}
	}

	/**
	 * @since 3.8
	 */
	public static <T extends Component> List<T> findAll(final Container container, final Class<T> clazz) {
		final MArrayList<T> result = new MArrayList<>();
		new ContainerScanner(container) {
			@Override
			@SuppressWarnings("unchecked")
			public void processComponent(final Container parent, final Component c) {
				if ((clazz == null) || clazz.isInstance(c))
					result.add((T)c);
			}
		};

		return result;
	}

	/**
	 * @since 3.8.9
	 */
	public static Component findName(final Container container, final String name) {
		final Property<Component> result = new Property<>();
		new ContainerScanner(container) {
			@Override
			public void processComponent(final Container parent, final Component c) {
				if (name.equals(c.getName())) {
					result.set(c);

					stop();
				}
			}
		};

		return result.get();
	}

	@Override
	public T getObjectAt(final int index) {
		return list.get(index);
	}

	@Override
	public int getObjectCount() {
		return list.size();
	}

}
