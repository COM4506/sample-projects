// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Dimension;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;

import org.makagiga.commons.AbstractIterator;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Sortable;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;

/**
 * A combo box with mouse wheel support.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MComboBox<I> extends JComboBox<I>
implements
	Iterable<I>,
	MouseWheelListener,
	MText.TextFieldExtensions,
	Sortable<I>,
	UI.EventsControl,
	UI.MouseWheelEventsControl
{
	
	// private

	private BiConsumer<MComboBox<I>, I> eventHandler;
	private boolean compactSize;
	private boolean eventsEnabled = true;
	private boolean layingOut;
	private boolean mouseWheelEventsEnabled = true;
	private boolean wideList;

	// public

	/**
	 * Constructs a combo box with default model.
	 */
	public MComboBox() {
		this(new DefaultComboBoxModel<I>());
	}

	/**
	 * Constructs a combo box with @p model.
	 */
	public MComboBox(final ComboBoxModel<I> model) {
		super(model);
		
		addActionListener(e -> {
			if (eventsEnabled) {
				onSelect();
				if (eventHandler != null)
					eventHandler.accept(this, getSelectedItem());
			}
		} );
		addMouseWheelListener(this);
		MText.commonSetup(getTextField());
	}
	
	/**
	 * @since 4.2
	 */
	@SafeVarargs
	@SuppressWarnings("varargs")
	public MComboBox(final I... items) {
		this(new DefaultComboBoxModel<I>(items));
	}

	/**
	 * Adds all @p items.
	 * 
	 * @throws NullPointerException If @p items is @c null
	 * 
	 * @since 2.4
	 */
	public void addAllItems(final Collection<? extends I> items) {
		for (I i : items)
			addItem(i);
	}

	/**
	 * Adds all @p items.
	 * 
	 * @throws NullPointerException If @p items is @c null
	 * 
	 * @since 2.4
	 */
	@SafeVarargs
	public final void addAllItems(final I... items) {
		if (items.length > 0) {
			for (I i : items)
				addItem(i);
		}
	}
	
	@Override
	public void doLayout() {
		try {
			layingOut = true;
			super.doLayout();
		}
		finally {
			layingOut = false;
		}
	}

	/**
	 * @since 2.0
	 */
	@Override
	public boolean getEventsEnabled() { return eventsEnabled; }
	
	@Override
	public void setEventsEnabled(final boolean value) { eventsEnabled = value; }

	/**
	 * Overriden to limit component width/height.
	 */
	@Override
	public Dimension getMaximumSize() {
		Dimension pref = getPreferredSize();

		return new Dimension(
			compactSize ? pref.width : Integer.MAX_VALUE,
			pref.height
		);
	}

	/**
	 * @since 2.0
	 */
	@Override
	public boolean getMouseWheelEventsEnabled() { return mouseWheelEventsEnabled; }
		
	/**
	 * @since 2.0
	 */
	@Override
	public void setMouseWheelEventsEnabled(final boolean value) { mouseWheelEventsEnabled = value; }

	@Override
	public Dimension getMinimumSize() {
		if (compactSize)
			return new Dimension(10, super.getMinimumSize().height);
		
		return super.getMinimumSize();
	}

	/**
	 * Returns the selected item.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public I getSelectedItem() {
		return (I)super.getSelectedItem();
	}
	
	/**
	 * @since 5.0
	 */
	public boolean setSelectedItem(final Predicate<I> predicate) {
		for (I i : this) {
			if (predicate.test(i)) {
				setSelectedItem(i);
			
				return true;
			}
		}
		
		return false;
	}

	/**
	 * @since 5.0
	 */
	public boolean isCompactSize() { return compactSize; }

	/**
	 * @since 5.0
	 */
	public void setCompactSize(final boolean value) { compactSize = value; }

	@Override
	public Dimension getSize() {
		Dimension size = super.getSize();
		
		if (!wideList)
			return size;
		
		if (!layingOut) {
			size.width = Math.max(size.width, getPreferredSize().width);
			// suggested by TineQ
			size.width = Math.min(size.width, UI.getScreenSize().width);
		}
		
		return size;
	}

	/**
	 * Returns the selected item as string,
	 * or @c null if combo box is not in editable mode.
	 */
	@Override
	public String getText() {
		return isEditable() ? getTextField().getText() : null;
	}

	/**
	 * Sets the selected item text to {@code value}.
	 * Combo box must be in editable mode.
	 */
	@Override
	public void setText(final String value) {
		if (isEditable())
			getTextField().setText(value);
	}

	/**
	 * Returns the text field component associated with this combo box.
	 */
	@InvokedFromConstructor
	public JTextField getTextField() {
		return (JTextField)getEditor().getEditorComponent();
	}

	public boolean isWideList() { return wideList; }
	
	/**
	 * CREDITS: http://www.jroller.com/page/santhosh?entry=make_jcombobox_popup_wide_enough
	 */
	public void setWideList(final boolean value) { wideList = value; }

	/**
	 * Returns the iterator.
	 */
	@Override
	public Iterator<I> iterator() {
		if (isEmpty())
			return Collections.emptyIterator();

		return new AbstractIterator<>(getItemCount(), this::getItemAt);
	}

	/**
	 * A mouse wheel event handler.
	 * It selects the next/previous item in the list.
	 * @param e A mouse wheel event
	 */
	@Override
	public void mouseWheelMoved(final MouseWheelEvent e) {
		if (UI.isWeb())
			return;

		if (!mouseWheelEventsEnabled)
			return;
		
		if (!isEnabled())
			return;
		
		int count = getItemCount();

		if (count < 2)
			return;

		int index = getSelectedIndex();
		if (index == -1)
			index = 0;

		// select previous item
		if (e.getWheelRotation() < 0) {
			if (index > 0)
				setSelectedIndex(index - 1);
		}
		// select next item
		else {
			if (index < count - 1)
				setSelectedIndex(index + 1);
		}
		e.consume();
	}
	
	/**
	 * @since 5.0
	 */
	public void onSelect(final BiConsumer<MComboBox<I>, I> eventHandler) {
		if (this.eventHandler != null)
			MLogger.warning("core", "Replacing old onSelect handler: %s -> %s", this.eventHandler, eventHandler);
	
		this.eventHandler = eventHandler;
	}
	
	@Override
	public void setMaximumRowCount(final int value) {
		super.setMaximumRowCount((value == -1) ? getItemCount() : value);
	}

	@Override
	public void sort() {
		sort(null);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void sort(final Comparator<? super I> comparator) {
		ComboBoxModel<I> model = getModel();
		
		if ((model == null) || (model.getClass() != DefaultComboBoxModel.class))
			throw new UnsupportedOperationException("\"DefaultComboBoxModel\" expected");
		
		int count = model.getSize();

		if (count < 2)
			return;

		I[] array = (I[])new Object[count];
		for (int i = 0; i < count; ++i)
			array[i] = model.getElementAt(i);
		Arrays.sort(array, comparator);
		setModel(new DefaultComboBoxModel<>(array));
	}

	@Override
	public void updateUI() {
		// LafWidget.COMBO_BOX_NO_AUTOCOMPLETION
		if (UI.isSubstance())
			putClientProperty("lafwidgets.comboboxNoAutoCompletion", true);

		super.updateUI();
	}

	// common extensions
	
	/**
	 * @deprecated As of 2.2, replaced by {@link #setText(String)}
	 */
	@Deprecated
	@Override
	public void clear() {
		setText(null);
	}

	/**
	 * Returns {@code true} if combo box list is empty.
	 */
	@Obsolete // confusing name
	@Override
	public boolean isEmpty() {
		return getItemCount() == 0;
	}

	@Override
	public void makeDefault() {
		if (isEditable())
			MText.makeDefault(getTextField());
		else
			requestFocusInWindow();
	}

	// text completion

	@Override
	public String getAutoCompletion() {
		return MText.getAutoCompletionID(getTextField());
	}

	@Override
	public void saveAutoCompletion() {
		MText.saveAutoCompletion(getTextField());
	}
	
	@Override
	public void setAutoCompletion(final String id) {
		MText.installAutoCompletion(getTextField(), id);
	}

	// protected

	/**
	 * Invoked when selection changed.
	 */
	@Obsolete
	protected void onSelect() { }

}
