// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import java.util.EventObject;
import java.util.Objects;
import javax.swing.JPopupMenu;

import org.makagiga.commons.MApplication;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.OS;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public final class MSystemTray {
	
	// private
	
	private static boolean visible;
	private static Color background;
	private static Color textBackground;
	private static Color textColor;
	private static Dimension lastWindowSize;
	private static Image originalImage;
	private static String lastToolTip;
	private static String text;
	private static TrayIcon icon;
	
	// public
	
	/**
	 * Returns the icon background color or {@code null}.
	 *
	 * @since 4.0
	 */
	public synchronized static Color getBackground() { return background; }

	/**
	 * Sets the icon background color to {@code value} (can be {@code null}).
	 *
	 * @mg.note
	 * Since version 4.2 this works on all platforms.
	 *
	 * @since 4.0
	 */
	public synchronized static void setBackground(final Color value) { background = value; }

	public synchronized static TrayIcon getIcon() { return icon; }

	/**
	 * @since 5.6
	 */
	public static boolean isSupported() {
		// HACK: no system tray
		if (OS.isGNOME() || OS.isUnity())
			return false;

		return SystemTray.isSupported();
	}

	/**
	 * @since 2.0
	 */
	public synchronized static boolean isVisible() {
		return visible && (icon != null);
	}

	/**
	 * @since 4.10
	 */
	public synchronized static void setText(final String text, final Color textBackground, final Color textColor) {
		if (icon == null)
			return;
	
		if (
			!Objects.equals(text, MSystemTray.text) ||
			!Objects.equals(textBackground, MSystemTray.textBackground) ||
			!Objects.equals(textColor, MSystemTray.textColor)
		) {
			MSystemTray.text = text;
			MSystemTray.textBackground = textBackground;
			MSystemTray.textColor = textColor;
			
			Image newImage;
			if (TK.isEmpty(text)) {
				newImage = originalImage;
			}
			else {
				BufferedImage bi = UI.toBufferedImage(originalImage, false);
				MGraphics2D g = new MGraphics2D(bi);
				
				if (textBackground != null) {
					g.setColor(textBackground);
					g.fillRect();
				}
				
				g.setFont(Font.DIALOG, Font.BOLD, Math.min(bi.getHeight() - 1, 16));
				g.setTextAntialiasing(null);

				g.setColor(textColor);
				FontMetrics fm = g.getFontMetrics();
				g.drawStringCentered(text, 0, 0, bi.getWidth(), bi.getHeight(), fm);
				
				Color shadowColor = MColor.deriveAlpha(Color.GRAY, 127);
				g.setColor(shadowColor);
				g.drawStringCentered(text, 1, 1, bi.getWidth(), bi.getHeight(), fm);
				
				g.dispose();
				newImage = bi;
			}
			
			if (newImage != null)
				icon.setImage(newImage);
		}
	}
	
	/**
	 * @since 2.4
	 */
	public synchronized static void setToolTip(final String value) {
		lastToolTip = value;
		if (icon != null) {
			String text = value;
			
			String defaultToolTip = MApplication.getFullName();
			if (defaultToolTip != null) {
				if (text != null)
					text += (" - " + defaultToolTip);
				else
					text = defaultToolTip;
			}
			
			icon.setToolTip(text);
		}
	}

	public synchronized static void setVisible(final boolean value) {
		if (visible == value)
			return;
		
		visible = value;
		
		if (!isSupported()) {
			MLogger.warning("core", "System tray is not supported on this Platform/Desktop Environment");
			
			return;
		}

		SystemTray systemTray = SystemTray.getSystemTray();
		// show
		if (value) {
			Image image = MApplication.getLogo();
			if (image == null)
				image = MIcon.stock("ui/misc").getImage();
			
			// HACK: smooth icon
			Dimension traySize = systemTray.getTrayIconSize();
			image = UI.scaleImage(image, traySize.width, traySize.height, UI.Quality.HIGH);

/* FIXME: system tray on Linux and E17 is crappy:

This happen randomly:
* java.awt.AWTException: TrayIcon couldn't be displayed.
     [java]     at sun.awt.X11.XTrayIconPeer.<init>(XTrayIconPeer.java:268)

This happen even if it's supported:
* java.lang.UnsupportedOperationException: The system tray is not supported on the current platform.
     [java]     at java.awt.SystemTray.getSystemTray(SystemTray.java:186)
     [java]     at sun.awt.X11.XTrayIconPeer$4$1.run(XTrayIconPeer.java:225)

* E17: traySize always returns 24x24 which makes the icon very ugly
*/

			if (background != null) {
				BufferedImage bi = UI.createCompatibleImage(traySize.width, traySize.height, false);
				Graphics2D g = bi.createGraphics();
				g.setColor(background);
				g.fillRect(0, 0, bi.getWidth(), bi.getHeight());
				g.drawImage(image, 0, 0, null);
				g.dispose();
				image = bi;
			}
			originalImage = image;

			icon = new TrayIcon(image);
			icon.setImageAutoSize(false);
			setToolTip(lastToolTip);

			// handle keyboard support (Win+B + Space)
			if (OS.isWindows()) {
				icon.addActionListener(MSystemTray::handleEvent);
			}
			
			icon.addMouseListener(new MMouseAdapter() {
				@Override
				public void mouseClicked(final MouseEvent e) {
					MSystemTray.handleEvent(e);
				}
				@Override
				public void popupTrigger(final MouseEvent e) {
					MMainWindow mainWindow = MainView.getWindow();
					
					if ((mainWindow != null) && mainWindow.isLocked())
						return;
					
					MMenu menu = new MMenu();
					menu.addTitle(MApplication.getFullName(), MApplication.getSmallIcon());
					int itemCount = menu.getItemCount();
					
					if (mainWindow != null)
						mainWindow.onTrayIconMenuPopup(menu);
					
					if (menu.getItemCount() > itemCount)
						menu.addSeparator();
					menu.add(MApplication.getQuitAction());
					menu.addSeparator();
					menu.addCloseMenuItem();

					// CREDITS: http://weblogs.java.net/blog/ixmal/archive/2006/05/using_jpopupmen.html
					JPopupMenu popup = menu.getPopupMenu();
					popup.setLocation(e.getPoint());
					popup.setInvoker(popup);
					popup.setVisible(true);
				}
			} );
			try {
				systemTray.add(icon);
			}
			catch (AWTException exception) {
				MLogger.exception(exception);
				MLogger.warning("core", "System tray is not supported on this platform");
				
				visible = false;
				if (icon != null) {
					systemTray.remove(icon);
					icon = null;
				}
			}
		}
		// hide
		else {
			if (icon != null) {
				systemTray.remove(icon);
				icon = null;
			}
		}
	}

	// private
	
	@Uninstantiable
	private MSystemTray() {
		TK.uninstantiable();
	}
	
	private static void handleEvent(final EventObject event) {
		// do not "dispose" active modal dialogs
		if (Arrays.stream(MWindow.getWindows())
			.anyMatch(window -> (window instanceof Dialog) && window.isVisible())
		) {
			MLogger.debug("core", "A modal dialog is active - ignoring event");
			TK.beep();
		
			return;
		}
	
		MMainWindow mainWindow = MainView.getWindow();
		
		if (
			(mainWindow != null) &&
			(event instanceof MouseEvent) &&
			mainWindow.onTrayIconClick((MouseEvent)event)
		) {
			return;
		}
		
		if (
			(mainWindow != null) &&
			(
				((event instanceof MouseEvent) && MMouseAdapter.isLeft((MouseEvent)event)) ||
				(event instanceof ActionEvent)
			)
		) {
			if (mainWindow.isVisible()) {
				lastWindowSize = mainWindow.getSize();
				mainWindow.setVisible(false);
				mainWindow.fireWindowIconified();
			}
			else {
				mainWindow.restore();
				// HACK: fix window size after restore
				if (lastWindowSize != null) {
					mainWindow.setSize(lastWindowSize);
					lastWindowSize = null;
				}
			}
		}
	}
	
}
