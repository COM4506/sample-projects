// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.util.Collections;
import java.util.List;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.JRootPane;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * Access to the main view UI components.
 *
 * @since 3.8.1, 4.0 (org.makagiga.commons.swing package)
 */
public final class MainView {
	
	// private

	private static MMainWindow mainWindow;
	private static MStatusBar statusBar;

	// public

	/**
	 * @since 3.8.3
	 */
	public static void bind(final Action... actions) {
		JRootPane rp = mainWindow.getRootPane();
		for (Action i : actions)
			MAction.connect(rp, JRootPane.WHEN_IN_FOCUSED_WINDOW, i);
	}

	/**
	 * @since 3.8.6
	 */
	public static List<Action> getBindList() {
		JRootPane rp = mainWindow.getRootPane();
		ActionMap actionMap = rp.getActionMap();
		Object[] keys = actionMap.keys();

		if (keys == null)
			return Collections.emptyList();

		MArrayList<Action> result = new MArrayList<>(keys.length);
		for (Object i : keys) {
			Action a = actionMap.get(i);
			if (a != null)
				result.add(a);
		}

		return result;
	}

	public static MStatusBar getStatusBar() { return statusBar; }

	public static MMainWindow getWindow() { return mainWindow; }

	// private

	@Uninstantiable
	private MainView() {
		TK.uninstantiable();
	}
	
	// package
	
	static void init(final MMainWindow mainWindow, final MStatusBar statusBar) {
		MainView.mainWindow = mainWindow;
		MainView.statusBar = statusBar;
	}

}
