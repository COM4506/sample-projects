// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Window;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.ref.WeakReference;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import javax.swing.SwingWorker;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.PassiveException;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;

/**
 * A simplified {@link javax.swing.SwingWorker}.
 *
 * @since 3.8.8, 4.0 (org.makagiga.commons.swing package)
 */
public abstract class MSwingWorker<T> implements MDisposable {

	// public

	public enum Option { STATUS_ICON, WAIT_CURSOR }
	
	// private

	private MSmallButton statusButton;
	private PropertyChangeListener pcl;
	private final Set<Option> options;
	private final String title;
	private transient volatile SwingWorker<T, Void> worker;
	private WeakReference<Object> ownerRef;
	
	// public

	public MSwingWorker(final String title) {
		this(null, title);
	}

	public MSwingWorker(final Object owner, final String title) {
		this(owner, title, (Option[])null);
	}

	/**
	 * @since 4.0
	 */
	public MSwingWorker(final Object owner, final String title, final Option... options) {
		ownerRef = new WeakReference<>(owner);
		this.title = TK.checkNullOrEmpty(title);
		this.options = TK.newEnumSet(options);

		pcl = new PropertyChangeListener() {
			@Override
			public void propertyChange(final PropertyChangeEvent e) {
				String name = e.getPropertyName();
				if ("state".equals(name)) {
					SwingWorker.StateValue state = (SwingWorker.StateValue)e.getNewValue();
					switch (state) {
						case DONE:
							setCursor(Cursor.DEFAULT_CURSOR);
							setStatusIconVisible(false);
							SwingWorker.class.cast(e.getSource()).removePropertyChangeListener(this);
							break;
						//case PENDING:
						//	break;
						case STARTED:
							setCursor(Cursor.WAIT_CURSOR);
							setStatusIconVisible(true);
							break;
					}
				}
			}
		};
	}

	public synchronized void abort() {
		if (worker != null) {
			if (!worker.cancel(true))
				worker.removePropertyChangeListener(pcl);
			worker = null;
		}
	}

	public synchronized void start() {
		abort();

		worker = new SwingWorker<T, Void>() {
			@Override
			protected T doInBackground() throws Exception {
				return MSwingWorker.this.doInBackground();
			}
			@Override
			protected void done() {
				boolean cancelled = this.isCancelled();
				try {
					if (cancelled)
						throw new PassiveException(i18n("Cancelled: {0}", MSwingWorker.this.title));

					MSwingWorker.this.onSuccess(this.get());
				}
				catch (ExecutionException exception) {
					MSwingWorker.this.onError(exception.getCause(), cancelled);
				}
				catch (Exception exception) {
					MSwingWorker.this.onError(exception, cancelled);
				}
				finally {
					MSwingWorker.this.onEnd();
					MSwingWorker.this.worker = null;
				}
			}
		};
		worker.addPropertyChangeListener(pcl);
		worker.execute();
	}

	// MDisposable

	/**
	 * @since 4.0
	 */
	@Override
	public synchronized void dispose() {
		abort();

		pcl = null;
		ownerRef = TK.dispose(ownerRef);

		removeStatusIcon();
	}

	// protected

	protected abstract T doInBackground() throws Exception;

	protected synchronized Object getOwner() {
		return TK.get(ownerRef);
	}

	protected void onEnd() { }

	protected void onError(final Throwable throwable, final boolean cancelled) {
		Object owner = getOwner();
		Window ownerWindow =
			(owner instanceof Component)
			? UI.windowFor((Component)owner)
			: null;

		MMessage.error(ownerWindow, throwable);
	}

	protected abstract void onSuccess(final T result);

	// private

	private void removeStatusIcon() {
		if (statusButton != null) {
			statusButton.setVisible(false);

			MStatusBar statusBar = MainView.getStatusBar();
			statusBar.removeButton(statusButton);
			statusButton = null;
			
			// restore status bar visibility on last button hide
			if ((statusBar.getButtonPanel().getComponentCount() == 0) && statusBar.isClosed())
				statusBar.setVisible(false);
		}
	}

	private void setCursor(final int cursor) {
		if (!options.contains(Option.WAIT_CURSOR))
			return;

		Object owner = getOwner();
		if (owner instanceof Component)
			Component.class.cast(owner).setCursor(Cursor.getPredefinedCursor(cursor));
	}

	private void setStatusIconVisible(final boolean visible) {
		if (!options.contains(Option.STATUS_ICON))
			return;

		if (visible) {
			if (statusButton == null) {
				statusButton = new MSmallButton(new MAction(i18n("Cancel: {0}", title), "ui/stop") {
					@Override
					public void onAction() {
						MSwingWorker.this.abort();
					}
				}, false);
				
				MStatusBar statusBar = MainView.getStatusBar();
				statusBar.addButton(statusButton);
				statusBar.setVisible(true);
			}
		}
		else {
			removeStatusIcon();
		}
	}

}
