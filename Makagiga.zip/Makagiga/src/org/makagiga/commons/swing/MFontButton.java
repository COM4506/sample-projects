// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Font;
import java.util.Objects;
import java.util.StringJoiner;

import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.html.HTMLBuilder;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MFontButton extends MButton implements ValueChooser<Font> {

	// public
	
	/**
	 * @since 5.6
	 */
	public static final String NO_TEXT_LABEL = "MFontButton.NO_TEXT_LABEL";
	
	// private
	
	private Font selectedFont;
	private final String textLabel;
	
	// public
	
	public MFontButton() {
		this(null, null);
	}
	
	public MFontButton(final Font defaultFont) {
		this(null, defaultFont);
	}
	
	/**
	 * @since 2.4
	 */
	public MFontButton(final String textLabel, final Font defaultFont) {
		this.textLabel = textLabel;

		if (UI.buttonIcons.get())
			setIcon(MActionInfo.CHOOSE_FONT.getSmallIcon());
		setValue(defaultFont);
		setToolTipText(MActionInfo.CHOOSE_FONT.getDialogTitle());
	}

	/**
	 * @since 2.4, 5.6 (public)
	 */
	public void fireValueChanged(final Font oldFont, final Font newFont) {
		TK.fireValueChanged(this, getValueListeners(), oldFont, newFont);
	}

	// ValueChooser
	
	/**
	 * @since 2.4
	 */
	@Override
	public void addValueListener(final ValueListener<Font> l) {
		listenerList.add(ValueListener.class, l);
	}

	/**
	 * @since 2.4
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ValueListener<Font>[] getValueListeners() {
		return listenerList.getListeners(ValueListener.class);
	}

	/**
	 * @since 2.4
	 */
	@Override
	public void removeValueListener(final ValueListener<Font> l) {
		listenerList.remove(ValueListener.class, l);
	}

	/**
	 * @since 3.8.12
	 */
	@Override
	public Font getValue() { return selectedFont; }

	/**
	 * @since 3.8.12
	 */
	@Override
	public void setValue(final Font value) {
		Font defaultFont = UI.getFont(this);
		Font newValue = (value == null) ? defaultFont : value;
		if (!Objects.equals(selectedFont, newValue)) {
			Font oldValue = selectedFont;
			selectedFont = newValue;
			firePropertyChange(VALUE_PROPERTY, oldValue, newValue);
			
			// update button texts
			
			String name = selectedFont.getName();
			int size = selectedFont.getSize();
			int style = selectedFont.getStyle();
			
			HTMLBuilder html = new HTMLBuilder();
			
			StringJoiner cssStyle = new StringJoiner("; ");
			cssStyle.add("font-family: " + name);
			cssStyle.add("font-size: " + TK.limit(size, UI.getMinimumFontSize(), 24));
			if ((style & Font.BOLD) != 0)
				cssStyle.add("font-weight: bold");
			if ((style & Font.ITALIC) != 0)
				cssStyle.add("font-style: italic");

			html.beginTag("html");
			html.doubleTag("p", html.escape(MActionInfo.CHOOSE_FONT.getText()));
			html.doubleTag(
				"span",
				html.escape(name) + " " + size,
				"style", cssStyle
			);
			html.endTag("html");
			setToolTipText(html.toString());
			
			StringBuilder text = new StringBuilder();
			if (!NO_TEXT_LABEL.equals(textLabel)) {
				text.append(Objects.toString(textLabel, MActionInfo.CHOOSE_FONT.getText()));
				text.append(" - ");
			}
			text.append(name);
			text.append(' ');
			text.append(size);
			setText(text.toString());
			
			setFont(UI.deriveFontStyle(defaultFont, style));
		}
	}
	
	// protected

	@Override
	protected void onClick() {
		Font oldFont = getValue();
		Font newFont = Input.getFont(getWindowAncestor(), oldFont);
		if (newFont != null) {
			setValue(newFont);
			fireValueChanged(oldFont, getValue());
		}
	}

}
