// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Window;
import java.awt.event.MouseEvent;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.UI;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 5.6
 */
public class MPlusMinusPanel extends MPanel {

	// private
	
	private final AutoRepeat minusAutoRepeat = new AutoRepeat();
	private final AutoRepeat plusAutoRepeat = new AutoRepeat();
	private final MSmallButton minusButton;
	private final MSmallButton plusButton;

	// public

	public MPlusMinusPanel() {
		this(MIcon.Size.SMALL);
	}

	public MPlusMinusPanel(final MIcon.Size size) {
		super(UI.HORIZONTAL);
		setOpaque(false);

		minusButton = new MSmallButton(ShapeIcon.MINUS.resized(size), i18n("Decrement"));
		minusButton.setFocusable(false);
		add(minusButton);

		plusButton = new MSmallButton(ShapeIcon.PLUS.resized(size), i18n("Increment"));
		plusButton.setFocusable(false);
		add(plusButton);
	}

	@Override
	public void addNotify() {
		super.addNotify();
		minusAutoRepeat.install(minusButton);
		plusAutoRepeat.install(plusButton);
	}

	@Override
	public void removeNotify() {
		super.removeNotify();
		minusAutoRepeat.uninstall();
		plusAutoRepeat.uninstall();
	}

	public MSmallButton getMinusButton() { return minusButton; }

	public MSmallButton getPlusButton() { return plusButton; }

	// private classes
	
	private static final class AutoRepeat extends MMouseAdapter {
	
		// private
		
		private MSmallButton button;
		private final MTimer timer;
	
		// public
		
		public AutoRepeat() {
			timer = MTimer.milliseconds(200, self -> {
				Window window = button.getWindowAncestor();

				if ((window == null) || !window.isActive())
					return MTimer.STOP;

				button.doClick(0);
				
				return MTimer.CONTINUE;
			} );
		}
		
		public void install(final MSmallButton button) {
			if (this.button == null) {
				this.button = button;
				button.addMouseListener(this);
			}
		}

		public void uninstall() {
			if (button != null) {
				button.removeMouseListener(this);
				button = null;
			}
			timer.stop();
		}

		// MouseListener

		@Override
		public void mouseExited(final MouseEvent e) {
			timer.stop();
		}

		@Override
		public void mousePressed(final MouseEvent e) {
			if (e.getComponent().isEnabled()) {
				timer.start();
				e.consume();
			}
		}

		@Override
		public void mouseReleased(final MouseEvent e) {
			if (timer.isRunning()) {
				timer.stop();
				e.consume();
			}
		}

	}

}
