// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Cursor;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.swing.BorderFactory;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.DateFormatter;

import org.makagiga.commons.DT;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MCalendar;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MDate;
import org.makagiga.commons.UI;

/**
 * A date spinner (date/time editor).
 *
 * @mg.note
 * Since version 4.0 this class uses {@link java.util.Date} instead of {@link MDate}.
 *
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MDateSpinner extends AbstractSpinner<SpinnerDateModel, java.util.Date> {

	// public

	/**
	 * Constructs a date spinner
	 * with @c SpinnerDateModel and @c MSpinner.DateEditor.
	 */
	public MDateSpinner() {
		this(true);
	}
	
	/**
	 * @deprecated Since 4.2
	 */
	@Deprecated
	public MDateSpinner(final boolean userMenu) {
		super(new SpinnerDateModel());
		setEditor(new DateEditor(this));
		setupEditor();
		if (userMenu)
			setupUserActions();
		
		JTextField tf = getTextField();
		tf.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
		
		MHighlighter.install(tf, (highlighter, textComponent, text) -> { } )
			.setHighlightFields(true);
	}
	
	public void clearDate() {
		setDate(MDate.invalid());
	}
	
	/**
	 * @since 3.8.6
	 */
	public MCalendarPanel createMenuCalendarPanel(final MMenu hostMenu) {
		MCalendarPanel calendar = new MCalendarPanel(toDate()) {
			@Override
			protected MMenu onClick(final int day) {
				MCalendar c = MCalendar.of(super.getValue());
				// copy old time
				c.setTime(MCalendar.of(MDateSpinner.this.getDate()));
				MDateSpinner.this.setDate(c.toDate());

				hostMenu.setPopupMenuVisible(false);
				MDateSpinner.this.requestFocusInWindow();

				return null;
			}
		};
		calendar
			.getDateSpinner()
				.getTextField()
					.putClientProperty(MText.NO_GLOBAL_MENU, true);
		calendar.setBorder(BorderFactory.createLineBorder(MColor.WHITE, 2));
		calendar.setMonthMenuButtonVisible(false);
		calendar.setShowInfo(false);

		return calendar;
	}

	/**
	 * @since 4.0
	 */
	public java.util.Date getDate() {
		return getModel().getDate();
	}

	/**
	 * @since 4.0
	 */
	public void setDate(final java.util.Date value) {
		getModel().setValue(value);
	}

	public void setDateFormat(final int dateStyle) {
		setFormat(DateFormat.getDateInstance(dateStyle));
	}

	/**
	 * Sets date/time format to @p dateStyle and @p timeStyle.
	 */
	public void setDateTimeFormat(final int dateStyle, final int timeStyle) {
		setFormat(DateFormat.getDateTimeInstance(dateStyle, timeStyle));
	}
	
	public void setFormat(final DateFormat value) {
		DateFormatter formatter = (DateFormatter)getTextField(this).getFormatter();
		formatter.setFormat(value);

		// force view update
		ChangeEvent e = new ChangeEvent(getModel());
		for (ChangeListener i : getModel().getChangeListeners())
			i.stateChanged(e);
	}

	/**
	 * Sets date/time format to @p pattern.
	 * @see java.text.SimpleDateFormat
	 */
	public void setSimpleFormat(final String pattern) {
		setFormat(new SimpleDateFormat(pattern));
	}

	public void setTimeFormat(final int timeStyle) {
		setFormat(DateFormat.getTimeInstance(timeStyle));
	}

	/**
	 * @since 3.8.11
	 */
	public MCalendar toCalendar() {
		return MCalendar.of(getDate());
	}
	
	/**
	 * @since 4.0
	 */
	public MDate toDate() {
		return new MDate(getDate());
	}

	/**
	 * @since 5.2
	 */
	public LocalDate toLocalDate() {
		return DT.toLocalDate(getDate());
	}

	/**
	 * @since 5.2
	 */
	public LocalDateTime toLocalDateTime() {
		return DT.toLocalDateTime(getDate());
	}

	// private
	
	private void addField(final int field, final int value) {
		MCalendar c = MCalendar.of(getDate());
		c.add(field, value);
		setDate(c.toDate());
	}
	
	private void setupUserActions() {
		MText.setUserMenu(getTextField(), (textComponent, menu) -> setupUserMenu(menu));
	}
	
	private void setupUserMenu(final MMenu menu) {
		MMenu setDateTimeMenu = new MMenu(MActionInfo.SET_DATE_TIME.withDialogTitle());

		setDateTimeMenu.add(new MAction(MActionInfo.CURRENT_DATE_AND_TIME, action -> setDate(MDate.now())));

		setDateTimeMenu.add(new MAction(MActionInfo.NO_DATE_TIME, action -> clearDate()));

		setDateTimeMenu.addSeparator();

		setDateTimeMenu.add(new MAction(i18n("Next Day"), action -> addField(MCalendar.DAY_OF_MONTH, 1)));

		setDateTimeMenu.add(new MAction(i18n("Next Week"), action -> addField(MCalendar.DAY_OF_MONTH, 7)));

		setDateTimeMenu.add(new MAction(i18n("Next Month"), action -> addField(MCalendar.MONTH, 1)));

		setDateTimeMenu.add(new MAction(i18n("Next Year"), action -> addField(MCalendar.YEAR, 1)));

		menu.add(setDateTimeMenu);

		// do not show 2nd calendar
		MCalendarPanel parent = UI.getAncestorOfClass(MCalendarPanel.class, this);
		if (parent == null)
			menu.add(createMenuCalendarPanel(menu));
	}

}
