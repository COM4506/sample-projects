// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.beans.ConstructorProperties;
import java.util.EnumSet;
import java.util.Objects;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MRating extends MPanel implements ValueChooser<MRating.Star> {

	// public

	/**
	 * @since 4.0
	 */
	public enum Star {
	
		// public
	
		ZERO(0.0f, 0),
		ONE(0.2f, 1),
		TWO(0.4f, 2),
		THREE(0.6f, 3),
		FOUR(0.8f, 4),
		FIVE(1.0f, 5);
		
		// private
		
		private final float value;
		private final int count;
		
		// public

		/**
		 * @since 5.6
		 */
		public int getCount() { return count; }

		public boolean isSet() { return this != ZERO; }

		public static Star of(final float value) {
			if (value <= ZERO.value)
				return ZERO;

			if (value <= ONE.value)
				return ONE;

			if (value <= TWO.value)
				return TWO;

			if (value <= THREE.value)
				return THREE;

			if (value <= FOUR.value)
				return FOUR;

			return FIVE;
		}

		public float toFloat() { return value; }
		
		@Override
		public String toString() {
			return count + "/5";
		}
		
		// private
		
		private Star(final float value, final int count) {
			this.value = value;
			this.count = count;
		}
		
	}
	
	// private

	private boolean highlightEnabled = true;
	private static MIcon globalGrayStarIcon;
	private static MIcon globalStarIcon;
	private MSmallButton clearButton;
	private Star value;

	// public
	
	public MRating() {
		this(Star.ZERO);
	}

	/**
	 * @since 4.0
	 */
	@ConstructorProperties("value")
	public MRating(final Star value) {
		super(UI.HORIZONTAL);
		this.value = Objects.requireNonNull(value);
		setOpaque(false);
		
		StaticHandler handler = new StaticHandler();
		addMouseListener(handler);
		
		clearButton = new MSmallButton(MIcon.small("ui/clearright"), i18n("No Rating"));
		clearButton.addActionListener(e -> clicked(Star.ZERO));
		clearButton.addMouseListener(handler);
		clearButton.setToolTipLocationPolicy(UI.ToolTipLocationPolicy.ABOVE);
		clearButton.setVisible(false);
		add(clearButton);

		for (Star i : EnumSet.range(Star.ONE, Star.FIVE)) {
			RatingButton b = new RatingButton(i);
			b.addMouseListener(handler);
			add(b);
		}
		updateView();
	}
	
	/**
	 * @since 2.0
	 */
	public boolean isClearButtonVisible() {
		return clearButton.isVisible();
	}

	/**
	 * @since 2.0
	 */
	public void setClearButtonVisible(final boolean value) {
		clearButton.setVisible(value);
	}

	public boolean isHighlightEnabled() { return highlightEnabled; }
	
	public void setHighlightEnabled(final boolean value) { highlightEnabled = value; }

	@Override
	public void setEnabled(final boolean value) {
		super.setEnabled(value);
		clearButton.setEnabled(value);
		for (RatingButton button : new ContainerIterator<>(this, RatingButton.class))
			button.setEnabled(value);
	}
	
	public void setValue(final float value) {
		setValue(Star.of(value));
	}

	// ValueChooser

	/**
	 * @since 4.0
	 */
	@Override
	public void addValueListener(final ValueListener<MRating.Star> l) {
		listenerList.add(ValueListener.class, l);
	}

	/**
	 * @since 4.0
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ValueListener<MRating.Star>[] getValueListeners() {
		return listenerList.getListeners(ValueListener.class);
	}

	/**
	 * @since 4.0
	 */
	@Override
	public void removeValueListener(final ValueListener<MRating.Star> l) {
		listenerList.remove(ValueListener.class, l);
	}

	/**
	 * @since 4.0
	 */
	@Override
	public MRating.Star getValue() { return value; }

	/**
	 * @since 4.0
	 */
	@Override
	public void setValue(final MRating.Star value) {
		if (this.value != value) {
			Star oldValue = this.value;
			this.value = Objects.requireNonNull(value);
			updateView();
			firePropertyChange(VALUE_PROPERTY, oldValue, this.value);
		}
	}

	// private

	private void clicked(final Star newValue) {
		Star oldValue = value;
		setValue(newValue);
		repaint(); // fix icon repaint
		TK.fireValueChanged(this, getValueListeners(), oldValue, this.value);
	}

	private MIcon getGrayStarIcon() {
		if (globalGrayStarIcon == null)
			globalGrayStarIcon = getStarIcon().getDisabledInstance();
		
		return globalGrayStarIcon;
	}

	private MIcon getStarIcon() {
		if (globalStarIcon == null) {
			if (UI.isRetro())
				globalStarIcon = MIcon.small("ui/star");
			else
				globalStarIcon = MIcon.small("ui/star").getReflectionInstance();
		}
		
		return globalStarIcon;
	}
	
	private void highlight(final Star star) {
		for (RatingButton button : new ContainerIterator<>(this, RatingButton.class)) {
			if (isEnabled() && (button.star.compareTo(star) <= 0)) {
				button.setBackground(UI.getSelectionBackground());
				button.setOpaque(true);
			}
			else {
				button.setBackground(null);
				button.setOpaque(false);
			}
		}
	}

	private void updateView() {
		int count = 0;
		Star star = getValue();
		for (RatingButton i : new ContainerIterator<>(this, RatingButton.class)) {
			if (star.getCount() >= ++count)
				i.setIcon(getStarIcon());
			else
				i.setIcon(getGrayStarIcon());
			i.setDisabledIcon(i.getIcon());
		}
	}

	// private classes
	
	private static final class RatingButton extends MButton {
		
		// private
		
		private final Star star;
		
		// public

		@Override
		public void updateUI() {
			setUI(UI.getSimpleButtonUI());
		}
		
		// protected

		protected RatingButton(final Star star) {
			this.star = Objects.requireNonNull(star);
			setContentAreaFilled(false);
			setCursor(Cursor.HAND_CURSOR);
			setOpaque(false);
			setRequestFocusEnabled(false);
			setStyle("margin: 2; padding: 0");
			setToolTipLocationPolicy(UI.ToolTipLocationPolicy.ABOVE);
			setToolTipText(i18n("Click to select rating: {0}", star.toString()));
		}

		@Override
		protected void onClick() {
			UI.getAncestorOfType(MRating.class, this)
				.ifPresent(rating -> {
					if (rating.isEnabled())
						rating.clicked(star);
					else
						UI.beep();
				} );
		}

	}
	
	private static final class StaticHandler extends MMouseAdapter {
	
		// public
		
		public StaticHandler() { }

		@Override
		public void mouseEntered(final MouseEvent e) {
			Component c = e.getComponent();
			MRating rating = UI.getAncestorOfClass(MRating.class, c);
			
			if (rating == null)
				return;
			
			if (rating.highlightEnabled) {
				if (c instanceof MSmallButton)
					rating.highlight(Star.ZERO);
				else if (c instanceof RatingButton)
					rating.highlight(RatingButton.class.cast(c).star);
			}
		}

		@Override
		public void mouseExited(final MouseEvent e) {
			UI.getAncestorOfType(MRating.class, e.getComponent())
				.ifPresent(rating -> {
					// clear selection
					if (rating.highlightEnabled)
						rating.highlight(Star.ZERO);
				} );
		}

	}

}
