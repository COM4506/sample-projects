// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.beans.Beans;
import java.beans.ConstructorProperties;
import java.util.Objects;
import javax.swing.Icon;
import javax.swing.JComponent;

import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.Config;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MColor;
import org.makagiga.commons.TK;
import org.makagiga.commons.TriBoolean;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.beans.ContainerDelegate;
import org.makagiga.commons.painters.FlatPainter;
import org.makagiga.commons.painters.GlassPainter;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.border.MLineBorder;

/**
 * A toggleable panel.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTogglePanel extends MPanel {
	
	// private

	private boolean expanded;
	private boolean firstExpand = true;
	private static final int PADDING = 5;
	private final MLineBorder border;
	private Color buttonBackground;
	private Color buttonForeground;
	private ComponentAnimation toggleAnimation;
	private JComponent component;
	private JComponent componentPane;
	private String id;
	private ToggleButton titlePanel;

	// public

	/**
	 * Constructs a toggle panel.
	 */
	public MTogglePanel() {
		this(null, null, null, null, false);
		
		// add container delegate
		if (Beans.isDesignTime()) {
			componentPane = new MComponent();
			componentPane.setLayout(new BorderLayout());
			setComponent(componentPane);
		}
	}

	/**
	 * Constructs a toggle panel.
	 * @param icon The button icon
	 *
	 * @since 1.2
	 */
	public MTogglePanel(final Icon icon) {
		this(null, icon, null, null, false);
	}

	/**
	 * Constructs a toggle panel.
	 * @param text A title text (button text)
	 */
	@ConstructorProperties("text")
	public MTogglePanel(final String text) {
		this(text, null, null, null, false);
	}

	/**
	 * Constructs a toggle panel.
	 * @param text The button text
	 * @param icon The button icon
	 *
	 * @since 1.2
	 */
	public MTogglePanel(final String text, final Icon icon) {
		this(text, icon, null, null, false);
	}

	/**
	 * Constructs a toggle panel.
	 * @param text A title text (button text)
	 * @param component A component to display in the panel
	 */
	@ConstructorProperties({ "text", "component" })
	public MTogglePanel(final String text, final JComponent component) {
		this(text, null, component, null, false);
	}

	/**
	 * @since 2.4
	 */
	public MTogglePanel(final String text, final JComponent component, final String id, final boolean defaultExpanded) {
		this(text, null, component, id, defaultExpanded);
	}

	/**
	 * @since 2.4
	 */
	public MTogglePanel(final String text, final Icon icon, final JComponent component, final String id, final boolean defaultExpanded) {
		super(UI.VERTICAL);
		
		if (id != null)
			this.id = TK.validateID(id);

		border = new MLineBorder();
		Color borderColor = MColor.getContrast(UI.getBackground(this));
		for (MLineBorder.Style i : border) {
			if (i.getPosition() == MLineBorder.Position.TOP) {
				i.setVisible(false);
			}
			else {
				i.setColor(borderColor);
				i.setPadding(PADDING);
				i.setSize(1);
			}
		}
		setBorder(border);

		this.component = component;
		titlePanel = new ToggleButton(text, icon);
		add(titlePanel);
		if (component != null)
			add(component);

		if (id == null)
			setExpanded(defaultExpanded);
		else
			setExpanded(getConfigPrivileged().read("TogglePanel.expanded." + id, defaultExpanded));
	}

	/**
	 * @since 2.0
	 */
	public void addActionListener(final ActionListener l) {
		listenerList.add(ActionListener.class, l);
	}

	/**
	 * @since 2.0
	 */
	public ActionListener[] getActionListeners() {
		return listenerList.getListeners(ActionListener.class);
	}

	/**
	 * @since 2.0
	 */
	public void removeActionListener(final ActionListener l) {
		listenerList.remove(ActionListener.class, l);
	}

	@Obsolete
	public ToggleButton getButton() { return titlePanel; }
	
	public Color getButtonBackground() { return buttonBackground; }
	
	public void setButtonBackground(final Color value) {
		if (!Objects.equals(buttonBackground, value)) {
			buttonBackground = value;
			titlePanel.updateColors();
		}
	}

	public Color getButtonForeground() { return buttonForeground; }
	
	public void setButtonForeground(final Color value) {
		if (!Objects.equals(buttonForeground, value)) {
			buttonForeground = value;
			titlePanel.updateColors();
		}
	}

	public JComponent getComponent() { return component; }
	
	@InvokedFromConstructor
	public void setComponent(final JComponent value) {
		if (value != null)
			value.setVisible(expanded);
		
		MComponent.replace(
			((componentPane != null) && (componentPane != value))
				? componentPane
				: this,
			component,
			value,
			null,
			true
		);
		component = value;
	}
	
	/**
	 * @since 2.0
	 */
	@ContainerDelegate
	public Container getComponentPane() {
		if ((componentPane == null) && (component == null)) {
			componentPane = new MComponent();
			componentPane.setLayout(new BorderLayout());
			setComponent(componentPane);
		}

		return componentPane;
	}

	/**
	 * @since 3.8.6
	 */
	public String getID() { return id; }

	@Override
	public Dimension getMaximumSize() {
		Dimension d = super.getMaximumSize();

		return new Dimension(d.width, getPreferredSize().height);
	}

	/**
	 * @since 2.0
	 */
	@Obsolete
	public GlassPainter.RoundType getRoundType() {
		return titlePanel.button.getRoundType();
	}

	/**
	 * @since 2.0
	 */
	@Obsolete
	public void setRoundType(final GlassPainter.RoundType value) {
		titlePanel.button.setRoundType(value);
	}

	public String getText() {
		return titlePanel.button.getText();
	}

	public void setText(final String value) {
		titlePanel.button.setText(value);
	}

	@Override
	public String getToolTipText() {
		return titlePanel.button.getToolTipText();
	}

	@Override
	public void setToolTipText(final String value) {
		titlePanel.button.setToolTipText(value);
	}

	/**
	 * Returns @c true if panel is expaned.
	 */
	public boolean isExpanded() { return expanded; }

	/**
	 * Expands/collapses the panel.
	 *
	 * @param value If {@code true} the panel will be expanded, and the <i>main component</i> will be visible
	 *
	 * @since 2.0
	 */
	@InvokedFromConstructor
	public void setExpanded(final boolean value) {
		setExpanded(value, false);
	}

	/**
	 * @since 5.6
	 */
	public void setExpanded(final boolean value, final boolean animation) {
		if (!firstExpand && (value == expanded))
			return;

		firstExpand = false;
		expanded = value;
		titlePanel.setSelected(value, false);
		border.getBottom()
			.setPadding(value ? PADDING : 0);

		if (id != null) {
			MAccessController.doPrivileged(() -> {
				Config.getDefault().write("TogglePanel.expanded." + id, expanded);

				return null;
			} );
		}

		if (component == null)
			return;

		toggleAnimation = TK.dispose(toggleAnimation);

		if (animation) {
			Dimension from;
			Dimension to;

			component.setMaximumSize(null);
			component.setPreferredSize(null);
			Dimension prefSize = new Dimension(component.getPreferredSize());

			int minHeight = 0;

			if (value) {
				from = new Dimension(prefSize.width, minHeight);
				to = new Dimension(prefSize);

				component.setPreferredSize(from);
				component.setVisible(true);
			}
			else {
				from = new Dimension(prefSize);
				to = new Dimension(prefSize.width, minHeight);
			}

			prefSize.setSize(from);

			toggleAnimation = new ComponentAnimation(component)
				.duration(200)
// TODO: .ease(ComponentAnimation.EASE_OUT_SINE)
				.dimensionProperty(
					"prefSize",
					from, to,
					() -> prefSize,
					newValue -> {
						prefSize.setSize(newValue);
						component.setPreferredSize(newValue);
						revalidate();
					}
				)
				.onDone(self -> {
					toggleAnimation = TK.dispose(toggleAnimation);
					
					updateComponent(value, false);
					revalidate(); // "validate" is not enough
				} )
				.play();
		}
		else {
			updateComponent(value, true);
		}
	}

	// protected

	protected void fireActionPerformed() {
		TK.fireActionPerformed(this, getActionListeners());
	}

	// private

	private Config getConfigPrivileged() {
		SecurityManager sm = System.getSecurityManager();

		if (sm == null)
			return Config.getDefault();

		return MAccessController.doPrivileged(Config::getDefault);
	}

	private void updateComponent(final boolean visible, final boolean validate) {
		if (visible) {
			component.setMaximumSize(null);
			component.setPreferredSize(null);
		}
		else {
			component.setMaximumSize(new Dimension());
			component.setPreferredSize(new Dimension());
		}
		component.setVisible(visible);
		if (validate)
			validate();
	}

	private void toggled(final TriBoolean expand, final boolean animation) {
		boolean b = expand.isUndefined() ? !titlePanel.isSelected() : expand.isTrue();
		titlePanel.setSelected(b, true);
		setExpanded(b, animation);
		fireActionPerformed();
	}
	
	// public classes
	
	@Obsolete // rename
	public final class ToggleButton extends MPanel {
		
		// private
		
		private boolean selected;
		private Icon buttonIcon;
		private MMessageLabel button;
		
		// public
		
		public ToggleButton(final String text) {
			this(text, null);
		}
		
		/**
		 * @since 1.2
		 */
		public ToggleButton(final String text, final Icon icon) {
			if (icon == null) {
				button = new MMessageLabel(text);
				button.setDirection(MMessageLabel.Direction.RIGHT);
			}
			else {
				button = new MMessageLabel(text, icon);
				buttonIcon = icon;
			}
			button.setBackgroundPainted(false);
			button.setCursor(Cursor.HAND_CURSOR);
			button.setFocusable(true);
			
			FlatPainter painter = new FlatPainter();
			button.setPainter(painter);
			button.setStyle("margin: 2px");
			addCenter(button);
			
			UI.onKeyPressed(button, e -> {
				if (isEnabled() && MAction.isTrigger(e)) {
					e.consume();
					toggled(TriBoolean.UNDEFINED, true);
				}
			} );
			UI.onButtonClicked(button, e -> toggled(TriBoolean.UNDEFINED, true));
		}
		
		/**
		 * @since 2.0
		 */
		@Obsolete // unused? remove
		public void doClick(final boolean expand) {
			MTogglePanel.this.toggled(TriBoolean.of(expand), false);
		}

		@Override
		public Dimension getMaximumSize() {
			return new Dimension(Integer.MAX_VALUE, super.getPreferredSize().height);
		}

		public boolean isSelected() { return selected; }
		
		@Obsolete
		public void setSelected(final boolean value, final boolean animationUnused) {
			if (selected != value) {
				selected = value;
				updateColors();
				if (buttonIcon == null)
					button.setDirection(selected ? MMessageLabel.Direction.BOTTOM : MMessageLabel.Direction.RIGHT);
				button.setBackgroundPainted(selected);
				setMargin(0, 0, selected ? MTogglePanel.PADDING : 0, 0); // add bottom/separator margin
			}
		}
		
		// private
		
		private void updateColors() {
			Color bg;
			Color fg;

			if (selected) {
				bg = TK.get(MTogglePanel.this.buttonBackground, UI.getSelectionBackground());
				fg = TK.get(MTogglePanel.this.buttonForeground, UI.getSelectionForeground());
			}
			else {
				bg = UI.getBackground(this);
				fg = UI.getForeground(this);
			}

			button.setColor(bg, fg, false);
		}

	}
	
}
