// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.beans.ConstructorProperties;
import java.beans.EventHandler;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.function.Predicate;
import java.util.function.Supplier;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

import com.jhlabs.image.GammaFilter;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.fx.MTimeline;
import org.makagiga.commons.style.StyleSupport;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * A push button.
 *
 * @mg.example
 * <pre class="brush: java">
 * MButton button = new MButton("Hello");
 * button.addActionListener(e -&gt; ...);
 * </pre>
 *
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MButton extends JButton
implements
	MIcon.Name,
	StyleSupport
{
	
	// public

	/**
	 * @since 4.0
	 */
	public static final String SAFE_ACTION_ICON_PROPERTY = "org.makagiga.commons.swing.MButton.safeActionIcon";
	
	// private

	private boolean mouseHover;
	private boolean popupMenuArrowPainted = true;
	private boolean popupMenuEnabled;
	private boolean popupMenuVisible;
	private boolean rolloverEffectEnabled = true;
	private transient ComponentAnimation popupMenuArrowAnimation;
	private int minimumWidth = -1;
	private final Point arrowPoint1 = new Point();
	private final Point arrowPoint2 = new Point();
	private final Point arrowPoint3 = new Point();
	private static StaticHoverTimelineScenario hoverScenario;
	private static final StaticRolloverHandler staticRolloverHandler = new StaticRolloverHandler();
	private static final String ROLLOVER_ICON_PROPERTY = "org.makagiga.commons.swing.MButton.rollover";
	private static final String SAFE_ACTION_PROPERTY = "org.makagiga.commons.swing.MButton.safeAction";
	private Supplier<MMenu> popupMenuSupplier;
	private UI.ToolTipLocationPolicy toolTipLocationPolicy = UI.ToolTipLocationPolicy.DEFAULT;

	// public

	/**
	 * Constructs a button with empty text and no icon.
	 */
	public MButton() {
		this(null, (Icon)null);
	}

	/**
	 * Constructs a button.
	 * @param action An action (can be @c null)
	 */
	public MButton(final Action action) {
		super(action);
		init();
	}
	
	/**
	 * @since 3.0
	 */
	public MButton(final MActionInfo info) {
		this(info.getText(), info.getIconName());
	}

	/**
	 * @since 4.0
	 */
	public MButton(final MActionInfo info, final boolean forceIcon) {
		this(info.getText());
		if (forceIcon)
			setIconName(info.getIconName());
		else
			setIconNameUI(info.getIconName());
	}

	/**
	 * Constructs a button.
	 * @param icon An icon (can be @c null)
	 */
	public MButton(final Icon icon) {
		this(null, icon);
	}

	/**
	 * Constructs a button.
	 * @param text A text (can be @c null)
	 */
	@ConstructorProperties("text")
	public MButton(final String text) {
		this(text, (Icon)null);
	}

	/**
	 * Constructs a button.
	 * @param text A text (can be @c null)
	 * @param icon An icon (can be @c null)
	 */
	@ConstructorProperties({ "text", "icon" })
	public MButton(final String text, final Icon icon) {
		super(text, icon);
		init();
	}

	/**
	 * Constructs a button.
	 * 
	 * @param text the button text
	 * @param iconName the icon name (example: {@code "ui/ok"})
	 *
	 * @see #setIconName(String)
	 * @see #setText(String)
	 */
	@ConstructorProperties({ "text", "iconName" })
	public MButton(final String text, final String iconName) {
		this(text, MIcon.stock(iconName));
	}

	/**
	 * @since 3.8.6
	 */
	public boolean doPopupMenu() {
		if (isPopupMenuEnabled()) {
			if (popupMenuSupplier != null) {
				if (showMenu(popupMenuSupplier.get()))
					return true;
			}

			if (showMenu(onPopupMenu()))
				return true;

			JPopupMenu popupMenu = getComponentPopupMenu();
			if (popupMenu != null) {
				installArrowUpdater(popupMenu);
				Point p = getMenuLocation(popupMenu);
				MMenu.showPopup(popupMenu, getParent(), p.x, p.y);

				return true;
			}
		}

		return false;
	}
	
	/**
	 * @since 2.0
	 */
	@Override
	public String getIconName() {
		return MIcon.getName(getIcon());
	}

	/**
	 * @since 2.0
	 */
	@Override
	public void setIconName(final String value) {
		setIcon(MIcon.stock(value));
	}

	/**
	 * @since 3.8
	 */
	public void setIconNameUI(final String value) {
		if (UI.buttonIcons.get())
			setIconName(value);
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension d = super.getPreferredSize();
		
		if (minimumWidth == -1)
			return d;
		
		if (d.width < minimumWidth)
			d.width = minimumWidth;
		
		return d;
	}

	@Override
	public Point getToolTipLocation(final MouseEvent e) {
		return
			(toolTipLocationPolicy == UI.ToolTipLocationPolicy.DEFAULT)
			? super.getToolTipLocation(e)
			: toolTipLocationPolicy.getLocation(this, e);
	}
	
	/**
	 * @since 4.2
	 */
	public UI.ToolTipLocationPolicy getToolTipLocationPolicy() { return toolTipLocationPolicy; }
	
	/**
	 * @since 4.2
	 */
	public void setToolTipLocationPolicy(final UI.ToolTipLocationPolicy value) {
		toolTipLocationPolicy = Objects.requireNonNull(value);
	}

	@Override
	public String getToolTipText(final MouseEvent e) {
		Action action = getAction();
		
		String text = super.getToolTipText();
		if (UI.DYNAMIC_TOOL_TIP_TEXT.equals(text)) {
			text = getText();
			if ((text == null) && (action != null)) {
				text = MAction.getValue(action, Action.NAME, null);
				if (TK.isEmpty(text))
					text = MAction.getToolTipText(action);
			}
		}
		else if (Objects.equals(text, getText())) {
			// do not duplicate button text
			text = null;
		}

		if ("".equals(text))
			text = null;

		// append key stroke info

		KeyStroke keyStroke1 =
			(action == null)
			? null
			: (KeyStroke)MAction.getValue(action, Action.ACCELERATOR_KEY, null);

		StringJoiner keyStrokeString = null;
		if (keyStroke1 != null) {
			keyStrokeString = new StringJoiner(" | ", "(", ")");
			keyStrokeString.add(UI.toString(keyStroke1));

			KeyStroke keyStroke2 =
				(action == null)
				? null
				: (KeyStroke)MAction.getValue(action, MAction.ALTERNATE_ACCELERATOR_KEY, null);
			if ((keyStroke2 != null) && !keyStroke1.equals(keyStroke2))
				keyStrokeString.add(UI.toString(keyStroke2));
		}

		if (keyStrokeString != null) {
			if (text == null)
				return keyStrokeString.toString();

			int htmlEnd = text.lastIndexOf("</body>");
		
			// text/plain
			if (htmlEnd == -1)
				return text + "  " + keyStrokeString;
		
			// text/html
			return text.substring(0, htmlEnd) + "&nbsp;&nbsp;" + keyStrokeString + text.substring(htmlEnd);
		}
		else {
			return text;
		}
	}
	
	/**
	 * @since 2.0
	 */
	public int getMinimumWidth() { return minimumWidth; }

	/**
	 * @since 2.0
	 */
	public void setMinimumWidth(final int value) {
		if (value != minimumWidth) {
			minimumWidth = value;
			invalidate();
		}
	}

	/**
	 * @since 3.0
	 */
	public Window getWindowAncestor() {
		return SwingUtilities.getWindowAncestor(this);
	}

	/**
	 * @since 2.0
	 */
	public boolean isPopupMenuArrowPainted() { return popupMenuArrowPainted; }

	/**
	 * @since 2.0
	 */
	public void setPopupMenuArrowPainted(final boolean value) {
		if (value != popupMenuArrowPainted) {
			popupMenuArrowPainted = value;
			repaint(); // repaint arrow
		}
	}

	/**
	 * @since 2.0
	 */
	public boolean isPopupMenuEnabled() {
		return popupMenuEnabled || (popupMenuSupplier != null);
	}

	/**
	 * @since 2.0
	 */
	public void setPopupMenuEnabled(final boolean value) {
		if (value != popupMenuEnabled) {
			popupMenuEnabled = value;
			repaint(); // repaint arrow
		}
	}
	
	/**
	 * @since 3.8.9
	 */
	public boolean isRolloverEffectEnabled() { return rolloverEffectEnabled; }

	/**
	 * @since 3.8.9
	 */
	public void setRolloverEffectEnabled(final boolean value) { rolloverEffectEnabled = value; }

	/**
	 * @since 3.0
	 */
	public boolean isSafeAction() {
		return getClientProperty(SAFE_ACTION_PROPERTY) != null;
	}

	/**
	 * @since 3.0
	 */
	public void setSafeAction(final boolean enabled) {
		SafeActionHandler handler = UI.getClientProperty(this, SAFE_ACTION_PROPERTY, null);
		if (enabled) {
			if (handler == null) {
				handler = new SafeActionHandler();
				addMouseListener(handler);
				putClientProperty(SAFE_ACTION_PROPERTY, handler);
			}
		}
		else {
			if (handler != null) {
				removeMouseListener(handler);
				putClientProperty(SAFE_ACTION_PROPERTY, null);
			}
		}
	}
	
	/**
	 * @since 3.0, 4.0 (returns {@code java.awt.event.ActionListener})
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public ActionListener onClick(final Object target, final String action) {
		ActionListener l = EventHandler.create(ActionListener.class, target, action);
		addActionListener(l);

		return l;
	}

	/**
	 * @since 5.4
	 */
	public void setActionInfoUI(final MActionInfo actionInfo) {
		setIconNameUI(actionInfo.getIconName());
		setText(actionInfo.getText());
	}

	/**
	 * @since 3.4
	 */
	public void setCursor(final int type) {
		setCursor(Cursor.getPredefinedCursor(type));
	}
	
	@Override
	public void setIcon(final Icon value) {
		super.setIcon(value);
		clearRollover(this);
	}

	/**
	 * @since 3.8
	 */
	public void setIconUI(final Icon value) {
		if (UI.buttonIcons.get())
			setIcon(value);
	}

	/**
	 * @since 5.0
	 */
	public void setPopupMenu(final Supplier<MMenu> value) {
		if (value != popupMenuSupplier) {
			popupMenuSupplier = value;
			repaint(); // repaint arrow
		}
	}

	/**
	 * @since 5.6
	 */
	public void showFeedback(final Icon icon) {
		if (icon.getIconWidth() == MIcon.getSmallSize())
			setIcon(MIcon.getSmallThrobber());
		else
			setIcon(MIcon.getThrobber());

		MTimer.seconds(1, self -> {
			setIcon(icon);

			return MTimer.STOP;
		} )
			.start();
	}

	// StyleSupport

	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	@Override
	protected void actionPropertyChanged(final Action action, final String propertyName) {
		super.actionPropertyChanged(action, propertyName);
		if ((action != null) && MAction.VISIBLE_KEY.equals(propertyName)) {
			Object o = action.getValue(MAction.VISIBLE_KEY);
			if (o instanceof Boolean)
				setVisible((Boolean)o);
		}
	}

	@Override
	protected void configurePropertiesFromAction(final Action a) {
		super.configurePropertiesFromAction(a);
		if (a != null) {
			Object o = a.getValue(MAction.VISIBLE_KEY);
			if (o instanceof Boolean)
				setVisible((Boolean)o);
		}
	}

	/**
	 * Invoked when button is clicked.
	 */
	@Obsolete
	protected void onClick() { }
	
	/**
	 * @since 2.0
	 */
	protected MMenu onPopupMenu() { return null; }

	/**
	 * @since 5.0
	 */
	protected void paintPopupMenuArrow(final Graphics2D g) {
		if (
			popupMenuArrowPainted && isPopupMenuEnabled() && isEnabled() &&
			((popupMenuArrowAnimation != null) || mouseHover || popupMenuVisible || isFocusOwner())
		) {
			Color arrowColor = null;
			if (UI.isMetal())
				arrowColor = UIManager.getColor("controlDkShadow");
			if (arrowColor == null) {
				arrowColor = UI.getBackground(this);
				arrowColor = MColor.getContrast(arrowColor);
			}
			g.setColor(arrowColor);

			Object hint = UI.setAntialiasing(g, true);

			if (popupMenuArrowAnimation == null)
				setupArrowPoints(arrowPoint1, arrowPoint2, arrowPoint3);

			g.fill(MGraphics2D.createTriangle(
				arrowPoint1.x, arrowPoint1.y,
				arrowPoint2.x, arrowPoint2.y,
				arrowPoint3.x, arrowPoint3.y
			));

			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, hint); // restore hint
		}
	}

	@Override
	protected void paintComponent(final Graphics graphics) {
		super.paintComponent(graphics);
		paintPopupMenuArrow((Graphics2D)graphics);
	}

	// private
	
	private static void clearRollover(final AbstractButton button) {
		if ((button instanceof MButton) && !MButton.class.cast(button).isRolloverEffectEnabled())
			return;

		if (!UI.getLookAndFeelType().isButtonRolloverEffectSupported())
			return;

		// reset rollover effect
		if (isRolloverEffect(button)) {
			if (hoverScenario != null)
				hoverScenario.stop();
			button.setRolloverIcon(null);
			button.setRolloverSelectedIcon(null);
		}
	}

	private Point getMenuLocation(final JPopupMenu popupMenu) {
		Rectangle r = getBounds();
		r.x -= popupMenu.getPreferredSize().width / 2;
		r.x += getWidth() / 2;
		
		return new Point(r.x, r.y + r.height);
	}

	private void init() {
		addActionListener(e -> processClickEvent());
		
		// install rollover effect
		if (UI.getLookAndFeelType().isButtonRolloverEffectSupported())
			setRolloverEnabled(true);

		addMouseListener(staticRolloverHandler);

		putClientProperty(ROLLOVER_ICON_PROPERTY, true);
	}
	
	private void installArrowUpdater(final JPopupMenu popupMenu) {
		popupMenu.addPopupMenuListener(new PopupMenuListener() {
			@Override
			public void popupMenuCanceled(final PopupMenuEvent e) { }
			@Override
			public void popupMenuWillBecomeInvisible(final PopupMenuEvent e) {
				setPopupMenuVisible(false);
				popupMenu.removePopupMenuListener(this);
			}
			@Override
			public void popupMenuWillBecomeVisible(final PopupMenuEvent e) {
				setPopupMenuVisible(true);
			}
		} );
	}
	
	private static boolean isRolloverEffect(final AbstractButton button) {
		return UI.getClientProperty(button, ROLLOVER_ICON_PROPERTY, false);
	}
	
	private void processClickEvent() {
		if (doPopupMenu())
			return;

		onClick();
	}
	
	private void setPopupMenuVisible(final boolean visible) {
		if (popupMenuVisible == visible)
			return;
	
		popupMenuVisible = visible;

		Point toPoint1 = new Point();
		Point toPoint2 = new Point();
		Point toPoint3 = new Point();
		setupArrowPoints(toPoint1, toPoint2, toPoint3);

		popupMenuArrowAnimation = TK.dispose(popupMenuArrowAnimation);
		popupMenuArrowAnimation = new ComponentAnimation(this)
			.autoRepaint(true)
			.duration(300)
			.pointProperty(
				"arrowPoint1",
				arrowPoint1, toPoint1,
				() -> arrowPoint1, arrowPoint1::setLocation
			)
			.pointProperty(
				"arrowPoint2",
				arrowPoint2, toPoint2,
				() -> arrowPoint2, arrowPoint2::setLocation
			)
			.pointProperty(
				"arrowPoint3",
				arrowPoint3, toPoint3,
				() -> arrowPoint3, arrowPoint3::setLocation
			)
			.onDone(self -> popupMenuArrowAnimation = TK.dispose(popupMenuArrowAnimation))
			.play();
	}

	private void setupArrowPoints(final Point p1, final Point p2, final Point p3) {
		int w = getWidth();
		int h = getHeight();

		if (popupMenuVisible) {
			int size = Math.min(14, w);
			p1.setLocation(w / 2, h - size / 2);
			p2.setLocation(w / 2 - size / 2, h);
			p3.setLocation(w / 2 + size / 2, h);
		}
		else {
			int size = 7;
			p1.setLocation(w, h - size);
			p2.setLocation(w - size, h);
			p3.setLocation(w, h);
		}
	}

	private boolean showMenu(final MMenu menu) {
		if (menu == null)
			return false;

		JPopupMenu popupMenu = menu.getPopupMenu();
		if (popupMenu != null) {
			installArrowUpdater(popupMenu);
			menu.showPopup(getParent(), getMenuLocation(popupMenu));
		}
		
		return true;
	}

	// private classes
	
	private static final class SafeActionHandler extends MMouseAdapter implements Predicate<MTimer> {
		
		// private

		private boolean closeMode;
		private Icon buttonIcon;
		private MTimer buttonTimer;
		private WeakReference<AbstractButton> buttonRef;
		
		// public

		@Override
		public void mouseEntered(final MouseEvent e) {
			setCloseMode((AbstractButton)e.getSource(), true);
		}

		@Override
		public void mouseExited(final MouseEvent e) {
			setCloseMode((AbstractButton)e.getSource(), false);
		}

		// Predicate

		@Override
		public boolean test(final MTimer timer) {
			AbstractButton button = TK.get(buttonRef);
			if (button != null) {
				buttonRef = TK.dispose(buttonRef);
				button.setEnabled(true);
			}
			
			return false;
		}

		// private
		
		private void setCloseMode(final AbstractButton b, final boolean value) {
			if (value == closeMode)
				return;

			if (value && !b.isEnabled())
				return;

			closeMode = value;
			if (closeMode) {
				buttonIcon = b.getIcon();
				b.setEnabled(false);
				Icon safeActionIcon = (Icon)b.getClientProperty(SAFE_ACTION_ICON_PROPERTY);
				if (safeActionIcon == null) {
					if (buttonIcon == null)
						b.setIcon(MIcon.stock("ui/close"));
					else
						b.setIcon(MIcon.stock("ui/close", buttonIcon.getIconWidth()));
				}
				else {
					b.setIcon(safeActionIcon);
				}
				if (buttonTimer == null)
					buttonTimer = MTimer.milliseconds(500, this);
				buttonRef = new WeakReference<>(b);
				buttonTimer.restart();
			}
			else {
				b.setEnabled(true);
				b.setIcon(buttonIcon);
				if (buttonTimer != null)
					buttonTimer.stop();
			}
		}

	}

	private static final class StaticHoverTimeline extends MTimeline<Object> {

		// private

		private final Object lock = new Object();
		private WeakReference<AbstractButton> contextRef;

		// private

		private StaticHoverTimeline(final StaticHoverTimelineScenario scenario, final long duration, final float from, final float to) {
			setDuration(duration);

			addPropertyToInterpolate(
				MTimeline.<Float>property("gamma")
				.on(scenario.filter)
				.from(from)
				.to(to)
				.setWith((object, name, value) -> {
					GammaFilter filter = (GammaFilter)object;
					filter.setGamma(value);

					AbstractButton button;
					synchronized (lock) {
						button = TK.get(contextRef);
					}

					if (button == null)
						return;

					UI.invokeLater(() -> {
						Icon icon = button.getIcon();

						if (icon == null)
							return;

						MIcon rolloverIcon = MIcon.class.cast(icon).getFilteredInstance(filter);
						button.setRolloverIcon(rolloverIcon);
						if (button.getRolloverSelectedIcon() == null)
							button.setRolloverSelectedIcon(rolloverIcon);
					} );
				} )
			);
		}

		private void setContext(final AbstractButton b) {
			synchronized (lock) {
				if (b == null) {
					contextRef = TK.dispose(contextRef);
				}
				else if ((contextRef == null) || (contextRef.get() != null)) {
					contextRef = new WeakReference<>(b);
				}
			}
		}

	}

	private static final class StaticHoverTimelineScenario {

		// private

		private final GammaFilter filter = new GammaFilter();
		private final StaticHoverTimeline dec;
		private final StaticHoverTimeline inc;

		// private

		private StaticHoverTimelineScenario() {
			inc = new StaticHoverTimeline(this, 250, 1.0f, 2.5f);
			inc.addCallback(new MTimeline.UICallback() {
				@Override
				public void onDone() {
					dec.play();
				}
			} );

			dec = new StaticHoverTimeline(this, 250, 2.5f, 1.5f);
		}

		private void play(final AbstractButton b) {
			inc.abort();
			dec.abort();

			inc.setContext(b);
			dec.setContext(b);

			inc.play();
		}

		private void stop() {
			inc.abort();
			dec.abort();
			
			inc.setContext(null);
			dec.setContext(null);
		}

	}

	private static final class StaticRolloverHandler extends MMouseAdapter {

		// public

		@Override
		public void mouseEntered(final MouseEvent e) {
			AbstractButton button = (AbstractButton)e.getSource();

			if (button instanceof MButton) {
				MButton b = (MButton)button;
				b.mouseHover = true;

				if (!UI.getLookAndFeelType().isButtonRolloverEffectSupported() || !b.isRolloverEffectEnabled())
					return;
			}

			if (!UI.isSubstance() || (button instanceof MSmallButton))
				startRolloverEffect(button);
		}

		@Override
		public void mouseExited(final MouseEvent e) {
			AbstractButton button = (AbstractButton)e.getSource();

			if (button instanceof MButton)
				MButton.class.cast(button).mouseHover = false;

			if (button.isRolloverEnabled())
				MButton.clearRollover(button);
		}

		// private

		private void startRolloverEffect(final AbstractButton button) {
			Icon icon = button.getIcon();
			if (
				(icon instanceof MIcon) &&
				button.isRolloverEnabled() &&
				MButton.isRolloverEffect(button) &&
				(MIcon.class.cast(icon).getImage() != null)
			) {
				if (MButton.hoverScenario == null)
					MButton.hoverScenario = new StaticHoverTimelineScenario();
				MButton.hoverScenario.play(button);
			}
		}

	}

}
