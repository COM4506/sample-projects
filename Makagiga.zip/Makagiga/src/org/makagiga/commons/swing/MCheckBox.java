// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.event.ActionListener;
import java.beans.ConstructorProperties;
import java.beans.EventHandler;
import javax.swing.JCheckBox;

import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.form.FieldEditor;

/**
 * A check box.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
@FieldEditor(type = boolean.class, valueProperty = "selected", labelProperty = "text")
public class MCheckBox extends JCheckBox {
	
	// private
	
	private boolean original;

	// public

	/**
	 * Constructs a check box.
	 */
	public MCheckBox() {
		this(null);
	}

	/**
	 * Constructs a check box.
	 * @param text A text
	 */
	@ConstructorProperties("text")
	public MCheckBox(final String text) {
		setText(text);
		addActionListener(e -> onClick());
	}
	
	/**
	 * Returns @c true if selection has changed
	 * since the last @ref setAndRemember(final boolean) call.
	 *
	 * @since 1.2
	 */
	public boolean isModified() {
		return isSelected() != original;
	}
	
	/**
	 * @since 3.0, 4.0 (returns {@code java.awt.event.ActionListener})
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public ActionListener onClick(final Object target, final String action) {
		ActionListener l = EventHandler.create(ActionListener.class, target, action);
		addActionListener(l);

		return l;
	}

	/**
	 * @since 3.0, 4.0 (returns {@code java.awt.event.ActionListener})
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public ActionListener onSelect(final Object target, final String targetPropertyName) {
		ActionListener l = EventHandler.create(ActionListener.class, target, targetPropertyName, "source.selected");
		addActionListener(l);

		return l;
	}

	/**
	 * Sets selection to @p value and remembers the new value.
	 *
	 * @see #isModified()
	 *
	 * @since 1.2
	 */
	public void setAndRemember(final boolean value) {
		setSelected(value);
		original = value;
	}

	@Override
	public void updateUI() {
		super.updateUI();
		if (UI.isMetal())
			setIconTextGap(8);
	}

	// protected

	/**
	 * Invoked when check box is clicked.
	 */
	@Obsolete
	protected void onClick() { }

}
