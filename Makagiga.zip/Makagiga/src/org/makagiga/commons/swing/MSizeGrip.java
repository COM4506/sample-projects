// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.lang.ref.WeakReference;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;

import org.makagiga.commons.MColor;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MSizeGrip extends MComponent {
	
	// private

	private final Dimension size = new Dimension(10, 10);
	private final Point clickLocation = new Point();
	private static StaticHandler handler;
	private final WeakReference<Container> containerRef;
	
	// public
	
	public MSizeGrip(final Container container) {
		containerRef = new WeakReference<>(container);

		if (handler == null)
			handler = new StaticHandler();
		addMouseListener(handler);
		addMouseMotionListener(handler);

		setCursor(Cursor.SE_RESIZE_CURSOR);
		setSize(size);
	}
	
	@Override
	public void addNotify() {
		super.addNotify();
		Container c = getParent();
		if (c != null)
			setComponentOrientation(c.getComponentOrientation());
	}

	@Override
	public Dimension getMaximumSize() {
		return getPreferredSize();
	}

	@Override
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(size);
	}
	
	// protected

	@Override
	protected void paintComponent(final Graphics graphics) {
		if (!isContainerResizable())
			return;

		Graphics2D g = (Graphics2D)graphics.create();
		UI.setAntialiasing(g, false);

		Color color1 = MColor.getContrast(UI.getBackground(this));
		Color color2 = MColor.getBrighter(color1);

		drawLine(g, color1, color2, 0);
		drawLine(g, color1, color2, 3);
		drawLine(g, color1, color2, 6);

		g.dispose();
	}

	// private
	
	private void doDrag(final MouseEvent e) {
		Container container = containerRef.get();
		
		if (container == null)
			return;
		
		Point start = container.getLocationOnScreen();
		int width = e.getXOnScreen() - start.x + clickLocation.x;
		int height = e.getYOnScreen() - start.y + clickLocation.y;
		
		Dimension min;
		if (container.isMinimumSizeSet())
			min = container.getMinimumSize();
		else
			min = new Dimension(50, 50);
		container.setSize(
			Math.max(width, min.width),
			Math.max(height, min.height)
		);
	}

	private void drawLine(final Graphics g, final Color color1, final Color color2, final int pos) {
		int x2 = getWidth() - 1;
		int y2 = getHeight() - 1;
		g.setColor(color2);
		g.drawLine(x2 - pos, y2, x2, y2 - pos);
		g.setColor(color1);
		g.drawLine(x2 - (pos + 1), y2, x2, y2 - (pos + 1));
	}
	
	private boolean isContainerResizable() {
		Container container = containerRef.get();

		if (container instanceof JDialog)
			return JDialog.class.cast(container).isResizable();

		if (container instanceof JFrame)
			return JFrame.class.cast(container).isResizable();

		if (container instanceof JInternalFrame)
			return JInternalFrame.class.cast(container).isResizable();

		return false;
	}

	// private classes

	private static final class StaticHandler extends MMouseAdapter {

		// public

		@Override
		public void mouseDragged(final MouseEvent e) {
			MSizeGrip sizeGrip = (MSizeGrip)e.getSource();
			sizeGrip.doDrag(e);
		}

		@Override
		public void mousePressed(final MouseEvent e) {
			MSizeGrip sizeGrip = (MSizeGrip)e.getSource();
			sizeGrip.clickLocation.setLocation(
				sizeGrip.getWidth() - e.getX() + 1,
				sizeGrip.getHeight() - e.getY() + 1
			);
		}

	}

}
