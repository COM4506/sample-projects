// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Window;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.painters.GradientPainter;
import org.makagiga.commons.validator.Validator;
import org.makagiga.commons.validator.ValidatorMessage;

/**
 * @since 3.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MWizardDialog extends MDialog {
	
	// private

	private ChangeListener changeListener;
	private final EventListenerList listenerList = new EventListenerList();
	private MButton backButton;
	private MButton cancelButton;
	private MButton nextButton;
	private MTabbedPane<Page> pages;
	
	// public

	public MWizardDialog(final Window owner, final String title) {
		this(owner, title, MIcon.stock("ui/wizard"));
	}
	
	public MWizardDialog(final Window owner, final String title, final Icon icon) {
		super(owner, title, icon, MODAL | COMPACT_HEADER);

		pages = new MTabbedPane<Page>() {
			@Override
			public void setEnabledAt(final int index, final boolean enabled) {
				super.setEnabledAt(index, enabled);
				// update custom tab component
				Component c = this.getTabComponentAt(index);
				if (c != null)
					c.setEnabled(enabled);
			}
		};
		pages.setTabPlacement(UI.LEFT);
		addCenter(pages);

		installValidatorMessage();

		addSouth(createButtonsPanel());
	}
	
	public void addChangeListener(final ChangeListener l) {
		listenerList.add(ChangeListener.class, l);
	}
	
	public ChangeListener[] getChangeListeners() {
		return listenerList.getListeners(ChangeListener.class);
	}

	public void removeChangeListener(final ChangeListener l) {
		listenerList.remove(ChangeListener.class, l);
	}

	public Page addPage(final String title, final JComponent component) {
		return addPage(title, null, component);
	}
	
	public Page addPage(final String title, final String description, final JComponent component) {
		return addPage(title, null, description, component);
	}

	public Page addPage(final String title, final Icon icon, final String description, final JComponent component) {
		Page page = new Page(description, component);
		pages.addTab(title, icon, page);
		
		MLabel tc = new MLabel(title, icon);
		tc.setHorizontalAlignment(MLabel.CENTER);
		tc.setHorizontalTextPosition(MLabel.CENTER);
		tc.setVerticalAlignment(MLabel.CENTER);
		tc.setVerticalTextPosition(MLabel.BOTTOM);
		pages.setTabComponentAt(pages.getTabCount() - 1, tc);
		
		return page;
	}

	public void complete() {
		cancelButton.setEnabled(false);
		backButton.setEnabled(false);
		nextButton.setEnabled(true); // "Close" button
	}
	
	@Override
	public boolean exec(final JComponent defaultFocus) {
		int count = pages.getTabCount();
		for (int i = 1; i < count; i++) // 0 - first page; enabled initially
			pages.setEnabledAt(i, false);
		updateState();

		changeListener = e -> {
			updateState();
			fireStateChanged();
		};
		pages.addChangeListener(changeListener);
		
		return super.exec(defaultFocus);
	}
	
	public Page getCurrentPage() {
		return pages.getSelectedTab();
	}

	public void setCurrentPage(final Page page) {
		pages.setSelectedComponent(page);
	}
	
	/**
	 * @since 4.10
	 */
	@Obsolete
	public MTabbedPane<Page> getPages() { return pages; }
	
	public boolean isDone() {
		return (pages.getSelectedIndex() == (pages.getTabCount() - 1));
	}

	public void nextPage() {
		// close wizard
		if (!cancelButton.isEnabled()) {
			accept();
			
			return;
		}
		
		int count = pages.getTabCount();
		int current = pages.getSelectedIndex();
		if (current < count - 1) {
			current++;
			pages.setEnabledAt(current, true);
			pages.setSelectedIndex(current);
		}
		if (isDone()) {
			for (int i = 0; i < count - 1; i++)
				pages.setEnabledAt(i, false);
		}
	}

	public void previousPage() {
		int current = pages.getSelectedIndex();
		if (current > 0) {
			pages.setEnabledAt(current, false);
			pages.setEnabledAt(current - 1, true);
			pages.setSelectedIndex(current - 1);
		}
	}

	public void setDescription(final String value) {
		Page page = pages.getSelectedTab();
		if (page != null)
			UI.invokeLater(() -> page.setDescription(value));
	}

	// protected

	@InvokedFromConstructor
	protected MPanel createButtonsPanel() {
		MPanel p = MPanel.createHBoxPanel();
		int sideMargin = (UI.isNimbus() || UI.isSubstance())
			? MPanel.DEFAULT_CONTENT_MARGIN
			: 0;
		p.setMargin(p.getContentMargin(), sideMargin, 0, sideMargin);

		// HACK: "Esc" key need enabled "cancelButton" button to work properly
		MAction cancelAction = new MAction(i18n("Cancel"), action -> {
			getCancelButton().setEnabled(true);
			reject();
		} );
		bind(MButton.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT, VK_ESCAPE, cancelAction);

		cancelButton = new MButton(cancelAction);
		cancelButton.setMinimumWidth(75); // NOTE: 75 - sync. with MDialog
		cancelButton.setIconNameUI("ui/cancel");
		p.add(cancelButton);

		p.addContentGap();
		p.addStretch();

		backButton = new MButton();
		backButton.setMinimumWidth(75);
		backButton.addActionListener(e -> previousPage());
		backButton.setIconNameUI("ui/previous");
		if (backButton.getIcon() == null)
			backButton.setText("< " + i18n("Back"));
		else
			backButton.setText(i18n("Back"));
		
		nextButton = new MButton();
		nextButton.setMinimumWidth(75);
		nextButton.addActionListener(e -> nextPage());
		setDefault(nextButton);

		MButtonPanel backNextPanel = new MButtonPanel(
			MButtonPanel.HORIZONTAL | MButtonPanel.NO_REVERSE | MButtonPanel.NO_PAINTER,
			backButton,
			nextButton
		);
		backNextPanel.setMaximumSize(Size.preferred());
		p.add(backNextPanel);

		setCancelButton(cancelButton);
		setOKButton(nextButton);

		return p;
	}
	
	protected void fireStateChanged() {
		TK.fireStateChanged(this, getChangeListeners());
	}

	@Override
	protected void onClose() {
		super.onClose();
		if (changeListener != null) {
			pages.removeChangeListener(changeListener);
			changeListener = null;
		}
	}

	protected void updateState() {
		int count = pages.getTabCount();
		int current = pages.getSelectedIndex();
		if (current == count - 2) {
			backButton.setEnabled(current > 0);
			nextButton.setEnabled(true);
			nextButton.setIconNameUI("ui/ok");
			nextButton.setText(i18n("Finish"));
		}
		else if (current == count - 1) {
			backButton.setEnabled(false);
			nextButton.setEnabled(false);
			nextButton.setIconNameUI("ui/close");
			nextButton.setText(i18n("Close"));
		}
		else {
			backButton.setEnabled(current > 0);
			nextButton.setEnabled(true);
			nextButton.setIconNameUI("ui/next");
			if (nextButton.getIcon() == null)
				nextButton.setText(i18n("Next") + " >");
			else
				nextButton.setText(i18n("Next"));//!!!update mnemonic
		}

/*
		for (Validator<?> i : getValidatorSupport()) {
			JComponent component = i.getComponent();
			if (component != null) {
				Container ancestor = SwingUtilities.getAncestorOfClass(Page.class, component);
				i.setEnabled((count > 0) && (ancestor == pages.getSelectedTab()));
			}
			else {
				i.setEnabled(false);
			}
		}
*/
		ValidatorMessage message = getValidatorMessage();
		if (message != null)
			message.setVisible(false);

		// enable validators only for the current page
		Page page = getCurrentPage();
		for (Validator<?> i : getValidatorSupport()) {
			JComponent component = i.getComponent();
			if (component != null)
				i.setEnabled(page == UI.getAncestorOfClass(Page.class, component));
		}

		getValidatorSupport().validate(this);
	}
	
	// public classes
	
	public static class Page extends MPanel {
		
		// private
		
		private final MMessageLabel description;
		
		// public
		
		public Page(final String descriptionText, final JComponent component) {
			description = new MMessageLabel();
			description.setColor(MHighlighter.INFO_COLOR, Color.BLACK);
			description.setDirection(MMessageLabel.Direction.BOTTOM);
			description.setPainter(new GradientPainter());
			addNorth(description);
			addCenter(component);
			
			setDescription(descriptionText);
		}

		@InvokedFromConstructor
		public void setDescription(final String value) {
			description.setText(value);
			description.setVisible(!TK.isEmpty(value));
		}
		
	}

}
