// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.URI;
import java.text.ParseException;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.ClipboardException;
import org.makagiga.commons.FS;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MClipboard;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MDate;
import org.makagiga.commons.MFormat;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.MStringBuilder;
import org.makagiga.commons.OS;
import org.makagiga.commons.PassiveException;
import org.makagiga.commons.Property;
import org.makagiga.commons.TK;
import org.makagiga.commons.Tuple;
import org.makagiga.commons.UI;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.io.LogFile;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.preview.PreviewPanel;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.syntax.Syntax;
import org.makagiga.commons.syntax.SyntaxException;
import org.makagiga.commons.syntax.SyntaxLayerUI;
import org.makagiga.commons.swing.event.MMouseAdapter;
		
/**
 * Misc. message and input dialogs.
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MMessage<V extends JComponent> extends MDialog {

	// private

	private WeakReference<V> viewRef;

	// public

	public MMessage(final Window owner, final String label, final String title, final Icon icon, final V view, final int flags) {
		super(owner, title, icon, flags);
		init(label, view);
	}

	public MMessage(final Window owner, final String label, final String title, final String iconName, final V view, final int flags) {
		super(owner, title, iconName, flags);
		init(label, view);
	}

	/**
	 * Displays a confirmation box.
	 * @param owner the owner window
	 * @param text A message text
	 * @return {@code true} if <i>OK</i> pressed; otherwise {@code false}
	 */
	public static boolean confirm(final Window owner, final String text) {
		return customConfirm(owner, MIcon.stock("ui/question"), null, null, text);
	}

	public static boolean confirmDelete(final Window owner, final String text) {
		return confirmDelete(owner, text, null);
	}
	
	public static boolean confirmDelete(final Window owner, final String text, final Object info) {
		return customConfirm(
			owner,
			MIcon.stock("ui/delete"),
			MActionInfo.DELETE,
			null,
			UI.makeHTML(text + makeInfo(info))
		);
	}

	/**
	 * @since 3.0
	 */
	public static boolean confirmFileOverwrite(final Window owner, final String oldFileDisplayName, final File oldFile, final File newFile) {
		Objects.requireNonNull(oldFile);
		
		FileInfoPanel oldFileInfo = new FileInfoPanel(oldFile, i18n("Existing File"));
		FileInfoPanel newFileInfo = (newFile != null) ? (new FileInfoPanel(newFile, i18n("New File"))) : null;
		
		MDialog dialog = new MDialog(
			owner,
			i18n("File already exists. Overwrite?"),
			MIcon.stock("ui/question"),
			MDialog.STANDARD_DIALOG
		);
		dialog.getOKButton().setText(i18n("Overwrite"));
		dialog.getOKButton().setIconNameUI("ui/warning");
		
		MPanel p = dialog.getMainPanel();
		p.setSimpleLayout()
			.setContentGap();
		
		if (oldFileDisplayName != null)
			oldFileInfo.addInfo(i18n("Name:"), oldFileDisplayName);
		p.add(oldFileInfo, "left");
		
		if (newFileInfo != null) {
			p.add(new MLabel(ShapeIcon.RIGHT_ARROW), "center");
			p.add(newFileInfo, "right");
		}
		
		oldFileInfo.alignLabels();
		oldFileInfo.startPreview();
		if (newFileInfo != null) {
			newFileInfo.alignLabels();
			newFileInfo.startPreview();
		}
		
		dialog.pack();
		boolean result = dialog.exec();
		
		oldFileInfo.stopPreview();
		if (newFileInfo != null)
			newFileInfo.stopPreview();
		
		return result;
	}

	/**
	 * @since 4.0
	 */
	public static boolean confirmFileOverwrite(final Window owner, final File file) {
		return customConfirm(
			owner,
			null,
			MActionInfo.OVERWRITE,
			null,
			UI.makeHTML(i18n("File already exists. Overwrite?") + makeInfo(file))
		);
	}

	/**
	 * @since 4.0
	 */
	public static MPanel createErrorPanel(final Throwable throwable, final int flags) {
		MPanel p = MPanel.createBorderPanel();

		MLabel error = new MLabel(i18n("Error"), getRandomErrorIconName());
		error.makeLargeMessage();
		p.addCenter(error);

		MButton detailsButton = new MButton(i18n("Details"));
		detailsButton.addActionListener(e -> {
			MMessage.errorDetails(detailsButton.getWindowAncestor(), throwable);
		} );
		p.addSouth(detailsButton);

		return p;
	}

	public static MList<Object> createListView(final Icon icon, final Object[] list) {
		return new ListView(icon, list);
	}

	/**
	 * @since 3.0
	 *
	 * @deprecated As of 4.4, replaced by {@link Builder}
	 */
	@Deprecated
	public static boolean customConfirm(
		final Window owner,
		final Icon icon,
		final MActionInfo okInfo,
		final MActionInfo cancelInfo,
		final String text
	) {
		return customConfirm(owner, icon, okInfo, cancelInfo, text, null);
	}

	/**
	 * @since 3.0
	 *
	 * @deprecated As of 4.4, replaced by {@link Builder}
	 */
	@Deprecated
	public static boolean customConfirm(
		final Window owner,
		final Icon icon,
		final MActionInfo okInfo,
		final MActionInfo cancelInfo,
		final String text,
		final Object[] list
	) {
		return customConfirm(
			owner,
			null, // title
			icon,
			(okInfo == null) ? null : okInfo.getIcon(),
			(okInfo == null) ? null : okInfo.getText(),
			(cancelInfo == null) ? null : cancelInfo.getIcon(),
			(cancelInfo == null) ? null : cancelInfo.getText(),
			text,
			list,
			null
		);
	}

	/**
	 * Displays an error message box.
	 * @param owner the owner window
	 * @param text A message text
	 */
	public static void error(final Window owner, final String text) {
		MPanel view = createView(text);
		MMessage<MPanel> base = new MMessage<>(
			owner,
			null,
			i18n("Error"),
			getRandomErrorIconName(),
			view,
			MDialog.SIMPLE_DIALOG
		);
		base.setResizable(false);
		base.exec();
	}
	
	public static void error(final Window owner, final Throwable throwable) {
		error(owner, throwable, null);
	}
	
	/**
	 * {@code info} of type {@code String} surrounded with {@code "html"} tags will be displayed as HTML
	 * (example: {@code "<html>File Name: <b>Foo</b></html>"}).
	 */
	public static void error(final Window owner, final Throwable throwable, final Object info) {
		if (throwable != null)
			MLogger.exception(throwable);

		// passive message

		if (throwable instanceof PassiveException) {
			MStatusBar.error(getThrowablePassiveMessage(throwable, info));

			return;
		}

		// popup message

		String text = (throwable == null) ? i18n("Unknown Error") : TK.buildErrorMessage(throwable);

		if (info != null) {
			String infoString = info.toString();
			
			// show "infoString" as HTML
			if ((info instanceof String) && infoString.startsWith("<html>") && infoString.endsWith("</html>")) {
				try {
					infoString = TK.substring(infoString, "<html>", "</html>", false);
				}
				catch (ParseException exception) {
					MLogger.developerException(exception);
				}
				text = UI.makeHTML(TK.escapeXML(text) + "\n\n" + infoString);
			}
			// show "infoString" as plain text
			else {
				text = (text + "\n\n" + infoString);
			}
		}
		
		MPanel view = createView(text);
		MMessage<MPanel> base = new MMessage<>(
			owner,
			null,
			i18n("Error"),
			getRandomErrorIconName(),
			view,
			MDialog.SIMPLE_DIALOG | MDialog.USER_BUTTON
		);
		base.onUserClick(self -> errorDetails(self, throwable));
		if (throwable == null)
			base.getUserButton().setVisible(false);
		else
			base.getUserButton().setText(i18n("Details"));
		base.setResizable(false);
		base.exec(base.getOKButton());
	}
	
	public static void errorDetails(final Window owner, final Throwable throwable) {
		errorDetails(owner, throwable, true);
	}

	/**
	 * @since 4.2
	 */
	public static void errorDetails(final Window owner, final Throwable throwable, final boolean showSystemSummary) {
		if (throwable == null)
			return;
		
		MEditorPane stackText = new MEditorPane();
		stackText.setEditable(false);
		stackText.setName("MMessage.stackText");
		MText.setupMonospacedFont(stackText);
		
		MDialog dialog = new MDialog(
			owner,
			i18n("Error Details"),
			"ui/error",
			MDialog.SIMPLE_DIALOG | MDialog.LINK_BUTTON | MDialog.USER_BUTTON | MDialog.FORCE_STANDARD_BORDER
		);
		dialog.onUserClick(self -> MText.copyAll(stackText));
		dialog.getMainPanel().setMargin(0);
		dialog.getUserButton().setActionInfoUI(MActionInfo.COPY_ALL);
		MLinkButton linkButton = dialog.getLinkButton();
		if (MApplication.getBugs() == null) {
			linkButton.setVisible(false);
		}
		else {
			linkButton.setText(i18n("Report Bug"));
			linkButton.setURI(MApplication.getBugs());
		}
		
		MButton saveAsButton = new MButton(MActionInfo.SAVE_AS.getText()) {
			@Override
			protected void onClick() {
				MDialog dialog = MDialog.of(this);

				MFileChooser fileChooser = MFileChooser.createFileChooser(dialog, MActionInfo.SAVE_AS.getDialogTitle());
				fileChooser.setFileFilter(
					fileChooser.addFilter(i18n("Plain Text"), "txt")
				);
				fileChooser.setAutoAddExtension(true);
				fileChooser.setConfigKey("bugs");
				fileChooser.setSelectedFile(new File(throwable.getClass().getName() + ".txt"));

				if (fileChooser.saveDialog()) {
					try {
						MEditorPane stackText = (MEditorPane)ContainerIterator.findName(dialog, "MMessage.stackText");
						MText.save(stackText, fileChooser.getSelectedFile());
					}
					catch (IOException exception) {
						MMessage.error(dialog, exception);
					}
				}
			}
		};
		saveAsButton.setIconNameUI(MActionInfo.SAVE_AS.getIconName());
		dialog.getButtonsPanel().addContentGap();
		dialog.getButtonsPanel().add(saveAsButton);

		Tuple.Two<LogFile, String> logInfo = null;
		if (MLogger.isDeveloper() && !FS.isRestricted()) {
			logInfo = MAccessController.doPrivileged(() -> {
				LogFile logFile = MApplication.getLogFile();
				logFile.flush();
				try {
					return Tuple.of(logFile, FS.read(logFile.getFile(), "UTF8"));
				}
				catch (IOException exception) { // quiet
					return null;
				}
			} );
		}
		
		MStringBuilder s = new MStringBuilder(1024 * 64);

		if (!FS.isRestricted() && showSystemSummary)
			s.append(OS.getSummary(true));

		String separator = TK.filler('-', 40);

		Throwable i = throwable;
		do {
			if (!s.isEmpty())
				s.n().n();
			
			s.append(separator).n();
			s.append(TK.identifierToDisplayString(i.getClass().getSimpleName())).n();
			s.append(i).n();
			s.append(separator).n();
			
			for (StackTraceElement ste : i.getStackTrace())
				s.append(ste).n();
		} while ((i = i.getCause()) != null);

		LogFile logFile = (logInfo == null) ? null : logInfo.get1();
		String log = (logInfo == null) ? null : logInfo.get2();
		if ((log != null) && (logFile != null)) {
			s
			.n().n()
			.append(separator).n()
			.append(logFile.getFile()).append(':').n()
			.append(separator).n();
			
			// JEditorPane is too slow for larger text
			int max = 1024 * 64;
			if (log.length() > max) {
				s.append("(...)").n();
				log = log.substring(log.length() - max);
			}
			s.append(log);
		}
		
		SyntaxLayerUI syntaxUI = null;
		
		if (!s.isEmpty()) {
			UI.setWaitCursor(true);
			stackText.setText(s.toString());
			stackText.setCaretPosition(0);

			try {
				String syntaxCode =
					"Context {\n" +
					"\tstart: " + separator + "\n" +
					"\tend: " + separator + "\n" +
					"\tline-start: true\n" +
					"\tcolor: $headerColor\n" +
					"\tfont-style: bold\n" +
					"}\n" +
					"\n" +
					"Context {\n" +
					"\tstart: org.makagiga\n" +
					"\tend: \\n\n" +
					"\tline-start: true\n" +
					"\tbackground-color: $fixmeBackgroundColor\n" +
					"\tcolor: auto\n" +
					"}";

				Syntax syntax = new Syntax(syntaxCode);
				syntaxUI = new SyntaxLayerUI(stackText);
				syntaxUI.setSyntax(syntax);
				dialog.addCenter(syntaxUI.wrap(stackText));
			}
			catch (SyntaxException exception) {
				MLogger.developerException(exception);
				
				dialog.addCenter(stackText);
			}
			
			UI.setWaitCursor(false);
		}
		dialog.setSize(UI.WindowSize.MEDIUM);
		dialog.exec(dialog.getOKButton());
		
		TK.dispose(syntaxUI);
	}
	
	/**
	 * @since 4.4
	 */
	public static MActionInfo getAction(final Window owner, final String title, final Icon icon, final List<MActionInfo> actionList) {
		Property<MActionInfo> result = new Property<>();
	
		MButton defaultButton = null;
		MPanel view = MPanel.createGridPanel(actionList.size(), 1, 10, 10);
		
		for (MActionInfo i : actionList) {
			MButton b = new MButton(i);
			b.addActionListener(e -> {
				MMessage<?> message = UI.getAncestorOfClass(MMessage.class, b);
				result.set(i);
				message.accept();
			} );
			b.setHorizontalAlignment(UI.LEADING);
			view.add(b);
			
			if (defaultButton == null)
				defaultButton = b;
		}
		
		MMessage<MPanel> message = new MMessage<>(
			owner,
			null, // label
			title,
			icon,
			view,
			CANCEL_BUTTON | MODAL
		);
		message.packFixed();
		
		if (defaultButton != null)
			message.setDefault(defaultButton);
		if (message.exec(defaultButton))
			return result.get();

		return null;
	}

	/**
	 * Returns a localized "Are you sure?" text.
	 *
	 * @since 3.8
	 */
	public static String getSimpleConfirmMessage() {
		return i18n("Are you sure?");
	}

	/**
	 * @since 3.8.6
	 */
	public V getView() { return viewRef.get(); }

	/**
	 * Displays an information message box.
	 * @param owner the owner window
	 * @param text A message text
	 */
	public static void info(final Window owner, final String text) {
		infoWithIcon(owner, "ui/info", text);
	}

	/**
	 * Displays an information message box.
	 * @param owner the owner window
	 * @param iconName An icon name
	 * @param text A message text
	 */
	public static void infoWithIcon(final Window owner, final String iconName, final String text) {
		MPanel view = createView(text);
		MMessage<MPanel> base = new MMessage<>(
			owner,
			null,
			i18n("Information"),
			iconName,
			view,
			MDialog.SIMPLE_DIALOG
		);
		base.setResizable(false);
		base.exec();
	}

	/**
	 * @since 3.0
	 */
	public static boolean simpleConfirm(final Window owner) {
		return simpleConfirm(owner, MActionInfo.OK, null);
	}

	/**
	 * @since 3.0
	 */
	public static boolean simpleConfirm(final Window owner, final MActionInfo okInfo) {
		return simpleConfirm(owner, okInfo, null);
	}

	/**
	 * @since 3.0
	 */
	public static boolean simpleConfirm(final Window owner, final MActionInfo okInfo, final Object[] list) {
		return customConfirm(owner, okInfo.getIcon(), okInfo, null, getSimpleConfirmMessage(), list);
	}

	public static void warning(final Window owner, final String text) {
		MMessage<MPanel> base = new MMessage<>(
			owner,
			null,
			i18n("Warning"),
			"ui/warning",
			createView(text),
			MDialog.SIMPLE_DIALOG
		);
		base.setResizable(false);
		base.exec();
	}

	// private

	private static MPanel createView(String text) {
		if (text == null)
			text = "";
		boolean html = text.startsWith("<html>");
		boolean multiline = (text.indexOf('\n') != -1);
		String originalText = text;
		if (multiline && html)
			text = text.replace("\n", "<br>");

		MLabel pane = new MLabel();
		if (multiline && html)
			pane.setText(text);
		else if (multiline && !html)
			pane.setMultilineText(text);
		else
			pane.setText(text);

		final MDataAction<String> copyAction = new MDataAction<>(originalText, MActionInfo.COPY,
			self -> {
				try {
					MClipboard.setString(self.getData());
				}
				catch (ClipboardException exception) {
					self.showErrorMessage(exception);
				}
			}
		);
		copyAction.setEnabled(!originalText.isEmpty());
		copyAction.connect(pane, JComponent.WHEN_IN_FOCUSED_WINDOW);

		pane.addMouseListener(new MMouseAdapter() {
			@Override
			public void popupTrigger(final MouseEvent e) {
				MMenu menu = new MMenu();
				menu.add(copyAction);
				menu.showPopup(e);
			}
		} );

		MPanel view = MPanel.createBorderPanel(MPanel.DEFAULT_CONTENT_MARGIN);
		view.setContentMargin();
		view.addCenter(pane);
		
		MTip tip = new MTip(MMessage.class.getName(), "message");
		tip.showNextTip(MTip.Visible.SELDOM);
		view.addSouth(tip);

		return view;
	}

	private static boolean customConfirm(
		final Window owner,
		final String title,
		final Icon icon,
		final Icon okIcon,
		final String okText,
		final Icon cancelIcon,
		final String cancelText,
		final String text,
		final Object[] list,
		final Tuple.Two<URI, String> link
	) {
		boolean hideIcon = false;
		boolean resizable = false;
		MPanel mainPanel = MPanel.createBorderPanel(5);
		mainPanel.addNorth(createView(text));
		
		// list view
		
		if (list != null) {
		
			// show as small HTML table
		
			if ((list.length > 0) && (list[0] instanceof HTMLBuilder.TableColumn) && (list.length < 20)) {
				HTMLBuilder html = HTMLBuilder.newSwingDoc();
				html.beginTag(
					"table",
					"border", 0,
					"cellpadding", 0,
					"cellspacing", 10
				);
				html.appendTableCells(list);
				html.endTag("table");
				html.endSwingDoc();

				MLabel label = new MLabel(html.toString());
				label.setIcon(icon);
				mainPanel.addCenter(label);
				
				hideIcon = true;
				resizable = true;
			}
			
			// show as list
			
			else if (list.length < 1000) {
				mainPanel.addCenter(createListView(icon, list));
				
				hideIcon = true;
				resizable = true;
			}
		}

		MMessage<MPanel> base = new MMessage<>(
			owner,
			null,
			TK.isEmpty(title) ? i18n("Confirm") : title,
			hideIcon ? null : icon,
			mainPanel,
			MDialog.STANDARD_DIALOG | ((link != null) ? MDialog.LINK_BUTTON : 0)
		);

		// setup "Cancel" button
		MButton button = base.getCancelButton();
		if (UI.buttonIcons.get() && (cancelIcon != null))
			button.setIcon(cancelIcon);
		if (cancelText != null)
			button.setText(cancelText);

		// setup "OK" button
		button = base.getOKButton();
		if (UI.buttonIcons.get() && (okIcon != null))
			button.setIcon(okIcon);
		if (okText != null)
			button.setText(okText);
		
		// setup link button
		if (link != null) {
			URI uri = link.get1();
			String uriText = link.get2();
			if (TK.isEmpty(uriText)) {
				base.getLinkButton().setURIAndText(uri);
			}
			else {
				base.getLinkButton().setText(uriText);
				base.getLinkButton().setURI(uri);
			}
		}
		
		// update layout
		if ((cancelIcon != null) || (cancelText != null) || (okIcon != null) || (okText != null) || (link != null))
			base.pack();

		base.setResizable(resizable);

		return base.exec(base.getOKButton());
	}

	private static String getThrowablePassiveMessage(final Throwable throwable, final Object info) {
		if (throwable == null)
			return i18n("Unknown Error");

		String text = throwable.getLocalizedMessage();
		if (text == null) {
			Throwable cause = throwable.getCause();
			text = (cause == null) ? i18n("Unknown Error") : cause.getLocalizedMessage();
		}

		if (info != null)
			text += " - " + info;

		return text.replace('\n', ' ');
	}

	private void init(final String aLabel, final V view) {
		viewRef = new WeakReference<>(view);

		MPanel mainPanel = MPanel.createVBoxPanel();

		// init label
		MLabel label = null;
		if (aLabel != null) {
			label = new MLabel(aLabel);
			mainPanel.add(label);
			mainPanel.addGap();
		}

		// init view
		if (view != null) {
			mainPanel.add(view);
			if (label != null)
				label.setLabelFor(MWrapperPanel.getWrappedView(view));
		}

		addCenter(mainPanel);
		pack();
	}

	private static String makeInfo(final Object info) {
		return
			(info == null)
			? ""
			: "<br><br><b>" + TK.escapeXML(info.toString()) + "</b>";
	}

	// package

	@SuppressFBWarnings({ "MDM_RANDOM_SEED", "SACM_STATIC_ARRAY_CREATED_IN_METHOD" })
	static String getRandomErrorIconName() {
		String[] icons = {
			"ui/error",
			"labels/emotion/angry",
			"labels/emotion/cry",
			"labels/emotion/sad"
		};

		return icons[new Random().nextInt(icons.length)];
	}
	
	// public classes
	
	/**
	 * @since 4.4
	 */
	public static final class Builder {
	
		// private
		
		private Icon icon = MIcon.stock("ui/question");
		private MActionInfo cancel;
		private MActionInfo ok;
		private Object[] list;
		private String text;
		private String title;
		private Tuple.Two<URI, String> link;
	
		// public
		
		public Builder() { }

		public Builder cancel(final MActionInfo cancel) {
			this.cancel = cancel;
			
			return this;
		}

		public Builder cancel(final String text, final String iconName) {
			this.cancel = new MActionInfo(text, iconName);
			
			return this;
		}
		
		public boolean exec() {
			return exec(UI.windowFor(null));
		}
		
		public boolean exec(final Component owner) {
			return MMessage.customConfirm(
				(owner instanceof Window) ? (Window)owner : UI.windowFor(owner),
				title,
				icon,
				(ok == null) ? null : ok.getIcon(),
				(ok == null) ? null : ok.getText(),
				(cancel == null) ? null : cancel.getIcon(),
				(cancel == null) ? null : cancel.getText(),
				text,
				list,
				link
			);
		}

		public boolean exec(final MAction source) {
			return exec(source.getSourceWindow());
		}

		public Builder html(final String text) {
			this.text = UI.makeHTML(text);
			
			return this;
		}

		public Builder icon(final Icon icon) {
			this.icon = icon;
			
			return this;
		}

		public Builder icon(final String icon) {
			this.icon = MIcon.stock(icon);
			
			return this;
		}
		
		/**
		 * @since 4.6
		 */
		public Builder link(final URI uri) {
			link = (uri == null) ? null : Tuple.<URI, String>of(uri, null);
			
			return this;
		}

		public Builder list(final Collection<?> items) {
			this.list = items.toArray();
			
			return this;
		}

		public Builder list(final Object... items) {
			this.list = TK.copyOf(items);
			
			return this;
		}

		public Builder ok(final MActionInfo ok) {
			this.ok = ok;
			
			return this;
		}

		public Builder ok(final String text, final String iconName) {
			this.ok = new MActionInfo(text, iconName);
			
			return this;
		}
		
		/**
		 * @since 4.6
		 */
		public Builder simpleText() {
			return text(MMessage.getSimpleConfirmMessage());
		}

		public Builder text(final String text) {
			this.text = text;
			
			return this;
		}

		public Builder title(final MActionInfo title) {
			this.icon = title.getIcon();
			this.title = title.getDialogTitle();
			
			return this;
		}

		public Builder title(final String title) {
			this.title = title;
			
			return this;
		}

	}
	
	// private classes
	
	private static final class FileInfoPanel extends MPanel {
		
		// private
		
		private final File file;
		private final PreviewPanel preview;
		
		// private
		
		private FileInfoPanel(final File file, final String title) {
			super(UI.VERTICAL);
			setContentMargin();
			this.file = file;
			preview = new PreviewPanel(PreviewPanel.SMALL_WIDTH);
			preview.setMaximumHeight(PreviewPanel.SMALL_WIDTH);
			
			addSeparator(title);
			
			addInfo(i18n("Name:"), file.getPath());
			addInfo(i18n("Modified:"), new MDate(file.lastModified()).fancyFormat(MDate.FANCY_FORMAT_APPEND_TIME));
			long size = file.length();
			addInfo(i18n("Size:"), MFormat.toAutoSize(size) + " (" + size + ")");
			addContentGap();
			add(preview);
		}
		
		private void addInfo(final String label, final String info) {
			MTextLabel infoComponent = new MTextLabel(info);
			addGap();
			add(MPanel.createHLabelPanel(infoComponent, label));
		}

		private void startPreview() {
			preview.update(file);
		}

		private void stopPreview() {
			preview.cancel(true);
		}
		
	}
	
	private static final class ListView extends MList<Object> {
		
		// private
		
		private Watermark watermark;
		
		// public
		
		public ListView(final Icon icon, final Object[] data) {
			Image image = (icon instanceof ImageIcon) ? ImageIcon.class.cast(icon).getImage() : null;
			if (image != null)
				watermark = new Watermark(UI.scaleImage(image, 64, 64, UI.Quality.HIGH), new Dimension(5, 5));

			MRenderer<Object> renderer = new MRenderer<Object>(4) {
				@Override
				public boolean isFocused() { return false; }
				@Override
				public boolean isSelected() { return false; }
				@Override
				protected void onRender(final Object o) {
					this.setIcon((o instanceof Icon) ? (Icon)o : null);
					this.setText((o instanceof Icon) ? null : Objects.toString(o));
				}
			};
			renderer.setHTMLEnabled(false);
			setCellRenderer(renderer);
			
			setSingleSelectionMode();
			setToolTipText(i18n("Selected items"));
			for (Object i : data) {
				if (i != null) {
					if (i instanceof Icon) {
						addItem(i);
					}
					else {
						String s = i.toString();
						if (TK.isEmpty(s))
							addItem(" ");
						else
							addItem(TK.centerSqueeze(s, 128));
					}
				}
			}
			clearSelection();
		}
		
		@Override
		public void removeNotify() {
			super.removeNotify();
			watermark = TK.dispose(watermark);
		}
		
		// protected
		
		@Override
		protected void paintComponent(final Graphics g) {
			super.paintComponent(g);
			if (watermark != null)
				watermark.paint(this, g);
		}
		
	}

}
