// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Collections;
import javax.swing.AbstractButton;
import javax.swing.FocusManager;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.painters.GlassPainter;

/**
 * A button panel.
 * 
 * @mg.note {@link MDialog} and {@link MWizardDialog} will automatically create
 * a {@code MButtonPanel} for you.
 *
 * @mg.example
 * <pre class="brush: java">
 * okButton = new MButton(UI.i18n("Do Something"), "ui/ok");
 * cancelButton = new MButton(MActionInfo.CANCEL);
 * buttonPanel = new MButtonPanel(MButtonPanel.HORIZONTAL, okButton, cancelButton);
 * </pre>
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MButtonPanel extends MPanel {
	
	// public
	
	// flags
	
	/**
	 * The horizontal layout (default).
	 */
	public static final int HORIZONTAL = 1;

	/**
	 * The vertical layout.
	 */
	public static final int VERTICAL = 1 << 1;

	/**
	 * Ignore @ref UI.reverseOKCancel property.
	 * This flag does not work with @ref VERTICAL flag.
	 */
	public static final int NO_REVERSE = 1 << 2;
	
	/**
	 * @since 4.0
	 */
	public static final int NO_PAINTER = 1 << 3;

	// private

	private final boolean vertical;
	private static KeyAdapter keyAdapter;
	
	// public
	
	/**
	 * @throws IllegalArgumentException If @p buttons array is null or empty
	 */
	public MButtonPanel(final int flags, final AbstractButton... buttons) {
		super(null);
		
		if (TK.isEmpty(buttons))
			throw new IllegalArgumentException("\"buttons\" array is null or empty");

		MArrayList<AbstractButton> buttonList = new MArrayList<>(buttons.length);
		for (AbstractButton i : buttons) {
			if (i != null)
				buttonList.add(i);
		}

		Flags f = Flags.valueOf(flags);
		vertical = f.isSet(VERTICAL);
		if (vertical)
			setLayout(new GridLayout(buttonList.size(), 1, 0, UI.getDialogButtonSpacing()));
		else
			setLayout(new GridLayout(1, buttonList.size(), UI.getDialogButtonSpacing(), 0));
		
		if (UI.OKCancelLayout.isReversed() && f.isClear(NO_REVERSE) && !vertical)
			Collections.reverse(buttonList);
		
		for (AbstractButton i : buttonList)
			addButton(i);

		if (f.isClear(NO_PAINTER))
			setMargin(5);
		setOpaque(false);
		if (f.isClear(NO_PAINTER) && (UI.isMetal() || UI.isNimbus())) {
			GlassPainter painter = new GlassPainter();
			if (UI.isMetal())
				painter.setRoundType(GlassPainter.RoundType.NONE);
			setPainter(painter);
		}
		
		limitHeight();
	}
	
	// private
	
	private void addButton(final AbstractButton b) {
		if (b != null) {
			if (keyAdapter == null)
				keyAdapter = new StaticHandler();

			add(b);
			b.addKeyListener(keyAdapter);
		}
	}

	private static void selectButton(final KeyEvent e, final boolean next, final boolean vertical) {
		AbstractButton b = (AbstractButton)e.getSource();
		Container parent = b.getParent();
		if (parent instanceof MButtonPanel) {
			if (MButtonPanel.class.cast(parent).vertical != vertical)
				return;

			FocusManager fm = FocusManager.getCurrentManager();
			if (next)
				fm.focusNextComponent();
			else
				fm.focusPreviousComponent();
		}
	}

	// private classes

	private static final class StaticHandler extends KeyAdapter {

		// public

		@Override
		public void keyPressed(final KeyEvent e) {
			switch (e.getKeyCode()) {
				case VK_LEFT:
					MButtonPanel.selectButton(e, false, false);
					break;
				case VK_RIGHT:
					MButtonPanel.selectButton(e, true, false);
					break;
				case VK_UP:
					MButtonPanel.selectButton(e, false, true);
					break;
				case VK_DOWN:
					MButtonPanel.selectButton(e, true, true);
					break;
			}
		}

	}
	
}
