// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.mv.MV;

// TODO: optimize MV.VIEW operations if no model filter
/**
 * A tree item/node used in @ref MTreeModel.
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MTreeItem
implements
	MRenderer.Renderable,
	MutableTreeNode,
	Serializable
{
	private static final long serialVersionUID = 2879837469836957677L;
	
	// private

	private static final byte ALLOWS_CHILDREN = 1;
	private static final byte VISIBLE = 1 << 1;

	private byte flags = ALLOWS_CHILDREN | VISIBLE;
	private static final Enumeration<TreeNode> EMPTY_LIST = Collections.emptyEnumeration();
	private MutableTreeNode parent;
	transient private Object userObject;
	
	// package
	
	MArrayList<MutableTreeNode> children;

	// public
	
	public MTreeItem() { }

	/**
	 * (MODEL)
	 */
	public void add(final MutableTreeNode node) {
		reparent(node);

		if (children == null)
			children = new MArrayList<>();
		children.add(node);
	}

	/**
	 * (MODEL/VIEW)
	 */
	public TreeNode getChildAt(final int index, final MV mv) {
		if (TK.isEmpty(children))
			throw new ArrayIndexOutOfBoundsException("Node is empty");

		if (mv == MV.VIEW) {
			int viewIndex = -1;
			for (MutableTreeNode i : children) {
				if (isVisible(i)) {
					viewIndex++;

					if (viewIndex == index)
						return i;
				}
			}
			// for compatibility: throw new ArrayIndexOutOfBoundsException("Node not found");
		}

		return children.get(index);
	}

	/**
	 * (MODEL/VIEW)
	 */
	public int getChildCount(final MV mv) {
		if (TK.isEmpty(children))
			return 0;

		if (mv == MV.VIEW) {
			int result = 0;
			for (MutableTreeNode i : children) {
				if (isVisible(i))
					result++;
			}
			
			return result;
		}
		
		return children.size();
	}

	public int getIndex(final TreeNode node, final MV mv) {
		if (TK.isEmpty(children))
			return -1;
			
		if (mv == MV.VIEW) {
			int viewIndex = -1;
			for (MutableTreeNode i : children) {
				if (isVisible(i)) {
					viewIndex++;

					if (i == node)
						return viewIndex;
				}
			}
			
			return -1;
		}

		return children.indexOf(node);
	}

	/**
	 * (MODEL) Returns the parent item, root item, or @c null if this is the @b root item.
	 */
	public MTreeItem getParentItem() {
		return (MTreeItem)parent;
	}
	
	public TreeNode[] getPathArray() {
		List<TreeNode> list = getPathList();
		
		return list.toArray(new TreeNode[list.size()]);
	}
	
	public List<TreeNode> getPathList() {
		LinkedList<TreeNode> result = new LinkedList<>();
		TreeNode node = this;
		while (true) {
			result.addFirst(node);
			node = node.getParent();

			if (node == null)
				break; // while
		}
		
		return result;
	}

	/**
	 * (MODEL) Returns the tree path of this item.
	 */
	public TreePath getTreePath() {
		return new TreePath(getPathArray());
	}
	
	/**
	 * (MODEL/VIEW)
	 */
	public boolean isEmpty(final MV mv) {
		return (getChildCount(mv) == 0);
	}
	
	public boolean isFilter() {
		if (TK.isEmpty(children))
			return false;

		for (MutableTreeNode i : children) {
			if (!isVisible(i))
				return true;
		}
		
		return false;
	}
	
	public boolean isNodeAncestor(final MutableTreeNode node) {
		if (node == null)
			return false;
		
		if (node == this)
			return true;

		return getPathList().contains(node);
	}

	/**
	 * (MODEL)
	 */
	public boolean isRoot() {
		return (parent == null);
	}

	/**
	 * (VIEW)
	 */
	public boolean isVisible() {
		return (flags & VISIBLE) != 0;
	}

	/**
	 * (VIEW)
	 */
	public void setVisible(final boolean value) {
		if (value)
			flags |= VISIBLE;
		else
			flags &= ~VISIBLE;
	}

	/**
	 * @since 3.0
	 */
	public boolean matches(final MTreeItem item) { return false; }
	
	public void removeAllChildren() {
		if (children != null) {
			children.clear();
			children = null;
		}
	}
	
	/**
	 * @since 4.0
	 */
	@Obsolete
	public <T extends MTreeItem> List<T> toList(final MV modelView) {
		return toList(modelView, true);
	}

	/**
	 * @since 5.8
	 */
	@SuppressWarnings("unchecked")
	public <T extends MTreeItem> List<T> toList(final MV modelView, final boolean returnCopy) {
		if (modelView == MV.MODEL) {
			switch (getChildCount(MV.MODEL)) {
				case 0: return Collections.emptyList();
				case 1: {
					Object result = returnCopy ? Collections.singletonList((T)children.get(0)) : children;

					return (List<T>)result;
				}
				default: {
					Object result = returnCopy ? children.clone() : children;

					// HACK: ugly cast
					return (List<T>)result;
				}
			}
		}
		else {
			if (TK.isEmpty(children))
				return Collections.emptyList();

			// NOTE: Do not use getChildCount/getChildAt to avoid many nested for-loops.
			// This method is much faster for a large number of nodes.
			MArrayList<T> result = new MArrayList<>(children.size());
			for (MutableTreeNode i : children) {
				T node = (T)i;
				if (isVisible(node))
					result.add(node);
			}
			
			return result;
		}
	}

	@Override
	public String toString() { return "MTreeItem"; }

	// MutableTreeNode
	
	@Deprecated
	@Override
	public Enumeration<? extends TreeNode> children() {
		return TK.isEmpty(children) ? EMPTY_LIST : Collections.enumeration(children);
	}
	
	@Override
	public boolean getAllowsChildren() {
		return (flags & ALLOWS_CHILDREN) != 0;
	}
	
	public void setAllowsChildren(final boolean value) {
		if (value != getAllowsChildren()) {
			if (value)
				flags |= ALLOWS_CHILDREN;
			else
				flags &= ~ALLOWS_CHILDREN;
			
			if (!getAllowsChildren())
				removeAllChildren();
		}
	}
	
	@Deprecated
	@Override
	public TreeNode getChildAt(final int index) {
		return getChildAt(index, MV.MODEL);
	}
	
	@Deprecated
	@Override
	public int getChildCount() {
		return getChildCount(MV.MODEL);
	}

	@Deprecated
	@Override
	public int getIndex(final TreeNode node) {
		return getIndex(node, MV.MODEL);
	}

	@Override
	public TreeNode getParent() { return parent; }
	
	@Override
	public void setParent(final MutableTreeNode value) { parent = value; }
	
	public Object getUserObject() { return userObject; }
	
	@Override
	public void setUserObject(final Object value) { userObject = value; }
	
	@Override
	public void insert(final MutableTreeNode node, final int index) {
		reparent(node);
		
		if (children == null)
			children = new MArrayList<>();
		children.add(index, node);
	}
	
	@Override
	public boolean isLeaf() {
		return isEmpty(MV.MODEL);
	}
	
	@Override
	public void remove(final int index) {
		if (children != null)
			remove(children.get(index));
	}
	
	@Override
	public void remove(final MutableTreeNode node) {
		if (children != null)
			children.remove(node);
		node.setParent(null);
	}
	
	@Override
	public void removeFromParent() {
		if (parent != null)
			parent.remove(this);
	}
	
	/**
	 * Removes @p node from its parent then sets its parent to @c this.
	 * 
	 * @since 3.0
	 */
	public void reparent(final MutableTreeNode node) {
		node.removeFromParent();
		node.setParent(this);
	}

	// MRenderer.Renderable
	
	/**
	 * @since 3.6
	 */
	@Override
	public void setupRenderer(final MRenderer<?> r) {
		r.setIcon(null);
		r.setText(toString());
	}

	// private
	
	private boolean isVisible(final MutableTreeNode node) {
		return !(node instanceof MTreeItem) || MTreeItem.class.cast(node).isVisible();
	}
	
	// Serializable

	private void readObject(final ObjectInputStream input) throws ClassNotFoundException, IOException {
		input.defaultReadObject();
		userObject = TK.deserialize(input, "userObject");
	}

	private void writeObject(final ObjectOutputStream output) throws IOException {
		output.defaultWriteObject();
		TK.serialize(output, "userObject", userObject);
	}

}
