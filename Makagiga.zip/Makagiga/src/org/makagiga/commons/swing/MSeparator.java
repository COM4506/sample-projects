// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Stroke;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

import org.makagiga.commons.MColor;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;

/**
 * A separator (horizontal or vertical line).
 *
 * @mg.warning This class is <b>not</b> thread-safe.
 * 
 * @since 2.4, 4.0 (org.makagiga.commons.swing package)
 */
public class MSeparator extends JSeparator {

	// private

	private boolean centered;
	private transient Stroke separatorStroke;
	
	// package
	
	static final String LABEL_PROPERTY = "org.makagiga.commons.swing.MSeparator.label";
	
	// public
	
	/**
	 * Constructs a horizontal separator.
	 */
	public MSeparator() {
		this(HORIZONTAL);
	}
	
	/**
	 * Constructs a horizontal or vertical separator.
	 * 
	 * @param orientation {@code MSeparator.HORIZONTAL} - horizontal separator,
	 * {@code MSeparator.VERTICAL} - vertical separator
	 * 
	 * @throws IllegalArgumentException If @p orientation is neither @c MSeparator.HORIZONTAL nor @c MSeparator.VERTICAL
	 */
	public MSeparator(final int orientation) {
		super(orientation);
	}

	/**
	 * @since 3.4
	 */
	@Obsolete
	public boolean isCentered() { return centered; }

	/**
	 * @since 3.4
	 */
	@Obsolete
	public void setCentered(final boolean value) {
		if (value != centered) {
			centered = value;
			repaint();
		}
	}

	/**
	 * @since 5.4
	 */
	public static MSeparator newHorizontalLine(final Color color) {
		MSeparator separator = new MSeparator(HORIZONTAL);
		separator.setCentered(true);
		if (color != null)
			separator.setForeground(color);
		
		return separator;
	}

	/**
	 * @since 5.4
	 */
	public static MSeparator newHorizontalLine() {
		return newHorizontalLine(null);
	}

	// protected

	/**
	 * @since 5.2
	 */
	protected int getLineLocation() {
		if (getOrientation() == HORIZONTAL)
			return getHeight() / 2;

		return getWidth() / 2;
	}

	@Override
	protected void paintComponent(final Graphics graphics) {
		if (centered) {
			Graphics2D g = (Graphics2D)graphics.create();

			if (UI.isRetro()) {
				UIDefaults defaults = UIManager.getDefaults();
				
				Color color = defaults.getColor("Retro.Separator.color");
				g.setColor(TK.get(color, Color.BLACK));
				
				if (separatorStroke == null) {
					int strokeSize = defaults.getInt("Retro.Separator.strokeSize");
					separatorStroke = new BasicStroke((strokeSize == 0) ? 2.0f : (float)strokeSize);
				}
			}
			else {
				Color fg = UI.getForeground(this);
				g.setColor(MColor.deriveAlpha(fg, 60));

				if (separatorStroke == null)
					separatorStroke = UI.createSeparatorStroke(1.0f);
			}
			g.setStroke(separatorStroke);

			// HORIZONTAL
			if (getOrientation() == HORIZONTAL) {
				int y = getLineLocation();

				// NOTE: see MPanel.addSeparator
				Object labelObject = getClientProperty(LABEL_PROPERTY);
				if (labelObject instanceof JLabel) {
					JLabel label = (JLabel)labelObject;
					Insets i = label.getInsets();
					if (i != null)
						y = (getHeight() + i.top) / 2;
				}

				g.drawLine(0, y, getWidth() - 1, y);
			}
			// VERTICAL
			else {
				int x = getLineLocation();
				g.drawLine(x, 0, x, getHeight() - 1);
			}
			g.dispose();
		}
		else {
			super.paintComponent(graphics);
		}
	}

}
