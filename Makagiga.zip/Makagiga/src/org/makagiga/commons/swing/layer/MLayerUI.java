// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.layer;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.JLayer;
import javax.swing.plaf.LayerUI;

import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.UI;

/**
 * @since 4.2
 */
public class MLayerUI<V extends Component> extends LayerUI<V> {

	// private

	private transient Font messageFontCache;
	private final long layerEventMask;

	// public
	
	public MLayerUI() {
		this(0L);
	}
	
	public MLayerUI(final long layerEventMask) {
		this.layerEventMask = layerEventMask;
	}

	@Override
	public void installUI(final JComponent c) {
		super.installUI(c);
		JLayer.class.cast(c).setLayerEventMask(layerEventMask);
	}

	@Override
	public void uninstallUI(final JComponent c) {
		super.uninstallUI(c);
		// return to its initial state
		JLayer.class.cast(c).setLayerEventMask(0);
	}

	/**
	 * @since 5.0
	 */
	public JLayer<V> wrap(final V c) {
		return new JLayer<>(c, this);
	}

	// protected

	protected void paintMessage(final Graphics g, final JComponent c, final Color background, final Color foreground, final String text) {
		if (background != null) {
			g.setColor(background);
			g.fillRect(0, 0, c.getWidth() - 1, c.getHeight() - 1);
		}
		g.setColor(foreground);
		MGraphics2D mg = new MGraphics2D(g);
		if (messageFontCache == null)
			messageFontCache = new Font(Font.DIALOG, Font.BOLD, UI.getDefaultFontSize() + 2);
		mg.setFont(messageFontCache);
		mg.setTextAntialiasing(null);
		mg.drawStringCentered(text, c);
	}

}
