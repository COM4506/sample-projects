// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.layer;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;
import javax.swing.JLayer;

import org.makagiga.commons.UI;

/**
 * @since 4.8
 */
public class LoupeLayerUI extends MLayerUI<JComponent> {

	// public

	public static final double MINIMUM_ZOOM = 1.0d;

	// private

	private boolean enabled;
	private BufferedImage imageBuf;
	private final Dimension size = new Dimension(100, 100);
	private double zoom = 2d;
	private final Point mousePos = new Point(-1, -1);
	private final Rectangle repaintRect = new Rectangle();
	
	// public

	public LoupeLayerUI() {
		super(
			AWTEvent.MOUSE_EVENT_MASK |
			AWTEvent.MOUSE_MOTION_EVENT_MASK |
			AWTEvent.MOUSE_WHEEL_EVENT_MASK
		);
	}

	@Override
	public void eventDispatched(final AWTEvent e, final JLayer<? extends JComponent> l) {
		if (e instanceof MouseEvent) {
			if (!isEnabled())
				return;
		
			MouseEvent me = (MouseEvent)e;
			JComponent view = l.getView();
			switch (me.getID()) {
				case MouseEvent.MOUSE_DRAGGED:
				case MouseEvent.MOUSE_MOVED: {
					optimizedRepaint(view); // repaint old area
                                        mousePos.setLocation(me.getPoint());
					optimizedRepaint(view); // repaint new area
				} break;
				
				case MouseEvent.MOUSE_PRESSED:
				case MouseEvent.MOUSE_RELEASED:
					optimizedRepaint(view);
					break;
					
				case MouseEvent.MOUSE_WHEEL: {
					if (!(e instanceof MouseWheelEvent))
						return;

					MouseWheelEvent mwe = (MouseWheelEvent)e;
					int rot = mwe.getWheelRotation();
					// change size
					if (me.isShiftDown()) {
						int d = 10;
						if (rot > 0) {
							Dimension oldSize = new Dimension(size);
							size.width -= d;
							size.height -= d;
							optimizedRepaint(view, me.getX(), me.getY(), oldSize, zoom);
						}
						else if (rot < 0) {
							size.width += d;
							size.height += d;
							optimizedRepaint(view);
						}
					}
					// zoom in/out
					else if (me.isControlDown()) {
						double d = 0.2d;
						if ((rot > 0) && (zoom > MINIMUM_ZOOM)) {
							double oldZoom = zoom;
							zoom = Math.max(MINIMUM_ZOOM, zoom - d);
							optimizedRepaint(view, me.getX(), me.getY(), size, oldZoom);
						}
						else if (rot < 0) {
							zoom += d;
							optimizedRepaint(view);
						}
					}
				} break;
			}
		}
	}
	
	public Dimension getSize() {
		return new Dimension(size);
	}

	public void setSize(final int w, final int h) {
		size.setSize(w, h);
	}

	public double getZoom() { return zoom; }
	
	public void setZoom(final double value) { zoom = value; }
	
	public boolean isEnabled() { return enabled; }
	
	public void setEnabled(final boolean value) { enabled = value; }
	
	@Override
	public void paint(final Graphics cg, final JComponent component) {
		
		// paint component
		
		super.paint(cg, component);
		
		// create zoom image
		
		if (!enabled)
			return;
		
		if (zoom <= MINIMUM_ZOOM)
			return;
		
		if ((mousePos.x == -1) && (mousePos.y == -1))
			return;
		
		if ((size.width <= 0) || (size.height <= 0))
			return;
		
		if ((imageBuf == null) || (imageBuf.getWidth() != size.width) || (imageBuf.getHeight() != size.height))
			imageBuf = UI.createCompatibleImage(size.width, size.height, true);

		Graphics2D ig = imageBuf.createGraphics();
		
		double tx = -((double)mousePos.x - (double)size.width / 2d / zoom) * zoom;
		double ty = -((double)mousePos.y - (double)size.height / 2d / zoom) * zoom;
		ig.translate(tx, ty);
		ig.scale(zoom, zoom);
		super.paint(ig, component);
		ig.dispose();
		
		// paint loupe
		
		int ix = mousePos.x - size.width / 2;
		int iy = mousePos.y - size.height / 2;
		cg.drawImage(imageBuf, ix, iy, null);
		cg.setColor(Color.LIGHT_GRAY);
		cg.drawRect(ix, iy, size.width - 1, size.height - 1);

		// debug
/*
		cg.setColor(Color.RED);
		int lineX = mousePos.x - size.width / 2;
		cg.drawLine(lineX, mousePos.y, lineX + size.width, mousePos.y);
*/
	}
	
	// private
	
	private void optimizedRepaint(final JComponent view) {
		optimizedRepaint(view, mousePos.x, mousePos.y, size, zoom);
	}
	
	private void optimizedRepaint(final JComponent view, final int x, final int y, final Dimension d, final double zoom) {
		int iw = (int)(d.width * zoom);
		int ih = (int)(d.height * zoom);
		repaintRect.setLocation(x - iw / 2, y - ih / 2);
		repaintRect.setSize(iw, ih);
		view.repaint(repaintRect);
	}

}