// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.layer;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.JLayer;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;

/**
 * @since 4.2
 */
public class BrowseLayerUI extends MLayerUI<Component> {

	// private

	private final Point dragStart = new Point();
	
	// public

	public BrowseLayerUI() {
		super(AWTEvent.MOUSE_EVENT_MASK | AWTEvent.MOUSE_MOTION_EVENT_MASK);
	}
	
	@Override
	public void eventDispatched(final AWTEvent e, final JLayer<? extends Component> l) {
		if (e instanceof MouseEvent) {
			MouseEvent me = (MouseEvent)e;
			switch (me.getID()) {
				case MouseEvent.MOUSE_PRESSED: {
					dragStart.setLocation(me.getX(), me.getY());
					l.getView().setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				} break;
				case MouseEvent.MOUSE_RELEASED: {
					l.getView().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
				} break;
				case MouseEvent.MOUSE_DRAGGED: {
					Component view = l.getView();
					Container parent = SwingUtilities.getUnwrappedParent(view);
					if (parent instanceof JViewport) {
						JViewport viewport = (JViewport)parent;
						Point p = viewport.getViewPosition();
						p.translate(dragStart.x - me.getX(), dragStart.y - me.getY());
						p.x = Math.max(0, p.x);
						p.y = Math.max(0, p.y);
						viewport.setViewPosition(p);
						me.consume();
					}
				} break;
			}
		}
	}

}