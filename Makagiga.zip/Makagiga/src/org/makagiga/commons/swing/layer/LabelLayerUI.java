// Copyright 2012 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.layer;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Polygon;
import java.util.Objects;
import javax.swing.JComponent;
import javax.swing.JLayer;

import org.makagiga.commons.UI;

/**
 * @since 4.6
 */
public class LabelLayerUI extends MLayerUI<JComponent> {

	// private

	private boolean visible = true;
	private Color background = new Color(0x70bfd9ff, true);
	private Color borderColor = new Color(0x700000bf, true);
	private Color foreground = borderColor;
	private Font font;
	private int padding = 15;
	private String text = "Text";
	
	// public

	public LabelLayerUI() { }
	
	public LabelLayerUI(final String text) {
		setText(text);
	}
	
	public Color getBackground() { return background; }
	
	public void setBackground(final Color value) {
		background = Objects.requireNonNull(value);
	}

	public Color getBorderColor() { return borderColor; }
	
	public void setBorderColor(final Color value) { borderColor = value; }

	public Font getFont() {
		if (font == null)
			font = new Font(Font.DIALOG, Font.BOLD, 24);
	
		return font;
	}
	
	public void setFont(final Font value) {
		font = Objects.requireNonNull(value);
	}

	public Color getForeground() { return foreground; }
	
	public void setForeground(final Color value) {
		foreground = Objects.requireNonNull(value);
	}
	
	public int getPadding() { return padding; }
	
	public void setPadding(final int value) {
		if (value < 0)
			throw new IllegalArgumentException("value < 0");
	
		padding = value;
	}
	
	public String getText() { return text; }
	
	public void setText(final String value) { text = value; }

	public boolean isVisible() { return visible; }
	
	public void setVisible(final boolean value) { visible = value; }

	@Override
	public void paint(final Graphics componentGraphics, final JComponent component) {
		super.paint(componentGraphics, component);
		
		if (!visible)
			return;
		
		if (text == null)
			return;
		
		Graphics2D g = (Graphics2D)componentGraphics.create();
		
		// enable antialiasing
		UI.setAntialiasing(g, true);
		UI.setBasicTextAntialiasing(g, true);

		g.setFont(getFont());
		FontMetrics fm = g.getFontMetrics();
		
		int addPadding = 0;
		int minOffset = 100;
		int s = fm.stringWidth(text) + padding * 2;
		
		// fix for a very short text
		if (s < minOffset) {
			addPadding = (minOffset - s) / 2;
			s = minOffset;
		}
		
		int textHeight = fm.getHeight();
		
		// draw background
		
		g.setColor(getBackground());
		Polygon p = new Polygon();
		
		int topLeftX = s - textHeight - padding;
		int topRightX = s + padding;
		
		int insetsY = 0;
		int insetsX = 0;
		Insets insets = null;
		if (component instanceof JLayer) {
			JLayer<?> layer = (JLayer<?>)component;
			insets = JComponent.class.cast(layer.getView()).getInsets();
		}
		if (insets != null) {
			insetsX += insets.left;
			insetsY += insets.top;
		}
		
		// top
		p.addPoint(insetsX + topLeftX, insetsY);
		p.addPoint(insetsX + topRightX, insetsY);
		// bottom
		p.addPoint(insetsX, s + padding + insetsY);
		p.addPoint(insetsX, s - textHeight - padding + insetsY);
		
		g.fill(p);
		
		// draw border
		
		if (borderColor != null) {
			g.setColor(borderColor);
			g.drawLine(insetsX + topLeftX, insetsY, insetsX, s - textHeight - padding + insetsY);
			g.drawLine(insetsX + topRightX, insetsY, insetsX, s + padding + insetsY);
		}
		
		// draw text
		
		g.setColor(getForeground());
		g.rotate(Math.toRadians(-45), (double)s / 2d, (double)s / 2d);
		g.drawString(text, padding + addPadding, s / 2 + insetsY);
		
		g.dispose();
	}

}
