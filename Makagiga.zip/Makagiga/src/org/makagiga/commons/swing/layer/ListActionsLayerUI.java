// Copyright 2012 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing.layer;

import java.awt.AWTEvent;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.util.Objects;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLayer;
import javax.swing.JList;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 4.6
 */
public class ListActionsLayerUI extends MLayerUI<JComponent> {

	// public

	public static final String INDEX_PROPERTY = "org.makagiga.commons.swing.layer.ListActionsLayerUI.INDEX_PROPERTY";
	
	// private

	private Action currentAction;
	private boolean mouseOver;
	private int currentIndex = NONE;
	private static final int NONE = Integer.MIN_VALUE;
	private int iconMargin = 5;
	private int lastIndex = NONE;
	private final MArrayList<Object> actionList = new MArrayList<>();
	private final Point pressedPoint = new Point(-1, -1);
	private final Rectangle iconArea = new Rectangle(NONE, NONE, NONE, NONE);
	private final Rectangle oldIconArea = new Rectangle(NONE, NONE, NONE, NONE);
	private final String actionIconKey;
	private static final String SEPARATOR = "-";
	
	// public

	public ListActionsLayerUI(final String actionIconKey) {
		super(MouseEvent.MOUSE_EVENT_MASK | MouseEvent.MOUSE_MOTION_EVENT_MASK);
		this.actionIconKey = Objects.requireNonNull(actionIconKey);
	}
	
	public void addAction(final Action a) {
		actionList.add(Objects.requireNonNull(a));
	}

	public void removeAction(final Action a) {
		actionList.remove(Objects.requireNonNull(a));
	}
	
	public void addSeparator() {
		actionList.add(SEPARATOR);
	}

	@Override
	public void eventDispatched(final AWTEvent e, final JLayer<? extends JComponent> l) {
		if (e instanceof MouseEvent) {
			MouseEvent me = (MouseEvent)e;
			JList<?> list = (JList<?>)l.getView();
			switch (me.getID()) {
				case MouseEvent.MOUSE_MOVED: {
					oldIconArea.setBounds(iconArea);
					updateActionInfo(l, list, me);

					if (MMenu.getCurrentPopup() != null) {
						// hide actions if popup menu is visible
						if (oldIconArea.x != NONE) {
							l.repaint(oldIconArea);
							oldIconArea.x = NONE;
						}
						
						return;
					}

					// set cursor and tool tip text
					if (mouseOver && (currentAction != null) && currentAction.isEnabled()) {
						list.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
						Object o = currentAction.getValue(Action.SHORT_DESCRIPTION);
						if (o == null)
							o = currentAction.getValue(Action.NAME);
						list.setToolTipText(Objects.toString(o, null));
					}
					else {
						list.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
						list.setToolTipText(null);
					}
					
					// repaint changed areas
					if (!oldIconArea.equals(iconArea)) {
						l.repaint(oldIconArea);
						l.repaint(iconArea);
					}
				} break;
				
				case MouseEvent.MOUSE_RELEASED/*MOUSE_CLICKED*/: {
					updateActionInfo(l, list, me);
					if (
						MMouseAdapter.isLeft(me) && mouseOver &&
						(currentAction != null) && currentAction.isEnabled() &&
						MMouseAdapter.isButtonClick(me, pressedPoint)
					) {
						me.consume();
						try {
							currentAction.putValue(INDEX_PROPERTY, currentIndex);
							MAction.fire(currentAction, list);
						}
						finally {
							currentAction.putValue(INDEX_PROPERTY, null);
						}
					}
				} break;
				
				case MouseEvent.MOUSE_PRESSED: {
					updateActionInfo(l, list, me);
					if (MMouseAdapter.isLeft(me) && (currentAction != null)) {
						pressedPoint.setLocation(me.getX(), me.getY());
						me.consume(); // do not select list item after action fire
					}
				} break;
			}
		}
	}
	
	/**
	 * @since 4.8
	 */
	public int getIconMargin() { return iconMargin; }

	/**
	 * @since 4.8
	 */
	public void setIconMargin(final int value) { iconMargin = value; }

	@Override
	public void paint(final Graphics g, final JComponent layer) {
		super.paint(g, layer);
		
		JList<?> list = (JList<?>)JLayer.class.cast(layer).getView();
		
		if ((list.getModel().getSize() == 0) || actionList.isEmpty() || (iconArea.x == NONE) || (iconArea.y == NONE))
			return;
		
		int x = layer.getWidth();
		for (Object item : TK.reverse(actionList)) {
			if (item.equals(SEPARATOR)) {
				x -= MPanel.DEFAULT_CONTENT_MARGIN;
			}
			else if (item instanceof Action) {
				Action action = (Action)item;
				Icon icon = getIcon(action);
				if (icon != null)  {
					x -= (icon.getIconWidth() + iconMargin);
					if (!action.isEnabled() && (icon instanceof MIcon))
						icon = MIcon.class.cast(icon).getDisabledInstance();
					icon.paintIcon(layer, g, x, iconArea.y);
				}
			}
		}
	}
	
	// protected
	
	protected void currentIndexChanged(final MouseEvent e) { }
	
	protected int getCurrentIndex() { return currentIndex; }
	
	// private

	private Icon getIcon(final Action action) {
		return (Icon)action.getValue(actionIconKey);
	}

	private void updateActionInfo(final JLayer<?> layer, final JList<?> list, final MouseEvent e) {
		// invalidate
		currentAction = null;
		currentIndex = NONE;
		iconArea.setSize(NONE, NONE);
		mouseOver = false;

		if (MMenu.getCurrentPopup() != null)
			return;

		if (actionList.isEmpty())
			return;

		currentIndex = list.locationToIndex(e.getPoint());
		
		if (currentIndex == -1)
			return;

		if (currentIndex != lastIndex) {
			lastIndex = currentIndex;
			currentIndexChanged(e);
		}

		iconArea.setLocation(0, list.indexToLocation(currentIndex).y);

		iconArea.height = NONE;
		for (Object i : actionList) {
			if (i instanceof Action) {
				Action action = (Action)i;
				Icon icon = getIcon(action);
				if (icon != null)
					iconArea.height = Math.max(icon.getIconHeight(), iconArea.height);
			}
		}
		if (iconArea.height > 0) {
			Rectangle cellRect = list.getCellBounds(currentIndex, currentIndex);
			if (cellRect != null) {
				iconArea.y += cellRect.height / 2;
				iconArea.y -= iconArea.height / 2;
			}
		}

		iconArea.width = layer.getWidth();
		int x = iconArea.width;
		for (Object item : TK.reverse(actionList)) {
			if (item.equals(SEPARATOR)) {
				x -= MPanel.DEFAULT_CONTENT_MARGIN;
			}
			else if (item instanceof Action) {
				Action action = (Action)item;
				Icon icon = getIcon(action);
				if (icon != null)
					x -= (icon.getIconWidth() + iconMargin);

				if (x <= e.getX()) {
					currentAction = action;
					mouseOver = (e.getY() >= iconArea.y) && (e.getY() <= iconArea.y + icon.getIconHeight() - 1);
				
					break; // for
				}
			}
		}
	}

}