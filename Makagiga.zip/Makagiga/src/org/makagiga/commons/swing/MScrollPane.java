// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import javax.swing.plaf.metal.MetalBorders;
import javax.swing.plaf.metal.MetalLookAndFeel;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.fx.MTimeline;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.commons.swing.layer.BrowseLayerUI;

/**
 * A scroll pane (pane with scroll bars).
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MScrollPane extends JScrollPane {
	
	// public

	/**
	 * @deprecated As of 4.2, replaced by {@link #BROWSE_LAYER}
	 */
	@Deprecated
	public static final int DRAG_SCROLLER = 1;

	public static final int NO_BORDER = 1 << 1;
	
	/**
	 * @since 4.2
	 */
	public static final int BROWSE_LAYER = 1 << 2;
	
	/**
	 * @since 4.2
	 */
	public static final int NO_BORDER_AUTO = 1 << 3;

	/**
	 * @since 5.6
	 */
	public static final int FAST_SCROLL = 1 << 4;

	// private

	private int maximumHeight = -1;
	private static SharedHandler sharedHandler;
	private Size prefSize;
	private static final String SCROLL_TIMELINE_PROPERTY = "org.makagiga.commons.swing.MScrollPane.scrollTimeline";

	// public

	/**
	 * @since 3.8.6
	 */
	public MScrollPane() {
		this(null, 0);
	}

	/**
	 * @since 3.8.6
	 */
	public MScrollPane(final int flags) {
		this(null, flags);
	}

	/**
	 * Constructs a scroll pane.
	 * @param component A component to add to the scroll pane
	 */
	public MScrollPane(final JComponent component) {
		this(component, 0);
	}

	/**
	 * Constructs a scroll pane.
	 * @param component A component to add to the scroll pane
	 * @param flags The flags
	 */
	public MScrollPane(final JComponent component, final int flags) {
		super(
			((flags & BROWSE_LAYER) != 0)
			? new BrowseLayerUI().wrap(component)
			: component
		);
		Flags f = Flags.valueOf(flags);
		if (f.isSet(DRAG_SCROLLER))
			installDragScroller(component);
		if (f.isSet(NO_BORDER))
			setBorder(null);
		if (f.isSet(NO_BORDER_AUTO) && !UI.isPgs())
			setBorder(null);

		if (sharedHandler == null)
			sharedHandler = new SharedHandler();

		addComponentListener(sharedHandler);

		JScrollBar scrollBar = getHorizontalScrollBar();
		if (scrollBar != null)
			scrollBar.addMouseWheelListener(sharedHandler);

		if (f.isSet(FAST_SCROLL))
			setScrollSpeed(30);
	}

	/**
	 * Scrolls the component.
	 * @param component A component to scroll
	 * @param x A horizontal offset
	 * @param y A vertical offset
	 */
	public static void autoScroll(final JComponent component, final int x, final int y) {
		component.scrollRectToVisible(new Rectangle(x, y, 1, 1));
	}

	/**
	 * @since 3.8
	 */
	@Obsolete
	public int getMaximumHeight() { return maximumHeight; }

	/**
	 * @since 3.8
	 */
	@Obsolete
	public void setMaximumHeight(final int value) {
		if (value != maximumHeight) {
			maximumHeight = value;
			revalidate();
		}
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension d = super.getPreferredSize();

		if (prefSize != null)
			return prefSize.apply(this, d);

		if (maximumHeight == -1)
			return d;

		return new Dimension(d.width, maximumHeight);
	}

	/**
	 * @since 5.6
	 */
	public void setPreferredSize(final Size size) { prefSize = size; }

	/**
	 * @since 3.8.6
	 */
	public static JScrollPane getScrollPane(final Component component) {
		JViewport viewport = getViewport(component);

		if (viewport == null)
			return null;

		Component parent = viewport.getParent();

		return
			(parent instanceof JScrollPane)
			? (JScrollPane)parent
			: null;
	}

	/**
	 * @since 3.8.6
	 */
	public static JViewport getViewport(final Component component) {
		Container parent = SwingUtilities.getUnwrappedParent(component);

		return (parent instanceof JViewport) ? (JViewport)parent : null;
	}

	/**
	 * @deprecated Since 4.2
	 */
	@Deprecated
	public static DragScroller installDragScroller(final JComponent component) {
		return new DragScroller(component);
	}
	
	/**
	 * Scrolls a component.
	 *
	 * Keyboard info:
	 * - Alt - scroll horizontally
	 * - Ctrl - double scroll speed
	 *
	 * @param component A component to scroll
	 * @param e A mouse wheel event
	 */
	public static void mouseWheelScroll(final JComponent component, final MouseWheelEvent e) {
		if (component == null)
			return;

		if (e == null)
			return;

		Rectangle r = component.getVisibleRect();

		int speed = (e.getWheelRotation() * 30);

		// ctrl - double speed
		if (e.isControlDown())
			speed *= 2;

		// alt - scroll horizontally
		if (e.isAltDown())
			r.translate(speed, 0);
		else
			r.translate(0, speed);

		component.scrollRectToVisible(r);
	}

	@Override
	public void paint(final Graphics graphics) {
		super.paint(graphics);

		// ensure it's a default Metal border:

		if (!UI.isMetal())
			return;

		if (!(getBorder() instanceof MetalBorders.ScrollPaneBorder))
			return;

		Insets i = getInsets();
		
		if ((i == null) || (i.right != 2) || (i.bottom != 2))
			return;

		// HACK: patch one-pixel border "artefacts" in top/right and bottom/left corners
		try (MGraphics2D g = MGraphics2D.copy(graphics)) {
			g.setColor(MetalLookAndFeel.getControlDarkShadow()/* getSecondary1()/0x7A8A99 */);
			g.drawPoint(1, getHeight() - 2);
			g.drawPoint(getWidth() - 2, 2);
		}
	}

	public static void scrollToBottom(final JComponent c, final boolean resetX) {
		doVerticalScroll(c, false, resetX);
	}

	/**
	 * @since 4.6
	 */
	public static void scrollToLeft(final JComponent c) {
		doHorizontalScroll(c, true);
	}

	/**
	 * @since 3.8
	 */
	public static void scrollToNextItem(final JComponent c, final Rectangle itemBounds) {
		if (itemBounds != null) {
			Rectangle r = (Rectangle)itemBounds.clone();
			
			// keep the parent node visible
			if (c instanceof JTree)
				r.x = Math.max(0, r.x - 50);
			
			c.scrollRectToVisible(r);

			// add bottom margin, so user can see next item
			JViewport v = getViewport(c);
			int yOffset = (v == null) ? 0 : v.getViewPosition().y;
			if (yOffset > 0) {
				r.translate(0, r.height);
				c.scrollRectToVisible(r);
			}
		}
	}

	public static void scrollToTop(final JComponent c, final boolean resetX) {
		doVerticalScroll(c, true, resetX);
	}

	/**
	 * @since 5.0
	 */
	public static <T extends JComponent> MTimeline<T> scrollToVisible(final T c, final Rectangle r) {
		return scrollToVisible(c, r, 250);
	}

	/**
	 * @since 5.0
	 */
	public static <T extends JComponent> MTimeline<T> scrollToVisible(final T c, final Rectangle r, final long duration) {
		JViewport viewport = getViewport(c);

		// end animation that is already in progress
		if (viewport != null) {
			Object timelineObject = viewport.getClientProperty(SCROLL_TIMELINE_PROPERTY);
			if (timelineObject instanceof MTimeline) {
				MTimeline.class.cast(timelineObject).cancel();
				MTimeline.class.cast(timelineObject).setEnabled(false);
				viewport.putClientProperty(SCROLL_TIMELINE_PROPERTY, null);
				c.scrollRectToVisible(r);
				
				return null;
			}
		}

		if ((duration == 0) || (viewport == null) || !c.isDisplayable()) {
			c.scrollRectToVisible(r);

			return null;
		}
		
		Rectangle from = new Rectangle(viewport.getViewRect());
		Rectangle to = new Rectangle(r);
		Rectangle current = new Rectangle(from);
		
		MTimeline<T> timeline = new MTimeline<>(c, duration);
		timeline.setEase(MTimeline.Ease.SINE);

		timeline.addPropertyToInterpolate(
			MTimeline.<Rectangle>property("rect")
			.from(from)
			.to(to)
			.getWith((object, name) -> current)
			.setWith((object, name, value) -> c.scrollRectToVisible(value))
		);

		timeline.addCallback(new MTimeline.UICallback() {
			@Override
			public void onDone() {
				viewport.putClientProperty(SCROLL_TIMELINE_PROPERTY, null);
			}
		} );

		viewport.putClientProperty(SCROLL_TIMELINE_PROPERTY, timeline);
		timeline.play();
		
		return timeline;
	}
	
	/**
	 * @since 2.2
	 */
	public void setScrollBarVisible(final boolean value) {
		setHorizontalScrollBarPolicy(value ? HORIZONTAL_SCROLLBAR_AS_NEEDED : HORIZONTAL_SCROLLBAR_NEVER);
		setVerticalScrollBarPolicy(value ? VERTICAL_SCROLLBAR_AS_NEEDED : VERTICAL_SCROLLBAR_NEVER);
	}

	@Obsolete
	public void setScrollSpeed(final int value) {
		getHorizontalScrollBar().setUnitIncrement(value);
		getVerticalScrollBar().setUnitIncrement(value);
	}

	// private

	private static void doHorizontalScroll(final JComponent c, final boolean left) {
		JViewport v =
			(c instanceof JScrollPane)
			? JScrollPane.class.cast(c).getViewport()
			: getViewport(c);
		if (v != null) {
			Point p = v.getViewPosition();
			p.x = left ? 0 : v.getViewSize().width;
			v.setViewPosition(p);
		}
	}

	private static void doVerticalScroll(final JComponent c, final boolean top, final boolean resetX) {
		JViewport v =
			(c instanceof JScrollPane)
			? JScrollPane.class.cast(c).getViewport()
			: getViewport(c);
		if (v != null) {
			Point p = v.getViewPosition();
			if (resetX)
				p.x = 0;
			p.y = top ? 0 : v.getViewSize().height;
			v.setViewPosition(p);
		}
	}

	// package
	
	static Rectangle convertRectangle(final Container container, final Component c) {
		JScrollPane scrollPane = getScrollPane(c);
		
		return SwingUtilities.convertRectangle(
			(scrollPane != null) ? scrollPane.getParent() : c.getParent(),
			(scrollPane != null) ? scrollPane.getBounds() : c.getBounds(),
			container
		);
	}

	// public classes

	/**
	 * @deprecated Since 4.2
	 */
	@Deprecated
	public static class DragScroller {
		
		// private

		private final Point startDrag = new Point();

		// public
		
		public DragScroller(final JComponent component) {
			MMouseAdapter mouseAdapter = new MMouseAdapter() {
				@Override
				public void mouseDragged(final MouseEvent e) {
					int dx = startDrag.x - e.getX();
					int dy = startDrag.y - e.getY();
					JComponent component = (JComponent)e.getSource();
					JViewport viewport = MScrollPane.getViewport(component);
					Point viewPosition = viewport.getViewPosition();
					viewPosition.translate(dx, dy);
					viewport.setViewPosition(viewPosition);
					e.consume();
				}
				@Override
				public void mousePressed(final MouseEvent e) {
					startDrag.setLocation(e.getX(), e.getY());
					UI.setStyle("cursor: pointer", e.getComponent());
				}
				@Override
				public void mouseReleased(final MouseEvent e) {
					startDrag.setLocation(0, 0);
					UI.setStyle("cursor: default", e.getComponent());
				}
			};
			component.addMouseListener(mouseAdapter);
			component.addMouseMotionListener(mouseAdapter);
		}
		
	}
	
	// private classes
	
	private static final class SharedHandler extends ComponentAdapter implements MouseWheelListener {
	
		// public
		
		public SharedHandler() { }

		// HACK: adjust editor width after scroll pane resize
		@Override
		public void componentResized(final ComponentEvent e) {
			if (!(e.getSource() instanceof JScrollPane))
				return;

			JScrollPane sp = (JScrollPane)e.getSource();
			JViewport viewport = sp.getViewport();

			if (viewport == null)
				return;

			Component view = viewport.getView();
			if (view instanceof MEditorPane) {
				MEditorPane editor = (MEditorPane)view;
				
				if (!"text/plain".equals(editor.getContentType()))
					return;
				
				int magic;
				JScrollBar vScrollBar = sp.getVerticalScrollBar();
				if ((vScrollBar != null) && vScrollBar.isVisible())
					magic = vScrollBar.getWidth();
				else
					magic = 0;

				if (view.getWidth() + magic > sp.getWidth())
					view.setSize(sp.getWidth() - magic, view.getHeight());
			}
		}

		@Override
		public void mouseWheelMoved(final MouseWheelEvent e) {
			if (e.getSource() instanceof JScrollBar) {
				JScrollBar scrollBar = (JScrollBar)e.getSource();
				if (scrollBar.isEnabled() && (scrollBar.getOrientation() == JScrollBar.HORIZONTAL))
					MAction.fire(e, "negativeUnitIncrement", "positiveUnitIncrement", scrollBar);
			}
		}

	}

}
