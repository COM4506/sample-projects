// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.SwingUtilities;

import org.makagiga.commons.UI;

/**
 * A basic component.
 *
 * @since 3.4, 4.0 (org.makagiga.commons.swing package)
 */
public class MComponent extends JComponent {
	
	// public

	/**
	 * Constructs a component with {@code null} layout.
	 */
	public MComponent() { }

	/**
	 * Constructs a component with {@code layout}.
	 *
	 * @param layout the layout manager
	 */
	public MComponent(final LayoutManager layout) {
		setLayout(layout);
	}

	/**
	 * @since 3.8.1
	 */
	public static BufferedImage createScreenshot(final Component c, final Color background) {
		return createScreenshot(c, background, null);
	}

	/**
	 * @since 4.2
	 */
	public static BufferedImage createScreenshot(final Component c, final Color background, final Dimension clip) {
		int w = (clip == null) ? c.getWidth() : clip.width;
		int h = (clip == null) ? c.getHeight() : clip.height;
		BufferedImage image = UI.createCompatibleImage(w, h, true);
		Graphics2D g = image.createGraphics();
		if (background != null) {
			g.setColor(background);
			g.fillRect(0, 0, w, h);
		}
		UI.setTextAntialiasing(g, null);
		if (clip != null)
			g.setClip(0, 0, w, h);
		c.paint(g);
		g.dispose();

		return image;
	}

	/**
	 * @since 3.8.8
	 */
	public static boolean removeFromParent(final Component component, final boolean validateParent) {
		Container parent = component.getParent();
		if (parent != null) {
			parent.remove(component);

			if (validateParent) {
				parent.validate();
				parent.repaint();
			}

			return true;
		}

		return false;
	}

	/**
	 * @since 3.8.1
	 */
	public static void replace(final Container container, final Component remove, final Component add, final Object constraints, final boolean revalidate) {
		if (remove == add)
			return;

		boolean shouldValidate = false;
		
		if (remove != null) {
			container.remove(remove);
			shouldValidate = true;
		}

		if (add != null) {
			if (constraints == null) {
				if ((container instanceof MPanel) && (add instanceof JComponent))
					MPanel.class.cast(container).add((JComponent)add); // fix vbox layout
				else
					container.add(add);
			}
			else {
				container.add(add, constraints);
			}
			shouldValidate = true;
		}

		if (shouldValidate) {
			if (revalidate && (container instanceof JComponent)) {
				JComponent jc = (JComponent)container;
				jc.revalidate();
			}
			else {
				container.validate();
			}
			container.repaint();
		}
	}

	/**
	 * @since 3.8.1
	 */
	public static void requestFocus(final Component c) {
		if (c instanceof JScrollPane) {
			Component v = SwingUtilities.getUnwrappedView(JScrollPane.class.cast(c).getViewport());
			if (v != null)
				requestFocus(v);
		}
		else if (c instanceof MText.TextFieldExtensions) {
			doRequestTextFieldFocus(c);
		}
		else if (c instanceof MWrapperPanel<?>) {
			JComponent v = MWrapperPanel.class.cast(c).getView();
			if (v instanceof MText.TextFieldExtensions) {
				doRequestTextFieldFocus(v);
			}
			else {
				doFocus(v);
			}
		}
		else {
			doFocus(c);
		}
	}
	
	/**
	 * Workaround for asynchronous Swing focus manager.
	 *
	 * @see <a href="http://docs.oracle.com/javase/tutorial/uiswing/misc/focus.html#transferTiming">Timing Focus Transfers</a>
	 *
	 * @since 4.4
	 */
	public static void requestFocusLater(final Component c) {
		MTimer.milliseconds(500, timer -> {
			c.requestFocusInWindow();
			
			return MTimer.STOP;
		} )
			.start();
	}

	/**
	 * Sets mouse cursor to {@code type}.
	 *
	 * @param type the cursor type
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * setCursor(java.awt.Cursor.HAND_CURSOR);
	 * </pre>
	 *
	 * @throws IllegalArgumentException If {@code type} is invalid
	 */
	public void setCursor(final int type) {
		setCursor(Cursor.getPredefinedCursor(type));
	}
	
	/**
	 * @since 4.6
	 */
	public static Dimension setFixedSize(final Component component, final Dimension size) {
		return setFixedSize(component, size.width, size.height);
	}
	
	/**
	 * Sets maximum, minimum, preferred and normal size
	 * of {@code component} to {@code width} and {@code height}.
	 * 
	 * @param width the new component width
	 * @param height the new component height
	 * 
	 * @return A new dimension set to {@code width} and {@code height}
	 * 
	 * @throws NullPointerException If {@code component} is {@code null}
	 * 
	 * @since 4.0
	 */
	public static Dimension setFixedSize(final Component component, final int width, final int height) {
		Dimension d = new Dimension(width, height);
		component.setMaximumSize(d);
		component.setMinimumSize(d);
		component.setPreferredSize(d);
		component.setSize(d);

		return d;
	}

	// private

	private static void doFocus(final Component component) {
		if (component == null)
			return;
		
		if (component instanceof Focusable)
			Focusable.class.cast(component).focus();
		else
			component.requestFocusInWindow();
	}

	private static void doRequestTextFieldFocus(final Component c) {
		if (c instanceof JSpinner) {
			// do not focus disabled spinner
			if (c.isEnabled())
				MText.TextFieldExtensions.class.cast(c).makeDefault();
		}
		else if (c instanceof JComboBox<?>) {
			// do not focus disabled combo box
			if (c.isEnabled())
				MText.TextFieldExtensions.class.cast(c).makeDefault();
		}
		else {
			MText.TextFieldExtensions.class.cast(c).makeDefault();
		}
	}

}
