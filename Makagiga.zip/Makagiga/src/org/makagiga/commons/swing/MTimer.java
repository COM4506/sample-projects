// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Method;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import javax.swing.Timer;

import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.annotation.Obsolete;

/**
 * A timer.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTimer extends Timer implements MDisposable {

	// private
	
	private final AccessControlContext acc;
	private Predicate<MTimer> onTimeout;

	// public

	/**
	 * @since 4.2
	 */
	public static final boolean CONTINUE = true;

	/**
	 * @since 4.2
	 */
	public static final boolean STOP = false;

	// public

	/**
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public MTimer(final int delay) {
		this(TimeUnit.MILLISECONDS, delay);
	}

	/**
	 * @since 3.6
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public MTimer(final int delay, final ActionListener listener) {
		super(delay, listener);
		acc = null;
	}

	/**
	 * @since 4.0
	 */
	@Obsolete
	public MTimer(final TimeUnit unit, final int delay) {
		this(unit, delay, null);
	}

	/**
	 * @since 5.0
	 */
	public MTimer(final TimeUnit unit, final int delay, final Predicate<MTimer> onTimeout) {
		super((int)unit.toMillis(delay), null);
		this.onTimeout = onTimeout;
		acc = AccessController.getContext();
		addActionListener(new StaticHandler());
	}

	/**
	 * @since 3.8.1
	 */
	public static String debug() {
		try {
			boolean timerQueueAccessible = true;
			Method timerQueue = Timer.class.getDeclaredMethod("timerQueue");
			try {
				timerQueueAccessible = timerQueue.isAccessible();
				if (!timerQueueAccessible)
					timerQueue.setAccessible(true);
				Object o = timerQueue.invoke(new MTimer(0));

				return Objects.toString(o, null);
			}
			finally {
				if (!timerQueueAccessible)
					timerQueue.setAccessible(false);
			}
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			return null;
		}
	}

	/**
	 * @since 5.0
	 */
	public static MTimer milliseconds(final int milliseconds, final Predicate<MTimer> onTimeout) {
		return new MTimer(TimeUnit.MILLISECONDS, milliseconds, onTimeout);
	}

	/**
	 * @since 5.0
	 */
	public static MTimer minutes(final int minutes, final Predicate<MTimer> onTimeout) {
		return new MTimer(TimeUnit.MINUTES, minutes, onTimeout);
	}

	/**
	 * @since 5.0
	 */
	public static MTimer seconds(final int seconds, final Predicate<MTimer> onTimeout) {
		return new MTimer(TimeUnit.SECONDS, seconds, onTimeout);
	}

	/**
	 * Sets both <i>delay</i> and <i>initial delay</i>.
	 *
	 * @param unit the delay unit
	 * @param delay the new delay
	 *
	 * @since 4.0
	 */
	public void setDelay(final TimeUnit unit, final int delay) {
		int i = (int)unit.toMillis(delay);
		setDelay(i);
		setInitialDelay(i);
	}
	
	/**
	 * @since 4.4
	 */
	public void setInitialDelay(final TimeUnit unit, final int delay) {
		int i = (int)unit.toMillis(delay);
		setInitialDelay(i);
	}

	// MDisposable

	/**
	 * Stops this timer and removes all action listeners.
	 *
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		stop();
		for (ActionListener i : getActionListeners())
			removeActionListener(i);
		onTimeout = null;
	}

	// protected

	/**
	 * Invoked on timeout.
	 * By default this method returns {@code false}.
	 *
	 * Return #STOP ({@code false}) to stop this timer; #CONTINUE ({@code true}) to continue.
	 * 
	 * @since 2.0
	 */
	protected boolean onTimeout() { return STOP; }

	// private
	
	private boolean doTimeout() {
		if (onTimeout != null)
			return onTimeout.test(this);

		return onTimeout();
	}

	// private classes

	private static final class StaticHandler implements ActionListener {

		// public

		public StaticHandler() { }

		@Override
		public void actionPerformed(final ActionEvent e) {
			final MTimer timer = (MTimer)e.getSource();

			boolean result;
			if ((timer.acc != null) && (System.getSecurityManager() != null)) {
				result = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
					@Override
					public Boolean run() {
						return timer.doTimeout();
					}
				}, timer.acc);
			}
			else {
				result = timer.doTimeout();
			}

			if (!result)
				timer.stop();
		}

	}

}
