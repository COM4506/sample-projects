// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Font;
import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import javax.swing.event.DocumentEvent;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.autocompletion.AutoCompletionData;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.painters.GlassPainter;
import org.makagiga.commons.mv.MRenderer;

/**
 * A regular expression editor with validator and error highlighter.
 *
 * @see java.util.regex.Pattern
 *
 * @since 4.0
 */
public class MRegexPanel extends MTextFieldPanel {

	// public
	
	public enum Mode { PLAIN, REGULAR_EXPRESSION }

	// private
	
	private int errorIndex = -1;
	private static LinkedHashMap<String, String> constructs;
	private MLabel status;
	private MLabel testStatus;
	private Mode mode;
	private MPanel southPanel;
	private MTextFieldPanel testPanel;

	// public
	
	public MRegexPanel() {
		this(false);
	}
	
	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public MRegexPanel(final boolean limitWidth) {
		super(limitWidth);
		setRoundType(GlassPainter.RoundType.NONE);
		
		southPanel = new MPanel(true);
		
		status = MLabel.createSmall(null, null);

		testPanel = new MTextFieldPanel(false);
		testPanel.onChange(e -> validateRegex());
		testPanel.getMenuButton().setVisible(false);
		testPanel.getTextField().setStyle("font-family: monospace");
		testPanel.getTextField().setToolTipText(UI.makeHTML(i18n("Enter a text to check if it<br>matches the Regular Expression.")));
		testPanel.setLabel(i18n("Test:"));
		testPanel.setRoundType(GlassPainter.RoundType.NONE);
		
		testStatus = new MLabel(MIcon.small("ui/ok"));

		southPanel.getGroupLayout()
			.beginRows()
				.addComponent(status)
				.addHorizontalSeparator()
				.beginColumns()
					.addComponent(testPanel)
					.addComponent(testStatus)
				.end()
			.end();
		addSouth(southPanel);
		
		setAutoCompletion("regexp");
		AutoCompletion ac = MText.getAutoCompletion(getTextField());
		ac.setRenderer(new AutoCompletion.Renderer() {
			@Override
			public void onRender(final MRenderer<AutoCompletionData.Item> renderer, final AutoCompletionData.Item item) {
				String text = item.toString();
				String help = MRegexPanel.getConstructs().get(text);
				if (help != null) {
					text =
						HTMLBuilder.createCode("<b>" + TK.escapeXML(text) + "</b>") +
						("    " + TK.escapeXML(help)).replace(" ", "&nbsp;"); // no wrap
					renderer.setHTMLEnabled(true);
					renderer.setText(UI.makeHTML(text));
				}
				else {
					renderer.setHTMLEnabled(false);
					renderer.setText(text);
				}
			}
		} );

		setMode(Mode.REGULAR_EXPRESSION);

		MHighlighter.install(getTextField(), (h, textComponent, text) -> {
			if (isRegExp() && (errorIndex != -1))
				h.addHighlight(errorIndex, MHighlighter.ERROR_COLOR);
		} );
	}
	
	public Mode getMode() { return mode; }
	
	@InvokedFromConstructor
	public void setMode(final Mode value) {
		if (Objects.requireNonNull(value) == mode)
			return;
		
		mode = value;

		status.setVisible(isRegExp());
		southPanel.setVisible(isRegExp());

		MTextField textField = getTextField();
		AutoCompletion ac = MText.getAutoCompletion(textField);
		if (isRegExp()) {
			textField.setPromptText(i18n("Regular Expression"));
			textField.setStyle("font-family: monospace");
			setLabel(null);
			
			ac.sorted.no();
			ac.yOffset.set(UI.getFont(status).getSize() + 5); // do not hover status label
			
			ac.setMode(AutoCompletion.Mode.CURRENT_WORD);

			for (String i : getConstructs().keySet())
				ac.addStaticItem(i);
		}
		else {
			textField.setPromptText(null);
			textField.setStyle("font-family: " + Font.DIALOG_INPUT);
			setLabel(i18n("Text:"));
			
			ac.sorted.yes();
			ac.yOffset.set(0);
			
			ac.setMode(AutoCompletion.Mode.ANY_TEXT);

			for (String i : getConstructs().keySet())
				ac.removeStaticItem(i);
		}
		textField.setToolTipText(textField.getPromptText());

		validateRegex();
	}
	
	/**
	 * @since 4.8
	 */
	@Obsolete
	public Pattern toPattern() {
		return Pattern.compile(getText());
	}
	
	// protected
	
	@Override
	protected void onChange(final DocumentEvent e) {
		validateRegex();
	}
	
	@Override
	protected MMenu onPopupMenu() {
		MMenu menu = new MMenu();
		
		menu.addSeparator(i18n("Insert"));
		
		MAction ignoreCaseAction = new MText.InsertAction(getTextField(), i18n("Ignore Case"), "(?iu)") {
			@Override
			public void onAction() {
				this.get()
					.setCaretPosition(0);
				super.onAction();
			}
		};
		ignoreCaseAction.setEnabled(isRegExp());
		menu.add(ignoreCaseAction);
		
		menu.addSeparator();
		
		MLinkAction helpAction = new MLinkAction(URI.create("http://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html"));
		helpAction.setActionInfo(MActionInfo.HELP.noKeyStroke());
		helpAction.setEnabled(isRegExp());
		menu.add(helpAction);
		
		return menu;
	}
	
	// private
	
	private synchronized static LinkedHashMap<String, String> getConstructs() {
		if (constructs == null) {
			constructs = new LinkedHashMap<>();

			// CREDITS: Based on the JDK 7 docs: http://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html

			// Characters

			constructs.put("\\\\", "The backslash character");
			constructs.put("\\t", "The tab character");
			constructs.put("\\n", "The newline (line feed) character");
			constructs.put("\\r", "The carriage-return character");
			constructs.put("\\f", "The form-feed character");

			// Predefined character classes

			constructs.put(".", "Any character (may or may not match line terminators)");
			constructs.put("\\d", "A digit: [0-9]");
			constructs.put("\\D", "A non-digit");
			constructs.put("\\s", "A whitespace character");
			constructs.put("\\S", "A non-whitespace character");
			constructs.put("\\w", "A word character: [a-zA-Z_0-9]");
			constructs.put("\\W", "A non-word character");

			// Boundary matchers

			constructs.put("^", "The beginning of a line");
			constructs.put("$", "The end of a line");
			constructs.put("\\b", "A word boundary");
			constructs.put("\\B", "A non-word boundary");
			constructs.put("\\G", "The end of the previous match");

			// Greedy quantifiers
			
			constructs.put("?", "once or not at all");
			constructs.put("*", "zero or more times");
			constructs.put("+", "one or more times");
			
			// Quotation

			constructs.put("\\", "Nothing, but quotes the following character");
			constructs.put("\\Q", "Nothing, but quotes all characters until \\E");
			constructs.put("\\E", "Nothing, but ends quoting started by \\Q");
			
			//  Predefined Character

			constructs.put("\\p{Lower}", "A lowercase character");
			constructs.put("\\p{Upper}", "An uppercase character");
			constructs.put("\\p{ASCII}", "All ASCII");
			constructs.put("\\p{Alpha}", "An alphabetic character");
			constructs.put("\\p{Digit}", "A decimal digit character");
			constructs.put("\\p{Alnum}", "An alphanumeric character");
			constructs.put("\\p{Punct}", "A punctuation character");
			constructs.put("\\p{Graph}", "A visible character");
			constructs.put("\\p{Print}", "A printable character");
			constructs.put("\\p{Blank}", "A space or a tab");
			constructs.put("\\p{Cntrl}", "A control character");
			constructs.put("\\p{XDigit}", "A hexadecimal digit");
			constructs.put("\\p{Space}", "A whitespace character");
			
			// Special constructs
			
			constructs.put("?d", "Unix Lines Mode");
			constructs.put("?i", i18n("Ignore Case"));
			constructs.put("?m", "Multiline Mode");
			constructs.put("?s", "Dotall Mode");
			constructs.put("?u", "Unicode-aware Case Folding");
		}
		
		return constructs;
	}
	
	private boolean isRegExp() {
		return mode == Mode.REGULAR_EXPRESSION;
	}
	
	private void setRegexError(final PatternSyntaxException error) {
		if (error != null) {
			status.setIcon(MIcon.small("ui/error"));
			status.setText(error.getDescription());
			setState(State.ERROR);
			errorIndex = error.getIndex();
		}
		else {
			status.setIcon(MIcon.small("ui/ok"));
			status.setText(i18n("No Error"));
			setState(State.NORMAL);
			errorIndex = -1;
			MHighlighter.removeUserHighlights(getTextField());
		}
	}
	
	private void validateRegex() {
		try {
			testStatus.setVisible(false);
			
			if (isRegExp()) {
				Pattern pattern = toPattern();

				if (pattern.matcher(testPanel.getText()).matches()) {
					testPanel.setState(State.OK);
					testStatus.setVisible(true);
				}
				else {
					testPanel.setState(State.WARNING);
				}
			}
			else {
				testPanel.setState(State.NORMAL);
			}

			setRegexError(null);
		}
		catch (PatternSyntaxException exception) {
			testPanel.setState(State.WARNING);
			
			setRegexError(exception);
		}
	}

}
