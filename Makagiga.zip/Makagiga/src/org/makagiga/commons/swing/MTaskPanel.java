// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Cursor;
import java.lang.ref.WeakReference;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.swing.JComponent;
import javax.swing.SwingWorker;
import javax.swing.event.ChangeListener;

import org.makagiga.commons.MDisposable;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.transition.TransitionPanel;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MTaskPanel<T> extends TransitionPanel
implements
	Future<T>,
	MDisposable
{

	// public

	/**
	 * @since 4.0
	 */
	public static final String MAIN_COMPONENT = "main";

	/**
	 * @since 4.0
	 */
	public static final String THROBBER_COMPONENT = "throbber";

	// private

	private volatile boolean cancelled;
	private volatile boolean error;
	private StaticThrobber throbber;
	private volatile transient SwingWorker<T, Object> worker;
	private WeakReference<JComponent> mainComponentRef;
	
	// public
	
	public MTaskPanel() {
		this(null);
	}
	
	public MTaskPanel(final JComponent mainComponent) {
		setMainComponent(mainComponent);
		
		throbber = new StaticThrobber();
		add(throbber, THROBBER_COMPONENT);
	}

	/**
	 * @since 2.4
	 */
	public void addChangeListener(final ChangeListener l) {
		listenerList.add(ChangeListener.class, l);
	}

	/**
	 * @since 2.4
	 */
	public ChangeListener[] getChangeListeners() {
		return listenerList.getListeners(ChangeListener.class);
	}

	/**
	 * @since 2.4
	 */
	public void removeChangeListener(final ChangeListener l) {
		listenerList.remove(ChangeListener.class, l);
	}

	/**
	 * @since 4.0
	 */
	public JComponent getMainComponent() {
		return mainComponentRef.get();
	}

	/**
	 * @since 4.0
	 */
	@InvokedFromConstructor
	public void setMainComponent(final JComponent value) {
		JComponent old = TK.get(mainComponentRef);
		if (old != null)
			remove(old);

		if (value != null) {
			add(value, MAIN_COMPONENT);
			mainComponentRef = new WeakReference<>(value);
		}

		validate();
		showCard(MAIN_COMPONENT, false);
	}
	
	public MThrobber getThrobber() { return throbber; }

	public SwingWorker<T, Object> getWorker() { return worker; }
	
	/**
	 * @since 2.2
	 */
	public boolean isActive() {
		return worker != null;
	}
	
	/**
	 * @since 3.0
	 */
	public boolean isError() { return error; }
	
	public void setErrorMessage(final String text) {
		error = true;
		throbber.setIconName(MMessage.getRandomErrorIconName());
		if ((text != null) && text.contains("\n"))
			throbber.setMultilineText(text);
		else
			throbber.setText(text);
		throbber.setToolTipText(i18n("Error"));
		showCard(THROBBER_COMPONENT);
	}

	/**
	 * @since 4.6
	 */
	public void showErrorMessage(final Throwable t) {
		if (t instanceof ExecutionException) {
			MMessage.error(getWindowAncestor(), t.getCause());
		}
		else {
			MMessage.error(getWindowAncestor(), t);
		}
	}

	public void start() {
		start(i18n("Please Wait..."));
	}
	
	public synchronized void start(final String text) {
		cancel(true);
		
		throbber.setText(text);
		throbber.setActive(true);
		showCard(THROBBER_COMPONENT, false);

		error = false; // clear last error
		
		worker = new SwingWorker<T, Object>() {
			@Override
			protected T doInBackground() throws Exception {
				return MTaskPanel.this.doInBackground();
			}
			@Override
			protected void done() {
				try {
					MTaskPanel.this.cancelled = this.isCancelled();
					MTaskPanel.this.throbber.setText(null);
					MTaskPanel.this.throbber.setActive(false);
					MTaskPanel.this.showCard(MAIN_COMPONENT);

					MTaskPanel.this.done();
				}
				finally {
					MTaskPanel.this.worker = null;
					MTaskPanel.this.fireStateChanged();
				}
			}
		};
		worker.execute();
		
		MTaskPanel.this.fireStateChanged();
	}

	// Future

	@Override
	public boolean cancel(final boolean mayInterruptIfRunning) {
		boolean result = false;
		if (worker != null) {
			result = worker.cancel(mayInterruptIfRunning);
			worker = null;
		}

		return result;
	}

	/**
	 * @since 4.0
	 */
	@Override
	public T get() throws ExecutionException, InterruptedException {
		return (worker == null) ? null : worker.get();
	}

	/**
	 * @since 4.0
	 */
	@Override
	public T get(final long timeout, final TimeUnit unit) throws ExecutionException, InterruptedException, TimeoutException {
		return (worker == null) ? null : worker.get(timeout, unit);
	}

	@Override
	public boolean isCancelled() { return cancelled; }

	/**
	 * @since 4.0
	 */
	@Override
	public boolean isDone() {
		return (worker == null) || worker.isDone();
	}
	
	// MDisposable
	
	/**
	 * @since 4.8
	 */
	@Override
	public void dispose() {
		cancel(true);
	}

	// protected
	
	protected T doInBackground() throws Exception { return null; }
	
	protected void done() { }
	
	/**
	 * @since 2.4
	 */
	protected void fireStateChanged() {
		TK.fireStateChanged(this, getChangeListeners());
	}
	
	/**
	 * @since 3.0
	 */
	protected void setError(final boolean value) { error = value; }

	// private classes

	private static final class StaticThrobber extends MThrobber {

		// public

		@Override
		public void setActive(final boolean active) {
			super.setActive(active);
			this.setCursor(active ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR);
		}

		// private

		private StaticThrobber() {
			makeLargeMessage();
			setToolTipText(i18n("Click to cancel"));

			UI.onButtonClicked(this, e -> {
				TK.safeCast(getParent(), MTaskPanel.class)
					.ifPresent(parent -> parent.cancel(true));
			} );
		}

	}

}
