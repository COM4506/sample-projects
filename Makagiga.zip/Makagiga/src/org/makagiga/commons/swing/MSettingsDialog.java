// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.Window;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.event.ListSelectionListener;

import org.makagiga.commons.Config;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.security.MAccessController;

/**
 * A settings dialog.
 * 
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MSettingsDialog extends MDialog {

	// private

	private boolean firstResize = true;
	private boolean needRestart;
	private final int pageListPosition;
	private ListSelectionListener listHandler;
	private final MArrayList<Class<? extends MSettingsPage>> advancedPages = new MArrayList<>();
	private MButton advancedButton;
	private MButton revertButton;
	private MList<MSettingsPage> pageList;
	private static MNotification.Message restartMessage;
	private MPanel pagePanel;
	private String id;

	// public

	/**
	 * @since 3.8.11
	 */
	public MSettingsDialog(final Window owner, final String id) {
		this(owner, id, UI.TOP);
	}

	/**
	 * @since 3.8
	 */
	public MSettingsDialog(final Window owner, final String id, final int pageListPosition) {
		this(owner, i18n("Settings"), "ui/configure", STANDARD_DIALOG, id, pageListPosition);
	}

	/**
	 * Constructs a settings dialog.
	 * @param parent A parent window
	 * @param title A dialog title
	 * @param iconName An icon name (may be @c null)
	 * @param id An ID (may be @c null)
	 *
	 * @throws IllegalArgumentException If @p id is invalid
	 */
	public MSettingsDialog(final Window parent, final String title, final String iconName, final String id, final int pageListPosition) {
		this(parent, title, iconName, STANDARD_DIALOG, id, pageListPosition);
	}

	/**
	 * Constructs a settings dialog.
	 * @param parent A parent window
	 * @param title A dialog title
	 * @param iconName An icon name
	 * @param flags A dialog flags (e.g. @ref org.makagiga.commons.MDialog.STANDARD_DIALOG)
	 * @param id An ID (may be @c null)
	 *
	 * @throws IllegalArgumentException If @p id is invalid
	 */
	public MSettingsDialog(final Window parent, final String title, final String iconName, final int flags, final String id, final int pageListPosition) {
		this(parent, title, MIcon.stock(iconName), flags, id, pageListPosition);
	}
	
	/**
	 * @since 4.0
	 */
	public MSettingsDialog(final Window owner, final int flags, final String id) {
		this(
			owner,
			MActionInfo.SETTINGS.getDialogTitle(),
			MActionInfo.SETTINGS.getIcon(),
			flags,
			id,
			UI.TOP
		);
	}

	/**
	 * Constructs a settings dialog.
	 * @param parent A parent window
	 * @param title A dialog title
	 * @param icon A dialog icon
	 * @param flags A dialog flags (e.g. @ref org.makagiga.commons.MDialog.STANDARD_DIALOG)
	 * @param id An ID (may be @c null)
	 *
	 * @throws IllegalArgumentException If @p id is invalid
	 */
	public MSettingsDialog(final Window parent, final String title, final Icon icon, final int flags, final String id, final int pageListPosition) {
		super(parent, title, icon, flags | COMPACT_HEADER);
		this.pageListPosition = pageListPosition;
		getMainPanel().setContentMargin();
		setSize(UI.WindowSize.LARGE);

		if (id != null)
			this.id = TK.validateID(id);
		
		pageList = new MList<>();
		pageList.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		pageList.setSingleSelectionMode();
		listHandler = e -> {
			if (!e.getValueIsAdjusting())
				updateView();
		};
		pageList.getSelectionModel().addListSelectionListener(listHandler);
		
		MRenderer<MSettingsPage> renderer = new MRenderer<>(2);
		renderer.setHTMLEnabled(false);
		renderer.setUseAlternateRowColor(false);
		MLabel rendererLabel = renderer.getLabel();
		rendererLabel.setHorizontalAlignment(UI.CENTER);
		rendererLabel.setHorizontalTextPosition(UI.CENTER);
		rendererLabel.setVerticalTextPosition(UI.BOTTOM);
		pageList.setCellRenderer(renderer);
		
		if (pageListPosition == UI.TOP) {
			pageList.setLayoutOrientation(MList.HORIZONTAL_WRAP);
			getTitlePanel().addCenter(pageList);
		}
		else if (pageListPosition == UI.LEFT) {
			addWest(new MScrollPane(pageList));
		}
		else
			throw new IllegalArgumentException("\"pageListPosition\" must be \"TOP\" or \"LEFT\"");
		
		pagePanel = new MPanel();
		addCenter(pagePanel);

		revertButton = new MButton();
		if (UI.buttonIcons.get())
			revertButton.setIcon(MActionInfo.RESTORE_DEFAULT_VALUES.getIcon());
		else
			revertButton.setIcon(MActionInfo.RESTORE_DEFAULT_VALUES.getSmallIcon());
		revertButton.setToolTipText(MActionInfo.RESTORE_DEFAULT_VALUES.getText());
		revertButton.addActionListener(e ->
			getSelectedPage()
				.getMainPropertyPanel()
				.restoreDefaultValues(
					this,
					getSelectedPage().getText()
				)
		);

		getButtonsPanel().add(revertButton);
		getButtonsPanel().addContentGap();
		
		advancedButton = new MButton(MActionInfo.ADVANCED);
		advancedButton.addActionListener(e -> advanced());
		if (!UI.buttonIcons.get())
			advancedButton.setIcon(null);
		advancedButton.setVisible(false);
		getButtonsPanel().add(advancedButton);
	}

	/**
	 * @since 3.0
	 */
	public void addAdvancedPage(final Class<? extends MSettingsPage> clazz) {
		advancedPages.add(clazz);
		advancedButton.setVisible(true);
	}

	/**
	 * Adds a new page (tab) to the dialog.
	 * @param page A page to add
	 */
	public void addPage(final MSettingsPage page) {
		pageList.addItem(page);
		page.setParentWindow(this);

		// limit list width - wrap if more than 3 pages
		if (
			(pageListPosition == UI.TOP) &&
			(pageList.getLayoutOrientation() == MList.HORIZONTAL_WRAP)
		) {
			int i = (int)Math.ceil((float)pageList.getItemCount() / 3f);
			pageList.setVisibleRowCount(Math.max(1, i));

			// use standard label alignment to save vertical space
			if (pageList.getVisibleRowCount() > 1) {
				ListCellRenderer<? super MSettingsPage> renderer = pageList.getCellRenderer();
				if (renderer instanceof MRenderer<?>) {
					MLabel rendererLabel = MRenderer.class.cast(renderer).getLabel();
					if (rendererLabel != null) {
						rendererLabel.setHorizontalAlignment(UI.LEADING);
						rendererLabel.setHorizontalTextPosition(UI.TRAILING);
						rendererLabel.setVerticalTextPosition(UI.CENTER);
					}
				}
			}
		}
	}
	
	/**
	 * @since 3.0
	 */
	public void advanced() {
		String advancedID = (id == null) ? null : (id + "-advanced");
		MSettingsDialog dialog = new Builder()
			.title(i18n("Advanced"))
			.icon(MActionInfo.ADVANCED.getIconName())
			.id(advancedID)
		.build(this);

		try {
			for (MSettingsPage i : pageList) {
				MSettingsPage page = i.createAdvancedPage();
				if ((page != null) && (page != i))
					dialog.addPage(page);
			}
		
			for (Class<? extends MSettingsPage> i : advancedPages) {
				MSettingsPage page = i.newInstance();
				dialog.addPage(page);
			}
			dialog.exec();
		}
		//catch (ReflectiveOperationException exception) {
		// NOTE: catch both checked and unchecked exceptions from "i.newInstance()"
		catch (Exception exception) {
			MMessage.error(this, exception);
		}
	}

	@Override
	public boolean exec() {
		return exec(((pageList != null) && pageList.isDisplayable()) ? pageList : null);
	}

	@Override
	public boolean exec(final JComponent defaultFocus) {
		final Config config = getConfigPrivileged();
		
		if (pageList.isEmpty()) {
			pageList.setEnabled(false);
			pageList.setText(MList.AUTO_TEXT);
		}
		else {
			if (id != null)
				pageList.setSelectedIndex(config.readInt("Settings.tab." + id, 0, pageList), true);

			if (pageList.isSelectionEmpty())
				pageList.setSelectedIndex(0, true);
		}

		pack();

		if (id != null) {
			Point defaultValue = new Point();
			Point value = config.readPoint(Config.getScreenKey("Settings.location." + id), defaultValue);
			if (!value.equals(defaultValue)) {
				getFixedScreenYLocation(value, getHeight());
				setDefaultLocation(value);
			}
		}

		boolean result = super.exec(defaultFocus);
		
		// clear references to "this"
		for (MSettingsPage i : pageList)
			i.setParentWindow(null);

		if (id != null) {
			final int selectedIndex = pageList.getSelectedIndex();
			final Point location = getLocation();
			MAccessController.doPrivileged(() -> {
				config.write(Config.getScreenKey("Settings.location." + id), location);
				config.write("Settings.tab." + id, selectedIndex);

				return null;
			} );
		}

		pageList.clear();
		pageList = null;
		
		return result;
	}

	static MSettingsDialog createDialog(final Window owner, final MSettingsPage page) { // package
		String id = null;
		try {
			if (!TK.isEmpty(page.getName()))
				id = TK.validateID(page.getName());
		}
		catch (IllegalArgumentException exception) {
			MLogger.exception(exception);
		}
		
		String mainTitle = i18n("Settings");
		String subTitle = page.getText();
		String dialogTitle =
			(TK.isEmpty(subTitle) || mainTitle.equals(subTitle))
			? mainTitle
			: subTitle + " - " + mainTitle;

		MSettingsDialog dialog = new Builder()
			.title(dialogTitle)
			.icon(page.getIcon())
			.flags(page.getDialogFlags())
			.id(id)
		.build(owner);

		MPanel main = dialog.getMainPanel();
		dialog.setMainPanelMargin(main.getContentMargin());

		JScrollPane sp = MScrollPane.getScrollPane(dialog.getPageList());
		if (sp != null)
			sp.setVisible(false);
		dialog.addPage(page);
		
		return dialog;
	}

	static boolean execPage(final Window owner, final MSettingsPage page, final JComponent defaultFocus) { // package
		if (page == null)
			return false;

		return createDialog(owner, page)
			.exec(defaultFocus);
	}
	
	/**
	 * @since 4.4
	 */
	public MButton getAdvancedButton() { return advancedButton; }

	/**
	 * @since 3.8
	 */
	public MList<MSettingsPage> getPageList() { return pageList; }

	public MSettingsPage getSelectedPage() {
		return pageList.getSelectedItem();
	}

	/**
	 * @since 3.4
	 */
	public void setSelectedPage(final MSettingsPage page) {
		pageList.setSelectedItem(page, true);
	}

	/**
	 * @since 3.8
	 */
	public boolean isPageListVisible() {
		return MScrollPane.getScrollPane(pageList).isVisible();
	}

	/**
	 * @since 3.8
	 */
	public void setPageListVisible(final boolean value) {
		MScrollPane.getScrollPane(pageList).setVisible(value);
	}

	public void setNeedRestart(final boolean value) { needRestart = value; }

	@Obsolete // move to MApplication
	public synchronized static void showRestartInfo() {
		if (restartMessage == null) {
			restartMessage = new MNotification.Message(
				MActionInfo.OK.getText(),
				MApplication.getRestartMessage(),
				"ui/refresh"
			) {
				@Override
				protected void onClose() {
					MSettingsDialog.restartMessage = null;
				}
			};
			restartMessage.setColor(MHighlighter.WARNING_COLOR);
			restartMessage.setTimeout(10000);
			restartMessage.show();
		}
		else {
			restartMessage.toFront();
		}
	}

	// protected
	
	protected void apply() {
		for (MSettingsPage i : pageList) {
			if (i.initDone) {
				if (!i.getAutoUpdateModel())
					i.updateModel();
				i.onOK();
			}
			if (i.getNeedRestart())
				needRestart = true;
		}

		if (needRestart)
			showRestartInfo();
	}

	@Override
	protected boolean onAccept() {
		apply();
		
		MAccessController.doPrivileged(() -> {
			Config.getDefault().sync();

			return null;
		} );

		return true;
	}

	@Override
	protected final void onClose() {
		for (MSettingsPage i : pageList)
			i.onClose();

		if (listHandler != null) {
			pageList.getSelectionModel().removeListSelectionListener(listHandler);
			listHandler = null;
		}
		super.onClose();
	}
	
	protected void onPageChange() { }

	/**
	 * @since 3.8.6
	 */
	protected void updatePagePanel(final MPanel pagePanel, final MSettingsPage page) {
		pagePanel.removeAll();
		pagePanel.addNorth(page);
		pagePanel.validate();
	}
	
	// private
	
	private Config getConfigPrivileged() {
		SecurityManager sm = System.getSecurityManager();

		if (sm == null)
			return Config.getDefault();

		return MAccessController.doPrivileged(Config::getDefault);
	}

	private void updateView() {
		MSettingsPage page = getSelectedPage();
		if (page != null) {
			if (!page.initDone) {
				page.initOnDemand();
				
				if (MApplication.getForceRTL())
					page.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
				
				Mnemonic pageMnemonic = new Mnemonic();
				pageMnemonic.exclude(this.getMnemonic());
				pageMnemonic.apply(page);
			}

			updatePagePanel(pagePanel, page);
			
			revertButton.setEnabled(page.getMainPropertyPanel().hasEditors());
		}
		else {
			revertButton.setEnabled(false);
		}
		onPageChange();
		
		// update window size
		if (firstResize) {
			firstResize = false;
			setAutoSize(false);
		}
		else {
			setAutoSize(true);
		}
	}
	
	// public classes
	
	/**
	 * @since 4.4
	 */
	public static final class Builder {
	
		// private
		
		private Icon icon = MActionInfo.SETTINGS.getIcon();
		private int flags = MSettingsDialog.STANDARD_DIALOG;
		private int pageListPosition = UI.TOP;
		private final MArrayList<MSettingsPage> pageList = new MArrayList<>();
		private String id;
		private String title = MActionInfo.SETTINGS.getDialogTitle();

		// public
		
		public Builder() { }
		
		public MSettingsDialog build(final Component owner) {
			MSettingsDialog dialog = new MSettingsDialog(
				(owner instanceof Window) ? (Window)owner : UI.windowFor(owner),
				title,
				icon,
				flags,
				id,
				pageListPosition
			);
			for (MSettingsPage i : pageList)
				dialog.addPage(i);
			
			return dialog;
		}
		
		public Builder flags(final int flags) {
			this.flags = flags;
			
			return this;
		}
		
		public Builder icon(final Icon icon) {
			this.icon = icon;
			
			return this;
		}
		
		public Builder icon(final String iconName) {
			this.icon = MIcon.stock(iconName);
			
			return this;
		}
		
		public Builder id(final String id) {
			this.id = id;
			
			return this;
		}
		
		public Builder page(final MSettingsPage... page) {
			pageList.addAll(page);
			
			return this;
		}
		
		public Builder pageListPosition(final int pageListPosition) {
			this.pageListPosition = pageListPosition;
			
			return this;
		}
		
		public Builder title(final String title) {
			this.title = title;
			
			return this;
		}
	
	}

}
