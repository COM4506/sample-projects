// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.util.Objects;
import java.util.function.Function;
import javax.swing.JComponent;
import javax.swing.text.JTextComponent;

import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MColor;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.html.MHTMLViewer;

/**
 * @since 5.0
 */
public class MTextPreviewPanel extends MPanel {

	// public
	
	public static final Function<MTextPreviewPanel, String> TEXT_HTML_PROVIDER = preview -> {
		String linkFG = ColorProperty.toString(preview.linkForeground);
	
		return UI.makeHTML(
			TK.escapeXML(i18n("Text")) +
			" <a href=\"" + TK.escapeXML(MApplication.getHomePage()) + "\" style=\"color: " + linkFG + "\">" +
			TK.escapeXML(i18n("Link")) +
			"</a>"
		);
	};

	public static final Function<MTextPreviewPanel, String> TEXT_PLAIN_PROVIDER = preview ->
		i18n("The quick brown fox jumps over the lazy dog") + "\n" +
			// monospaced font test
			// CREDITS: Konsole
			"1234567890, o, O ... l i L I";

	// private
	
	private Color linkForeground = MColor.LINK;
	private final Function<MTextPreviewPanel, String> textProvider;
	private final JTextComponent textComponent;

	// public

	public MTextPreviewPanel() {
		this(TEXT_PLAIN_PROVIDER, false);
	}

	public MTextPreviewPanel(final String text) {
		this(preview -> text, false);
	}

	public MTextPreviewPanel(final Function<MTextPreviewPanel, String> textProvider, final boolean html) {
		this.textProvider = Objects.requireNonNull(textProvider);

		if (html) {
			textComponent = new MHTMLViewer();
		}
		else {
			textComponent = new MEditorPane();
			textComponent.setEditable(false);
		}
		textComponent.setToolTipText(i18n("Preview"));
		addCenter(textComponent);
		
		setTextMargin(5);
		setTitle(i18n("Preview"));
		
		updateText();
	}

	public void bindLinkForeground(final ValueChooser<? extends Color> editor) {
		setLinkForeground(editor.getValue());
		JComponent.class.cast(editor).addPropertyChangeListener(ValueChooser.VALUE_PROPERTY, e -> setLinkForeground((Color)e.getNewValue()));
	}

	public void bindTextBackground(final ValueChooser<? extends Color> editor) {
		setTextBackground(editor.getValue());
		JComponent.class.cast(editor).addPropertyChangeListener(ValueChooser.VALUE_PROPERTY, e -> setTextBackground((Color)e.getNewValue()));
	}

	public void bindTextFont(final ValueChooser<Font> editor) {
		setTextFont(editor.getValue());
		JComponent.class.cast(editor).addPropertyChangeListener(ValueChooser.VALUE_PROPERTY, e -> setTextFont((Font)e.getNewValue()));
	}

	public void bindTextForeground(final ValueChooser<? extends Color> editor) {
		setTextForeground(editor.getValue());
		JComponent.class.cast(editor).addPropertyChangeListener(ValueChooser.VALUE_PROPERTY, e -> setTextForeground((Color)e.getNewValue()));
	}

	@Override
	public Dimension getMaximumSize() {
		return new Dimension(super.getMaximumSize().width, getPreferredSize().height);
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension d = super.getPreferredSize();

		return new Dimension(d.width, Math.min(200, d.height));
	}

	public Font getTextFont() {
		return UI.getFont(textComponent);
	}

	public void setTextFont(final Font value) {
		textComponent.setFont(value);
		
		updateDialogSize();
	}

	public static String getTextSample(final JTextComponent from) {
		String s = from.getText();
		s = s.trim();

		return TK.rightSqueeze(s, 200);
	}

	public void setLinkForeground(final Color value) {
		linkForeground = value;
		updateText();
	}

	public void setTextBackground(final Color value) {
		textComponent.setBackground(value);
	}
	
	public void setTextEditable(final boolean value) {
		textComponent.setEditable(value);
	}

	public void setTextForeground(final Color value) {
		textComponent.setForeground(value);
	}
	
	public void setTextMargin(final int value) {
		setTextMargin(UI.createInsets(value));
	}

	public void setTextMargin(final Insets value) {
		if (value != null) {
			textComponent.setMargin((Insets)value.clone());
			textComponent.repaint();

			updateDialogSize();
		}
	}
	
	public void updateText() {
		String text = textProvider.apply(this);
		if (TK.isEmpty(text))
			text = TEXT_PLAIN_PROVIDER.apply(this);
		textComponent.setText(text);
		if (!(textComponent instanceof MHTMLViewer))
			textComponent.setCaretPosition(0);
	}

	// private
	
	private void updateDialogSize() {
		getDialog().ifPresent(dialog -> {
			dialog.setAutoSize(false);
			// HACK: do layout now
			dialog.validate();
		} );
	}

}
