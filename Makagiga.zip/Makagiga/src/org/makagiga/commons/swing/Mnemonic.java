// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import java.awt.Component;
import java.awt.Container;
import java.io.Serializable;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRootPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

import org.makagiga.commons.TK;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public final class Mnemonic implements Serializable {

	// public

	/**
	 * @since 4.0
	 */
	public static final Info NONE = new Info((char)0, 0);
	
	// private

	private final char[] defaultMnemonics;
	private final char[] mnemonics = new char[36];
	private static final int[] TAB_KEYS = { VK_1, VK_2, VK_3, VK_4, VK_5, VK_6, VK_7, VK_8, VK_9, VK_0 };
	private static final String BAD_MNEMONICS = "gijlpqyIJQ"; // underline makes a char unreadable
	private static final String EXCLUDED_PROPERTY = "org.makagiga.commons.swing.Mnemonics.excluded";
	
	// public
	
	public Mnemonic() {
		this(null);
	}
	
	public Mnemonic(final Container container) {
		reset();
		defaultMnemonics = mnemonics.clone();

		apply(container);
	}
	
	public void apply(final Container container) {
		if (container == null)
			return;

		if ((container instanceof JComponent) && isExcluded((JComponent)container))
			return;

		// do not duplicate mnemonics already used in menu bar
		if (!(container instanceof JMenuItem)) {
			JRootPane rootPane = SwingUtilities.getRootPane(container);
			if (rootPane != null) {
				JMenuBar menuBar = rootPane.getJMenuBar();
				if (menuBar instanceof MMenuBar) {
					for (JMenu i : (MMenuBar)menuBar) {
						if (i == null)
							continue; // for
					
						char currentMnemonic = (char)i.getMnemonic();
						if (currentMnemonic != 0)
							markAsUsed(currentMnemonic);
					}
				}
			}
		}

		new ContainerScanner(container) {
			@Override
			public void processComponent(final Container parent, final Component component) {
				Mnemonic.this.doProcess(component);
			}
			@Override
			protected boolean shouldScan(final Container parent) {
				if ((parent instanceof JComponent) && Mnemonic.isExcluded((JComponent)parent))
					return false;

				return true;
			}
		};
	}

	public String apply(final AbstractButton button, final String text) {
		Info info = parse(text);
		if (info.isValid()) {
			char mnemonic = info.getCharacter();
			button.setMnemonic(mnemonic);
			markAsUsed(mnemonic);

			return remove(text);
		}
		
		return text;
	}

	/**
	 * @since 3.0
	 */
	public void exclude(final Mnemonic mnemonic) {
		for (int i = 0; i < mnemonics.length; i++) {
			if (mnemonic.mnemonics[i] == 0)
				mnemonics[i] = 0;
		}
	}

	/**
	 * @since 3.8.7
	 */
	public static int[] getTabKeys() {
		return TAB_KEYS.clone();
	}

	/**
	 * @since 3.8.7
	 */
	public static boolean isExcluded(final JComponent c) {
		return Boolean.TRUE.equals(c.getClientProperty(EXCLUDED_PROPERTY));
	}

	/**
	 * @since 3.8.7
	 */
	public static void setExcluded(final JComponent c, final boolean excluded) {
		c.putClientProperty(EXCLUDED_PROPERTY, excluded ? true : null);
	}

	/**
	 * @since 3.8
	 */
	public static Mnemonic.Info parse(final String text) {
		if (text == null)
			return NONE;

		int length = text.length();

		if (length < 2)
			return NONE;

		int lastAmp = -1;
		for (int i = 0; i < length; i++) {
			char c = text.charAt(i);
			if (c == '&') {
				if (lastAmp != -1) {
					lastAmp = -1;
				}
				else {
					lastAmp = i;
				}
			}
			else {
				if (lastAmp != -1) {
					if (c != ' ')
						return new Info(c, i);

					lastAmp = -1;
				}
			}
		}

		return NONE;
	}
	
	/**
	 * @since 4.10
	 */
	public static void removeAll(final Container container) {
		new ContainerScanner(container) {
			@Override
			public void processComponent(final Container parent, final Component component) {
				if (component instanceof AbstractButton) {
					AbstractButton button = (AbstractButton)component;
					button.setMnemonic(0);
					button.setDisplayedMnemonicIndex(-1);
				}
				else if (component instanceof JLabel) {
					JLabel label = (JLabel)component;
					label.setDisplayedMnemonic(0);
					label.setDisplayedMnemonicIndex(-1);
				}
				else if (component instanceof JTabbedPane) {
					JTabbedPane tabs = (JTabbedPane)component;
					int count = tabs.getTabCount();
					for (int i = 0; i < count; i++) {
						tabs.setMnemonicAt(i, 0);
						tabs.setDisplayedMnemonicIndexAt(i, -1);
					}
				}
			}
		};

	}
	
	/**
	 * @since 4.4
	 */
	public void reset() {
		int index = 0;
		for (char c = 'A'; c <= 'Z'; c++) {
			mnemonics[index] = c;
			index++;
		}
		for (char d = '0'; d <= '9'; d++) {
			mnemonics[index] = d;
			index++;
		}
	}

	public static String set(final AbstractButton button, final String text) {
		if ((button != null) && isExcluded(button))
			return text;

		Info info = parse(text);
		if (info.isValid()) {
			button.setMnemonic(info.getCharacter());

			return remove(text);
		}

		return text;
	}

	/**
	 * @since 1.2
	 */
	public void update(final AbstractButton button) {
		if (isExcluded(button))
			return;

		int currentMnemonic = button.getMnemonic();
		if (currentMnemonic != 0) {
			for (int letter = 0; letter < mnemonics.length; letter++) {
				if (defaultMnemonics[letter] == currentMnemonic) {
					mnemonics[letter] = (char)currentMnemonic; // free mnemonic
					
					break; // for
				}
			}
			button.setMnemonic(0);
		}
		processButton(button);
	}
	
	// private

	private boolean doProcess(final Component component) {
		if (component instanceof AbstractButton) {
			processButton((AbstractButton)component);

			return true;
		}

		if (component instanceof JLabel) {
			processLabel((JLabel)component);

			return true;
		}

		if (component instanceof JTabbedPane) {
			processTabs((JTabbedPane)component);

			return true;
		}

		return false;
	}
	
	private char findMnemonicFor(final String text) {
		if (TK.isEmpty(text))
			return 0;

		int len = text.length();
		for (int i = 0; i < len; i++) {
			char c = text.charAt(i);

			// "bad" mnemonic?
			if (BAD_MNEMONICS.indexOf(c) != -1)
				continue; // for
			
			for (int letter = 0; letter < mnemonics.length; letter++) {
				if (mnemonics[letter] == 0)
					continue; // for
						
				if (Character.toUpperCase(c) == mnemonics[letter]) {
					char result = mnemonics[letter];
					mnemonics[letter] = 0;

					return result;
				}
			}
		}
		
		return 0;
	}
	
	private void markAsUsed(final char mnemonic) {
		for (int letter = 0; letter < mnemonics.length; letter++) {
			if (mnemonics[letter] == mnemonic) {
				mnemonics[letter] = 0;
					
				break; // for
			}
		}
	}

	private void processButton(final AbstractButton button) {
		if (isExcluded(button))
			return;

		char currentMnemonic = (char)button.getMnemonic();
		if (currentMnemonic != 0) {
			markAsUsed(currentMnemonic);
		
			return;
		}
		
		char mnemonic = findMnemonicFor(button.getText());
		if (mnemonic != 0)
			button.setMnemonic(mnemonic);
	}
	
	private void processLabel(final JLabel label) {
		if (isExcluded(label))
			return;

		if (label.getLabelFor() == null)
			return;
		
		char currentMnemonic = (char)label.getDisplayedMnemonic();
		if (currentMnemonic != 0) {
			markAsUsed(currentMnemonic);
		
			return;
		}

		char mnemonic = findMnemonicFor(label.getText());
		if (mnemonic != 0)
			label.setDisplayedMnemonic(mnemonic);
	}
	
	private void processTabs(final JTabbedPane tabs) {
		if (isExcluded(tabs))
			return;

		int count = tabs.getTabCount();

		if (count == 0)
			return;

		for (int i = 0; i < count; i++) {
			if (i <= TAB_KEYS.length - 1)
				tabs.setMnemonicAt(i, TAB_KEYS[i]);
			else
				tabs.setMnemonicAt(i, -1);
		}
	}

	private static String remove(final String text) {
// FIXME: 3.0: ignore double amp (escape)
		int i = text.indexOf('&');

		if (i == -1)
			return text;

		return text.substring(0, i) + text.substring(i + 1);
	}
	
	// public classes
	
	/**
	 * @since 4.0
	 */
	public static final class Info implements Serializable {
	
		// private
		
		private final char mnemonic;
// TODO: use "index" field
		private final int index;
		
		// public

		public Info(final char mnemonic, final int index) {
			this.mnemonic = mnemonic;
			this.index = index;
		}

		@Override
		public boolean equals(final Object o) {
			if (o == this)
				return true;
				
			if (!(o instanceof Info))
				return false;
				
			Info other = (Info)o;
			
			return
				(this.mnemonic == other.mnemonic) &&
				(this.index == other.index);
		}
		
		@Override
		public int hashCode() {
			return TK.hash(mnemonic, index);
		}
		
		public char getCharacter() { return mnemonic; }
		
		public boolean isValid() {
			return mnemonic != 0;
		}
		
	}
	
}