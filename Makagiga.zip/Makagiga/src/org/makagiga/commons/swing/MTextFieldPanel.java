// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Dimension;
import java.util.concurrent.TimeUnit;
import javax.swing.BorderFactory;
import javax.swing.event.DocumentEvent;

import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.painters.AbstractPainter;
import org.makagiga.commons.painters.GlassPainter;
import org.makagiga.commons.painters.Painter;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTextFieldPanel extends MPanel implements MText.TextFieldExtensions {
	
	/**
	 * @since 3.0
	 */
	public enum State { NORMAL, OK, WARNING, ERROR }
	
	// private

	private boolean focusOnClear = true;
	private boolean limitWidth;
	private DocumentEvent lastDocumentEvent;
	private int changeEventDelay;
	private final MLabel label;
	private MPanel buttonPanel;
	private MSmallButton clearButton;
	private MSmallButton menuButton;
	private MTextField textField;
	private MTimer changeEventDelayTimer;
	private State state = State.NORMAL;
	
	// public
	
	public MTextFieldPanel() {
		this(null, false);
	}
	
	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public MTextFieldPanel(final boolean limitWidth) {
		this(null, limitWidth);
	}
	
	/**
	 * @since 2.0
	 */
	public MTextFieldPanel(final String text) {
		this(text, false);
	}

	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public MTextFieldPanel(final String text, final boolean limitWidth) {
		this.limitWidth = limitWidth;
		setMargin(1);
		setOpaque(false);
		
		buttonPanel = MPanel.createHBoxPanel();
		buttonPanel.setOpaque(false);
		addEast(buttonPanel);
		
		clearButton = new MSmallButton(MActionInfo.CLEAR_LEFT);
		clearButton.addActionListener(e -> {
			textField.clear();
			if (focusOnClear)
				textField.makeDefault();
		} );
		buttonPanel.add(clearButton);
		
		textField = new MTextField(text) {
			@Override
			public void setPromptText(final String value) {
				super.setPromptText(value);
				if (UI.isSeaGlass())
					this.putClientProperty("JTextField.Search.PlaceholderText", value);
			}
			@Override
			protected void onChange(final DocumentEvent e) {
				if (MTextFieldPanel.this.changeEventDelay == 0) {
					MTextFieldPanel.this.doChange(e);
				}
				else {
					MTextFieldPanel.this.lastDocumentEvent = e;
					MTextFieldPanel.this.changeEventDelayTimer.restart();
				}
			}
		};
		updateClearButton();
		textField.setCaretPosition(0);
		addCenter(textField);
		
		label = MLabel.createFor(textField, null);
		addWest(label);

		menuButton = new MSmallButton(ShapeIcon.MENU, i18n("Options"));
		menuButton.setPopupMenu(this::onPopupMenu);
		menuButton.setPopupMenuArrowPainted(false);
		buttonPanel.add(menuButton);

		setPainter(new GlassPainter());
	}
	
	/**
	 * Returns the <i>east</i> button panel with horizontal box layout.
	 * 
	 * @since 3.0
	 */
	public MPanel getButtonPanel() { return buttonPanel; }
	
	public int getChangeEventDelay() { return changeEventDelay; }
	
	public void setChangeEventDelay(final int value) {
		if (value == changeEventDelay)
			return;
	
		changeEventDelay = value;
		// no delay
		if (changeEventDelay == 0) {
			lastDocumentEvent = null;
			if (changeEventDelayTimer != null) {
				changeEventDelayTimer.stop();
				changeEventDelayTimer = null;
			}
		}
		// setup timer
		else {
			if (changeEventDelayTimer == null) {
				changeEventDelayTimer = MTimer.milliseconds(changeEventDelay, timer -> {
					if (lastDocumentEvent != null) {
						doChange(lastDocumentEvent);
						lastDocumentEvent = null;
					}
						
					return MTimer.STOP;
				} );
			}
			changeEventDelayTimer.setDelay(TimeUnit.MILLISECONDS, changeEventDelay);
			changeEventDelayTimer.restart();
		}
	}
	
	public MTimer getChangeEventDelayTimer() { return changeEventDelayTimer; }

	/**
	 * @since 5.6
	 */
	public boolean getFocusOnClear() { return focusOnClear; }

	/**
	 * @since 5.6
	 */
	public void setFocusOnClear(final boolean value) { focusOnClear = value; }

	/**
	 * @since 3.0
	 */
	public MLabel getLabelComponent() { return label; }

	@Override
	public Dimension getMaximumSize() {
		return limitWidth ? getPreferredSize() : super.getMaximumSize();
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension d = super.getPreferredSize();
		
		return limitWidth ? new Dimension(200, d.height) : d;
	}
	
	/**
	 * @since 3.0
	 */
	public State getState() { return state; }

	/**
	 * @since 3.0
	 */
	public void setState(final State value) {
		if (state != value) {
			state = value;
			
			Painter p = getPainter();
			if (p instanceof AbstractPainter) {
				boolean warning = false;
				Color color;
				switch (state) {
					case NORMAL:
						color = null;
						break;
					case OK:
						color = MHighlighter.OK_COLOR;
						break;
					case WARNING:
						color = MHighlighter.WARNING_COLOR;
						warning = true;
						break;
					case ERROR:
						color = MHighlighter.ERROR_COLOR;
						warning = true;
						break;
					default:
						throw new WTFError(value);
				}

				AbstractPainter painter = (AbstractPainter)p;
				painter.setPaintStripes(warning);
				painter.setPrimaryColor(color);
				repaint();
			}
		}
	}

	@Override
	public String getText() {
		return textField.getText();
	}
	
	@Override
	public void setText(final String value) {
		textField.setText(value);
	}
	
	public MSmallButton getClearButton() { return clearButton; }

	/**
	 * @since 2.0
	 */
	public MSmallButton getMenuButton() { return menuButton; }

	/**
	 * @since 4.0
	 */
	public String getPromptText() {
		return textField.getPromptText();
	}

	/**
	 * @since 4.0
	 */
	public void setPromptText(final String value) {
		textField.setPromptText(value);
	}

	/**
	 * @since 4.8
	 */
	public GlassPainter.RoundType getRoundType() {
		return AbstractPainter.getRoundType(getPainter());
	}

	/**
	 * @since 4.8
	 */
	public void setRoundType(final GlassPainter.RoundType value) {
		AbstractPainter.setRoundType(this, getPainter(), value);
	}

	public MTextField getTextField() { return textField; }
	
	/**
	 * @since 2.0
	 */
	public boolean isEditable() {
		return textField.isEditable();
	}

	/**
	 * @since 2.0
	 */
	public void setEditable(final boolean value) {
		if (isEditable() == value)
			return;
		
		textField.setEditable(value);
		if (clearButton != null) {
			clearButton.setEnabled(value);
			clearButton.setVisible(value && !UI.isSeaGlass());
		}
		if (menuButton != null)
			menuButton.setEnabled(value);
		updateClearButton();
	}
	
	/**
	 * @since 5.0
	 */
	@Override
	public void onChange(final MText.TextChangedListener listener) {
		listenerList.add(MText.TextChangedListener.class, listener);
	}
	
	/**
	 * @since 3.0
	 */
	public void setLabel(final String text) {
		label.setText(text);
		boolean visible = !TK.isEmpty(text);
		label.setBorder(visible ? BorderFactory.createEmptyBorder(0, 0, 0, 5) : null);
		label.setVisible(visible);
	}

	/**
	 * @since 4.2
	 */
	public void setList(final MList<?> list) {
		UI.onKeyPressed(getTextField(), e -> {
			if ((list == null) || !list.isShowing() || e.isConsumed())
				return;
			
			if (TK.isKeyStroke(e, VK_UP)) {
				list.selectRelativeIndex(-1, true, true);
				e.consume();
			}
			else if (TK.isKeyStroke(e, VK_DOWN)) {
				list.selectRelativeIndex(1, true, true);
				e.consume();
			}
		} );
	}

	// common extensions
	
	@Override
	public void clear() {
		textField.clear();
	}

	@Override
	public boolean isEmpty() {
		return textField.isEmpty();
	}

	@Override
	public void makeDefault() {
		textField.makeDefault();
	}
	
	// text completion
	
	@Override
	public String getAutoCompletion() {
		return MText.getAutoCompletionID(textField);
	}
	
	@Override
	public void saveAutoCompletion() {
		MText.saveAutoCompletion(textField);
	}
	
	@Override
	public void setAutoCompletion(final String id) {
		MText.installAutoCompletion(textField, id);
	}

	// protected
	
	@Obsolete
	protected void onChange(final DocumentEvent e) { }
	
	/**
	 * @since 2.0
	 */
	@Obsolete
	protected MMenu onPopupMenu() { return null; }

	/**
	 * @since 3.8
	 */
	protected void updateClearButton(final boolean on) {
		clearButton.setEnabled(on);
		clearButton.setVisible(on);
	}
	
	// private

	private void doChange(final DocumentEvent e) {
		for (MText.TextChangedListener i : listenerList.getListeners(MText.TextChangedListener.class))
			i.textChanged(e);
		onChange(e);

		updateClearButton();
	}

	private void updateClearButton() {
		if (clearButton != null) {
			boolean on = textField.isEditable() && !isEmpty() && !UI.isSeaGlass();
			updateClearButton(on);
		}
	}

}
