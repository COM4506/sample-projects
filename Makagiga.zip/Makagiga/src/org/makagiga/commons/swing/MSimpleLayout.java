// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager2;
import java.awt.Point;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.TK;
import org.makagiga.commons.WTFError;

/**
 * @since 4.10
 */
public class MSimpleLayout implements LayoutManager2 {

	// public
	
	public enum Position { TOP, BOTTOM, LEFT, RIGHT, CENTER }
	
	// private
	
	private boolean honorsVisibility = true;
	private enum Size { MAXIMUM, MINIMUM, PREFERRED }
	private int centerBottom;
	private int centerTop;
	private int hGap;
	private int vGap;
	private int margin;
	private final Map<Position, List<Info>> map;
	private static final Map<String, Position> stringConstraintsMap;
	private static final Position[] positions = Position.values();

	// public
	
	static {
		stringConstraintsMap = new HashMap<>();
		for (Position i : positions)
			stringConstraintsMap.put(TK.toLowerCaseName(i), i);
	}
	
	public MSimpleLayout() {
		map = new EnumMap<>(Position.class);
		for (Position i : positions)
			map.put(i, new MArrayList<>(5));
	}
	
	public int getHGap() { return hGap; }
	
	public MSimpleLayout setHGap(final int value) {
		hGap = requirePositive(value);
		
		return this;
	}
	
	/**
	 * @since 4.10
	 */
	public boolean getHonorsVisibility() { return honorsVisibility; }

	/**
	 * @since 4.10
	 */
	public MSimpleLayout setHonorsVisibility(final boolean value) {
		honorsVisibility = value;
		
		return this;
	}

	public int getVGap() { return vGap; }
	
	public MSimpleLayout setVGap(final int value) {
		vGap = requirePositive(value);
		
		return this;
	}

	public int getMargin() { return margin; }
	
	public MSimpleLayout setMargin(final int value) {
		margin = requirePositive(value);
		
		return this;
	}
	
	public MSimpleLayout setGap(final int value) {
		setHGap(value);
		setVGap(value);
		
		return this;
	}

	public MSimpleLayout setContentGap() {
		setGap(MPanel.DEFAULT_CONTENT_MARGIN);
	
		return this;
	}

	public MSimpleLayout setContentMargin() {
		setMargin(MPanel.DEFAULT_CONTENT_MARGIN);
	
		return this;
	}

	public MSimpleLayout setDefaultGap() {
		setGap(5);
	
		return this;
	}

	public static MSimpleLayout withGap(final int gap) {
		MSimpleLayout l = new MSimpleLayout();
		l.setGap(gap);
		
		return l;
	}

	public static MSimpleLayout withMargin(final int margin) {
		MSimpleLayout l = new MSimpleLayout();
		l.setMargin(margin);
		
		return l;
	}

	public static MSimpleLayout withMarginAndGap(final int margin, final int gap) {
		MSimpleLayout l = new MSimpleLayout();
		l.setMargin(margin);
		l.setGap(gap);
		
		return l;
	}

	// LayoutManager

	/**
	 * @deprecated Since 4.10
	 */
	@Deprecated
	@Override
	public void addLayoutComponent(final String name, final Component c) {
		addLayoutComponent(c, null);
	}

	@Override
	public void removeLayoutComponent(final Component c) {
		remove(c);
	}

	@Override
	public void layoutContainer(final Container container) {
		Point p = new Point();
		
		// TOP
		
		p.setLocation(margin, margin);
		layout(container, Position.TOP, p, true);
		centerTop = p.y;

		// BOTTOM

		p.setLocation(margin, 0);
		layout(container, Position.BOTTOM, p, false);
		centerBottom = Math.abs(p.y);
		
		// LEFT
		
		p.setLocation(margin, centerTop);
		layout(container, Position.LEFT, p, true);
		int centerLeft = p.x;
		
		// RIGHT

		p.setLocation(0, centerTop);
		layout(container, Position.RIGHT, p, false);
		int centerRight = Math.abs(p.x);
		
		// CENTER
		
		p.setLocation(centerLeft, centerTop);
		List<Info> centerList = map.get(Position.CENTER);
		if (!centerList.isEmpty()) {
			int w = container.getWidth();
			int h = container.getHeight();

			// equal height like in GridLayout
			int maxHeight =
				((h - (centerTop + centerBottom) - margin)
				- (centerList.size() - 1) * vGap) / centerList.size();
				
			for (Info i : centerList) {
				i.layout(p.x, p.y, w - (centerLeft + centerRight) - margin, maxHeight);
				p.y += maxHeight + vGap;
			}
		}
	}

	@Override
	public Dimension minimumLayoutSize(final Container container) {
		return calcLayoutSize(Size.MINIMUM);
	}

	@Override
	public Dimension preferredLayoutSize(final Container container) {
		return calcLayoutSize(Size.PREFERRED);
	}
	
	// LayoutManager2

	@Override
	public void addLayoutComponent(final Component c, final Object constraints) {
		Position position;
		if (constraints == null) // convert null to default
			position = Position.CENTER;
		else if (constraints instanceof Position)
			position = (Position)constraints;
		else if (constraints instanceof String) // convert String to Position
			position = stringConstraintsMap.get(constraints.toString());
		else
			position = null;
		
		if (position == null)
			throw new IllegalArgumentException("Invalid layout constraints: " + constraints);

		// remove duplicates
		remove(c);

		map.get(position)
			.add(new Info(c));
	}

	@Override
	public float getLayoutAlignmentX(final Container container) { return Component.LEFT_ALIGNMENT; }

	@Override
	public float getLayoutAlignmentY(final Container container) { return Component.TOP_ALIGNMENT; }

	@Override
	public void invalidateLayout(final Container container) {
		for (Position i : positions) {
			for (Info info : map.get(i))
				info.flushCache();
		}
	}

	@Override
	public Dimension maximumLayoutSize(final Container container) {
		return calcLayoutSize(Size.MAXIMUM);
	}
	
	// private
	
	private Dimension calcLayoutSize(final Size size) {
		int w = 0;
		int h = 0;

		for (Info i : map.get(Position.TOP)) {
			Dimension d = i.getSize(size);
			w = Math.max(w, d.width);
			h += d.height + vGap;
		}

		for (Info i : map.get(Position.BOTTOM)) {
			Dimension d = i.getSize(size);
			w = Math.max(w, d.width);
			h += d.height + vGap;
		}

		int totalWidth = 0;
		int leftRightHeight = 0;

		for (Info i : map.get(Position.LEFT)) {
			Dimension d = i.getSize(size);
			totalWidth += d.width + hGap;
			leftRightHeight = Math.max(leftRightHeight, d.height);
		}

		for (Info i : map.get(Position.RIGHT)) {
			Dimension d = i.getSize(size);
			totalWidth += d.width + hGap;
			leftRightHeight = Math.max(leftRightHeight, d.height);
		}

		int centerHeight = 0;
		List<Info> centerList = map.get(Position.CENTER);
		if (!centerList.isEmpty()) {
			int centerWidth = 0;
			for (Info i : centerList) {
				Dimension d = i.getSize(size);
				centerWidth = Math.max(centerWidth, d.width);
				centerHeight += d.height;
			}
			centerHeight += (centerList.size() - 1) * vGap;
			totalWidth += centerWidth;
		}

		return new Dimension(
			Math.max(w, totalWidth) + (margin * 2),
			h + Math.max(leftRightHeight, centerHeight) + (margin * 2)
		);
	}
	
	private void layout(final Container container, final Position position, final Point p, final boolean forward) {
		List<Info> list = map.get(position);
		
		if (list.isEmpty())
			return;
		
		int w = container.getWidth();
		int h = container.getHeight();
		
		ListIterator<Info> it = list.listIterator(forward ? 0 : list.size());
		while (true) {
			if (forward) {
				if (!it.hasNext())
					break; // while
			}
			else {
				if (!it.hasPrevious())
					break; // while
			}
		
			Info i = forward ? it.next() : it.previous();
			Dimension d = i.getPreferredSize();
			int leftRightHeight = h - (centerBottom + centerTop) - margin;
			int topBottomWidth = w - margin * 2;
			switch (position) {
				case TOP:
					i.layout(p.x, p.y, topBottomWidth, d.height);
					p.y += d.height + vGap;
					break;
				case BOTTOM:
					i.layout(p.x, p.y + h - d.height - margin, topBottomWidth, d.height);
					p.y -= d.height + vGap;
					break;
				case LEFT:
					i.layout(p.x, p.y, d.width, leftRightHeight);
					p.x += d.width + hGap;
					break;
				case RIGHT:
					i.layout(p.x + w - d.width - margin, p.y, d.width, leftRightHeight);
					p.x -= d.width + hGap;
					break;
				default:
					throw new WTFError(position);
			}
		}
	}
	
	private void remove(final Component c) {
		for (Position i : positions) {
			map.get(i)
				.removeIf(info -> info.getComponent() == c);
		}
	}
	
	private int requirePositive(final int value) {
		if (value < 0)
			throw new IllegalArgumentException("Value cannot be less than zero: " + value);
	
		return value;
	}
	
	// private classes
	
	private final class Info {
	
		// private
		
		private final Component component;
		private Dimension maximumSizeCache;
		private Dimension minimumSizeCache;
		private Dimension preferredSizeCache;
	
		// public
		
		public Info(final Component component) {
			this.component = Objects.requireNonNull(component);
		}
		
		public void flushCache() {
			maximumSizeCache = null;
			minimumSizeCache = null;
			preferredSizeCache = null;
		}
		
		public Component getComponent() { return component; }

		public Dimension getMaximumSize() {
			if (isHidden())
				return new Dimension(0, 0);
		
			if (maximumSizeCache == null)
				maximumSizeCache = component.getMaximumSize();
			
			return maximumSizeCache;
		}

		public Dimension getMinimumSize() {
			if (isHidden())
				return new Dimension(0, 0);

			if (minimumSizeCache == null)
				minimumSizeCache = component.getMinimumSize();
			
			return minimumSizeCache;
		}

		public Dimension getPreferredSize() {
			if (isHidden())
				return new Dimension(0, 0);

			if (preferredSizeCache == null)
				preferredSizeCache = component.getPreferredSize();
			
			return preferredSizeCache;
		}
		
		public Dimension getSize(final Size size) {
			switch (size) {
				case MAXIMUM: return getMaximumSize();
				case MINIMUM: return getMinimumSize();
				case PREFERRED: return getPreferredSize();
				default: throw new WTFError(size);
			}
		}
		
		public void layout(final int x, final int y, final int w, final int h) {
			if (!isHidden())
				component.setBounds(x, y, w, h);
		}
		
		// private
		
		private boolean isHidden() {
			if (!MSimpleLayout.this.getHonorsVisibility())
				return false;
			
			return !component.isVisible();
		}
	
	}

}