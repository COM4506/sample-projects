// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.util.Objects;
import javax.swing.JComponent;
import javax.swing.JViewport;

import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MGraphics2D;

/**
 * @mg.warning {@code Watermark} will automatically change {@code JViewport}'s mode to the {@code SIMPLE_SCROLL_MODE}.
 * In some cases {@code SIMPLE_SCROLL_MODE} may decrease redrawing performance.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class Watermark implements MDisposable {
	
	// private

	private boolean initViewport = true;
	private final Dimension margin;
	private Image image;

	// public

	/**
	 * @since 4.0
	 */
	public Watermark(final Image image, final Dimension margin) {
		this.image = Objects.requireNonNull(image);
		this.margin = new Dimension(margin);
	}

	/**
	 * Paints the watermark image.
	 * @param component The component
	 * @param graphics The graphics 2D
	 *
	 * @throws NullPointerException If @p component is @c null
	 *
	 * @since 2.0
	 */
	public void paint(final JComponent component, final Graphics graphics) {
		if (image == null)
			return;
		
		MGraphics2D g = new MGraphics2D(graphics);
		Point position;
		Dimension size;
		
		JViewport componentViewport = MScrollPane.getViewport(component);
		if (initViewport) {
			initViewport = false;
			if (componentViewport != null)
				componentViewport.setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
		}

		if (componentViewport == null) {
			position = new Point();
			size = component.getSize();
		}
		else {
			position = componentViewport.getViewPosition();
			size = componentViewport.getSize();
		}
		
		g.setAlpha(0.1f);
		g.drawImage(
			image,
			position.x + (size.width - image.getWidth(null) - margin.width),
			position.y + (size.height - image.getHeight(null) - margin.height)
		);
		g.dispose();
	}
	
	// MDisposable
	
	@Override
	public void dispose() {
		image = null;
	}
	
}
