// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.ConstructorProperties;
import java.io.Serializable;
import java.util.Objects;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;

import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.style.StyleSupport;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * A label with static text and/or icon.
 *
 * @mg.screenshot
 * <img alt="MLabel example" src="../doc-files/MLabel.png">
 *
 * @mg.example
 * <pre class="brush: java">
 * MLabel label = new MLabel("Hello");
 * label.setIconName("ui/ok");
 * </pre>
 *
 * @see #MLabel(String)
 * @see #setIconName(String)
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MLabel extends JLabel
implements
	MIcon.Name,
	StyleSupport
{
	
	// private
	
	private boolean strikeThrough;
	private boolean textAntialiasing;
	private static Color defaultStrikeThroughColor;
	private Color strikeThroughColor;
	private MouseListener localBuddyMouseListener;
	private static StaticHandler staticHandler = new StaticHandler();

	// public

	/**
	 * Constructs a label with {@code null} text and {@code null} icon.
	 */
	public MLabel() {
		this(null, (Icon)null);
	}

	/**
	 * Constructs a label with {@code null} text.
	 *
	 * @param icon the icon (can be {@code null})
	 */
	@ConstructorProperties("icon")
	public MLabel(final Icon icon) {
		this(null, icon);
	}

	/**
	 * Constructs a label with {@code null} text.
	 *
	 * @param image the icon image (can be {@code null})
	 */
	public MLabel(final Image image) {
		this(null, (image == null) ? null : new MIcon(image));
	}

	/**
	 * Constructs a label with {@code null} icon.
	 *
	 * @param text the text (can be {@code null})
	 */
	@ConstructorProperties("text")
	public MLabel(final String text) {
		this(text, (Icon)null);
	}

	/**
	 * Constructs a label.
	 *
	 * @param text the text (can be {@code null})
	 * @param icon the icon (can be {@code null})
	 */
	@ConstructorProperties({ "text", "icon" })
	public MLabel(final String text, final Icon icon) {
		setIcon(icon);
		setText(text);
	}

	/**
	 * Constructs a label.
	 *
	 * @param text the text (can be {@code null})
	 * @param iconName the icon name (can be {@code null})
	 *
	 * @see #setIconName(String)
	 *
	 * @since 1.2
	 */
	@ConstructorProperties({ "text", "iconName" })
	public MLabel(final String text, final String iconName) {
		this(text, MIcon.stock(iconName));
	}

	/**
	 * Creates and returns a new label with a <i>buddy</i> {@code component}.
	 * The {@code horizontalAlignment} property is set to {@code LEADING}.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * MLabel label = MLabel.createFor(nameTextField, "Name:");
	 * assert label.getLabelFor() == nameTextField;
	 * </pre>
	 * 
	 * @param component the <i>buddy</i> component (can be {@code null})
	 * @param text the text (can be {@code null})
	 *
	 * @return A new label with a <i>buddy</i> {@code component}.
	 *
	 * @see #getLabelFor()
	 */
	public static MLabel createFor(final Component component, final String text) {
		return createFor(component, text, LEADING);
	}

	/**
	 * Creates and returns a new label with a <i>buddy</i> {@code component}.
	 *
	 * @param component the <i>buddy</i> component (can be {@code null})
	 * @param text the text (can be {@code null})
	 * @param horizontalAlignment the horizontal alignment
	 *
	 * @return A new label with a <i>buddy</i> {@code component}.
	 *
	 * @see #getLabelFor()
	 */
	public static MLabel createFor(final Component component, final String text, final int horizontalAlignment) {
		MLabel label = new MLabel(text);
		label.setHorizontalAlignment(horizontalAlignment);
		label.setLabelFor(component);

		return label;
	}
	
	/**
	 * @since 4.2
	 */
	public static MLabel createSmall(final String text) {
		return createSmall(text, null);
	}

	/**
	 * Creates and returns a label with smaller font size.
	 * 
	 * @param text the text (can be {@code null})
	 * @param icon the icon (can be {@code null})
	 *
	 * @return A label with smaller font size.
	 *
	 * @since 3.0
	 */
	public static MLabel createSmall(final String text, final Icon icon) {
		MLabel label = new MLabel(text, icon);
		UI.changeFontSize(label, -1);
		
		return label;
	}

	/**
	 * Returns the label component associated with {@code c} component, or {@code null}.
	 *
	 * @param c the component
	 *
	 * @return the label component associated with {@code c} component, or {@code null}.
	 *
	 * @throws NullPointerException If {@code c} is {@code null}
	 *
	 * @see #getLabelFor()
	 *
	 * @since 3.4
	 */
	public static JLabel getLabel(final JComponent c) {
		return UI.getClientProperty(c, "labeledBy", null);
	}
	
	/**
	 * @since 4.0
	 */
	public Color getStrikeThroughColor() {
		if (strikeThroughColor == null) {
			if (defaultStrikeThroughColor == null)
				defaultStrikeThroughColor = MColor.deriveAlpha(MColor.RED, 127);
			strikeThroughColor = defaultStrikeThroughColor;
		}
		
		return strikeThroughColor;
	}

	/**
	 * @since 4.0
	 */
	public void setStrikeThroughColor(final Color value) {
		Objects.requireNonNull(value);
		if (!Objects.equals(getStrikeThroughColor(), value)) {
			strikeThroughColor = value;
			if (strikeThrough)
				repaint();
		}
	}
	
	/**
	 * Whether or not strike through line is painted over the text.
	 *
	 * @mg.default
	 * {@code false}
	 *
	 * @return Whether or not strike through line is painted over the text.
	 *
	 * @see #setStrikeThrough(boolean)
	 *
	 * @since 3.0
	 */
	public boolean isStrikeThrough() { return strikeThrough; }

	/**
	 * Sets whether or not strike through line is painted over the text.
	 *
	 * @param value the new value
	 *
	 * @see #isStrikeThrough()
	 *
	 * @since 3.0
	 */
	public void setStrikeThrough(final boolean value) {
		if (value != strikeThrough) {
			strikeThrough = value;
			repaint();
		}
	}

	/**
	 * Whether or not text antialiasing is forced.
	 *
	 * @return Whether or not text antialiasing is forced.
	 *
	 * @mg.default
	 * {@code false}
	 *
	 * @see #setTextAntialiasing(boolean)
	 *
	 * @since 3.0
	 */
	public boolean isTextAntialiasing() { return textAntialiasing; }

	/**
	 * Sets whether or not text antialiasing is forced.
	 *
	 * @param value the new value
	 *
	 * @see #isTextAntialiasing()
	 *
	 * @since 3.0
	 */
	public void setTextAntialiasing(final boolean value) {
		if (value != textAntialiasing) {
			textAntialiasing = value;
			repaint();
		}
	}

	/**
	 * Sets the following properties:
	 *
	 * <ul>
	 * <li>horizontalAlignment = CENTER</li>
	 * <li>horizontalTextPosition = CENTER</li>
	 * <li>verticalAlignment = CENTER</li>
	 * <li>verticalTextPosition = BOTTOM</li>
	 * <li>iconTextGap = {@link MPanel#DEFAULT_CONTENT_MARGIN}</li>
	 * </ul>
	 *
	 * @since 3.4
	 */
	public void makeLargeMessage() {
		setHorizontalAlignment(CENTER);
		setHorizontalTextPosition(CENTER);
		setVerticalAlignment(CENTER);
		setVerticalTextPosition(BOTTOM);
		setIconTextGap(MPanel.DEFAULT_CONTENT_MARGIN);
	}

	/**
	 * @since 5.6
	 */
	public static MLabel newPlainText(final String text) {
		MLabel l = new MLabel();
		l.setHTMLEnabled(false); // 1.
		l.setText(text); // 2.

		return l;
	}

	/**
	 * Sets cursor to {@code type}.
	 *
	 * @param type the new cursor type
	 *
	 * @throws IllegalArgumentException If {@code type} is invalid
	 *
	 * @see java.awt.Cursor
	 *
	 * @since 3.4
	 */
	public void setCursor(final int type) {
		setCursor(Cursor.getPredefinedCursor(type));
	}

	/**
	 * Sets text as HTML.
	 * The <code>&lt;html&gt;&lt;body&gt;</code> and <code>&lt;/body&gt;&lt;/html&gt;</code>
	 * tags will be added automatically.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * MLabel label = new MLabel();
	 * label.setHTML("&lt;b&gt;Bold&lt;/b&gt; Text");
	 * assert label.getText().equals("&lt;html&gt;&lt;body&gt;&lt;b&gt;Bold&lt;/b&gt; Text&lt;/body&gt;&lt;/html&gt;");
	 * </pre>
	 *
	 * @param code the HTML code (can be {@code null})
	 *
	 * @see #setMultilineText(String)
	 * @see #setText(String)
	 * @see TK#escapeXML(String)
	 * @see UI#makeHTML(String)
	 */
	public void setHTML(final String code) {
		if (code == null)
			setText(null);
		else
			setText(UI.makeHTML(code));
	}

	/**
	 * @since 5.6
	 */
	public void setHTMLEnabled(final boolean value) {
		UI.setHTMLEnabled(this, value);
	}

	/**
	 * Sets icon image to {@code value}.
	 * 
	 * @param value the new icon image (can be {@code null}).
	 */
	public void setImage(final Image value) {
		setIcon((value == null) ? null : new MIcon(value));
	}

	/**
	 * Overriden to install mouse listener that focuses the <i>buddy</i> component.
	 *
	 * @param component the buddy component (can be {@code null})
	 */
	@Override
	public void setLabelFor(final Component component) {
		super.setLabelFor(component);
		if (component == null) {
			if (localBuddyMouseListener != null) {
				removeMouseListener(localBuddyMouseListener);
				localBuddyMouseListener = null;
			}
		}
		else if (!UI.isRetro()/* has own listener */) {
			if (localBuddyMouseListener == null) {
				localBuddyMouseListener = staticHandler;
				addMouseListener(localBuddyMouseListener);
			}
		}
	}

	/**
	 * Sets text as one or more lines.
	 * The lines are separated using "\n".
	 *
	 * @mg.warning
	 * The {@code value} may be converted and stored as HTML.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * MLabel label = new MLabel();
	 * label.setMultilineText("Line 1\nLine 2");
	 * </pre>
	 *
	 * @param value the new text
	 *
	 * @see #setHTML(String)
	 *
	 * @since 3.8
	 */
	public void setMultilineText(final String value) {
		// multi line
		if ((value != null) && value.contains("\n")) {
			HTMLBuilder html = new HTMLBuilder();
			html.beginHTML();
			html.beginDoc();
			
			String[] lineArray = value.split("\n");
			TK.forEach(lineArray, (line, index) -> {
				html.append(html.escape(line));
				if (index < lineArray.length - 1)
					html.append("<br>");
			} );

			html.endDoc();
			setText(html.toString());
		}
		// single line
		else {
			setText(value);
		}
	}

	/**
	 * Sets text to {@code value}.
	 *
	 * @param value the new text (<code>value.toString()</code>)
	 *
	 * @throws NullPointerException If {@code value} is {@code null}
	 */
	public void setNumber(final Number value) {
		setText(value.toString());
	}

	/**
	 * Overriden to set
	 * <code>"substancelaf.useThemedDefaultIcons"</code> client property to {@code false}.
	 */
	@Override
	public void updateUI() {
		// SubstanceLookAndFeel.USE_THEMED_DEFAULT_ICONS
		if (UI.isSubstance())
			putClientProperty("substancelaf.useThemedDefaultIcons", false);
		super.updateUI();
	}

	// MIcon.Name

	/**
	 * @since 2.0
	 */
	@Override
	public String getIconName() {
		return MIcon.getName(getIcon());
	}

	/**
	 * @since 2.0
	 */
	@Override
	public void setIconName(final String value) {
		setIcon(MIcon.stock(value));
	}

	// StyleSupport

	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	/**
	 * Overriden to paint antialiased text and/or strike through line.
	 *
	 * @see #isStrikeThrough()
	 * @see #isTextAntialiasing()
	 *
	 * @param graphics the graphics
	 */
	@Override
	protected void paintComponent(final Graphics graphics) {
		Graphics2D g = (Graphics2D)graphics;

		if (textAntialiasing)
			UI.setTextAntialiasing(g, null);

		super.paintComponent(g);

		// NOTE: copied from UI.strikeThrough method
		if (strikeThrough) {
			String text = getText();
			if (!TK.isEmpty(text)) {
				int w = getWidth();
				g.setColor(getStrikeThroughColor());

				FontMetrics metrics = g.getFontMetrics(getFont());
				int textWidth = metrics.stringWidth(text);

				int x1;
				int ha = getHorizontalAlignment();
				if (ha == RIGHT)
					x1 = (w - textWidth);
				else if (ha == CENTER)
					x1 = (w / 2) - (textWidth / 2);
				else
					x1 = 0;
				
				Insets insets = getInsets();
				if (insets != null) {
					if (ha == RIGHT)
						x1 -= insets.right;
					else
						x1 += insets.left;
				}

				Icon icon = getIcon();
				if (icon != null)
					x1 += (icon.getIconWidth() + getIconTextGap());

				int x2 = Math.min(w - 5, textWidth + x1 - 5);
				int y1 = getHeight() / 2;
				g.drawLine(x1, y1, x2, y1);
/* chaotic lines
				Random random = new Random(text.hashCode());
				g.setColor(MColor.deriveAlpha(Color.BLUE, 100));
				g.setStroke(new BasicStroke(2));
				UI.setAntialiasing(g, true);
				int lx = x1;
				int ly = y1 - 5;
				boolean addY = true;
				while (lx < x2) {
					int rx = lx + random.nextInt(5) + 2;
					int r = random.nextInt(5) + 10;
					int ry;
					if (addY)
						ry = ly + r;
					else
						ry = ly - r;
					addY = !addY;
					g.drawLine(lx, ly, rx, ry);
					lx = rx;
					ly = ry;
				}
*/
			}
		}
	}

	// private classes

	private static final class StaticHandler extends MMouseAdapter implements Serializable {

		// public

		@Override
		public void buttonClicked/*mouseClicked*/(final MouseEvent e) {
			if (isLeft(e)) {
				MLabel label = (MLabel)e.getSource();
				Component labelFor = label.getLabelFor();

				if (!label.isEnabled())
					return;

				if (labelFor != null) {
					MComponent.requestFocus(labelFor);
					e.consume();
				}
			}
		}

	}

}
