// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.html.FormView;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;

import org.makagiga.commons.Globals;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.Tuple;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.sb.SecureOpen;
import org.makagiga.commons.style.StyleSupport;

/**
 * A text pane.
 *
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTextPane extends JTextPane
implements
	MText.CommonExtensions,
	MText.Modifiable,
	SecureOpen,
	StyleSupport
{
	
	// private
	
	private boolean modified;
	private boolean secureOpen;
	private Tuple.Two<URL, String> currentLink;

	// public

	/**
	 * HTML content type and UTF-8 encoding.
	 */
	public static final String TEXT_HTML_UTF_8 = "text/html; charset=UTF-8";

	// public

	/**
	 * Constructs a text pane.
	 */
	public MTextPane() {
		setDragEnabled(Kiosk.actionDragDrop.get());
		MText.install(this);

		StaticHandler handler = new StaticHandler();
		addHyperlinkListener(handler);
		MText.setUserMenu(this, handler);
		MText.setStandardColors(this);
	}

	@Override
	public void doLayout() {
		try {
			super.doLayout();
		}
		// HACK: some crash in HTML renderer
		catch (ArrayIndexOutOfBoundsException exception) {
			MLogger.developerException(exception);
		}
	}

	/**
	 * @since 4.6
	 */
	public AttributeSet getLinkAttributes(final AttributeSet attr) {
		for (Object o : TK.iterable(attr.getAttributeNames())) {
			if (o.equals(HTML.Tag.A)) {
				o = attr.getAttribute(HTML.Tag.A);

				if (o instanceof AttributeSet)
					return (AttributeSet)o;
			}
		}
		
		return null;
	}

	@Override
	public Dimension getPreferredSize() {
		try {
			return super.getPreferredSize();
		}
		// HACK: some crash in HTML renderer
		catch (ArrayIndexOutOfBoundsException exception) {
			MLogger.developerException(exception);
			
			return new Dimension(200, 200);
		}
	}

	@Override
	public String getToolTipText(final MouseEvent e) {
		String s = getUI().getToolTipText(this, e.getPoint());
		
		if (!TK.isEmpty(s))
			return s;
		
		s = super.getToolTipText(e);
		
		return TK.isEmpty(s) ? null : s;
	}

	/**
	 * @mg.default {@code false}
	 *
	 * @since 3.8.6
	 */
	@Override
	public boolean isSecureOpen() { return secureOpen; }

	/**
	 * @since 3.8.6
	 */
	@Override
	public void setSecureOpen(final boolean value) { secureOpen = value; }

	@Override
	public void scrollToReference(final String reference) {

		// try <a name= (default)

		super.scrollToReference(reference);

		// try <... id=

		if (reference == null)
			return;

		Document doc = getDocument();

		if (doc instanceof HTMLDocument) {
			HTMLDocument htmlDoc = (HTMLDocument)doc;
			Element e = htmlDoc.getElement(reference);
			if (e != null) {
				// CREDITS: based on the JEditorPane.scrollToReference(String)
				try {
					Rectangle r = modelToView(e.getStartOffset());
					if (r != null) {
						r.height = getVisibleRect().height;
						MScrollPane.scrollToVisible(this, r);
					}
				}
				catch (BadLocationException exception) {
					MLogger.exception(exception);
				}
			}
		}
	}

	@InvokedFromConstructor
	@Override
	public void setBackground(final Color color) {
		super.setBackground(color);
		MEditorPane.fixNimbus(this, "TextPane[Enabled].backgroundPainter", color);
	}

	@Override
	public synchronized void setText(final String value) {
		currentLink = null;
		setToolTipText(UI.DYNAMIC_TOOL_TIP_TEXT);
		super.setText(value);
	}

	// MText.CommonExtensions

	@Override
	public synchronized void clear() {
		setText(null);
	}

	@Override
	public synchronized boolean isEmpty() {
		return MText.isEmpty(this);
	}
	
	// MText.Modifiable

	/**
	 * @since 2.0
	 */
	@Override
	public boolean isModified() { return modified; }

	/**
	 * @since 2.0
	 */
	@Override
	public void setModified(final boolean value, final Object event) {
		modified = value;
		if (modified)
			onChange((event instanceof DocumentEvent) ? (DocumentEvent)event : null);
	}

	// StyleSupport
	
	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	/**
	 * @since 2.0
	 */
	protected void onChange(final DocumentEvent e) { }

	/**
	 * Invoked when user clicked on the hyperlink.
	 * By default this function does nothing and returns {@code false}.
	 *
	 * @param e the hyperlink event
	 * @param uri the clicked link address
	 *
	 * @since 4.0
	 */
	protected boolean onHyperlinkClick(final HyperlinkEvent e, final URI uri) { return false; }

	// private classes

	private static final class StaticHandler
	implements
		HyperlinkListener,
		MText.UserMenu<MTextPane>
	{

		// public

		public StaticHandler() { }

		@Override
		public void hyperlinkUpdate(final HyperlinkEvent e) {
			if (e.getSource() instanceof FormView) {
				MStatusBar.warning(i18n("Unsupported HTML Element: {0}", "<form>"));

				return;
			}

			MTextPane textPane = (MTextPane)e.getSource();
			if (
				(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) &&
				// HACK: fix "a" tags with left margin
				(textPane.currentLink != null)
			) {
				//textPane.currentLink = null;
				textPane.setToolTipText(UI.DYNAMIC_TOOL_TIP_TEXT);

				Document doc = textPane.getDocument();
				String description = e.getDescription();
				URI uri = null;
				URL url = e.getURL();
				URL base = (doc instanceof HTMLDocument) ? HTMLDocument.class.cast(doc).getBase() : null;

				// scroll to reference - <a name="name"></a>

				String ref = null;
				if (TK.startsWith(description, '#'))
					ref = description.substring(1);
				else if (url != null)
					ref = url.getRef();

				if (ref != null) {
					textPane.scrollToReference(ref);

					if (
						(url == null) ||
						((url != null) && (base != null) && base.sameFile(url))
					)
						return;
				}
				
				try {
					if (url != null)
						uri = url.toURI();
				}
				catch (URISyntaxException exception) {
					MLogger.exception(exception);
				}
				
				// handle event

				if ((uri != null) && textPane.onHyperlinkClick(e, uri))
					return;

				// open external URI

				if (uri != null) {
					MApplication.openURI(uri, textPane);
				}
				
				// resolve relative URI
				
				else if (!TK.isEmpty(description)) {
					try {
						if (description.equals("/"))
							uri = new URI("./");
						else {
							if (description.contains(":"))
								uri = new URI(description); // preserve scheme part
							else
								uri = new URI(TK.escapeURL(description));
						}
						
						if (!uri.isAbsolute() && (base != null))
							uri = base.toURI().resolve(uri);
						
						// handle event or open external URI
						if (!textPane.onHyperlinkClick(e, uri))
							MApplication.openURI(uri, textPane);
					}
					catch (URISyntaxException exception) {
						MLogger.exception(exception);
					}
				}
			}
			else if (e.getEventType() == HyperlinkEvent.EventType.ENTERED) {
				Element element = e.getSourceElement();
				String description = e.getDescription();
				URL url = e.getURL();
				String linkName = MText.getText(textPane.getDocument(), element);
				if (linkName == null)
					linkName = description;
				textPane.currentLink = Tuple.of(url, linkName);

				String toolTipText;
				String urlText;

				if (url == null)
					urlText = TK.isEmpty(description) ? i18n("No Description") : description;
				else
					urlText = url.toString();

				if (urlText.startsWith("makagiga-"))
					urlText = ""; // internal protocol; no tool tip
				if (urlText.isEmpty())
					toolTipText = "";
				else
					toolTipText = TK.escapeXML(TK.centerSqueeze(urlText, 128));

				// add a description from "title" attribute (<a title=...)
				Optional<String> optionalTitle = Optional.ofNullable(element)
					.map(Element::getAttributes)
					.map(textPane::getLinkAttributes)
					.map(attr -> Objects.toString(attr.getAttribute(HTML.Attribute.TITLE), ""))
					.filter(TK::nonEmpty);
				if (optionalTitle.isPresent()) {
					String titleHTML = TK.escapeXML(TK.rightSqueeze(optionalTitle.get(), 128));
					if (!titleHTML.equals(toolTipText)) { // do not duplicate text
						if (!toolTipText.isEmpty())
							toolTipText += "<br>";
						toolTipText += titleHTML;
					}
				}

				textPane.setToolTipText(toolTipText.isEmpty() ? UI.DYNAMIC_TOOL_TIP_TEXT : UI.makeHTML(toolTipText));
			}
			else if (e.getEventType() == HyperlinkEvent.EventType.EXITED) {
				textPane.currentLink = null;
				textPane.setToolTipText(UI.DYNAMIC_TOOL_TIP_TEXT);
			}
		}

		@Override
		public void onUserMenu(final MTextPane textComponent, final MMenu menu) {
			try {
				Tuple.Two<URL, String> linkInfo = textComponent.currentLink;
				URL url = null;
				String description = null;
				
				// resolve from text attributes
				
				if ((linkInfo == null) || (linkInfo.get1() == null)) {
					if (textComponent.getDocument() instanceof HTMLDocument) {
						AttributeSet linkAttr = textComponent.getLinkAttributes(textComponent.getInputAttributes());
						if (linkAttr != null) {
							Object href = linkAttr.getAttribute(HTML.Attribute.HREF);
							description = Objects.toString(href, null);
							try {
								url = new URL(description);
							}
							// ignore URL and use description instead
							catch (MalformedURLException exception) { }
						}
					}
				}
				
				// use info
				
				else {
					url = linkInfo.get1();
					description = linkInfo.get2();
				}
				
				// add standard link menu
				if (url != null) {
					Globals.updateLinkMenu(menu, url.toURI(), description);
				}
				
				// add "Open" link action
				if ((url != null) || (description != null)) {
					MDataAction<Tuple.Two<URL, String>> openLinkAddressAction = new MDataAction<Tuple.Two<URL, String>>(
						Tuple.of(url, description),
						MActionInfo.OPEN_URI
					) {
						@Override
						public void onAction() {
							URL url = this.getData().get1();
							String description = this.getData().get2();
							HyperlinkEvent e = new HyperlinkEvent(
								textComponent,
								HyperlinkEvent.EventType.ACTIVATED,
								url,
								Objects.toString(url, description)
							);
							try {
								textComponent.currentLink = this.getData();
								textComponent.fireHyperlinkUpdate(e);
							}
							finally {
								textComponent.currentLink = null;
							}
						}
					};
					openLinkAddressAction.setEnabled(Kiosk.linkAllowOpen.get());
					openLinkAddressAction.setHelpText(UI.getLinkToolTipText(Objects.toString(url, description)));
					menu.add(openLinkAddressAction);
				}
			}
			catch (URISyntaxException exception) {
				MStatusBar.error(exception);
			}
		}

	}

}
