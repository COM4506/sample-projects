// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import javax.swing.Icon;
import javax.swing.JMenuItem;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.UI;
import org.makagiga.commons.style.StyleSupport;

/**
 * A menu item.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MMenuItem extends JMenuItem implements StyleSupport {

	// public
	
	/**
	 * Constructs a menu item.
	 */
	public MMenuItem() { }

	/**
	 * Constructs a menu item.
	 * @param action An action
	 *
	 * @since 2.0
	 */
	public MMenuItem(final MAction action) {
		if (!action.isHTMLEnabled())
			UI.setHTMLEnabled(this, false);
		setAction(action);
		setToolTipText(action.getHelpText());
	}

	/**
	 * Constructs a menu item.
	 * @param text A text
	 */
	public MMenuItem(final String text) {
		super(text);
	}

	/**
	 * Constructs a menu item.
	 * @param text A text
	 * @param icon An icon
	 */
	public MMenuItem(final String text, final Icon icon) {
		super(text, icon);
	}

	/**
	 * Constructs a menu item.
	 * @param text A text
	 * @param iconName An icon name
	 */
	public MMenuItem(final String text, final String iconName) {
		this(text, MIcon.small(iconName));
	}

	/**
	 * Returns the action associated with this menu item.
	 */
	@Override
	public MAction getAction() {
		return (MAction)super.getAction();
	}

	// StyleSupport

	/**
	 * @since 2.0
	 */
	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

}
