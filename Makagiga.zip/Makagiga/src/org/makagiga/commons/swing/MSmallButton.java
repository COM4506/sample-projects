// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Cursor;
import java.awt.Graphics2D;
import javax.swing.Action;
import javax.swing.Icon;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.UI;

/**
 * A small button.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MSmallButton extends MButton {

	// public
	
	/**
	 * Constructs a button.
	 */
	public MSmallButton() {
		this((Icon)null, null);
	}

	/**
	 * @since 3.0
	 */
	public MSmallButton(final Action action, final boolean showText) {
		super(action);
		setIcon((Icon)MAction.getValue(action, Action.SMALL_ICON, null));
		if (!showText) {
			setToolTipText(getText());
			setText(null);
		}
		else {
			setToolTipText(UI.DYNAMIC_TOOL_TIP_TEXT);
		}
	}

	/**
	 * @since 3.0
	 */
	public MSmallButton(final MActionInfo actionInfo) {
		this(actionInfo.getSmallIcon(), actionInfo.getText());
	}

	/**
	 * @since 2.0
	 */
	public MSmallButton(final Icon icon, final String toolTipText) {
		super(icon);
		setToolTipText(toolTipText);
	}

	/**
	 * @since 5.6
	 */
	public void paintFocus(final Graphics2D g) {
		UI.paintFocus(this, g, null, 1);
	}

	@Override
	public void updateUI() {
		setUI(UI.getSimpleButtonUI());
		
		setBorderPainted(false);
		setContentAreaFilled(false);
		setCursor(Cursor.HAND_CURSOR);
		setRequestFocusEnabled(false);

		updateUIStyle();
	}

	// protected

	/**
	 * @since 3.8.3
	 */
	protected void updateUIStyle() {
		setStyle("margin: 3; padding: 2");
	}
	
}
