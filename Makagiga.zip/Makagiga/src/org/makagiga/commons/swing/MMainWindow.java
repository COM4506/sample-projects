// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JMenuBar;

import org.makagiga.commons.Config;
import org.makagiga.commons.FS;
import org.makagiga.commons.Lockable;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.UI;
import org.makagiga.commons.about.MAboutDialog;

/**
 * The main window.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MMainWindow extends MFrame implements Lockable {

	// private

	private boolean locked;
	private boolean oldMenuBarVisible = true;
	private boolean showSystemTrayInfo = true;
	
	// public
	
	/**
	 * @since 4.2
	 */
	public static final String LOCKED_PROPERTY = "locked";

	// public

	/**
	 * Constructs the main (global) window.
	 */
	public MMainWindow() {
		super(MApplication.getFullName());
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

		readConfig(Config.getDefault(), null);
		setMinimumSize(new Dimension(getWidth() / 2, getHeight() / 2));

		if (MApplication.getLogo() != null)
			setIconImage(MApplication.getLogo());
		
		MStatusBar statusBar = new MStatusBar();
		addSouth(statusBar);

		// init global window and status bar
		MainView.init(this, statusBar);

		// add close event handler
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(final WindowEvent e) {
				// do not initialize MSystemTray class if tray icon is disabled
				if (UI.systemTray.get() && UI.hideMainWindowInTray.get() && MSystemTray.isVisible()) {
					setVisible(false);
					fireWindowIconified();

					if (showSystemTrayInfo) {
						showSystemTrayInfo = false;
						MNotification.Message m = new MNotification.Message(
							MApplication.getFullName(),
							UI.makeHTML(i18n("The application is still running<br>in the system tray.")),
							MApplication.getIcon()
						);
						m.setTimeout(MNotification.getDefaultTimeout());
						m.show();
					}
				}
				else {
					MApplication.quit();
				}
			}
			@Override
			public void windowDeiconified(final WindowEvent e) {
				// repaint window on restore
				repaint();
			}
			@Override
			public void windowIconified(final WindowEvent e) {
				onMinimize();
			}
		} );
	}

	/**
	 * Shows information about this application.
	 */
	public void about() {
		MAboutDialog about = new MAboutDialog(this);
		about.exec();
	}

	/**
	 * Returns @c true if the main window is locked.
	 * 
	 * @see #setLocked(boolean)
	 * 
	 * @since 2.4
	 */
	@Override
	public boolean isLocked() { return locked; }

	/**
	 * Sets whether or not the main window is locked.
	 * 
	 * Locked frame properties:
	 * - Ignores all mouse and keyboard input events
	 * - Content pane is hidden
	 * - Menu bar is hidden
	 * - System tray popup menu is disabled
	 * 
	 * @param value {@code true} = locked, {@code false} = unlocked
	 * 
	 * @see #isLocked()
	 * 
	 * @since 2.4
	 */
	@Override
	public void setLocked(final boolean value) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new MApplication.Permission("setLocked"));

		if (value == locked)
			return;
		
		locked = value;
		JMenuBar menuBar = getJMenuBar();
		if (locked) {
			if (menuBar != null) {
				oldMenuBarVisible = menuBar.isVisible();
				menuBar.setVisible(false);
			}
		}
		else {
			if (menuBar != null)
				menuBar.setVisible(oldMenuBarVisible);
		}
		getContentPane().setVisible(!locked);

		firePropertyChange(LOCKED_PROPERTY, !locked, locked);
	}

	/**
	 * @since 4.0
	 */
	public boolean onTrayIconClick(final MouseEvent e) { return false; }

	/**
	 * @since 4.0
	 */
	public void onTrayIconMenuPopup(final MMenu menu) { }

	public void restore() {
		setVisible(true);
		if (getExtendedState() == ICONIFIED)
			setExtendedState(NORMAL);
		toFront();
	}

	/**
	 * @since 3.8.7
	 */
	public void updateTitle(final String subTitle) {
		StringBuilder name = new StringBuilder(MApplication.getFullName());
		if (FS.getProfile() != null)
			name.append(" [").append(FS.getProfile()).append(']');
		else if (FS.isPortable())
			name.append(" [Portable]");

		if (MApplication.isSafeMode())
			name.append(" [Safe-Mode]");

		if (MApplication.offline.get())
			name.append(" [Offline]");

		if (subTitle != null) {
			name.insert(0, " - ");
			name.insert(0, subTitle);
		}

		setTitle(name.toString());
	}
	
	// protected

	/**
	 * Invoked when this window is minimized (iconified).
	 */
	protected void onMinimize() { }

	// package private

	void fireWindowIconified() {
		WindowListener[] wl = getWindowListeners();
		if (wl.length > 0) {
			WindowEvent e = new WindowEvent(this, WindowEvent.WINDOW_ICONIFIED);
			for (WindowListener i : wl)
				i.windowIconified(e);
		}
	}

}
