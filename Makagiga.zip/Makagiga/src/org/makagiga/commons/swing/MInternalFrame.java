// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.beans.PropertyVetoException;
import java.util.Objects;
import java.util.Optional;
import javax.swing.DesktopManager;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.MouseInputAdapter;
import javax.swing.plaf.DesktopIconUI;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MInternalFrame extends JInternalFrame
implements
	MBorderLayout,
	MIcon.Name
{

	// public
	
	/**
	 * @since 4.0
	 */
	public enum PreviewImageType { SCREENSHOT, SIMPLE }
	
	// private
	
	private boolean backgroundDraggable;
	private boolean shaped;
	private DragAdapter dragAdapter;
	private PreviewImageType previewImageType = PreviewImageType.SCREENSHOT;
	
	// public
	
	public MInternalFrame() {
		this(null);
	}
	
	public MInternalFrame(final String title) {
		super(title);
		setContentPane(new ContentPane());

		// frame options
		setClosable(true);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setIconifiable(true);
		setResizable(true);
		
		addInternalFrameListener(new StaticHandler());
	}

	public void close() {
		try {
			setClosed(true);
		}
		catch (PropertyVetoException exception) {
			MLogger.exception(exception);
		}
	}
	
	/**
	 * @since 4.0
	 */
	public MInternalFrame.PreviewImageType getPreviewImageType() { return previewImageType; }

	/**
	 * @since 4.0
	 */
	public void setPreviewImageType(final MInternalFrame.PreviewImageType value) {
		previewImageType = Objects.requireNonNull(value);
	}

	/**
	 * @since 2.2
	 */
	@Override
	public String getIconName() {
		return MIcon.getName(getFrameIcon());
	}

	/**
	 * @since 2.2
	 */
	@Override
	public void setIconName(final String value) {
		setFrameIcon(MIcon.stock(value));
	}

	public boolean isBackgroundDraggable() { return backgroundDraggable; }
	
	public void setBackgroundDraggable(final boolean value) {
		if (backgroundDraggable == value)
			return;
		
		backgroundDraggable = value;
		if (backgroundDraggable) {
			if (dragAdapter == null) {
				dragAdapter = new DragAdapter();
				dragAdapter.install(this);
			}
		}
		else {
			if (dragAdapter != null) {
				dragAdapter.uninstall(this);
				dragAdapter = null;
			}
		}
	}
	
	public boolean isShaped() { return shaped; }

	public void setShaped(final boolean value) {
		if (value == shaped)
			return;
		
		shaped = value;
		Container contentPane = getContentPane();
		if (contentPane instanceof ContentPane)
			ContentPane.class.cast(contentPane).setShaped(shaped);

		// HACK: non-opaque background (Nimbus, GTK+)
		getRootPane().setOpaque(!shaped);

		updateUI();
	}

	public void select() {
		try {
			setSelected(true);
		}
		catch (PropertyVetoException exception) {
			MLogger.warning("core", exception.toString());
		}
	}

	/**
	 * Overriden to force default cursor if desktop pane is locked.
	 *
	 * @param value the cursor
	 */
	@Override
	public void setCursor(final Cursor value) {
		if (MDesktopPane.isLocked(this))
			super.setCursor(Cursor.getDefaultCursor());
		else
			super.setCursor(value);
	}

	public void setIcon(final Icon icon) {
		setFrameIcon(icon);
	}

	@Override
	public void setLocation(final int x, final int y) {
		JDesktopPane dp = getDesktopPane();
		if ((dp != null) && (dp.getDesktopManager() instanceof MDesktopPane.MDesktopManager)) {
			int snapSize = MDesktopPane.MDesktopManager.class.cast(dp.getDesktopManager()).getSnapSize();
			super.setLocation(Math.max(snapSize, x), Math.max(snapSize, y));
		}
		else {
			super.setLocation(x, y);
		}
	}

	@Override
	public void setVisible(final boolean value) {
		if (value && MApplication.getForceRTL() && !isVisible())
			applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

		super.setVisible(value);
	}

	/**
	 * @since 3.4
	 */
	public void showContextMenu(final MouseEvent e) {
		MMenu menu = onContextMenu(e);
		if (menu != null)
			menu.showPopup(e);
	}

	// MBorderLayout
	
	@Override
	public void addCenter(final JComponent component) {
		UI.addCenter(this, component);
	}

	@Override
	public void addEast(final JComponent component) {
		add(component, BorderLayout.LINE_END);
	}

	@Override
	public void addNorth(final JComponent component) {
		add(component, BorderLayout.PAGE_START);
	}

	@Override
	public void addSouth(final JComponent component) {
		add(component, BorderLayout.PAGE_END);
	}

	@Override
	public void addWest(final JComponent component) {
		add(component, BorderLayout.LINE_START);
	}
	
	// protected

	/**
	 * @since 3.8.12
	 */
	protected MMenu.Title addTitle(final MMenu menu) {
		String t = getTitle();

		if (!TK.isEmpty(t))
			return menu.addTitle(TK.centerSqueeze(t, 25), getFrameIcon());

		return null;
	}

	/**
	 * @since 4.0
	 */
	protected Image createPreviewImage() {
		Component visibleComponent = (isIcon() ? getDesktopIcon() : this);
		PreviewImageType usePreviewImageType = isIcon() ? PreviewImageType.SCREENSHOT : previewImageType;
		switch (usePreviewImageType) {
			case SCREENSHOT:
				return MComponent.createScreenshot(visibleComponent, UI.INVISIBLE);
			case SIMPLE: {
				Rectangle r = visibleComponent.getBounds();
				BufferedImage bi = UI.createCompatibleImage(r.width, r.height, false);
				Graphics2D g = bi.createGraphics();
				
				g.setColor(UI.getBackground(visibleComponent));
				g.fillRect(0, 0, r.width, r.height);
				
				Icon icon = getFrameIcon();
				if (icon != null) {
					icon.paintIcon(
						this,
						g,
						r.width / 2 - icon.getIconWidth() / 2,
						r.height / 2 - icon.getIconHeight() / 2
					);
				}
				
				g.dispose();
				
				return bi;
			}
			default:
				throw new WTFError(usePreviewImageType);
		}
	}

	protected boolean canClose() { return true; }

	/**
	 * @since 3.8.12
	 */
	protected MAction createCloseAction() {
		boolean locked = MDesktopPane.isLocked(this);
		MAction closeAction = new MAction(MActionInfo.CLOSE.noKeyStroke(),
			action -> doDefaultCloseAction()
		);
		closeAction.setAcceleratorKey(VK_F4, CTRL_MASK);
		closeAction.setEnabled(!locked);

		return closeAction;
	}

	protected void invalidateUI() {
		invalidateUI((DesktopIconUI)UIManager.getUI(desktopIcon));
	}
	
	protected void invalidateUI(final DesktopIconUI ui) {
		invalidate();
		// HACK: copied from the "JInternalFrame/updateUIWhenHidden" which is package protected
		if (desktopIcon != null) {
			desktopIcon.setUI(ui);
			Dimension d = desktopIcon.getPreferredSize();
			desktopIcon.setSize(d.width, d.height);
			desktopIcon.invalidate();
			for (Component i : desktopIcon.getComponents())
				SwingUtilities.updateComponentTreeUI(i);
		}
	}
	
	protected void onActivate() { }

	protected void onClose() { }
	
	/**
	 * @since 2.4
	 */
	protected MMenu onContextMenu(final InputEvent e) {
		MMenu menu = new MMenu();
		addTitle(menu);
		menu.add(createCloseAction());
		
		return menu;
	}
	
	protected void onDeactivate() { }
	
	protected void onDispose() { }
	
	protected void onMinimize() { }

	@Override
	protected void paintBorder(final Graphics g) {
		if (shouldPaintBorder())
			super.paintBorder(g);
	}

	@Override
	protected void paintComponent(final Graphics g) {
		if (!shaped)
			super.paintComponent(g);
	}

	/**
	 * @since 3.8.7
	 */
	protected boolean shouldPaintBorder() { return !shaped; }

	// public classes
	
	public static class ContentPane extends MPanel {

		// private

		private boolean shaped;

		// public

		public ContentPane() {
			if (UI.isSeaGlass())
				setOpaque(true);
		}

		public void setShaped(final boolean value) {
			if (value != shaped) {
				shaped = value;
				setOpaque(!shaped);
				repaint();
			}
		}

		// protected

		@Override
		protected void paintComponent(final Graphics g) {
			if (!shaped)
				super.paintComponent(g);
		}

	}
	
	public static class DragAdapter extends MouseInputAdapter {

		// private

		private boolean dragged;
		private Point dragStart = new Point();
		
		// public

		/**
		 * @since 3.0
		 */
		public DragAdapter() { }
		
		public void install(final JComponent c) {
			UI.setHandCursor(c, true);

			MouseListener[] oldML = c.getMouseListeners();
			for (MouseListener i : oldML)
				c.removeMouseListener(i);

			c.addMouseListener(this);
			c.addMouseMotionListener(this);

			// HACK: reorder listeners to handle consumed events correctly
			for (MouseListener i : oldML)
				c.addMouseListener(i);
		}

		public void uninstall(final JComponent c) {
			UI.setHandCursor(c, false);
			c.removeMouseListener(this);
			c.removeMouseMotionListener(this);
		}

		@Override
		public void mouseDragged(final MouseEvent e) {
			if (e.isConsumed())
				return;
			
			if (!MMouseAdapter.isLeft(e))
				return;
			
			dragged = true;
			final JComponent source = (JComponent)e.getSource();
			final JComponent c = resolveSource(source);

			if (c instanceof JInternalFrame.JDesktopIcon) {
				if (MDesktopPane.isLocked(c))
					return;

				// snap
				JDesktopPane dp = MDesktopPane.getDesktopPane(c);
				if (dp != null) {
					Point p = SwingUtilities.convertPoint(c, e.getPoint(), dp);
					p.translate(-dragStart.x, -dragStart.y);
					if (dp.getDesktopManager() instanceof MDesktopPane.MDesktopManager) {
						MDesktopPane.MDesktopManager dm = (MDesktopPane.MDesktopManager)dp.getDesktopManager();
						dm.snap(dp, c, p);
					}
					c.setLocation(p);
				}
			}
			else {
				if (MDesktopPane.isLocked(c))
					return;

				getDM(c).ifPresent(dm -> {
					Point p = SwingUtilities.convertPoint(c, e.getPoint(), MDesktopPane.getDesktopPane(c));
					p.translate(-dragStart.x, -dragStart.y);
					dm.dragFrame(c, p.x, p.y);
				} );
			}
			
			e.consume();
		}

		@Override
		public void mousePressed(final MouseEvent e) {
			if (e.isConsumed())
				return;

			if (showContextMenu(e))
				return;

			if (!MMouseAdapter.isLeft(e))
				return;

			final JComponent source = (JComponent)e.getSource();
			final JComponent c = resolveSource(source);
			dragStart = e.getPoint();
			source.requestFocusInWindow();
			
			if (c instanceof JInternalFrame.JDesktopIcon) {
				JInternalFrame.JDesktopIcon di = (JInternalFrame.JDesktopIcon)c;
				di.getInternalFrame().toFront();
			}

			if (!MDesktopPane.isLocked(c))
				UI.setStyle("cursor: move", source);
			else
				UI.setStyle("cursor: default", source);

			getDM(c)
				.ifPresent(dm -> dm.beginDraggingFrame(c));

			e.consume();
		}

		@Override
		public void mouseReleased(final MouseEvent e) {
			if (e.isConsumed())
				return;
			
			if (showContextMenu(e))
				return;

			if (!MMouseAdapter.isLeft(e))
				return;

			final JComponent source = (JComponent)e.getSource();
			UI.setHandCursor(source, true);

			final JComponent c = resolveSource(source);

			if (dragged) {
				dragged = false;
				e.consume();
			}
			dragStart.setLocation(0, 0);

			getDM(c)
				.ifPresent(dm -> dm.endDraggingFrame(c));
		}
		
		// private
		
		private Optional<DesktopManager> getDM(final JComponent c) {
			JDesktopPane dp = MDesktopPane.getDesktopPane(c);

			return Optional.ofNullable((dp != null) ? dp.getDesktopManager() : null);
		}
		
		private JComponent resolveSource(final JComponent c) {
			if ((c instanceof JInternalFrame) || (c instanceof JInternalFrame.JDesktopIcon))
				return c;
			
			return UI.getAncestorOfClass(MInternalFrame.class, c);
		}
		
		private boolean showContextMenu(final MouseEvent e) {
			if (!e.isPopupTrigger())
				return false;

			final JComponent source = (JComponent)e.getSource();
			JInternalFrame f = MDesktopPane.getInternalFrame(resolveSource(source));
			if (f instanceof MInternalFrame) {
				MInternalFrame.class.cast(f).showContextMenu(e);
				e.consume();

				return true;
			}

			return false;
		}

	}

	// private classes

	private static final class StaticHandler extends InternalFrameAdapter {

		// public

		@Override
		public void internalFrameActivated(final InternalFrameEvent e) {
			MInternalFrame internalFrame = (MInternalFrame)e.getSource();
			internalFrame.onActivate();
		}

		@Override
		public void internalFrameClosing(final InternalFrameEvent e) {
			MInternalFrame internalFrame = (MInternalFrame)e.getSource();
			if (internalFrame.canClose()) {
				internalFrame.onClose();
				internalFrame.onDispose();
				internalFrame.dispose();
				if (internalFrame.dragAdapter != null) {
					internalFrame.dragAdapter.uninstall(internalFrame);
					internalFrame.dragAdapter = null;
				}
			}
		}

		@Override
		public void internalFrameDeactivated(final InternalFrameEvent e) {
			MInternalFrame internalFrame = (MInternalFrame)e.getSource();
			internalFrame.onDeactivate();
		}

		@Override
		public void internalFrameDeiconified(final InternalFrameEvent e) {
			MInternalFrame internalFrame = (MInternalFrame)e.getSource();
			// HACK: "activate" frame on deiconify
			internalFrame.onActivate();
		}

		@Override
		public void internalFrameIconified(final InternalFrameEvent e) {
			MInternalFrame internalFrame = (MInternalFrame)e.getSource();
			internalFrame.onMinimize();
		}

		// private

		private StaticHandler() { }

	}

}
