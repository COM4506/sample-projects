// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.Collections;
import java.util.List;
import javax.accessibility.AccessibleContext;
import javax.swing.JTree;
import javax.swing.ToolTipManager;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * A tree.
 *
 * Defaults:
 * - Tool tip manager will register this component
 * - The model is @c MTreeModel
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MTree<I extends MTreeItem, M extends MTreeModel<I>> extends JTree {

	// public
	
	/**
	 * @since 4.6
	 */
	public static final int AUTO_ROW_HEIGHT = -1;

	// public

	/**
	 * Constructs a new tree with @ref MTreeModel model.
	 */
	@SuppressWarnings("unchecked")
	public MTree() {
		this((M)new MTreeModel<I>());
	}

	/**
	 * Constructs a new tree.
	 * @param model A tree model
	 */
	public MTree(final M model) {
		super(model);
		ToolTipManager.sharedInstance().registerComponent(this);
		MCellTip.getInstance().install(this);

		StaticHandler handler = new StaticHandler();
		addKeyListener(handler);
		addMouseListener(handler);
		addMouseMotionListener(handler);
	}
	
	/**
	 * @since 4.2
	 */
	@SuppressWarnings("unchecked")
	public MTree(final I root) {
		this((M)new MTreeModel<I>(root));
	}

	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	@Obsolete
	public void focusItem(final I item) {
		if (item == null)
			return;

		new MTreeScanner<I>(getModel().getRootItem()) {
			@Override
			public void processItem(final I i) {
				if ((i != null) && ((i == item) || i.matches(item))) {
					selectItem(i, true);
					stop();
				}
			}
		};
	}

	/**
	 * (VIEW) Returns an item at @p location.
	 * @return {@code null} if no item under {@code location}
	 */
	public I getItemForLocation(final Point location) {
		if (location == null)
			return null;
		
		int row = getRowForLocation(location);

		if (row == -1)
			return null;

		I item = getItemAtRow(row);

		if (item == null)
			return null;

		return item;
	}

	/**
	 * (VIEW) Returns an item at row @p index, or @c null if no item at this index.
	 */
	@SuppressWarnings("unchecked")
	public I getItemAtRow(final int index) {
		TreePath path = getPathForRow(index);

		return (path == null) ? null : (I)path.getLastPathComponent();
	}

	/**
	 * (MODEL) Returns the model.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public M getModel() {
		return (M)super.getModel();
	}
	
	public int getRowForLocation(final Point p) {
		return getRowForLocation(p.x, p.y);
	}
	
	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	@SuppressWarnings("unchecked")
	public I getSelectedItem() {
		TreePath path = getSelectionPath();
		
		return (path == null) ? null : (I)path.getLastPathComponent();
	}
	
	/**
	 * (VIEW) Returns the selected items, or empty list if no selection.
	 * 
	 * @since 3.0
	 */
	@SuppressWarnings("unchecked")
	public List<I> getSelection() {
		TreePath[] selection = getSelectionPaths();

		if (TK.isEmpty(selection))
			return Collections.emptyList();

		if (selection.length == 1)
			return Collections.singletonList((I)selection[0].getLastPathComponent());

		MArrayList<I> result = new MArrayList<>(selection.length);
		for (TreePath i : selection)
			result.add((I)i.getLastPathComponent());
		
		return result;
	}
	
	@Override
	public Point getToolTipLocation(final MouseEvent e) {
		int row = getRowForLocation(e.getPoint());
		
		if (row == -1)
			return null;
		
		Rectangle r = getRowBounds(row);
		
		return new Point(r.x + 10, r.y + r.height + 10);
	}

	/**
	 * Returns @c true @p if row represents the drop location.
	 * See @c javax.swing.tree.TreeCellRenderer API documentation
	 * for more details.
	 */
	public boolean isDropZone(final int row) {
		JTree.DropLocation dropLocation = getDropLocation();
		
		return
			(dropLocation != null) &&
			(dropLocation.getChildIndex() == -1) &&
			(getRowForPath(dropLocation.getPath()) == row);
	}

	/**
	 * (VIEW)
	 */
	public boolean isExpanded(final I item) {
		return isExpanded(item.getTreePath());
	}

	/**
	 * (VIEW)
	 */
	public void setExpanded(final I item, final boolean state) {
		if (state)
			expandPath(item.getTreePath());
		else
			collapsePath(item.getTreePath());
	}

	/**
	 * (VIEW) Selects an item.
	 * @param item An item to select
	 * @param scroll If @c true scroll to @p item
	 */
	public void selectItem(final I item, final boolean scroll) {
		if (item != null) {
			TreePath path = item.getTreePath();
			setSelectionPath(path);
			if (scroll) {
				// NOTE: modified "scrollPathToVisible"
				makeVisible(path);
				Rectangle bounds = getPathBounds(path);
				MScrollPane.scrollToNextItem(this, bounds);

				if ((bounds != null) && (accessibleContext != null))
					accessibleContext.firePropertyChange(AccessibleContext.ACCESSIBLE_VISIBLE_DATA_PROPERTY, false, true);
				
				// HACK: invoke setSelectionPath twice to select previously collapsed node
				setSelectionPath(path);
			}
		}
	}
	
	/**
	 * (VIEW)
	 */
	public void repaint(final TreePath path) {
		if (path != null) {
			Rectangle r = getPathBounds(path);
			if (r != null)
				repaint(r);
		}
	}
	
	/**
	 * Sets "single selection mode".
	 * 
	 * @since 3.0
	 */
	public void setSingleSelectionMode() {
		getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
	}

	public void stopEditing(final boolean focusTree) {
		if (isEditing()) {
			stopEditing();
			if (focusTree)
				requestFocusInWindow();
		}
	}

	/**
	 * (VIEW) Toggles the @p item.
	 */
	public boolean toggleItem(final I item) {
		TreePath path = item.getTreePath();
		boolean result = isExpanded(path);
		
		if (result)
			collapsePath(path);
		else
			expandPath(path);
		
		return !result;
	}
	
	/**
	 * (VIEW)
	 * 
	 * @since 3.0
	 */
	public boolean toggleRow(final int row) {
		boolean result = isExpanded(row);
		if (result)
			collapseRow(row);
		else
			expandRow(row);
		
		return !result;
	}

	@Override
	public void updateUI() {
		if (UI.isQuaqua())
			putClientProperty("Quaqua.Tree.style", "striped");
		super.updateUI();
	}

	// protected
	
	/**
	 * @since 3.0
	 */
	protected MMenu createContextMenu() { return null; }
	
	/**
	 * @since 3.0
	 */
	protected void onAction(final InputEvent e, final int index) {
		toggleRow(index);
	}
	
	/**
	 * @since 3.0
	 */
	protected void popupContextMenu(final InputEvent e) {
		Point p;
		
		if (e != null) {
			p = MouseEvent.class.cast(e).getPoint();
			// select row under mouse
			int rowUnderMouse = getRowForLocation(p);
			if (!isRowSelected(rowUnderMouse))
				setSelectionRow(rowUnderMouse);
		}
		else {
			p = new Point();
		}
		
		popupContextMenu(p);
	}

	@Override
	protected void processKeyEvent(final KeyEvent e) {
		// HACK: VK_SPACE (character) pressed in the Tree is forwarded to the focused component (e.g. text editor)
		if ((e.getID() == KEY_PRESSED) && (TK.isKeyStroke(e, VK_ENTER)/* || TK.isKeyStroke(e, VK_SPACE)*/)) {
			openAtRow(e, getLeadSelectionRow());
			e.consume();
		}
		else {
			super.processKeyEvent(e);
		}
	}
	
	// private

	/**
	 * (VIEW)
	 */
	private void openAtRow(final InputEvent e, final int index) {
		if (index == -1) {
			// do not clear selection on "+/-" click
			if (e instanceof MouseEvent)
				return;
				
			clearSelection();
		}
		else {
			onAction(e, index);
		}
	}

	private void popupContextMenu(final Point p) {
		if (!isSelectionEmpty()) {
			MMenu menu = createContextMenu();
			if (menu != null)
				menu.showPopup(this, p);
		}
	}
	
	// private classes

	private static final class StaticHandler extends MMouseAdapter implements KeyListener {

		// public

		@Override
		public void keyPressed(final KeyEvent e) {
			if (UI.isPopupTrigger(e)) {
				MTree<?, ?> tree = (MTree<?, ?>)e.getSource();

				Point p = new Point();
				
				TreePath selection = tree.getLeadSelectionPath();
				if (selection != null) {
					Rectangle r = tree.getPathBounds(selection);
					if (r != null) {
						// NOTE: copied from getToolTipLocation
						p.x = r.x + 10;
						p.y = r.y + 10;
					}
				}
				
				tree.popupContextMenu(p);
			}
		}

		@Override
		public void keyTyped(final KeyEvent e) { }

		@Override
		public void keyReleased(final KeyEvent e) { }

		@Override
		public void buttonClicked/*mouseClicked*/(final MouseEvent e) {
			if (
				(MAction.isTrigger(e) || isMiddle(e)) &&
				// ctrl, shift - selection mode
				!e.isControlDown() && !e.isShiftDown()
			) {
				e.consume();
				MTree<?, ?> tree = (MTree<?, ?>)e.getSource();
				tree.openAtRow(e, tree.getRowForLocation(e.getPoint()));
			}
		}

		@Override
		public void mouseMoved(final MouseEvent e) {
			MTree<?, ?> tree = (MTree<?, ?>)e.getSource();
			int row = tree.getRowForLocation(e.getPoint());
			TreeCellRenderer r = tree.getCellRenderer();
			if (r instanceof MRenderer<?>) {
				MRenderer<?> mr = (MRenderer<?>)r;
				mr.setMouseHover(tree, tree.getPathForRow(row));
			}
			tree.setCursor(Cursor.getPredefinedCursor((row != -1) ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
		}

		@Override
		public void popupTrigger(final MouseEvent e) {
			MTree<?, ?> tree = (MTree<?, ?>)e.getSource();
			tree.popupContextMenu(e);
		}

	}

}
