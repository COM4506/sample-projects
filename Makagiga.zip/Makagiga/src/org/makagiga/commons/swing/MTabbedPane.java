// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.plaf.ButtonUI;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

import org.makagiga.commons.AbstractIterator;
import org.makagiga.commons.Attributes;
import org.makagiga.commons.Config;
import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.border.MLineBorder;

/**
 * A tabbed pane.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTabbedPane<T extends JComponent> extends JTabbedPane
implements
	Config.IntRange,
	Iterable<T>,
	MouseWheelListener
{

	// private

	private boolean movingTabs;
	private boolean reorderingAllowed;
	private static Insets oldInsets;
	private Insets currentBorderContentInsets;
	private PaintShortcutTimer paintShortcutTimer;
	
	// public

	/**
	 * Constructs a tabbed pane.
	 */
	public MTabbedPane() {
		addMouseWheelListener(this);
		setDropTarget(new TabDropTarget());
	}

	/**
	 * @since 3.8.8
	 */
	public void addTab(final MTab tab) {
		addTab(tab.tabTitle, tab);
		tab.tabTitle = null;
	}

	/**
	 * @since 3.8
	 */
	public void addTab(final String title, final T tab) {
		super.addTab(title, tab);
	}

	/**
	 * @since 3.8
	 */
	public void addTab(final String title, final Icon icon, final T tab) {
		super.addTab(title, icon, tab);
	}

	/**
	 * Adds a new tab.
	 * @param title A title
	 * @param iconName An icon name
	 * @param tab A component
	 */
	public void addTab(final String title, final String iconName, final T tab) {
		addTab(title, MIcon.stock(iconName), tab);
	}

	/**
	 * Adds a @c null tab.
	 * @param title A title
	 * @param iconName An icon name
	 */
	public void addTab(final String title, final String iconName) {
		addTab(title, MIcon.stock(iconName), null);
	}
	
	/**
	 * Returns the selected tab, or @c null if no selection.
	 */
	@SuppressWarnings("unchecked")
	public T getSelectedTab() {
		return (T)getSelectedComponent();
	}

	/**
	 * Returns tab at @p index, or @c null if no tab at that index.
	 */
	@SuppressWarnings("unchecked")
	public T getTabAt(final int index) {
		try {
			return (T)getComponentAt(index);
		}
		catch (IndexOutOfBoundsException exception) { // quiet
			return null;
		}
	}

	/**
	 * @deprecated As of 3.8, replaced by @ref setTabAt(final int, final T)
	 */
	@Deprecated
	@Override
	public void setComponentAt(final int index, final Component c) {
		super.setComponentAt(index, c);
	}

	/**
	 * @since 3.8
	 */
	public void setTabAt(final int index, final T tab) {
		super.setComponentAt(index, tab);
	}

	public int indexAtLocation(final Point p) {
		return indexAtLocation(p.x, p.y);
	}

	/**
	 * @since 3.8
	 */
	public void insertTab(final String title, final Icon icon, final T tab, final int index) {
		super.insertTab(title, icon, tab, null, index);
	}

	/**
	 * Returns @c true if no tabs.
	 */
	public boolean isEmpty() {
		return getTabCount() == 0;
	}

	/**
	 * @since 4.8
	 */
	public boolean isReorderingAllowed() { return reorderingAllowed; }

	/**
	 * @since 4.8
	 */
	public void setReorderingAllowed(final boolean value) { reorderingAllowed = value; }

	public boolean isTabHeaderVisible() {
		return !(ui instanceof HiddenTabsUI);
	}
	
	public void setTabHeaderVisible(final boolean value) {
		if (value) {
			if (currentBorderContentInsets != null)
				setBorderContentInsets(currentBorderContentInsets);
			updateUI(); // reset UI
			if (currentBorderContentInsets != null)
				restoreBorderContentInsets();
		}
		else {
			if (ui instanceof HiddenTabsUI)
				return;
			
			setUI(new HiddenTabsUI());
		}
	}

	/**
	 * Returns the iterator.
	 */
	@Override
	public Iterator<T> iterator() {
		if (isEmpty())
			return Collections.emptyIterator();
	
		return new AbstractIterator<>(getTabCount(), this::getTabAt);
	}

	/**
	 * A mouse wheel event handler.
	 * It selects the next/previous tab.
	 * @param e A mouse wheel event
	 */
	@Override
	public void mouseWheelMoved(final MouseWheelEvent e) {
		int index = indexAtLocation(e.getPoint());
		
		if (index == -1)
			return;

		if (e.getWheelRotation() < 0)
			selectPreviousTab();
		else
			selectNextTab();
		
		e.consume();
	}

	@Override
	public void setTabLayoutPolicy(final int tlp) {
		// HACK: A03: custom tab components are not supported
		//       GTK: NPE bug in older versions (?)
		super.setTabLayoutPolicy(
			(tlp == SCROLL_TAB_LAYOUT) && (UI.isA03() || UI.isGTK())
			? WRAP_TAB_LAYOUT
			: tlp
		);
	}

	/**
	 * @mg.note This overriden method will automatically force {@code TOP} placement
	 * if the <code>LEFT/RIGHT</code> placement is not correctly supported
	 * by the current Look And Feel.
	 *
	 * @param tp the tab placement
	 */
	@Override
	public void setTabPlacement(final int tp) {
		if (UI.isA03()) {
			super.setTabPlacement(TOP);
		}
		else if (UI.isSubstance() && ((tp == LEFT) || (tp == RIGHT))) {
			super.setTabPlacement(TOP);
		}
		else {
			super.setTabPlacement(tp);
		}
	}

	// Config.IntRange

	/**
	 * @since 3.0
	 */
	@Override
	public Config.IntInfo getIntInfo() {
		return new Config.IntInfo(0, getTabCount() - 1);
	}
	
	// protected

	/**
	 * CREDITS: http://www.jroller.com/page/santhosh?entry=get_rid_of_ugly_jtabbedpane
	 */
	protected static Insets createBorderContentInsetsForPlacement(final int placement) {
		final int SIZE = 4;
		switch (placement) {
			case LEFT: return new Insets(0, SIZE, 0, 0);
			case RIGHT: return new Insets(0, 0, 0, SIZE);
			case TOP: return new Insets(SIZE, 0, 0, 0);
			case BOTTOM: return new Insets(0, 0, SIZE, 0);
			default: throw new IllegalArgumentException("Invalid \"placement\" value: " + placement);
		}
	}
	
	@Override
	protected void fireStateChanged() {
		try {
			if (!movingTabs)
				super.fireStateChanged();
		}
		// HACK: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=7075600
		catch (IllegalArgumentException exception) {
			MLogger.developerException(exception);
		}
	}
	
	/**
	 * @since 4.8
	 */
	protected void onAfterTabMove(final int from, final int to) { }

	/**
	 * @since 4.8
	 */
	protected void onBeforeTabMove(final int from, final int to) { }

	@Override
	protected boolean processKeyBinding(final KeyStroke ks, final KeyEvent e, final int condition, final boolean pressed) {
		if (pressed && (condition == WHEN_FOCUSED)) {
			if (TK.isKeyStroke(e, VK_LEFT, CTRL_MASK))
				moveTab(false);
			else if (TK.isKeyStroke(e, VK_RIGHT, CTRL_MASK))
				moveTab(true);
		}

		if (e.getKeyCode() == VK_ALT) {
			if (paintShortcutTimer == null)
				paintShortcutTimer = new PaintShortcutTimer();
			paintShortcutTimer.setAltPressed(pressed);
		}

		return super.processKeyBinding(ks, e, condition, pressed);
	}

	protected synchronized void restoreBorderContentInsets() {
		if (!UI.isMetal())
			return;
		
		Insets insets = (Insets)UIManager.get("TabbedPane.contentBorderInsets");
		if (insets != null)
			currentBorderContentInsets = (Insets)insets.clone();
		synchronized (MTabbedPane.class) {
			if (oldInsets != null)
				UIManager.put("TabbedPane.contentBorderInsets", oldInsets);
		}
	}

	protected synchronized static void setBorderContentInsets(final Insets value) {
		if (!UI.isMetal())
			return;

		oldInsets = UIManager.getInsets("TabbedPane.contentBorderInsets");
		UIManager.put("TabbedPane.contentBorderInsets", value);
	}

	// private
	
	private void moveTab(final boolean right) {
		if (!isReorderingAllowed() || !isFocusOwner())
			return;
	
		int currentIndex = getSelectedIndex();
		Component currentComponent = getTabAt(currentIndex);

		if ((currentComponent instanceof MTab) && !MTab.class.cast(currentComponent).isReorderingAllowed())
			return;
		
		int targetIndex = right ? (currentIndex + 1) : (currentIndex - 1);

		if ((targetIndex < 0) || (targetIndex > getTabCount() - 1))
			return;

		Component targetComponent = getTabAt(targetIndex);

		if ((targetComponent instanceof MTab) && !MTab.class.cast(targetComponent).isReorderingAllowed())
			return;

		try {
			movingTabs = true;
			
			onBeforeTabMove(currentIndex, targetIndex);
			onBeforeTabMove(targetIndex, currentIndex);
			
			if (right) {
				Attributes<String, Object> targetAttr = removeTabAndGetAttr(targetIndex);
				Attributes<String, Object> currentAttr = removeTabAndGetAttr(currentIndex);
				moveTab(targetComponent, targetIndex, currentIndex, targetAttr);
				moveTab(currentComponent, currentIndex, targetIndex, currentAttr);
			}
			else {
				Attributes<String, Object> currentAttr = removeTabAndGetAttr(currentIndex);
				Attributes<String, Object> targetAttr = removeTabAndGetAttr(targetIndex);
				moveTab(currentComponent, currentIndex, targetIndex, currentAttr);
				moveTab(targetComponent, targetIndex, currentIndex, targetAttr);
			}

			movingTabs = false;
			setSelectedIndex(targetIndex);
			requestFocusInWindow();
		}
		finally {
			movingTabs = false;
		}
		
	}
	
	private void moveTab(final Component c, final int from, final int to, final Attributes<String, Object> attr) {
		insertTab(
			(String)attr.get("title"),
			(Icon)attr.get("icon"),
			c,
			(String)attr.get("toolTipText"),
			to
		);
		
		// restore saved tab properties
		setBackgroundAt(to, (Color)attr.get("background"));
		setDisabledIconAt(to, (Icon)attr.get("disabledIcon"));
		setDisplayedMnemonicIndexAt(to, (Integer)attr.get("displayedMnemonicIndex"));
		setEnabledAt(to, (Boolean)attr.get("enabled"));
		setForegroundAt(to, (Color)attr.get("foreground"));
		setMnemonicAt(to, (Integer)attr.get("mnemonic"));
		
		onAfterTabMove(from, to);
	}
	
	private Attributes<String, Object> removeTabAndGetAttr(final int i) {
		// remember tab properties before remove
		Attributes<String, Object> attr = new Attributes<>();
		attr.set("background", getBackgroundAt(i));
		attr.set("disabledIcon", getDisabledIconAt(i));
		attr.set("displayedMnemonicIndex", getDisplayedMnemonicIndexAt(i));
		attr.set("enabled", isEnabledAt(i));
		attr.set("foreground", getForegroundAt(i));
		attr.set("icon", getIconAt(i));
		attr.set("mnemonic", getMnemonicAt(i));
		attr.set("title", getTitleAt(i));
		attr.set("toolTipText", getToolTipTextAt(i));
		
		removeTabAt(i);
	
		return attr;
	}

	private void selectNextTab() {
		int count = getTabCount();

		if (count < 2)
			return;

		int current = getSelectedIndex();
		if (current == -1)
			current = 0;

		int index = current + 1;
		while (true) {
			if (index > count - 1)
				index = 0;

			if (index == current)
				return;

			if (isEnabledAt(index))
				break; // while

			index++;
		}
		setSelectedIndex(index);
	}

	private void selectPreviousTab() {
		int count = getTabCount();

		if (count < 2)
			return;

		int current = getSelectedIndex();
		if (current == -1)
			current = 0;

		int index = current - 1;
		while (true) {
			if (index < 0)
				index = count - 1;

			if (index == current)
				return;

			if (isEnabledAt(index))
				break; // while

			index--;
		}
		setSelectedIndex(index);
	}
	
	// public classes
	
	/**
	 * @since 3.0
	 */
	public static class TabComponent extends MPanel {

		// private

		private final MLabel text;
		private MLineBorder.Style colorStyle;
		private String paintShortcut;
		private final TabIcon icon;
		private final WeakReference<MTabbedPane<?>> tabs;

		// public

		public TabComponent(final MTabbedPane<?> tabs) {
			super(5, 5);
			this.tabs = new WeakReference<>(tabs);
			setColorPosition(MLineBorder.Position.TOP);
			setOpaque(false);

			icon = new TabIcon(this);
			addWest(icon);

			text = new MLabel();
			for (MouseListener i : text.getMouseListeners())
				text.removeMouseListener(i);
			addCenter(text);
		}

		@Override
		public Dimension getPreferredSize() {
			Dimension d = super.getPreferredSize();
			
			MTabbedPane<?> t = tabs.get();

			if (t == null)
				return d;

			boolean compactWidth = (t.getTabCount() > 5);
			int minWidth = compactWidth ? 50 : 100;
			int maxWidth = compactWidth ? 150 : 200;

			return new Dimension(TK.limit(d.width, minWidth, maxWidth), d.height);
		}

		/**
		 * @since 3.8.7
		 */
		public TabIcon getTabIcon() { return icon; }

		/**
		 * @since 3.4
		 */
		public MLabel getTextLabel() { return text; }

		@Override
		public void paint(final Graphics _graphics) {
			MTabbedPane<?> t = tabs.get();
			if ((t != null) && t.isTabHeaderVisible()) {
				super.paint(_graphics);

				if (paintShortcut != null) {
					MGraphics2D g = MGraphics2D.copy(_graphics);
					
					g.setAntialiasing(true);
					g.setFont(UI.deriveFontStyle(UI.getFont(this), Font.BOLD));
					g.setTextAntialiasing(null);

					g.setColor(new Color(50, 50, 50, 180));
					int padding = 5;
					FontMetrics fm = g.getFontMetrics();
					int x = 0;
					int y = 0;
					int w = fm.stringWidth(paintShortcut);
					int h = getHeight();
					g.fillRoundRect(x, y, w + (padding * 2), h, 16);

					g.setColor(Color.WHITE);
					g.drawString(
						paintShortcut,
						x + padding,
						y + (h / 2) - (fm.getHeight() / 2) + fm.getAscent()
					);

					g.dispose();
				}
			}
		}

		/**
		 * @since 3.8.7
		 */
		public void setColor(final Color color) {
			if ((colorStyle != null) && !Objects.equals(colorStyle.getColor(), color)) {
				colorStyle.setColor(color);
				repaint();
			}
		}

		/**
		 * @since 4.4
		 */
		public void setColorPosition(final MLineBorder.Position value) {
			MLineBorder border = new MLineBorder(value);
			colorStyle = border.getStyle(value);
			colorStyle.setColor(null);
			colorStyle.setSize(((value == MLineBorder.Position.TOP) || (value == MLineBorder.Position.BOTTOM)) ? 2 : 3);
			setBorder(border);
		}

		public void setIcon(final Icon value) {
			icon.setIcon(value);
		}

		public void setText(final String value) {
			text.setText(value);
		}

		// protected
		
		protected int getIndex() {
			MTabbedPane<?> t = tabs.get();
			
			return (t == null) ? -1 : t.indexOfTabComponent(this);
		}
		
		protected void onClick() { }

		// private

		private void setPaintShortcut(final String value) {
			if (!Objects.equals(value, paintShortcut)) {
				paintShortcut = value;
				repaint();
			}
		}

	}
	
	/**
	 * @since 3.0
	 */
	public static class TabIcon extends MButton {

		// private

		private final TabComponent tabComponent;

		// public

		public TabIcon(final TabComponent tabComponent) {
			this.tabComponent = Objects.requireNonNull(tabComponent);
			setBorder(BorderFactory.createEmptyBorder(1, 5, 1, 5));
			setContentAreaFilled(false);
			setFocusable(false);
			setOpaque(false);
			setRolloverEffectEnabled(false);
			setToolTipText(i18n("Close"));
			setSafeAction(true);
		}

		@Override
		public void updateUI() {
			setUI((ButtonUI)BasicButtonUI.createUI(this));
		}

		// protected

		@Override
		protected final void onClick() {
			tabComponent.onClick();
		}

	}
	
	// private classes
	
	private static final class HiddenTabsUI extends BasicTabbedPaneUI {
		
		// protected

		@Override
		protected int calculateMaxTabHeight(final int tabPlacement) {
			return 0;
		}

		@Override
		protected int calculateTabAreaHeight(final int tabPlacement, final int horizRunCount, final int maxTabWidth) {
			return 0;
		}
		
		@Override
		protected int calculateTabHeight(final int tabPlacement, final int tabIndex, final int fontHeight) {
			return 0;
		}

		@Override
		protected int calculateTabWidth(final int tabPlacement, final int tabIndex, final FontMetrics metrics) {
			return 0;
		}

		@Override
		protected Insets getContentBorderInsets(final int tabPlacement) {
			return UI.createInsets(0);
		}

		@Override
		protected Insets getSelectedTabPadInsets(final int tabPlacement) {
			return UI.createInsets(0);
		}

		@Override
		protected Insets getTabAreaInsets(final int tabPlacement) {
			return UI.createInsets(0);
		}

		@Override
		protected Insets getTabInsets(final int tabPlacement, final int tabIndex) {
			return UI.createInsets(0);
		}

	}

	private final class PaintShortcutTimer extends MTimer {

		// private
		
		private int tick;

		// protected
		
		protected PaintShortcutTimer() {
			super(TimeUnit.MILLISECONDS, 500);
		}

		@Override
		protected boolean onTimeout() {
			switch(++this.tick) {
				case 1: return this.setShortcutVisible(true);
				case 5: return this.setShortcutVisible(false);
				default: return MTimer.CONTINUE;
			}
		}

		protected void setAltPressed(final boolean pressed) {
			if (pressed) {
				this.tick = 0;
				this.restart();
			}
			else {
				this.stop();
				this.setShortcutVisible(false);
			}
		}

		// private
		
		private boolean setShortcutVisible(final boolean visible) {
			int[] keys = Mnemonic.getTabKeys();
			int count = Math.min(keys.length, MTabbedPane.this.getTabCount());

			if (visible && (count < 4))
				return MTimer.STOP;

			for (int index = 0; index < count; index++) {
				final int i = index;
				TK.safeCast(MTabbedPane.this.getTabComponentAt(i), TabComponent.class)
					.ifPresent(tc -> {
						if (visible)
							tc.setPaintShortcut(UI.toString(keys[i], (i == 0) ? ALT_MASK : 0));
						else
							tc.setPaintShortcut(null);
					} );
			}
			
			return visible;
		}

	}

	private static final class TabDropTarget extends DropTarget {

		// public

		@Override
		public synchronized void dragEnter(final DropTargetDragEvent e) {
			super.dragEnter(e);
			doSelectTab(e);
		}
		
		@Override
		public synchronized void dragOver(final DropTargetDragEvent e) {
			super.dragOver(e);
			doSelectTab(e);
		}

		// private

		private TabDropTarget() { }

		private void doSelectTab(final DropTargetDragEvent e) {
			// select a tab under mouse cursor
			MTabbedPane<?> tabs = (MTabbedPane<?>)getComponent();
			int i = tabs.indexAtLocation(e.getLocation());
			if ((i != -1) && (tabs.getSelectedIndex() != i))
				tabs.setSelectedIndex(i);

			e.rejectDrag();
		}

	}

}
