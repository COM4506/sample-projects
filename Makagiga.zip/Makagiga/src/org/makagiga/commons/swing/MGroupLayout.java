// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.util.Collection;
import java.util.Stack;
import javax.swing.Box;
import javax.swing.GroupLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;

import org.makagiga.commons.MArrayList;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.DesignPattern;

/**
 * A human readable {@code javax.swing.GroupLayout}.
 *
 * @mg.screenshot
 * <img alt="MGroupLayout example" src="../doc-files/MGroupLayout.png">
 *
 * @mg.example
 * Based on
 * <a href="http://weblogs.java.net/blog/2006/10/11/layout-manager-showdown">Layout Manager Showdown</a> "Address Book Demo".
 *
 * <pre class="brush: java">
// ...
MGroupLayout l = new MGroupLayout(container, true);
l.setAutoCreateContainerGaps(true);
Dimension listMaxSize = new Dimension(MGroupLayout.PREFERRED_SIZE, MGroupLayout.DEFAULT_SIZE);
l

	// left column (list)

	.addComponent(new MScrollPane(list), null, null, listMaxSize)

	// right column (text fields)

	.beginRows()
		.beginColumns()
			.addComponent(lastName, "Last Name")
			.addComponent(firstName, "First Name")
		.end()
		.beginColumns()
			.addComponent(phone, "Phone")
			.addComponent(email, "Email")
		.end()
		.beginColumns()
			.addComponent(address1, "Address 1")
		.end()
		.beginColumns()
			.addComponent(address2, "Address 2")
		.end()
		.beginColumns()
			.addComponent(city, "City")
		.end()
		.beginColumns()
			.addComponent(state, "State")
			.addComponent(postalCode, "Postal Code")
		.end()
		.beginColumns()
			.addComponent(country, "Country")
		.end()
		.addContentGap()
		.beginColumns()
			.addComponent(new MButton("New"))
			.addComponent(new MButton("Delete"))
			.addComponent(new MButton("Edit"))
			.addComponent(new MButton("Save"))
			.addComponent(new MButton("Cancel"))
		.end()
	.end()
;
// equal text field and label widths
l.linkSize(lastName, phone, city, state, country);
l.linkLabelSize(lastName, address1, address2, phone, city, state, country);
// ...
 * </pre>
 *
 * @see <a href="http://madbean.com/anim/totallygridbag/">Totally Gridbag</a>
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing.MGroupLayout name)
 */
@DesignPattern(DesignPattern.BUILDER)
public class MGroupLayout extends GroupLayout {
	
	// private

	private static final Dimension DEFAULT = new Dimension(DEFAULT_SIZE, DEFAULT_SIZE);
	private enum AddOrientation { HORIZONTAL, VERTICAL }
	private final Stack<AddOrientation> addOrientationStack = new Stack<>();
	private final Stack<Group> hStack = new Stack<>();
	private final Stack<Group> vStack = new Stack<>();
	
	// public

/*
	public static void main(final String... args) {
		UI.invokeLater(new Runnable() {
			@Override
			public void run() {

				// Set Nimbus Look And Feel...

				MFrame f = new MFrame("Test");
				f.setDefaultCloseOperation(MFrame.EXIT_ON_CLOSE);

				MList<String> list = new MList<>();
				list.addAllItems(
					"Bugs Bunny", "Sylvester Cat", "Wile  Coyote",
					"Tasmanian Devil", "Daffy Duck", "Elmer Fudd",
					"Pepe Le Pew", "Marvin Martian"
				);

				MTextField lastName = new MTextField("Martian");
				lastName.setPreferredSize(new Dimension(150, 10));
				MTextField firstName = new MTextField("Marvin");
				MTextField phone = new MTextField("805-123-4567");
				MTextField email = new MTextField("marvin@wb.com");
				MTextField address1 = new MTextField("foo");
				MTextField address2 = new MTextField("bar");
				MTextField city = new MTextField("Ventura");
				MTextField state = new MTextField("CA");
				MTextField postalCode = new MTextField("93001");
				MTextField country = new MTextField("");

				MGroupLayout l = new MGroupLayout(f.getContentPane(), true);
				l.setAutoCreateContainerGaps(true);
				Dimension listMaxSize = new Dimension(MGroupLayout.PREFERRED_SIZE, MGroupLayout.DEFAULT_SIZE);
				l

					// left column (list)

					.addComponent(new MScrollPane(list), null, null, listMaxSize)

					// right column (text fields)

					.beginRows()
						.beginColumns()
							.addComponent(lastName, "Last Name")
							.addComponent(firstName, "First Name")
						.end()
						.beginColumns()
							.addComponent(phone, "Phone")
							.addComponent(email, "Email")
						.end()
						.beginColumns()
							.addComponent(address1, "Address 1")
						.end()
						.beginColumns()
							.addComponent(address2, "Address 2")
						.end()
						.beginColumns()
							.addComponent(city, "City")
						.end()
						.beginColumns()
							.addComponent(state, "State")
							.addComponent(postalCode, "Postal Code")
						.end()
						.beginColumns()
							.addComponent(country, "Country")
						.end()
						.addContentGap()
						.beginColumns()
							.addComponent(new MButton("New"))
							.addComponent(new MButton("Delete"))
							.addComponent(new MButton("Edit"))
							.addComponent(new MButton("Save"))
							.addComponent(new MButton("Cancel"))
						.end()
					.end()
				;
				// equal text field and label widths
				l.linkSize(lastName, phone, city, state, country);
				l.linkLabelSize(lastName, address1, address2, phone, city, state, country);

				f.setLayout(l);
				f.pack();
				f.setVisible(true);
			}
		} );
	}
*/

	/**
	 * @mg.example
	 * <pre class="brush: java">
	 * ...
	 * // a generic example
	 * JPanel panel = new JPanel();
	 * MGroupLayout layout = new MGroupLayout(panel, true);
	 * panel.setLayout(layout);
	 * ...
	 * // a shortcut
	 * MPanel panel = new MPanel();
	 * MGroupLayout layout = p.setGroupLayout(true);
	 * ...
	 * </pre>
	 *
	 * @param host the component for this layout
	 */
	public MGroupLayout(final Container host, final boolean autoCreatePadding) {
		super(host);
		if (autoCreatePadding)
			setAutoCreateGaps(autoCreatePadding);

		SequentialGroup hg = createSequentialGroup();
		setHorizontalGroup(hg);
		
		ParallelGroup vg = createParallelGroup();
		setVerticalGroup(vg);
		
		addOrientationStack.push(AddOrientation.HORIZONTAL);
		hStack.push(hg);
		vStack.push(vg);
	}

	/**
	 * @since 5.2
	 */
	public MGroupLayout addButtonGap() {
		return addGap(UI.getDialogButtonSpacing());
	}

	public MGroupLayout addComponent(final Component c) {
		getHGroup().addComponent(c);
		
		Group g = getVGroup();
		if (g instanceof ParallelGroup)
			ParallelGroup.class.cast(g).addComponent(c, Alignment.CENTER);
		else
			g.addComponent(c);
		
		return this;
	}

	/**
	 * @since 4.0
	 */
	public MGroupLayout addComponent(final Component c, final Alignment verticalAlignment) {
		getHGroup().addComponent(c);
		
		Group g = getVGroup();
		if (g instanceof ParallelGroup)
			ParallelGroup.class.cast(g).addComponent(c, verticalAlignment);
		else
			g.addComponent(c);
		
		return this;
	}

	/**
	 * @since 3.8.3
	 */
	public MGroupLayout addComponent(final Component c, Dimension min, Dimension pref, Dimension max) {
		if (min == null)
			min = DEFAULT;
		if (pref == null)
			pref = DEFAULT;
		if (max == null)
			max = DEFAULT;

		getHGroup().addComponent(c, min.width, pref.width, max.width);
		getVGroup().addComponent(c, min.height, pref.height, max.height);

		return this;
	}

	/**
	 * @since 2.4
	 */
	public MGroupLayout addComponent(final Component c, final String label) {
		switch (getAddOrientation()) {
			case HORIZONTAL:
				addComponent(MLabel.createFor(c, label, MLabel.TRAILING));
				if (!getAutoCreateGaps())
					addGap(MPanel.DEFAULT_CONTENT_MARGIN);
				addComponent(c);
				break;
			case VERTICAL:
				addComponent(MLabel.createFor(c, label));
				if (!getAutoCreateGaps())
					addGap();
				addComponent(c);
				break;
			default:
				throw new WTFError(getAddOrientation());
		}
		
		return this;
	}

	/**
	 * Adds a gap of size @ref MPanel.DEFAULT_CONTENT_MARGIN.
	 * 
	 * @since 2.4
	 */
	public MGroupLayout addContentGap() {
		return addGap(MPanel.DEFAULT_CONTENT_MARGIN);
	}

	public MGroupLayout addFixedComponent(final Component c, final Dimension size) {
		getHGroup().addComponent(c, size.width, size.width, size.width);
		
		Group g = getVGroup();
		if (g instanceof ParallelGroup)
			ParallelGroup.class.cast(g).addComponent(c, Alignment.CENTER, size.height, size.height, size.height);
		else
			g.addComponent(c, size.height, size.height, size.height);
		
		return this;
	}

	/**
	 * Adds a gap of size @c 5.
	 * 
	 * @since 2.4
	 */
	public MGroupLayout addGap() {
		return addGap(5);
	}

	/**
	 * Adds a gap of the specified @p size.
	 * 
	 * @since 2.4
	 */
	public MGroupLayout addGap(final int size) {
		switch (getAddOrientation()) {
			case HORIZONTAL:
				getHGroup().addGap(size);

				return this;
			case VERTICAL:
				getVGroup().addGap(size);
				
				return this;
			default:
				throw new WTFError(getAddOrientation());
		}
	}
	
	/**
	 * @since 4.2
	 */
	public MGroupLayout addHeader(final String text) {
		MLabel l = new MLabel(text);
		l.setStyle(MPanel.HEADER_FONT_STYLE);
		addComponent(l);
		addGap(5);
		
		return this;
	}

	/**
	 * @since 5.2
	 */
	public MGroupLayout addHorizontalSeparator() {
		switch (getAddOrientation()) {
			case VERTICAL:
				addComponent(MSeparator.newHorizontalLine());

				return this;
			case HORIZONTAL:
				throw new IllegalStateException("Use beginRows() first");
			default:
				throw new WTFError(getAddOrientation());
		}
	}

	/**
	 * @since 3.8.3
	 */
	public MGroupLayout addHStretchComponent(final Component c) {
		getHGroup().addComponent(c, 1, 1, Integer.MAX_VALUE);
		Group g = getVGroup();
		if (g instanceof ParallelGroup)
			ParallelGroup.class.cast(g).addComponent(c, Alignment.CENTER);
		else
			g.addComponent(c);

		return this;
	}

	/**
	 * @since 5.4
	 */
	public MGroupLayout addLargeContentGap() {
		return addGap(MPanel.DEFAULT_CONTENT_MARGIN * 2);
	}

	/**
	 * @since 3.8.6
	 */
	public MGroupLayout addScrollable(final JComponent c) {
		return addScrollable(c, 0);
	}

	/**
	 * @since 3.8.6
	 */
	public MGroupLayout addScrollable(final JComponent c, final String label) {
		return addScrollable(c, 0, label);
	}

	/**
	 * @since 3.8.6
	 */
	public MGroupLayout addScrollable(final JComponent c, final int scrollPaneFlags) {
		if (UI.needScrollPane(c))
			return addComponent(new MScrollPane(c, scrollPaneFlags));

		return addComponent(c);
	}

	/**
	 * @since 3.8.6
	 */
	public MGroupLayout addScrollable(final JComponent c, final int scrollPaneFlags, final String label) {
		if (UI.needScrollPane(c))
			return addComponent(new MScrollPane(c, scrollPaneFlags), label);

		return addComponent(c, label);
	}

	/**
	 * Adds a horizontal or vertical separator.
	 * 
	 * @since 2.4
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public MGroupLayout addSeparator() {
		switch (getAddOrientation()) {
			case HORIZONTAL:
				addComponent(new MSeparator(MSeparator.VERTICAL));
				
				return this;
			case VERTICAL:
				addComponent(new MSeparator(MSeparator.HORIZONTAL));

				return this;
			default:
				throw new WTFError(getAddOrientation());
		}
	}

	/**
	 * @since 3.0
	 */
	public MGroupLayout addStretch() {
		switch (getAddOrientation()) {
			case HORIZONTAL:
				addComponent(Box.createHorizontalGlue());

				return this;
			case VERTICAL:
				addComponent(Box.createVerticalGlue());
				
				return this;
			default:
				throw new WTFError(getAddOrientation());
		}
	}

	public MGroupLayout beginColumns() {
		addOrientationStack.push(AddOrientation.HORIZONTAL);
		
		Group g;
		
		g = createSequentialGroup();
		getHGroup().addGroup(g);
		hStack.push(g);

		g = createParallelGroup();
		getVGroup().addGroup(g);
		vStack.push(g);

		return this;
	}

	public MGroupLayout beginRows() {
		return beginRows(false);
	}
	
	/**
	 * @since 3.0
	 */
	public MGroupLayout beginRows(final boolean hCenter) {
		addOrientationStack.push(AddOrientation.VERTICAL);
		
		Group g;
			
		if (hCenter)
			g = createParallelGroup(Alignment.CENTER);
		else
			g = createParallelGroup();
		getHGroup().addGroup(g);
		hStack.push(g);

		g = createSequentialGroup();
		getVGroup().addGroup(g);
		vStack.push(g);

		return this;
	}

	/**
	 * @since 2.4
	 */
	public MGroupLayout end() {
		addOrientationStack.pop();
		hStack.pop();
		vStack.pop();
		
		return this;
	}
	
	/**
	 * @since 3.8.3
	 */
	public MGroupLayout linkLabelSize(final Component... c) {
		MArrayList<Component> labels = new MArrayList<>(c.length);
		for (Component i : c) {
			if (i instanceof JComponent) {
				JLabel l = MLabel.getLabel((JComponent)i);
				if (l != null)
					labels.add(l);
				else if (i instanceof JLabel)
					labels.add(i);
			}
		}
		linkSize(labels.toArray(Component.class));
		
		return this;
	}

	/**
	 * @since 5.0
	 */
	public MGroupLayout linkLabelSize(final Collection<? extends Component> c) {
		if (!c.isEmpty())
			linkLabelSize(c.toArray(new Component[c.size()]));
		
		return this;
	}

	// private
	
	private AddOrientation getAddOrientation() {
		return addOrientationStack.peek();
	}
	
	private Group getHGroup() {
		return hStack.peek();
	}

	private Group getVGroup() {
		return vStack.peek();
	}

}
