// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.lang.ref.SoftReference;
import java.net.URI;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.swing.Icon;

import org.makagiga.commons.Config;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.MStringBuilder;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.security.MAccessController;

// TODO: font chooser, details,
//       optimize MArrayList initial size, search example, better tool tips, copy to clipboard (Ctrl+C),
//       option to clear recent items, optimize label view?, filter by single char/codepoint,
//       search autocompletion, drag & drop, copy as hex, OK -> Insert, redesign text context menu,
//       remember last Category, sort Category list, show warning if font can't display a character

/**
 * @since 5.2
 */
public class MCharacterChooser extends MPanel
implements
	Focusable,
	MDisposable,
	// use "Integer" instead of "Character" to support code points larger than 0xffff
	ValueChooser<Integer>
{

	// private
	
	private Block filterBlock;
	private Block recentItemsBlock;
	private Block starredItemsBlock;
	private static int lastCodePoint = -1;
	private boolean eventsEnabled;
	private int value = -1;
	private MList<Block> blockList;
	private MSearchPanel searchPanel;
	private static SoftReference<Unicode> unicodeRef;
	private Unicode unicode;
	
	// package
	
	MList<Char> charListView;

	// public
	
	public MCharacterChooser(final Font characterFont) {
		super(true);

		unicode = getUnicode();

		// init special blocks

		filterBlock = new Block("(" + i18n("Search Results") + ")");
		recentItemsBlock = new Block("(" + MActionInfo.HISTORY + ")");
		starredItemsBlock = new Block("(" + MActionInfo.SHOW_STARRED + ")");
		readConfig();

		// init "Category" list

		blockList = new MList<Block>() {
			@Override
			public Dimension getPreferredSize() {
				Dimension d = super.getPreferredSize();
				
				return new Dimension(200, d.height);
			}
		};
		blockList.setSingleSelectionMode();

		blockList.addItem(starredItemsBlock);
		blockList.addItem(recentItemsBlock);
		blockList.addItem(filterBlock);
		blockList.addAllItems(unicode.blockList);

		MRenderer<Block> blockRenderer = new MRenderer<>((renderer, item) -> {
			String text = item.toString();
			renderer.setText(text);
			renderer.setToolTipText(text);

			Icon icon;
			if (item == filterBlock)
				icon = ShapeIcon.SEARCH;
			else if (item == recentItemsBlock)
				icon = MActionInfo.HISTORY.getSmallIcon();
			else if (item == starredItemsBlock)
				icon = MActionInfo.SHOW_STARRED.getSmallIcon();
			else
				icon = null;
			renderer.setIcon(icon);
		} );
		blockList.setCellRenderer(blockRenderer);

		blockList.onSelect(self -> {
			if (eventsEnabled)
				showBlock(self.getSelectedItem(), -1);
		} );

		// init character list view

		charListView = new MList<>();
		Font baseFont = (characterFont != null) ? characterFont : UI.getFont(charListView);
		charListView.setFont(UI.deriveFontSize(baseFont, 24));
		charListView.setLayoutOrientation(MList.HORIZONTAL_WRAP);
		charListView.setSingleSelectionMode();
		charListView.setVisibleRowCount(-1); // for HORIZONTAL_WRAP

		// init info panel

		InfoPanel infoPanel = new InfoPanel();
		infoPanel.charViewLabel.setFont(UI.deriveFontSize(baseFont, 128));

		charListView.addActionListener(e -> {
			if (charListView.getActionType() == MList.ActionType.ITEM_POPUP_MENU) {
				Char selectedChar = charListView.getSelectedItem();
		
				if (selectedChar == null)
					return;
		
				MMenu menu = new MMenu();
/*
				menu.add(new MAction(i18n("Copy Name"), "ui/copy", action -> {
					try {
						String name = fontName.getSelectedItem();
						if (name != null)
							MClipboard.setString(name);
					}
					catch (ClipboardException exception) {
						action.showErrorMessage(exception);
					}
				} ));
*/
// TODO: common code
				boolean isStar = starredItemsBlock.charList.contains(selectedChar);
				MAction toggleStarAction = new MAction(self -> {
					if (isStar)
						starredItemsBlock.charList.remove(selectedChar);
					else
						starredItemsBlock.charList.add(selectedChar);
				} );
				toggleStarAction.setName((isStar ? MActionInfo.REMOVE_STAR : MActionInfo.ADD_STAR).getText());
				toggleStarAction.setSmallIcon(isStar ? "ui/remove" : "ui/add");
				menu.add(toggleStarAction);

				menu.showPopup(charListView.getActionEvent());
			}
		} );

		charListView.onSelect(self -> {
			Char selection = charListView.getSelectedItem();

			infoPanel.update(selection);

			if ((selection != null) && eventsEnabled && (selection.codePoint != value)) {
				int oldValue = value;
				value = selection.codePoint;
				TK.fireValueChanged(this, getValueListeners(), oldValue, value);
				
				lastCodePoint = selection.codePoint;
				
				if (blockList.getSelectedItem() != recentItemsBlock)
					recentItemsBlock.charList.add(selection);
			}
		} );

		// trigger "OK" press in parent dialog on Enter/Double-Click
		charListView.onTrigger((self, item) -> {
			getDialog()
				.ifPresent(MDialog::accept);
		} );

		MRenderer<Char> charRenderer = new MRenderer<>((renderer, item) -> {
			MLabel label = renderer.getLabel();

			// highlight starred items
			if (!renderer.isSelected() && starredItemsBlock.charList.contains(item)) {
				label.setBackground(MHighlighter.SEARCH_COLOR);
				label.setForeground(MColor.getContrastBW(MHighlighter.SEARCH_COLOR));
				label.setOpaque(true);
			}

			label.setHorizontalAlignment(UI.CENTER);
			renderer.setText(item.toString());
			renderer.setToolTipText(item.getToolTipText());
		} );
		charRenderer.setUseAlternateRowColor(false);

		charListView.setCellRenderer(charRenderer, new Char((int)'x'));
		charListView.setFixedCellHeight(UI.getFont(charListView).getSize() + 10);
		charListView.setFixedCellWidth((int)(charListView.getFixedCellHeight() * 1.5f));

		// init search panel

		searchPanel = new MSearchPanel();
		searchPanel.setChangeEventDelay(500);
		searchPanel.setList(charListView);
		searchPanel.onChange(e -> doFilter(searchPanel.getText()));

		Dimension blockListMaxSize = new Dimension(MGroupLayout.PREFERRED_SIZE, MGroupLayout.DEFAULT_SIZE);
		Dimension infoPanelMinSize = new Dimension(200, MGroupLayout.DEFAULT_SIZE);

		getGroupLayout()
			.beginRows()
				.addComponent(searchPanel)
				.addContentGap()
				.beginColumns()
					.beginRows()
						.addComponent(MLabel.createFor(blockList, i18n("Category:")))
						.addComponent(new MScrollPane(blockList), null, null, blockListMaxSize)
					.end()
					.addContentGap()
					.beginRows()
						.addScrollable(charListView, i18n("Characters:"))
					.end()
				.end()
			.end()
			.addContentGap()
			.addComponent(infoPanel, infoPanelMinSize, null, null);

		// select recently used character

		Block lastBlock = null;
		Optional<Char> lastChar = Optional.empty();
		if (lastCodePoint != -1) {
			for (Block i : unicode.blockList) {
				if ((lastCodePoint >= i.start) && (lastCodePoint <= i.end)) {
					lastBlock = i;
					lastChar = i.charList
						.stream()
						.filter(c -> c.codePoint == lastCodePoint)
						.findFirst();
					
					break; // for
				}
			}
		}

		if (lastChar.isPresent())
			showBlock(lastBlock, lastChar.get().codePoint);
		else
			showBlock(unicode.blockList.getFirst(), -1);

		eventsEnabled = true;
	}

	// Focusable
	
	@Override
	public void focus() {
		blockList.requestFocusInWindow();
	}

	// MDisposable
	
	@Override
	public void dispose() {
		filterBlock = null;
		recentItemsBlock = null;
		starredItemsBlock = null;
		blockList = null;
		searchPanel = null;
		unicode = null;
		charListView = null;
	}

	// ValueChooser

	@Override
	public void addValueListener(final ValueListener<Integer> l) {
		listenerList.add(ValueListener.class, l);
	}

	@Override
	public void removeValueListener(final ValueListener<Integer> l) {
		listenerList.remove(ValueListener.class, l);
	}

	@Override
	@SuppressWarnings("unchecked")
	public ValueListener<Integer>[] getValueListeners() {
		return listenerList.getListeners(ValueListener.class);
	}

	@Override
	public Integer getValue() { return value; }

	@Override
	public void setValue(final Integer value) {
		this.value = Objects.requireNonNull(value);
	}

	// private

	private void doFilter(final String filter) {
		filterBlock.charList.clear();

		if (filter.isEmpty()) {
			searchPanel.setState(MSearchPanel.State.NORMAL);
		
			return;
		}

		Pattern pattern = TK.newTextSearchPattern(filter, 0);
		for (Block block : unicode.blockList) {
			for (Char i : block.charList) {
				String name = i.getName();
				if (
					!name.isEmpty() &&
					(
						pattern.matcher(name).find() ||
						pattern.matcher(i.formatHex()).find() ||
						i.formatDec().contains(filter)
					)
				)
					filterBlock.charList.add(i);
			}
		}

		if (filterBlock.charList.isEmpty()) {
			charListView.setText(i18n("No item found: {0}", filter));
			searchPanel.setState(MSearchPanel.State.ERROR);
		}
		else if (filterBlock.charList.size() > 10000) {
			filterBlock.charList.clear();
			charListView.setText(i18n("Too many results"));
			searchPanel.setState(MSearchPanel.State.WARNING);
		}
		else {
			charListView.setText(MList.AUTO_TEXT);
			searchPanel.setState(MSearchPanel.State.OK);
		}

		showBlock(filterBlock, -1);
	}

	private synchronized static Unicode getUnicode() {
		Unicode unicode = TK.get(unicodeRef);
		
		if (unicode == null) {
			unicode = new Unicode();
			unicodeRef = new SoftReference<>(unicode);
		}
		
		return unicode;
	}
	
	private void readConfig() {
		Config config = MAccessController.doPrivileged(Config::getDefault);
		recentItemsBlock.parse(config.read("CharacterChooser.recentItems", ""));
		starredItemsBlock.parse(config.read("CharacterChooser.starredItems", ""));
	}
	
	private void showBlock(final Block block, final int selectCodePoint) {
		if (blockList.getSelectedItem() != block) {
			eventsEnabled = false;
			blockList.setSelectedItem(block, true);
			eventsEnabled = true;
		}

		charListView.clear();
		if (block != filterBlock)
			charListView.setText(MList.AUTO_TEXT); // reset

		UI.lengthyOperation(this, () -> {
			charListView.addAllItems(block.charList);
			
			return null;
		} );
		
		if (!charListView.isEmpty()) {
			if (selectCodePoint != -1)
				charListView.setSelectedItem(i -> i.codePoint == selectCodePoint, true);
			else
				charListView.setSelectedIndex(0, true);
		}
	}

	// package
	
	static String toString(final int codePoint) {
		return new String(Character.toChars(codePoint));
	}
	
	void writeConfig() {
		String recentItemsValue = recentItemsBlock.toConfigValue();
		String starredItemsValue = starredItemsBlock.toConfigValue();
		
		MAccessController.doPrivileged(() -> {
			Config config = Config.getDefault();
			config.write("CharacterChooser.recentItems", recentItemsValue);
			config.write("CharacterChooser.starredItems", starredItemsValue);
			
			return null;
		} );
	}

	// private classes
	
	private static final class Block {
	
		// private
		
		private int end;
		private final int start;
		private final MArrayList<Char> charList = new MArrayList<>();
		private final String displayName;
		private final String name;
	
		// public
		
		public Block(final String text) {
			name = "";
			displayName = text;
			start = 0;
		}
		
		public Block(final Character.UnicodeBlock unicodeBlock, final int start) {
			this.name = unicodeBlock.toString();
			this.start = start;
			
			// FOO BAR -> Foo Bar
			String s = TK.toLowerCase(name);
			s = TK.identifierToDisplayString(s.replace(' ', '_'));
			displayName = s;
		}

		public void add(final int codePoint) {
			charList.add(new Char(codePoint));
		}

		public String getName() { return name; }

		public void parse(final String value) {
			// parse a space separated list of code points
			for (String i : TK.fastSplit(value, ' ')) {
				try {
					add(Integer.parseInt(i, 16));
				}
				catch (NumberFormatException exception) {
					MLogger.exception(exception);
				}
			}
		}

		public String toConfigValue() {
			// create a space separated list of code points
			return charList.stream()
				.distinct() // remove duplicates
				.map(c -> Integer.toHexString(c.codePoint)) // no Char.formatHex; compatible with Integer.parseInt(..., 16)
				.collect(Collectors.joining(" "));
		}

		@Override
		public String toString() {
			String s = displayName;
			if (MLogger.isDeveloper())
				s += " (count: " + charList.size() + ", range: " + Char.formatHex(start) + ".." + Char.formatHex(end) + ")";
			
			return s;
		}

	}

	private static final class Char {
	
		// private
		
		// initialize lazily
		private final int codePoint;
		private String dec;
		private String hex;
		private String name;
		private String string;
		private String toolTipText;
	
		// public
		
		public Char(final int codePoint) {
			this.codePoint = codePoint;
		}

		@Override
		public boolean equals(final Object o) {
			if (o == this)
				return true;
			
			if ((o == null) || (o.getClass() != this.getClass()))
				return false;
			
			return this.codePoint == Char.class.cast(o).codePoint;
		}
		
		public String formatDec() {
			if (dec == null)
				dec = Integer.toString(codePoint);
			
			return dec;
		}
		
		public static String formatHex(final int codePoint) {
			String hex = TK.toUpperCase(Integer.toHexString(codePoint));

			// max string length is 8 ("U+10FFFF", as defined in Character.MAX_CODE_POINT)
			MStringBuilder s = new MStringBuilder(8);

			s.append("U+");
			// add leading zeros
			if (hex.length() < 4)
				s.fill('0', 4 - hex.length());
			s.append(hex);

			return s.toString();
		}

		public String formatHex() {
			if (hex == null)
				hex = formatHex(codePoint);

			return hex;
		}

		@Override
		public int hashCode() { return codePoint; }

		public String getName() {
			if (name == null)
				name = Objects.toString(Character.getName(codePoint), "");

			return name;
		}

		public String getToolTipText() {
			if (toolTipText == null)
				toolTipText = getName() + " (" + formatHex() + ")";

			return toolTipText;
		}

		@Override
		public String toString() {
			if (string == null)
				string = MCharacterChooser.toString(codePoint);
			
			return string;
		}

	}

	private static final class InfoPanel extends MPanel {

		// private
		
		private final MTextLabel charCodeLabel;
		private final MTextLabel charNameLabel;
		private final MLabel charViewLabel;
		private final MLinkButton moreInfoButton;

		// public
		
		public InfoPanel() {
			super(null);

			charViewLabel = new MLabel();
			charViewLabel.setBackground(Color.WHITE);
			charViewLabel.setForeground(Color.BLACK);
			charViewLabel.setOpaque(true);

			charViewLabel.setBorder(UI.createEmptyBorder(getContentMargin()));
			charViewLabel.setHorizontalAlignment(UI.CENTER);
			
			charNameLabel = new MTextLabel();
			charCodeLabel = new MTextLabel();
			
			moreInfoButton = new MLinkButton(i18n("More Info..."));
			
			setSimpleLayout()
				.setContentGap()
				.setContentMargin();

			add(charViewLabel, "center");
			add(charNameLabel, "bottom");
			add(charCodeLabel, "bottom");
			add(moreInfoButton, "bottom");
		}

		public void update(final Char c) {
			if (c == null) {
				charViewLabel.setText("");
				charNameLabel.setText("");
				charCodeLabel.setText("");

				moreInfoButton.setEnabled(false);
			}
			else {
				charViewLabel.setText(c.toString());
				charNameLabel.setText(c.getName());
				charCodeLabel.setText(c.formatHex());

				moreInfoButton.setURI(URI.create("https://codepoints.net/" + c.formatHex()));
				moreInfoButton.setEnabled(true);
			}
		}

	}

	private static final class Unicode {

		// public
		
		public final MArrayList<Block> blockList = new MArrayList<>();

		// public
		
		public Unicode() {
			Block currentBlock = null;
			Character.UnicodeBlock lastUnicodeBlock = null;

			// HACK: skip large blocks that may be slow to load and display
			int endCodePoint = 0x1ffff/*Character.MAX_CODE_POINT*/;
			for (int codePoint = Character.MIN_CODE_POINT; codePoint < endCodePoint; codePoint++) {
				Character.UnicodeBlock unicodeBlock = Character.UnicodeBlock.of(codePoint);

				if (unicodeBlock == null)
					continue; // for

				if (!Objects.equals(lastUnicodeBlock, unicodeBlock)) {
					currentBlock = new Block(unicodeBlock, codePoint);
					blockList.add(currentBlock);

					lastUnicodeBlock = unicodeBlock;
				}
				
				currentBlock.add(codePoint);
				currentBlock.end = codePoint;
			}
		}

	}

}
