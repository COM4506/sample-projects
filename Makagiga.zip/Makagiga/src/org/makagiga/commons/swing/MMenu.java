// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.IllegalComponentStateException;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Iterator;
import java.util.function.Consumer;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

import org.makagiga.commons.AbstractIterator;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.painters.GradientPainter;
import org.makagiga.commons.style.StyleSupport;

/**
 * A menu.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MMenu extends JMenu
implements
	Iterable<JMenuItem>,
	StyleSupport
{
	
	// private

	private boolean autoRemoveAll;
	private boolean autoSplit = true;
	private boolean noSplit;
	private Consumer<MMenu> onSelect;
	private int maxHeight = -1;
	private int popupMenuVerticalAlignment = TOP;
	private MMenu _currentMenu;
	private static StaticHandler staticHandler = new StaticHandler();
	private static final String SEPARATOR_PROPERTY = "org.makagiga.commons.swing.MMenu.separator";
	private static WeakReference<JPopupMenu> currentPopupRef;

	// public

	/**
	 * Constructs a menu.
	 */
	public MMenu() {
		this(null, (Icon)null);
	}

	/**
	 * @since 3.0
	 */
	public MMenu(final MActionInfo info) {
		this(info.getText(), info.getIconName());
	}

	/**
	 * Constructs a menu.
	 * @param text A text (&amp; - mnemonic)
	 */
	public MMenu(final String text) {
		this(text, (Icon)null);
	}

	/**
	 * Constructs a menu.
	 * @param text A text (&amp; - mnemonic)
	 * @param icon An icon
	 */
	public MMenu(final String text, final Icon icon) {
		setDelay(500);
		
		if (icon != null)
			setIcon(icon);
		setText(Mnemonic.set(this, text));

		addMenuListener(staticHandler);
		ComponentHighlight.getInstance(); // init
	}

	/**
	 * Constructs a menu.
	 * @param text A text (&amp; - mnemonic)
	 * @param iconName An icon name (e.g. "ui/quit")
	 */
	public MMenu(final String text, final String iconName) {
		this(text, MIcon.small(iconName));
	}

	@Override
	public JMenuItem add(final JMenuItem menuItem) {
		if (noSplit)
			return super.add(menuItem);

		try {
			noSplit = true;
			MMenu menu = getCurrentMenu();

			return (menu == this) ? super.add(menuItem) : menu.add(menuItem);
		}
		finally {
			noSplit = false;
		}
	}

	/**
	 * Adds an @p action to the menu.
	 * @return A new menu item
	 *
	 * @since 2.0
	 */
	public MMenuItem add(final MAction action) {
		return (MMenuItem)getCurrentMenu().add(new MMenuItem(action));
	}

	/**
	 * Adds an item to the menu.
	 * @param text An item text
	 * @return A new menu item
	 */
	@Override
	public MMenuItem add(final String text) {
		return (MMenuItem)getCurrentMenu().add(new MMenuItem(text));
	}

	/**
	 * Adds a check box to the menu.
	 * @param action A "toggle" action
	 * @return A new check box menu item
	 *
	 * @since 1.2
	 */
	public JCheckBoxMenuItem addCheckBox(final Action action) {
		JCheckBoxMenuItem item = (JCheckBoxMenuItem)getCurrentMenu().add(new JCheckBoxMenuItem());
		if ((action instanceof MAction) && !MAction.class.cast(action).isHTMLEnabled())
			UI.setHTMLEnabled(item, false);
		item.setAction(action);
		String value = MAction.getValue(action, Action.LONG_DESCRIPTION, null);
		item.setToolTipText(value);
		
		return item;
	}

	/**
	 * @since 3.0
	 */
	public JCheckBoxMenuItem addCheckBox(final MAction action, final boolean selected) {
		action.setSelected(selected);

		return addCheckBox(action);
	}

	/**
	 * @since 4.2
	 */
	public MMenuItem addCloseMenuItem() {
		MMenuItem menuItem = add(i18n("Close This Menu"));
		menuItem.setIcon(MIcon.small("ui/close"));
		
		return menuItem;
	}

	/**
	 * @since 4.4
	 */
	public JCheckBoxMenuItem addDefaultCheckBox(final MAction action, final boolean selected) {
		JCheckBoxMenuItem item = addCheckBox(action, selected);
		if (selected && UI.isLooks())
			UI.setStyle("font-weight: bold", item);

		return item;
	}

	/**
	 * @since 4.4
	 */
	public JRadioButtonMenuItem addDefaultRadioButton(final MAction action, final boolean selected) {
		JRadioButtonMenuItem item = addRadioButton(action, selected);
		if (selected && UI.isLooks())
			UI.setStyle("font-weight: bold", item);

		return item;
	}

	/**
	 * Adds all menu components from the @p menu.
	 * @throws NullPointerException If @p menu is @c null
	 */
	public void addItemsFromMenu(final MMenu menu) {
		Component[] components = menu.getMenuComponents();
		for (Component c : components)
			getCurrentMenu().add(c);
	}

	/**
	 * @since 4.2
	 */
	public Title addNoItemsInfo(final boolean condition) {
		if (condition)
			return addTitle(i18n("No Items"), "ui/info");
		
		return null;
	}

	/**
	 * Adds an @p action to the menu.
	 * @return A new radio button menu item
	 *
	 * @since 2.0
	 */
	public JRadioButtonMenuItem addRadioButton(final MAction action) {
		JRadioButtonMenuItem item = (JRadioButtonMenuItem)getCurrentMenu().add(new JRadioButtonMenuItem());
		if (!action.isHTMLEnabled())
			UI.setHTMLEnabled(item, false);
		item.setAction(action);
		item.setToolTipText(action.getHelpText());

		return item;
	}

	/**
	 * @since 3.0
	 */
	public JRadioButtonMenuItem addRadioButton(final MAction action, final boolean selected) {
		action.setSelected(selected);
		
		return addRadioButton(action);
	}

	@Override
	public void addSeparator() {
		// NOTE: do not use getCurrentMenu() here
		if (_currentMenu == null)
			super.addSeparator();
		else
			_currentMenu.addSeparator();
	}

	/**
	 * @since 3.8.11
	 */
	@Obsolete // merge with addSeparator()
	public void addSeparator(final boolean force) {
		if (!force) {
			int c = getMenuComponentCount();

			// do not insert separator as first element if menu is empty
			
			if (c == 0)
				return;

			// do not insert separator after other separator or title

			Component last = getMenuComponent(c - 1);
			if (
				(last instanceof JPopupMenu.Separator) ||
				(
					(last instanceof MPanel) &&
					Boolean.TRUE.equals(MPanel.class.cast(last).getClientProperty(SEPARATOR_PROPERTY))
				)
			) {
				return;
			}
		}

		addSeparator();
	}

	/**
	 * @since 5.4
	 */
	public JComponent addSeparator(final MActionInfo info) {
		return addSeparator(info.getDialogTitle(), info.getSmallIcon());
	}

	/**
	 * @since 5.4
	 */
	public JComponent addSeparator(final String title) {
		return addSeparator(title, (Icon)null);
	}

	/**
	 * @since 5.4
	 */
	public JComponent addSeparator(final String title, final Icon icon) {
		MLabel label = new MLabel(title, icon);
		
/* DEAD:
		Color color = UIManager.getColor("MenuItem.selectionBackground");
		if ((color != null) && !color.equals(UIManager.getColor("MenuItem.background")))
			label.setForeground(color);
		else
*/
		label.setStyle("font-weight: bold");

		MPanel panel = MPanel.createBorderPanel(5);
		panel.putClientProperty(SEPARATOR_PROPERTY, true);
		panel.addWest(label);
		panel.addCenter(MSeparator.newHorizontalLine(UI.getForeground(this)));
		panel.setMargin(0, 5, 0, 5);
		panel.setOpaque(false);
		if (!UI.isRetro())
			panel.setAlignmentX(LEFT_ALIGNMENT);
	
		currentMenu().add(panel);
		
		return panel;
	}

	/**
	 * @since 5.4
	 */
	public JComponent addSeparator(final String title, final String smallIconName) {
		return addSeparator(title, MIcon.small(smallIconName));
	}

	/**
	 * @since 3.8.1
	 */
	public Title addTitle(final MActionInfo info) {
		return addTitle(info.getDialogTitle(), info.getIconName());
	}

	public Title addTitle(final String text) {
		return addTitle(text, (Icon)null);
	}

	/**
	 * Adds a title to the menu.
	 *
	 * @param text The title text
	 * @param icon The title icon (can be @c null)
	 *
	 * @return A new title menu item
	 *
	 * @since 2.0
	 */
	public Title addTitle(final String text, final Icon icon) {
		Title title = new Title(text, icon);

		// HACK: wrap label to fix menu width problems
		MPanel p = MPanel.createBorderPanel();
		p.putClientProperty(SEPARATOR_PROPERTY, true);
		if (!UI.isRetro())
			p.setAlignmentX(LEFT_ALIGNMENT);
		p.addCenter(title);
		p.setOpaque(false);

		// NOTE: do not use getCurrentMenu() here
		currentMenu().add(p);
		
		return title;
	}

	/**
	 * Adds a title to the menu.
	 *
	 * @param text The title text
	 * @param iconName The title icon name (can be @c null)
	 *
	 * @return A new title menu item
	 *
	 * @since 2.0
	 */
	public Title addTitle(final String text, final String iconName) {
		return addTitle(text, MIcon.small(iconName));
	}

	/**
	 * @since 5.4
	 */
	public boolean getAutoRemoveAll() { return autoRemoveAll; }

	/**
	 * @since 5.4
	 */
	public void setAutoRemoveAll(final boolean value) { autoRemoveAll = value; }

	/**
	 * Returns an icon associated with this menu component,
	 * or @c null if no icon.
	 */
	public Icon getComponentIcon() {
		Component c = getComponent();

		return
			(c instanceof AbstractButton)
			? AbstractButton.class.cast(c).getIcon()
			: null;
	}
	
	/**
	 * @since 2.0
	 */
	public static JPopupMenu getCurrentPopup() {
		return TK.get(currentPopupRef);
	}

// TODO: auto limit max. width

	/**
	 * @since 4.4
	 */
	public int getPopupMenuVerticalAlignment() { return popupMenuVerticalAlignment; }

	/**
	 * @since 4.4
	 */
	public void setPopupMenuVerticalAlignment(final int value) { popupMenuVerticalAlignment = value; }

	public static void hideCurrentPopup() {
		JPopupMenu popup = getCurrentPopup();
		if (popup != null) {
			popup.setVisible(false);
			currentPopupRef.clear();
		}
	}
	
	/**
	 * @since 4.6
	 */
	public boolean isAutoSplit() { return autoSplit; }

	/**
	 * @since 4.6
	 */
	public void setAutoSplit(final boolean value) {
		autoSplit = value;
		
		MMenu m = currentMenu();
		if (m != this)
			m.setAutoSplit(value);
	}

	/**
	 * Returns @c true if menu has no items.
	 */
	public boolean isEmpty() {
		return getItemCount() == 0;
	}

	/**
	 * @since 1.2
	 */
	@Override
	public Iterator<JMenuItem> iterator() {
		if (isEmpty())
			return Collections.emptyIterator();

		return new AbstractIterator<>(getItemCount(), this::getItem);
	}
	
	/**
	 * @since 5.0
	 */
	@SuppressWarnings("unchecked")
	public void onSelect(final Consumer<? extends MMenu> onSelect) { this.onSelect = (Consumer<MMenu>)onSelect; }

	/**
	 * Removes all items from the menu.
	 */
	@Override
	public void removeAll() {
		_currentMenu = null;
		super.removeAll();
		putClientProperty("org.makagiga.commons.swing.MMenu.mnemonicDone", false);
	}

	/**
	 * Removes all items from @p index to the end of the menu.
	 */
	public void removeFrom(final int index) {
		_currentMenu = null;
		
		int count = getItemCount();

		if (count == 0)
			return;

		for (int i = count - 1; i >= index; --i)
			remove(i);
	}
	
	public void setMnemonics() {
		if (UI.getClientProperty(this, "org.makagiga.commons.swing.MMenu.mnemonicDone", false))
			return;

		if (UI.getClientProperty(this, "org.makagiga.commons.swing.MMenu.mnemonicLock", false))
			return;

		try {
			putClientProperty("org.makagiga.commons.swing.MMenu.mnemonicLock", true);
			new Mnemonic(this);
		}
		finally {
			putClientProperty("org.makagiga.commons.swing.MMenu.mnemonicDone", true);
			putClientProperty("org.makagiga.commons.swing.MMenu.mnemonicLock", null);
		}
	}

	/**
	 * Displays the popup menu.
	 * @param parent A parent component
	 * @throws NullPointerException If @p parent is @c null
	 */
	public JPopupMenu showPopup(final Component parent) {
		Point popupLocation;
		if (parent instanceof JComponent)
			popupLocation = JComponent.class.cast(parent).getPopupLocation(null);
		else
			popupLocation = null;
		if (popupLocation == null)
			popupLocation = parent.getMousePosition();
		
		if (popupLocation == null)
			return showPopup(parent, 0, 0);

		return showPopup(parent, popupLocation);
	}

	/**
	 * Displays the popup menu.
	 * @param parent A parent component
	 * @param component A position for the popup menu
	 * @throws NullPointerException If @p parent is @c null
	 * @throws NullPointerException If @p component is @c null
	 */
	public JPopupMenu showPopup(final Component parent, final Component component) {
		Rectangle r = component.getBounds();
		
		return showPopup(parent, new Point(r.x, r.y + r.height));
	}

	/**
	 * Displays the popup menu.
	 * @param parent A parent component
	 * @param point A location where to display the popup menu
	 * @throws NullPointerException If @p parent is @c null
	 */
	public JPopupMenu showPopup(final Component parent, final Point point) {
		if (point == null)
			return showPopup(parent);

		return showPopup(parent, point.x, point.y);
	}

	/**
	 * Displays the popup menu.
	 * @param parent A parent component
	 * @param x A horizontal location where to display the popup menu
	 * @param y A vertical location where to display the popup menu
	 * @throws NullPointerException If @p parent is @c null
	 */
	public JPopupMenu showPopup(final Component parent, final int x, final int y) {
		JPopupMenu popupMenu = getPopupMenu();
		showPopup(popupMenu, parent, x, y);

		return popupMenu;
	}

	/**
	 * @since 3.2
	 */
	public static void showPopup(final JPopupMenu popupMenu, final Component parent, final int x, final int y) {
		popupMenu.addPopupMenuListener(new PopupMenuListener() {
			@Override
			public void popupMenuCanceled(final PopupMenuEvent e) {
				if (currentPopupRef != null)
					currentPopupRef.clear();
			}
			@Override
			public void popupMenuWillBecomeInvisible(final PopupMenuEvent e) {
				if (currentPopupRef != null)
					currentPopupRef.clear();
			}
			@Override
			public void popupMenuWillBecomeVisible(final PopupMenuEvent e) {
				MCellTip.getInstance().setVisible(false);
				currentPopupRef = new WeakReference<>(popupMenu);
				new Mnemonic(popupMenu);
			}
		} );
		try {
			// HACK: A03 LAF
			UI.hideToolTip(null);
			
			popupMenu.show(parent, x, y);
		}
		catch (IllegalComponentStateException exception) {
			// HACK: possibly caused by parent.getLocationOnScreen() and MouseGestures
			MLogger.developerException(exception);

			if ((parent != null) && parent.isShowing())
				popupMenu.show(null, x, y);
		}
	}
	
	/**
	 * @since 1.2
	 */
	public JPopupMenu showPopup(final InputEvent e) {
		if (e instanceof MouseEvent)
			return showPopup(e.getComponent(), MouseEvent.class.cast(e).getPoint());
		
		return showPopup(e.getComponent());
	}

	// protected

	/**
	 * Returns the current menu.
	 */
	protected MMenu getCurrentMenu() {
		if (!autoSplit)
			return currentMenu();
	
		if (maxHeight == -1) {
			Insets i = UI.getScreenInsets();
			maxHeight = UI.getScreenSize().height - (i.top + i.bottom);
		}

		int menuHeight;
		Component[] components = currentMenu().getMenuComponents();
		if (components.length > 0) {
			Component prototype = components[0];
			for (Component i : components) {
				if (i instanceof JMenuItem) {
					prototype = i;

					break; // for
				}
			}
			menuHeight = (prototype.getPreferredSize().height * components.length) + 50;
		}
		else {
			menuHeight = 0;
		}
		
		if (menuHeight > maxHeight) {
			MMenu submenu = new MMenu(i18n("More..."));
			submenu.setStyle("font-style: italic");
			MMenu m = currentMenu();

			// do not duplicate separators
			int count = m.getMenuComponentCount();
			if ((count > 0) && !(m.getMenuComponent(count - 1) instanceof JPopupMenu.Separator))
				m.addSeparator();

			try {
				m.noSplit = true;
				m.add(submenu);
			}
			finally {
				m.noSplit = false;
			}
			_currentMenu = submenu;
		}
		
		return currentMenu();
	}

	@Override
	protected Point getPopupMenuOrigin() {
		Point p = super.getPopupMenuOrigin();
		if (p != null) {
			if (popupMenuVerticalAlignment == CENTER) {
				Dimension prefSize = getPopupMenu().getPreferredSize();

				p.y = -(prefSize.height / 2);
				p.y += (getHeight() / 2);
			}
			
			// Long menu may popup outside the screen...
			Point screenLocation = new Point();
			SwingUtilities.convertPointToScreen(screenLocation, this);
			screenLocation.y += p.y;
			if (screenLocation.y < 0)
				p.y += Math.abs(screenLocation.y);

/*
			if (getParent() instanceof JMenuBar) {
				//if (UI.isMetal())
					//p.x = -10;
			}
			else {
				// HACK: do not overlap popup menus (selection paint issues)
				if (UI.isWindows())
					p.x += 4;//!!!?3
			}
*/
/* DEAD:
			if (getParent() instanceof JMenuBar) {
				if (prefSize == null)
					prefSize = getPopupMenu().getPreferredSize();

				p.x = -(prefSize.width / 2);
				p.x += (getWidth() / 2);
			}
*/
		}
		
		return p;
	}
	
	/**
	 * @since 4.2
	 */
	protected void onSelect() { }

	// private

	private MMenu currentMenu() {
		return TK.get(_currentMenu, this);
	}
	
	// public classes
	
	public static class Title extends MLabel {

		// private

		private final GradientPainter painter;
		
		// public

		public Title(final String text) {
			this(text, null);
		}
		
		/**
		 * @since 2.0
		 */
		public Title(final String text, final Icon icon) {
			if (UI.isRetro()) {
				setOpaque(true);
				painter = null;
			}
			else {
				painter = new GradientPainter();
			}

			setHTMLEnabled(false);
			setIcon(icon);
			setText(text);
		}
		
		@Override
		public Color getBackground() {
			if (UI.isRetro())
				return TK.get(UIManager.getColor("Retro.MenuTitle.background"), Color.BLACK);
		
			Component parent = getParent();
			Color bg = (parent == null) ? null : parent.getBackground();
			
			return TK.get(bg, Color.WHITE);
		}

		@Override
		public Color getForeground() {
			if (UI.isRetro())
				return TK.get(UIManager.getColor("Retro.MenuTitle.foreground"), Color.WHITE);

			Component parent = getParent();
			Color fg = (parent == null) ? null : parent.getForeground();
			
			return TK.get(fg, Color.BLACK);
		}
		
		@Override
		public Dimension getMaximumSize() {
			return new Dimension(Integer.MAX_VALUE, super.getMaximumSize().height);
		}

		@Override
		public void updateUI() {
			super.updateUI();
			setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
		}

		// protected

		@Override
		protected void paintComponent(final Graphics g) {
			if (painter != null)
				painter.paint(this, (Graphics2D)g);
			super.paintComponent(g);
		}

	}

	// private classes

	private static final class ComponentHighlight extends MComponent implements ChangeListener {

		// private

		private boolean noHighlightedComponent;
		private final Color color = MColor.BRICK_RED.deriveAlpha(200);
		private static ComponentHighlight _instance;
		private final Rectangle oldComponentRectangle = new Rectangle();
		private WeakReference<Component> currentRef;
		
		// public
		
		@Override
		public void stateChanged(final ChangeEvent e) {
			MenuElement[] selection = MenuSelectionManager.defaultManager().getSelectedPath();
			// no selection
			if (TK.isEmpty(selection)) {
				hideCurrent();
			}
			else {
				// HACK: fix when invoked via key event
				Component current = TK.get(currentRef);
				if (current != null) {
					repaintOldComponent();
					currentRef = null;
				}

				Component c = getHighlightedComponent(selection[selection.length - 1]);
				// hide previous highlight
				if (c == null) {
					noHighlightedComponent = true;
					repaintOldComponent();
				}
				// show new highlight
				else if (c.isShowing() && c.isVisible()) {
					show(c);
				}
			}
		}

		// protected

		@Override
		protected void paintComponent(final Graphics graphics) {
			Component c = TK.get(currentRef);

			if ((c == null) || noHighlightedComponent || !c.isShowing() || !c.isVisible())
				return;

			Graphics2D g = (Graphics2D)graphics;
			Rectangle r = MScrollPane.convertRectangle(this, c);
			g.setColor(color);
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g.fillRoundRect(r.x, r.y, r.width, r.height, 10, 10);
		}

		// private

		private ComponentHighlight() {
			setOpaque(false);
			MenuSelectionManager.defaultManager().addChangeListener(this);
		}

		private Component getHighlightedComponent(final MenuElement e) {
			if (e instanceof AbstractButton) {
				Action a = AbstractButton.class.cast(e).getAction();

				if (a instanceof MAction)
					return MAction.class.cast(a).getHighlightedComponent();
			}

			return null;
		}

		private static ComponentHighlight getInstance() {
			if (_instance == null)
				_instance = new ComponentHighlight();

			return _instance;
		}

		private void hideCurrent() {
			noHighlightedComponent = true;
			Component c = TK.get(currentRef);
			if (c != null) {
				Window w = SwingUtilities.getWindowAncestor(c);
				if (
					(w instanceof RootPaneContainer) &&
					(RootPaneContainer.class.cast(w).getGlassPane() instanceof ComponentHighlight)
				) {
					MFrame.clearGlassPane((RootPaneContainer)w);
				}
			}
			currentRef = null;
		}
		
		private void repaintOldComponent() {
			if ((oldComponentRectangle.width > 0) && (oldComponentRectangle.height > 0)) {
				repaint(oldComponentRectangle);
				oldComponentRectangle.setSize(0, 0);
			}
		}

		private void show(final Component c) {
			noHighlightedComponent = false;
			Window w = SwingUtilities.getWindowAncestor(c);
			if (w instanceof RootPaneContainer) {
				RootPaneContainer rpc = (RootPaneContainer)w;
				if (rpc.getGlassPane() != this) {
					hideCurrent(); // 1.
					currentRef = new WeakReference<>(c); // 2.
					noHighlightedComponent = false; // 3.
					
					rpc.setGlassPane(this);
					setVisible(true);
					
					Rectangle r = MScrollPane.convertRectangle(this, c);
					oldComponentRectangle.setBounds(r);
				}
				else {
					currentRef = new WeakReference<>(c);
				
					repaintOldComponent();
				
					// repaint new component
					Rectangle r = MScrollPane.convertRectangle(this, c);
					repaint(r);
					oldComponentRectangle.setBounds(r);
				}
			}
		}
	
	}

	private static final class StaticHandler implements MenuListener {

		// public

		public StaticHandler() { }

		@Override
		public void menuCanceled(final MenuEvent e) { }

		@Override
		public void menuDeselected(final MenuEvent e) {
			MMenu menu = (MMenu)e.getSource();

			if (menu.getAutoRemoveAll())
				menu.removeAll();
		}

		@Override
		public void menuSelected(final MenuEvent e) {
			MMenu menu = (MMenu)e.getSource();

			if (menu.getAutoRemoveAll())
				menu.removeAll();

			if (menu.onSelect != null)
				menu.onSelect.accept(menu);
			else
				menu.onSelect();

			menu.setMnemonics();
		}

	}

}
