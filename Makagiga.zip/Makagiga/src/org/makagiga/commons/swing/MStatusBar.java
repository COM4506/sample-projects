// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Rectangle;
import javax.accessibility.AccessibleContext;
import javax.accessibility.AccessibleRole;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.JLayeredPane;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.UI;
import org.makagiga.commons.painters.FlatPainter;
import org.makagiga.commons.swing.border.MLineBorder;

/**
 * A status bar.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MStatusBar extends MPanel {

	// public

	/**
	 * Autohide message after the specified time.
	 * 
	 * @since 2.0
	 */
	public static final int AUTOHIDE_MESSAGE = 1;
	
	/**
	 * Error message.
	 * 
	 * @since 2.0
	 */
	public static final int ERROR_MESSAGE = 1 << 1;
	
	/**
	 * Information message.
	 * 
	 * @since 2.0
	 */
	public static final int INFO_MESSAGE = 1 << 2;
	
	/**
	 * Warning message.
	 * 
	 * @since 2.0
	 */
	public static final int WARNING_MESSAGE = 1 << 3;

	/**
	 * Repaint the status bar component immediately.
	 *
	 * @since 4.4
	 */
	public static final int FORCE_REPAINT = 1 << 4;

	/**
	 * OK message.
	 *
	 * @since 5.0
	 */
	public static final int OK_MESSAGE = 1 << 5;

	/**
	 * This property is changed when @ref setClosed is invoked.
	 */
	public static final String CLOSED_PROPERTY = "MStatusBar.closed";

	// private

	private boolean closed;
	private final Border textBorder;
	private int blinkCount;
	private MIcon icon;
	private final MMessageLabel text;
	private final MPanel buttonPanel;
	private final MTimer blinkTimer;
	private final MTimer textTimer;

	// public

	/**
	 * Constructs a status bar.
	 */
	public MStatusBar() {
		super(UI.HORIZONTAL);
		
		MWhatsThis.set(this, i18n("Status Bar - Info and minor error messages"));

		buttonPanel = MPanel.createHBoxPanel();
		add(buttonPanel);

		textBorder = BorderFactory.createCompoundBorder(
			new MLineBorder(MLineBorder.Position.TOP, MLineBorder.Position.RIGHT),
			UI.createEmptyBorder(3)
		);

		// text
		text = new MMessageLabel();
		text.setPainter(new FlatPainter());
		text.setStyle("cursor: hand; font-size: larger");
		UI.onButtonClicked(text, e -> text.setVisible(false));
		add(text);

		int timeout = UI.statusBarTimeout.get(1, Integer.MAX_VALUE);
		textTimer = MTimer.seconds(timeout, self -> {
			ready();
			if (closed)
				setVisible(false);
				
			return MTimer.STOP;
		} );
		
		blinkTimer = MTimer.seconds(1, self -> {
			if ((blinkCount % 2) == 0) {
				text.setIcon(MIcon.small("ui/info"));
			}
			else {
				synchronized (this) {
					text.setIcon(icon);
				}
			}
			blinkCount++;

			return (blinkCount < 4);
		} );
		
		setClosed(true);
	}

	/**
	 * @since 3.8.1
	 */
	public void addButton(final MSmallButton button) {
		buttonPanel.add(button);
		buttonPanel.validate();
	}

	/**
	 * @since 3.8.8
	 */
	public void removeButton(final MSmallButton button) {
		buttonPanel.remove(button);
		buttonPanel.validate();
	}

	/**
	 * @since 3.8.6
	 */
	public static void error(final Throwable t) {
		if (t instanceof OutOfMemoryError)
			error(i18n("Out of memory: {0}", t.getMessage()));
		else
			error(t.toString());

		MLogger.developerException(t);
	}

	/**
	 * Displays an error message text.
	 * The message will be automatically hidden.
	 *
	 * @param value The message text
	 *
	 * @since 2.0
	 */
	public synchronized static void error(final String value) {
		MainView.getStatusBar().setText(value, AUTOHIDE_MESSAGE | ERROR_MESSAGE);
	}

	@Override
	public AccessibleContext getAccessibleContext() {
		if (accessibleContext == null)
			accessibleContext = new AccessibleMStatusBar();

		return accessibleContext;
	}

	/**
	 * @since 3.8.8
	 */
	public MPanel getButtonPanel() { return buttonPanel; }

	/**
	 * Displays an information message.
	 * The message will be automatically hidden.
	 *
	 * @param value The message text
	 *
	 * @since 2.0
	 */
	public synchronized static void info(final String value) {
		MainView.getStatusBar().setText(value, AUTOHIDE_MESSAGE | INFO_MESSAGE);
	}

	/**
	 * Returns @c true if status bar is closed.
	 */
	public boolean isClosed() { return closed; }
	
	/**
	 * If @p value is @c true, the status bar will be closed (hidden).
	 * @see #CLOSED_PROPERTY
	 */
	public void setClosed(final boolean value) {
		setVisible(!value);
		if (value != closed) {
			closed = value;
			firePropertyChange(CLOSED_PROPERTY, !value, value);
		}
	}

	/**
	 * Displays a message without autohidding.
	 *
	 * @param value The message text
	 *
	 * @since 2.0
	 */
	public synchronized static void message(final String value) {
		MainView.getStatusBar().setText(value, INFO_MESSAGE);
	}

	/**
	 * @since 5.0
	 */
	public synchronized static void ok(final String value) {
		MainView.getStatusBar().setText(value, AUTOHIDE_MESSAGE | OK_MESSAGE);
	}

	/**
	 * Displays the default status text.
	 */
	public synchronized static void ready() {
		MainView.getStatusBar().setText(null, 0);
	}

	public synchronized void setText(final String value, final int f) {
		Flags flags = Flags.valueOf(f);
		// icon
		boolean isBlink;
		if (flags.isSet(ERROR_MESSAGE)) {
			icon = MIcon.small("ui/error");
			isBlink = true;
			startTextAnimation(MHighlighter.ERROR_COLOR, flags.isSet(FORCE_REPAINT));
		}
		else if (flags.isSet(INFO_MESSAGE)) {
			icon = MIcon.small("ui/info");
			isBlink = false;
			startTextAnimation(MHighlighter.INFO_COLOR, flags.isSet(FORCE_REPAINT));
		}
		else if (flags.isSet(OK_MESSAGE)) {
			icon = MIcon.small("ui/ok");
			isBlink = false;
			startTextAnimation(MHighlighter.OK_COLOR, flags.isSet(FORCE_REPAINT));
		}
		else if (flags.isSet(WARNING_MESSAGE)) {
			icon = MIcon.small("ui/warning");
			isBlink = true;
			startTextAnimation(MHighlighter.WARNING_COLOR, flags.isSet(FORCE_REPAINT));
		}
		else {
			ComponentAnimation.stopBackgroundBlend(text);
			icon = null;
			isBlink = false;
			text.setColor(null, null);
		}
		text.setIcon(icon);
		if (isBlink) {
			blinkCount = 0;
			blinkTimer.restart();
		}
		else {
			blinkTimer.stop();
		}

		// set border only when needed to avoid "black lines" in upper-right corner
		text.setBorder(textBorder);

		text.setText(value);
		text.setToolTipText(value);

		JLayeredPane lp = UI.getAncestorOfClass(JLayeredPane.class, this);
		if (lp != null) {
			boolean visible = !closed || (icon != null);
		
			if (visible) {
				text.setSize(text.getPreferredSize());
				text.setLocation(0, lp.getHeight() - text.getHeight());
				if (text.getParent() != lp)
					lp.add(text, JLayeredPane.POPUP_LAYER);
			}

			text.setVisible(visible);

			if (visible && flags.isSet(FORCE_REPAINT)) {
				Rectangle r = new Rectangle(
					0,
					lp.getHeight() - text.getHeight(),
					lp.getWidth(),
					text.getHeight()
				);
				lp.paintImmediately(r);
			}
		}
		
		if (flags.isSet(AUTOHIDE_MESSAGE))
			textTimer.restart();
		else
			textTimer.stop();
	}

	/**
	 * Displays a warning message text.
	 * The message will be automatically hidden.
	 *
	 * @param value The message text
	 *
	 * @since 2.0
	 */
	public synchronized static void warning(final String value) {
		MainView.getStatusBar().setText(value, AUTOHIDE_MESSAGE | WARNING_MESSAGE);
	}

	// private

	private void startTextAnimation(final Color to, final boolean forceRepaint) {
		// HACK: Fix background color in mouse gestures status bar help
		ComponentAnimation.stopBackgroundBlend(text);
	
		text.setForeground(MColor.getContrastBW(to));
		if (forceRepaint)
			text.setBackground(to);
		else
			ComponentAnimation.blendBackgroundProperty(text, null, to);
	}

	// protected classes

	/**
	 * @since 3.8.8
	 */
	protected class AccessibleMStatusBar extends AccessibleJPanel {

		// public

		@Override
		public AccessibleRole getAccessibleRole() {
			return AccessibleRole.STATUS_BAR;
		}

	}

}
