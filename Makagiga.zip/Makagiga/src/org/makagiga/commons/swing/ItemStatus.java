// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.Objects;
import javax.accessibility.Accessible;
import javax.accessibility.AccessibleContext;
import javax.accessibility.AccessibleRole;

import org.makagiga.commons.MColor;
import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Obsolete;

/**
 * @since 3.8.3, 4.0 (org.makagiga.commons.swing package)
 */
@Obsolete
public class ItemStatus extends MComponent implements Accessible {

	// private

	private final Dimension prefSizeCache = new Dimension(Integer.MIN_VALUE, Integer.MIN_VALUE);
	private final Icon icon = new Icon();

	// public

	public ItemStatus(final Font baseFont) {
		setOpaque(false);
		icon.font = baseFont.deriveFont(Font.BOLD, (float)Math.max(10, baseFont.getSize() - 1));
	}

	@Override
	public AccessibleContext getAccessibleContext() {
		if (accessibleContext == null)
			accessibleContext = new AccessibleItemStatus();

		return accessibleContext;
	}

	@Override
	public Dimension getMaximumSize() {
		return getPreferredSize();
	}

	@Override
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	@Override
	public Dimension getPreferredSize() {
		if (
			(prefSizeCache.width == Integer.MIN_VALUE) ||
			(prefSizeCache.height == Integer.MIN_VALUE)
		) {
			if (TK.isEmpty(icon.text)) {
				prefSizeCache.setSize(0, 0);
			}
			else {
				FontMetrics fm = getFontMetrics(icon.font);
				prefSizeCache.setSize(fm.stringWidth(icon.text), fm.getHeight());

				int margin = 2;
				prefSizeCache.width += (margin * 2);
				prefSizeCache.height += (margin * 2);
			}
		}
		
		return (Dimension)prefSizeCache.clone();
	}

	public String getText() { return icon.text; }

	public void setText(final String text) {
		if (!Objects.equals(icon.text, text)) {
			prefSizeCache.setSize(Integer.MIN_VALUE, Integer.MIN_VALUE); // invalidate
			icon.text = text;
			revalidate();
			repaint();
		}
	}

	public void setText(final int text, final Color color) {
		setText(Integer.toString(text), color);
	}

	public void setText(final String text, final Color color) {
		Color newColor = TK.get(color, MColor.WHITE);
		newColor = MColor.deriveColor(newColor, 0.98f);

		if (!Objects.equals(icon.background, newColor)) {
			icon.background = newColor;
			icon.foreground = null; // reset
			repaint();
		}

		setText(text);
	}

	// protected

	@Override
	protected void paintComponent(final Graphics graphics) {
		icon.size.setSize(getWidth(), getHeight());
		icon.paintIcon(this, graphics, 0, 0);
	}

	// public classes

	/**
	 * @since 3.8.8
	 */
	public static final class Icon implements javax.swing.Icon {
		
		// private

		private Color background;
		private Color foreground;
		private final Dimension size = new Dimension();
		private Font font;
		private String text;

		// public
		
		/**
		 * @since 4.0
		 */
		public Icon() { }

		public Icon(final String text, final Color color, final Dimension size, final Font font) {
			this.text = text;
			this.background = color;
			this.size.setSize(size);
			this.font = Objects.requireNonNull(font);
		}

		@Override
		public void paintIcon(final Component c, final Graphics graphics, final int x, final int y) {
			if (TK.isEmpty(text))
				return;

			int w = getIconWidth();
			int h = getIconHeight();

			MGraphics2D g = new MGraphics2D(graphics);
			g.setAntialiasing(true);
			g.setTextAntialiasing(null);

			g.setColor(background);
			graphics.fillRoundRect(x, y, w, h, 9, 9);

			if (foreground == null)
				foreground = MColor.getContrast(background, 0.75f);
			
			g.setColor(foreground);
			g.setFont(font);
			g.drawStringCentered(text, x, y, w, h);
		}

		@Override
		public int getIconWidth() { return size.width; }

		@Override
		public int getIconHeight() { return size.height; }

	}
	
	// private classes

	private final class AccessibleItemStatus extends AccessibleJComponent {

		// public
		
		@Override
		public String getAccessibleName() {
			return Objects.toString(ItemStatus.this.getText(), "?");
		}

		@Override
		public AccessibleRole getAccessibleRole() { return AccessibleRole.LABEL; }

	}

}
