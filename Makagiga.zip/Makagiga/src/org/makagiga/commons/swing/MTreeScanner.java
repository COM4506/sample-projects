// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.util.Enumeration;
import javax.swing.tree.TreeNode;

import org.makagiga.commons.AbstractScanner;

/**
 * (MODEL) A tree scanner.
 *
 * @param <T> the node type
 *
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public abstract class MTreeScanner<T extends TreeNode> extends AbstractScanner {

	// private
	
	private int level = 1;

	// public

	/**
	 * Constructs a tree scanner.
	 * The scan will begin automatically from the @p root item.
	 * The @p root item is not processed.
	 *
	 * @param root the tree root item
	 */
	public MTreeScanner(final T root) {
		this(root, false);
	}

	/**
	 * Constructs a tree scanner.
	 * The scan will begin automatically from the @p root item.
	 *
	 * @param root the tree root item
	 * 
	 * @since 4.0
	 */
	public MTreeScanner(final T root, final boolean processRoot) {
		if (root != null) {
			if (processRoot)
				processItem(root);
			recurse(root);
		}
	}
	
	/**
	 * Called for each tree item.
	 * @param item A tree item
	 */
	public abstract void processItem(final T item);

	/**
	 * Called for each parent tree item.
	 * 
	 * @param parent the parent tree item
	 */
	public void processParent(final T parent) { }

	// protected
	
	/**
	 * @since 5.4
	 */
	protected int getLevel() { return level; }
	
	// private

	private void recurse(final T item) {
		if (isStopped())
			return;
		
		try {
			level++;
		
			int childCount = item.getChildCount();
			if (childCount == 0) {
				if (item.getAllowsChildren())
					processParent(item);
				
				return;
			}

			for (Enumeration<?> e = item.children(); e.hasMoreElements();) {
				@SuppressWarnings("unchecked")
				T i = (T)e.nextElement();
				if (i != null) {
					processItem(i);

					if (isStopped())
						return;

					recurse(i);

					if (isStopped())
						return;
				}
			}
			processParent(item);
		}
		finally {
			level--;
		}
	}

}
