// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Objects;
import javax.swing.JEditorPane;
import javax.swing.Painter;
import javax.swing.event.DocumentEvent;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.EditorKit;
import javax.swing.text.Element;
import javax.swing.text.View;
import javax.swing.text.ViewFactory;
import javax.swing.text.WrappedPlainView;

import org.makagiga.commons.Kiosk;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.autocompletion.AutoCompletion;
import org.makagiga.commons.style.StyleSupport;

/**
 * @since 3.8, 4.0 (org.makagiga.commons.swing package)
 */
public class MEditorPane extends JEditorPane
implements
	MText.CommonExtensions,
	MText.Modifiable,
	StyleSupport
{

	// private

	private boolean modified;
	private static Painter<JEditorPane> backgroundPainter;

	// package

	static final String USER_BACKGROUND = "org.makagiga.commons.swing.MEditorPane.USER_BACKGROUND";

	// public
	
	public MEditorPane() {
		setDragEnabled(Kiosk.actionDragDrop.get());
		MText.install(this);
		if (!UI.isRetro())
			MText.setStandardColors(this);
	}

	@Override
	public void cut() {
		AutoCompletion ac = MText.getAutoCompletion(this);
		if (ac != null)
			ac.invokeDisabled(super::cut);
		else
			super.cut();
	}

	@Override
	public void paste() {
		AutoCompletion ac = MText.getAutoCompletion(this);
		if (ac != null)
			ac.invokeDisabled(super::paste);
		else
			super.paste();
	}

	/**
	 * @since 3.8.9
	 */
	public static MEditorPane newPlainText(final String text, final boolean editable) {
		MEditorPane editorPane = new MEditorPane();
		editorPane.setEditable(editable);
		
		editorPane.setText(text);
		MText.getUndoManager(editorPane).discardAllEdits();

		editorPane.setCaretPosition(0);

		return editorPane;
	}

	@Override
	public void setBackground(final Color color) {
		super.setBackground(color);
		fixNimbus(this, "EditorPane[Enabled].backgroundPainter", color);
	}

	/**
	 * @since 4.0
	 */
	public void setText(final String text, final boolean scrollToTop) {
		setText(text);
		if (scrollToTop)
			setCaretPosition(0);
	}

	// MText.CommonExtensions

	@Override
	public synchronized void clear() {
		setText(null);
	}

	@Override
	public synchronized boolean isEmpty() {
		return MText.isEmpty(this);
	}

	// MText.Modifiable

	@Override
	public boolean isModified() { return modified; }

	@Override
	public void setModified(final boolean value, final Object event) {
		modified = value;
		if (modified)
			onChange((event instanceof DocumentEvent) ? (DocumentEvent)event : null);
	}

	// StyleSupport

	@Override
	public void setStyle(final String style) {
		UI.setStyle(style, this);
	}

	// protected

	@Override
	protected EditorKit createDefaultEditorKit() {
		EditorKit impl = super.createDefaultEditorKit();

		if (impl instanceof ViewFactory)
			return new WordWrapEditorKit((ViewFactory)impl);

		return impl;
	}

	protected void onChange(final DocumentEvent e) { }

	// private
	
	private static final class WordWrapEditorKit extends DefaultEditorKit implements ViewFactory {
	
		// private
		
		private final ViewFactory impl;
	
		// public
		
		public WordWrapEditorKit(final ViewFactory impl) {
			this.impl = impl;
		}
	
		@Override
		public View create(final Element element) {
			if (Boolean.TRUE.equals(element.getDocument().getProperty("i18n")))
				return impl.create(element);
			
			return new WrappedPlainView(element, true/* enable word wrap */);
		}
	
		@Override
		public ViewFactory getViewFactory() { return this; }
	
	}

	// package

	// HACK: by default Nimbus does not support a custom background color
	static void fixNimbus(final JEditorPane ep, final String key, final Color background) {
		if (!UI.isNimbus())
			return;

		if (Objects.equals(UI.getClientProperty(ep, MEditorPane.USER_BACKGROUND, null), background))
			return;
		
		ep.putClientProperty(USER_BACKGROUND, background);

		if (backgroundPainter == null) {
			backgroundPainter = new Painter<JEditorPane>() {
				@Override
				public void paint(final Graphics2D g, final JEditorPane c, final int w, final int h) {
					if (c == null)
						return;

					Color bg = UI.getClientProperty(c, MEditorPane.USER_BACKGROUND, null);
					g.setColor(TK.get(bg, Color.WHITE));
					g.fillRect(0, 0, w, h);
				}
			};
		}

		UI.NimbusOverrides no = new UI.NimbusOverrides();
		no.put(key, backgroundPainter);
		no.install(ep, true);
	}

}
