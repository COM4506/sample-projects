// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.util.Hashtable;
import javax.swing.JSlider;

import org.makagiga.commons.MAction;
import org.makagiga.commons.TriBoolean;
import org.makagiga.commons.UI;

/**
 * A slider.
 *
 * @mg.example
 * <pre class="brush: java">
 * MSlider slider = new MSlider();
 *
 * MSlider.Labels labels = new MSlider.Labels();
 * labels.add(Brush.MIN_SIZE, i18n("Small"));
 * labels.add(Brush.MEDIUM_SIZE, i18n("Medium"));
 * labels.add(Brush.MAX_SIZE, i18n("Large"));
 * slider.setLabels(labels);
 *
 * slider.setMinimum(Brush.MIN_SIZE);
 * slider.setMaximum(Brush.MAX_SIZE);
 * slider.setValue(Brush.DEFAULT_SIZE);
 *
 * slider.addChangeListener(e -&gt; ...);
 * </pre>
 *
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MSlider extends JSlider
implements
	UI.EventsControl,
	UI.MouseWheelEventsControl
{

	// private

	private boolean eventsEnabled;
	private boolean mouseWheelEventsEnabled = true;

	// public

	/**
	 * Constructs a slider.
	 */
	public MSlider() {
		addChangeListener(e -> {
			if (getEventsEnabled())
				onChange();
		} );

		addMouseWheelListener(e -> {
			// increments/decrement the slider value
			if (getMouseWheelEventsEnabled() && isEnabled())
				MAction.fire(e, "positiveUnitIncrement", "negativeUnitIncrement", this);
		} );
	}
	
	/**
	 * @deprecated Since 5.2
	 *
	 * @since 2.0
	 */
	@Deprecated
	@Override
	public boolean getEventsEnabled() { return eventsEnabled; }

	/**
	 * @deprecated Since 5.2
	 */
	@Deprecated
	@Override
	public void setEventsEnabled(final boolean value) { eventsEnabled = value; }

	/**
	 * @since 2.0
	 */
	@Override
	public boolean getMouseWheelEventsEnabled() { return mouseWheelEventsEnabled; }
		
	/**
	 * @since 2.0
	 */
	@Override
	public void setMouseWheelEventsEnabled(final boolean value) { mouseWheelEventsEnabled = value; }

	/**
	 * @since 2.0
	 */
	public void setLabels(final Labels labels) {
		setLabelTable(labels);
		setPaintLabels(true);
	}

	/**
	 * @since 3.8.6
	 *
	 * @deprecated Since 5.2
	 */
	@Deprecated
	public void setValue(final int value, final boolean disableEvents) {
		TriBoolean oldEventsEnabled = disableEvents ? TriBoolean.of(eventsEnabled) : TriBoolean.UNDEFINED;
		try {
			if (disableEvents)
				setEventsEnabled(false);
			setValue(value);
		}
		finally {
			if (oldEventsEnabled.isDefined())
				setEventsEnabled(oldEventsEnabled.isTrue());
		}
	}

	public void showSimpleLabels() {
		Labels labels = new Labels();
		labels.add(getMinimum(), "-");
		labels.add(getMaximum(), "+");
		setLabels(labels);
	}
	
	/**
	 * @since 4.0
	 */
	public void showTicks(final int step, final boolean showLabels) {
		int size = getMinimum();
		int max = getMaximum();
		Labels labels = new Labels();
		while (size <= max) {
			if (showLabels)
				labels.add(size);
			else
				labels.add(size, null);
			size += step;
		}
		setLabels(labels);
		setMajorTickSpacing(step);
		setPaintTicks(true);
	}

	// protected

	/**
	 * @deprecated As of 5.2, replaced by #addChangeListener(javax.swing.event.ChangeListener)
	 */
	@Deprecated
	protected void onChange() { }
	
	// public classes
	
	/**
	 * @since 2.0
	 */
	public static class Labels extends Hashtable<Integer, MLabel> {
		
		// public
		
		public Labels() { }
		
		public MLabel add(final int value, final String text) {
			MLabel l = new MLabel(text);
			put(value, l);
			
			return l;
		}
		
		public MLabel add(final int value) {
			return add(value, Integer.toString(value));
		}
		
	}

}
