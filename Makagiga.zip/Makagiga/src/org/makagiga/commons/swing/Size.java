// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.util.function.BiFunction;

import org.makagiga.commons.UI;

/**
 * @since 5.6
 */
@FunctionalInterface
public interface Size extends BiFunction<Component, Dimension, Dimension> {

	// public

	public static Size height(final int value) {
		return (component, size) -> new Dimension(size.width, value);
	}

	public static Size minimumWidth(final int value) {
		return (component, size) -> new Dimension(Math.max(value, size.width), size.height);
	}

	public static Size preferred() {
		return (component, size) -> new Dimension(component.getPreferredSize());
	}

	public static Size preferredHeight() {
		return (component, size) -> new Dimension(size.width, component.getPreferredSize().height);
	}

	public static Size width(final int value) {
		return (component, size) -> new Dimension(value, size.height);
	}

	public static Size windowWidth(final double proportion) {
		return (component, size) -> {
			Window window = UI.windowFor(component);

			if (window == null)
				return new Dimension(size);

			return new Dimension((int)((double)window.getWidth() * proportion), size.height);
		};
	}

}
