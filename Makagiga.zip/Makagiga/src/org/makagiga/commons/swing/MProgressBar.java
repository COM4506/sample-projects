// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeListener;

import org.makagiga.commons.MColor;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;

/**
 * A progress bar.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MProgressBar extends JProgressBar {

	// private
	
	private static final Color DEFAULT_MAXIMUM_COLOR = new Color(0x63BF63/* green */); // derived from 0x6382BF (blue)
	private Color maximumColor = DEFAULT_MAXIMUM_COLOR;
	private Color minimumColor = new Color(0x6382BF/* blue */);

	// public
	
	/**
	 * Constructs a progress bar.
	 */
	public MProgressBar() {
		if (UI.isMetal())
			setBorderPainted(false); // must be called from constructor
	}

	@Override
	public Dimension getPreferredSize() {
		Dimension d = super.getPreferredSize();

		if (UI.isMetal()) {
			if (UI.SizeVariant.MINI.toString().equals(getClientProperty("JComponent.sizeVariant")))
				return new Dimension(d.width, Math.max(1, (int)((double)d.height * 0.5d)));
		}
		
		return d;
	}

	/**
	 * Increases value by one.
	 */
	@Obsolete
	public void step() {
		setValue(getValue() + 1);
	}

	@Override
	public void updateUI() {
		super.updateUI();

		if (UI.isMetal()) {
			setBackground(MColor.WHITE);
			setForeground(calcCurrentColor());
			setBorder(UI.createEmptyBorder(0));

			UI.setStyle("font-size: larger; font-weight: bold", this);
		}
	}

	// protected

	@Override
	protected ChangeListener createChangeListener() {
		ChangeListener original = super.createChangeListener();

		if (!UI.isMetal())
			return original;

		return e -> {
			original.stateChanged(e);

			if (UI.isMetal())
				setForeground(calcCurrentColor());
		};
	}

	// private
	
	private Color calcCurrentColor() {
		if ((minimumColor == null) || (maximumColor == null) || isIndeterminate())
			return DEFAULT_MAXIMUM_COLOR; // not fully initialized yet

		return MColor.interpolate(
			minimumColor,
			maximumColor,
			SimpleProgressBar.calcProgress(getValue(), getMinimum(), getMaximum())
		);
	}

}
