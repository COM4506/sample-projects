// Copyright 2013 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.lang.ref.WeakReference;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.makagiga.commons.MDataAction;
import org.makagiga.commons.TK;

/**
 * @since 4.6
 */
public class MCharsetMenu extends MMenu {

	// private
	
	private Charset selectedCharset;
	private static final String ROOT = "-";
	private WeakReference<MFileChooser> fileChooserRef;

	// public
	
	public MCharsetMenu() {
		this(StandardCharsets.UTF_8);
	}
	
	public MCharsetMenu(final Charset selectedCharset) {
		this.selectedCharset = Objects.requireNonNull(selectedCharset);
	
		Map<String, Set<Charset>> map = createGroupByType();
		
		for (Charset i : map.get(ROOT))
			addRadioButton(new CharsetAction(this, i), i.equals(selectedCharset));
		
		addSeparator();
		
		for (Map.Entry<String, Set<Charset>> entry : map.entrySet()) {
			String key = entry.getKey();

			if (ROOT.equals(key))
				continue; // for
			
			MMenu menu = new MMenu(key);
			for (Charset i : entry.getValue())
				menu.addRadioButton(new CharsetAction(this, i), i.equals(selectedCharset));
			add(menu);
		}
	}
	
	public Charset getSelectedCharset() { return selectedCharset; }
	
	// private
	
	private static void add(final Map<String, Set<Charset>> map, final String group, final Charset charset) {
		map.computeIfAbsent(group, key -> new LinkedHashSet<>())
			.add(charset);
	}
	
	private Map<String, Set<Charset>> createGroupByType() {
		Map<String, Set<Charset>> map = new LinkedHashMap<>();
		
		String misc = i18n("Miscellaneous");
		
		add(map, ROOT, StandardCharsets.UTF_8);
		add(map, ROOT, Charset.defaultCharset());
		add(map, "ISO", StandardCharsets.ISO_8859_1);
		add(map, misc, StandardCharsets.US_ASCII);
		add(map, "Unicode", StandardCharsets.UTF_8); // as first

		for (Charset i : Charset.availableCharsets().values()) {
			String key;
			String name = i.name();
			if (name.startsWith("IBM"))
				key = "IBM";
			else if (name.startsWith("ISO-"))
				key = "ISO";
			else if (name.startsWith("UTF-"))
				key = "Unicode";
			else if (name.startsWith("windows-"))
				key = "Windows";
			else
				key = misc;
			add(map, key, i);
		}

		return map;
	}
	
	// package
	
	MCharsetMenu(final MFileChooser fileChooser) {
		this(fileChooser.getSelectedCharset());
		fileChooserRef = new WeakReference<>(fileChooser);
	}
	
	// private classes
	
	private static final class CharsetAction extends MDataAction<Charset> {
	
		// private
		
		private final MCharsetMenu charsetMenu;
	
		// public
		
		public CharsetAction(final MCharsetMenu charsetMenu, final Charset charset) {
			super(charset, charset.displayName());
			this.charsetMenu = charsetMenu;
		}
		
		@Override
		public void onAction() {
			charsetMenu.selectedCharset = getData();
			
			MFileChooser fileChooser = TK.get(charsetMenu.fileChooserRef);
			if (fileChooser != null)
				fileChooser.setSelectedCharset(charsetMenu.getSelectedCharset());
		}
	
	}

}