// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Font;
import java.awt.font.TextAttribute;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Objects;

import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.DesignPattern;

/**
 * @since 5.2
 */
@DesignPattern(DesignPattern.BUILDER)
public class FontBuilder implements Serializable {

	// private
	
	private boolean bold;
	private boolean italic;
	private boolean lineThrough;
	private boolean smaller;
	private boolean underline;
	private Font _baseFont;
	private Font fontCache;

	// public

	public FontBuilder() { }

	public Font apply(final Component component) {
		Font font = build(component);
		component.setFont(font);
		
		return font;
	}

	public Font build() {
		return build(null);
	}

	public Font build(final Component component) {
		if (fontCache != null)
			return fontCache;

		Font bf;
		if (_baseFont != null)
			bf = _baseFont;
		else if (component != null)
			bf = UI.getFont(component);
		else
			bf = null;

		HashMap<TextAttribute, Object> attr = new HashMap<>(5);

		if (bold)
			attr.put(TextAttribute.WEIGHT, TextAttribute.WEIGHT_BOLD);

		if (italic)
			attr.put(TextAttribute.POSTURE, TextAttribute.POSTURE_OBLIQUE);

		if (lineThrough)
			attr.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);

		if (smaller) {
			if (bf == null)
				throw new IllegalArgumentException("Need base font to calculate a smaller size");
			
			attr.put(TextAttribute.SIZE, TK.limit(bf.getSize() - 1, UI.getMinimumFontSize(), Integer.MAX_VALUE));
		}

		if (underline)
			attr.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);

		fontCache = (bf != null) ? bf.deriveFont(attr) : new Font(attr);

		return fontCache;
	}

	public void clearCache() {
		fontCache = null;
	}

	public FontBuilder setBaseFont(final Font value) {
		if (!Objects.equals(value, _baseFont)) {
			_baseFont = value;
			clearCache();
		}
		
		return this;
	}

	public FontBuilder setBold(final boolean value) {
		if (value != bold) {
			bold = value;
			clearCache();
		}
		
		return this;
	}

	public FontBuilder setItalic(final boolean value) {
		if (value != italic) {
			italic = value;
			clearCache();
		}
		
		return this;
	}

	public FontBuilder setLineThrough(final boolean value) {
		if (value != lineThrough) {
			lineThrough = value;
			clearCache();
		}
		
		return this;
	}

	public FontBuilder setSmaller(final boolean value) {
		if (value != smaller) {
			smaller = value;
			clearCache();
		}
		
		return this;
	}

	public FontBuilder setUnderline(final boolean value) {
		if (value != underline) {
			underline = value;
			clearCache();
		}
		
		return this;
	}

}
