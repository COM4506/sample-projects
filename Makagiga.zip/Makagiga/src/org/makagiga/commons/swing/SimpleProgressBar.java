// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.io.Serializable;
import java.util.Objects;

/**
 * @since 3.8.5, 4.0 (org.makagiga.commons.swing package)
 */
public class SimpleProgressBar implements Serializable {

	// private

	private boolean borderPainted = true;
	//private Color background = Color.BLACK;
	private Color foreground = Color.YELLOW;
	private int maximum;
	private int minimum;
	private int value;
	
	// public
	
	public SimpleProgressBar() { }

/*
	public Color getBackground() { return background; }

	public void setBackground(final Color value) { background = value; }
*/

	public Color getForeground() { return foreground; }

	public void setForeground(final Color value) {
		foreground = Objects.requireNonNull(value);
	}

	public int getMaximum() { return maximum; }

	public void setMaximum(final int value) { maximum = value; }

	/**
	 * @since 5.0
	 */
	public int getMinimum() { return minimum; }

	/**
	 * @since 5.0
	 */
	public void setMinimum(final int value) { minimum = value; }

	/**
	 * @since 5.0
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public float getPercent() {
		return calcProgress(getValue(), getMinimum(), getMaximum()) * 100f;
	}

	public int getValue() { return value; }

	public void setValue(final int value) { this.value = value; }

	public boolean isBorderPainted() { return borderPainted; }

	public void setBorderPainted(final boolean value) { borderPainted = value; }

	public void paint(final Graphics2D g, final int x, final int y, final int w, final int h) {
		if ((w <= 0) || (h <= 0))
			return;

/*
		if (background != null) {
			g.setColor(background);
			g.fillRect(x, y, w, h);
		}
*/

		if (maximum > minimum) {
			g.setColor(foreground);
			if (borderPainted) {
				g.setStroke(new BasicStroke(1.0f));
				g.drawRect(x, y, w, h);
			}
			
			int progressWidth = (int)(((float)w * getPercent()) / 100.0f);
			if (progressWidth > 0)
				g.fillRect(x, y, progressWidth, h);
		}
	}

	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public void step() {
		if (value < maximum)
			value++;
	}

	// package

	static float calcProgress(final int value, final int min, final int max) {
		float total = (float)max - (float)min;

		if (total == 0f)
			return 0f;

		return ((float)value - (float)min) / total;
	}

}
