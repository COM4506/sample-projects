// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;

import org.makagiga.commons.AbstractIterator;
import org.makagiga.commons.Config;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Searchable;
import org.makagiga.commons.Sortable;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.style.StyleSupport;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * A list.
 *
 * @mg.example
 * <pre class="brush: java">
 * MList&lt;String&gt; list = new MList&lt;&gt;();
 * list.addItem("Item 1");
 * list.addItem("Item 2");
 * // sort items by name
 * list.sort();
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MList<I> extends JList<I>
implements
	Config.IntRange,
	Iterable<I>,
	Sortable<I>,
	StyleSupport
{
	
	// public
	
	/**
	 * @since 1.2
	 */
	public enum ActionType {
		NONE,
		ITEM_POPUP_MENU,
		TRIGGER,
		
		/**
		 * @since 2.4
		 *
		 * @deprecated Since 5.0
		 */
		@Deprecated
		SINGLE_CLICK
	}
	
	/**
	 * @since 4.2
	 */
	public static final String AUTO_TEXT = "org.makagiga.commons.swing.MList.AUTO_TEXT";

	// private

	private ActionType actionType = ActionType.NONE;
	private BiConsumer<MList<I>, I> triggerHandler;
	private Consumer<MList<I>> selectHandler;
	private transient Font textFontCache;
	private InputEvent actionEvent;
	private Pattern highlightedText;
	private String text;

	// public

	/**
	 * Constructs a new list with @c DefaultListModel.
	 */
	public MList() {
		this(new DefaultListModel<I>());
	}

	/**
	 * Constructs a new list with @p model.
	 */
	public MList(final ListModel<I> model) {
		super(model);

		StaticHandler<I> handler = new StaticHandler<>();
		addKeyListener(handler);
		addMouseListener(handler);
		getSelectionModel().addListSelectionListener(e -> {
			onSelect();
			if (selectHandler != null)
				selectHandler.accept(this);
		} );
		
		MCellTip.getInstance().install(this);
	}

	/**
	 * @since 4.2
	 */
	@SafeVarargs
	public MList(final I... items) {
		this(new DefaultListModel<I>());
		addAllItems(items);
	}

	/**
	 * @since 3.2
	 */
	public void addActionListener(final ActionListener l) {
		listenerList.add(ActionListener.class, l);
	}

	/**
	 * @since 3.2
	 */
	public ActionListener[] getActionListeners() {
		return listenerList.getListeners(ActionListener.class);
	}

	/**
	 * @since 3.2
	 */
	public void removeActionListener(final ActionListener l) {
		listenerList.remove(ActionListener.class, l);
	}

	/**
	 * Adds all @p items to the list.
	 * 
	 * @throws NullPointerException If @p items is @c null
	 * @throws UnsupportedOperationException If model does not support this operation
	 * 
	 * @since 2.4
	 */
	public void addAllItems(final Collection<? extends I> items) {
		for (I i : items)
			addItem(i);
	}

	/**
	 * Adds all @p items to the list.
	 * 
	 * @throws NullPointerException If @p items is @c null
	 * @throws UnsupportedOperationException If model does not support this operation
	 * 
	 * @since 2.4
	 */
	@SafeVarargs
	public final void addAllItems(final I... items) {
		if (items.length > 0) {
			for (I i : items)
				addItem(i);
		}
	}

	/**
	 * Adds an @p item to the list.
	 * @throws UnsupportedOperationException If model does not support this operation
	 */
	public void addItem(final I item) {
		getDefaultModel().addElement(item);
	}

	/**
	 * Adds an @p item to the list at @p index.
	 * @throws UnsupportedOperationException If model does not support this operation
	 */
	public void addItem(final I item, final int index) {
		getDefaultModel().add(index, item);
	}

	/**
	 * Removes all items.
	 * @throws UnsupportedOperationException If model does not support this operation
	 */
	public void clear() {
		getDefaultModel().clear();
	}
	
	/**
	 * @since 4.0
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public void filter(final MSearchPanel searchPanel, final Collection<I> allItems, final RowFilter<Collection<I>, Integer> rowFilter) {
		clear();
		setHighlightedText("");
		
		if (allItems == null) {
			if (searchPanel != null)
				searchPanel.setState(MSearchPanel.State.NORMAL);
			setText(null);
			
			return;
		}
		
		if (rowFilter == null) {
			addAllItems(allItems);
			if (searchPanel != null)
				searchPanel.setState(MSearchPanel.State.NORMAL);
			setText(null);
			
			return;
		}
		
		int i = 0;
		for (I value : allItems) {
			if (rowFilter.include(new ItemRowFilterEntry(allItems, i++, value))) {
				addItem(value);
			}
		}
		
		if (isEmpty()) {
			if (searchPanel != null) {
				searchPanel.setState(MSearchPanel.State.ERROR);
				setText(i18n("No item found: {0}", searchPanel.getText()));
			}
			else {
				setText(i18n("No item found"));
			}
		}
		else {
			if (searchPanel != null) {
				if (getItemCount() == allItems.size())
					searchPanel.setState(MSearchPanel.State.NORMAL);
				else
					searchPanel.setState(MSearchPanel.State.OK);
				setHighlightedText(searchPanel.getText());
			}
			setText(null);
		}
	}

	/**
	 * @since 5.6
	 */
	public void filter(final MSearchPanel searchPanel, final Collection<I> allItems, final BiPredicate<I, String> filter) {
		Objects.requireNonNull(searchPanel);

		clear();
		setHighlightedText("");
		
		if (TK.isEmpty(allItems)) {
			searchPanel.setState(MSearchPanel.State.NORMAL);
			setText(null);
			
			return;
		}
		
		String filterText = searchPanel.getText();
		
		if ((filter == null) || filterText.isEmpty()) {
			addAllItems(allItems);
			searchPanel.setState(MSearchPanel.State.NORMAL);
			setText(null);
			
			return;
		}
		
		for (I i : allItems) {
			if (filter.test(i, filterText))
				addItem(i);
		}
		
		if (isEmpty()) {
			searchPanel.setState(MSearchPanel.State.ERROR);
			setText(i18n("No item found: {0}", filterText));
		}
		else {
			if (getItemCount() == allItems.size())
				searchPanel.setState(MSearchPanel.State.NORMAL);
			else
				searchPanel.setState(MSearchPanel.State.OK);
			setHighlightedText(filterText);
			setText(null);
		}
	}

	/**
	 * @since 2.4
	 */
	public int findItem(final I item) {
		ListModel<I> model = getModel();
		int size = model.getSize();
		
		if (size == 0)
			return -1;
		
		for (int i = 0; i < size; i++) {
			if (model.getElementAt(i) == item)
				return i;
		}
		
		return -1;
	}

	/**
	 * Returns the current action event.
	 *
	 * @since 1.2
	 */
	public InputEvent getActionEvent() { return actionEvent; }

	/**
	 * Returns the current action type.
	 *
	 * @since 1.2
	 */
	public ActionType getActionType() { return actionType; }

	/**
	 * Returns the default list model.
	 * 
	 * @throws UnsupportedOperationException If model is not an instance of the @c DefaultListModel
	 */
	public DefaultListModel<I> getDefaultModel() {
		ListModel<I> model = getModel();

		if (!(model instanceof DefaultListModel<?>))
			throw new UnsupportedOperationException();
		
		return (DefaultListModel<I>)model;
	}

	/**
	 * @since 5.0
	 */
	public Pattern getHighlightedText() { return highlightedText; }

	/**
	 * @since 5.0
	 */
	public void setHighlightedText(final Pattern value) { highlightedText = value; }

	/**
	 * @since 5.0
	 */
	public void setHighlightedText(final String regex) {
		if (TK.isEmpty(regex))
			setHighlightedText((Pattern)null);
		else
			setHighlightedText(Pattern.compile(Pattern.quote(regex), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE));
	}

	/**
	 * Returns an item at @p index or @c null.
	 */
	public I getItemAt(final int index) {
		return getModel().getElementAt(index);
	}

	/**
	 * Returns an item at @p point or @c null.
	 */
	public I getItemAt(final Point point) {
		int index = locationToIndex(point);

		if (index == -1)
			return null;

		Rectangle r = getCellBounds(index, index);

		if (r == null)
			return null;

		if (!r.contains(point))
			return null;

		return getItemAt(index);
	}

	/**
	 * Returns the number of items.
	 */
	public int getItemCount() {
		return getModel().getSize();
	}

	/**
	 * Returns the first selected item, or @c null if no selection.
	 */
	public I getSelectedItem() {
		return getSelectedValue();
	}
	
	/**
	 * @since 2.0
	 */
	public void setSelectedIndex(final int value, final boolean ensureIndexIsVisible) {
		setSelectedIndex(value);
		if (ensureIndexIsVisible)
			ensureIndexIsVisible(value);
	}

	/**
	 * Selects an item.
	 * @param value An item to select
	 */
	public void setSelectedItem(final I value) {
		setSelectedValue(value, false);
	}

	/**
	 * @since 2.4
	 */
	public void setSelectedItem(final I value, final boolean ensureIndexIsVisible) {
		setSelectedValue(value, ensureIndexIsVisible);
	}

	/**
	 * @since 5.2
	 */
	public boolean setSelectedItem(final Predicate<I> predicate, final boolean ensureIndexIsVisible) {
		for (I i : this) {
			if (predicate.test(i)) {
				setSelectedItem(i, ensureIndexIsVisible);
			
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Returns the selected items, or an empty list if no selection.
	 *
	 * @since 1.2
	 */
	public List<I> getSelectedItems() {
		return getSelectedValuesList();
	}

	/**
	 * @since 2.0
	 */
	public String getText() { return text; }
	
	/**
	 * @since 2.0
	 */
	public void setText(final String value) {
		if (!Objects.equals(text, value)) {
			text = value;
			repaint();
		}
	}

	/**
	 * Returns @c true if list is empty.
	 */
	public boolean isEmpty() {
		return getModel().getSize() == 0;
	}

	/**
	 * Returns the iterator.
	 */
	@Override
	public Iterator<I> iterator() {
		if (isEmpty())
			return Collections.emptyIterator();

		return new AbstractIterator<>(getItemCount(), this::getItemAt);
	}
	
	/**
	 * @since 5.0
	 */
	public void onSelect(final Consumer<MList<I>> selectHandler) {
		if (this.selectHandler != null)
			MLogger.warning("core", "Replacing old onSelect handler: %s -> %s", this.selectHandler, selectHandler);

		this.selectHandler = selectHandler;
	}

	/**
	 * @since 5.2
	 */
	public void onTrigger(final BiConsumer<MList<I>, I> triggerHandler) {
		if (this.triggerHandler != null)
			MLogger.warning("core", "Replacing old onTrigger handler: %s -> %s", this.triggerHandler, triggerHandler);

		this.triggerHandler = triggerHandler;
	}

	/**
	 * Removes an item.
	 * @param item An item ro remove
	 * @throws UnsupportedOperationException If model does not support this operation
	 */
	public boolean removeItem(final I item) {
		return getDefaultModel().removeElement(item);
	}

	/**
	 * Removes all items from the specified index.
	 * @param fromIndex An index of the first item to remove
	 * @throws UnsupportedOperationException If model does not support this operation
	 */
	public boolean removeRange(final int fromIndex) {
		int count = getItemCount();

		if (count == 0)
			return false;

		if (fromIndex > count - 1)
			return false;

		try {
			getDefaultModel().removeRange(fromIndex, count - 1);

			return true;
		}
		catch (ArrayIndexOutOfBoundsException | IllegalArgumentException exception) {
			MLogger.exception(exception);

			return false;
		}
	}
	
	/**
	 * @since 2.4
	 */
	public void repaintItem(final I item) {
		int index = findItem(item);
		
		if (index == -1)
			return;
		
		Rectangle r = getCellBounds(index, index);
		if (r != null)
			repaint(r);
	}

	/**
	 * Replaces item at @p index with @p item.
	 * @throws UnsupportedOperationException If model does not support this operation
	 */
	public void replaceItem(final I item, final int index) {
		getDefaultModel().set(index, item);
	}
	
	/**
	 * @since 2.0
	 */
	public void selectRelativeIndex(final int d, final boolean ensureIndexIsVisible) {
		selectRelativeIndex(d, ensureIndexIsVisible, false);
	}

	/**
	 * @since 4.10
	 */
	public void selectRelativeIndex(final int d, final boolean ensureIndexIsVisible, final boolean wrap) {
		int count = getItemCount();
		
		if (count == 0)
			return;
	
		int newIndex = getSelectedIndex() + d;
		if (newIndex < 0)
			newIndex = wrap ? count - 1 : 0;
		else if (newIndex > count - 1)
			newIndex = wrap ? 0 : count - 1;
		setSelectedIndex(newIndex, ensureIndexIsVisible);
	}

	/**
	 * @since 2.4
	 */
	public void setCellRenderer(final ListCellRenderer<? super I> renderer, final I prototypeCellValue) {
		setCellRenderer(renderer);
		setPrototypeCellValue(prototypeCellValue);
	}

	/**
	 * Sets "single selection mode".
	 */
	public void setSingleSelectionMode() {
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	}

	@Override
	public void sort() {
		sort(null);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public void sort(final Comparator<? super I> comparator) {
		ListModel<I> model = getModel();

		if ((model == null) || (model.getClass() != DefaultListModel.class))
			throw new UnsupportedOperationException("\"DefaultListModel\" expected");
		
		int count = model.getSize();

		if (count < 2)
			return;

		I[] array = (I[])new Object[count];
		for (int i = 0; i < count; ++i)
			array[i] = model.getElementAt(i);
		Arrays.sort(array, comparator);
		DefaultListModel<I> newModel = new DefaultListModel<>();
		for (int i = 0; i < count; ++i)
			newModel.addElement(array[i]);
		setModel(newModel);
	}

	@Override
	public void updateUI() {
		if (UI.isQuaqua())
			putClientProperty("Quaqua.List.style", "striped");

		super.updateUI();

		if (textFontCache == null) {
			Font componentFont = UI.getFont(this);
			textFontCache = componentFont.deriveFont(Font.BOLD, Math.min(componentFont.getSize() + 1, 24));
		}
	}

	// Config.IntRange

	/**
	 * @since 3.0
	 */
	@Override
	public Config.IntInfo getIntInfo() {
		return new Config.IntInfo(0, getItemCount() - 1);
	}

	// protected

	/**
	 * @since 3.2
	 */
	protected void fireActionPerformed() {
		TK.fireActionPerformed(this, getActionListeners());
	}
	
	/**
	 * @since 4.2
	 */
	protected boolean isActionTrigger(final KeyEvent e) {
		return TK.isKeyStroke(e, VK_SPACE);
	}

	/**
	 * @see #getActionType()
	 *
	 * @since 1.2
	 */
	protected void onAction() { }
	
	@Obsolete
	protected void onSelect() { }

	@Override
	protected void paintComponent(final Graphics graphics) {
		super.paintComponent(graphics);
		if (isEmpty()) {
			String s = AUTO_TEXT.equals(text) ? i18n("No Items") : text;
			if (!TK.isEmpty(s))
				paintListText((Graphics2D)graphics, s);
		}
	}

	// private
	
	private boolean canShowPopupMenu(final I item) {
		if (item == null)
			return false;

		if (isSelectionEmpty())
			return false;
		
		if (
			(getSelectionMode() == ListSelectionModel.SINGLE_SELECTION) &&
			(getSelectedItem() != item)
		)
			return false;
		
		return true;
	}
	
	private void doAction(final ActionType actionType, final InputEvent actionEvent) {
		try {
			this.actionType = actionType;
			this.actionEvent = actionEvent;

			if ((actionType == ActionType.TRIGGER) && (triggerHandler != null)) {
				I item = getSelectedItem();
				if (item != null)
					triggerHandler.accept(this, item);
			}

			onAction();
			fireActionPerformed();
		}
		finally {
			this.actionType = ActionType.NONE;
			this.actionEvent = null;
		}
	}

	private void paintListText(final Graphics2D g, final String text) {
		if (textFontCache != null)
			g.setFont(textFontCache);
		
		FontMetrics metrics = g.getFontMetrics();
		int w = metrics.stringWidth(text);
		int h = metrics.getHeight();
		int x = (getWidth() / 2) - (w / 2);
		int y = (getHeight() - h) / 2 + metrics.getAscent();

		// draw background
		Rectangle r = new Rectangle(x - 5, ((getHeight() - h) / 2) - 5, w + 10, h + 10);
		Color background = TK.get(getSelectionBackground(), Color.WHITE);
		g.setColor(UI.isRetro() ? background : MColor.getBrighter(background));
		g.fillRect(r.x, r.y, r.width, r.height);
		if (!UI.isRetro()) {
			g.setColor(background);
			g.drawRect(r.x - 1, r.y - 1, r.width + 1, r.height + 1);
		}

		// draw text
		Color foreground = TK.get(getSelectionForeground(), Color.BLACK);
		g.setColor(UI.isRetro() ? foreground : MColor.getBrighter(foreground));
		UI.setTextAntialiasing(g, null);
		g.drawString(text, x, y);
	}
	
	// public classes
	
	/**
	 * @since 3.0
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public static abstract class Filter<I, F> extends RowFilter<Collection<I>, Integer> {
		
		// private
		
		private final F filter;
		
		// public
		
		public Filter(final F filter) {
			this.filter = filter;
		}
		
		/**
		 * @since 4.0
		 */
		public F getFilter() { return filter; }
		
		public abstract boolean include(final I item);

		@Override
		@SuppressWarnings("unchecked")
		public boolean include(final Entry<? extends Collection<I>, ? extends Integer> entry) {
			return include((I)entry.getValue(0));
		}
		
	}

	/**
	 * @since 3.8
	 *
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public static class SearchableFilter<I extends Searchable<F>, F> extends Filter<I, F> {

		// private

		private final Set<Searchable.Matches> options;

		// public

		public SearchableFilter(final F filter) {
			this(filter, Searchable.DEFAULT_SEARCH_OPTIONS);
		}

		public SearchableFilter(final F filter, final Set<Searchable.Matches> options) {
			super(filter);
			this.options = options;
		}

		@Override
		public boolean include(final I item) {
			return item.matches(getFilter(), options);
		}

	}

	// private classes
	
	private final class ItemRowFilterEntry extends RowFilter.Entry<Collection<I>, Integer> {
		
		// private

		private final Collection<I> model;
		private final I value;
		private final Integer identifier;
		
		// public
		
		@Override
		public Integer getIdentifier() { return identifier; }
		
		@Override
		public Collection<I> getModel() { return model; }
		
		@Override
		public Object getValue(final int columnIndex) { return value; }
		
		@Override
		public int getValueCount() { return 1; }
		
		// private
		
		private ItemRowFilterEntry(final Collection<I> model, final int identifier, final I value) {
			this.model = model;
			this.identifier = identifier;
			this.value = value;
		}
		
	}

	private static final class StaticHandler<I> extends MMouseAdapter implements KeyListener {

		// public

		@Override
		public void keyPressed(final KeyEvent e) {
			@SuppressWarnings("unchecked")
			MList<I> list = (MList<I>)e.getSource();
			if (UI.isPopupTrigger(e) && list.canShowPopupMenu(list.getSelectedItem())) {
				list.doAction(ActionType.ITEM_POPUP_MENU, e);
				e.consume();
			}
			else if (list.isActionTrigger(e)) {
				list.doAction(ActionType.TRIGGER, e);
				e.consume();
			}
		}

		@Override
		public void keyTyped(final KeyEvent e) { }

		@Override
		public void keyReleased(final KeyEvent e) { }

		@Override
		public void mouseClicked(final MouseEvent e) {
			if (isLeft(e)) {
				@SuppressWarnings("unchecked")
				MList<I> list = (MList<I>)e.getSource();
				I item = list.getItemAt(e.getPoint());
				if (item != null) {
					switch (e.getClickCount()) {
						// single click
						case 1:
							list.doAction(ActionType.SINGLE_CLICK, e);
							e.consume();
							break;
						// double click
						case 2:
							list.doAction(ActionType.TRIGGER, e);
							e.consume();
							break;
					}
				}
			}
		}

		@Override
		public void popupTrigger(final MouseEvent e) {
			@SuppressWarnings("unchecked")
			MList<I> list = (MList<I>)e.getSource();
			I item = list.getItemAt(e.getPoint());

			if (item == null)
				return;

			if (
				(
					(list.getSelectionMode() == ListSelectionModel.SINGLE_SELECTION) &&
					(list.getSelectedItem() != item)
				) ||
				list.isSelectionEmpty()
			)
				list.setSelectedItem(item);

			if (list.canShowPopupMenu(item)) {
				list.doAction(ActionType.ITEM_POPUP_MENU, e);
				e.consume();
			}
		}

	}

}
