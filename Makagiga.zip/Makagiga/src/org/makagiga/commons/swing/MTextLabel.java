// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.UIManager;
import javax.swing.plaf.TextUI;
import javax.swing.plaf.basic.BasicTextFieldUI;

import org.makagiga.commons.UI;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MTextLabel extends MTextField {
	
	// public
	
	public MTextLabel() {
		this(null);
	}
	
	public MTextLabel(final String text) {
		super(text);
		setEditable(false);
		setStyle("cursor: text");
		setText(text);
	}
	
	@Override
	public void setText(final String value) {
		super.setText(value);
		setCaretPosition(0);
	}

	@Override
	public void updateUI() {
		setUI((TextUI)BasicTextFieldUI.createUI(this));
		setBackground(null);
		setBorder(null);
		setOpaque(false);

		if (UI.isRetro()) {
			Font font = UIManager.getFont("Retro.font");
			setFont((font == null) ? UI.createDefaultFont() : font);
			setForeground(UIManager.getColor("text"));
		}
		else if (UI.isSeaGlass()) {
			setFont(UI.createDefaultFont());
			setSelectionColor(UI.getSelectionBackground());
			setSelectedTextColor(UI.getSelectionForeground());
		}
		else if (UI.isNimbus()) {
			setForeground(UIManager.getColor("text"));
			setSelectionColor(UI.getSelectionBackground());
			setSelectedTextColor(UI.getSelectionForeground());
		}
	}
	
	// protected
	
	/**
	 * Overriden to enable text antialiasing
	 * for {@code BasicTextFieldUI}.
	 */
	@Override
	protected void paintComponent(final Graphics g) {
		UI.setTextAntialiasing((Graphics2D)g, null);
		super.paintComponent(g);
	}
	
}
