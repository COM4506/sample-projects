// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.AWTPermission;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JToolTip;
import javax.swing.KeyStroke;

import org.makagiga.commons.Config;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.mods.Mods;
import org.makagiga.commons.security.MAccessController;

/**
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MNotification implements Iterable<MNotification.Message> {
	
	// public
	
	/**
	 * Invoked from the {@code MNotification} constructor.
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.1
	 */
	public static final String MOD_INIT = "init@org.makagiga.commons.swing.MNotification";

	/**
	 * Invoked on message view update.
	 *
	 * <ul>
	 * <li>Arg 0: {@link Message} - the current message</li>
	 * </ul>
	 *
	 * @see org.makagiga.commons.mods.Mods

	 * @since 3.8.1
	 */
	public static final String MOD_UPDATE_VIEW = "updateView@org.makagiga.commons.swing.MNotification";
	
	// private

	private final ActionGroup actionGroup;
	private boolean needUpdate = true;
	private int lastMessagesCount;
	private static final KeyStroke CLOSE_MESSAGE_KEY_STROKE = KeyStroke.getKeyStroke(VK_SEMICOLON, MAction.getMenuMask() | SHIFT_MASK);
	private final MArrayList<Message> messages = new MArrayList<>();
	private final MLabel count;
	private final MLabel icon;
	private final MLabel text;
	private final MLabel title;
	private static MNotification _instance;
	private final MPanel mainPanel;
	private final MPanel northPanel;
	private final MProgressBar timeout;
	private final MSmallButton closeButton;
	private final PopupWindow popupWindow;
	
	// public
	
	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public synchronized void addMessage(final Message message) {
		Objects.requireNonNull(message);
		
		if (message._timeout == -1) {
			needUpdate = messages.isEmpty();
			messages.add(message);
			updateWindow(messages.size() == 1);
		}
		else {
			needUpdate = true;
			messages.add(0, message);
			updateWindow(true);
		}
	}
	
	/**
	 * @since 4.2
	 */
	public static MMenu createMenu() {
		MMenu menu = new MMenu(i18n("Notifications"));
		menu.onSelect(self -> {
			if (self.isEmpty())
				MNotification.getInstance().actionGroup.updateMenu(self);
		} );
		
		return menu;
	}
	
	/**
	 * Returns the @b close button or @c null.
	 *
	 * @since 3.4
	 */
	public MButton getCloseButton() { return closeButton; }

	/**
	 * Returns the {@code count} label.
	 *
	 * @since 3.4
	 */
	public MLabel getCountLabel() { return count; }
	
	/**
	 * @since 4.6
	 */
	public static int getDefaultTimeout() { return 10000; }

	/**
	 * Returns the @b icon label or @c null.
	 *
	 * @since 3.4
	 */
	public MLabel getIconLabel() { return icon; }

	/**
	 * Returns the main panel.
	 *
	 * @since 3.4
	 */
	public MPanel getMainPanel() { return mainPanel; }

	public synchronized static MNotification getInstance() {
		if (_instance == null)
			_instance = MAccessController.doPrivileged(MNotification::new);
		
		return _instance;
	}
	
	/**
	 * @since 2.0
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public static int getMessageCount() {
		synchronized (MNotification.class) {
			return (_instance == null) ? 0 : _instance.messages.size();
		}
	}

	/**
	 * Returns the timeout progress bar or @c null.
	 *
	 * @since 3.4
	 */
	public MProgressBar getProgressBar() { return timeout; }

	/**
	 * Returns the @b text label or @c null.
	 *
	 * @since 3.4
	 */
	public MLabel getTextLabel() { return text; }

	/**
	 * Returns the @b title label or @c null.
	 *
	 * @since 3.4
	 */
	public MLabel getTitleLabel() { return title; }

	/**
	 * @since 2.0
	 */
	public static void hideMessage(final Class<? extends Action> actionClass) {
		if (isEmpty())
			return;
		
		MNotification notification = MNotification.getInstance();
		for (MNotification.Message i : notification) {
			Action a = i.getAction();
			if ((a != null) && (a.getClass() == actionClass))
				notification.hideMessage(i);
		}
	}

	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public synchronized void hideMessage(final Message message) {
		needUpdate = true;
		
		messages.remove(Objects.requireNonNull(message));
		message.shutDown();
		
		updateWindow(false);
	}

	/**
	 * @since 4.6
	 */
	public static boolean isEmpty() {
		synchronized (MNotification.class) {
			return (_instance == null) ? true : _instance.messages.isEmpty();
		}
	}

	/**
	 * @since 2.0
	 */
	public static Message showError(final String text) {
		return showMessage(i18n("Error"), text, "ui/error");
	}

	/**
	 * @since 2.0
	 */
	public static Message showInfo(final String text) {
		return showMessage(i18n("Information"), text, "ui/info");
	}

	/**
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public static Message showMessage(final Message message) {
		getInstance().addMessage(message);
		
		return message;
	}
	
	public static Message showMessage(final String title, final String text, final Icon icon) {
		Message message = new Message(title, text, icon);
		getInstance().addMessage(message);

		return message;
	}

	public static Message showMessage(final String title, final String text, final String iconName) {
		return showMessage(title, text, MIcon.medium(iconName));
	}
	
	public static Message showWarning(final String text) {
		return showMessage(i18n("Warning"), text, "ui/warning");
	}
	
	/**
	 * @since 2.0
	 *
	 * @deprecated Since 4.6
	 */
	@Deprecated
	public void updateMessage(final Message message) {
		updateMessage(message, true);
		updateSizeAndPosition(false);
	}
	
	// Iterable
	
	/**
	 * @since 2.0
	 */
	@Override
	public Iterator<MNotification.Message> iterator() {
		@SuppressWarnings("unchecked")
		List<Message> copy = (List<Message>)messages.clone();

		return copy.iterator();
	}

	// protected
	
	protected MNotification() {
		popupWindow = new PopupWindow();

		mainPanel = MPanel.createBorderPanel(0);
		popupWindow.addCenter(mainPanel);
		
		northPanel = MPanel.createHBoxPanel();
		northPanel.setOpaque(true);
		
		title = new MLabel() {
			@Override
			public JToolTip createToolTip() {
				JToolTip toolTip = super.createToolTip();
				MNotification.Message message = MNotification.getInstance().getCurrentMessage();
				UI.setHTMLEnabled(toolTip, (message != null) && message.isHTMLEnabled());
				
				return toolTip;
			}
			@Override
			public Dimension getMinimumSize() {
				// HACK: fix popup window width
				return new Dimension(0, 0);
			}
			@Override
			public Point getToolTipLocation(final MouseEvent e) {
				return UI.ToolTipLocationPolicy.ABOVE.getLocation(this, e);
			}
		};
		title.setBorder(UI.createEmptyBorder(3));
		northPanel.add(title);

		count = MLabel.createSmall(null);
		count.setBorder(UI.createEmptyBorder(3));
		count.setOpaque(true);
		count.setStyle("cursor: move; font-weight: bold");

		northPanel.addStretch();
		northPanel.addGap();
		northPanel.add(count);

		MAction closeMessageAction = new MAction(i18n("Close Message"), "ui/close",
			self -> closeCurrent()
		);
		closeMessageAction.setAcceleratorKey(CLOSE_MESSAGE_KEY_STROKE);

		closeButton = new MSmallButton(closeMessageAction, false) {
			@Override
			protected void updateUIStyle() {
				this.setStyle("margin: 0; padding: 0");
			}
		};
		closeButton.setHorizontalTextPosition(UI.LEADING);
		closeButton.setText(i18n("Close"));
		northPanel.addGap();
		northPanel.add(closeButton);
		
		icon = new MLabel();
		icon.setBorder(UI.createEmptyBorder(4));
		mainPanel.addWest(icon);

		mainPanel.addNorth(northPanel);
		
		text = new MLabel();
		text.setBorder(UI.createEmptyBorder(4));
		mainPanel.addCenter(text);
		
		timeout = new MProgressBar();
		UI.SizeVariant.MINI.apply(timeout);
		timeout.setMinimum(0);
		mainPanel.addSouth(timeout);

		// window dragging and mouse support
		ComponentDragAdapter dragAdapter = new ComponentDragAdapter() {
			private boolean dragged;
			private Insets screenInsets;
			private Dimension screenSize;
			@Override
			public void adjustNewLocation(final Point p) {
				MNotification.PopupWindow popupWindow = MNotification.this.popupWindow;
			
				int snapSize = 5;
			
				// snap to left/right edge of the screen
				int right = screenSize.width - popupWindow.getWidth() - screenInsets.right;
				if (p.x < screenInsets.left + snapSize) {
					p.x = screenInsets.left;
					UI.horizontalNotificationPosition.set(UI.HorizontalPosition.LEFT);
				}
				else if (p.x >= right - snapSize) {
					p.x = right;
					UI.horizontalNotificationPosition.set(UI.HorizontalPosition.RIGHT);
				}
			
				// snap to top/bottom edge of the screen
				int bottom = screenSize.height - popupWindow.getHeight() - screenInsets.bottom;
				if (p.y < screenInsets.top + snapSize) {
					p.y = screenInsets.top;
					UI.verticalNotificationPosition.set(UI.VerticalPosition.TOP);
				}
				else if (p.y >= bottom - snapSize) {
					p.y = bottom;
					UI.verticalNotificationPosition.set(UI.VerticalPosition.BOTTOM);
				}
			}
			@Override
			public void buttonClicked/*mouseClicked*/(final MouseEvent e) {
				// execute action
				if (!dragged && !e.isConsumed() && (isLeft(e) || isMiddle(e)) && isActionTrigger(e)) {
					e.consume();
					MNotification.this.executeMessageAction(e.getSource(), e);
				}
			}
			@Override
			public void mouseDragged(final MouseEvent e) {
				if (isActionTrigger(e))
					return;

				dragged = true;
			
				if (Kiosk.notificationLocked.get())
					return;

				super.mouseDragged(e);
			}
			@Override
			public void mouseEntered(final MouseEvent e) {
				super.mouseEntered(e);
				
				// stop auto hide
				MNotification.Message m = MNotification.this.getCurrentMessage();
				if ((m != null) && (m.timeoutAnimation != null)) {
					m.timeoutAnimation = TK.dispose(m.timeoutAnimation);
					MNotification.this.timeout.setVisible(false);
				}
			}
			@Override
			public void mousePressed(final MouseEvent e) {
				dragged = false;
			
				if (Kiosk.notificationLocked.get()) {
					super.mousePressed(e);

					return;
				}

				screenInsets = UI.getScreenInsets();
				screenSize = UI.getScreenSize();

				super.mousePressed(e);
			}
			@Override
			public void mouseReleased(final MouseEvent e) {
				if (dragged) {
					super.mouseReleased(e);

					if (Kiosk.notificationLocked.get())
						return;

					Config.getDefault().sync();
				}
				else {
					super.mouseReleased(e);
				}
				
				dragged = false;
			}
			@Override
			public void popupTrigger(final MouseEvent e) {
				if (!dragged)
					MNotification.this.showPopupMenu(e);
			}
			private boolean isActionTrigger(final MouseEvent e) {
				return (e.getComponent() == icon) || (e.getComponent() == mainPanel) || (e.getComponent() == text);
			}
		};
		dragAdapter.setMoveCursor(false);
		dragAdapter.install(northPanel);
		dragAdapter.install(title);
		dragAdapter.install(count);
		UI.setStyle("cursor: move", northPanel, title);

		dragAdapter.install(icon);
		dragAdapter.install(mainPanel);
		dragAdapter.install(text);
		UI.setStyle("cursor: hand", icon, mainPanel, text);

		actionGroup = new ActionGroup() {
			@Override
			public void update() {
				boolean empty = MNotification.this.messages.isEmpty();
				this.setEnabled("next-message", !empty);
				this.setEnabled("close-message", !empty);
				this.setEnabled("close-all-messages", !empty);
			}
		};
		
		MAction nextMessageAction = new MAction(i18n("Next Message"), "ui/next",
			self -> executeMessageAction(self.getSource(), null)
		); 
		nextMessageAction.setAcceleratorKey(VK_QUOTE, MAction.getMenuMask());
		actionGroup.add("next-message", nextMessageAction);
		
		actionGroup.addSeparator();

		actionGroup.add("close-message", closeMessageAction);

		actionGroup.add("close-all-messages", new MAction(i18n("Close All Messages"), action -> {
			closeAll();
		} ));

		actionGroup.update();
		
// FIXME: bind should use action ID instead of its name
		// HACK: <MAction>
		MainView.bind(actionGroup.<MAction>getAction("next-message"));
		MainView.bind(actionGroup.<MAction>getAction("close-message"));
		//MainView.bind(actionGroup.getAction("close-all-messages"));

		Mods.exec(this, MOD_INIT);
	}

	protected static void closeAll() {
		synchronized (MNotification.class) {
			if (_instance != null) {
				for (Message i : _instance.messages)
					i.shutDown();
				_instance.messages.clear();
				_instance.lastMessagesCount = 0;
				_instance.actionGroup.update();
				if (_instance.popupWindow != null) {
					AccessController.doPrivileged((PrivilegedAction<Void>)() -> {
						_instance.popupWindow.dispose();

						return null;
					}, null, new AWTPermission("accessEventQueue"));

					_instance.popupWindow.setSize(1, 1); // reset maximum size
				}
			}
		}
	}

	protected void closeCurrent() {
		Message m = getCurrentMessage();
		if (m != null)
			hideMessage(m);
	}
	
	protected Message getCurrentMessage() {
		return messages.isEmpty() ? null : messages.getFirst();
	}
	
	protected void showPopupMenu(final MouseEvent e) {
		MMenu menu = new MMenu();
		menu.add(new MAction(MActionInfo.CLOSE.noKeyStroke(), action -> {
			closeCurrent();
		} ));
		menu.add(new MAction(MActionInfo.CLOSE_ALL.noKeyStroke(), action -> {
			MNotification.closeAll();
		} ));
		
		menu.addSeparator();
		
		menu.addCheckBox(new MAction(i18n("Transparent"), action -> {
			if (popupWindow != null) {
				UI.notificationTransparent.set(action.isSelected());
				popupWindow.updateTransparent();

				Config.getDefault().sync();
			}
		} ), UI.notificationTransparent.get())
			.setEnabled(
				(popupWindow != null) &&
				popupWindow.isTransparentOptionSupported() &&
				!Kiosk.notificationLocked.get()
			);

		menu.showPopup(e);
	}

	/**
	 * @since 2.0
	 */
	protected synchronized void updateMessage(final Message message, final boolean forceUpdate) {
		if (!forceUpdate && !needUpdate)
			return;

		if (getCurrentMessage() != message)
			return;

		needUpdate = false;

		// set colors
		Color bg = message.getColor();
		Color fg = MColor.getContrastBW(bg);
		mainPanel.setBorder(BorderFactory.createLineBorder(bg, 1));
		northPanel.setBackground(bg);
		northPanel.setForeground(fg);
		title.setForeground(fg);
		
		ComponentAnimation.stopBackgroundBlend(count);
		count.setBackground(bg);
		count.setForeground(fg);

		closeButton.setForeground(fg);

		boolean allowHTML = message.isHTMLEnabled();
		title.setHTMLEnabled(allowHTML);
		text.setHTMLEnabled(allowHTML);
		
		icon.setIcon(message.icon);
		icon.setVisible(message.icon != null);

		String appName = MApplication.getFullName();
		String titleText = Objects.toString(message.title, "");
		// append application name to the popup title
		if (!titleText.equals(appName)) {
			if (!TK.isEmpty(titleText))
				titleText += " - ";
			titleText += appName;
		}

		title.setText(titleText);
		title.setToolTipText(titleText);
		closeButton.setVisible(message.closeButtonVisible);

		if (TK.isEmpty(message.text)) {
			text.setText(null);
			text.setVisible(false);
		}
		else {
			text.setText(message.text);
			text.setVisible(true);
		}
		
		BorderLayout mainLayout = (BorderLayout)mainPanel.getLayout();
		Component c = mainLayout.getLayoutComponent(BorderLayout.CENTER);
		if (c != null)
			mainPanel.remove(c);
		if (message.component == null)
			mainPanel.addCenter(text);
		else
			mainPanel.add(message.component, BorderLayout.CENTER);

		updateTimeoutProgressBar(message);

		Mods.exec(this, MOD_UPDATE_VIEW, message);
	}
	
	/**
	 * @since 2.0
	 */
	protected void updateSizeAndPosition(final boolean paintAll) {
		if (popupWindow != null) {
			popupWindow.updateTransparent();

			Dimension pref = popupWindow.getPreferredSize();
			Insets screenInsets = UI.getScreenInsets();
			Dimension screenSize = UI.getScreenSize();
				
			pref.width = TK.limit(pref.width, popupWindow.getWidth(), Math.min(screenSize.width / 2, 500));
			popupWindow.setSize(pref);
			
			int x = popupWindow.getX();
			int y = popupWindow.getY();
			
			// snap to left/right edge of the screen
			int right = screenSize.width - popupWindow.getWidth() - screenInsets.right;
			if (x < screenInsets.left)
				UI.horizontalNotificationPosition.set(UI.HorizontalPosition.LEFT);
			else if (x >= right)
				UI.horizontalNotificationPosition.set(UI.HorizontalPosition.RIGHT);
			
			// snap to top/bottom edge of the screen
			int bottom = screenSize.height - popupWindow.getHeight() - screenInsets.bottom;
			if (y < screenInsets.top)
				UI.verticalNotificationPosition.set(UI.VerticalPosition.TOP);
			else if (y >= bottom)
				UI.verticalNotificationPosition.set(UI.VerticalPosition.BOTTOM);
				
			popupWindow.showAtPosition(
				UI.verticalNotificationPosition.get(),
				UI.horizontalNotificationPosition.get(),
				false
			);
		}
		if (paintAll)
			paintImmediately();
	}
	
	/**
	 * @since 3.0
	 */
	protected void updateTimeoutProgressBar(final Message message) {
		if (message._timeout == -1) {
			timeout.setVisible(false);
		}
		else {
			timeout.setMaximum(message._timeout);
			timeout.setValue(message._currentTimeout);
			timeout.setVisible(true);
		}
	}

	/**
	 * @since 2.0
	 */
	protected void updateWindow(final boolean paintAll) {
		actionGroup.update();
	
		// no more message; dispose window
		if (messages.isEmpty()) {
			closeAll();
			lastMessagesCount = 0;
		
			return;
		}
		
		int messagesCount = messages.size();
		if (messagesCount > 1) {
			count.setText("+" + (messagesCount - 1));
			count.setVisible(getCurrentMessage().countInfoVisible);
		}
		else {
			count.setText(null);
			count.setVisible(false);
		}
		
		updateMessage(getCurrentMessage(), false);
		updateSizeAndPosition(paintAll);

		// after "updateMessage"
		if (UI.animations.booleanValue() && count.isVisible() && (messagesCount > lastMessagesCount)) {
			Color from = MColor.getContrastBW(UI.getForeground(count));
			ComponentAnimation.blendBackgroundProperty(count, from, northPanel.getBackground());
		}
		lastMessagesCount = messagesCount;
	}

	// private

	private synchronized void executeMessageAction(final Object source, final InputEvent e) {
		if (!messages.isEmpty()) {
			needUpdate = true;
			
			Message message = messages.remove(0);
			message.shutDown();
			
			updateWindow(true);
			
			Action action = message.action;
			if (action != null) {
				try {
					message.inputEvent = e;
					MAction.fire(action, source);
				}
				finally {
					message.inputEvent = null;
				}
			}
		}
	}

	private synchronized void paintImmediately() {
		mainPanel.paintImmediately(mainPanel.getBounds());
	}
	
	private synchronized boolean toFront(final Message message) {
		int index = messages.indexOf(message);
		
		if ((index == -1) || (index == 0)/* already in front */)
			return false;
		
		messages.remove(message);
		messages.add(0, message);
		needUpdate = true;
		updateMessage(message);
		
		return true;
	}

	// public classes
	
	public static class Message implements MIcon.Name {
		
		// private
		
		private Action action;
		private boolean closeButtonVisible = true;
		private boolean countInfoVisible = true;
		private Color color;
		private Component component;
		private ComponentAnimation timeoutAnimation;
		private Icon icon;
		private InputEvent inputEvent;
		private int _currentTimeout = -1;
		private int _timeout = -1;
		private Object userObject;
		private String title;
		private String text;
		
		// public
		
		/**
		 * @since 2.0
		 */
		public Message() {
			this(null, null, (Icon)null);
		}
		
		/**
		 * @since 2.0
		 */
		public Message(final Action action) {
			setAction(action);
		}
		
		public Message(final String title, final String text, final String iconName) {
			this(title, text, MIcon.medium(iconName));
		}

		public Message(final String title, final String text, final Icon icon) {
			this.title = title;
			this.text = text;
			this.icon = icon;
		}
		
		public Action getAction() { return action; }

		@InvokedFromConstructor
		public void setAction(final Action value) {
			action = value;
			if (action == null) {
				title = null;
				text = null;
				icon = null;
			}
			else {
				title = MAction.getValue(action, Action.NAME, null);
				text = MAction.getToolTipText(action);
				icon = MAction.getIcon(action, MIcon.Size.MEDIUM);
			}
		}
		
		/**
		 * @since 4.6
		 */
		public Color getColor() {
			if (color != null)
				return color;
			
			String iconName = MIcon.getName(icon);

			if ("ui/error".equals(iconName))
				return MHighlighter.ERROR_COLOR;

			if ("ui/info".equals(iconName))
				return MHighlighter.INFO_COLOR;

			if ("ui/warning".equals(iconName))
				return MHighlighter.WARNING_COLOR;
		
			return MApplication.getLightBrandColor();
		}

		/**
		 * @since 4.6
		 */
		public void setColor(final Color value) { color = value; }

		/**
		 * @since 4.8
		 */
		public Component getComponent() { return component; }

		/**
		 * @since 4.8
		 */
		public void setComponent(final Component value) { component = value; }

		/**
		 * @since 2.0
		 */
		public Icon getIcon() { return icon; }

		/**
		 * @since 2.0
		 */
		public void setIcon(final Icon value) { icon = value; }

		/**
		 * Returns the input event that invoked this action, or @c null.
		 *
		 * @since 3.6
		 */
		public InputEvent getInputEvent() { return inputEvent; }

		/**
		 * @since 2.0
		 */
		public String getText() { return text; }

		/**
		 * @since 2.0
		 */
		public void setText(final String value) { text = value; }
		
		/**
		 * @since 3.0
		 */
		public int getTimeout() { return _timeout; }

		/**
		 * @since 3.0
		 */
		public void setTimeout(int value) {
			if (value == -1)
				value = MNotification.getDefaultTimeout();
			if (value != _timeout) {
				timeoutAnimation = TK.dispose(timeoutAnimation);

				_timeout = value;
				_currentTimeout = _timeout;
				
				if (_timeout != -1) {
					MNotification notification = MNotification.getInstance();
					timeoutAnimation = new ComponentAnimation(notification.timeout)
						.duration(_timeout)
						.integerProperty(
							"currentTimeout",
							_currentTimeout, 0,
							() -> _currentTimeout,
							newValue -> {
								_currentTimeout = newValue;
								if (notification.messages.getFirst() == this)
									notification.updateTimeoutProgressBar(this);
							}
						)
						.onDone(self -> {
							if (notification.messages.getFirst() == this)
								hide();
							timeoutAnimation = null;
						} )
						.play();
				}
			}
		}

		/**
		 * @since 2.0
		 */
		public String getTitle() { return title; }

		/**
		 * @since 2.0
		 */
		public void setTitle(final String value) { title = value; }

		/**
		 * @since 2.0
		 */
		public Object getUserObject() { return userObject; }
		
		/**
		 * @since 2.0
		 */
		public void setUserObject(final Object value) { userObject = value; }

		/**
		 * @since 4.6
		 */
		public void hide() {
			MNotification.getInstance().hideMessage(this);
		}

		public boolean isCloseButtonVisible() { return closeButtonVisible; }
		
		public void setCloseButtonVisible(final boolean value) { closeButtonVisible = value; }

		public boolean isCountInfoVisible() { return countInfoVisible; }
		
		public void setCountInfoVisible(final boolean value) { countInfoVisible = value; }

		/**
		 * @since 4.6
		 */
		public void show() {
			MNotification.showMessage(this);
		}

		/**
		 * @since 4.2
		 */
		public boolean toFront() {
			return MNotification.getInstance().toFront(this);
		}

		/**
		 * @since 4.6
		 */
		public void update() {
			MNotification.getInstance().updateMessage(this);
		}
		
		// MIcon.Name
		
		/**
		 * @since 4.8
		 */
		@Override
		public String getIconName() {
			return MIcon.getName(getIcon());
		}

		/**
		 * @since 4.8
		 */
		@Override
		public void setIconName(final String value) {
			setIcon(MIcon.stock(value));
		}

		// protected
		
		/**
		 * @since 3.0
		 */
		protected void onClose() { }
		
		// private
		
		private boolean isHTMLEnabled() {
			return
				!(action instanceof MAction) ||
				MAction.class.cast(action).isHTMLEnabled();
		}
		
		private void shutDown() {
			onClose();
			timeoutAnimation = TK.dispose(timeoutAnimation);
		}

	}
	
	// private classes
	
	private static final class PopupWindow extends MWindow {

		// private
		
		private PopupWindow() {
			setAlwaysOnTop(true);
			setModalExclusionType(Dialog.ModalExclusionType.APPLICATION_EXCLUDE);
		}
		
		private boolean isTransparentOptionSupported() {
			GraphicsConfiguration gc = getGraphicsConfiguration();
			
			return (gc != null) && gc.getDevice().isWindowTranslucencySupported(GraphicsDevice.WindowTranslucency.TRANSLUCENT);
		}

		private void updateTransparent() {
			try {
				if (isTransparentOptionSupported())
					setOpacity(UI.notificationTransparent.get() ? 0.85f : 1.0f);
				//else
				//	MLogger.debug("ui", "Window Translucency not supported");
			}
			catch (UnsupportedOperationException exception) {
				MLogger.exception(exception);
			}
		}

	}
	
}
