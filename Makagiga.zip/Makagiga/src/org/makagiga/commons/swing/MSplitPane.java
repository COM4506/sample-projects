// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.beans.ConstructorProperties;
import javax.swing.JComponent;
import javax.swing.JSplitPane;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicSplitPaneDivider;
import javax.swing.plaf.metal.MetalSplitPaneUI;

import org.makagiga.commons.UI;

/**
 * A split pane.
 *
 * Defaults:
 * - Horizontal orientation (left and right component)
 * - border = {@code null}
 * - oneTouchExpandable = {@code false}
 *
 * @mg.note Since version 2.3.2 Beta "continuous layout" property is {@code false} by default.
 *
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public class MSplitPane extends JSplitPane {
	
	// private
	
	private JComponent sidebar;

	// public

	/**
	 * Constructs a split pane.
	 */
	public MSplitPane() {
		this(HORIZONTAL_SPLIT);
	}

	/**
	 * Constructs a split pane.
	 *
	 * Valid orientations:
	 * - @c HORIZONTAL_SPLIT (left and right component)
	 * - @c VERTICAL_SPLIT (top and bottom component)
	 * 
	 * @param orientation the splitter orientation
	 */
	@ConstructorProperties("orientation")
	public MSplitPane(final int orientation) {
		super(orientation);
		setBorder(null);
		setOneTouchExpandable(false);
	}
	
	public JComponent getSidebar() { return sidebar; }
	
	public void setSidebar(final JComponent value) {
		sidebar = value;
		setLeftComponent(sidebar);
	}
	
	public boolean isSidebarVisible() {
		return (sidebar != null) && (getDividerLocation() > 1);
	}

	public void setSidebarVisible(final boolean value) {
		sidebar.setVisible(value);
		if (value) {
			if (!isSidebarVisible()) {
				int i = getLastDividerLocation();
				setLastDividerLocation((i <= 1) ? -1 : i);
				setDividerLocation(getLastDividerLocation());
			}
		}
		else {
			setDividerLocation(0);
		}
	}

	public boolean toggleSidebar() {
		boolean visible = !isSidebarVisible();
		setSidebarVisible(visible);
		
		return visible;
	}
	
	@Override
	public void updateUI() {
		if (UI.isMetal()) {
			setUI(new NewMetalSplitPaneUI());
			setDividerSize(8);
		}
		else
			super.updateUI();
		
		if (UI.isWindows())
			setDividerSize(8);
	}
	
	// private classes

	// a Metal divider w/o "bumps"
	private static final class NewMetalSplitPaneUI extends MetalSplitPaneUI {
	
		// public
		
		public NewMetalSplitPaneUI() { }
		
		@Override
		public BasicSplitPaneDivider createDefaultDivider() {
			return new BasicSplitPaneDivider(this) {
				@Override
				public void paint(final Graphics graphics) {
					Color bg;
					if ((splitPane != null) && splitPane.isFocusOwner())
						bg = UIManager.getColor("SplitPane.dividerFocusColor");
					else
						bg = UIManager.getColor("ToolBar.background");
					if (bg != null) {
						Graphics2D g = (Graphics2D)graphics;
						g.setColor(bg);
						g.fillRect(0, 0, getWidth(), getHeight());
					}
					super.paint(graphics);
				}
			};
		}

	}

}
