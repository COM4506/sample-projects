// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import static org.makagiga.commons.UI.i18n;

import java.awt.Rectangle;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;
import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import org.makagiga.commons.Config;
import org.makagiga.commons.EnumProperty;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.StringList;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.icons.ShapeIcon;
import org.makagiga.commons.mv.MV;

/**
 * @since 2.4, 4.0 (org.makagiga.commons.swing package)
 */
public class ColumnManager<M extends TableModel> {
	
	// private
	
	private MArrayList<TableColumn> allColumns;
	private MArrayList<TableColumn> defaultColumnOrder;
	private final WeakReference<MTable<M>> tableRef;
	
	// public
	
	public ColumnManager(final MTable<M> table) {
		tableRef = new WeakReference<>(table);
		update();
	}

	/**
	 * @since 3.8.6
	 */
	public JComponent createCornerComponent() {
		MSmallButton cornerComponent = new MSmallButton(ShapeIcon.MENU, MActionInfo.SETTINGS.getDialogTitle());
		cornerComponent.setPopupMenu(this::createMenu);
		cornerComponent.setEnabled(Kiosk.actionSettings.get());
		cornerComponent.setPopupMenuArrowPainted(false);

		return cornerComponent;
	}
	
	/**
	 * @since 3.8.6
	 */
	public MMenu createMenu() {
		MMenu menu = new MMenu(i18n("Columns"), MActionInfo.SETTINGS.getIconName());
		menu.setPopupMenuVerticalAlignment(MMenu.CENTER);

		MTable<M> table = tableRef.get();

		if ((table != null) && (table.getRowSorter() != null))
			createSortMenu(menu, true);

		if (Kiosk.tableColumnReorderingAllowed.booleanValue())
			createVisibleMenu(menu, true);

		if (table != null) {
			menu.addSeparator();

			SaveAsDefaultAction saveAsDefaultAction = new SaveAsDefaultAction(table);
			saveAsDefaultAction.setEnabled(table instanceof Config.GlobalEntry);
			menu.add(saveAsDefaultAction);
		}

		return menu;
	}
	
	/**
	 * @since 3.0
	 */
	public MMenu createSortMenu() {
		MMenu sortMenu = new MMenu(i18n("Sort by Column"));
		MTable<M> table = TK.get(tableRef);
		
		if (table.getRowSorter() == null) {
			sortMenu.setEnabled(false);
			
			return sortMenu;
		}

		sortMenu.setAutoRemoveAll(true);
		sortMenu.onSelect(self -> createSortMenu(self, false));

		return sortMenu;
	}
	
	/**
	 * @since 3.0
	 */
	public void createSortMenu(final MMenu parent, final boolean title) {
		ButtonGroup bg = new ButtonGroup();
		SortAction sortAction;
		
		if (title)
			parent.addSeparator(i18n("Sort by Column"));
		sortAction = new SortAction(-1, i18n("Unsorted"));
		bg.add(parent.addRadioButton(sortAction, true)); // unsorted
		
		List<TableColumn> tableColumns = getVisibleColumns();
		if (!tableColumns.isEmpty())
			parent.addSeparator();
		
		for (TableColumn i : tableColumns) {
			sortAction = new SortAction(i.getModelIndex(), i.getHeaderValue().toString());
			bg.add(parent.addRadioButton(sortAction));
			MTable<M> table = TK.get(tableRef);
			int viewIndex = table.convertColumnIndexToView(i.getModelIndex());
			sortAction.setSelected(table.isSortByColumn(viewIndex));
		}
	}

	/**
	 * @since 3.0
	 */
	public MMenu createVisibleMenu() {
		MMenu visibleMenu = new MMenu(i18n("Visible Columns"));
		visibleMenu.setAutoRemoveAll(true);
		visibleMenu.setEnabled(Kiosk.tableColumnReorderingAllowed.booleanValue());
		visibleMenu.onSelect(self -> createVisibleMenu(self, false));

		return visibleMenu;
	}

	/**
	 * @since 3.0
	 */
	public void createVisibleMenu(final MMenu parent, final boolean title) {
		if (title)
			parent.addSeparator(i18n("Visible Columns"));

		int visibleCount = 0;
		VisibleAction firstVisibleAction = null;
		for (int i = 0; i < allColumns.size(); i++) {
			String name = allColumns.get(i).getHeaderValue().toString();
			VisibleAction action = new VisibleAction(i, name);

			boolean visible = isVisible(i);
			parent.addCheckBox(action, visible);

			if (visible) {
				if (firstVisibleAction == null)
					firstVisibleAction = action;
				visibleCount++;
			}
		}
		// leave at least one visible column
		if ((visibleCount == 1) && (firstVisibleAction != null)) {
			firstVisibleAction.setEnabled(false);
		}
		
		parent.addSeparator();
		parent.add(new MAction(MActionInfo.RESTORE_DEFAULT_VALUES.getText() /* no icon */) {
			@Override
			public void onAction() {
				StringList defaultColumnsList = new StringList();
				defaultColumnsList.addAll(getDefaultColumnOrderAsString().split(" "));
				List<TableColumn> _allColumns = getAllColumns();

				MTable<M> table = TK.get(tableRef);

				AbstractListTableModel.ColumnInfo[] columnInfoArray;
				if (table.getModel() instanceof AbstractListTableModel<?>) {
					AbstractListTableModel<?> model = (AbstractListTableModel<?>)table.getModel();
					columnInfoArray = model.getColumnInfo();
				}
				else {
					columnInfoArray = new AbstractListTableModel.ColumnInfo[0];
				}
				
				List<TableColumn> sortedAllColumns = new MArrayList<>(_allColumns.size());
				if ((columnInfoArray.length == 0) || defaultColumnsList.isEmpty()) {
					sortedAllColumns.addAll(_allColumns);
				}
				else {
					for (String id : defaultColumnsList) {
						for (TableColumn tc : _allColumns) {
							if (Objects.equals(tc.getIdentifier(), id)) {
								sortedAllColumns.add(tc);
							
								break; // for
							}
						}
					}
				}

				for (TableColumn tc : _allColumns) {
					table.getColumnModel().removeColumn(tc);
					table.removeColumn(tc);
				}

				for (TableColumn tc : sortedAllColumns) {
					String id = Objects.toString(tc.getIdentifier(), "");
					if (defaultColumnsList.contains(id)) {
						table.getColumnModel().addColumn(tc);

						for (AbstractListTableModel.ColumnInfo ci : columnInfoArray) {
							if (id.equals(ci.getID())) {
								int w = ci.getDefaultWidth();
								if (w != -1) {
									tc.setPreferredWidth(w);
									tc.setWidth(w);
								}

								break; // for
							}
						}
					}
				}
			}
		} );
	}

	public List<TableColumn> getAllColumns() { return allColumns; }
	
	public List<TableColumn> getDefaultColumnOrder() { return defaultColumnOrder; }
	
	public String getDefaultColumnOrderAsString() {
		StringJoiner result = new StringJoiner(" ");
		for (TableColumn i : defaultColumnOrder)
			result.add(String.valueOf(i.getIdentifier()));
		
		return result.toString();
	}

	public void setDefaultColumnOrder(final Enum<?>... columns) {
		defaultColumnOrder.clear();
		for (Enum<?> i : columns)
			defaultColumnOrder.add(allColumns.get(i.ordinal()));
	}

	public void setDefaultColumnOrder(final int... columns) {
		defaultColumnOrder.clear();
		for (int i : columns)
			defaultColumnOrder.add(allColumns.get(i));
	}

	/**
	 * @since 3.0
	 */
	public List<TableColumn> getVisibleColumns() {
		MTable<M> table = TK.get(tableRef);
		TableColumnModel tcm = table.getColumnModel();
		int count = tcm.getColumnCount();
		MArrayList<TableColumn> result = new MArrayList<>(count);
		for (int i = 0; i < count; i++)
			result.add(tcm.getColumn(i));
		
		return result;
	}
	
	public boolean isVisible(final int modelIndex) {
		MTable<M> table = TK.get(tableRef);

		return table.convertColumnIndexToView(modelIndex) != -1;
	}
	
	public void setVisible(final int modelIndex, final boolean visible) {
		// already visible/hidden
		if (visible == isVisible(modelIndex))
			return;

		MTable<M> table = tableRef.get();
		
		if (table == null)
			return;
		
		TableColumn tc = allColumns.get(modelIndex);
		if (visible) {
			table.addColumn(tc);

			// select newly visible column
			int selectColumn = table.convertColumnIndexToView(modelIndex);
			if (selectColumn != -1) {
				Rectangle r = table.getCellRect(table.isEmpty(MV.VIEW) ? -1 : table.getSelectedRow(), selectColumn, true);
				if (r != null)
					MScrollPane.scrollToVisible(table, r);
			}
		}
		else {
			table.removeColumn(tc);
		}
	}

	/**
	 * @since 3.4
	 */
	public void readConfig(final Config global, final Config local, final Config.GlobalEntry globalEntry) {
		MTable<M> table = tableRef.get();

		if (table == null)
			return;

		// column visibility/order
		if ((local == null) || !readColumnOrder(table, local, globalEntry.getGlobalEntry("columns"), null))
			readColumnOrder(table, global, globalEntry.getGlobalEntry("columns"), getDefaultColumnOrderAsString());

// FIXME: 3.0: use global default values
		Config config = (local != null) ? local : global;

		// column sort
		readSortOrder(table, config, globalEntry.getGlobalEntry("sortMethod"), globalEntry.getGlobalEntry("sortOrder"));

		// current row
		if (!table.isEmpty(MV.MODEL)) {
			int row = config.readInt(globalEntry.getGlobalEntry("currentRow"), 0);
			try {
				if (row != -1)
					row = table.convertRowIndexToView(row);
				table.selectRow((row != -1) ? row : 0);
			}
			catch (IndexOutOfBoundsException exception) {
				table.selectRow(0); // row index does not exist; select first row
			}
		}

		// column width
		for (TableColumn i : allColumns) {
			int defaultWidth = i.getPreferredWidth();
			int width = config.readInt(globalEntry.getGlobalEntry("columnWidth." + i.getIdentifier()), defaultWidth, 30);
			i.setPreferredWidth(width);
			i.setWidth(width);
		}
	}

	/**
	 * @since 3.4
	 */
	public void writeConfig(final Config global, final Config local, final Config.GlobalEntry globalEntry) {
		MTable<M> table = tableRef.get();

		if (table == null)
			return;

		Config config = (local != null) ? local : global;

		// column visibility/order
		writeColumnOrder(table, config, globalEntry.getGlobalEntry("columns"));

		// column sort
		writeSortOrder(table, config, globalEntry.getGlobalEntry("sortMethod"), globalEntry.getGlobalEntry("sortOrder"));

		// current row
		int row = table.getSelectedRow();
		config.write(globalEntry.getGlobalEntry("currentRow"), (row == -1) ? 0 : table.convertRowIndexToModel(row));

		// column width
		for (TableColumn i : allColumns)
			config.write(globalEntry.getGlobalEntry("columnWidth." + i.getIdentifier()), i.getWidth());
	}

	/**
	 * @since 3.6
	 */
	@InvokedFromConstructor
	public void update() {
		allColumns = (MArrayList<TableColumn>)getVisibleColumns();
		defaultColumnOrder = new MArrayList<>(allColumns);
	}

	/**
	 * Sets column identifier and preferred width from
	 * the associated {@code AbstractListTableModel.ColumnInfo} (if available).
	 *
	 * @since 3.8
	 */
	public void updateProperties() {
		MTable<M> table = tableRef.get();

		if (table == null)
			return;

		if (!(table.getModel() instanceof AbstractListTableModel<?>))
			return;

		AbstractListTableModel.ColumnInfo[] ci = AbstractListTableModel.class.cast(table.getModel()).getColumnInfo();

		if (ci.length != allColumns.size())
			return;

		for (int i = 0; i < ci.length; i++) {
			String id = ci[i].getID();
			if (id != null)
				allColumns.get(i).setIdentifier(id);

			int w = ci[i].getDefaultWidth();
			if (w != -1)
				allColumns.get(i).setPreferredWidth(w);
		}
	}

	// private

	private boolean readColumnOrder(final JTable table, final Config config, final String key, final String defaultColumns) {
		String columnConfig = config.read(key, defaultColumns);

		if (TK.isEmpty(columnConfig))
			return false;

		String[] visibleColumns = columnConfig.split(" ");

		if (TK.isEmpty(visibleColumns))
			return false;

		TableColumnModel columnModel = table.getColumnModel();
		int columnCount = columnModel.getColumnCount();

		// remove all columns
		Map<Object, TableColumn> oldColumns = new HashMap<>(columnCount);
		TableColumn tableColumn;
		for (int i = columnCount - 1; i >= 0; --i) {
			tableColumn = columnModel.getColumn(i);
			oldColumns.put(tableColumn.getIdentifier(), tableColumn);
			columnModel.removeColumn(tableColumn);
		}

		// show columns in the specified order
		for (String i : visibleColumns) {
			tableColumn = oldColumns.get(i);
			if (tableColumn != null)
				columnModel.addColumn(tableColumn);
		}

		if (columnModel.getColumnCount() == 0)
			return false;

		return true;
	}

	private void readSortOrder(final MTable<?> table, final Config config, final String methodKey, final String orderKey) {
		String method = config.read(methodKey, null);
		String order = config.read(orderKey, null);

		if (TK.isEmpty(method) || TK.isEmpty(order)) {
			table.setDefaultSortOrder();

			return;
		}

		// sort method

		String[] methodArray = method.split(" ");

		if (TK.isEmpty(methodArray)) {
			table.setDefaultSortOrder();

			return;
		}

		int[] methodKeys = new int[methodArray.length];
		for (int i = 0; i < methodArray.length; i++) {
			try {
				methodKeys[i] = Integer.parseInt(methodArray[i]);
			}
			catch (NumberFormatException exception) {
				MLogger.exception(exception);
				table.setDefaultSortOrder();

				return;
			}
		}

		// sort order

		String[] orderArray = order.split(" ");

		if (TK.isEmpty(orderArray)) {
			table.setDefaultSortOrder();

			return;
		}

		SortOrder[] orderKeys = new SortOrder[orderArray.length];
		for (int i = 0; i < orderArray.length; i++)
			orderKeys[i] = EnumProperty.parse(orderArray[i], SortOrder.UNSORTED);

		if (methodKeys.length != orderKeys.length) {
			table.setDefaultSortOrder();

			return;
		}

		MArrayList<RowSorter.SortKey> sortKeys = new MArrayList<>();
		for (int i = 0; i < methodKeys.length; i++)
			sortKeys.add(new RowSorter.SortKey(methodKeys[i], orderKeys[i]));

		if (sortKeys.isEmpty()) {
			table.setDefaultSortOrder();
		}
		else {
			try {
				RowSorter<? extends TableModel> sorter = table.getRowSorter();
				if (sorter != null)
					sorter.setSortKeys(sortKeys);
			}
			// for compatibility with future versions
			catch (IllegalArgumentException exception) {
				table.setDefaultSortOrder();
			}
		}
	}

	private void writeColumnOrder(final JTable table, final Config config, final String key) {
		TableColumnModel columnModel = table.getColumnModel();
		String[] columns = new String[columnModel.getColumnCount()];
		Arrays.setAll(columns, i -> columnModel.getColumn(i).getIdentifier().toString());
		config.write(key, TK.isEmpty(columns) ? null : String.join(" ", columns));
	}

	private void writeSortOrder(final JTable table, final Config config, final String methodKey, final String orderKey) {
		RowSorter<? extends TableModel> sorter = table.getRowSorter();
		String method = null;
		String order = null;

		if (sorter != null) {
			List<? extends RowSorter.SortKey> sortKeys = sorter.getSortKeys();
			for (RowSorter.SortKey i : sortKeys) {
				// method
				if (method == null)
					method = Integer.toString(i.getColumn());
				else
					method += " " + i.getColumn();
				// order
				if (order == null)
					order = i.getSortOrder().name();
				else
					order += " " + i.getSortOrder().name();
			}
		}

		// method
		config.write(methodKey, method);
		// order
		config.write(orderKey, order);
	}

	// private classes

	private static abstract class ColumnAction extends MDataAction<Integer> {
		
		// protected
		
		protected ColumnAction(final int column, final String text) {
			super(column, text);
		}

	}

	private static final class SaveAsDefaultAction extends MDataAction.Weak<MTable<?>> {

		// public

		@Override
		public void onAction() {
			MTable<?> table = get();
			ColumnManager<?> columnManager = table.getColumnManager();

			Config.GlobalEntry ge = (Config.GlobalEntry)table;
			Config config = Config.getDefault();
			columnManager.writeColumnOrder(table, config, ge.getGlobalEntry("columns"));
			config.sync();
		}

		// private

		private SaveAsDefaultAction(final MTable<?> table) {
			super(table, MActionInfo.SAVE_AS_DEFAULT.getText() /* no icon */);
		}

	}

	private final class SortAction extends ColumnAction {
		
		// public
		
		@Override
		public void onAction() {
			MTable<M> table = TK.get(ColumnManager.this.tableRef);
			table.sortBy(getData(), true);
		}
		
		// private

		private SortAction(final int column, final String text) {
			super(column, text);
		}
		
	}

	private final class VisibleAction extends ColumnAction {
		
		// public
		
		@Override
		public void onAction() {
			ColumnManager.this.setVisible(getData(), isSelected());
		}
		
		// private

		private VisibleAction(final int column, final String text) {
			super(column, text);
		}
		
	}

}
