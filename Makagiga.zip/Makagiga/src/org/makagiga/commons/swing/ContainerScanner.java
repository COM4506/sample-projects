// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.Component;
import java.awt.Container;
import javax.swing.JMenu;

import org.makagiga.commons.AbstractScanner;
import org.makagiga.commons.TK;

/**
 * Recursively scans the container's tree structure.
 * 
 * @since 4.0 (org.makagiga.commons.swing package)
 */
public abstract class ContainerScanner extends AbstractScanner {
	
	// public
	
	/**
	 * Constructs a container scanner.
	 * @param root A root container (component)
	 */
	public ContainerScanner(final Container root) {
		scan(root);
	}
	
	/**
	 * Called on each component.
	 * @param parent A parent container (component)
	 * @param component A current component
	 */
	public abstract void processComponent(final Container parent, final Component component);

	// protected

	/**
	 * @mg.default {@code true}
	 *
	 * @since 3.8.7
	 */
	protected boolean shouldScan(final Container parent) { return true; }
	
	// private
	
	private void scan(final Container container) {
		if (!shouldScan(container))
			return;

		Component[] components;
		if (container instanceof JMenu)
			components = JMenu.class.cast(container).getMenuComponents();
		else
			components = container.getComponents();

		if (TK.isEmpty(components))
			return;

		processComponent(container.getParent(), container);
		for (Component i : components) {
			processComponent(container, i);
			if (i instanceof Container)
				scan((Container)i);
		}
	}
	
}
