// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.swing;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.IllegalComponentStateException;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.util.Iterator;
import java.util.List;
import javax.swing.DefaultDesktopManager;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;

import org.makagiga.commons.Lockable;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.fx.MTimeline;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.swing package)
 */
public class MDesktopPane<I extends JInternalFrame> extends JDesktopPane
implements
	Iterable<I>,
	Lockable
{

	// private

	private boolean locked;
	
	// public
	
	public MDesktopPane() {
		setDesktopManager(new MDesktopManager());
	}

	/**
	 * @since 3.8.6
	 */
	public static JDesktopPane getDesktopPane(final JComponent c) {
		if (c instanceof JDesktopPane)
			return (JDesktopPane)c;

		JInternalFrame f = getInternalFrame(c);

		return (f == null) ? null : f.getDesktopPane();
	}

	public static JInternalFrame getInternalFrame(final JComponent c) {
		if (c instanceof JInternalFrame)
			return (JInternalFrame)c;

		if (c instanceof JInternalFrame.JDesktopIcon)
			return JInternalFrame.JDesktopIcon.class.cast(c).getInternalFrame();

		if (c instanceof BasicInternalFrameTitlePane)
			return (JInternalFrame)c.getParent();

		return null;
	}

	public List<I> getFrames() {
		return toList(getAllFrames());
	}
	
	public List<I> getFrames(final int layer) {
		return toList(getAllFramesInLayer(layer));
	}

	// Iterable

	@Override
	public Iterator<I> iterator() {
		return getFrames().iterator();
	}

	// Lockable

	/**
	 * @since 3.8.6
	 */
	@Override
	public boolean isLocked() { return locked; }

	/**
	 * @since 3.8.6
	 */
	@Override
	public void setLocked(final boolean value) { locked = value; }

	/**
	 * @since 3.8.6
	 */
	public static boolean isLocked(final JComponent c) {
		JDesktopPane dp = getDesktopPane(c);

		return (dp instanceof Lockable) && Lockable.class.cast(dp).isLocked();
	}

	// protected

	/**
	 * @since 3.0
	 */
	protected void onEndDraggingFrame(final JComponent f) { }

	/**
	 * @since 3.0
	 */
	protected void onEndResizingFrame(final JComponent f) { }

	/**
	 * @since 5.0
	 */
	protected void onSnap(final JComponent f1, final JComponent f2, final UI.HorizontalPosition position) { }

	/**
	 * @since 5.0
	 */
	protected void onSnap(final JComponent f1, final JComponent f2, final UI.VerticalPosition position) { }

	// private
	
	@SuppressWarnings("unchecked")
	private List<I> toList(final JInternalFrame[] array) {
		MArrayList<I> result = new MArrayList<>(array.length);
		for (JInternalFrame i : array)
			result.add((I)i);

		return result;
	}
	
	// public classes
	
	/**
	 * @since 2.4
	 */
	public static class MDesktopManager extends DefaultDesktopManager {
		
		// private
		
		private boolean dragging;
		private boolean resizing;
		private boolean snapEnabled;
		private final GhostFrame ghost = new GhostFrame();
		private int snapSize = 5;
		private final MArrayList<Rectangle> snapRectCache = new MArrayList<>();
		private UI.HorizontalPosition newSnapX;
		private UI.VerticalPosition newSnapY;

		// public

		@Override
		public void beginDraggingFrame(final JComponent c) {
			dragging = true;
			newSnapX = null;
			newSnapY = null;
			
			JInternalFrame f;
			if (c instanceof JInternalFrame) {
				super.beginDraggingFrame(c);
				f = (JInternalFrame)c;
			}
			else {
				f = JInternalFrame.JDesktopIcon.class.cast(c).getInternalFrame();
			}

			snapRectCache.clear();
			JDesktopPane dp = MDesktopPane.getDesktopPane(f);
			if (dp != null) {
				for (JInternalFrame i : dp.getAllFrames()) {
					// skip self and frames on other workspaces
					if ((i != f) && i.isVisible())
						snapRectCache.add(i.getBounds());
				}
			}

			if (!MDesktopPane.isLocked(c))
				ghost.begin(f, false);
		}

		@Override
		public void closeFrame(final JInternalFrame f) {
			ghost.begin(f, true);
			super.closeFrame(f);
			ghost.end(true);
		}

		@Override
		public void dragFrame(final JComponent c, final int newX, final int newY) {
			if ((c instanceof JInternalFrame) && !MDesktopPane.isLocked(c)) {
				Point newLocation = new Point(newX, newY);
				snap(MDesktopPane.getDesktopPane(c), c, newLocation);
				super.dragFrame(c, newLocation.x, newLocation.y);
			}
		}

		@Override
		public void endDraggingFrame(final JComponent f) {
			dragging = false;

			snapRectCache.clear();
			
			if (f instanceof JInternalFrame)
				super.endDraggingFrame(f);

			if (!MDesktopPane.isLocked(f))
				ghost.end(false);
			
			JDesktopPane dp = MDesktopPane.getDesktopPane(f);
			if (dp instanceof MDesktopPane<?>) {
				MDesktopPane<?> mdp = (MDesktopPane<?>)dp;
				mdp.onEndDraggingFrame(f);
				
				if (f instanceof JInternalFrame) {
					if (newSnapX != null)
						mdp.onSnap(f, null, newSnapX);
					if (newSnapY != null)
						mdp.onSnap(f, null, newSnapY);
				}
			}
		}

		@Override
		public void beginResizingFrame(final JComponent f, final int direction) {
			resizing = true;
			super.beginResizingFrame(f, direction);
		}

		@Override
		public void resizeFrame(final JComponent f, final int newX, final int newY, final int newWidth, final int newHeight) {
			if (!MDesktopPane.isLocked(f))
				super.resizeFrame(f, newX, newY, newWidth, newHeight);
		}

		@Override
		public void endResizingFrame(final JComponent f) {
			resizing = false;
			super.endResizingFrame(f);
			JDesktopPane dp = MDesktopPane.getDesktopPane(f);
			if (dp instanceof MDesktopPane<?>)
				MDesktopPane.class.cast(dp).onEndResizingFrame(f);
		}
		
		/**
		 * @since 3.0
		 */
		public int getSnapSize() { return snapSize; }

		/**
		 * @since 3.0
		 */
		public void setSnapSize(final int value) { snapSize = value; }

		/**
		 * @since 5.0
		 */
		public int getSnapX(final JDesktopPane d, final JComponent c, final UI.HorizontalPosition position) {
			switch (position) {
				case LEFT: return snapSize;
				case RIGHT: return d.getWidth() - c.getWidth() - snapSize + 2;
				default: throw new WTFError(position);
			}
		}

		/**
		 * @since 5.0
		 */
		public int getSnapY(final JDesktopPane d, final JComponent c, final UI.VerticalPosition position) {
			switch (position) {
				case TOP: return snapSize;
				case BOTTOM: return d.getHeight() - c.getHeight() - snapSize + 2;
				default: throw new WTFError(position);
			}
		}

		/**
		 * @since 4.0
		 */
		public boolean isDragging() { return dragging; }

		/**
		 * @since 4.0
		 */
		public boolean isResizing() { return resizing; }

		/**
		 * @since 3.0
		 */
		public boolean isSnapEnabled() { return snapEnabled; }

		/**
		 * @since 3.0
		 */
		public void setSnapEnabled(final boolean value) { snapEnabled = value; }

		public void paintBackground(final JDesktopPane desktopPane, final Graphics2D g) {
			ghost.paint(g);
		}
		
		public void snap(final JDesktopPane d, final JComponent c, final Point p) {
			if (!snapEnabled)
				return;
			
			final int x1 = p.x;
			final int y1 = p.y;
			final int x2 = x1 + c.getWidth();
			final int y2 = y1 + c.getHeight();
			final int w = c.getWidth();
			final int h = c.getHeight();
			
			if (x1 < snapSize * 2) {
				newSnapX = UI.HorizontalPosition.LEFT;
				p.x = getSnapX(d, c, newSnapX);
			}
			else if (x2 + snapSize * 2 > d.getWidth()) {
				newSnapX = UI.HorizontalPosition.RIGHT;
				p.x = getSnapX(d, c, newSnapX);
			}
			else {
				newSnapX = UI.HorizontalPosition.NONE;
			}

			if (y1 < snapSize * 2) {
				newSnapY = UI.VerticalPosition.TOP;
				p.y = getSnapY(d, c, newSnapY);
			}
			else if (y2 + snapSize * 2 > d.getHeight()) {
				newSnapY = UI.VerticalPosition.BOTTOM;
				p.y = getSnapY(d, c, newSnapY);
			}
			else {
				newSnapY = UI.VerticalPosition.NONE;
			}
				
			if (!(c instanceof JInternalFrame))
				return;
			
			if (snapRectCache.isEmpty())
				return;

			// left edge
			boolean xSnap = false;
			snapRectCache.sort((r1, r2) -> Integer.compare(r1.x + r1.width, r2.x + r2.width));
			for (Rectangle i : snapRectCache) {
				if ((x1 > i.x + i.width) && (x1 < i.x + i.width + snapSize * 2)) {
					p.x = i.x + i.width + snapSize;
					xSnap = true;

					break; // for
				}
			}

			// right edge
			if (!xSnap) {
				snapRectCache.sort((r1, r2) -> Integer.compare(r1.x, r2.x));
				for (Rectangle i : snapRectCache) {
					if ((x2 < i.x) && (x2 + snapSize * 2 > i.x)) {
						p.x = i.x - w - snapSize + 2;

						break; // for
					}
				}
			}
			
			// top edge
			boolean ySnap = false;
			snapRectCache.sort((r1, r2) -> Integer.compare(r1.y + r1.height, r2.y + r2.height));
			for (Rectangle i : snapRectCache) {
				if ((y1 > i.y + i.height) && (y1 < i.y + i.height + snapSize * 2)) {
					p.y = i.y + i.height + snapSize;
					ySnap = true;

					break; // for
				}
			}
			
			// bottom edge
			if (!ySnap) {
				snapRectCache.sort((r1, r2) -> Integer.compare(r1.y, r2.y));
				for (Rectangle i : snapRectCache) {
					if ((y2 < i.y) && (y2 + snapSize * 2 > i.y)) {
						p.y = i.y - h - snapSize + 2;

						break; // for
					}
				}
			}
		}

	}

	// private classes

	private static final class GhostFrame extends MTimeline.UICallback {

		// private

		private float alpha;
		private float scale;
		private Image image;
		private JDesktopPane desktopPane;
		private MTimeline<JDesktopPane> animation;
		private Rectangle bounds;

		// public

		@Override
		public void onDone() {
			image = null;
			doRepaint(); // before "bounds = null"
			bounds = null;
			desktopPane = null;
		}

		// private

		private GhostFrame() { }

		private void begin(final JInternalFrame f, final boolean closing) {
			Rectangle r = f.isIcon() ? f.getDesktopIcon().getBounds() : f.getBounds();
			if (!r.equals(bounds)) {
				stopAnimations();

				alpha = closing ? 1.0f : 0.2f;
				scale = 1.0f;
				bounds = r;
				desktopPane = f.getDesktopPane();
				
				try {
					if (f instanceof MInternalFrame) {
						image = MInternalFrame.class.cast(f).createPreviewImage();
					}
					else {
						image = MComponent.createScreenshot(
							(f.isIcon() ? f.getDesktopIcon() : f),
							UI.INVISIBLE
						);
					}
				}
				// HACK: Workaround for "component must be showing on the screen to determine its location"
				//       in some LAFs.
				catch (IllegalComponentStateException exception) {
					MLogger.developerException(exception);
					
					image = null;
				}
				doRepaint();
			}
		}

		private void doRepaint() {
			if (desktopPane != null)
				desktopPane.repaint(bounds);
		}

		private void end(final boolean closing) {
			if (bounds != null) {
				stopAnimations();

				if (!UI.animations.get()) {
					onDone();
					
					return;
				}

				animation = new MTimeline<>(desktopPane);
				animation.addCallback(this);

				if (closing) {
					animation.setDuration(500);
					animation.addPropertyToInterpolate(
						MTimeline.<Float>property("scale")
						.from(scale)
						.to(0.0f)
						.getWith((object, name) -> scale)
						.setWith((object, name, value) -> {
							if (value != scale) {
								scale = value;
								doRepaint();
							}
						} )
					);
				}
				else {
					animation.setDuration(250);
					animation.addPropertyToInterpolate(
						MTimeline.<Float>property("alpha")
						.from(alpha)
						.to(0.0f)
						.getWith((object, name) -> alpha)
						.setWith((object, name, value) -> {
							if (value != alpha) {
								alpha = value;
								doRepaint();
							}
						} )
					);
				}

				animation.play();
			}
		}

		private void paint(final Graphics2D graphics) {
			if ((bounds != null) && (image != null)) {
				Graphics2D g = (Graphics2D)graphics.create();
				int x = bounds.x;
				int y = bounds.y;
				int w = image.getWidth(null);
				int h = image.getHeight(null);

				if (alpha < 1.0f)
					g.setComposite(AlphaComposite.SrcOver.derive(alpha));

				if (scale < 1.0f) {
					w *= scale;
					h *= scale;
					x += image.getWidth(null) / 2 - w / 2;
					y += image.getHeight(null) / 2 - h / 2;
					g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
				}

				g.drawImage(image, x, y, w, h, null);
				g.dispose();
			}
		}

		private void stopAnimations() {
			if (animation != null) {
				doRepaint();
				animation.abort();
				animation.removeCallback(this);
				animation = null;
			}
		}

	}
	
}
