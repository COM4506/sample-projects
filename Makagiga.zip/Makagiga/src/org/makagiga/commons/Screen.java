// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static org.makagiga.commons.UI.i18n;

import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.util.List;
import java.util.Objects;

import org.makagiga.commons.security.MAccessController;

/**
 * @since 5.6
 */
public final class Screen {

	// private

	private final GraphicsDevice device;

	// public

	@Override
	public boolean equals(final Object o) {
		if (o == this)
			return true;
		
		if ((o == null) || (o.getClass() != this.getClass()))
			return false;
		
		return this.getID().equals(Screen.class.cast(o).getID());
	}

	@Override
	public int hashCode() {
		return getID().hashCode();
	}

	public static List<Screen> getAll() {
		MArrayList<Screen> result = new MArrayList<>();
		GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		for (GraphicsDevice i : graphicsEnvironment.getScreenDevices()) {
			if (i.getType() == GraphicsDevice.TYPE_RASTER_SCREEN)
				result.add(new Screen(i));
		}

		return result;
	}

	public Rectangle getBounds() {
		return device
			.getDefaultConfiguration()
			.getBounds();
	}

	public static Point getCenter() {
		return GraphicsEnvironment
			.getLocalGraphicsEnvironment()
			.getCenterPoint();
	}

	public static Screen getCurrent(final Window window) {
		Point location = window.getLocation();
		for (Screen i : getAll()) {
			if (i.getBounds().contains(location))
				return i;
		}

		return getPrimary();
	}

	public GraphicsDevice getDevice() { return device; }

	public String getID() {
		return device.getIDstring();
	}

	public Insets getInsets() {
		return Toolkit
			.getDefaultToolkit()
			.getScreenInsets(device.getDefaultConfiguration());
	}

	public static Screen getPrimary() {
		return new Screen(GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice());
	}

	public Dimension getResolution() {
		DisplayMode dm = MAccessController.doPrivileged(device::getDisplayMode);

		return new Dimension(dm.getWidth(), dm.getHeight());
	}

	public boolean isPrimary() {
		return equals(getPrimary());
	}

	/**
	 * @since 5.6
	 */
	public boolean isSmallHeight() {
		return getBounds().height <= 600;
	}

	public String toDisplayString() {
		return String.format(
			"%s, %s%s",
			getID(),
			MFormat.dimension(getResolution()),
			isPrimary() ? (" (" + i18n("Default") + ")") : ""
		);
	}

	@Override
	public String toString() {
		DisplayMode dm = MAccessController.doPrivileged(device::getDisplayMode);
		int bpp = dm.getBitDepth();

		return String.format(
			"%s (%s, %s bpp)%s",
			getID(),
			MFormat.dimension(dm.getWidth(), dm.getHeight()),
			(bpp == DisplayMode.BIT_DEPTH_MULTI) ? "multi" : Integer.toString(bpp),
			isPrimary() ? " <Primary>" : ""
		);
	}

	// private
	
	private Screen(final GraphicsDevice device) {
		this.device = Objects.requireNonNull(device);
	}

}
