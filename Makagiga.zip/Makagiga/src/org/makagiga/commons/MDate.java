// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static org.makagiga.commons.UI.i18n;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import org.makagiga.commons.annotation.Obsolete;

/**
 * @see MCalendar
 */
public class MDate extends java.util.Date {
	
	// public
	
	/**
	 * @since 2.0
	 */
	public enum CompareResult {
		
		UNKNOWN,

		BEFORE,
		
		/**
		 * @since 4.4
		 */
		EQUAL,

		TODAY,

		/**
		 * @since 3.8.7
		 */
		TOMORROW,
		
		/**
		 * @since 4.4
		 */
		THIS_WEEK,

		/**
		 * @since 4.4
		 */
		THIS_MONTH,
		
		AFTER;

	}
	
	// date/time formats

	/**
	 * Full date/time format.
	 */
	public static final int FULL = DateFormat.FULL;

	/**
	 * Long date/time format.
	 */
	public static final int LONG = DateFormat.LONG;

	/**
	 * Medium date/time format.
	 */
	public static final int MEDIUM = DateFormat.MEDIUM;

	/**
	 * Short date/time format.
	 */
	public static final int SHORT = DateFormat.SHORT;

	/**
	 * @since 4.4
	 */
	public static final int FANCY_FORMAT_ABSOLUTE = 1;

	/**
	 * @since 4.4
	 */
	public static final int FANCY_FORMAT_APPEND_TIME = 1 << 1;

	/**
	 * @since 4.4
	 */
	public static final int FANCY_FORMAT_APPEND_YEAR = 1 << 2;
	
	/**
	 * @since 4.8
	 */
	public static final int FORMAT_PERIOD_APPEND_SECONDS = 1;

	/**
	 * @since 4.8
	 */
	public static final int FORMAT_PERIOD_APPEND_TIME = 1 << 1;

	/**
	 * @since 4.8
	 */
	public static final int FORMAT_PERIOD_VERBOSE_TIME = 1 << 2;

	/**
	 * @since 4.10
	 */
	public static final int FORMAT_PERIOD_SHORT_TIME_SUFFIX = 1 << 3;

	/**
	 * @since 4.2
	 */
	@Obsolete
	public static final long INVALID_TIME = 0L;
	
	/**
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	
	/**
	 * A {@code yyyy-MM-dd} date format.
	 *
	 * @since 4.2
	 */
	public static final String YYYY_MM_DD_FORMAT = "yyyy-MM-dd";

	/**
	 * @since 2.0
	 *
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";

	/**
	 * A {@code HH:mm:ss} time format.
	 *
	 * @since 4.2
	 */
	public static final String HH_MM_SS_FORMAT = "HH:mm:ss";

	/**
	 * A {@code HH:mm} time format.
	 *
	 * @since 4.6
	 */
	public static final String HH_MM_FORMAT = "HH:mm";

	/**
	 * @since 2.0
	 *
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public static final String DEFAULT_DATE_TIME_FORMAT = YYYY_MM_DD_FORMAT + " " + HH_MM_SS_FORMAT;
	
	// private

	private static final ThreadLocal<SimpleDateFormat> FORMAT_RFC3339 = ThreadLocal.withInitial(
		() -> new SimpleDateFormat(YYYY_MM_DD_FORMAT + "'T'" + HH_MM_SS_FORMAT + "Z", Locale.US)
	);

	private static final ThreadLocal<SimpleDateFormat> FORMAT_RFC822 = ThreadLocal.withInitial(
		() -> new SimpleDateFormat("EEE, d MMM yyyy " + HH_MM_SS_FORMAT + " Z", Locale.US)
	);

	private static final ThreadLocal<DateFormat> FORMAT_SHORT_TIME = ThreadLocal.withInitial(
		() -> DateFormat.getTimeInstance(MDate.SHORT)
	);

	private static final ThreadLocal<SimpleDateFormat> PARSE_RFC = new ThreadLocal<>();

	// public
	
	public MDate() { }
	
	/**
	 * @since 3.8.11
	 */
	public MDate(final java.util.Calendar calendar) {
		super(calendar.getTimeInMillis());
	}

	public MDate(final java.util.Date date) {
		super(date.getTime());
	}

	/**
	 * @since 1.2
	 */
	public MDate(final long time) {
		super(time);
	}

	/**
	 * @since 2.0
	 */
	public CompareResult compareDateTime(final MDate otherDateTime, final boolean returnToday) {
		long t1 = this.getTime();
		
		if (t1 == INVALID_TIME)
			return CompareResult.UNKNOWN;
		
		long t2 = otherDateTime.getTime();

		if (t2 == INVALID_TIME)
			return CompareResult.UNKNOWN;

		if (t1 == t2)
			return CompareResult.EQUAL;

		if (t1 < t2)
			return CompareResult.BEFORE;

		return compareCalendars(otherDateTime.toCalendar(), returnToday);
	}

	/**
	 * @since 4.4
	 */
	public CompareResult compareDateTime(final MCalendar otherCalendar, final boolean returnToday) {
		long t1 = this.getTime();
		
		if (t1 == INVALID_TIME)
			return CompareResult.UNKNOWN;
		
		long t2 = otherCalendar.getTimeInMillis();

		if (t2 == INVALID_TIME)
			return CompareResult.UNKNOWN;

		if (t1 == t2)
			return CompareResult.EQUAL;

		if (t1 < t2)
			return CompareResult.BEFORE;

		return compareCalendars(otherCalendar, returnToday);
	}
	
	private CompareResult compareCalendars(final MCalendar other, final boolean returnToday) { // private
		MCalendar calendar = toCalendar();

		int m = calendar.toMonth().getValue();
		int y = calendar.getYear();

		int otherM = other.toMonth().getValue();
		int otherY = other.getYear();
		
		boolean sameMonthAndYear = (m == otherM) && (y == otherY);

		if (
			returnToday &&
			(calendar.getDay() == other.getDay()) &&
			sameMonthAndYear
		)
			return CompareResult.TODAY;

		other.addDay(1);
		boolean tomorrow = other.isSameDate(calendar);
		other.addDay(-1); // undo calendar change
		
		if (tomorrow)
			return CompareResult.TOMORROW;

		if (
			(calendar.getWeek() == other.getWeek()) &&
			calendar.isWeekDateSupported() &&
			(calendar.getWeekYear() == other.getWeekYear())
		)
			return CompareResult.THIS_WEEK;

		if (sameMonthAndYear)
			return CompareResult.THIS_MONTH;

		return CompareResult.AFTER;
	}

	/**
	 * Returns the current date/time.
	 */
	@Obsolete
	public static long currentTime() {
		return new MDate().getTime();
	}

	/**
	 * @mg.warning This method is not thread-safe.
	 *
	 * @since 4.4
	 */
	public static String fancyFormat(final java.util.Date date, final int options) {
		if (!isValid(date))
			return "";
		
		String s = null;
		MCalendar calendar = MCalendar.of(date);
		MCalendar test = MCalendar.today();
		int todayYear = test.getYear();
		
		if ((options & FANCY_FORMAT_ABSOLUTE) == 0) {
			if (calendar.isSameDate(test)) {
				s = i18n("Today");
			}
			else {
				test.addDay(1);
				if (calendar.isSameDate(test)) {
					s = i18n("Tomorrow");
				}
				else {
					test.addDay(-2);
					if (calendar.isSameDate(test))
						s = i18n("Yesterday");
				}
			}
		}
		if (s == null) {
			s = format(
				date,
				((options & FANCY_FORMAT_APPEND_YEAR) != 0) || (calendar.getYear() != todayYear)
				? "EEEE, MMM d, yyyy"
				: "EEEE, MMM d",
				Locale.getDefault(Locale.Category.FORMAT)
			);
		}

		return
			((options & FANCY_FORMAT_APPEND_TIME) != 0)
			? (s + "  " + formatTime(date, SHORT))
			: s;
	}

	/**
	 * @since 4.4
	 */
	public String fancyFormat(final int options) {
		return fancyFormat(this, options);
	}

	/**
	 * @since 4.0
	 *
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public static String fancyFormat(final java.util.Date date, final int dateStyle, final boolean includeTime) {
		StringBuilder s = new StringBuilder();

		if (isValid(date)) {
			MCalendar calendar = MCalendar.of(date);

			if (calendar.isSameDate(MCalendar.today()))
				s.append(i18n("Today"));
			else if (calendar.isSameDate(MCalendar.tomorrow()))
				s.append(i18n("Tomorrow"));
			else if (calendar.isSameDate(MCalendar.yesterday()))
				s.append(i18n("Yesterday"));
		}

		if (s.length() == 0)
			s.append(formatDate(date, dateStyle));

		if (includeTime)
			s.append(' ').append(formatTime(date, SHORT));

		return s.toString();
	}

	/**
	 * @since 2.0
	 *
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public String fancyFormat(final int dateStyle, final boolean includeTime) {
		return fancyFormat(this, dateStyle, includeTime);
	}

	public String format(final String format) {
		return new SimpleDateFormat(format).format(this);
	}

	/**
	 * @since 2.0
	 */
	public String format(final String format, final Locale locale) {
		return new SimpleDateFormat(format, locale).format(this);
	}

	/**
	 * @since 4.0
	 */
	public static String format(final java.util.Date date, final String format, final Locale locale) {
		return new SimpleDateFormat(format, locale).format(date);
	}

	/**
	 * @since 4.0
	 */
	public static String formatDate(final java.util.Date date, final int dateStyle) {
		DateFormat df = DateFormat.getDateInstance(dateStyle);

		return df.format(date);
	}

	/**
	 * @since 4.10
	 */
	public static String formatDate(final java.util.Date date, final int dateStyle, final Locale locale) {
		DateFormat df = DateFormat.getDateInstance(dateStyle, locale);

		return df.format(date);
	}

	public String formatDateTime(final int dateStyle, final int timeStyle) {
		DateFormat df = DateFormat.getDateTimeInstance(dateStyle, timeStyle);
		
		return df.format(this);
	}

	/**
	 * @since 4.10
	 */
	public String formatDateTime(final int dateStyle, final int timeStyle, final Locale locale) {
		DateFormat df = DateFormat.getDateTimeInstance(dateStyle, timeStyle, locale);
		
		return df.format(this);
	}

	/**
	 * @since 4.8
	 */
	public static String formatPeriod(final long ms, final int options) {
		long seconds = TimeUnit.MILLISECONDS.toSeconds(ms);
		long minutes = (seconds / 60L) % 60L;

		long hours = TimeUnit.SECONDS.toHours(seconds);
		long days = TimeUnit.HOURS.toDays(hours);
		
		// DOC: https://en.wikipedia.org/wiki/Gregorian_calendar
		float daysInMonth = 365.2425f / 12f;
		long months = (long)((float)days / daysInMonth);

		hours -= (days * 24L);
		seconds -= (days * 24L * 3600L) + (hours * 3600L) + (minutes * 60L);
		days -= (long)((float)months * daysInMonth);

		StringBuilder s = new StringBuilder(128);

		if (months > 0) {
			if (months > 12) {
				long years = months / 12;
				months -= (years * 12);
				s.append(i18n("Years: {0}", Long.toString(years)/* no number format */));
				s.append(", ");
			}
		
			s.append(i18n("Months: {0}", Long.toString(months)/* no number format */));
			if (days > 0)
				s.append(", ");
		}

		if (days > 0) {
			s.append(i18n("Days: {0}", Long.toString(days)/* no number format */));
			if ((options & FORMAT_PERIOD_APPEND_TIME) != 0)
				s.append(", ");
		}
			
		if ((options & FORMAT_PERIOD_APPEND_TIME) != 0) {
			boolean timeSuffix = (options & FORMAT_PERIOD_SHORT_TIME_SUFFIX) != 0;
			boolean verbose = (options & FORMAT_PERIOD_VERBOSE_TIME) != 0;
			
			if (verbose) {
				s.append(i18n("Hours: {0}", hours)).append(", ");
				s.append(i18n("Minutes: {0}", minutes));
			}
			else {
				if (hours < 10)
					s.append('0');
				s.append(hours);
				if (timeSuffix)
					s.append('h');
				s.append(':');

				if (minutes < 10)
					s.append('0');
				s.append(minutes);
				if (timeSuffix)
					s.append('m');
			}

			if ((options & FORMAT_PERIOD_APPEND_SECONDS) != 0) {
				if (verbose) {
					s.append(", ");
					s.append(i18n("Seconds: {0}", seconds));
				}
				else {
					s.append(':');
					if (seconds < 10)
						s.append('0');
					s.append(seconds);
					if (timeSuffix)
						s.append('s');
				}
			}
		}

		return s.toString();
	}

	/**
	 * @since 2.0
	 */
	@Obsolete
	public String formatRFC3339() {
		return FORMAT_RFC3339.get().format(this);
	}

	/**
	 * @since 2.0
	 */
	@Obsolete
	public String formatRFC822() {
		return FORMAT_RFC822.get().format(this);
	}

	/**
	 * @since 4.0
	 */
	public static String formatTime(final java.util.Date date, final int timeStyle) {
		DateFormat df;
		if (timeStyle == MDate.SHORT)
			df = FORMAT_SHORT_TIME.get();
		else
			df = DateFormat.getTimeInstance(timeStyle);
		
		return df.format(date);
	}

	/**
	 * Returns the number of days between this date and @p time.
	 *
	 * @deprecated Since 4.8
	 */
	@Deprecated
	public long getDayCount(final long time) {
		return toDays(getTime() - time);
	}
	
	/**
	 * @since 2.0
	 */
	@Obsolete
	public static MDate invalid() {
		return new MDate(INVALID_TIME);
	}

	/**
	 * @since 2.0
	 */
	public boolean isToday() {
		if (!isValid())
			return false;
		
		return toCalendar().isSameDate(MCalendar.today());
	}
	
	/**
	 * @since 2.0
	 */
	@Obsolete
	public boolean isValid() {
		return getTime() != INVALID_TIME;
	}

	/**
	 * @since 4.0
	 */
	@Obsolete
	public static boolean isValid(final java.util.Date date) {
		return date.getTime() != INVALID_TIME;
	}

	/**
	 * Returns the current date/time.
	 */
	public static MDate now() {
		return new MDate();
	}

	/**
	 * @since 2.0
	 */
	public static java.util.Date parse(final String date, final String format, final Locale locale, final java.util.Date defaultValue) {
		if (TK.isEmpty(date))
			return defaultValue;
		
		try {
			return new SimpleDateFormat(format, locale).parse(date);
		}
		catch (ParseException exception) {
			return defaultValue;
		}
	}

	/**
	 * @since 2.0
	 */
	public static java.util.Date parseRFC3339(final String value) {
		String date = value;
		StringBuilder pattern = new StringBuilder(32);
		pattern.append(YYYY_MM_DD_FORMAT + "'T'" + HH_MM_SS_FORMAT);

		// 2003-12-13T18:30:02.25+01:00 (ms)
		int ms = date.indexOf('.');
		if (ms != -1)
			pattern.append(".SS");

		// 2003-12-13T18:30:02+01:00 (time zone)
		int timeZone = date.indexOf('+');
		if (timeZone != -1) {
			// +01:00 -> +0100
			String tz = date.substring(timeZone + 1).replace(":", "");
			date = date.substring(0, timeZone + 1) + tz;
			pattern.append('Z');
		}

		return parseRFC(date, pattern.toString());
	}

	/**
	 * @since 2.0
	 */
	public static java.util.Date parseRFC822(final String value) {
		if (value == null)
			return null;

		StringBuilder format = new StringBuilder("EEE, d MMM yyyy ");
		format.append(HH_MM_SS_FORMAT);

		int lastSep = value.lastIndexOf(' ');
		if (lastSep != -1) {
			int zIndex = value.lastIndexOf('+');
			if ((zIndex == -1) || (zIndex < lastSep))
				zIndex = value.lastIndexOf('-');
			if ((zIndex != -1) && (zIndex > lastSep))
				format.append(" z");
		}

		return parseRFC(value, format.toString());
	}

	/**
	 * Sets date value to @p time (number of milliseconds).
	 *
	 * @throws IllegalStateException If date object is immutable
	 * @throws NullPointerException If @p time is @c null
	 */
	public void setTime(final java.util.Date time) {
		setTime(time.getTime());
	}

	/**
	 * @since 3.8.12
	 */
	public MCalendar toCalendar() {
		return MCalendar.of(this);
	}

	/**
	 * @since 1.2
	 *
	 * @deprecated As of 4.2, replaced by {@link java.util.concurrent.TimeUnit}
	 */
	@Deprecated
	public static long toDays(final long time) {
		return TimeUnit.MILLISECONDS.toDays(time);
	}

	// private
	
	private static java.util.Date parseRFC(final String value, final String pattern) {
		try {
			if (TK.isEmpty(value))
				return null;

			SimpleDateFormat f = PARSE_RFC.get();
			if ((f == null) || !Objects.equals(f.toPattern(), pattern)) {
				f = new SimpleDateFormat(pattern, Locale.US);
				PARSE_RFC.set(f);
			}

			try {
				return f.parse(value);
			}
			catch (ParseException exception) {
				return null;
			}
		}
		catch (IllegalArgumentException exception) {
			MLogger.warning("core", "Invalid date: %s", value);
			
			return null;
		}
	}
	
}
