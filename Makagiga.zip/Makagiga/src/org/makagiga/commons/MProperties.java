// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

/**
 * @since 2.0
 */
public class MProperties extends Properties {
	
	// private

	private boolean safeStore;
	private String comment;
	
	// public
	
	public MProperties() { }
	
	public MProperties(final Properties defaults) {
		super(defaults);
	}
	
	public synchronized String getComment() { return comment; }
	
	public synchronized void setComment(final String value) { comment = value; }

	/**
	 * @since 3.0
	 */
	public synchronized boolean isSafeStore() { return safeStore; }

	/**
	 * @since 3.0
	 */
	public synchronized void setSafeStore(final boolean value) { safeStore = value; }

	public void loadUTF8(final File file) throws IOException {
		try (FS.TextReader reader = FS.getUTF8Reader(file)) {
			load(reader);
		}
	}
	
	public void loadUTF8(final InputStream input) throws IOException {
		load(FS.getUTF8Reader(input));
	}

	/**
	 * @since 4.10
	 */
	public void loadUTF8(final Path file) throws IOException {
		try (BufferedReader reader = Files.newBufferedReader(file)) {
			load(reader);
		}
	}

	/**
	 * @deprecated May cause @c ClassCastException in @c store if @p value is not a @c String
	 */
	@Deprecated
	@Override
	public Object put(final Object key, final Object value) {
		return super.put(key, value);
	}

	/**
	 * @deprecated May cause @c ClassCastException in @c store
	 */
	@Deprecated
	@Override
	public void putAll(final Map<? extends Object, ? extends Object> t) {
		super.putAll(t);
	}

	/**
	 * @since 3.0
	 */
	public synchronized void removeNonStringValues() {
		Iterator<Map.Entry<Object, Object>> it = entrySet().iterator();
		while (it.hasNext()) {
			if (!(it.next().getValue() instanceof String))
				it.remove();
		}
	}
	
	/**
	 * @mg.note {@code value} other than {@code java.lang.String} will cause
	 * {@code ClassCastException} in {@code store()} or {@code storeUTF8()}.
	 *
	 * @see #isSafeStore()
	 * @see #removeNonStringValues()
	 *
	 * @since 3.0
	 */
	public Object setObject(final String key, final Object value) {
		return super.put(key, value);
	}

	public Object setPropertyValue(final String key, final Object value) {
		if (value == null) {
			synchronized (this) {
				return remove(key);
			}
		}
		
		return setProperty(key, value.toString());
	}

	public void storeUTF8(final File file) throws IOException {
		try (FS.TextWriter writer = FS.getUTF8Writer(file)) {
			// save String properties only
			if (isSafeStore()) {
				Properties p = new Properties();
				for (Map.Entry<Object, Object> i : entrySet()) {
					if ((i.getKey() instanceof String) && (i.getValue() instanceof String))
						p.setProperty((String)i.getKey(), (String)i.getValue());
				}
				p.store(writer, comment);
			}
			else {
				store(writer, comment);
			}
		}
	}
	
	public void storeUTF8(final OutputStream output) throws IOException {
		store(FS.getUTF8Writer(output), comment);
	}

	/**
	 * @since 4.10
	 */
	public void storeUTF8(final Path file) throws IOException {
		storeUTF8(file.toFile());
	}

	/**
	 * @deprecated May cause @c ClassCastException in @c store
	 */
	@Deprecated
	@Override
	public Collection<Object> values() {
		return super.values();
	}

}
