// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;

/**
 * @since 2.0
 */
public final class Benchmark implements Serializable {
	
	// private
	
	private long nanoStart;
	private long totalCount;
	private long totalNano;
	private long totalStart;
	private MLogger log;
	
	// public

	public Benchmark() {
		this("benchmark");
	}
	
	public Benchmark(final String id) {
		log = MLogger.get(id);
	}
	
	public void begin() {
		reset();
	}
	
	public static Benchmark begin(final String id) {
		Benchmark b = new Benchmark(id);
		b.begin();
		
		return b;
	}
	
	public long elapsedMS() {
		return elapsedNano() / 1000000L;
	}

	/**
	 * @since 3.0
	 */
	public long elapsedNano() {
		return Math.abs(System.nanoTime() - nanoStart);
	}

	public long elapsedSeconds() {
		return elapsedMS() / 1000L;
	}

	public void end() {
		log.info(MFormat.nano(elapsedNano()) + " ms");
	}

	public void end(final String text, final Object... args) {
		log.infoFormat(
			MFormat.nano(elapsedNano()) + " ms: " + text,
			args
		);
	}

	/**
	 * @since 4.0
	 *
	 * @deprecated As of 5.2, replaced by {@link MFormat#nano(long)}
	 */
	@Deprecated
	public static String formatNano(final long value) {
		return MFormat.nano(value);
	}

	/**
	 * @since 4.6
	 */
	public void logTotal(final long diff) {
		log.debugFormat("%d: total=%s ms (+%s)", totalCount, MFormat.nano(totalNano()), MFormat.nano(diff));
	}

	/**
	 * @since 4.6
	 */
	public void markTotal() {
		totalStart = System.nanoTime();
	}

	/**
	 * @since 4.0
	 */
	public void reset() {
		nanoStart = System.nanoTime();
		totalStart = nanoStart;
		
		totalCount = 0;
		totalNano = 0;
	}

	/**
	 * @since 5.0
	 */
	public static Benchmark run(final String id, final Runnable block) {
		Benchmark b = new Benchmark(id);
		b.begin();
		block.run();
		b.end();
		
		return b;
	}

	/**
	 * @since 5.0
	 */
	public void sumTotal(final Runnable block) {
		markTotal();
		block.run();
		logTotal(sumTotal());
	}

	/**
	 * @since 4.6
	 */
	public long sumTotal() {
		long diff = Math.abs(System.nanoTime() - totalStart);
		totalNano += diff;
		totalCount++;
		
		return diff;
	}

	/**
	 * @since 4.6
	 */
	public long totalNano() { return totalNano; }

}
