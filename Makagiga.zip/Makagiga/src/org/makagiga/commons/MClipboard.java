// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.AWTPermission;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import org.makagiga.commons.annotation.Uninstantiable;

/**
 * @since 2.0
 */
public final class MClipboard {
	
	// private
	
	private static AWTPermission ACCESS_CLIPBOARD_PERMISSION = new AWTPermission("accessClipboard");
	private static boolean historyEnabled;
	private static Clipboard localClipboard; // no security manager
	private static LinkedList<Object> _history;
	
	// public
	
	public static void clear() throws ClipboardException {
		setString("");
		
		// clear "selection"
		Clipboard selection = Toolkit.getDefaultToolkit().getSystemSelection();
		if (selection != null) {
			try {
				selection.setContents(new StringSelection(""), null);
			}
			catch (Exception exception) {
				MLogger.exception(exception);
			}
		}
	}
	
	public synchronized static void clearHistory() {
		if (_history != null) {
			checkPermission();

			_history.clear();
		}
	}

	/**
	 * @since 2.4
	 */
	public synchronized static Object getContents(final DataFlavor flavor) throws ClipboardException {
		return getContents(getDefault(), flavor);
	}

	/**
	 * @since 2.4
	 */
	public synchronized static Object getContents(final Clipboard clipboard, final DataFlavor flavor) throws ClipboardException {
		Objects.requireNonNull(clipboard, "clipboard");
		Objects.requireNonNull(flavor, "flavor");
		
		try {
			if (clipboard.isDataFlavorAvailable(flavor))
				return clipboard.getData(flavor);
			
			return null;
		}
		catch (Exception exception) {
			throw new ClipboardException(exception);
		}
	}
	
	/**
	 * @since 2.4
	 */
	public synchronized static void setContents(final Transferable contents) throws ClipboardException {
		Objects.requireNonNull(contents, "contents");
		
		Clipboard clipboard = getDefault();
		try {
			clipboard.setContents(
				contents,
				(contents instanceof ClipboardOwner) ? (ClipboardOwner)contents : null
			);
		}
		catch (Exception exception) {
			throw new ClipboardException(exception);
		}
	}

	public static Clipboard getDefault() {
		try {
			return Toolkit.getDefaultToolkit().getSystemClipboard();
		}
		catch (SecurityException exception) {
			MLogger.exception(exception);
			
			checkPermission();

			synchronized (MClipboard.class) {
				if (localClipboard == null)
					localClipboard = new Clipboard("Local Clipboard");
			}
			
			return localClipboard;
		}
	}

	public synchronized List<Object> getHistory() {
		if (_history == null)
			return Collections.emptyList();

		checkPermission();
		
		return Collections.unmodifiableList(_history);
	}

	/**
	 * @since 2.4
	 */
	public synchronized static Image getImage() throws ClipboardException {
		try {
			return MDataTransfer.getImage(getDefault());
		}
		catch (Exception exception) {
			throw new ClipboardException(exception);
		}
	}

	/**
	 * @since 2.4
	 */
	public static String getString() throws ClipboardException {
		Object data = getContents(DataFlavor.stringFlavor);
		
		if (data == null)
			return null;
		
		return (String)data;
	}

	/**
	 * @since 2.4
	 */
	public synchronized static void setString(final String value) throws ClipboardException {
		setContents(new StringSelection(value));
		updateHistory(value);
	}

	/**
	 * @since 3.0
	 */
	public static URL getURL() {
		try {
			String s = getString();
			if (s != null) {
				s = s.trim();
				
				return new URL(s);
			}
		}
		catch (ClipboardException exception) {
			MLogger.exception(exception);
		}
		catch (MalformedURLException exception) { } // quiet

		return null;
	}

	/**
	 * @throws NullPointerException If {@code flavor} is {@code null}
	 */
	public static boolean isDataFlavorAvailable(final DataFlavor flavor) throws ClipboardException {
		Objects.requireNonNull(flavor, "flavor");

		try {
			return getDefault().isDataFlavorAvailable(flavor);
		}
		catch (IllegalStateException exception) {
			throw new ClipboardException(exception);
		}
		// HACK: workaround for "Failed to retrieve atom name" NPE exception
		catch (NullPointerException exception) {
			MLogger.exception(exception);
			
			return false;
		}
	}
	
	public synchronized static boolean isHistoryEnabled() { return historyEnabled; }
	
	public synchronized static void setHistoryEnabled(final boolean value) {
		checkPermission();

		historyEnabled = value;
	}
	
	// private
	
	@Uninstantiable
	private MClipboard() {
		TK.uninstantiable();
	}

	private static void checkPermission() {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			// NOTE: SecurityManager.checkSystemClipboardAccess() is deprecated in JDK8
			sm.checkPermission(ACCESS_CLIPBOARD_PERMISSION);
	}
	
	private synchronized static void updateHistory(final Object data) throws ClipboardException {
		if (!historyEnabled || (data == null))
			return;

		if (_history == null)
			_history = new LinkedList<>();

		// newer first; older last
		if (_history.size() == 10)
			_history.removeLast();
		_history.addFirst(data);
/*
			for (int i = 0; i < _history.size(); i++) {
				MLogger.debug("clipboard", "History object #%d: %s", i, _history.get(i));
			}
			MLogger.debug("clipboard", "History size is now %d", _history.size());
*/
	}

}
