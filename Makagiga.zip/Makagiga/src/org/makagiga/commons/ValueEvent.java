// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.EventObject;
import java.util.Objects;

/**
 * A value event.
 *
 * @mg.threadSafe
 * 
 * @see ValueListener
 * 
 * @since 2.4
 */
public final class ValueEvent<T> extends EventObject {
	private static final long serialVersionUID = 5359681257958835398L;
	
	// private

	transient private Object reason;
	transient private T newValue;
	transient private T oldValue;
	
	// public

	/**
	 * Constructs a new value event with @c null <i>reason</i>.
	 * 
	 * @param source The event source
	 * @param oldValue The old value (can be @c null)
	 * @param newValue The new value (can be @c null)
	 * 
	 * @throws IllegalArgumentException If @p source is @c null
	 */
	public ValueEvent(final Object source, final T oldValue, final T newValue) {
		this(source, oldValue, newValue, null);
	}
	
	/**
	 * Constructs a new value event.
	 * 
	 * @param source The event source
	 * @param oldValue The old value (can be @c null)
	 * @param newValue The new value (can be @c null)
	 * @param reason The event reason (can be @c null)
	 * 
	 * @throws IllegalArgumentException If @p source is @c null
	 */
	public ValueEvent(final Object source, final T oldValue, final T newValue, final Object reason) {
		super(source);
		this.oldValue = oldValue;
		this.newValue = newValue;
		this.reason = reason;
	}
	
	/**
	 * Returns the new value or @c null.
	 * 
	 * @see #getOldValue()
	 */
	public T getNewValue() { return newValue; }

	/**
	 * Returns the old value or @c null.
	 * 
	 * @see #getNewValue()
	 */
	public T getOldValue() { return oldValue; }
	
	/**
	 * Returns the event reason or @c null.
	 * 
	 * @see #isReason(Object)
	 */
	public Object getReason() { return reason; }

	/**
	 * Returns @c true if event reason equals @p reason.
	 * 
	 * @see #getReason()
	 */
	public boolean isReason(final Object reason) {
		return Objects.equals(this.reason, reason);
	}

	// private
	
	// Serializable

	@SuppressWarnings("unchecked")
	private void readObject(final ObjectInputStream input) throws ClassNotFoundException, IOException {
		input.defaultReadObject();

		//if (source == null)
		//	throw new IllegalArgumentException();

		Object o;
		
		o = TK.deserialize(input, "newValue");
		if (o != null)
			newValue = (T)o;
		
		o = TK.deserialize(input, "oldValue");
		if (o != null)
			oldValue = (T)o;
		
		o = TK.deserialize(input, "reason");
		if (o != null)
			reason = o;
	}

	private void writeObject(final ObjectOutputStream output) throws IOException {
		output.defaultWriteObject();
		TK.serialize(output, "newValue", newValue);
		TK.serialize(output, "oldValue", oldValue);
		TK.serialize(output, "reason", reason);
	}

}
