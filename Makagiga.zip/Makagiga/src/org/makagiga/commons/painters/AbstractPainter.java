// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.painters;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Transparency;
import java.awt.image.VolatileImage;
import java.io.Serializable;
import java.util.Objects;

import org.makagiga.commons.UI;

/**
 * @since 2.0
 */
public abstract class AbstractPainter
implements
	Painter,
	javax.swing.Painter<Component>,
	Serializable
{

	// private

	private transient BasicStroke stripesStroke;
	private boolean cached = true;
	private boolean paintStripes;
	private boolean usePainterInsets;
	private Cache cache;
	private Color primaryColor;
	private Insets insets;
	
	// public
	
	public AbstractPainter(final Color primaryColor, final Insets insets) {
		this.primaryColor = primaryColor;
		if (insets != null)
			this.insets = (Insets)insets.clone();
	}
	
	/**
	 * @since 4.4
	 */
	public boolean getPaintStripes() { return paintStripes; }

	/**
	 * @since 4.4
	 */
	public void setPaintStripes(final boolean value) {
		if (value != paintStripes) {
			paintStripes = value;
			if (cache != null)
				cache.invalidate();
		}
	}

	public Color getPrimaryColor() { return primaryColor; }
		
	public void setPrimaryColor(final Color value) {
		if (cache != null) {
			if (!Objects.equals(primaryColor, value)) {
				primaryColor = value;
				cache.invalidate();
			}
		}
		else {
			primaryColor = value;
		}
	}

	@Override
	public Insets getPainterInsets(final Component c) {
		return (insets == null) ? null : (Insets)insets.clone();
	}
	
	public void setPainterInsets(final Insets value) {
		if (cache != null) {
			if (!Objects.equals(insets, value)) {
				insets = (value == null) ? null : (Insets)value.clone();
				cache.invalidate();
			}
		}
		else {
			insets = value;
		}
	}

	/**
	 * @since 4.8
	 */
	public static GlassPainter.RoundType getRoundType(final Painter painter) {
		if (painter instanceof GlassPainter)
			return GlassPainter.class.cast(painter).getRoundType();
		
		if (painter instanceof GradientPainter)
			return GradientPainter.class.cast(painter).isRounded() ? GlassPainter.RoundType.ALL : GlassPainter.RoundType.NONE;

		return GlassPainter.RoundType.NONE;
	}

	/**
	 * @since 4.8
	 */
	public static void setRoundType(final Component c, final Painter painter, final GlassPainter.RoundType value) {
		if (painter instanceof GlassPainter) {
			GlassPainter p = (GlassPainter)painter;
			if (!Objects.equals(p.getRoundType(), value)) {
				p.setRoundType(value);
				c.repaint();
			}
		}
		else if (painter instanceof GradientPainter) {
			GradientPainter p = (GradientPainter)painter;
			boolean newRounded = (value == GlassPainter.RoundType.ALL);
			if (p.isRounded() != newRounded) {
				p.setRounded(newRounded);
				c.repaint();
			}
		}
	}

	/**
	 * @mg.default {@code false}
	 *
	 * @since 3.8.8
	 */
	public boolean getUsePainterInsets() { return usePainterInsets; }

	/**
	 * @since 3.8.8
	 */
	public void setUsePainterInsets(final boolean value) { usePainterInsets = value; }

	/**
	 * Invalidates the painter cache.
	 *
	 * @since 3.4
	 */
	public void invalidate() {
		if (cache != null)
			cache.invalidate();
	}

	/**
	 * @since 3.0
	 */
	public boolean isCached() { return cached; }

	/**
	 * @since 3.0
	 */
	public void setCached(final boolean value) {
		if (value != cached) {
			cached = value;
			if (cache != null)
				cache.invalidate();
		}
	}

	/**
	 * Returns @c true.
	 * 
	 * @since 3.0
	 */
	public boolean isOpaque() { return true; }
	
	@Override
	public void paint(final Component c, final Graphics2D g) {
		Insets i = usePainterInsets ? getPainterInsets(c) : null;
		if (i == null)
			paint(c, g, 0, 0, c.getWidth(), c.getHeight());
		else
			paint(c, g, i.left, i.top, c.getWidth() - (i.left + i.right), c.getHeight() - (i.top + i.bottom));
	}

	// javax.swing.Painter

	/**
	 * @mg.note
	 * Does nothing if {@code object} is {@code null}.
	 * 
	 * @since 4.0
	 */
	@Override
	public void paint(final Graphics2D g, final Component object, final int w, final int h) {
		if (object != null)
			paint(object, g, 0, 0, w, h);
	}
	
	// protected
	
	/**
	 * @since 4.0
	 */
	protected Cache getCache() { return cache; }

	/**
	 * @since 4.0
	 */
	protected void setCache(final Cache value) { cache = value; }
	
	/**
	 * @since 4.0
	 */
	protected Insets getInsets() { return insets; }
	
	/**
	 * @since 4.4
	 */
	protected void paintStripes(final Component object, final Graphics2D g, final int x, final int y, final int width, final int height, final Color color) {
		UI.setAntialiasing(g, true);
		g.setColor(color);
		int size = 10;
		if (stripesStroke == null)
			stripesStroke = new BasicStroke(size);
		g.setStroke(stripesStroke);
		for (int px = x; px < x + width; px += size * 2) {
			g.drawLine(px, y, px - size / 2, y + height - 1);
		}
	}

	// public classes

	/**
	 * @since 3.0
	 */
	public static final class Cache implements Serializable {
		private static final long serialVersionUID = 5382010243884201615L;

		// private

		private transient boolean paintInProgress;
		private int x;
		private int y;
		private int width;
		private int height;
		private transient VolatileImage image;

		// public

		public Cache() {
			invalidate();
		}

		public void invalidate() {
			//MLogger.debug("painter-cache", "invalidate");

			paintInProgress = false;
			x = -1;
			y = -1;
			width = -1;
			height = -1;
			if (image != null) {
				image.flush();
				image = null;
			}
		}

		public boolean paint(final Painter p, final Component c, final Graphics2D g, final int x, final int y, final int width, final int height) {
			if ((p instanceof AbstractPainter) && !AbstractPainter.class.cast(p).isCached())
				return false;

			if (c == null)
				return false;

			if (paintInProgress)
				return false;

			if (
				(this.x != x) ||
				(this.y != y) ||
				(this.width != width) ||
				(this.height != height)
			) {
				invalidate();
			}

			do {
				int code = (image == null) ? VolatileImage.IMAGE_INCOMPATIBLE : image.validate(c.getGraphicsConfiguration());

				if (code == VolatileImage.IMAGE_INCOMPATIBLE) {
					invalidate();
					image = UI.createCompatibleVolatileImage(width, height, Transparency.OPAQUE);
				}

				if (code != VolatileImage.IMAGE_OK) {
					Graphics2D vg = image.createGraphics();
					paintInProgress = true;
					try {
						// HACK: workaround for VolatileImage background; detect component background change
						if ((p instanceof AbstractPainter) && !AbstractPainter.class.cast(p).isOpaque()) {
							Component parent = c.getParent();
							if (parent != null) {
								Color bg = parent.getBackground();
								if (bg != null) {
									vg.setColor(bg);
									vg.fillRect(0, 0, width, height);
								}
							}
						}

						p.paint(c, vg, 0, 0, width, height);
					}
					finally {
						paintInProgress = false;
					}
					vg.dispose();
				}

				this.x = x;
				this.y = y;
				this.width = width;
				this.height = height;
				g.drawImage(image, x, y, null);
			} while (image.contentsLost());

			return true;
		}

	}

}
