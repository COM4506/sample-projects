// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.painters;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics2D;

import org.makagiga.commons.MColor;
import org.makagiga.commons.UI;

/**
 * @since 2.0
 */
public class FlatPainter extends AbstractPainter {
	
	// public
	
	/**
	 * @since 4.2
	 */
	public FlatPainter() {
		this((Color)null);
	}
	
	public FlatPainter(final Color color) {
		super(color, null);
	}
	
	/**
	 * @since 5.0
	 */
	public FlatPainter(final Component c) {
		this(getBG(c));
	}
	
	@Override
	public void paint(final Component c, final Graphics2D g, final int x, final int y, final int width, final int height) {
		Color color = getPrimaryColor();
		if (color != null)
			g.setColor(color);
		g.fillRect(x, y, width, height);
	}
	
	// private
	
	private static Color getBG(final Component c) {
		Color bg = UI.getBackground(c);

		return MColor.isDark(bg) ? MColor.deriveColor(bg, 1.1f) : MColor.deriveColor(bg, 0.96f);
	}

}
