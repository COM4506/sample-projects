// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.painters;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import java.util.Objects;

import org.makagiga.commons.UI;

/**
 * @since 2.0
 */
public class RoundedBackgroundPainter extends AbstractPainter {
	
	// private

	private int arc;

	// public

	public RoundedBackgroundPainter() {
		this(null, 9, UI.createInsets(0));
	}

	/**
	 * @since 3.0
	 */
	public RoundedBackgroundPainter(final Color color) {
		this(color, 9, UI.createInsets(0));
	}

	public RoundedBackgroundPainter(final Color color, final int arc, final Insets insets) {
		super(color, Objects.requireNonNull(insets));
		this.arc = arc;
	}

	@Override
	public boolean isOpaque() {
		return arc == 0;
	}

	@Override
	public void paint(final Component c, final Graphics2D g, final int x, final int y, final int width, final int height) {
		Color color = getPrimaryColor();
		if (color == null)
			color = UI.getDarker(c.getBackground(), Color.WHITE);

		Insets insets = getInsets();
		g.setColor(color);
		Shape shape = new RoundRectangle2D.Float(
			x + insets.left,
			y + insets.top,
			width - (insets.left + insets.right),
			height - (insets.top + insets.bottom),
			arc,
			arc
		);
		Object saveAA = UI.setAntialiasing(g, true);
		g.fill(shape);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, saveAA);
	}

}
