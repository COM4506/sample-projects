// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.painters;

import java.awt.Color;
import java.awt.Component;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.Objects;

import org.makagiga.commons.MColor;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;

/**
 * @since 2.0
 */
public class GlassPainter extends AbstractPainter {
	
	// public

	public enum RoundType { NONE, ALL, TOP, BOTTOM }

	// private

	private RoundType roundType = RoundType.ALL;

	// public

	public GlassPainter() {
		this((Color)null);
	}

	public GlassPainter(final Color color) {
		super(color, null);
		setCache(new Cache());
	}

	/**
	 * @since 3.4
	 */
	public GlassPainter(final Color color, final RoundType roundType) {
		super(color, null);
		this.roundType = Objects.requireNonNull(roundType);
		setCache(new Cache());
	}
	
	/**
	 * @since 4.0
	 */
	public static int getArcForHeight(final int h) {
		return Math.min(Math.max(8, h / 3), 24);
	}

	/**
	 * @since 3.8.8
	 */
	public static Color getBrighterColor(final Color baseColor) {
		return MColor.getBrighter(
			baseColor,
			MColor.isDark(baseColor) ? 35 : 55
		);
	}

	public RoundType getRoundType() { return roundType; }

	public void setRoundType(final RoundType value) {
		if (!Objects.equals(roundType, value)) {
			roundType = Objects.requireNonNull(value);
			getCache().invalidate();
		}
	}

	@Override
	public boolean isOpaque() {
		return roundType == RoundType.NONE;
	}

	@Override
	public void paint(final Component c, final Graphics2D graphics, final int x, final int y, final int w, final int h) {
		//Benchmark b = Benchmark.begin("glass-painter");

		// nothing to paint
		if ((w == 0) || (h  == 0))
			return;

		Graphics2D g = (Graphics2D)graphics.create();

		if (isOpaque() && getCache().paint(this, c, g, x, y, w, h)) {
			g.dispose();
			//b.end("cached");

			return;
		}

		int midHeight = h / 2;

		Color baseColor = getPrimaryColor();
		if (baseColor == null)
			baseColor = UI.getBackground(c);

		final int ARC = getArcForHeight(h);

		// bottom gradient
		GradientPaint bottomGradient = new GradientPaint(
			0.0f, midHeight + y, MColor.deriveColor(baseColor, 0.96f),
			0.0f, h + y, baseColor
		);
		g.setPaint(bottomGradient);

		Shape shape = null;
		switch (roundType) {
			case NONE:
			case TOP:
				shape = new Rectangle2D.Float(x, midHeight - ARC / 2 + y, w, midHeight + ARC / 2 + 1);
				g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
				break;
			case ALL:
			case BOTTOM:
				shape = new RoundRectangle2D.Float(x, midHeight - ARC / 2 + y, w, midHeight + ARC / 2 + 1, ARC, ARC);
				g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
				break;
			default:
				throw new WTFError(roundType);
		}
		g.fill(shape);

		// top gradient
		Color topBrighterColor = getBrighterColor(baseColor);
		int y2 = midHeight + ARC / 4;
		GradientPaint topGradient = new GradientPaint(
			0.0f, (float)y, topBrighterColor,
			0.0f, y2 + y, baseColor
		);
		g.setPaint(topGradient);

		switch (roundType) {
			case NONE:
			case BOTTOM:
				shape = new Rectangle2D.Float(x, y, w, y2);
				g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
				break;
			case ALL:
			case TOP:
				shape = new RoundRectangle2D.Float(x, y, w, y2, ARC, ARC);
				g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
				break;
			default:
				throw new WTFError(roundType);
		}
		g.fill(shape);

		if (getPaintStripes())
			paintStripes(c, g, x, y, w, h, baseColor);

		g.dispose();
		//b.end("not cached");
	}

}
