// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Objects;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;
import java.util.zip.ZipInputStream;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.cache.FileCache;

public final class Net {
	
	// public

	/**
	 * @since 2.0
	 */
	public static final int DOWNLOAD_NO_CACHE_UPDATE = 1;

	/**
	 * @since 2.0
	 */
	public static final int DOWNLOAD_USE_CACHE = 1 << 1;

	/**
	 * Accept "gzip,deflate,compress" encoding.
	 *
	 * @since 2.0
	 */
	public static final int SETUP_COMPRESS = 1 << 2;
	
	/**
	 * Accept "pack200-gzip" encoding.
	 * 
	 * @since 2.0
	 */
	public static final int SETUP_PACK200_GZIP = 1 << 3;
	
	/**
	 * @since 5.4
	 */
	public static final int CHECK_MOVED_PERMANENTLY = 1 << 4;
	
	/**
	 * @since 4.2
	 */
	public static final IntegerProperty connectTimeout = new IntegerProperty(30000, IntegerProperty.SECURE_WRITE);

	/**
	 * @since 4.2
	 */
	public static final IntegerProperty readTimeout = new IntegerProperty(30000, IntegerProperty.SECURE_WRITE);

	/**
	 * @since 4.0
	 */
	public static final URI ABOUT_BLANK = URI.create("about:blank");
	
	// public

	/**
	 * Checks for the @c HttpURLConnection.HTTP_MOVED_TEMP (302) HTTP Status-Code.
	 * Reopens and returns a new connection using the new "Location" field if necessary.
	 *
	 * @param connection the URL connection
	 * @param flags the flags used by @c setupConnection
	 *
	 * @since 3.6
	 */
	@SuppressFBWarnings("CFS_CONFUSING_FUNCTION_SEMANTICS")
	public static URLConnection checkTemporaryRedirect(final URLConnection connection, final int flags) throws IOException {
		if (!(connection instanceof HttpURLConnection))
			return connection;

		HttpURLConnection http = (HttpURLConnection)connection;
		int code = http.getResponseCode();
		
		if (
			(code == HttpURLConnection.HTTP_MOVED_TEMP/* 302 */) ||
			(
				(code == HttpURLConnection.HTTP_MOVED_PERM/* 301 */) &&
				((flags & CHECK_MOVED_PERMANENTLY) != 0)
			)
		) {
			http.disconnect();
			String newLocation = connection.getHeaderField("Location");

			if (newLocation == null)
				return connection;

			URLConnection result = new URL(newLocation).openConnection();
			setupConnection(result, flags);

			return result;
		}
		else {
			return connection;
		}
	}

	/**
	 * Try to fix malformed URI
	 * by escaping illegal characters.
	 *
	 * @since 3.8.3
	 */
	public static URI fixURI(final String uriString) {
		StringBuilder s = new StringBuilder(uriString);
		for (int i = 0; i < 10; i++) {
			try {
				return URI.create(s.toString());
			}
			catch (IllegalArgumentException runtimeException) {
				URISyntaxException exception = (URISyntaxException)runtimeException.getCause();
				int pos = exception.getIndex();
				
				if (pos == -1)
					throw runtimeException;

				String reason = exception.getReason();

				// fix double "#"
				if (
					(reason != null) &&
					reason.startsWith("Illegal character in fragment") &&
					(s.charAt(pos) == '#')
				) {
					s.deleteCharAt(pos);
					
					continue; // for
				}

				if ((reason != null) && !reason.startsWith("Illegal character"))
					throw runtimeException;

				// escape illegal character
				char illegalChar = s.charAt(pos);
				s.deleteCharAt(pos);
				s.insert(pos, TK.escapeURL(Character.toString(illegalChar)));
			}
		}

		throw new IllegalArgumentException(new URISyntaxException(uriString, "Malformed link address"));
	}
	
	/**
	 * @since 4.4
	 */
	public static String getBaseURL(final URL url) {
		return url.getProtocol() + "://" + url.getHost() + "/";
	}

	/**
	 * @since 2.0
	 */
	public static InputStream getInputStream(final URLConnection connection) throws IOException {
		String contentEncoding = connection.getContentEncoding();
		if (contentEncoding != null) {
			if (contentEncoding.contains("compress")) {
				return new ZipInputStream(connection.getInputStream());
			}
			else if (contentEncoding.contains("gzip")) {
				return new GZIPInputStream(connection.getInputStream());
			}
			else if (contentEncoding.contains("deflate")) {
				return new InflaterInputStream(connection.getInputStream());
			}
			else if (contentEncoding.contains("pack200-gzip")) {
				return new GZIPInputStream(connection.getInputStream());
			}
		}
			
		return connection.getInputStream();
	}
	
	public static boolean isHTTP(final String url) {
		return url.startsWith("http://") || url.startsWith("https://");
	}

	/**
	 * @since 4.0
	 */
	public static boolean isLocalFile(final String location) {
		return location.startsWith("file:/") || TK.startsWith(location, '/');
	}
	
	/**
	 * @since 1.2
	 */
	public static void setupConnection(final URLConnection connection, final int flags) {
		Flags f = Flags.valueOf(flags);
		String acceptEncoding = null;
		if (f.isSet(SETUP_COMPRESS))
			acceptEncoding = "gzip,deflate,compress";
		if (f.isSet(SETUP_PACK200_GZIP)) {
			if (acceptEncoding == null)
				acceptEncoding = "pack200-gzip";
			else
				acceptEncoding += ",pack200-gzip";
		}
		if (acceptEncoding != null)
			connection.setRequestProperty("Accept-Encoding", acceptEncoding);
		
		int min = 1000; // 1s
		int max = 1000 * 300; // 5m
		connection.setConnectTimeout(connectTimeout.get(min, max));
		connection.setReadTimeout(readTimeout.get(min, max));
	}

	/**
	 * @since 3.0
	 */
	public static void setupOutputProperties(final URLConnection connection, final String contentType, final long contentLength) {
		connection.setDoOutput(true);
		connection.setRequestProperty("Content-type", contentType);
		connection.setRequestProperty("Content-length", Long.toString(contentLength));
	}
	
	// private
	
	@Uninstantiable
	private Net() {
		TK.uninstantiable();
	}
	
	// public classes
	
	/**
	 * @since 2.0
	 */
	public static final class DownloadInfo {
		
		// private

		private boolean autoRequestFocus = true;
		private boolean modal = true;
		private boolean useTemporaryDirectory = true;
		private Class<? extends InputStream> inputType;
		private File destinationFile;
		private File file;
		private FileCache.Group group;
		private FS.ProgressListener progressListener;
		private InputStream input;
		private final int flags;
		private long lastModified;
		private long length = -1;
		private static final MLogger log = MLogger.get("download");
		private OutputStream output;
		private final String cacheSuffix;
		private String description = "";
		private final URL url;
		private URLConnection connection;
		
		// public

		/**
		 * @since 3.4
		 */
		public DownloadInfo(final URL url, final String cacheSuffix, final int flags) {
			this.url = url;
			this.cacheSuffix = cacheSuffix;
			this.flags = flags;
		}

		public void cancelDownload() {
			shutDownConnection();
			getGroup().remove(url);
			if (file != null) {
				file.delete();
				file = null;
			}
		}

		public String getCacheSuffix() { return cacheSuffix; }
		
		public URLConnection getConnection() { return connection; }

		/**
		 * @since 5.0
		 */
		public String getDescription() { return description; }

		/**
		 * @since 5.0
		 */
		public void setDescription(final String value) {
			description = Objects.requireNonNull(value);
		}

		/**
		 * @since 3.4
		 */
		public File getDestinationFile() { return destinationFile; }

		/**
		 * @since 3.4
		 */
		public void setDestinationFile(final File value) { destinationFile = value; }

		public File getFile() { return file; }
		
		/**
		 * @since 5.0
		 */
		public FileCache.Group getGroup() {
			return (group == null) ? FileCache.getDownloadGroup() : group;
		}

		/**
		 * @since 5.0
		 */
		public void setGroup(final FileCache.Group value) { group = value; }

		public Class<? extends InputStream> getInputType() { return inputType; }
		
		public long getLastModified() { return lastModified; }
		
		public long getLength() { return length; }
		
		public URL getURL() { return url; }

		/**
		 * A hint for the {@link org.makagiga.commons.swing.MDownloadDialog}.
		 *
		 * @see java.awt.Window#isAutoRequestFocus()
		 *
		 * @since 4.8
		 */
		public boolean isAutoRequestFocus() { return autoRequestFocus; }

		/**
		 * A hint for the {@link org.makagiga.commons.swing.MDownloadDialog}.
		 *
		 * @see java.awt.Window#setAutoRequestFocus(boolean)
		 *
		 * @since 4.8
		 */
		public void setAutoRequestFocus(final boolean value) { autoRequestFocus = value; }
		
		/**
		 * @since 4.10
		 */
		public boolean isModal() { return modal; }

		/**
		 * @since 4.10
		 */
		public void setModal(final boolean value) { modal = value; }

		public void setProgressListener(final FS.ProgressListener value)  { progressListener = value; }
		
		/**
		 * @since 4.10
		 */
		public void setUseTemporaryDirectory(final boolean value) { useTemporaryDirectory = value; }
		
		public void shutDownConnection() {
			try {
				FS.close(input);
			}
			// HACK: at sun.net.www.http.KeepAliveStream.close(KeepAliveStream.java:83)
			catch (NullPointerException exception) {
				MLogger.exception(exception);
			}
			FS.close(output);
			if (connection instanceof HttpURLConnection) {
				HttpURLConnection.class.cast(connection).disconnect();
				connection = null;
			}
		}

		/**
		 * @since 3.4
		 */
		public void startDownload() throws IOException {
			Flags f = Flags.valueOf(flags);
			FileCache.Group cache =
				f.isSet(DOWNLOAD_NO_CACHE_UPDATE | DOWNLOAD_USE_CACHE)
				? getGroup()
				: null;
			try {
				if (f.isSet(DOWNLOAD_NO_CACHE_UPDATE)) {
					file = cache.getFile(url, FileCache.IGNORE_DATE);
					
					if (file != null) {
						length = file.length();

						if (destinationFile != null)
							FS.copyFile(file, destinationFile);

						return;
					}
				}
				
				connection = url.openConnection();
				setupConnection(connection, f.intValue());
				connection = checkTemporaryRedirect(connection, f.intValue());
				lastModified = connection.getLastModified();
				if (f.isSet(DOWNLOAD_USE_CACHE)) {
					file = cache.getFile(url, lastModified);

					if (file != null) {
						log.debugFormat("Using file from cache: %s", file);
						length = file.length();

						if (destinationFile != null)
							FS.copyFile(file, destinationFile);

						return;
					}

					if (lastModified == FileCache.NO_DATE)
						file = cache.newPath(url, FileCache.IGNORE_DATE, cacheSuffix).toFile();
					else
						file = cache.newPath(url, lastModified, cacheSuffix).toFile();
					log.debugFormat("Creating new cache entry: %s", file);
				}
				else {
					if (useTemporaryDirectory || (destinationFile == null))
						file = File.createTempFile("download", cacheSuffix);
					else
						file = destinationFile;
				}

				log.debugFormat("Downloading \"%s\"...", url);
				
				input = getInputStream(connection);
				inputType = input.getClass();
				input = new BufferedInputStream(input);
				output = new FS.BufferedFileOutput(file);
				length = connection.getContentLengthLong();
				FS.copyStream(input, output, FS.COPY_BUF_LENGTH, length, progressListener);
				FS.close(output);

				if ((destinationFile != null) && !destinationFile.equals(file))
					FS.copyFile(file, destinationFile);
			}
			catch (IOException exception) {
				if (cache != null)
					cache.remove(url);

				throw exception;
			}
			catch (Exception exception) {
				if (cache != null)
					cache.remove(url);
				
				throw new IOException(exception);
			}
			finally {
				shutDownConnection();
			}
		}

	}
	
}
