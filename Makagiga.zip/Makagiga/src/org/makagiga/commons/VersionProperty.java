// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.text.ParseException;
import java.util.List;
import java.util.Objects;

import org.makagiga.commons.annotation.Obsolete;

/**
 * A version number property.
 * 
 * @mg.example
 * <pre class="brush: java">
 * VersionProperty version = new VersionProperty();
 *
 * version.set(3, 2, 1, "beta");
 * assert version.toString().equals("3.2.1-beta");
 *
 * version.set(1, 5, 0);
 * assert version.toString().equals("1.5");
 * </pre>
 * 
 * @mg.warning This class is <b>not</b> thread-safe.
 */
@Obsolete
public class VersionProperty extends IntegerProperty {

	// private

	private String qualifier;
	
	// public
	
	/**
	 * Constructs a version property.
	 * The default version number is <i>1.0.0</i>.
	 */
	public VersionProperty() {
		super(0x01_00_00);
	}
	
	/**
	 * Constructs a version property.
	 * 
	 * @param version the version number (example: {@code 0x03_02_01} = <i>3.2.1</i>)
	 * 
	 * @since 2.0
	 */
	public VersionProperty(final int version) {
		super(version);
	}

	/**
	 * @since 4.2
	 */
	public VersionProperty(final int version, final String qualifier) {
		super(version);
		this.qualifier = qualifier;
	}

	/**
	 * @since 4.0
	 */
	public VersionProperty(final int version, final int options) {
		super(version, options);
	}

	@Override
	public int compareTo(final Property<Integer> o) {
		int i = super.compareTo(o);
		if (i == 0) {
			i = Objects.toString(this.qualifier, "")
				.compareTo(Objects.toString(VersionProperty.class.cast(o).qualifier, ""));
		}
		
		return i;
	}

	/**
	 * Returns the bugfix/update version number. (example: 3.2.<b>1</b>)
	 * 
	 * @see #set(int, int, int)
	 */
	public int getBugfix() {
		return getBugfix(get());
	}

	/**
	 * Returns the minor version number. (example: <b>3</b>.2.1)
	 * 
	 * @see #set(int, int, int)
	 */
	public int getMajor() {
		return getMajor(get());
	}
	
	/**
	 * Returns the minor version number. (example: 3.<b>2</b>.1)
	 * 
	 * @see #set(int, int, int)
	 */
	public int getMinor() {
		return getMinor(get());
	}

	/**
	 * Returns the version qualifier string or @c null.
	 *
	 * @since 3.4
	 */
	public String getQualifier() { return qualifier; }

	/**
	 * @since 4.6
	 */
	public static int make(final int major, final int minor, final int bugfix) {
		int value = major << 16;
		value += (minor << 8);
		value += bugfix;
		
		return value;
	}

	/**
	 * Converts a {@code value} (dot separated numbers plus optional qualifier)
	 * to version numbers and qualifier string.
	 * Sets version <code>1.0.0</code> if {@code value} is {@code null} or empty.
	 * 
	 * @throws ParseException If {@code value} is in invalid format
	 */
	@Override
	public void parse(String value) throws ParseException {
		if (TK.isEmpty(value)) {
			set(1, 0, 0);
			
			return;
		}

		try {
			int i = value.indexOf('-');
			String q = null;
			if (i != -1) {
				q = value.substring(i + 1);
				value = value.substring(0, i);
			}

			List<String> tokens = TK.fastSplit(value, '.');
			set(
				(tokens.size() > 0) ? Integer.parseInt(tokens.get(0)) : 1,
				(tokens.size() > 1) ? Integer.parseInt(tokens.get(1)) : 0,
				(tokens.size() > 2) ? Integer.parseInt(tokens.get(2)) : 0,
				q
			);
		}
		catch (NumberFormatException exception) {
			parseError(exception);
		}
	}

	@Override
	public void read(final Config config, final String key) {
		try {
			parse(config.read(key, null));
		}
		catch (ParseException exception) {
			MLogger.exception(exception);
		}
	}

	@Override
	public void write(final Config config, final String key) {
		config.write(key, toString());
	}

	/**
	 * Sets version numbers and @c null qualifier.
	 * 
	 * @param major the major version number
	 * @param minor the minor version number
	 * @param bugfix the bugfix/update version number
	 * 
	 * @see #getMajor()
	 * @see #getMinor()
	 * @see #getBugfix()
	 */
	public void set(final int major, final int minor, final int bugfix) {
		set(major, minor, bugfix, null);
	}

	/**
	 * Sets version numbers and qualifier string.
	 *
	 * @param major the major version number
	 * @param minor the minor version number
	 * @param bugfix the bugfix/update version number
	 * @param qualifier the qualifier string
	 *
	 * @see #getMajor()
	 * @see #getMinor()
	 * @see #getBugfix()
	 * @see #getQualifier()
	 *
	 * @since 3.4
	 */
	public void set(final int major, final int minor, final int bugfix, final String qualifier) {
		this.qualifier = qualifier;
		set(make(major, minor, bugfix));
	}

	/**
	 * @since 4.4
	 */
	public String toDisplayString() {
		if (isNull())
			return "?";
		
		return toDisplayString(get(), qualifier);
	}

	/**
	 * @since 4.4
	 */
	public static String toDisplayString(final int value, final String qualifier) {
		StringBuilder result = new StringBuilder();
		result
			.append(getMajor(value))
			.append('.')
			.append(getMinor(value));

		int bugfix = getBugfix(value);
		if (bugfix != 0) {
			result
				.append('.')
				.append(bugfix);
		}

		if (!TK.isEmpty(qualifier)) {
			result.append(' ');
			if (qualifier.equalsIgnoreCase("beta"))
				result.append(TK.capitalize(qualifier));
			else
				result.append(qualifier);
		}
		
		return result.toString();
	}

	/**
	 * Returns a {@code String} representation of this version number.
	 *
	 * @mg.note "Zero" bugfix number is ignored.
	 *
	 * @mg.example
	 * <ul>
	 * <li><code>0x01_00_00 = "1.0"</code></li>
	 * <li><code>0x03_02_00 = "3.2"</code></li>
	 * <li><code>0x03_02_01 = "3.2.1"</code></li>
	 * <li><code>0x03_02_01 = "3.2.1-beta"</code> (if non-empty/non-null "beta" qualifier)</li>
	 * </ul>
	 */
	@Override
	public String toString() {
		if (isNull())
			return "";
		
		return toString(get(), qualifier);
	}

	/**
	 * @since 4.0
	 */
	public static String toString(final int value, final String qualifier) {
		StringBuilder result = new StringBuilder();
		result
			.append(getMajor(value))
			.append('.')
			.append(getMinor(value));

		int bugfix = getBugfix(value);
		if (bugfix != 0) {
			result
				.append('.')
				.append(bugfix);
		}

		if (!TK.isEmpty(qualifier)) {
			result
				.append('-')
				.append(qualifier);
		}
		
		return result.toString();
	}
	
	// private

	private static int getBugfix(final int i) {
		return i & 0x0000ff;
	}

	private static int getMajor(final int i) {
		return (i >> 16) & 0x0000ff;
	}
	
	private static int getMinor(final int i) {
		return (i >> 8) & 0x0000ff;
	}

}
