// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.request;

import org.makagiga.commons.Attributes;

/**
 * @since 2.0
 */
public final class RequestInfo<T> {

	// private

	private Attributes<String, Object> properties;
	private volatile boolean cancelled;
	private final RequestSource<T> source;
	
	// public

	/**
	 * @since 5.0
	 */
	public RequestInfo(final RequestSource<T> source, final Attributes<String, ?> properties) {
		this.source = source;
		if (properties != null)
			this.properties = new Attributes<>(properties);
	}

	@SuppressWarnings("unchecked")
	public synchronized <V> V getProperty(final String key, final V defaultValue) {
		if (properties == null)
			return defaultValue;
		
		return (V)properties.get(key);
	}

	public synchronized void setProperty(final String key, final Object value) {
		if (properties == null)
			properties = new Attributes<>();
		properties.set(key, value);
	}
	
	public RequestSource<T> getSource() { return source; }
	
	public boolean isCancelled() { return cancelled; }
	
	public void setCancelled(final boolean value) { cancelled = value; }

}
