// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.request;

import java.awt.EventQueue;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

import org.makagiga.commons.Attributes;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.security.MAccessController;

/**
 * @since 2.0
 */
public abstract class AbstractRequestManager<T> {
	
	// private
	
	private final AccessControlContext acc;
	private volatile boolean finishing;
	private ExecutorService threadPool;
	private int count;
	private final int maxThreads;
	private int threadPriority = Thread.NORM_PRIORITY;
	
	// public
	
	/**
	 * @since 4.0
	 */
	public AbstractRequestManager(final int maxThreads) {
		acc = AccessController.getContext();
		this.maxThreads = maxThreads;
		initThreadPool();
	}
	
	public List<Runnable> cancelAll() {
		if (!EventQueue.isDispatchThread())
			throw new IllegalStateException("\"cancelAll\" should be invoked on EDT");
		
		synchronized (this) {
			count = 0;
		
			return threadPool.shutdownNow();
		}
	}
	
	public synchronized void finishAll() {
		List<Runnable> tasks = cancelAll();
		if (!TK.isEmpty(tasks)) {
			finishing = true;
			for (Runnable i : tasks)
				i.run();
		}
		initThreadPool();
	}
	
	/**
	 * @since 3.0
	 */
	public synchronized int getCount() { return count; }
	
	public synchronized RequestInfo<T> startRequest(final RequestSource<T> source, final Attributes<String, ?> properties) {
		final RequestInfo<T> info = new RequestInfo<>(source, properties);
		try {
			count++;
			threadPool.execute(new Runnable() {
				@Override
				public void run() {
					if (!EventQueue.isDispatchThread()) {
						Thread t = Thread.currentThread();
						//MLogger.debug("request", "Setting thread priority: %s = %s (%s)", t, threadPriority, AbstractRequestManager.this);
						t.setPriority(threadPriority);
					}

					// get result
					try {
						final T result;
						if (info.isCancelled()) {
							result = null;
							MLogger.debug("request", "Cancelled: %s", info);
						}
						else {
							if (finishing) {
								// we are on EDT
								result = getResult(info);
							}
							else {
								if (System.getSecurityManager() == null) {
									result = getResult(info);
								}
								else {
									result = AccessController.doPrivileged(new PrivilegedExceptionAction<T>() {
										@Override
										public T run() throws Exception {
											return getResult(info);
										}
									}, acc);
								}
							}
						}
						
						if (finishing) {
							// we are on EDT
							source.requestDone(info, result);
						}
						else {
							Runnable r = new Runnable() {
								@Override
								public void run() {
									source.requestDone(info, result);
								}
							};
							if (System.getSecurityManager() == null)
								EventQueue.invokeLater(r);
							else
								MAccessController.invokeLater(r, acc);
						}
					}
					catch (Exception exception) {
						MLogger.exception(exception);
					}
					finally {
						synchronized (AbstractRequestManager.this) {
							count--;
						}
					}
				}
			} );
		}
		catch (RejectedExecutionException exception) {
			count--;
			
			MLogger.exception(exception);
			
			info.setCancelled(true);
		}

		return info;
	}
	
	// protected
	
	protected abstract T getResult(final RequestInfo<T> info) throws Exception;

	/**
	 * @since 3.6
	 */
	protected ExecutorService getThreadPool() { return threadPool; }

	@InvokedFromConstructor
	protected void initThreadPool() {
		count = 0;
		finishing = false;
		threadPool = Executors.newFixedThreadPool(maxThreads);
	}
	
	/**
	 * @since 4.0
	 */
	protected void setThreadPriority(final int value) { threadPriority = value; }
	
	/**
	 * @since 4.0
	 */
	protected void sleep(final long ms) {
		if (!finishing)
			TK.sleep(ms);
	}

}
