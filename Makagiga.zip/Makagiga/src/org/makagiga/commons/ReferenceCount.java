// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * A <i>reference count</i> map.
 *
 * @mg.example
 * <pre class="brush: java">
 * ReferenceCount&lt;String&gt; ref = new ReferenceCount&lt;&gt;();
 * ref.addReference("A"); // ref. count = 1
 * ref.addReference("A"); // ref. count = 2
 * ref.dereference("A"); // ref. count = 1; returns false
 * ref.dereference("A"); // ref. count = 0; returns true
 * </pre>
 *
 * @param <K> the key type
 *
 * @since 1.2, 4.0 (extends Object)
 */
public class ReferenceCount<K> implements Serializable {

	// private

	private final Map<K, MutableInteger> map;
	
	// public
	
	/**
	 * Constructs a new reference count map with
	 * the default initial capacity and the default load factor.
	 */
	public ReferenceCount() {
		this(new HashMap<K, MutableInteger>());
	}

	/**
	 * @since 4.0
	 */
	public ReferenceCount(final Map<K, MutableInteger> map) {
		this.map = Objects.requireNonNull(map);
	}

	/**
	 * Increases <i>reference count</i> for the {@code key}.
	 *
	 * @param key the key
	 *
	 * @return A number of <i>references</i> to the {@code key}
	 */
	public int addReference(final K key) {
		MutableInteger value = map.get(key);
		if (value == null) {
			value = new MutableInteger(1);
			map.put(key, value);
		}
		else {
			value.set(value.intValue() + 1);
		}
			
		return value.intValue();
	}

	/**
	 * Decreases <i>reference count</i> for the {@code key}.
	 *
	 * @param key the key
	 *
	 * @return {@code true} if there are no more references to the {@code key}
	 */
	public boolean dereference(final K key) {
		return removeReference(key) == 0;
	}
	
	/**
	 * @since 4.2
	 */
	public int get(final K key) {
		MutableInteger value = map.get(key);
		
		return (value == null) ? 0 : value.intValue();
	}

	/**
	 * @since 4.0
	 */
	public Map<K, MutableInteger> getMap() { return map; }

	/**
	 * @since 4.0
	 */
	public boolean isEmpty() {
		return map.isEmpty();
	}

	/**
	 * Decreases <i>reference count</i> for the {@code key}.
	 *
	 * @param key the key
	 *
	 * @return A number of <i>references</i> to the {@code key}
	 * or <code>-1</code> if {@code key} does not exist.
	 */
	public int removeReference(final K key) {
		MutableInteger value = map.get(key);
		
		if (value == null)
			return -1;
		
		if (value.intValue() == 1) {
			map.remove(key);
			
			return 0;
		}

		value.set(value.intValue() - 1);
		
		return value.intValue();
	}
	
}
