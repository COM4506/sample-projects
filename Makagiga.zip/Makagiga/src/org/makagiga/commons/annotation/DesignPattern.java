// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @since 3.8.3
 */
@Documented
@Inherited
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface DesignPattern {

	// public

	/**
	 * @since 4.0
	 */
	public static final String ABSTRACT_FACTORY = "Abstract Factory";

	/**
	 * @since 4.2
	 */
	public static final String ADAPTER = "Adapter";

	/**
	 * @since 4.2
	 */
	public static final String BRIDGE = "Bridge";

	/**
	 * @since 4.0
	 */
	public static final String BUILDER = "Builder";

	/**
	 * @since 4.0
	 */
	public static final String COMMAND = "Command";

	/**
	 * @since 4.2
	 */
	public static final String DECORATOR = "Decorator";

	/**
	 * @since 4.0
	 */
	public static final String FACTORY = "Factory";

	/**
	 * @since 4.2
	 */
	public static final String OBJECT_POOL = "Object Pool";

	/**
	 * @since 4.2
	 */
	public static final String PROTOTYPE = "Prototype";

	/**
	 * @since 4.0
	 */
	public static final String SINGLETON = "Singleton";

	/**
	 * @since 4.0
	 */
	public static final String UNKNOWN = "Unknown";

	/**
	 * @since 4.0
	 */
	public static final String VISITOR = "Visitor";

	// public

	/**
	 * @since 4.0
	 */
	public String[] value();

}
