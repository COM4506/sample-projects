// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.sb;

import java.awt.Window;
import java.net.URI;

/**
 * @since 2.0
 */
public interface PageChecker {

	// public
	
	public enum PageStatus { UNKNOWN, OK, BLACKLIST, MALWARE }

	// public

	/**
	 * Returns a non-{@code null} page status for {@code uri}.
	 *
	 * @param uri the URI to check
	 *
	 * @throws IllegalArgumentException If {@code uri} is {@code null}
	 *
	 * @since 3.0
	 */
	public PageStatus getPageStatus(final URI uri);

	/**
	 * @since 3.0
	 */
	public boolean showWarning(final Window parent, final URI uri, final PageStatus status);

}
