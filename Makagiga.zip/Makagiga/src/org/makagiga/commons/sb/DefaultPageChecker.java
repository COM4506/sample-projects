// Copyright 2008 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.sb;

import static org.makagiga.commons.UI.i18n;

import java.awt.Window;
import java.net.URI;
import java.security.BasicPermission;
import java.util.Set;

import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.TK;
import org.makagiga.commons.swing.MMessage;

/**
 * @since 3.0, 3.8.6 (implements PageChecker)
 */
public final class DefaultPageChecker implements PageChecker {
	
	// private
	
	private static PageChecker current = new DefaultPageChecker();
	private final Set<String> knownProtocols;
	private String[] badBytes;
	
	// public
	
	public synchronized static PageChecker get() { return current; }
	
	public synchronized static void set(final PageChecker value) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new DefaultPageChecker.Permission("set"));
		
		current = value;
	}

	// PageChecker

	/**
	 * @since 3.8.6
	 */
	@Override
	public PageStatus getPageStatus(final URI uri) {
		if (uri == null)
			throw new IllegalArgumentException("null uri");

		String protocol = uri.getScheme();

		if ("FILE".equalsIgnoreCase(protocol))
			return PageStatus.MALWARE;

		if (!knownProtocols.contains(protocol))
			return PageStatus.UNKNOWN;

		String path = uri.getPath();

		if (TK.isEmpty(path))
			return PageStatus.OK;

		String ascii = TK.toUpperCase(uri.toASCIIString());

		// DOC: http://www.charbase.com/202e-unicode-right-to-left-override
		if (ascii.contains("%E2%80%AE"))
			return PageStatus.MALWARE;

		synchronized (this) {
			if (badBytes == null) {
				badBytes = new String[0x1f + 1];
				for (int i = 0x00; i < badBytes.length; i++)
					badBytes[i] = "%" + TK.toUpperCase(TK.toByteHex(i));
			}
			for (String i : badBytes) {
				if (ascii.contains(i))
					return PageStatus.MALWARE;
			}
		}

		path = TK.toUpperCase(TK.unescapeURL(path));
		path = path.trim();

		if (
			path.endsWith(".BAT") ||
			path.endsWith(".CMD") ||
			path.endsWith(".COM") ||
			path.endsWith(".DESKTOP") ||
			path.endsWith(".EXE") ||
			path.endsWith(".PIF") ||
			path.endsWith(".RUN") ||
			path.endsWith(".WMF") ||
			path.endsWith(".SH")
		)
			return PageStatus.MALWARE;

		return PageStatus.OK;
	}

	/**
	 * @since 3.8.6
	 */
	@Override
	public boolean showWarning(final Window owner, final URI uri, final PageStatus status) {
		return new MMessage.Builder()
			.icon("ui/security-medium")
			.ok(MActionInfo.OPEN_URI)
			.text(i18n("Are you sure you want to open this file?") + "\n\n" + uri)
		.exec(owner);
	}

	// private
	
	private DefaultPageChecker() {
		knownProtocols = TK.newHashSet("ftp", "sftp", "http", "https", "mailto");
	}
	
	// public classes
	
	public static final class Permission extends BasicPermission {
		
		// private
		
		private Permission(final String name) {
			super(name);
		}
		
	}

}
