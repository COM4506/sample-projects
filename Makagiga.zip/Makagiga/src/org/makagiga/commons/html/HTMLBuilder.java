// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.html;

import java.awt.Color;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.Base64;
import java.util.Objects;
import javax.imageio.ImageIO;

import org.makagiga.commons.AbstractMarkupBuilder;
import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.MColor;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Important;

/**
 * A HTML builder.
 *
 * @since 4.0 (org.makagiga.commons.html package)
 */
public class HTMLBuilder extends AbstractMarkupBuilder {

	// public

	/**
	 * HTML 5.0.
	 *
	 * @since 3.8.3
	 */
	public static final String HTML_5 = "<!DOCTYPE html>";

	/**
	 * HTML 4.01 Transitional.
	 */
	public static final String HTML_TRANSITIONAL = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">";

	/**
	 * XHTML 1.0 Strict.
	 */
	public static final String XHTML_STRICT = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">";

	/**
	 * UTF-8 encoding.
	 */
	public static final String UTF_8 = "UTF-8";

	// private

	private boolean html5;

	// public

	/**
	 * Constructs an HTML (not XML) builder without DOCTYPE.
	 */
	public HTMLBuilder() {
		super(false);
	}

	/**
	 * @since 4.0
	 */
	public HTMLBuilder(final boolean xml) {
		super(xml);
	}

	/**
	 * Constructs an HTML builder.
	 * @param doctype A document type (DOCTYPE) (e.g. @ref HTML_TRANSITIONAL)
	 */
	public HTMLBuilder(final String doctype) {
		super(doctype.equals(HTML_5) || doctype.equals(XHTML_STRICT));
		html5 = doctype.equals(HTML_5);
		appendLine(doctype);
	}

	/**
	 * Adds an CSS attribute.
	 * 
	 * @mg.example
	 * <pre class="brush: java">
	 * builder.addAttr("border", "1px solid black");
	 * // Emits: border: 1px solid black;\n
	 * </pre>
	 *
	 * @param name An attribute name
	 * @param value An attribute value
	 */
	public HTMLBuilder addAttr(final String name, final String value) {
		appendLine("%s: %s;", name, value);
		
		return this;
	}

	/**
	 * Adds an CSS color attribute.
	 * 
	 * @mg.example
	 * <pre class="brush: java">
	 * builder.addAttr("background-color", Color.RED);
	 * // Emits: background-color: #ff0000;\n
	 * </pre>
	 *
	 * @param name An attribute name
	 * @param value A color value
	*/
	public HTMLBuilder addAttr(final String name, final Color value) {
		appendLine("%s: %s;", name, ColorProperty.toString(value));
		
		return this;
	}
	
	/**
	 * @throws IllegalArgumentException If @p level is less than 1 or greater than 6
	 * 
	 * @since 2.0
	 */
	public HTMLBuilder addHeader(final int level, final String code) {
		if ((level < 1) || (level > 6))
			throw new IllegalArgumentException("Invalid header \"level\"");
		
		doubleTag("h" + level, code);
		
		return this;
	}

	public HTMLBuilder addLink(final String href, final String rel, final String type, final String title) {
		singleTag(
			"link",
			"href", href,
			"rel", rel,
			"type", type,
			"title", Objects.toString(title, "")
		);
		
		return this;
	}

	/**
	 * Adds a meta information.
	 * 
	 * @mg.example
	 * <pre class="brush: java">
	 * builder.addMeta("Description", "\"Foo\" Home Page");
	 * // Emits: &lt;meta name="Description" content="&amp;quot;Foo&amp;quot; Home Page"&gt;\n
	 * </pre>
	 *
	 * @param name A meta information name
	 * @param value A meta information value
	 */
	public HTMLBuilder addMeta(final String name, final String value) {
		singleTag(
			"meta",
			"name", name,
			"content", value
		);
		
		return this;
	}

	public HTMLBuilder addStyle(final String href) {
		addLink(href, "stylesheet", "text/css", null);
		
		return this;
	}
	
	/**
	 * Append a simple non-semantic bullet list.
	 *
	 * @since 5.6
	 */
	public HTMLBuilder appendBulletList(final Object... items) {
		TK.forEach(items, (i, index) -> {
			append(UI.BULLET);
			append("&nbsp;");
			append(Objects.toString(i));
			if (index < items.length - 1)
				singleTag("br");
		} );
		
		return this;
	}
	
	/**
	 * @since 4.6
	 */
	public HTMLBuilder appendTableCells(final Object... cells) {
		boolean columnHasText = false;
		int cols = 0;
		for (Object i : cells) {
			if (i instanceof TableColumn) {
				cols++;
				columnHasText = !TableColumn.class.cast(i).getName().isEmpty();
			}
			else
				break; // for
		}

		// add header
		if (columnHasText) {
			beginTag("tr");
			for (int i = 0; i < cols; i++)
				doubleTag("td", "<b>" + escape(cells[i].toString()) + "</b>");
			endTag("tr");
		}
		
		// add rows
		int currentCol = 0;
		for (int i = cols; i < cells.length; i++) {
			if (currentCol == 0)
				beginTag("tr");

			// add cell
			TableColumn tableColumn = (TableColumn)cells[currentCol];
			String cellCode =
				tableColumn.isEscape()
				? escape(cells[i].toString())
				: cells[i].toString();
			if (!TK.isEmpty(tableColumn.getStyle()))
				doubleTag("td", cellCode, "style", tableColumn.getStyle());
			else
				doubleTag("td", cellCode);

			currentCol++;
			if (currentCol == cols) {
				endTag("tr");
				currentCol = 0;
			}
		}

		return this;
	}

	/**
	 * Begins the HTML document (ends HEAD, begins BODY)
	 */
	public HTMLBuilder beginDoc() {
		endTag("head");
		beginTag("body");
		
		return this;
	}

	public HTMLBuilder beginHTML(final String title, final String encoding, final String lang) {
		if (isXML()) {
			if (lang == null) {
				if (html5) {
					beginTag("html");
				}
				else {
					beginTag(
						"html",
						"xmlns", "http://www.w3.org/1999/xhtml"
					);
				}
			}
			else {
				if (html5) {
					beginTag(
						"html",
						"lang", lang
					);
				}
				else {
					beginTag(
						"html",
						"xmlns", "http://www.w3.org/1999/xhtml",
						"xml:lang", lang,
						"lang", lang
					);
				}
			}
		}
		else {
			if (lang == null) {
				beginTag("html");
			}
			else {
				beginTag(
					"html",
					"lang", lang
				);
			}
		}
		decIndent();
		beginTag("head");
		if (encoding != null) {
			if (html5) {
				singleTag(
					"meta",
					"charset", encoding
				);
			}
			else {
				singleTag(
					"meta",
					"http-equiv", "Content-Type",
					"content", "text/html; charset=" + encoding
				);
			}
		}
		if (title != null)
			doubleTag("title", escape(title));
		
		return this;
	}

	/**
	 * Begins the HTML (inserts HTML, HEAD, TITLE and META (Content-Type) tags.
	 * @param title A title
	 * @param encoding An encoding
	 */
	public HTMLBuilder beginHTML(final String title, final String encoding) {
		beginHTML(title, encoding, null);
		
		return this;
	}

	/**
	 * Begins the HTML. Inserts HTML and HEAD tags.
	 */
	public HTMLBuilder beginHTML() {
		beginHTML(null, null, null);
		
		return this;
	}

	/**
	 * Begins an CSS rule.
	 * 
	 * @mg.example
	 * <pre class="brush: java">
	 * builder.beginRule("body");
	 * // Emits: \nbody {\n
	 * </pre>
	 */
	public HTMLBuilder beginRule(final String name) {
		appendLine();
		appendLine("%s {", name);
		incIndent();
		
		return this;
	}

	/**
	 * Begins a CSS style.
	 *
	 * @mg.output
	 * <pre class="brush: html">
	 * &lt;style type="text/css"&gt;
	 * </pre>
	 */
	public HTMLBuilder beginStyle() {
		appendLine("<style type=\"text/css\">");
		
		return this;
	}

	/**
	 * @since 3.2
	 */
	public HTMLBuilder bestLinkRules(final Color background) {
		beginRule("a");
			addAttr("color", MColor.getLinkForeground(background));
		endRule();
		beginRule("a:visited");
			addAttr("color", MColor.getVisitedLinkForeground(background));
		endRule();
		beginRule("a:hover");
			addAttr("color", MColor.getHoverLinkForeground(background));
		endRule();
		
		return this;
	}

	/**
	 * @since 5.4
	 */
	public static String createCode(final String htmlCode) {
		return "<code style=\"font-family: " + UI.getMonospacedFontName() + "\">" + htmlCode + "</code>";
	}

	/**
	 * Returns a link tag.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * String link = HTMLBuilder.createLink("http://sf.net", "&lt;SourceForge.net&gt;");
	 * assert link.equals("&lt;a href=\"http://sf.net\"&gt;&amp;lt;SourceForge.net&amp;gt;&lt;/a&gt;");
	 * </pre>
	 *
	 * @param url the URL
	 * @param name the name (automatically escaped)
	 */
	public static String createLink(final String url, final String name) {
		return String.format("<a href=\"%s\">%s</a>", url, TK.escapeXML(name));
	}

	/**
	 * Ends the HTML document (inserts BODY and HTML).
	 */
	public HTMLBuilder endDoc() {
		endTag("body");
		endTag("html");
		
		return this;
	}

	/**
	 * Ends an CSS rule (inserts "}").
	 */
	public HTMLBuilder endRule() {
		decIndent();
		appendLine("}");
		
		return this;
	}

	/**
	 * Ends an CSS style.
	 *
	 * @mg.output
	 * <pre class="brush: html">
	 * \n
	 * &lt;/style&gt;\n
	 * </pre>
	 */
	public HTMLBuilder endStyle() {
		appendLine();
		appendLine("</style>");
		
		return this;
	}

	/**
	 * @see #newSwingDoc()
	 *
	 * @since 3.8.11
	 */
	public HTMLBuilder endSwingDoc() {
		endTag("html");
		
		return this;
	}

	/**
	 * @see #endSwingDoc()
	 *
	 * @since 3.8.11
	 */
	public static HTMLBuilder newSwingDoc() {
		HTMLBuilder html = new HTMLBuilder();
		html.beginTag("html");

		return html;
	}

	/**
	 * @since 5.0
	 */
	public static URI toDataURI(final RenderedImage image, final String format) throws IOException {
		String mime;
		switch (format) {
			case "jpeg":
				mime = "image/jpeg";
				break;
			case "png":
				mime = "image/png";
				break;
			default:
				throw new IOException("Unsupported image format: " + format);
		}
		
		ByteArrayOutputStream output = new ByteArrayOutputStream(16 * 1024);
		ImageIO.write(image, format, output);
		output.close();

		StringBuilder s = new StringBuilder(16 * 1024);
		s.append("data:");
		s.append(mime);
		s.append(";base64,");

		Base64.Encoder encoder = Base64.getEncoder();
		s.append(encoder.encodeToString(output.toByteArray()));

		return URI.create(s.toString());
	}

	// public classes

	/**
	 * @since 4.6
	 */
	public static class TableColumn {
	
		// private
		
		private boolean escape = true;
		private final String name;
		private String style;
	
		// public
		
		public TableColumn() {
			this("");
		}

		public TableColumn(final String name) {
			this.name = Objects.requireNonNull(name);
		}
		
		/**
		 * @since 4.8
		 */
		public boolean isEscape() { return escape; }
		
		/**
		 * @since 4.8
		 */
		public void setEscape(final boolean value) { escape = value; }
		
		public String getName() { return name; }

		public String getStyle() { return style; }
		
		public void setStyle(final String value) { style = value; }

		@Important
		@Override
		public String toString() { return name; }

	}

}
