// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.html;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.Image;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Objects;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.text.AttributeSet;
import javax.swing.text.ComponentView;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.View;
import javax.swing.text.ViewFactory;
import javax.swing.text.html.HTML;
import javax.swing.text.html.FormView;
import javax.swing.text.html.ImageView;
import javax.swing.text.html.ObjectView;

import org.makagiga.commons.Attributes;
import org.makagiga.commons.FS;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Net;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.request.AbstractRequestManager;
import org.makagiga.commons.request.RequestInfo;
import org.makagiga.commons.request.RequestSource;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.MComponent;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MLinkButton;

/**
 * @since 2.0, 4.0 (org.makagiga.commons.html package)
 */
public class HTMLViewFactory implements ViewFactory {

	// private
	
	private boolean loadsSynchronously;
	private final ImageDownloader imageDownloader;
	private static ImageFactory noImageFactory;
	private final ViewFactory impl;
	
	// public
	
	public HTMLViewFactory(final ViewFactory impl) {
		this(impl, null);
	}

	public HTMLViewFactory(final ViewFactory impl, final ImageDownloader imageDownloader) {
		this.impl = impl;
		this.imageDownloader = imageDownloader;
	}

	// CREDITS: http://forum.java.sun.com/thread.jspa?threadID=621766&tstart=240
	@Override
	public View create(final Element element) {
		View view = impl.create(element);

		Object name = element.getAttributes().getAttribute(StyleConstants.NameAttribute);

		// hide comment in editable editor pane
		if (HTML.Tag.COMMENT.equals(name))
			return new HiddenCommentView(element);

		// HACK: buggy/unsupported
		if (view instanceof FormView)
			return new HiddenFormView(element);

		if (view instanceof ImageView) {
			CachedImageView imageView = new CachedImageView(element, imageDownloader);
			imageView.setLoadsSynchronously(getLoadsSynchronously());
			
			return imageView;
		}

		if (view instanceof ObjectView)
			return new NoObjectView(element);

		return view;
	}

	/**
	 * Returns the associated image downloader, or @c null.
	 */
	public ImageDownloader getImageDownloader() { return imageDownloader; }

	public boolean getLoadsSynchronously() { return loadsSynchronously; }
	
	public void setLoadsSynchronously(final boolean value) { loadsSynchronously = value; }
	
	/**
	 * @since 4.2
	 */
	public synchronized static HTMLViewFactory.ImageFactory getNoImageFactory() {
		if (noImageFactory == null)
			noImageFactory = new NoImageFactory();
		
		return noImageFactory;
	}

	// private
	
	private static Component newHiddenComponent() {
		MComponent c = new MComponent();
		c.setVisible(false);
		MComponent.setFixedSize(c, 0, 0);

		return c;
	}

	// public classes
	
	public static class CachedImageView extends ImageView implements RequestSource<Image> {
		
		// private

		private boolean borderColorAvailable = true;
		private boolean downloading;
		private Image image;
		private final WeakReference<ImageDownloader> imageDownloaderRef;
		
		// public
		
		public CachedImageView(final Element element, final ImageDownloader imageDownloader) {
			super(element);
			imageDownloaderRef = new WeakReference<>(imageDownloader);
		}

		@Override
		public Image getImage() {
			return (image != null) ? image : super.getImage();
		}
		
		@Override
		public URL getImageURL() {
			AttributeSet attr = getElement().getAttributes();
			String srcAttr = (String)attr.getAttribute(HTML.Attribute.SRC);

			if (srcAttr == null)
				return null;

			URL source = super.getImageURL();

			if (
				(source == null) ||
				// handle malformed URL
				("http".equals(source.getProtocol()) && TK.isEmpty(source.getHost()))
			)
				return null;

			// HACK: remove width or height attribute to keep image aspect ratio
/*
			Object widthAttr = attr.getAttribute(HTML.Attribute.WIDTH);
			Object heightAttr = attr.getAttribute(HTML.Attribute.HEIGHT);
			if (
				(attr instanceof MutableAttributeSet) &&
				(
					((widthAttr != null) && (heightAttr == null)) ||
					((widthAttr == null) && (heightAttr != null))
				)
			) {
				final MutableAttributeSet mas = (MutableAttributeSet)attr;
				// need new thread to avoid deadlock
				Thread t = new Thread(new Runnable() {
					@Override
					public void run() {
						setLocked(true);
						try {
							mas.removeAttribute(HTML.Attribute.WIDTH);
							mas.removeAttribute(HTML.Attribute.HEIGHT);
						}
						finally {
							setLocked(false);
						}
					}
				}, "Image Attribute Writer");
				t.start();
			}
*/

			// do not cache local files
			if ("file".equals(source.getProtocol())) {
				return source;
			}
			
			ImageDownloader imageDownloader = imageDownloaderRef.get();
			if ((imageDownloader != null) && !getLoadsSynchronously()) {
				if (!downloading) {
					downloading = true;
					imageDownloader.startDownload(this, source);
				}
				
				return null;
			}
			else {
				return ImageDownloader.download(source, Net.DOWNLOAD_USE_CACHE);
			}
		}
		
		@Override
		public Icon getNoImageIcon() {
			return downloading ? getLoadingImageIcon() : super.getNoImageIcon();
		}
		
		@Override
		public String getToolTipText(final float x, final float y, final Shape shape) {
			StringBuilder s = new StringBuilder(256);
			
			// add "alt" text
			String alt = getAltText();
			if (!TK.isEmpty(alt))
				TK.escapeXML(s, alt);
				
			// add "title" text, do not duplicate "alt"
			String title = (String)getElement().getAttributes().getAttribute(HTML.Attribute.TITLE);
			if (!TK.isEmpty(title) && !Objects.equals(alt, title)) {
				if (s.length() > 0)
					s.append("<br>");
				TK.escapeXML(s, title);
			}

			if (s.length() == 0)
				return null;
				
			// wrap long tool tip text
			int maxLineLength = 50;
			if (s.length() > maxLineLength) {
				int lineLength = 0;
				for (int i = 0; i < s.length(); i++) {
					lineLength++;
					if ((s.charAt(i) == ' ') && (lineLength >= maxLineLength)) {
						lineLength = 0;
						s.replace(i, i + 1, "\n");
					}
				}
			}

			// display as HTML
			TK.fastReplace(s, "\n", "<br>");
			s.insert(0, UI.HTML_BEGIN);
			s.append(UI.HTML_END);

			return s.toString();
		}
		
		// RequestSource

		@Override
		public void requestDone(final RequestInfo<Image> info, final Image result) {
			downloading = false;
			image = result;
			
			if (result != null) {
				setSize(image.getWidth(null), image.getHeight(null));
				
				// HACK: invoke *private* "updateImageSize()"
				Method updateImageSizeMethod = AccessController.doPrivileged((PrivilegedAction<Method>)() -> {
					try {
						Field w = ImageView.class.getDeclaredField("width");
						w.setAccessible(true);
						w.setInt(this, image.getWidth(null));
					
						Field h = ImageView.class.getDeclaredField("height");
						h.setAccessible(true);
						h.setInt(this, image.getHeight(null));

						Method method = ImageView.class.getDeclaredMethod("updateImageSize");
						method.setAccessible(true);
						
						return method;
					}
					catch (Exception exception) {
						MLogger.exception(exception);
					}

					return null;
				},
					null,
					MAccessController.ACCESS_DECLARED_MEMBERS_PERMISSION,
					MAccessController.SUPPRESS_ACCESS_CHECKS_PERMISSION
				);
				
				if (updateImageSizeMethod != null) {
					try {
						updateImageSizeMethod.invoke(this);
					}
					catch (ReflectiveOperationException exception) {
						MLogger.exception(exception);
					}
				}

				preferenceChanged(this, true, true);
			}
		}

		// protected

		@Override
		protected void setPropertiesFromAttributes() {
			super.setPropertiesFromAttributes();

			// HACK: no border
			if (borderColorAvailable) {
				AccessController.doPrivileged((PrivilegedAction<Void>)() -> {
					try {
						Field borderColor = ImageView.class.getDeclaredField("borderColor");
						borderColor.setAccessible(true);
						borderColor.set(this, null);
					}
					catch (Exception exception) {
						borderColorAvailable = false;
						MLogger.exception(exception);
					}

					return null;
				},
					null,
					MAccessController.ACCESS_DECLARED_MEMBERS_PERMISSION,
					MAccessController.SUPPRESS_ACCESS_CHECKS_PERMISSION
				);
			}
		}
		
		// private

/*
		private void setLocked(final boolean locked) {
			AccessController.doPrivileged(new PrivilegedAction<Void>() {
				@Override
				public Void run() {
					Document doc = getDocument();

					if (!(doc instanceof AbstractDocument))
						return null;
						
					try {
						Method m = AbstractDocument.class.getDeclaredMethod(locked ? "writeLock" : "writeUnlock");
						m.setAccessible(true);
						m.invoke(doc);
					}
					catch (Exception exception) {
						MLogger.exception(exception);
					}
					
					return null;
				}
			}, acc);
		}
*/

	}
	
	public static class ImageDownloader extends AbstractRequestManager<Image> {

		// private

		private ImageFactory imageFactory;
		private final int downloadOptions;
		
		// public
		
		public ImageDownloader() {
			this(Net.DOWNLOAD_USE_CACHE);
		}

		/**
		 * @since 3.8.4
		 */
		public ImageDownloader(final int downloadOptions) {
			super(1);
			this.downloadOptions = downloadOptions;
		}

		/**
		 * @since 3.8.12
		 */
		public ImageFactory getImageFactory() { return imageFactory; }

		/**
		 * @since 3.8.12
		 */
		public void setImageFactory(final ImageFactory value) { imageFactory = value; }

		// protected

		@Override
		protected Image getResult(final RequestInfo<Image> info) throws Exception {
			URL url = info.getProperty("url", null);

			Image result = null;
			if (imageFactory != null)
				result = imageFactory.getImage(this, url);

			if (result != null)
				return result;
			
			return ImageIO.read(download(url, downloadOptions));
		}
		
		// private
		
		private static URL download(final URL url, final int downloadOptions) {
			Net.DownloadInfo download = new Net.DownloadInfo(url, ".image", downloadOptions);
			try {
				download.startDownload();
				
				return FS.toURL(download.getFile());
			}
			catch (IOException exception) {
				MLogger.exception(exception);
				
				return url;
			}
		}
		
		private void startDownload(final RequestSource<Image> requestSource, final URL url) {
			Attributes<String, URL> a = new Attributes<>();
			a.set("url", url);
			
			startRequest(requestSource, a);
		}
		
	}

	/**
	 * @since 3.8.12
	 */
	@FunctionalInterface
	public static interface ImageFactory {

		// public

		public Image getImage(final HTMLViewFactory.ImageDownloader downloader, final URL url) throws Exception;

	}

	// private classes

	private static final class HiddenCommentView extends ComponentView {

		// protected

		@Override
		protected Component createComponent() {
			return HTMLViewFactory.newHiddenComponent();
		}

		// private

		private HiddenCommentView(final Element e) {
			super(e);
		}

	}

	private static final class HiddenFormView extends FormView {

		// protected

		@Override
		protected Component createComponent() {
			return HTMLViewFactory.newHiddenComponent();
		}

		// private

		private HiddenFormView(final Element e) {
			super(e);
		}

	}

	private static final class NoImageFactory implements ImageFactory {
	
		// private
		
		private final BufferedImage emptyImage;
	
		// public
		
		public NoImageFactory() {
			emptyImage = UI.createCompatibleImage(1, 1, true);
		}

		@Override
		public Image getImage(final HTMLViewFactory.ImageDownloader downloader, final URL url) throws Exception { return emptyImage; }

	}

	private static final class NoObjectView extends ObjectView {

		// protected

		@Override
		protected Component createComponent() {
			Element element = getElement();
			AttributeSet attr = element.getAttributes();

			// show link to the movie
			for (Object name : TK.iterable(attr.getAttributeNames())) {
				if ("movie".equals(name)) {
					Object movie = attr.getAttribute(name);
					if (movie != null) {
						try {
							URI uri = new URI(movie.toString());

							MLinkButton b = new MLinkButton(uri, "<object/> " + uri.getHost());
							b.setIcon(MIcon.small("player/start"));

							return b;
						}
						catch (URISyntaxException exception) { } // quiet
					}
				}
			}

			// show error message
			MLabel l = MLabel.createSmall("<object/>", MIcon.small("ui/error"));
			l.setToolTipText(i18n("Unsupported HTML Element: {0}", "<object>"));

			return l;
		}

		// private

		private NoObjectView(final Element e) {
			super(e);
		}

	}

}
