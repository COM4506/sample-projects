// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.html;

import java.awt.datatransfer.DataFlavor;
import java.io.Reader;
import java.io.StringReader;
import java.net.URI;
import java.util.Objects;

import org.makagiga.commons.AbstractSelection;

/**
 * @since 3.8, 4.0 (org.makagiga.commons.html package)
 */
public class HTMLSelection extends AbstractSelection<String> {

	// private

	private static final DataFlavor HTML_FLAVOR = createDataFlavor("text/html; charset=UTF-8", Reader.class.getName());
	private final String plainText;

	// public

	public HTMLSelection(final String htmlCode) {
		this(htmlCode, null);
	}

	/**
	 * @since 4.6
	 */
	public HTMLSelection(final String htmlCode, final String plainText) {
		super(Objects.requireNonNull(htmlCode), HTML_FLAVOR, DataFlavor.stringFlavor);
		this.plainText = plainText;
	}

	/**
	 * @since 4.10
	 */
	public static HTMLSelection fromURI(final String uri) {
		return new HTMLSelection(HTMLBuilder.createLink(uri, uri), uri);
	}

	/**
	 * @since 4.10
	 */
	public static HTMLSelection fromURI(final URI uri) {
		return fromURI(uri.toString());
	}

	@Override
	public Object getContents(final DataFlavor flavor) {
		if (DataFlavor.stringFlavor.equals(flavor))
			return (plainText != null) ? plainText : getData();

		return new StringReader(getData());
	}

}
