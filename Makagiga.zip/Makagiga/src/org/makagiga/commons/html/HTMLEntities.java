// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.html;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.Uninstantiable;

/**
 * @since 3.8.7, 4.0 (org.makagiga.commons.html package)
 */
public final class HTMLEntities {

	// private

	private static Map<String, String> _map;
	
	// public

	public synchronized static Map<String, String> getMap() {
		if (_map == null) {
			_map = new LinkedHashMap<>();
			try (DataInputStream input = new DataInputStream(new BufferedInputStream(HTMLEntities.class.getResourceAsStream("entities.data")))) {
				// header, ignore
				input.readUTF();

				while (true) {
					_map.put(input.readUTF(), input.readUTF());
				}
			}
			catch (EOFException exception) { } // quiet
			catch (IOException exception) {
				MLogger.exception(exception);
			}
			_map = Collections.unmodifiableMap(_map);
		}

		return _map;
	}
	
	/**
	 * @since 5.0
	 */
	public static String resolve(final String text) throws ParseException {
		if (text.indexOf('&') == -1)
			return text;

		boolean amp = false;
		boolean hex = false;
		boolean num = false;
		int len = text.length();
		Map<String, String> map = null;
		StringBuilder s = new StringBuilder(len);
		StringBuilder entityNameBuf = null;

		for (int i = 0; i < len; i++) {
			char c = text.charAt(i);
			switch (c) {
				case '#':
					if (amp) {
						num = true;
						if ((i < len - 1) && (text.charAt(i + 1) == 'x')) {
							hex = true;
							i++;
						}
					}
					else {
						s.append(c);
					}
					break;
				case '&':
					if (amp)
						throw new ParseException("Invalid entity", i);

					amp = true;
					if (entityNameBuf == null)
						entityNameBuf = new StringBuilder(10);
					else
						entityNameBuf.setLength(0);
					break;
				case ';':
					if (amp) {
						amp = false;
						String name = entityNameBuf.toString();
						if (num) {
							try {
								if (hex)
									s.append((char)Integer.parseInt(name, 16));
								else
									s.append((char)Integer.parseInt(name));
							}
							catch (NumberFormatException exception) {
								s.append("&#");
								if (hex)
									s.append('x');
								s.append(name).append(';');
							}
						}
						else {
							if (map == null)
								map = getMap();
							String entityValue = map.get(name);
							if (entityValue == null)
								s.append('&').append(name).append(';');
							else
								s.append(entityValue);
						}
						entityNameBuf.setLength(0);
					}
					else {
						s.append(c);
					}
					hex = false;
					num = false;
					break;
				default:
					if (amp)
						entityNameBuf.append(c);
					else
						s.append(c);
			}
		}
		
		if (amp) {
			s.append('&');
			if (!TK.isEmpty(entityNameBuf)) {
				if (num) {
					s.append('#');
					if (hex)
						s.append('x');
				}
				s.append(entityNameBuf);
			}
		}
		
		return s.toString();
	}

	// private

	@Uninstantiable
	private HTMLEntities() {
		TK.uninstantiable();
	}

}
