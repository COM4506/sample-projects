// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.html;

import static java.awt.event.KeyEvent.*;

import java.awt.event.KeyEvent;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.swing.KeyStroke;
import javax.swing.text.Document;
import javax.swing.text.ViewFactory;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

import org.makagiga.commons.AbstractMarkupBuilder;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.MText;
import org.makagiga.commons.swing.MTextPane;

/**
 * @since 4.0 (org.makagiga.commons.html package)
 */
public class MHTMLViewer extends MTextPane implements MDisposable {

	// private

	private HTMLViewFactory.ImageDownloader imageDownloader;
	
	// public
	
	public MHTMLViewer() {
		this((String)null);
	}

	/**
	 * @since 4.0
	 */
	public MHTMLViewer(final AbstractMarkupBuilder html) {
		this(html.toString());
	}
	
	public MHTMLViewer(final String html) {
		MText.uninstallUndoManager(this);
		setEditable(false);
		putClientProperty(HONOR_DISPLAY_PROPERTIES, true);
		if (TK.isEmpty(html))
			setContentType(TEXT_HTML_UTF_8);
		else
			setHTML(html);
		//addHyperlinkListener(new AHoverListener());
	}

	/**
	 * @since 3.8.12
	 */
	public synchronized HTMLViewFactory.ImageDownloader getImageDownloader() { return imageDownloader; }

	/**
	 * @since 3.8.4
	 */
	public synchronized void installCache(final int downloadOptions) {
		uninstallCache();

		imageDownloader = new HTMLViewFactory.ImageDownloader(downloadOptions);
		setEditorKit(new StaticHTMLEditorKit(this));
	}

	/**
	 * @since 3.8.1
	 */
	public synchronized void uninstallCache() {
		if (imageDownloader != null) {
			AccessController.doPrivileged(new PrivilegedAction<Void>() {
				@Override
				public Void run() {
					imageDownloader.cancelAll();
				
					return null;
				}
			} );
			imageDownloader = null;
		}
	}

	/**
	 * @since 4.0
	 */
	public synchronized void setHTML(final AbstractMarkupBuilder html) {
		setHTML(html.toString());
	}

	@InvokedFromConstructor
	public void setHTML(final String html) {
		setHTML(html, null);
	}

	/**
	 * @since 3.8.8
	 */
	public synchronized void setHTML(final String html, final URL baseURL) {
		setContentType(TEXT_HTML_UTF_8);

		Document doc = getDocument();
		HTMLDocument htmlDoc = (doc instanceof HTMLDocument) ? (HTMLDocument)doc : null;

		if (htmlDoc != null) {

			// HACK:
			htmlDoc.putProperty("IgnoreCharsetDirective", true);
			
			htmlDoc.setAsynchronousLoadPriority(-1);
			if (baseURL != null)
				htmlDoc.setBase(baseURL);
		}

		setText(html);

		setCaretPosition(0);
		// scroll to top (setCaretPosition sometimes does not work :/)
		MScrollPane.scrollToTop(this, true);
	}
	
	// MDisposable
	
	/**
	 * @since 4.0
	 */
	@Override
	public void dispose() {
		uninstallCache();
	}

	// protected
	
	/**
	 * @since 4.6
	 */
	protected String createCustomCSS() { return null; }

	/**
	 * Overriden to disable Ctrl+T/Ctrl+Shift+T keyboard shortcut
	 * (collision with "Tabs" and "History" menu).
	 */
	@Override
	protected boolean processKeyBinding(final KeyStroke ks, final KeyEvent e, final int condition, final boolean pressed) {
		if (
			(ks.getKeyCode() == VK_T) &&
			((ks.getModifiers() & CTRL_DOWN_MASK) == CTRL_DOWN_MASK)
		) {
			return false;
		}

		return super.processKeyBinding(ks, e, condition, pressed);
	}

	// private classes

/* TODO: a:hover link color
	private static final class AHoverListener implements HyperlinkListener {

		// public

		public AHoverListener() { }

		@Override
		public void hyperlinkUpdate(final HyperlinkEvent e) {
			boolean hover = (e.getEventType() == HyperlinkEvent.EventType.ENTERED);
			Element element = e.getSourceElement();
			JEditorPane editor = (JEditorPane)e.getSource();
			HTMLDocument doc = (HTMLDocument)editor.getDocument();

			MutableAttributeSet attr = new SimpleAttributeSet();
			attr.addAttributes(element.getAttributes().copyAttributes());
			if (hover) {
				Color hoverColor = MColor.getHoverLinkForeground(editor.getBackground());
				StyleConstants.setForeground(attr, hoverColor);
			}
			else {
				Style rule = doc.getStyleSheet().getRule("a");
				attr.addAttributes(rule);
			}

			int start = element.getStartOffset();
			doc.setCharacterAttributes(start, element.getEndOffset() - start, attr, false);
		}

	}
*/

	private static final class StaticHTMLEditorKit extends HTMLEditorKit {

		// private

		private final WeakReference<MHTMLViewer> viewerRef;

		// public

		@Override
		public Document createDefaultDocument() {
			MHTMLViewer viewer = TK.get(viewerRef);
			String css = viewer.createCustomCSS();
			StyleSheet styles = null;
			if (css != null) {
				styles = new StyleSheet();
				styles.addRule(css);
			}
		
			HTMLDocument doc = (HTMLDocument)super.createDefaultDocument();
			if (styles != null)
				doc.getStyleSheet().addStyleSheet(styles);
		
			return doc;
		}

		@Override
		public ViewFactory getViewFactory() {
			MHTMLViewer viewer = viewerRef.get();

			if (viewer == null)
				return super.getViewFactory();

			return new HTMLViewFactory(super.getViewFactory(), viewer.getImageDownloader());
		}

		// private

		private StaticHTMLEditorKit(final MHTMLViewer viewer) {
			viewerRef = new WeakReference<>(viewer);
		}

	}

}
