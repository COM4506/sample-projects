// Copyright 2009 Konrad Twardowski
//
// Based on the
// http://stackoverflow.com/questions/629721/linkify-text-with-regular-expressions-in-java
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.html;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.makagiga.commons.MLogger;
import org.makagiga.commons.Singleton;
import org.makagiga.commons.TK;

/**
 * @since 3.8, 4.0 (org.makagiga.commons.html package)
 */
public final class Linkify {

	// private

	private final Pattern pattern;
	private static final Singleton<Linkify> _instance = new Singleton<>(() -> new Linkify(
		Pattern.compile(
			"[a-z]+:(/){1,3}([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?",
			Pattern.CASE_INSENSITIVE | Pattern.DOTALL/* | Pattern.UNIX_LINES*/
		)
	));
	
	// public

	public String apply(final CharSequence input) {
		Matcher m = pattern.matcher(input);

		return m.replaceAll("<a href=\"$0\">$0</a>");
	}

	/**
	 * @since 4.0
	 */
	public StringBuilder applyToHTML(final CharSequence input) {
		StringBuilder s = new StringBuilder(input);
// FIXME: <<<GT>>>; see MRenderer
		TK.fastReplace(s, "&gt;", "<<<GT>>>");
		TK.fastReplace(s, "&lt;", "<<<LT>>>");

		s = new StringBuilder(apply(s));
		TK.fastReplace(s, "<<<GT>>>", "&gt;");
		TK.fastReplace(s, "<<<LT>>>", "&lt;");

		return s;
	}

	/**
	 * @since 3.8.10
	 */
	public Set<URI> findAll(final CharSequence input) {
		if (TK.isEmpty(input))
			return Collections.emptySet();

		Matcher m = pattern.matcher(input);
		Set<URI> result = null;
		while (m.find()) {
			if (result == null)
				result = new TreeSet<>();
			try {
				result.add(new URI(m.group()));
			}
			catch (URISyntaxException exception) {
				MLogger.exception(exception);
			}
		}

		return (result == null) ? Collections.<URI>emptySet() : result;
	}

	public static Linkify getInstance() {
		return _instance.get();
	}

	// private
	
	private Linkify(final Pattern pattern) {
		this.pattern = Objects.requireNonNull(pattern);
	}

}
