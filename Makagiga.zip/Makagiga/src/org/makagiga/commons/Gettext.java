// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.security.MPermission;

/**
 * A text catalog/translator.
 *
 * @mg.example
 * <pre class="brush: java">
 * import static org.makagiga.commons.UI.i18n;
 * ...
 * System.out.println(i18n("Translate me!"));
 * </pre>
 */
public final class Gettext {

	// private

	private static final Map<String, String> cache = new ConcurrentHashMap<>(256);
	private static final MArrayList<Object> catalogs = new MArrayList<>();
	private static Object[] catalogsArray = TK.EMPTY_OBJECT_ARRAY;
	private static String language;
	private static String language_COUNTRY;
	private static String metaInfo = "";
	
	// package
	
	static Locale locale;

	// static

	/**
	 * Initializes and loads the catalog with translated strings.
	 * Messages for "en_US" language are not loaded.
	 */
	static {
		init();
	}

	static void init() { // package
		// reset fields
		cache.clear();
		catalogs.clear();
		catalogsArray = TK.EMPTY_OBJECT_ARRAY;

		locale = Locale.getDefault(Locale.Category.DISPLAY);
		language = locale.getLanguage();
		String country = locale.getCountry();
		if ("iw".equals(language))
			language = "he";
		if (TK.isEmpty(country))
			language_COUNTRY = null;
		else
			language_COUNTRY = language + "_" + country;

		// do not translate english to english
		try {
			if (!"en_US".equals(language_COUNTRY)) {
				if (!loadProperties(language_COUNTRY))
					loadProperties(language);
			}
			else {
				MLogger.info("core", "Using default UI language");
			}
		}
		catch (IllegalStateException exception) { } // quiet
	}

	// public
	
	/**
	 * @deprecated Since 4.10
	 */
	@Deprecated
	public static boolean addCatalogFromClassPath(final String dirString) {
		checkPermission("addCatalogFromClassPath");
		List<File> dirs = Arrays.asList(new File(dirString));
		
		return loadClass(language_COUNTRY, dirs) || loadClass(language, dirs);
	}

	public static boolean addCatalogFromProperties(final String dir) {
		checkPermission("addCatalogFromProperties");

		try {
			File i18nFile = new File(dir, "i18n.jar");

			if (!i18nFile.exists())
				return false;

			ZipFile zip = new ZipFile(i18nFile); // much faster than JarFile
			MProperties messages;

			InputStream input = null;
			if (language_COUNTRY != null)
				input = getInput(zip, "i18n/" + language_COUNTRY + ".properties");
			if (input == null)
				input = getInput(zip, "i18n/" + language + ".properties");

			if (input != null) {
				messages = new MProperties();
				try (InputStream in = input) {
					messages.loadUTF8(in);
				}
			}
			else {
				return false; // no messages
			}

			synchronized (Gettext.class) {
				catalogs.add(messages);
				catalogsArray = catalogs.toArray();
			}

			return true;
		}
		catch (Exception exception) {
			MLogger.exception(exception);

			return false;
		}
	}

	/**
	 * Returns a meta info for @p name.
	 *
	 * @return {@code null} if meta info is not available
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * Gettext.getMetaInfo("Last-Translator")
	 * Gettext.getMetaInfo("X-Generator")
	 * </pre>
	 *
	 * @since 3.4
	 */
	public static String getMetaInfo(final String name) {
		if (metaInfo.isEmpty())
			return null;

		String entryPrefix = name + ":";
		for (String entry : TK.fastSplit(metaInfo, '\n')) {
			if (entry.startsWith(entryPrefix))
				return entry.substring(entryPrefix.length()).trim();
		}

		return null;
	}

	/**
	 * @since 5.2
	 */
	public static URL getResource(final String lang) {
		return Gettext.class.getResource("i18n/" + lang + ".properties");
	}

	/**
	 * Translates the specified text.
	 * Do not call this function directly. Use "_" instead.
	 * @param id A text to translate
	 * @return A translated string
	 */
	public static String translate(final String id) {
		if (catalogs.isEmpty())
			return id;

		if (id == null) {
			MLogger.error("core", "Text to translate is null. Fix your code.");
			try {
				if (MLogger.isDeveloper())
					MLogger.trace();
			}
			catch (SecurityException exception) { } // quiet

			return id;
		}
		
		String message = cache.get(id);
		
		if (message != null)
			return message;

		for (Object messages : catalogsArray) {
			if (messages instanceof ResourceBundle) {
				try {
					ResourceBundle bundle = (ResourceBundle)messages;
					if (bundle.containsKey(id)) {
						message = bundle.getString(id);
						cache.put(id, message);
						
						return message;
					}
					
					// try next catalog
				}
				catch (Exception exception) { } // quiet; try next catalog
			}
			else if (messages instanceof MProperties) {
				try {
					message = MProperties.class.cast(messages).getProperty(id);
					if (message != null) {
						cache.put(id, message);

						return message;
					}
					
					// try next catalog
				}
				catch (Exception exception) { } // quiet; try next catalog
			}
		}
		
		return id; // return untranslated message
	}
	
	// private
	
	@Uninstantiable
	private Gettext() {
		TK.uninstantiable();
	}

	private static void checkPermission(final String name) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new Gettext.Permission(name));
	}

	private static InputStream getInput(final ZipFile zip, final String name) {
		ZipEntry entry = zip.getEntry(name);
		try {
			return (entry == null) ? null : zip.getInputStream(entry);
		}
		catch (IOException exception) {
			MLogger.exception(exception);

			return null;
		}
	}

	/**
	 * @deprecated Since 4.10
	 */
	@Deprecated
	private static boolean loadClass(final String lang, final List<File> dirs) {
		if (lang == null)
			return false;
	
		try {
			synchronized (Gettext.class) {
				URL[] jarPath = new URL[dirs.size()];
				for (int i = 0; i < jarPath.length; i++)
					jarPath[i] = FS.toURL(new File(dirs.get(i), "i18n.jar"));
				
				Class<?> c = URLClassLoader.newInstance(
					jarPath,
					Gettext.class.getClassLoader()
				).loadClass("Messages_" + lang);
				catalogs.add((ResourceBundle)c.newInstance());
				catalogsArray = catalogs.toArray();
			}
			
			MLogger.info("core", "Using UI language: %s", lang);
			
			return true;
		}
		catch (ClassNotFoundException exception) { // quiet
			return false;
		}
		catch (ReflectiveOperationException exception) {
			MLogger.exception(exception);
		
			return false;
		}
	}
	
	private static boolean loadProperties(final String lang) {
		try {
			InputStream resourceStream = Gettext.class.getResourceAsStream("i18n/" + lang + ".properties");
			
			if (resourceStream == null)
				return false;

			try (InputStream inputStream = new BufferedInputStream(resourceStream)) {
				MProperties messages = new MProperties();
				messages.loadUTF8(inputStream);
				metaInfo = messages.getProperty("__metainfo__", "");
				synchronized (Gettext.class) {
					catalogs.add(messages);
					catalogsArray = catalogs.toArray();
				}
			}

			return true;
		}
		catch (IOException exception) { // quiet
			return false;
		}
	}

	// public classes
	
	/**
	 * @since 3.0
	 */
	public static final class Permission extends MPermission {
		
		// private
		
		private Permission(final String name) {
			super(name, ThreatLevel.LOW, "Language Translation");
		}
		
	}

}
