// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Path;
import java.util.Objects;

import org.makagiga.commons.annotation.DesignPattern;
import org.makagiga.commons.annotation.Important;

/** An abstract markup builder. */
@DesignPattern(DesignPattern.BUILDER)
public abstract class AbstractMarkupBuilder
implements
	Appendable,
	CharSequence
{

	// private

	private final boolean xml;
	private int indent;
	private String eol = "\n";
	private String indentString = "\t";
	private final String tagEnd;
	
	@SuppressWarnings("PMD.AvoidStringBufferField")
	private final StringBuilder buf;

	// public

	/**
	 * Constructs a new markup builder.
	 * The string builder buffer size is set to @c 4KB.
	 */
	public AbstractMarkupBuilder(final boolean xml) {
		buf = new StringBuilder(4096);
		this.xml = xml;
		tagEnd = xml ? " />" : ">";
	}

	/**
	 * Adds an unescaped comment text.
	 *
	 * @param text the comment text
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * builder.appendComment("This is a comment");
	 * // Emits: "&lt;!-- This is a comment --&gt;\n"
	 * </pre>
	 */
	public AbstractMarkupBuilder appendComment(final String text) {
		if (text != null) {
			doIndent();
			buf
				.append("<!-- ")
				.append(text)
				.append(" -->")
				.append(eol);
		}
		
		return this;
	}

	/**
	 * @since 4.0
	 */
	public AbstractMarkupBuilder appendEscaped(final CharSequence cs) {
		TK.escapeXML(buf, cs);

		return this;
	}

	/**
	 * Appends an empty line to the buffer.
	 *
	 * @since 3.8.6
	 */
	public AbstractMarkupBuilder appendLine() {
		buf.append(eol);
		
		return this;
	}

	/**
	 * Appends @p code + <b>new line</b> to the buffer.
	 */
	public AbstractMarkupBuilder appendLine(final String code) {
		if (code != null) {
			doIndent();
			buf.append(code).append(eol);
		}
		
		return this;
	}

	/**
	 * Appends code + <b>new line</b> to the buffer.
	 * @param format A code to append
	 * @param args A @p format arguments
	 */
	public AbstractMarkupBuilder appendLine(final String format, final Object... args) {
		appendLine(String.format(format, args));
		
		return this;
	}

	/**
	 * Begins a tag.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * builder.beginTag("b");
	 * // Emits: "&lt;b&gt;\n"
	 * </pre>
	 */
	public AbstractMarkupBuilder beginTag(final String name) {
		if (name != null) {
			doIndent();
			buf
				.append('<')
				.append(name)
				.append('>')
				.append(eol);
		}
		indent++;
		
		return this;
	}

	public AbstractMarkupBuilder beginTag(final String name, final Object... attrs) {
		doIndent();
		buf.append('<').append(name);
		addAttributes(attrs);
		buf.append('>').append(eol);
		indent++;
		
		return this;
	}

	public AbstractMarkupBuilder decIndent() {
		if (indent > 0)
			indent--;
		
		return this;
	}

	public AbstractMarkupBuilder doubleTag(final String name, final String innerCode, final Object... attrs) {
		doIndent();
		buf.append('<').append(name);
		addAttributes(attrs);
		buf.append('>');
		if (!TK.isEmpty(innerCode))
			buf.append(innerCode);
		buf.append("</").append(name).append('>').append(eol);
		
		return this;
	}

	/**
	 * Ends a tag.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * builder.endTag("b");
	 * // Emits: "&lt;/b&gt;\n"
	 * </pre>
	 */
	public AbstractMarkupBuilder endTag(final String name) {
		decIndent();
		if (name != null) {
			doIndent();
			buf
				.append("</")
				.append(name)
				.append('>')
				.append(eol);
		}
		
		return this;
	}
	
	public String escape(final String value) {
		return TK.escapeXML(value);
	}
	
	/**
	 * @since 3.0
	 */
	public String getEOL() { return eol; }

	/**
	 * @since 3.0
	 */
	public AbstractMarkupBuilder setEOL(final String value) {
		Objects.requireNonNull(value);
		
		eol = value;
		
		return this;
	}

	/**
	 * Returns the current indent level.
	 * 
	 * @since 3.0
	 */
	public int getIndentLevel() { return indent; }

	/**
	 * Sets the current indent level to @p indentLevel.
	 * 
	 * @throws IllegalArgumentException If @p indentLevel is less than zero
	 * 
	 * @since 3.0
	 */
	public AbstractMarkupBuilder setIndentLevel(final int indentLevel) {
		if (indentLevel < 0)
			throw new IllegalArgumentException("\"indentLevel\" cannot be less than zero: " + indentLevel);
		
		indent = indentLevel;
		
		return this;
	}
	
	/**
	 * @since 3.0
	 */
	public String getIndentString() { return indentString; }

	/**
	 * @since 3.0
	 */
	public AbstractMarkupBuilder setIndentString(final String value) {
		Objects.requireNonNull(value);
		
		indentString = value;
		
		return this;
	}

	/**
	 * @since 3.2
	 */
	public AbstractMarkupBuilder incIndent() {
		indent++;
		
		return this;
	}
	
	/**
	 * @since 4.6
	 */
	public boolean isEmpty() {
		return length() == 0;
	}

	/**
	 * @since 4.0
	 */
	public boolean isXML() { return xml; }

	/**
	 * Saves this buffer to the specified file.
	 * The text is saved in the UTF-8 encoding.
	 *
	 * @param file the destination file
	 *
	 * @throws IOException If file write failed
	 *
	 * @since 4.0
	 */
	public AbstractMarkupBuilder write(final File file) throws IOException {
		FS.write(file, toString());
		
		return this;
	}

	/**
	 * @throws IOException If stream write error
	 *
	 * @since 4.0
	 */
	public AbstractMarkupBuilder write(final OutputStream stream, final boolean autoCloseStreams) throws IOException {
		PrintStream printStream = null;
		try {
			printStream = new PrintStream(stream, false, "UTF8");
			printStream.print(buf.toString());
			if (!autoCloseStreams)
				printStream.flush();
		}
		finally {
			if (autoCloseStreams) {
				FS.close(printStream);
				FS.close(stream);
			}
		}
		
		return this;
	}

	/**
	 * Saves this buffer to the specified file.
	 * The text is saved in the UTF-8 encoding.
	 *
	 * @param file the destination file
	 *
	 * @throws IOException If file write failed
	 *
	 * @since 4.0
	 */
	public AbstractMarkupBuilder write(final Path file) throws IOException {
		write(file.toFile());
		
		return this;
	}

	public AbstractMarkupBuilder singleTag(final String name, final Object... attrs) {
		doIndent();
		buf.append('<').append(name);
		addAttributes(attrs);
		buf.append(tagEnd).append(eol);
		
		return this;
	}

	// Appendable

	/**
	 * @since 3.8.10
	 */
	@Override
	public AbstractMarkupBuilder append(final CharSequence cs) {
		buf.append(cs);

		return this;
	}

	/**
	 * @since 3.8.10
	 */
	@Override
	public AbstractMarkupBuilder append(final CharSequence cs, final int start, final int end) {
		buf.append(cs, start, end);

		return this;
	}

	/**
	 * @since 3.8.10
	 */
	@Override
	public AbstractMarkupBuilder append(final char c) {
		buf.append(c);

		return this;
	}

	// CharSequence

	/**
	 * @since 3.2
	 */
	@Override
	public char charAt(final int index) {
		return buf.charAt(index);
	}

	/**
	 * @since 2.4
	 */
	@Override
	public int length() {
		return buf.length();
	}

	/**
	 * @since 3.2
	 */
	@Override
	public CharSequence subSequence(final int start, final int end) {
		return buf.subSequence(start, end);
	}

	/**
	 * Returns the markup code.
	 */
	@Important
	@Override
	public String toString() {
		return buf.toString();
	}
	
	// protected
	
	/**
	 * @since 2.0
	 */
	protected AbstractMarkupBuilder addAttributes(final Object... attrs) {
		if (attrs != null) {
			boolean attrName = true;
			for (Object a : attrs) {
				if (attrName) {
					buf.append(' ').append(a).append("=\"");
					attrName = false;
				}
				else {
					buf.append(escape(String.valueOf(a))).append('"');
					attrName = true;
				}
			}
		}
		
		return this;
	}

	/**
	 * @since 3.0
	 */
	protected AbstractMarkupBuilder doIndent() {
		if (indent == 0)
			return this;

		if (indentString.length() == 1) {
			TK.append(buf, indentString.charAt(0), indent);
		}
		else {
			for (int i = 0; i < indent; i++)
				buf.append(indentString);
		}
		
		return this;
	}

	/**
	 * @since 4.0
	 */
	protected String getTagEnd() { return tagEnd; }

}
