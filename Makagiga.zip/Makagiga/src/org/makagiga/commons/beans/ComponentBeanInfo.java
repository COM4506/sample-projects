// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.beans;

import java.awt.Component;

import org.makagiga.commons.MIcon;
import org.makagiga.commons.UI;
import org.makagiga.commons.sb.SecureOpen;
import org.makagiga.commons.swing.MText;

/**
 * @since 4.0
 */
public abstract class ComponentBeanInfo extends AbstractBeanInfo {
	
	// protected

	protected ComponentBeanInfo(final Class<? extends Component> beanClass, final String displayName, final String iconName) {
		super(beanClass, displayName, iconName);

		if (MIcon.Name.class.isAssignableFrom(beanClass))
			addPropertyDescriptor("iconName", PREFERRED, "The icon name (example: ui/ok)");

		if (MText.TextFieldExtensions.class.isAssignableFrom(beanClass)) {
			addPropertyDescriptor("autoCompletion", PREFERRED, "The text Auto Completion ID");
			addPropertyDescriptor("text", PREFERRED, "The text");
		}

		if (SecureOpen.class.isAssignableFrom(beanClass))
			addPropertyDescriptor("secureOpen", PREFERRED, "Whether or not secure link open function is enabled");
		
		if (UI.EventsControl.class.isAssignableFrom(beanClass))
			addPropertyDescriptor("eventsEnabled", HIDDEN, "Whether or not \"onChange\" event handler method is enabled");

		if (UI.MouseWheelEventsControl.class.isAssignableFrom(beanClass))
			addPropertyDescriptor("mouseWheelEventsEnabled", PREFERRED, "Whether or not additional mouse wheel support is enabled");
	}

}
