// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.beans;

import java.awt.Image;
import java.beans.BeanDescriptor;
import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;
import java.lang.reflect.Method;
import java.util.Objects;

import org.makagiga.commons.Flags;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.swing.ValueChooser;

/**
 * An abstract bean info.
 * 
 * @mg.example
 * <pre class="brush: java">
 * public final class MThrobberBeanInfo extends AbstractBeanInfo {
 *   public MThrobberBeanInfo() {
 *     super(MThrobber.class, "Throbber", "ui/ok");
 *     addPropertyDescriptor("active", PREFERRED, "Whether or not the animation is visible");
 *     addPropertyDescriptor("animationIcon", PREFERRED, "Animation icon (animated GIF)");
 *   }
 * }
 * </pre>
 * 
 * @mg.warning This class is <b>not</b> thread-safe.
 * 
 * @since 2.0
 *
 * @see ComponentBeanInfo
 */
public abstract class AbstractBeanInfo extends SimpleBeanInfo {

	// protected
	
	/**
	 * Whether or not the property is preferred.
	 */
	protected static final int PREFERRED = 1;
	
	/**
	 * Whether or not the property is a bound property.
	 */
	protected static final int BOUND = 1 << 1;

	/**
	 * Whether or not the property is for expert users only.
	 */
	protected static final int EXPERT = 1 << 2;

	/**
	 * Whether or not the property is hidden (not visible in IDE).
	 */
	protected static final int HIDDEN = 1 << 3;
	
	// private
	
	private final BeanDescriptor beanDescriptor;
	private final Class<?> beanClass;
	private MArrayList<PropertyDescriptor> propertyList;
	private String iconName;
	
	// public
	
	/**
	 * Constructs an abstract bean info.
	 * 
	 * - The constructor automatically scans for @ref ContainerDelegate annotation
	 * - A first found public method annotated with @ref ContainerDelegate will be set as "containerDelegate" property,
	 * and the "isContainer" will be set to @c true
	 * - All other annotated methods are ignored
	 * 
	 * @throws NullPointerException If @p beanClass or @p displayName is @c null
	 * 
	 * @see #getBeanDescriptor()
	 * @see ContainerDelegate
	 *
	 * @since 4.0
	 */
	public AbstractBeanInfo(final Class<?> beanClass, final String displayName, final String iconName) {
		this.beanClass = Objects.requireNonNull(beanClass);
		
		beanDescriptor = new BeanDescriptor(beanClass);
		beanDescriptor.setDisplayName(Objects.requireNonNull(displayName));
		
		for (Method i : beanClass.getMethods()) {
			if (i.isAnnotationPresent(ContainerDelegate.class)) {
				setContainer(true, i.getName());
				
				break; // for
			}
		}

		if (iconName != null)
			setIconName(iconName);
	}
	
	/**
	 * Returns bean info of the superclass.
	 */
	@Override
	public BeanInfo[] getAdditionalBeanInfo() {
		try {
			return new BeanInfo[] {
				Introspector.getBeanInfo(beanClass.getSuperclass())
			};
		}
		catch (IntrospectionException exception) {
			throw new WTFError(exception);
		}
	}
	
	/**
	 * Returns the bean descriptor.
	 * The bean class name and its display name is taken from the constructor parameters.
	 */
	@Override
	public BeanDescriptor getBeanDescriptor() { return beanDescriptor; }
	
	/**
	 * Returns the image for the specified @p iconKind.
	 * By default returns @c null if "icon name" is not set,
	 * or if @p iconKind is invalid.
	 * 
	 * Valid @p iconKind values are:
	 * - ICON_COLOR_16x16
	 * - ICON_MONO_16x16
	 * - ICON_COLOR_32x32
	 * - ICON_MONO_32x32
	 *
	 * @mg.note The current implementation
	 * always returns <i>COLOR</i> icon even for <i>MONO</i> kind.
	 * 
	 * @see #setIconName(String)
	 */
	@Override
	public Image getIcon(final int iconKind) {
		if (iconName == null)
			return null;
		
		switch (iconKind) {
			case ICON_COLOR_16x16:
			case ICON_MONO_16x16:
				return MIcon.stock(iconName, 16).getImage();
			case ICON_COLOR_32x32:
			case ICON_MONO_32x32:
				return MIcon.stock(iconName, 32).getImage();
			default:
				return null;
		}
	}

	@Override
	public synchronized final PropertyDescriptor[] getPropertyDescriptors() {
		return (propertyList == null) ? super.getPropertyDescriptors() : propertyList.toArray(PropertyDescriptor.class);
	}

	// protected

	/**
	 * @since 4.0
	 */
	protected synchronized void addPropertyDescriptor(final PropertyDescriptor pd) {
		if (propertyList == null)
			propertyList = new MArrayList<>();
		propertyList.add(pd);
	}

	/**
	 * @since 4.0
	 */
	protected PropertyDescriptor addPropertyDescriptor(final String propertyName, final int flags, final String shortDescription) {
		PropertyDescriptor pd = createPropertyDescriptor(propertyName, flags, shortDescription);
		addPropertyDescriptor(pd);

		return pd;
	}

	/**
	 * Returns the new property descriptor.
	 * 
	 * @param propertyName The property name
	 * @param flags The flags (example: @ref PREFERRED)
	 * @param shortDescription The short property description (less than about 40 characters)
	 * 
	 * @throws IllegalArgumentException If @p propertyName is @c null or empty
	 * @throws IllegalArgumentException If getter or setter for @p propertyName was not found
	 */
	protected PropertyDescriptor createPropertyDescriptor(final String propertyName, final int flags, final String shortDescription) {
		TK.checkNullOrEmpty(propertyName, "propertyName");

		try {
			Flags f = Flags.valueOf(flags);
			PropertyDescriptor pd = new PropertyDescriptor(propertyName, beanClass);
			pd.setBound(f.isSet(BOUND));
			pd.setExpert(f.isSet(EXPERT));
			pd.setHidden(f.isSet(HIDDEN));
			pd.setPreferred(f.isSet(PREFERRED));
			pd.setShortDescription(shortDescription);
			
			return pd;
		}
		catch (IntrospectionException exception) {
			throw new IllegalArgumentException(exception);
		}
	}

	/**
	 * @since 3.8.12
	 */
	protected PropertyDescriptor createValuePropertyDescriptor(final boolean bound) {
		int flags = PREFERRED;
		if (bound)
			flags |= BOUND;

		return createPropertyDescriptor(
			ValueChooser.VALUE_PROPERTY,
			flags,
			"The selected value"
		);
	}
	
	/**
	 * Sets the container specific properties.
	 * 
	 * @param isContainer Whether or not "isContainer" property is set
	 * @param containerDelegate The name of the container delegate method (can be @c null)
	 * 
	 * @see ContainerDelegate
	 */
	@InvokedFromConstructor
	protected void setContainer(final boolean isContainer, final String containerDelegate) {
		if (containerDelegate != null)
			beanDescriptor.setValue("containerDelegate", containerDelegate);
		beanDescriptor.setValue("isContainer", isContainer);
	}
	
	/**
	 * Sets "enum" editor properties.
	 * 
	 * @param pd The property descriptor
	 * @param values An array for @c Enum values
	 * 
	 * @see <a href="http://www.jformdesigner.com/doc/help/java_beans.html">More Info</a>
	 * 
	 * @throws NullPointerException If @p pd or @p values is @c null
	 */
	protected void setEnum(final PropertyDescriptor pd, final Enum<?>[] values) {
		EnumItem[] items = new EnumItem[values.length];
		for (int i = 0; i < values.length; i++) {
			Enum<?> e = values[i];
			items[i] = new EnumItem(
				e.toString(),
				e,
				e.getClass().getName().replace('$', '.') + "." + e.name()
			);
		}
		setEnum(pd, items);
	}
	
	/**
	 * Sets "enum" editor properties.
	 * 
	 * @param pd The property descriptor
	 * @param items An array of @ref EnumItem
	 * 
	 * @see EnumItem
	 * @see <a href="http://www.jformdesigner.com/doc/help/java_beans.html">More Info</a>
	 * 
	 * @throws NullPointerException If @p pd or @p items is @c null
	 */
	protected void setEnum(final PropertyDescriptor pd, final EnumItem... items) {
		MArrayList<Object> list = new MArrayList<>(items.length * 3);
		for (EnumItem i : items) {
			list.add(i.getDisplayName());
			list.add(i.getValue());
			list.add(i.getCode());
		}
		pd.setValue("enumerationValues", list.toArray());
	}
	
	/**
	 * Sets icon name to @p value (can be @c null).
	 * 
	 * @see #getIcon(int)
	 */
	protected void setIconName(final String value) { iconName = value; }
	
	// public classes
	
	/**
	 * An @c Enum editor item.
	 */
	public static final class EnumItem {
		
		// private
		
		private final Object value;
		private final String code;
		private final String displayName;
		
		// public
		
		/**
		 * Constructor an @c Enum editor item.
		 * 
		 * @param displayName The name visible in IDE
		 * @param value The enum value (any Java object)
		 * @param code The Java code inserted by IDE
		 * 
		 * @throws IllegalArgumentException If @p displayName or @p code is @c null or empty
		 * @throws NullPointerException If @p value is @c null
		 */
		public EnumItem(final String displayName, final Object value, final String code) {
			this.displayName = TK.checkNullOrEmpty(displayName, "displayName");
			this.value = Objects.requireNonNull(value);
			this.code = TK.checkNullOrEmpty(code, "code");
		}
		
		/**
		 * Returns the Java code.
		 */
		public String getCode() { return code; }

		/**
		 * Returns the display name.
		 */
		public String getDisplayName() { return displayName; }

		/**
		 * Returns the enum value.
		 */
		public Object getValue() { return value; }
		
	}

}
