// Copyright 2015 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static org.makagiga.commons.UI.i18n;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.format.TextStyle;
import java.time.temporal.WeekFields;
import java.util.Locale;
import java.util.Objects;

import org.makagiga.commons.annotation.Uninstantiable;

/**
 * A {@code java.time.*} utilities.
 *
 * @since 5.4
 */
public final class DT {

	// public

	public static final int FANCY_FORMAT_ABSOLUTE = 1;
	public static final int FANCY_FORMAT_APPEND_TIME = 1 << 1;
	public static final int FANCY_FORMAT_APPEND_YEAR = 1 << 2;
	
	public static final LocalDate UNDEFINED_LOCAL_DATE = LocalDate.MIN;
	public static final LocalDateTime UNDEFINED_LOCAL_DATE_TIME = LocalDateTime.MIN;

	// private
	
	private static final DateTimeFormatter FANCY_FORMATTER_NO_YEAR =
		DateTimeFormatter.ofPattern("EEEE, MMM d");
	private static final DateTimeFormatter FANCY_FORMATTER_TIME =
		DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);
	private static final DateTimeFormatter FANCY_FORMATTER_WITH_YEAR =
		DateTimeFormatter.ofPattern("EEEE, MMM d, yyyy");

	// public
	
	public static String fancyFormat(final LocalDate date, final int options) {
		if (isUndefined(date))
			return "";

		return fancyFormatLocalDate(date, Flags.valueOf(options));
	}

	public static String fancyFormat(final LocalDateTime dateTime, final int options) {
		if (isUndefined(dateTime))
			return "";

		Flags flags = Flags.valueOf(options);
		String dateText = fancyFormatLocalDate(dateTime.toLocalDate(), flags);
		String timeText = fancyFormatLocalTime(dateTime.toLocalTime(), flags);
		
		if (timeText.isEmpty())
			return dateText;
		
		return dateText + "  " + timeText;
	}

	public static DayOfWeek getFirstDayOfWeek() {
		return getWeekFields().getFirstDayOfWeek();
	}

	public static String getFullDisplayName(final DayOfWeek day) {
		return getDisplayName(day, true);
	}

	public static String getFullDisplayName(final Month month) {
		return getDisplayName(month, true);
	}

	public static WeekFields getWeekFields() {
		MCalendar.FirstDayOfWeek fdow = MApplication.firstDayOfWeek.get();
		switch (fdow) {
			case DEFAULT: return WeekFields.of(resolve(null));
			case MONDAY: return WeekFields.ISO;
			case SUNDAY: return WeekFields.SUNDAY_START;
			default: throw new WTFError(fdow);
		}
	}

	public static boolean isUndefined(final LocalDate date) {
		return date.isEqual(UNDEFINED_LOCAL_DATE);
	}

	public static boolean isUndefined(final LocalDateTime dateTime) {
		return dateTime.isEqual(UNDEFINED_LOCAL_DATE_TIME);
	}

	/**
	 * @since 5.6
	 */
	public static boolean isValid(final LocalDateTime dateTime) {
		return !dateTime.isEqual(UNDEFINED_LOCAL_DATE_TIME);
	}

	/**
	 * @since 5.6
	 */
	public static MDate toDate(final LocalDateTime dateTime) {
		return new MDate(dateTime
			.atZone(ZoneId.systemDefault())
			.toInstant()
			.toEpochMilli()
		);
	}

	/**
	 * @since 5.6
	 */
	public static MDate toDate(final ZonedDateTime dateTime) {
		return new MDate(dateTime
			.toInstant()
			.toEpochMilli()
		);
	}

	/**
	 * @since 5.6
	 */
	public static LocalDateTime toLocalDateTime(final java.util.Date date) {
		return LocalDateTime.ofInstant(
			date.toInstant(),
			ZoneId.systemDefault()
		);
	}

	/**
	 * @since 5.6
	 */
	public static LocalDate toLocalDate(final java.util.Date date) {
		return toLocalDateTime(date)
			.toLocalDate();
	}

	/**
	 * @since 5.6
	 */
	public static ZonedDateTime toZonedDateTime(final java.util.Date date) {
		return ZonedDateTime.ofInstant(
			date.toInstant(),
			ZoneId.systemDefault()
		);
	}

	// private
	
	@Uninstantiable
	private DT() {
		TK.uninstantiable();
	}

	private static String fancyFormatLocalDate(final LocalDate date, final Flags flags) {
		LocalDate now = LocalDate.now();
		
		if (flags.isClear(FANCY_FORMAT_ABSOLUTE)) {
			if (date.isEqual(now))
				return i18n("Today");

			if (date.isEqual(now.plusDays(1)))
				return i18n("Tomorrow");
			
			if (date.isEqual(now.minusDays(1)))
				return i18n("Yesterday");
		}

		DateTimeFormatter formatter = 
			(flags.isSet(FANCY_FORMAT_APPEND_YEAR) || (date.getYear() != now.getYear()))
			? FANCY_FORMATTER_WITH_YEAR
			: FANCY_FORMATTER_NO_YEAR;

		return formatter.format(date);
	}

	private static String fancyFormatLocalTime(final LocalTime time, final Flags flags) {
		if (flags.isSet(FANCY_FORMAT_APPEND_TIME))
			return time.format(FANCY_FORMATTER_TIME);

		return "";
	}

	private static String getDisplayName(final DayOfWeek day, final boolean full) {
		Objects.requireNonNull(day);

		Locale locale = resolve(null);
		String result = day.getDisplayName(full ? TextStyle.FULL_STANDALONE : TextStyle.SHORT_STANDALONE, locale);
		if (result.equals(Integer.toString(day.getValue())))
			result = day.getDisplayName(full ? TextStyle.FULL : TextStyle.SHORT, locale);

		return result;
	}

	private static String getDisplayName(final Month month, final boolean full) {
		Objects.requireNonNull(month);

		Locale locale = resolve(null);
		String result = month.getDisplayName(full ? TextStyle.FULL_STANDALONE : TextStyle.SHORT_STANDALONE, locale);
		if (result.equals(Integer.toString(month.getValue())))
			result = month.getDisplayName(full ? TextStyle.FULL : TextStyle.SHORT, locale);

		return result;
	}

	private static Locale resolve(final Locale locale) {
		return (locale == null) ? Locale.getDefault(Locale.Category.FORMAT) : locale;
	}

}
