// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static org.makagiga.commons.UI.i18n;

import java.awt.Desktop;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Policy;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.io.MProcess;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.MMessage;

/**
 * A set of OS dependent functions.
 *
 * @mg.example
 * <pre class="brush: java">
 * public static final void main(String[] args) {
 *   if (OS.isLinux())
 *     System.out.println("This OS is good");
 * ...
 * </pre>
 */
public final class OS {

	// public
	
	/**
	 * @since 2.0
	 */
	public static final StringProperty openCommand = new StringProperty("", StringProperty.PLATFORM | StringProperty.SECURE_WRITE);

	// private

	private static boolean cinnamon;
	private static boolean enlightenment;
	private static boolean gnome;
	private static boolean haiku;
	private static boolean kde;
	private static boolean linux;
	private static boolean lxde;
	private static boolean lxqt;
	private static boolean mac;
	private static boolean mate;
	private static boolean openJDK;
	private static boolean solaris;
	private static boolean unity;
	private static boolean unix;
	private static boolean webStart;
	private static boolean windows;
	private static boolean xfce;
	private static float _javaVersion;
	private static int _javaUpdate;
	private static int pid;
	private static MArrayList<Tuple.Three<String, String, Boolean>> _openCommands;
	private static String desktopEnvironment = "";
	private static String internalName;
	private static String javaArch;
	private static String javaArchRawProperty;
	private static String name;
	private static String runtimeName;
	private static String userFullName;
	private static String userName;
	private static String version;
	private static VersionProperty javaVersionProperty;

	// public

	static {
		init();
	}

	/**
	 * @since 2.0
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static boolean email(final String address) {
		return tryDefaultEmail("mailto:" + address);
	}
	
// FIXME: 3.0: problem with encoding/non-ascii chars
	/**
	 * @mg.warning
	 * Attachments are not supported.
	 *
	 * @since 2.0
	 *
	 * @see #email(String)
	 *
	 * @deprecated Since 4.4
	 */
	@Deprecated
	public static boolean email(final String address, final String subject, final File attachment) {
		if (attachment != null)
			MLogger.warning("core", "File attachments are unsupported");
	
		String s = address;
		if (subject != null)
			s += "?subject=" + TK.escapeURL(subject, TK.ESCAPE_SPACE);
		
		return tryDefaultEmail("mailto:" + s);
	}

	/**
	 * @since 3.8
	 *
	 * @deprecated As of 5.2, replaced by #getJavaArch()
	 */
	@Deprecated
	public static String getArch() { return javaArch; }

	/**
	 * Returns the OS internal name.
	 *
	 * Supported values are:
	 * - Linux - <code>"linux"</code>
	 * - Mac OS X - <code>"mac"</code>
	 * - Windows - <code>"windows"</code>
	 * - Others - <code>"unknown"</code>
	 */
	public static String getInternalName() { return internalName; }

	/**
	 * Returns the Java architecture.
	 *
	 * Supported return values:
	 * - "x86"
	 * - "x86_64"
	 * - "unknown"
	 *
	 * @since 5.2
	 */
	public static String getJavaArch() { return javaArch; }

	/**
	 * @since 2.0
	 *
	 * @deprecated As of 5.0, replaced by {@link #getJavaVersionProperty()}
	 */
	@Deprecated
	public static int getJavaUpdate() { return _javaUpdate; }

	/**
	 * @since 2.0
	 *
	 * @deprecated As of 5.0, replaced by {@link #getJavaVersionProperty()}
	 */
	@Deprecated
	public static float getJavaVersion() { return _javaVersion; }
	
	/**
	 * Returns the Java version numbers.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * if (OS.getJavaVersionProperty().getMajor() &gt;= 8) {
	 *    useJDK8Feature();
	 * }
	 *
	 * // Example numbers for Java (1.)8 Update 5 are:
	 * OS.getJavaVersionProperty().getMajor() == 8
	 * OS.getJavaVersionProperty().getMinor() == 0
	 * OS.getJavaVersionProperty().getBugfix() == 5 // 0 if update number is unavailable
	 * </pre>
	 *
	 * @since 4.6
	 */
	public static VersionProperty getJavaVersionProperty() { return javaVersionProperty; }
	
	/**
	 * @deprecated Since 5.6
	 */
	@Deprecated
	public static Locale getLocale() {
		return Locale.getDefault();
	}

	/**
	 * Returns the OS name. (e.g. "Linux")
	 */
	public static String getName() { return name; }

	/**
	 * Returns the PID (Process ID) of this application.
	 *
	 * @return Zero if method failed
	 *
	 * @see <a href="http://golesny.de/wiki/code:javahowtogetpid">Java How to get the PID from a process?</a>
	 * @see <a href="http://bugs.sun.com/view_bug.do?bug_id=4244896">Bug #4244896</a>
	 *
	 * @since 3.4
	 */
	@Obsolete
	public synchronized static int getPID() {
		if (runtimeName == null) {
			RuntimeMXBean rt = ManagementFactory.getRuntimeMXBean();
			runtimeName = rt.getName();
			Tuple.Two<String, String> s = Tuple.split(runtimeName, '@', TK.SPLIT_PAIR_NULL_ERROR);
			if (s != null) {
				try {
					pid = Integer.parseInt(s.get1());
				}
				catch (NumberFormatException exception) {
					MLogger.exception(exception);
				}
			}
		}

		return pid;
	}

	/**
	 * @since 4.0
	 */
	public static String getSummary(final boolean includeDistroInfo) {
		Map<String, String> envMap = new TreeMap<>();

		Map<String, String> properties = MAccessController.doPrivileged(() -> {
			String[] envKeys;
			if (isLinux()) {
				envKeys = new String[] {
					"_JAVA_OPTIONS", "JAVA_TOOL_OPTIONS",
					"DESKTOP_SESSION", "DISPLAY", "LANG",
					"XDG_CURRENT_DESKTOP"
				};
			}
			else if (isWindows()) {
				envKeys = new String[] {
					"_JAVACMD", "_JAVA_OPTIONS", "JAVA_TOOL_OPTIONS",
					"PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER",
					"PROCESSOR_LEVEL", "PROCESSOR_REVISION"
				};
			}
			else
				envKeys = TK.EMPTY_STRING_ARRAY;

			for (String i : envKeys)
				envMap.put(i, System.getenv(i));

			HashMap<String, String> map = new HashMap<>();
			for (String i : new String[] {
				"java.class.path", "java.home", "java.library.path", "java.runtime.version", "java.vendor",
				"java.vm.info", "java.vm.name", "sun.arch.data.model"
			} )
				map.put(i, System.getProperty(i));

			RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
			map.put("input-args", String.join(", ", runtime.getInputArguments()));
			map.put("is-private-jre", isPrivateJRE() ? "yes" : "no");
			map.put("policy", formatClassName(Policy.getPolicy()));

			return map;
		} );

		MStringBuilder result = new MStringBuilder();
		
		// application
		result.append(MApplication.getTitleAndCodename());
		
		String buildInfo = MApplication.getBuildInfo();
		if (!TK.isEmpty(buildInfo))
			result.append(" (build: ").append(buildInfo).append(')');

		result.n();

		// OS/Desktop Environment

		String systemBit = properties.get("sun.arch.data.model");
		systemBit = Objects.toString(systemBit, "?");
		
		result
			.append("Operating System: ")
			.append(getName())
			.append(' ')
			.append(getVersion())
			.append(" (").append(systemBit).append("-bit)")
			.n();

		result.append("Desktop Environment: ");
		if (desktopEnvironment.isEmpty())
			result.append(getName());
		else
			result.append(desktopEnvironment);

		if (isWebStart())
			result.append(", Web Start");

		result
			.n()
			.n();
		
		result
			// jvm
			.formatLine(
				"Java" + UI.TM + " %s (%s, build: %s, vendor: %s, OpenJDK: %s)",
				getJavaVersionProperty(),
				javaArchRawProperty,
				properties.get("java.runtime.version"),
				properties.get("java.vendor"),
				openJDK ? "yes" : "no"
			)
			.formatLine("Java Home: %s (private: %s)", properties.get("java.home"), properties.get("is-private-jre"))
			.formatLine("JVM Name: %s (%s)", properties.get("java.vm.name"), properties.get("java.vm.info"))
			.formatLine("JVM Arguments: %s", properties.get("input-args"))
			.formatLine("Class Path: %s", properties.get("java.class.path"))
			.formatLine("Library Path: %s", properties.get("java.library.path"))
			.n();

			// locale
			Locale defaultLocale = Locale.getDefault();
			result.formatLine(
				"Default Locale: %s, %s (%s)",
				defaultLocale.getDisplayLanguage(),
				defaultLocale.getDisplayCountry(),
				defaultLocale
			);

			Locale displayLocale = Locale.getDefault(Locale.Category.DISPLAY);
			result.formatLine(
				"  Display: %s, %s (%s)",
				displayLocale.getDisplayLanguage(),
				displayLocale.getDisplayCountry(),
				displayLocale
			);

			Locale formatLocale = Locale.getDefault();
			result.formatLine(
				"  Format: %s, %s (%s)",
				formatLocale.getDisplayLanguage(),
				formatLocale.getDisplayCountry(),
				formatLocale
			);

			result.formatLine(
				"Security Manager: %s (policy=%s)",
				formatClassName(System.getSecurityManager()),
				properties.get("policy")
			)
			.formatLine("Available Processors/Cores: %s", Runtime.getRuntime().availableProcessors());

		MApplication.getPID()
			.ifPresent(pid -> result.formatLine("Program PID: %d", pid));

		long uptime = MApplication.getUptime();
		if (uptime > 0) {
			int options = MDate.FORMAT_PERIOD_APPEND_SECONDS | MDate.FORMAT_PERIOD_APPEND_TIME | MDate.FORMAT_PERIOD_SHORT_TIME_SUFFIX;
			result.formatLine("Program Uptime: %s", MDate.formatPeriod(uptime, options));
		}

		// ui

		result.n();
		
		TK.forEach(Screen.getAll(), (screen, i) -> {
			result.formatLine("Screen Device #%d: %s", (i + 1), screen);

			Rectangle r = screen.getBounds();
			result.formatLine("  Bounds: x: %d | y: %d | size: %s", r.x, r.y, MFormat.dimension(r.getSize()));

			Insets insets = screen.getInsets();
			result.formatLine("  Insets: top: %d | bottom: %d | left: %d | right: %d", insets.top, insets.bottom, insets.left, insets.right);
		} );

		Point center = Screen.getCenter();
		result.formatLine("Screen Center: x: %d | y: %d", center.x, center.y);

		Toolkit toolkit = Toolkit.getDefaultToolkit();
		result.formatLine("Screen Resolution: %d dpi", toolkit.getScreenResolution());
		result.formatLine("UI Toolkit: %s", toolkit.getClass().getName());

		LookAndFeel laf = UIManager.getLookAndFeel();
		if (laf != null) {
			result.format("UI Look and Feel: %s (%s", laf.getName(), laf.getClass().getName());
			if (UI.isSynth())
				result.append(", Synth-based");
			if (UI.isWindowsClassic())
				result.append(", Classic");
			result.appendLine(")");
		}
		
		// dirs
		result.n();
		result.appendLine(i18n("{0}: Settings and Data", MApplication.getFullName()));
		result.appendLine(FS.getConfigDir());
		if (FS.getProfile() != null) {
			result.appendLine(i18n("Profile: {0}", FS.getProfile()));
		}
		if (!isWebStart()) {
			result.n().appendLine(i18n("Install Directory:"));
			result.appendLine(FS.getBaseDir());
		}

		if (!envMap.isEmpty()) {
			result
				.n()
				.appendLine("Environment Variables:");
			envMap.forEach((key, value) -> result.formatLine("%s = %s", key, Objects.toString(value, "<none>")));
		}

		if (includeDistroInfo && isLinux()) {
			// DOC: http://www.freedesktop.org/software/systemd/man/os-release.html
			Path osReleaseFile = Paths.get("/etc/os-release");

			result
				.n()
				.appendLine("Linux Distribution Info (" + osReleaseFile + "):");

			MAccessController.doPrivileged(() -> {
				try {
					for (String line : Files.readAllLines(osReleaseFile)) {
						line = line.trim();
						
						if (line.isEmpty() || (line.charAt(0) == '#'))
							continue; // for

						Tuple.Two<String, String> pair = Tuple.split(line, '=');
						switch (pair.get1()) {
							case "ID":
							case "ID_LIKE":
							case "NAME":
							case "PRETTY_NAME":
							case "VERSION":
							case "VERSION_ID": {
								String value = pair.get2();
								value = TK.removePrefix(value, '"');
								value = TK.removeSuffix(value, '"');
								result.appendLine(pair.get1() + " = " + value);
							} break;
						}
					}
				}
				catch (IOException exception) {
					MLogger.developerException(exception);
				}
				
				return null;
			} );
		}
		
		return result.toString();
	}

	/**
	 * Returns the current user <b>login</b> name. (e.g. "konrad")
	 *
	 * @see #getUserFullName()
	 */
	public static String getUserName() { return userName; }

	/**
	 * Returns the current user <b>full</b> name.
	 * If full name value is not supported the <b>login</b> name is returned.
	 *
	 * @see #getUserName()
	 */
	@Obsolete
	@SuppressFBWarnings("CLI_CONSTANT_LIST_INDEX")
	public synchronized static String getUserFullName() {
		if (userFullName == null) {
			if (isLinux()) {
				try {
					// DOC: http://en.wikipedia.org/wiki/Gecos_field
					FS.lines(Paths.get("/etc/passwd"), stream ->
						stream
						.map(line -> line.split("\\:"))
						.filter(fields -> (fields.length == 7) && getUserName().equals(fields[0]))
						.map(fields -> fields[4].split("\\,"))
						.filter(userInfo -> userInfo.length > 0)
						.findFirst()
						.ifPresent(userInfo -> userFullName = userInfo[0])
					);
				}
				catch (IOException exception) {
					MLogger.exception(exception);
				}
			}
			
			if (userFullName == null)
				userFullName = "";
		}
		
		return userFullName.isEmpty() ? getUserName() : userFullName;
	}

	/**
	 * Returns the OS version. (e.g. "5.1" on Windows XP)
	 */
	public static String getVersion() { return version; }

	/**
	 * Initializes this class.
	 *
	 * @mg.note Since 3.8.2, this method is invoked automatically.
	 */
	public static void init() {
		initJavaVersion();
		initArch();

		name = System.getProperty("os.name");
		userName = System.getProperty("user.name");
		version = System.getProperty("os.version");
		// detect os
		String osName = TK.toUpperCase(name);
		if (osName.startsWith("LINUX"))
			linux = true;
		else if (osName.startsWith("MAC"))
			mac = true;
		else if (osName.startsWith("SUNOS"))
			solaris = true;
		else if (osName.startsWith("WINDOWS"))
			windows = true;
		else if (osName.startsWith("HAIKU"))
			haiku = true;

		if (linux) {
			internalName = "linux";
			
			// detect desktop session

			// check for KDE
			// FIX #2988499 - always check "desktopSession" for null
			String desktopSession = Objects.toString(System.getenv("DESKTOP_SESSION"), "");
// TODO: check both "XDG_CURRENT_DESKTOP" and "DESKTOP_SESSION"
// TODO: Trinity
			kde = TK.containsIgnoreCase(desktopSession, "KDE");
			if (!kde) {
				String kdeFullSession = Objects.toString(System.getenv("KDE_FULL_SESSION"), "");
				kde = kdeFullSession.equalsIgnoreCase("true");
			}
			if (kde) {
				desktopEnvironment = "KDE";
			}

			else {
				gnome = TK.containsIgnoreCase(desktopSession, "GNOME");
				if (gnome) {
					desktopEnvironment = "GNOME";
				}
				else {
					unity = TK.containsIgnoreCase(desktopSession, "UBUNTU");
					if (unity) {
						desktopEnvironment = "Unity";
						gnome = true;
					}
				}

				if (!gnome) {
					xfce = TK.containsIgnoreCase(desktopSession, "XFCE");
					if (xfce) {
						desktopEnvironment = "Xfce";
					}
					else {
						lxde = TK.containsIgnoreCase(desktopSession, "LXDE");
						if (lxde) {
							desktopEnvironment = "LXDE";
						}
						else {
							mate = TK.containsIgnoreCase(desktopSession, "MATE");
							if (mate) {
								desktopEnvironment = "MATE";
							}
							else {
								cinnamon = TK.containsIgnoreCase(desktopSession, "cinnamon");
								if (cinnamon) {
									desktopEnvironment = "Cinnamon";
								}
								else {
									lxqt = TK.containsIgnoreCase(desktopSession, "LXQT");
									if (lxqt) {
										desktopEnvironment = "LXQt";
									}
									else {
										enlightenment = TK.containsIgnoreCase(desktopSession, "enlightenment");
										if (enlightenment) {
											desktopEnvironment = "Enlightenment";
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else if (mac) {
			internalName = "mac";
		}
		else if (solaris) {
			internalName = "solaris";
		}
		else if (windows) {
			internalName = "windows";
		}
		else {
			internalName = "unknown";
		}
		unix = !windows;
		webStart = System.getProperty("javawebstart.version") != null;
		
		initLocale();
	}

	/**
	 * Returns <code>true</code> if <i>Cinnamon</i> is the current session.
	 */
	public static boolean isCinnamon() { return cinnamon; }

	/**
	 * @since 5.0
	 */
	@Obsolete // convert to enum
	public static boolean isEnlightenment() { return enlightenment; }

	/**
	 * Returns @c true if @b GNOME is a current session.
	 */
	public static boolean isGNOME() { return gnome; }
	
	/**
	 * Returns {@code true} if application is running under Haiku OS.
	 *
	 * @since 4.4
	 */
	public static boolean isHaiku() { return haiku; }
	
	/**
	 * @since 3.4
	 *
	 * @deprecated Since 5.2
	 */
	@Deprecated
	public static boolean isHeadless() {
		return GraphicsEnvironment.isHeadless();
	}

	/**
	 * Returns @c true if @b KDE is a current session.
	 */
	public static boolean isKDE() { return kde; }

	/**
	 * Returns @c true if application is running under Linux.
	 */
	public static boolean isLinux() { return linux; }
	
	/**
	 * @since 4.2
	 *
	 * @deprecated Since 5.0
	 */
	@Deprecated
	public static boolean isLXDE() { return lxde; }

	/**
	 * @since 5.0
	 */
	public static boolean isLXQt() { return lxqt; }

	/**
	 * Returns @c true if application is running under Mac OS X.
	 */
	public static boolean isMac() { return mac; }

	/**
	 * Returns {@code true} if <b>MATE</b> is the current session.
	 *
	 * @since 4.8
	 */
	public static boolean isMATE() { return mate; }

	/**
	 * Returns {@code true} if application is running under OpenJDK.
	 *
	 * @since 3.8
	 */
	public static boolean isOpenJDK() { return openJDK; }

	/**
	 * @since 5.0
	 */
	public static boolean isPrivateJRE() {
		Path baseDir = FS.getBasePath();
		Path javaHome = Paths.get(System.getProperty("java.home"));
		
		return javaHome.startsWith(baseDir);
	}

	/**
	 * Returns @c true if application is running under (Open)Solaris.
	 *
	 * @since 3.0
	 */
	public static boolean isSolaris() { return solaris; }
	
	public static boolean isSupported() {
		return linux || mac || solaris || windows;
	}

	/**
	 * @since 4.2
	 */
	public static boolean isUnity() { return unity; }

	public static boolean isUnix() { return unix; }
	
	/**
	 * Returns @c true if application was launched via Web Start.
	 */
	public static boolean isWebStart() { return webStart; }

	/**
	 * Returns @c true if application is running under Windows.
	 */
	public static boolean isWindows() { return windows; }

	/**
	 * Returns {@code true} if <i>Xfce</i> is the current desktop session.
	 *
	 * @return {@code true} if <i>Xfce</i>
	 *
	 * @since 3.8.3
	 */
	public static boolean isXfce() { return xfce; }

	/**
	 * Launches the web browser/email client/other application with the specified URI.
	 * Displays an error message if launch failed.
	 *
	 * @mg.example
	 * <pre class="brush: java">
	 * OS.open(URI.create("http://www.example.com"));
	 * </pre>
	 *
	 * @param uri An URI to open
	 * 
	 * @return {@code true} if successful; otherwise {@code false}
	 * 
	 * @throws NullPointerException If @p uri is @c null
	 *
	 * @see MApplication#openURI(java.net.URI)
	 * 
	 * @since 3.0
	 */
	public static boolean open(final URI uri) {
		Objects.requireNonNull(uri);

		// try custom command
		if (!isDesktopAPIReliable()) {
			String uriString = uri.toString();

			if (!openCommand.isEmpty()) {
				if (tryLaunch(openCommand.get(), uriString))
					return true;
			}
			
			MArrayList<Tuple.Three<String, String, Boolean>> commandList =
				MAccessController.doPrivileged(() -> getOpenCommands());
			for (Tuple.Three<String, String, Boolean> i : commandList) {
				String command = i.get2();
				boolean available = i.get3();
				if (!command.isEmpty() && available) {
					if (tryLaunch(command, uriString))
						return true;
				}
			}
		}
		else {
			if ("mailto".equals(uri.getScheme()))
				return tryDefaultEmail(uri.toString());
		}

		// try default browser
		if (tryDefaultLaunch(Desktop.Action.BROWSE, uri))
			return true;

		UI.invokeLater(() -> {
			String text = i18n("Could not open: {0}", uri);
			if (!isDesktopAPIReliable() && !GeneralSettings.inTest) {
				text += "\n\n" + i18n("Click \"Settings\" to set your default file browser/launcher.");
				if (new MMessage.Builder()
					.icon("ui/error")
					.ok(MActionInfo.SETTINGS)
					.text(text)
					.exec()
				) {
					GeneralSettings settings = new GeneralSettings();
					settings.openCommandOnly = true;
					settings.exec(UI.windowFor(null));
				}
			}
			else {
				MMessage.error(UI.windowFor(null), text);
			}
		} );

		return false;
	}

	// private
	
	@Uninstantiable
	private OS() {
		TK.uninstantiable();
	}
	
	private static String extractCountry(final String country) {
		int i = country.indexOf('.');
		
		return
			(i == -1)
			? country
			: country.substring(0, i);
	}

	private static String formatClassName(final Object o) {
		return (o == null) ? "<none>" : o.getClass().getName();
	}

	private static void initArch() {
		javaArchRawProperty = System.getProperty("os.arch");
		String arch = javaArchRawProperty;
		if (arch == null) {
			arch = "unknown";
		}
		else {
			switch (arch) {
				case "i386":
				case "x86":
					arch = "x86";
					break;
				case "amd64":
				case "x86_64":
					arch = "x86_64";
					break;
				default:
					arch = "unknown";
					break;
			}
		}
		javaArch = arch;
	}

	private static void initJavaVersion() {
		String runtimeName = System.getProperty("java.runtime.name");
		openJDK = (runtimeName != null) && runtimeName.contains("OpenJDK");

		final String jv = System.getProperty("java.version");
		final int qualifierIndex = jv.indexOf('-');

		// NOTE: increase later
		int javaMajor = 8;
		_javaVersion = 1.8f;

// TODO: replace with a org.makagiga.commons.Version.parse (semantic version impl.)
//       or use API provided by JDK.
		try {
			// 1.8.0_13 -> 1.8
			int i = jv.lastIndexOf('.');
			if (i != -1) {
				String oneMajor = jv.substring(0, i);
				_javaVersion = Float.parseFloat(oneMajor);

				// 1.8 -> 8
				i = oneMajor.indexOf('.');
				if (i != -1) {
					int oneOrMajor = -1;
					try {
						oneOrMajor = Integer.parseInt(oneMajor.substring(0, i));
					}
					catch (Exception exception) {
						MLogger.developerException(exception);
					}

					if (oneOrMajor > 1)
						javaMajor = oneOrMajor;
					else
						javaMajor = Integer.parseInt(oneMajor.substring(i + 1));
				}
			}
			else {
				if (qualifierIndex != -1)
					javaMajor = Integer.parseInt(jv.substring(0, qualifierIndex));
				else
					javaMajor = Integer.parseInt(jv);
				_javaVersion = javaMajor;
			}
		}
		catch (Exception exception) {
			//MLogger.exception(exception);
			MLogger.warning("core", "Cannot parse Java Version info: %s", jv);
		}

		_javaUpdate = 0;
		try {
			// "underscore" version - x.y.z_uu -> uu
			int updateIndex = jv.indexOf('_');
			if (updateIndex != -1) {
				String update;
				if (qualifierIndex != -1)
					update = jv.substring(updateIndex + 1, qualifierIndex);
				else
					update = jv.substring(updateIndex + 1, jv.length());
				_javaUpdate = Integer.parseInt(update);
			}
		}
		catch (Exception exception) {
			MLogger.warning("core", "Cannot parse Java Update info: %s", jv);
		}

		// 1.8.0_13 -> 8.0.13
		javaVersionProperty = new VersionProperty(
			VersionProperty.make(javaMajor, 0, _javaUpdate),
			VersionProperty.READ_ONLY
		);
	}

	@SuppressFBWarnings("MDM_SETDEFAULTLOCALE")
	private static void initLocale() {
		Locale newLocale = null;

		if (linux) {
			String LANG = System.getenv("MAKAGIGA_LANG");
			if (!TK.isEmpty(LANG)) {
				int i = LANG.indexOf('_');
				if (i == -1) {
					String language = LANG;
					newLocale = new Locale(language);
				}
				else {
					String language = LANG.substring(0, i);
					String country_variant = LANG.substring(i + 1);
					i = country_variant.indexOf('_');
					if (i == -1) {
						String country = extractCountry(country_variant);
						newLocale = new Locale(language, country);
					}
					else {
						String country = extractCountry(country_variant.substring(0, i));
						String variant = country_variant.substring(i + 1);
						newLocale = new Locale(language, country, variant);
					}
				}
			}
		}

		if (newLocale != null)
			setLocale(newLocale, "MAKAGIGA_LANG environment variable");
	}

	private static boolean isInstalled(final MArrayList<Path> dirList, final String program) {
		for (Path dir : dirList) {
			Path programPath = dir.resolve(program);

			if (Files.exists(programPath) && Files.isExecutable(programPath))
				return true;
		}

		return false;
	}

	private static boolean tryDefaultEmail(final String uri) {
		if (tryDefaultLaunch(Desktop.Action.MAIL, URI.create(uri)))
			return true;
	
		MMessage.error(UI.windowFor(null), i18n("Could not send mail: {0}", uri));
		
		return false;
	}
	
	private static boolean tryDefaultLaunch(final Desktop.Action action, final URI uri) {
		try {
			if (!Desktop.isDesktopSupported())
				return false;
		}
		// bad implementation...
		catch (Exception exception) {
			MLogger.exception(exception);
			
			return false;
		}
		
		Desktop desktop = Desktop.getDesktop();
		if (desktop.isSupported(action)) {
			if (MLogger.isDeveloper())
				MLogger.debug("core", "Using default launcher...");
			try {
				switch (action) {
					case BROWSE:
						desktop.browse(uri);
						break;
					case MAIL:
						desktop.mail(uri);
						break;
				}
					
				return true;
			}
			catch (IOException exception) { } // quiet
		}
		
		return false;
	}

	private static boolean tryLaunch(final String command, final String url) {
		try {
			if (MLogger.isDeveloper())
				MLogger.debug("core", "Using custom launcher: %s", command);

			new MProcess(withURL(command, url).toArray());

			return true;
		}
		catch (IOException exception) {
			MLogger.exception(exception);
			
			return false;
		}
	}
		
	private static StringList withURL(final String command, String url) {
		StringList l = new StringList();
		
		url = url.replace(" ", "%20");

// FIXME: space characters in parameters
		if (command.contains("%u")) {
			l.addAll(TK.fastSplit(command.replace("%u", url), ' '));
		}
		else {
			l.addAll(TK.fastSplit(command, ' '));
			l.add(url);
		}

		return l;
	}
	
	// package

	synchronized static MArrayList<Tuple.Three<String, String, Boolean>> getOpenCommands() {
		if (_openCommands == null) {
			String pathEnv = Objects.toString(System.getenv("PATH"), "");
			MArrayList<Path> dirList = new MArrayList<>();
			for (String i : TK.fastSplit(pathEnv, ':')) {
				Path dir = Paths.get(i);
				if (Files.isDirectory(dir))
					dirList.add(dir);
			}

			_openCommands = new MArrayList<Tuple.Three<String, String, Boolean>>(
// TODO: LXQt?
				Tuple.of(i18n("Auto Detect"), "", true),
				Tuple.of("", "", false),
				Tuple.of("Cinnamon", "gvfs-open", isInstalled(dirList, "gvfs-open")),
				Tuple.of("Enlightenment", "enlightenment_open", isEnlightenment() && isInstalled(dirList, "enlightenment_open")),
				Tuple.of("GNOME", "gnome-open", isGNOME() && isInstalled(dirList, "gnome-open")),
				Tuple.of("KDE 5.x", "kde-open5", isKDE() && isInstalled(dirList, "kde-open5")),
				Tuple.of("KDE 4.x", "kde-open", isKDE() && isInstalled(dirList, "kde-open")),
				Tuple.of("MATE", "gvfs-open", isInstalled(dirList, "gvfs-open")),
				Tuple.of("Xfce", "exo-open", isXfce() && isInstalled(dirList, "exo-open")),
				Tuple.of(i18n("Auto Detect"), "xdg-open", isInstalled(dirList, "xdg-open")),
				Tuple.of("", "", false),
				Tuple.of("Firefox", "firefox", isInstalled(dirList, "firefox")),
				Tuple.of("Konqueror", "konqueror", isInstalled(dirList, "konqueror")),
				Tuple.of("Chromium", "chromium-browser", isInstalled(dirList, "chromium-browser")),
				Tuple.of("Opera", "opera", isInstalled(dirList, "opera"))
			);
		}

		return _openCommands;
	}

	static boolean isDesktopAPIReliable() {
		return isMac() || isWindows();
		// NOTE: Linux implementation depends on GNOME libs and it may not work on other DE
	}

// TODO: GUI and CLI options
	@SuppressFBWarnings("MDM_SETDEFAULTLOCALE")
	static void setLocale(final Locale newLocale, final String source) {
		if (!Locale.getDefault().equals(newLocale)) {
			Locale.setDefault(newLocale);
			MLogger.info("core", "Setting locale: %s/%s (%s | %s)", newLocale.getDisplayLanguage(), newLocale.getDisplayCountry(), newLocale, source);
			
			// reset locale sensitive data:

			Config.init();

			if (!newLocale.equals(Gettext.locale))
				Gettext.init();
		}
	}

}
