// Copyright 2011 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import static org.makagiga.commons.UI.i18n;

import java.awt.Image;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Path;
import javax.imageio.ImageIO;
import javax.swing.TransferHandler;

import org.makagiga.commons.io.FileSelection;
import org.makagiga.commons.swing.MStatusBar;

/**
 * @since 4.0
 */
public abstract class ImageTransferHandler extends TransferHandler {

	// private
	
	private final boolean readImageFile;
	
	// public
	
	public ImageTransferHandler(final boolean readImageFile) {
		this.readImageFile = readImageFile;
	}

	@Override
	public boolean canImport(final TransferHandler.TransferSupport support) {
		if (!support.isDrop())
			return false;

		DataFlavor[] flavors = support.getDataFlavors();
		//MDataTransfer.debug(flavors);
		for (DataFlavor i : flavors) {
			if (
				i.equals(DataFlavor.imageFlavor) ||
				i.equals(DataFlavor.javaFileListFlavor) ||
				i.equals(FileSelection.URI_LIST)
			)
				return true;
		}

		return false;
	}

	@Override
	public boolean importData(final TransferHandler.TransferSupport support) {
		Transferable t = support.getTransferable();

		if (support.isDataFlavorSupported(DataFlavor.imageFlavor)) {
			return doImport(t, DataFlavor.imageFlavor);
		}

		FileSelection.URIList list = FileSelection.getURIList(t);
		if (list != null) {
			URI uri = list.get(0);
			switch (uri.getScheme()) {
				case "file": {
					File file = new File(uri);
					String suffix = "." + FS.getFileExtension(file);

					if (MDataTransfer.isImageSupported(suffix))
						return doImport(t, file);
					
				} break;
				case "http":
				case "https": {
					Path imagePath = null;
					try {
						imagePath = MDataTransfer.getImage(uri);
						doImport(t, imagePath);
					}
					catch (IOException exception) {
						MStatusBar.error(exception);
					}
					finally {
						if (imagePath != null)
							FS.deleteSilently(imagePath);
					}
				} break;
				default:
					MStatusBar.error(i18n("Error: {0}", uri));
			}
		}

		return false;
	}

	// protected

	protected boolean onImport(final File file) { return false; }
	
	protected abstract boolean onImport(final Image image);

	// private

	private boolean doImport(final Transferable t, final Object source) {
		try {
			if (source instanceof File) {
				if (readImageFile)
					return onImport(ImageIO.read((File)source));
				
				return onImport((File)source);
			}

			if (source instanceof InputStream) {
				try (InputStream input = (InputStream)source) {
					return onImport(ImageIO.read(input));
				}
			}

			if (source == DataFlavor.imageFlavor) {
				Image image = MDataTransfer.getImage(t, DataFlavor.imageFlavor);

				return onImport(image);
			}
		}
		catch (IOException | UnsupportedFlavorException exception) {
			MLogger.exception(exception);
		}

		return false;
	}

}
