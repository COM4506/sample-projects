// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.color;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.util.Objects;
import java.util.function.Consumer;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MMenu;

/**
 * @since 5.0
 */
public class MColorMenu extends MMenu {

	// public
	
	public enum Option { LAZY_INIT, RESET_ACTION_VISIBLE, SIMPLE }

	// private

	private Color defaultValue;
	private Color value;
	private final ColorPalette colorPalette;
	private final Consumer<Color> onSelect;
	private final Option[] options;

	// public
	
	public MColorMenu(final Consumer<Color> onSelect, final Option... options) {
		this(ColorPalette.getApplicationPalette(), onSelect, options);
	}

	public MColorMenu(final ColorPalette colorPalette, final Consumer<Color> onSelect, final Option... options) {
		this.colorPalette = Objects.requireNonNull(colorPalette);
		this.onSelect = Objects.requireNonNull(onSelect);
		this.options = TK.copyOf(options);
		
		if (isOption(Option.SIMPLE)) {
			setIcon(colorPalette);
			setText(colorPalette.toString());
		}
		else {
			setIcon(MActionInfo.SET_COLOR.getSmallIcon());
			setText(MActionInfo.SET_COLOR.getDialogTitle());
		}
		
		setPopupMenuVerticalAlignment(CENTER);

		if (isOption(Option.LAZY_INIT)) {
			onSelect(self -> {
				if (isEmpty())
					init();
			} );
		}
		else {
			init();
		}
	}

	public Color getDefaultValue() { return defaultValue; }

	public void setDefaultValue(final Color value) { defaultValue = value; }
	
	public Color getValue() { return value; }
	
	public void setValue(final Color value) { this.value = value; }

	// protected
	
	private void fireEvent(final Color color) {
		setValue(color);
		onSelect.accept(color);
	}

	private void init() {
		MColorPicker colorPicker = new MColorPicker(colorPalette, true);
		colorPicker.setBackground(UI.getBackground(this));
		colorPicker.setColorButtonVisible(false);
		colorPicker.setOpaque(true);
		colorPicker.addValueListener(e -> {
			fireEvent(e.getNewValue());
			ColorHistory.add(e.getNewValue());
			MMenu.hideCurrentPopup();
		} );
		add(colorPicker);
		
		if (isOption(Option.SIMPLE))
			return;

		add(new MAction(i18n("More..."), action -> {
			Color newColor = MColorButton.selectColor(
				UI.windowFor(null),
				colorPalette,
				getValue(),
				getDefaultValue()
			);
			if (newColor != null)
				fireEvent(newColor);
		} ));

		addSeparator();

		for (ColorPalette i : ColorPalette.getAll()) {
			// skip large palettes
			if (i.getCount() > 150)
				continue; // for

			// already in menu
			if (i == colorPalette)
				continue; // for

			String s = i.toString();

			if (
				"Android".equals(s) || "Gold".equals(s) || "Grays".equals(s) ||
				"Lights".equals(s) || "Paintjet".equals(s)
			)
				continue; // for

			add(new MColorMenu(i, onSelect, Option.LAZY_INIT, Option.SIMPLE));
		}
		
		add(ColorHistory.createMenu(this::fireEvent));
		
		if (isOption(Option.RESET_ACTION_VISIBLE)) {
			addSeparator();

			add(new MAction(MActionInfo.RESTORE_DEFAULT_VALUES,
				action -> fireEvent(getDefaultValue())
			));
		}
	}
	
	private boolean isOption(final Option option) {
		return TK.indexOf(options, option) != -1;
	}

}
