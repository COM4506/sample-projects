// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.color;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Window;

import org.makagiga.commons.TK;
import org.makagiga.commons.UI;

/**
 * A color button.
 *
 * @mg.example
 * <pre class="brush: java">
 * MColorButton colorButton = new MColorButton();
 * colorButton.setValue(Color.BLUE);
 * colorButton.addValueListener(new ValueListener&lt;Color&gt;() {
 *   {@literal @}Override
 *   public void valueChanged(final ValueEvent&lt;Color&gt; e) {
 *     doSomethingWithColor(e.getNewValue());
 *   }
 * } );
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.color package)
 */
public class MColorButton extends MSmallColorButton {

	// private
	
	private Color defaultValue;
	
	// public

	/**
	 * Constructs a color button with black ({@code java.awt.Color.BLACK}) color.
	 *
	 * @see #setValue(Color)
	 */
	public MColorButton() { }
	
	/**
	 * Returns the default color or @c null.
	 * 
	 * @since 4.0
	 */
	public Color getDefaultValue() { return defaultValue; }

	/**
	 * Sets the default color to @p value (can be @c null).
	 * The default color will be used in the color chooser.
	 * 
	 * @since 4.0
	 */
	public void setDefaultValue(final Color value) { defaultValue = value; }

	// protected
	
	/**
	 * Overriden to call @ref onChange.
	 */
	@Override
	protected final void onClick() {
		MColorPicker parentPicker = UI.getAncestorOfClass(MColorPicker.class, this);
		ColorPalette parentPalette = (parentPicker == null) ? null : parentPicker.getSelectedColorPalette();

		Color oldColor = getValue();
		Color newColor = selectColor(getWindowAncestor(), parentPalette, oldColor, defaultValue);
		if ((newColor != null) && !newColor.equals(oldColor)) {
			setValue(newColor);
			fireValueChanged(oldColor, getValue());
		}
	}

	// package

	MColorButton(final Dimension iconSize) {
		super(Color.BLACK, iconSize, UI.isRetro() ? MColorIcon.Type.RECTANGLE_SIMPLE : MColorIcon.Type.RECTANGLE);
	}
	
	// used in MColorMenu
	static Color selectColor(final Window owner, final ColorPalette colorPalette, final Color oldColor, final Color defaultValue) {
		MColorChooserDialog colorChooser = new MColorChooserDialog(
			owner,
			null, // default title
			oldColor,
			TK.get(defaultValue, oldColor)
		);

		// use the same color palette as in parent color component
		if (colorPalette != null)
			colorChooser.setSelectedColorPalette(colorPalette);

		if (!colorChooser.exec())
			return null;

		return colorChooser.getValue();
	}

}
