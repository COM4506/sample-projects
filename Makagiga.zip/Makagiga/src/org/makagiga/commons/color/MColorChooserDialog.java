// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.color;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Robot;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.net.URI;
import java.text.ParseException;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import javax.swing.BorderFactory;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.event.ChangeListener;
import javax.swing.undo.AbstractUndoableEdit;

import org.makagiga.commons.ClipboardException;
import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.Config;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MClipboard;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MDataAction;
import org.makagiga.commons.MDisposable;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.TK;
import org.makagiga.commons.Tuple;
import org.makagiga.commons.UI;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.form.Field;
import org.makagiga.commons.form.Form;
import org.makagiga.commons.form.FormPanel;
import org.makagiga.commons.form.Info;
import org.makagiga.commons.html.HTMLBuilder;
import org.makagiga.commons.security.MAccessController;
import org.makagiga.commons.swing.ActionGroup;
import org.makagiga.commons.swing.ContainerScanner;
import org.makagiga.commons.swing.Input;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MLinkButton;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMenuItem;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MSmallButton;
import org.makagiga.commons.swing.MSimpleLayout;
import org.makagiga.commons.swing.MTextField;
import org.makagiga.commons.swing.MTimer;
import org.makagiga.commons.swing.MToggleButton;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.commons.swing.MUndoManager;
import org.makagiga.commons.swing.border.MLineBorder;

/**
 * A color chooser dialog.
 * 
 * @since 4.0 (org.makagiga.commons.color.MColorChooserDialog name)
 */
public class MColorChooserDialog extends MDialog {

	// private

	private boolean canUpdateUndoManager;
	private ChangeListener changeListener;
	private Color color;
	private final Color defaultColor;
	private HTMLColorChooserPanel htmlColorChooserPanel;
	private JColorChooser colorChooser;
	private MArrayList <Tuple.Two<Color, String>> _bookmarks;
	private MColorPicker colorPicker;
	private final MLabel backgroundPreviewLabel;
	private final MLabel foregroundPreviewLabel;
	private final MLineBorder previewBorder;
	private MUndoManager undoManager;
	private PickerColorChooserPanel pickerColorChooserPanel;
	private ValueListener<Color> valueListener;

	// public

	/**
	 * Constructs a color chooser dialog.
	 *
	 * @param owner the owner window
	 * @param title A dialog title
	 * @param initialColor An initial color
	 * @param defaultColor A default color
	 */
	public MColorChooserDialog(final Window owner, final String title, final Color initialColor, final Color defaultColor) {
		super(owner, Objects.toString(title, i18n("Choose a Color")), STANDARD_DIALOG | USER_BUTTON | FORCE_STANDARD_BORDER);

		undoManager = new MUndoManager();
		undoManager.updateUserActions();

		MButton bookmarksButton = new MButton(i18n("Bookmarks"), "ui/star");
		bookmarksButton.setPopupMenu(this::createBookmarksMenu);

		MButton historyButton = new MButton(MActionInfo.HISTORY, true);
		historyButton.setPopupMenu(() -> ColorHistory.createMenu(this::setValue));

		MToolBar toolBar = new MToolBar();
		toolBar.setTextPosition(MToolBar.TextPosition.ALONGSIDE_ICONS);
		toolBar.showLineBorder(MLineBorder.Position.BOTTOM);
		setToolBar(toolBar);

		undoManager.updateToolBar(toolBar);
		toolBar.addGap();
		toolBar.addButton(bookmarksButton, MToolBar.SHOW_TEXT);
		toolBar.addButton(historyButton, MToolBar.SHOW_TEXT);

		getUserButton().setIcon(
			UI.buttonIcons.get()
			? MActionInfo.RESTORE_DEFAULT_VALUES.getIcon()
			: MActionInfo.RESTORE_DEFAULT_VALUES.getSmallIcon()
		);

		String toolTipText = "<p>" + TK.escapeXML(MActionInfo.RESTORE_DEFAULT_VALUES.getText()) + "</p>";
		if (defaultColor != null)
			toolTipText += MSmallColorButton.createColorCode(defaultColor);
		getUserButton().setToolTipText(UI.makeHTML(toolTipText));
		
		this.defaultColor = defaultColor;

		// init preview

		previewBorder = new MLineBorder();
		for (MLineBorder.Style i : previewBorder)
			i.setSize(2);
		Border previewPadding = UI.createEmptyBorder(2);
		Border border = BorderFactory.createCompoundBorder(previewBorder, previewPadding);

		MLabel currentPreviewLabel = null;
		if (initialColor != null) {
			currentPreviewLabel = new MLabel();
			currentPreviewLabel.setBorder(UI.createEmptyBorder(4));

			currentPreviewLabel.setOpaque(true);
			currentPreviewLabel.setText(i18n("Current"));
			
			currentPreviewLabel.setBackground(initialColor);
			currentPreviewLabel.setForeground(MColor.getContrastBW(initialColor));
		}

		backgroundPreviewLabel = new MLabel(i18n("Preview"));
		backgroundPreviewLabel.setBorder(border);
		backgroundPreviewLabel.setOpaque(true);

		foregroundPreviewLabel = new MLabel(i18n("Preview"));
		foregroundPreviewLabel.setBackground(Color.WHITE);
		foregroundPreviewLabel.setBorder(border);
		foregroundPreviewLabel.setOpaque(true);

		colorPicker = new MColorPicker();
		colorPicker.setColorButtonVisible(false);

		if (colorPicker.colorPaletteComboBox != null) {
			Config config = getConfigPrivileged();
			colorPicker.readConfig(config, "ColorChooser");
		}
		
		addEast(colorPicker);

		MPanel previewPanel = MPanel.createHBoxPanel();
		if (currentPreviewLabel != null) {
			previewPanel.add(currentPreviewLabel);
			previewPanel.addGap();
		}
		previewPanel.add(backgroundPreviewLabel);
		previewPanel.add(foregroundPreviewLabel);

		// init color chooser
		UI.setWaitCursor(true);
		try {
			colorChooser = new JColorChooser();

			htmlColorChooserPanel = new HTMLColorChooserPanel();
			colorChooser.addChooserPanel(htmlColorChooserPanel);

			pickerColorChooserPanel = new PickerColorChooserPanel();
			colorChooser.addChooserPanel(pickerColorChooserPanel);

			colorChooser.setDragEnabled(Kiosk.actionDragDrop.get());
			
			// hide "Recent" panel
			new ContainerScanner(colorChooser) {
				@Override
				public void processComponent(final Container parent, final Component component) {
					if (
						(component instanceof JComponent) &&
						(parent instanceof JPanel) &&
						(parent.getComponentCount() == 1) &&
						"javax.swing.colorchooser.RecentSwatchPanel".equals(component.getClass().getName())
					) {
						parent.setVisible(false);
						
						JLabel l = MLabel.getLabel((JComponent)component);
						if (l != null)
							l.setVisible(false);
						
						this.stop();
					}
				}
			};
		}
		finally {
			UI.setWaitCursor(false);
		}
		colorChooser.setPreviewPanel(previewPanel);

		changeListener = e -> setValue(colorChooser.getSelectionModel().getSelectedColor());
		colorChooser.getSelectionModel().addChangeListener(changeListener);

		valueListener = e -> setValue(e.getNewValue());
		colorPicker.addValueListener(valueListener);
		
		addCenter(colorChooser);
		setValue(initialColor);
		if (initialColor == null)
			colorChooser.setColor(Color.BLACK);
		
		setDefaultFocus(colorChooser);
		packFixed();

		canUpdateUndoManager = true;
	}

	/**
	 * Returns the selected color, or {@code null} if dialog has been cancelled.
	 * 
	 * @since 4.0
	 */
	public Color getValue() { return color; }

	/**
	 * Sets color to @p value.
	 * 
	 * @since 4.0
	 */
	@InvokedFromConstructor
	public void setValue(final Color newColor) {
		boolean updateModel = !Objects.equals(color, newColor);

		if (canUpdateUndoManager && updateModel) {
			undoManager.addEdit(new ColorEdit(color, newColor));
			undoManager.updateUserActions();
		}

		color = newColor;

		for (MLineBorder.Style i : previewBorder)
			i.setColor(color);
		
		if (color == null) {
			backgroundPreviewLabel.setEnabled(false);
			foregroundPreviewLabel.setEnabled(false);
		}
		else {
			backgroundPreviewLabel.setEnabled(true);
			foregroundPreviewLabel.setEnabled(true);

			if (updateModel)
				colorChooser.setColor(color);
			
			backgroundPreviewLabel.setBackground(color);
			backgroundPreviewLabel.setForeground(MColor.getContrastBW(color));
			
			foregroundPreviewLabel.setForeground(color);
		}
		colorPicker.setValue(color);
	}

	// protected

	@Override
	protected boolean onAccept() {
		ColorHistory.add(getValue());

		return super.onAccept();
	}

	@Override
	protected void onClose() {
		if (colorPicker != null) {
			String colorPaletteName = colorPicker.getSelectedColorPalette().toString();
			MAccessController.doPrivileged(() -> {
				Config config = Config.getDefault();
				config.write("ColorChooser.colorPaletteName", colorPaletteName);
				config.sync();

				return null;
			} );
		}
		
		if (colorChooser != null) {
			if (changeListener != null) {
				colorChooser.getSelectionModel().removeChangeListener(changeListener);
				changeListener = null;
			}

			if (valueListener != null) {
				colorPicker.removeValueListener(valueListener);
				valueListener = null;
			}

			if (htmlColorChooserPanel != null) {
				colorChooser.removeChooserPanel(htmlColorChooserPanel);
				htmlColorChooserPanel.actionGroup = null;
				htmlColorChooserPanel.value = null;
				htmlColorChooserPanel = null;
			}

			if (pickerColorChooserPanel != null) {
				pickerColorChooserPanel.dispose();
				colorChooser.removeChooserPanel(pickerColorChooserPanel);
				pickerColorChooserPanel = null;
			}

			colorChooser = null;
			colorPicker = null;
		}

		undoManager = TK.dispose(undoManager);
	}

	@Override
	protected void onUserClick() {
		color = defaultColor;
		accept();
	}

	// private

	private MMenu createBookmarksMenu() {
		MArrayList<Tuple.Two<Color, String>> bookmarks = getBookmarks();
	
		MMenu menu = new MMenu();
		
		Color currentColor = getValue();
		Tuple.Two<Color, String> currentBookmark = null;
		for (Tuple.Two<Color, String> i : bookmarks) {
			if (i.get1().equals(currentColor)) {
				currentBookmark = i;
				
				break; // for
			}
		}
		
		if (currentBookmark != null) {
			menu.add(new MDataAction<>(currentBookmark, i18n("Remove Bookmark"), "ui/clearright",
				action -> {
					getBookmarks().remove(action.getData());
					syncBookmarks();
				}
			));
		}
		else {
			menu.add(new MColorAction(currentColor, i18n("Add Bookmark"), action -> {
				Color color = action.getColor();
				
				ColorPalette palette;
				if (colorPicker != null)
					palette = colorPicker.getSelectedColorPalette();
				else
					palette = ColorPalette.getNamedColors();
				String name = palette.getDisplayName(color);
				if (!TK.startsWith(name, '#'))
					name = ColorProperty.toDisplayString(color) + " - " + name;
				
				String bookmarkName = new Input.GetTextBuilder()
					.allowEmptyText(true)
					.autoCompletion("color-bookmark-name")
					.icon("ui/bookmark")
					.label(i18n("Name:"))
					.text(name)
					.title(action.getName())
					.exec(action);
					
				if (bookmarkName == null)
					return;
					
				getBookmarks().add(Tuple.of(color, bookmarkName));
				sortBookmarks();
				syncBookmarks();
			} ));
		}
		
		menu.addSeparator();
		
		for (Tuple.Two<Color, String> i : bookmarks) {
			Color color = i.get1();
			String name = i.get2();
			String toolTipText = ColorProperty.toDisplayString(color);
			if (name.isEmpty())
				name = toolTipText;
			
			MMenuItem item = menu.add(new MColorAction(color, name,
				action -> setValue(action.getColor())
			));
			item.setToolTipText(toolTipText);
			if (color.equals(currentColor))
				item.setStyle("font-weight: bold");
		}
		
		if (bookmarks.isEmpty())
			menu.addTitle(i18n("No Bookmarks"), "ui/info");

		return menu;
	}

	private MArrayList<Tuple.Two<Color, String>> getBookmarks() {
		if (_bookmarks != null)
			return _bookmarks;
	
		_bookmarks = new MArrayList<>();
		
		Config config = getConfigPrivileged();
		int bookmarkCount = config.readInt("ColorChooser.bookmarks.count", 0, 0, Integer.MAX_VALUE);
		for (int i = 0; i < bookmarkCount; i++) {
			Color color = config.readColor("ColorChooser.bookmarks.color." + (i + 1), null);
			String name = config.read("ColorChooser.bookmarks.name." + (i + 1), null);
			if ((color != null) && (name != null))
				_bookmarks.add(Tuple.of(color, name));
		}
		MColorChooserDialog.this.sortBookmarks();
		
		return _bookmarks;
	}

	private Config getConfigPrivileged() {
		SecurityManager sm = System.getSecurityManager();

		if (sm == null)
			return Config.getDefault();

		return MAccessController.doPrivileged(Config::getDefault);
	}
	
	private void sortBookmarks() {
		_bookmarks.sort(Comparator
			.comparing((Tuple.Two<Color, String> tuple) -> tuple.get1(), MColor::compare)
			.reversed()
		);
	}

	private void syncBookmarks() {
		MAccessController.doPrivileged(() -> {
			Config config = Config.getDefault();
			config.write("ColorChooser.bookmarks.count", _bookmarks.size());
			int index = 0;
			for (Tuple.Two<Color, String> i : _bookmarks) {
				index++;
				config.write("ColorChooser.bookmarks.color." + index, i.get1());
				config.write("ColorChooser.bookmarks.name." + index, i.get2());
			}

			// clean up
			if (_bookmarks.isEmpty()) {
				config.removeAllValues(key -> key.startsWith("Color.ColorChooser.bookmarks.color."));
				config.removeAllValues(key -> key.startsWith("String.ColorChooser.bookmarks.name."));
			}

			config.sync();

			return null;
		} );
	}

	// package

	void setSelectedColorPalette(final ColorPalette palette) {
		colorPicker.setSelectedColorPalette(palette);
	}
	
	// private classes

	private final class ColorEdit extends AbstractUndoableEdit {

		// private

		private final Color newColor;
		private final Color oldColor;

		// public

		@Override
		public void redo() {
			super.redo();
			this.setColor(newColor);
		}

		@Override
		public void undo() {
			super.undo();
			this.setColor(oldColor);
		}

		// private

		private ColorEdit(final Color oldColor, final Color newColor) {
			this.oldColor = oldColor;
			this.newColor = newColor;
		}

		private void setColor(final Color color) {
			try {
				MColorChooserDialog.this.canUpdateUndoManager = false;
				MColorChooserDialog.this.setValue(color);
			}
			finally {
				MColorChooserDialog.this.canUpdateUndoManager = true;
			}
		}

	}
	
	@Form(
		order = {
			"examples", "example1", "example2",
			"www", "colourLovers", "colorMixers", "colorSchemer", "colorSchemer2"
		}
	)
	private static final class HTMLColorChooserForm {

		// examples
		
		@Info(type = Info.TYPE_SEPARATOR)
		private final String examples = i18n("Examples");

		@Info(type = Info.TYPE_HTML)
		private final String example1 = i18n("{0} - red color", HTMLBuilder.createCode("#ff0000 | ff0000 | f00"));

		@Info(type = Info.TYPE_HTML)
		private final String example2 = i18n("{0} - light orange", HTMLBuilder.createCode("#FFA858 | 255, 168, 88 | rgb(255, 168, 88)"));

		// color schemers

		@Info(type = Info.TYPE_SEPARATOR)
		private final String www = "WWW";

		@Field(label = "COLOURlovers :: Color Trends & Palettes")
		private final URI colourLovers = URI.create("http://www.colourlovers.com/");

		@Field(label = "ColorMatch Remix")
		private final URI colorMixers = URI.create("http://www.colormixers.com/");

		@Field(label = "Color Schemer Online")
		private final URI colorSchemer = URI.create("http://www.colorschemer.com/online.html");

		@Field(label = "Color Scheme Designer")
		private final URI colorSchemer2 = URI.create("http://colorschemedesigner.com/");

	}
	
	private static final class HTMLColorChooserPanel extends MColorChooserPanel {
		
		// private
		
		private ActionGroup actionGroup;
		private boolean inUpdate;
		private FormPanel<HTMLColorChooserForm> formPanel;
		private MLabel status;
		private MTextField value;
		
		// public

		@Override
		public void updateChooser() {
			if (!inUpdate) {
				Color color = getColorFromModel();
				
				// HACK: alpha not supported yet...
				if ((color != null) && MColor.hasAlpha(color))
					color = MColor.deriveAlpha(color, 255);
					
				String s = ColorProperty.toString(color);
				if (!Objects.equals(s, value.getText())) {
					value.setText(s);

					MLinkButton b;

					b = formPanel.getComponent("colourLovers");
					b.setURI("http://www.colourlovers.com/color/" + TK.toUpperCase(s.substring(1)));

					b = formPanel.getComponent("colorMixers");
					b.setURI("http://www.colormixers.com/?color=" + s.substring(1));
				}
			}
		}

		// protected

		@Override
		protected void buildChooser() {
			super.buildChooser();
			
			actionGroup = new ActionGroup();

			actionGroup.add("copy-hex", new MAction((MAction action) -> {
				try {
					MClipboard.setString(toHexString());
				}
				catch (ClipboardException exception) {
					action.showErrorMessage(exception);
				}
			} ));

			actionGroup.add("copy-rgb", new MAction((MAction action) -> {
				try {
					MClipboard.setString(toRGBString());
				}
				catch (ClipboardException exception) {
					action.showErrorMessage(exception);
				}
			} ));

			actionGroup.add("paste", new MAction(MActionInfo.PASTE, action -> {
				value.clear();
				value.paste();
			} ))
				.setVisibleInMenu(false);

			value = new MTextField(18);
			value.onChange(e -> {
				updateActions();
				updateColor();
			} );
			value.setStyle("font-family: monospace; font-size: larger");
			
			MPanel valuePanel = MPanel.createSimplePanel();
			valuePanel.getSimpleLayout()
				.setHGap(5)
				.setMargin(5);

			status = new MLabel();
			valuePanel.add(status, "left");
			valuePanel.add(MLabel.createFor(value, i18n("Value:")), "left");
			valuePanel.add(value);
			
			MSmallButton copyButton = new MSmallButton(MActionInfo.COPY);
			copyButton.setPopupMenu(() -> {
				MAction hexAction = actionGroup.getAction("copy-hex");
				hexAction.setName(i18n("Copy - {0}", toHexString()));

				MAction rgbAction = actionGroup.getAction("copy-rgb");
				rgbAction.setName(i18n("Copy - {0}", toRGBString()));

				return actionGroup.createMenu();
			} );
			valuePanel.add(copyButton, "right");
			
			valuePanel.add(new MSmallButton(actionGroup.getAction("paste"), false), "right");

			add(valuePanel, BorderLayout.NORTH);

			formPanel = new FormPanel<>(new HTMLColorChooserForm());
			add(formPanel);
		}
		
		// private

		private HTMLColorChooserPanel() {
			super(i18n("Web"));
		}
		
		private String toHexString() {
			return ColorProperty.toString(getColorFromModel());
		}

		private String toRGBString() {
			Color color = getColorFromModel();
		
			return String.format("rgb(%d, %d, %d)", color.getRed(), color.getGreen(), color.getBlue());
		}

		private void updateActions() {
			boolean enabled = !value.isEmpty();
			actionGroup.setEnabled("copy-hex", enabled);
			actionGroup.setEnabled("copy-rgb", enabled);
		}

		private void updateColor() {
			try {
				inUpdate = true;
				
				Color color;
				String text = value.getText();
				
				// parse rgb(rrr, ggg, bbb) notation
				if (text.contains(",")) {
					// normalize:
					// rgb(rrr, ggg, bbb) -> rrr,ggg,bbb
					text = text.replace(" ", "");
					text = text.replace("rgb(", "");
					text = text.replace(")", "");

					List<String> rgb = TK.fastSplit(text, ',');
					
					if (rgb.size() != 3)
						throw new ParseException(text, 0);

					color = new Color(
						Integer.parseInt(rgb.get(0)),
						Integer.parseInt(rgb.get(1)),
						Integer.parseInt(rgb.get(2))
					);
				}
				// parse #rrggbb notation
				else {
					color = ColorProperty.parseColor(text);
				}
				
				setSelectedColor(color);
				status.setIcon(MIcon.small("ui/ok"));
				status.setToolTipText(i18n("OK"));
			}
			catch (NumberFormatException | ParseException exception) {
				status.setIcon(MIcon.small("ui/error"));
				status.setToolTipText(i18n("Error"));
			}
			finally {
				inUpdate = false;
			}
		}
		
	}

	/**
	 * Based on the idea from AB5k widget.
	 */
	private static final class PickerColorChooserPanel extends MColorChooserPanel implements MDisposable {

		// private

		private boolean errorSet;
		private Color color;
		private MLabel imageLabel;
		private MLabel valueLabel;
		private MTimer updateTimer;
		private MToggleButton enabled;
		private final Point lastMouseLocation = new Point();
		private Robot bender;

		// public

		@Override
		public void updateChooser() {
			if (color == null)
				return;

			valueLabel.setHTML(String.format(
				"HTML: " + MSmallColorButton.createColorCode(color) + "<br>" +
				"RGB: %d, %d, %d<br>" +
				"X: %d | Y: %d",
				color.getRed(),
				color.getGreen(),
				color.getBlue(),
				lastMouseLocation.x,
				lastMouseLocation.y
			));
		}

		// MDisposable

		/**
		 * @since 4.0
		 */
		@Override
		public void dispose() {
			bender = null;
			enabled = null;
			imageLabel = null;
			updateTimer = TK.dispose(updateTimer);
			valueLabel = null;
		}

		// protected

		@Override
		protected void buildChooser() {
			super.buildChooser();
			MSimpleLayout l = new MSimpleLayout();
			l.setContentGap();
			setLayout(l);

			enabled = new MToggleButton(i18n("Start"), MIcon.small("ui/colorpicker"));
			enabled.addActionListener(e -> {
				if (!enabled.isSelected()) {
					enabled.setIcon(MIcon.small("ui/colorpicker"));
					enabled.setText(i18n("Start"));

					// update selected color
					if (color != null)
						setSelectedColor(color);
				}
				else {
					enabled.setIcon(MIcon.small("player/pause"));
					enabled.setText(i18n("Press {0} to Stop", "<" + UI.toString(VK_SPACE, 0) + ">"));

					enabled.requestFocusInWindow();
				}
			} );
			add(enabled, "top");

			imageLabel = new MLabel();
			add(imageLabel);

			valueLabel = new MLabel();
			add(valueLabel, "bottom");

			updateTimer.start();
		}

		// private

		private PickerColorChooserPanel() {
			super(i18n("Color Picker"));

			updateTimer = MTimer.milliseconds(100, timer -> {
				getColorFromScreen();

				return MTimer.CONTINUE;
			} );
		}

		private void createRobot() {
			if (bender != null)
				return;

			if (errorSet)
				return;

			try {
				bender = new Robot();
			}
			catch (Exception exception) {
				MLogger.exception(exception);

				enabled.setEnabled(false);
				errorSet = true;
				valueLabel.makeLargeMessage();
				valueLabel.setIconName("ui/error");
				valueLabel.setText(exception.getMessage());
			}
		}

		private void getColorFromScreen() {
			if (!enabled.isSelected())
				return;

			createRobot();

			if (bender == null)
				return;

			PointerInfo pointerInfo = MAccessController.doPrivileged(MouseInfo::getPointerInfo);
			if (pointerInfo == null) { // no mouse?
				imageLabel.setIconName("ui/error");
				imageLabel.setText(i18n("Error"));
				
				return;
			}
			
			Point location = pointerInfo.getLocation();

			if (location.equals(lastMouseLocation))
				return;

			lastMouseLocation.setLocation(location);

			color = bender.getPixelColor(location.x, location.y);

			int size = 30;
			Dimension screenSize = UI.getScreenSize();
			int centerX = location.x - (size / 2);
			int centerY = location.y - (size / 2);
			final Rectangle r = new Rectangle(centerX, centerY, size, size);

			// do not capture "offscreen" image
			if (r.x < 0)
				r.x = 0;
			else if (r.x + size > screenSize.width)
				r.x = screenSize.width - size;
			if (r.y < 0)
				r.y = 0;
			else if (r.y + size > screenSize.height)
				r.y = screenSize.height - size;

			BufferedImage screenshot = MAccessController.doPrivileged(() -> bender.createScreenCapture(r));

			int zoom = 5;
			int zoomSize = size * zoom;
			BufferedImage icon = UI.createCompatibleImage(zoomSize, zoomSize, false);
			Graphics2D g = icon.createGraphics();
			g.setColor(Color.PINK);
			g.fillRect(0, 0, zoomSize, zoomSize);

			g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
			g.drawImage(
				screenshot,
				(r.x - centerX) * zoom,
				(r.y - centerY) * zoom,
				zoomSize,
				zoomSize,
				null
			);

			if (color != null) {
				g.setColor(MColor.getContrastBW(color));
				g.drawRect(zoomSize / 2, zoomSize / 2, zoom, zoom);
			}

			g.dispose();
			imageLabel.setImage(icon);

			updateChooser();
		}

	}

}
