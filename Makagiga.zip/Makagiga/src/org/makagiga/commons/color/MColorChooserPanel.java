// Copyright 2009 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.color;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.Icon;
import javax.swing.colorchooser.AbstractColorChooserPanel;

import org.makagiga.commons.UI;
import org.makagiga.commons.swing.MPanel;

/**
 * @since 3.8, 4.0 (org.makagiga.commons.color package)
 */
public abstract class MColorChooserPanel extends AbstractColorChooserPanel {

	// private

	private final String displayName;
	
	// public
	
	public MColorChooserPanel(final String displayName) {
		this.displayName = displayName;
	}

	@Override
	public String getDisplayName() { return displayName; }

	@Override
	public Icon getLargeDisplayIcon() { return null; }

	@Override
	public Icon getSmallDisplayIcon() { return null; }

	public void setSelectedColor(final Color value) {
		getColorSelectionModel().setSelectedColor(value);
	}

	// protected

	/**
	 * Overriden to set empty border (of size {@link MPanel#DEFAULT_CONTENT_MARGIN})
	 * and border layout with gap of size {@code 5}.
	 */
	@Override
	protected void buildChooser() {
		setBorder(UI.createEmptyBorder(MPanel.DEFAULT_CONTENT_MARGIN));
		setLayout(new BorderLayout(5, 5));
	}

}
