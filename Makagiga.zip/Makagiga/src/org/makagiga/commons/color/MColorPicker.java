// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.color;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Objects;
import javax.accessibility.AccessibleContext;
import javax.accessibility.AccessibleRole;
import javax.swing.JPopupMenu;

import org.makagiga.commons.Config;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.ValueListener;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.swing.MComboBox;
import org.makagiga.commons.swing.MMenuElement;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MScrollPane;
import org.makagiga.commons.swing.ValueChooser;
import org.makagiga.commons.swing.event.MMouseAdapter;

/**
 * A color picker.
 *
 * @mg.example
 * <pre class="brush: java">
 * MColorPicker colorPicker = new MColorPicker();
 * colorPicker.setValue(Color.BLUE);
 * colorPicker.addValueListener(new ValueListener&lt;Color&gt;() {
 *   {@literal @}Override
 *   public void valueChanged(ValueEvent&lt;Color&gt; e) {
 *     doSomethingWith(e.getNewValue());
 *   }
 * } );
 * </pre>
 * 
 * @since 4.0 (org.makagiga.commons.color package)
 */
// !!!: keyboard support
public class MColorPicker extends MMenuElement implements ValueChooser<Color> {
	
	// private

	private final ColorComponent colorComponent;
	private final MColorButton customColorButton;
	private final MPanel colorButtonPanel;
	
	// package
	
	MComboBox<ColorPalette> colorPaletteComboBox;

	// public

	/**
	 * Constructs a color picker.
	 */
	public MColorPicker() {
		this(ColorPalette.getApplicationPalette(), false);
	}

	/**
	 * @since 4.0
	 */
	public MColorPicker(final ColorPalette palette, final boolean simple) {
		colorComponent = new ColorComponent(this);
		setColorPalette(palette);
		addCenter(new MScrollPane(colorComponent, MScrollPane.NO_BORDER_AUTO));

		// custom color
		customColorButton = new MColorButton();
		customColorButton.addValueListener(e -> {
			firePropertyChange(VALUE_PROPERTY, e.getOldValue(), e.getNewValue());
			TK.fireValueChanged(this, getValueListeners(), e.getOldValue(), e.getNewValue());
			colorComponent.repaint();
		} );
		colorButtonPanel = MPanel.createHLabelPanel(customColorButton, i18n("More:"));
		if (!simple)
			addSouth(colorButtonPanel);

		if (!simple) {
			colorPaletteComboBox = new MComboBox<>();
			colorPaletteComboBox.onSelect((source, item) -> setColorPalette(item));
			colorPaletteComboBox.setRenderer(new MRenderer<ColorPalette>());
			// allow quick search - colorPaletteComboBox.setRequestFocusEnabled(false);
			colorPaletteComboBox.setToolTipText(i18n("Color Palette"));
			try {
				colorPaletteComboBox.setEventsEnabled(false);
				colorPaletteComboBox.addItem(palette);
				for (ColorPalette i : ColorPalette.getAll()) {
					if (i != palette) // do not duplicate entries
						colorPaletteComboBox.addItem(i);
				}
			}
			finally {
				colorPaletteComboBox.setEventsEnabled(true);
			}
			addNorth(colorPaletteComboBox);
		}
	}
	
	@Override
	public Component getComponent() { return colorComponent; }

	/**
	 * @since 3.8.10
	 */
	public ColorPalette getSelectedColorPalette() {
		return (colorPaletteComboBox != null) ? colorPaletteComboBox.getSelectedItem() : null;
	}

	/**
	 * @since 3.8.10
	 */
	public void setSelectedColorPalette(final ColorPalette palette) {
		if (colorPaletteComboBox != null)
			colorPaletteComboBox.setSelectedItem(palette);
	}

	/**
	 * @since 3.8.8
	 */
	public boolean isColorButtonVisible() {
		return colorButtonPanel.isVisible();
	}

	/**
	 * @since 3.8.8
	 */
	public void setColorButtonVisible(final boolean value) {
		colorButtonPanel.setVisible(value);
	}

	/**
	 * @since 3.8.10
	 */
	public void readConfig(final Config config, final String keyPrefix) {
		TK.checkNullOrEmpty(keyPrefix);

		if (colorPaletteComboBox == null)
			return;

		String colorPaletteName = config.read(keyPrefix + ".colorPaletteName", null);
		if (colorPaletteName != null) {
			for (ColorPalette i : colorPaletteComboBox) {
				if (i.toString().equals(colorPaletteName)) {
					colorPaletteComboBox.setSelectedItem(i);

					break; // for
				}
			}
		}
	}

	/**
	 * @since 3.8.10
	 */
	public void writeConfig(final Config config, final String keyPrefix) {
		TK.checkNullOrEmpty(keyPrefix);

		if (colorPaletteComboBox == null)
			return;

		String colorPaletteName = colorPaletteComboBox.getSelectedItem().toString();
		config.write(keyPrefix + ".colorPaletteName", colorPaletteName);
	}

	/**
	 * Enables/disables this component and its subcomponents.
	 * @param value {@code true} - enabled; {@code false} - disabled
	 */
	@Override
	public void setEnabled(final boolean value) {
		super.setEnabled(value);
		colorComponent.setEnabled(value);
		customColorButton.setEnabled(value);
	}

	// ValueChooser

	/**
	 * @since 4.0
	 */
	@Override
	public void addValueListener(final ValueListener<Color> l) {
		listenerList.add(ValueListener.class, l);
	}

	/**
	 * @since 4.0
	 */
	@Override
	public void removeValueListener(final ValueListener<Color> l) {
		listenerList.remove(ValueListener.class, l);
	}

	/**
	 * @since 4.0
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ValueListener<Color>[] getValueListeners() {
		return listenerList.getListeners(ValueListener.class);
	}

	/**
	 * @since 4.0
	 */
	@Override
	public Color getValue() {
		return customColorButton.getValue();
	}

	/**
	 * @since 4.0
	 */
	@Override
	public void setValue(final Color value) {
		Object oldColor = getValue();
		customColorButton.setValue(value);
		if (!Objects.equals(oldColor, value)) {
			firePropertyChange(VALUE_PROPERTY, oldColor, value);
			colorComponent.repaint();
		}
	}

	// private

	private void setColorPalette(final ColorPalette palette) {
		colorComponent.setColorPalette(palette);
		Dimension size = colorComponent.getPreferredSize();
		colorComponent.setSize(size);

		MScrollPane.scrollToTop(colorComponent, true);

		// HACK: update and fix layout
		revalidate();
	}

	// private classes

	private static final class ColorComponent extends MPanel {

		// private

		private ColorPalette colorPalette;
		private final int buttonSize;
		private List<Color> colorList;
		private final Point pressedPoint = new Point(-1, -1);
		private final WeakReference<MColorPicker> colorPickerRef;

		// public

		@Override
		public AccessibleContext getAccessibleContext() {
			if (accessibleContext == null)
				accessibleContext = new AccessibleColorComponent();

			return accessibleContext;
		}

		@Override
		public Dimension getMaximumSize() {
			return getPreferredSize();
		}

		@Override
		public Dimension getMinimumSize() {
			return new Dimension(buttonSize, buttonSize);
		}

		@Override
		public Dimension getPreferredSize() {
			if (colorPalette == null)
				return getMinimumSize();

			return new Dimension(
				colorPalette.getColumns() * buttonSize,
				colorPalette.getRows() * buttonSize
			);
		}

		@Override
		public Point getToolTipLocation(final MouseEvent e) {
			return UI.ToolTipLocationPolicy.ALONGSIDE.getLocation(this, e);
		}

		@Override
		public String getToolTipText(final MouseEvent e) {
			if (colorPalette != null) {
				Color color = getColor(e.getX(), e.getY());

				if (color != null)
					return MSmallColorButton.getToolTipText(this, color, colorPalette);
			}

			return null;
		}

		// protected

		@Override
		protected void paintComponent(final Graphics g) {
			MColorPicker colorPicker = TK.get(colorPickerRef);
			Color bg;
			if ((colorPicker != null) && colorPicker.isOpaque()) {
				bg = UI.getBackground(colorPicker);
				g.setColor(bg);
				g.fillRect(0, 0, getWidth(), getHeight());
			}
			else {
				bg = null;
			}

			if (colorPalette == null)
				return;

			Color selectedColor = findSelectedColor();
			if (selectedColor != null)
				selectedColor = MColor.deriveAlpha(selectedColor, 255); // normalize

			int colCount = colorPalette.getColumns();
			int rowCount = colorPalette.getRows();
			int index = 0;
			int x;
			int y = 0;
			for (int row = 0; row < rowCount; row++) {
				x = 0;
				for (int col = 0; col < colCount; col++) {
					if (index < colorPalette.getCount()) {
						Color color = colorList.get(index);
						if (!isEnabled())
							color = color.darker();
						g.setColor(color);
						g.fillRect(x, y, buttonSize, buttonSize);

						if (color.equals(selectedColor)) {
							Color c = MColor.getContrastBW(color);
							c = MColor.deriveAlpha(c, 100);
							g.setColor(c);
							int s = buttonSize / 2;
							g.fillRect(
								x + buttonSize / 2 - s / 2,
								y + buttonSize / 2 - s / 2,
								s, s
							);
						}

						// visually separate a button from the component
						if (
							!UI.isRetro() &&
							(index == colorPalette.getCount() - 1) &&
							(bg != null) &&
							color.equals(bg)
						) {
							g.setColor(MColor.getContrast(color, 0.1f));
							g.drawLine(x + buttonSize, y, x + buttonSize, y + buttonSize);
							g.drawLine(x, y + buttonSize - 1, x + buttonSize - 1, y + buttonSize - 1);
						}
					}
					index++;
					x += buttonSize;
				}
				y += buttonSize;
			}
		}

		@Override
		protected void processMouseEvent(final MouseEvent e) {
			super.processMouseEvent(e);

			if (
				!e.isConsumed() &&
				(
					(e.getID() == MouseEvent.MOUSE_PRESSED) ||
					(e.getID() == MouseEvent.MOUSE_RELEASED)
				) &&
				MMouseAdapter.isLeft(e)
			) {
				e.consume();

				if (!isEnabled()) {
					TK.beep();

					return;
				}
				
				if (e.getID() == MouseEvent.MOUSE_PRESSED) {
					pressedPoint.setLocation(e.getX(), e.getY());
				}
				else if (
					(e.getID() == MouseEvent.MOUSE_RELEASED) &&
					MMouseAdapter.isButtonClick(e, pressedPoint)
				) {
					Color color = getColor(e.getX(), e.getY());
					if (color != null) {
						MColorPicker colorPicker = TK.get(colorPickerRef);
						Color oldColor = colorPicker.getValue();
						colorPicker.setValue(color);
						TK.fireValueChanged(colorPicker, colorPicker.getValueListeners(), oldColor, color);
					}
					else {
						TK.beep();
					}
				}
			}
		}

		@Override
		protected void processMouseMotionEvent(final MouseEvent e) {
			super.processMouseMotionEvent(e);

			if (e.getID() == MouseEvent.MOUSE_MOVED) {
				Color color = getColor(e.getX(), e.getY());
				UI.setHandCursor(this, color != null);
			}
		}

		// private

		private ColorComponent(final MColorPicker colorPicker) {
			buttonSize = MIcon.getSmallSize();
			colorPickerRef = new WeakReference<>(colorPicker);

			setOpaque(false);
			setToolTipText(UI.DYNAMIC_TOOL_TIP_TEXT);
		}

		private Color findSelectedColor() {
// TODO: common code: getInvoker() helper
			Container parent = getParent();
			while (parent != null) {
				if (parent instanceof MColorChooserDialog)
					return MColorChooserDialog.class.cast(parent).getValue();

				if (parent instanceof MColorMenu) {
					Color c = MColorMenu.class.cast(parent).getValue();

					if (c != null)
						return c;
				}

				if (parent instanceof MSmallColorChooser)
					return MSmallColorChooser.class.cast(parent).getValue();

				if (parent instanceof MColorPicker) {
					MColorPicker cp = (MColorPicker)parent;

					if (cp.isColorButtonVisible()) // contains a sensible value
						return cp.getValue();
				}

				if (parent instanceof JPopupMenu) // MSmallColorChooser popup menu
					parent = (Container)JPopupMenu.class.cast(parent).getInvoker();
				else
					parent = parent.getParent();
			}

			return null;
		}

		private Color getColor(final int x, final int y) {
			Dimension ps = getPreferredSize();

			if ((x > ps.width - 1) || (y > ps.height - 1))
				return null;

			int index =
				(x / buttonSize) +
				((y / buttonSize) * colorPalette.getColumns());

			return (index < colorList.size()) ? colorList.get(index) : null;
		}

		private void setColorPalette(final ColorPalette palette) {
			colorList = palette.toColorList();
			colorPalette = palette;
		}
		
		// private classes

		private final class AccessibleColorComponent extends AccessibleJPanel {

			// public

			@Override
			public AccessibleRole getAccessibleRole() {
				return AccessibleRole.COLOR_CHOOSER;
			}
		
		}

	}

}
