// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons.color;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.SystemColor;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.SoftReference;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeSet;
import javax.swing.Icon;

import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.FS;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MGraphics2D;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.OS;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.annotation.Important;
import org.makagiga.commons.annotation.InvokedFromConstructor;
import org.makagiga.commons.mv.MRenderer;
import org.makagiga.commons.security.MAccessController;

/**
 * @since 3.8.3
 */
public class ColorPalette
implements
	Comparable<ColorPalette>,
	Icon,
	Iterable<Map.Entry<Color, String>>,
	MRenderer.Renderable
{

	// private

	private static ColorPalette _application;
	private static ColorPalette _namedColors;
	private static ColorPalette _system;
	private static ColorPalette _web20;
	private Image previewImage;
	private int columns = DEFAULT_COLUMNS;
	private static final int DEFAULT_COLUMNS = 8;
	private static SoftReference<List<ColorPalette>> allRef;
	private final Map<Color, String> map = new LinkedHashMap<>();
	private String name;
	
	// public
	
	public ColorPalette() { }
	
	/**
	 * @since 4.0
	 */
	public ColorPalette(final BufferedReader reader) throws IOException {
		readText(reader);
	}

	/**
	 * @since 4.0
	 */
	public ColorPalette(final DataInputStream input) throws IOException {
		readBinary(input);
	}

	public ColorPalette(final String name, final Color... colors) {
		this(DEFAULT_COLUMNS, name, colors);
	}

	public ColorPalette(final int columns, final String name, final Color... colors) {
		this.columns = columns;
		this.name = name;

		if (colors != null) {
			ColorPalette namedColors = getNamedColors();
			for (Color i : colors)
				add(i, namedColors.getDisplayName(i));
		}
	}

	public Image createPreviewImage(final int w, final int h) {
		int colCount = getColumns();
		int rowCount = getRows();
		BufferedImage i = UI.createCompatibleImage(colCount, rowCount, false);
		MGraphics2D g = new MGraphics2D(i);
		g.setColor(Color.WHITE);
		g.fillRect();

		int c = 0;
		int r = 0;
		synchronized (this) {
			for (Color color : map.keySet()) {
				g.setColor(color);
				g.drawPoint(c, r);

				if (c == colCount - 1) {
					c = 0;
					r++;
				}
				else {
					c++;
				}
			}
		}

		g.dispose();

		return UI.scaleImage(i, w, h, UI.Quality.LOW);
	}
	
	public synchronized static List<ColorPalette> getAll() {
		List<ColorPalette> all = TK.get(allRef);
		if (all == null) {
			String[] s = {
				"Blues", "Caramel", "Coldfire", "Dark_pastels", "Firecode",
				"Gold", "Grays", "Lights", "Makagiga", "Muted", "Paintjet", "Pastels",
				"Plasma", "Royal", "Tango", "Web", "android-ics", "retro"
			};
			all = new MArrayList<>(s.length + 4);
			for (String i : s)
				all.add(new ColorPalette(i));

			all.add(getNamedColors()); // 1
			all.add(getApplicationPalette()); // 2
			all.add(getWeb20Palette()); // 3
			
			if (!OS.isLinux()) {
				ColorPalette system = getSystemPalette(); // 4
				if (system.getCount() > 0)
					all.add(system);
			}

			all.sort(null);
			all = Collections.unmodifiableList(all);
			allRef = new SoftReference<>(all);
		}

		return all;
	}

	public synchronized static ColorPalette getApplicationPalette() {
		if (_application == null) {
			_application = new ColorPalette("oxygen");
			ColorPalette namedColors = getNamedColors();
			_application.add(Color.BLACK, namedColors.getDisplayName(Color.BLACK));
			_application.add(Color.WHITE, namedColors.getDisplayName(Color.WHITE));
		}

		return _application;
	}

	public int getColumns() {
		synchronized (this) {
			return columns;
		}
	}

	public int getCount() {
		synchronized (this) {
			return map.size();
		}
	}

	public String getDisplayName(final Color color) {
		if (color == null)
			return "?";

		String displayName = getName(color);
		if (displayName == null)
			displayName = ColorProperty.toDisplayString(color);

		return displayName;
	}

	public synchronized static ColorPalette getNamedColors() {
		if (_namedColors == null) {
			_namedColors = new ColorPalette("Named_Colors");
			_namedColors.name = i18n("Named Colors"); // localize name
		}

		return _namedColors;
	}

	public String getName(final Color color) {
		synchronized (this) {
			return map.get(color);
		}
	}

	public int getRows() {
		return (int)Math.ceil((double)getCount() / (double)getColumns());
	}

	/**
	 * @since 5.0
	 */
	public synchronized static ColorPalette getSystemPalette() {
		if (_system == null) {
			_system = new ColorPalette(4, "System");

			TreeSet<Color> set = MAccessController.doPrivileged(() -> {
				TreeSet<Color> result = new TreeSet<>(MColor::compare);
				for (Field i : SystemColor.class.getDeclaredFields()) {
					int mods = i.getModifiers();
					if (Modifier.isPublic(mods) && Modifier.isStatic(mods) && (i.getType() == SystemColor.class)) {
						try {
							SystemColor color = (SystemColor)i.get(null);
							
							// use color copy because the original RGB value may be altered by user
							if (color != null)
								result.add(new Color(color.getRGB()));
						}
						catch (ReflectiveOperationException exception) {
							MLogger.developerException(exception);
						}
					}
				}
				
				return result;
			} );
			for (Color i : set)
				_system.add(i, null);
		}
		
		return _system;
	}

	public synchronized static ColorPalette getWeb20Palette() {
		if (_web20 == null)
			_web20 = new ColorPalette("Web2.0");

		return _web20;
	}

	private void readText(final BufferedReader reader) throws IOException { // private
		boolean inHeader = true;
		String line;
		while ((line = reader.readLine()) != null) {
			line = line.trim();

			// check format
			if (inHeader) {
				if (!line.equals("GIMP Palette"))
					throw new IOException("Expected \"GIMP Palette\" header");

				inHeader = false;

				continue; // for
			}

			// skip whitespace
			if (line.isEmpty())
				continue; // for

			// skip comment
			if (line.charAt(0) == '#')
				continue; // for

			// columns
			if (line.startsWith("Columns:")) {
				int c = DEFAULT_COLUMNS;
				try {
					c = Integer.parseInt(line.substring(8).trim());
					c = TK.limit(c, 1, 16);
				}
				catch (NumberFormatException exception) {
					MLogger.exception(exception);
				}

				synchronized (this) {
					columns = c;
				}

				continue; // for
			}

			// palette name
			if (line.startsWith("Name:")) {
				synchronized (this) {
					name = line.substring(5).trim();
				}

				continue; // for
			}

			line = line.replace("\t", " "); // normalize whitespace
			List<String> values = TK.fastSplit(line, ' ');
			if (values.size() > 3) {
				try {
					Color color = new Color(
						parse(values.get(0)), // red
						parse(values.get(1)), // green
						parse(values.get(2)) // blue
					);
					String displayName = String.join(" ", values.subList(3, values.size()));
					add(color, displayName);
				}
				catch (NumberFormatException exception) {
					throw new IOException("Invalid number format: " + line, exception);
				}
			}
			else {
				throw new IOException("Invalid line format: " + line);
			}
		}
	}

	private void readBinary(final DataInputStream input) throws IOException { // private
		String id = input.readUTF();

		if (!id.equals("GIMP Palette"))
			throw new IOException("Expected \"GIMP Palette\" header");

		int version = input.readInt();

		if (version != 1)
			throw new IOException("Version " + version + " is not supported");

		synchronized (this) {
			name = input.readUTF();
			columns = input.readInt();
		}

		int size = input.readInt();
		for (int i = 0; i < size; i++) {
			Color color = new Color(
				input.readUnsignedByte(), // r
				input.readUnsignedByte(), // g
				input.readUnsignedByte() // b
			);
			String colorName = input.readUTF();
			synchronized (this) {
				map.put(color, colorName);
			}
		}
	}

	public List<Color> toColorList() {
		MArrayList<Color> result;
		synchronized (this) {
			result = new MArrayList<>(map.size());
			result.addAll(map.keySet());
		}

		return result;
	}

	/**
	 * Returns the display-name of this palette.
	 */
	@Important
	@Override
	public String toString() {
		synchronized (this) {
			return Objects.toString(name, "?");
		}
	}

	/**
	 * @since 3.8.8
	 */
	public void writeBinary(final DataOutputStream output) throws IOException {
		output.writeUTF("GIMP Palette");
		output.writeInt(1); // version
		output.writeUTF(toString()); // name
		output.writeInt(getColumns());
		
		synchronized (this) {
			output.writeInt(map.size());
			for (Map.Entry<Color, String> i : map.entrySet()) {
				Color color = i.getKey();
				output.writeByte(color.getRed());
				output.writeByte(color.getGreen());
				output.writeByte(color.getBlue());
				output.writeUTF(i.getValue());
			}
		}
	}

	/**
	 * @since 4.0
	 */
	public void writeText(final OutputStream output) throws IOException {
		try (FS.TextWriter writer = FS.getUTF8Writer(output)) {
			writer.println("GIMP Palette");
			writer.println("Name: " + this);
			writer.println("Columns: " + getColumns());
			writer.println("#");

			StringBuilder s = new StringBuilder(6000);
			synchronized (this) {
				for (Map.Entry<Color, String> i : map.entrySet()) {
					s.setLength(0);
					Color color = i.getKey();
					appendByte(s, color.getRed());
					s.append(' ');
					appendByte(s, color.getGreen());
					s.append(' ');
					appendByte(s, color.getBlue());
					s
						.append('\t')
						.append(i.getValue())
						.append('\n');
					writer.print(s);
				}
			}
		}
	}

	// Comparable

	@Override
	public int compareTo(final ColorPalette o) {
		return this.toString().compareToIgnoreCase(o.toString());
	}

	// Icon

	@Override
	public int getIconHeight() {
		return MIcon.getSmallSize();
	}

	@Override
	public int getIconWidth() {
		return MIcon.getSmallSize();
	}

	@Override
	public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
		synchronized (this) {
			if (previewImage == null)
				previewImage = createPreviewImage(getIconWidth(), getIconHeight());
			g.drawImage(previewImage, x, y, null);
		}
	}

	// Iterable

	@Override
	public Iterator<Map.Entry<Color, String>> iterator() {
		synchronized (this) {
			return TK.unmodifiableIterator(map.entrySet().iterator());
		}
	}

	// MRenderer.Renderable

	@Override
	public void setupRenderer(final MRenderer<?> r) {
		r.setIcon(this);
		r.setText(toString());
	}

	// protected

	@InvokedFromConstructor
	protected void add(final Color color, final String name) {
		synchronized (this) {
			map.put(color, name);
		}
	}

	// private

	private ColorPalette(final String fileName) {
		DataInputStream input = null;
		final String resource = "palettes/" + fileName + ".bgpl";
		try {
			InputStream resourceStream;
			SecurityManager sm = System.getSecurityManager();
			if (sm == null)
				resourceStream = ColorPalette.class.getResourceAsStream(resource);
			else
				resourceStream = MAccessController.doPrivileged(() -> ColorPalette.class.getResourceAsStream(resource));
			input = new DataInputStream(new BufferedInputStream(resourceStream));
			readBinary(input);
		}
		catch (IOException exception) {
			MLogger.exception(exception);
		}
		finally {
			FS.close(input);
		}
	}

	private void appendByte(final StringBuilder s, final int b) {
		String asString = Integer.toString(b);
		int leadingSpaces = 3 - asString.length();
		for (int i = 0; i < leadingSpaces; i++)
			s.append(' ');
		s.append(asString);
	}

	private int parse(final String s) {
		// force valid range: 0..255
		return TK.limit(Integer.parseInt(s), 0, 255);
	}

}
