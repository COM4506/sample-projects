// Copyright 2010 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.commons;

import java.awt.Frame;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.io.Serializable;
import java.net.URI;
import java.security.BasicPermission;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.swing.Icon;

import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.commons.html.HTMLSelection;
import org.makagiga.commons.mods.Mod;
import org.makagiga.commons.swing.ContainerIterator;
import org.makagiga.commons.swing.MLinkButton;
import org.makagiga.commons.swing.MMenu;

/**
 * @since 3.8.4
 */
public final class Globals {

	// public

	//public static final String WEB_BROWSER_OBJECT_PROVIDER = "org.makagiga.commons.WebBrowser";

	/**
	 * @since 4.0
	 */
	public static final String LINK_TITLE = "org.makagiga.commons.Globals.LINK_TITLE";

	/**
	 * @since 4.0
	 */
	public static final String LINK_URI = "org.makagiga.commons.Globals.LINK_URI";

	/**
	 * @since 3.8.9
	 */
	public static final String MOD_ABOUT_INIT_CREDITS = "initCredits@org.makagiga.commons.about.MAboutDialog";

	/**
	 * @since 5.4
	 */
	public static final String MOD_ABOUT_INIT_TABS = "initTabs@org.makagiga.commons.about.MAboutDialog";

	/**
	 * @since 4.6
	 */
	public static final String MOD_DELETE_PRIVATE_DATA = "deletePrivateData@org.makagiga.commons.Globals";

	/**
	 * @since 5.0
	 */
	public static final String MOD_SCRIPT_IDE_DISPOSE = "dispose@org.makagiga.commons.script.ScriptIDE";

	/**
	 * @since 5.0
	 */
	public static final String MOD_SCRIPT_IDE_INIT = "init@org.makagiga.commons.script.ScriptIDE";

	/**
	 * @since 5.0
	 */
	public static final String MOD_SCRIPT_IDE_RESULT = "result@org.makagiga.commons.script.ScriptIDE";

	/**
	 * Used to show a {@code WikiPanel} component.
	 *
	 * <ul>
	 * <li>Source: {@code java.awt.Window} - the owner window or {@code null}</li>
	 * <li>Arg 0: {@code java.net.URI} - the page URI to load</li>
	 * <li>Return: {@code true} - on success</li>
	 * </ul>
	 *
	 * @see org.makagiga.commons.mods.Mods
	 *
	 * @since 3.8.8
	 */
	public static final String MOD_WIKI_SHOW_PANEL = "showPanel@org.makagiga.web.wiki.WikiPanel";

	// private

	//private static Map<String, List<Object>> objectList = new HashMap<>();
	private static List<URIBookmark> recentURI;
	private static final Map<String, ObjectProvider> objectProviders = new HashMap<>();
	private static MArrayList<MAction> linkActions;
	private static final MArrayList<URIBookmark> uriBookmarks = new MArrayList<>();
	private static final PropertyChangeSupport pcs = new PropertyChangeSupport(new Object());
	private static final Set<String> visitedLinks = new HashSet<>();
	
	// public

	/**
	 * @since 4.0
	 */
	public static void addLinkAction(final MAction action) {
		synchronized (Globals.class) {
			if (linkActions == null)
				linkActions = new MArrayList<>();
			linkActions.add(action);
		}
	}

	/**
	 * @since 4.0
	 */
	public static void removeLinkAction(final MAction action) {
		synchronized (Globals.class) {
			if (linkActions != null)
				linkActions.remove(action);
		}
	}

	/**
	 * @since 4.0
	 */
	public static void addPropertyChangeListener(final PropertyChangeListener l) {
		checkPermission("propertyChangeListener");

		pcs.addPropertyChangeListener(l);
	}

	/**
	 * @since 4.0
	 */
	public static void removePropertyChangeListener(final PropertyChangeListener l) {
		checkPermission("propertyChangeListener");

		pcs.removePropertyChangeListener(l);
	}

	/**
	 * @since 4.10
	 */
	public static void addRecentURI(final URIBookmark recent) {
		checkPermission("recentURI");
		synchronized (Globals.class) {
			if (recentURI == null)
				recentURI = new MArrayList<>();
			if (!recentURI.contains(recent))
				recentURI.add(recent);
			
			// remove the oldest item
			if (recentURI.size() > 10)
				recentURI.remove(0);
		}
	}

	/**
	 * @since 4.10
	 */
	public static List<Globals.URIBookmark> getRecentURI() {
		checkPermission("recentURI");
		synchronized (Globals.class) {
			if (recentURI == null)
				return Collections.emptyList();
				
			return Collections.unmodifiableList(recentURI);
		}
	}

	/**
	 * @since 4.2
	 */
	public synchronized static void addURIBookmark(final URIBookmark bookmark) {
		uriBookmarks.add(bookmark);
	}

	/**
	 * @since 4.2
	 */
	public synchronized static void removeURIBookmark(final URIBookmark bookmark) {
		uriBookmarks.remove(bookmark);
	}
	
	/**
	 * @since 4.2
	 */
	public synchronized static List<Globals.URIBookmark> getURIBookmarks() { return uriBookmarks; }

	/**
	 * @since 4.0
	 */
	public static void deletePrivateData() {
		checkPermission("deletePrivateData");
	
		synchronized (visitedLinks) {
			visitedLinks.clear();
		}

		synchronized (Globals.class) {
			if (recentURI != null)
				recentURI.clear();
		}

		// update visited link colors
		for (Frame frame : Frame.getFrames()) {
			for (MLinkButton i : ContainerIterator.findAll(frame, MLinkButton.class))
				i.setForeground(i.getLinkColor());
		}
	}

	/**
	 * @since 4.0
	 */
	public static void firePropertyChange(final PropertyChangeEvent e) {
		checkPermission("propertyChangeListener");
	
		pcs.firePropertyChange(e);
	}

	/**
	 * @since 4.0
	 */
	public static void firePropertyChanged(final Object source, final String propertyName, final Object oldValue, final Object newValue) {
		firePropertyChange(new PropertyChangeEvent(source, propertyName, oldValue, newValue));
	}

	/**
	 * @since 4.0
	 */
	public static boolean isLinkVisited(final String url) {
		checkPermission("visitedLinks");
	
		if (url == null)
			return false;

		synchronized (visitedLinks) {
			return visitedLinks.contains(url);
		}
	}

	/**
	 * @since 4.0
	 */
	public static boolean setLinkVisited(final String url, final boolean value) {
		checkPermission("visitedLinks");
	
		if (url == null)
			return false;

		synchronized (visitedLinks) {
			if (value)
				return visitedLinks.add(url);

			return visitedLinks.remove(url);
		}
	}

/*
	public static List<Object> getObjectList(final String id) {
		TK.checkNullOrEmpty(id);

		checkPermission("getObjectList");

		synchronized (Globals.class) {
			List<Object> result = objectList.get(id);

			if (result == null)
				return Collections.emptyList();

			return Collections.unmodifiableList(result);
		}
	}
*/

	public static boolean isObjectProvider(final String id) {
		TK.checkNullOrEmpty(id);

		synchronized (Globals.class) {
			return objectProviders.containsKey(id);
		}
	}

	public static Object newObjectInstance(final String id) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
		TK.checkNullOrEmpty(id);

		checkPermission("newObjectInstance");

		ObjectProvider provider;
		synchronized (Globals.class) {
			provider = objectProviders.get(id);
		}

		if (provider != null)
			return TK.newInstance(provider.className, provider.classLoader);

		return null;
	}

	public static void setObjectProvider(final String id, final ObjectProvider provider) {
		TK.checkNullOrEmpty(id);

		checkPermission("setObjectProvider");

		synchronized (Globals.class) {
			objectProviders.put(id, provider);
		}
	}

	/**
	 * @since 4.0
	 */
	public static void updateLinkMenu(final MMenu menu, final URI uri, final String bookmarkTitle) {
		updateLinkMenu(menu, uri, true, bookmarkTitle);
	}

	/**
	 * @since 4.0
	 */
	public static void updateLinkMenu(final MMenu menu, final URI uri, final boolean showLinkActions, final String bookmarkTitle) {
		if (uri == null)
			return;
		
		menu.addTitle(TK.centerSqueeze(uri.toString()));

		MAction copyLinkAddressAction = new MAction(MActionInfo.COPY_LINK_ADDRESS, action -> {
			HTMLSelection selection = HTMLSelection.fromURI(uri);
			selection.copyToClipboard();
		} );
		menu.add(copyLinkAddressAction);

		if (Kiosk.linkExtraMenu.get() && showLinkActions) {
			synchronized (Globals.class) {
				if (linkActions != null) {
					for (MAction i : linkActions) {
						i.putValue(Globals.LINK_TITLE, bookmarkTitle);
						i.putValue(Globals.LINK_URI, uri);
						menu.add(i);
					}
				}
			}
		}
	}

	// private

	@Uninstantiable
	private Globals() {
		TK.uninstantiable();
	}

	private static void checkPermission(final String name) {
		SecurityManager sm = System.getSecurityManager();
		if (sm != null)
			sm.checkPermission(new Globals.Permission(name));
	}

	// public classes

	/**
	 * @since 4.6
	 */
	public static abstract class DeletePrivateDataMod
	implements
		MDisposable,
		Mod
	{
		
		// public
		
		public static final String ACCEPT_ACTION = "accept";
		public static final String DISPOSE_ACTION = "dispose";
		public static final String INIT_ACTION = "init";
		
		// public
		
		// MDisposable
		
		@Override
		public void dispose() { }
		
		// Mod

		@Override
		public final Object exec(final Object source, final String command, final Object... args) {
			if (
				Globals.MOD_DELETE_PRIVATE_DATA.equals(command) &&
				(args.length == 2)
			) {
				String action = args[0].toString();
				switch (action) {
					case ACCEPT_ACTION:
						onAccept(args);
						break;
					case DISPOSE_ACTION:
						dispose();
						break;
					case INIT_ACTION:
						onInit(args);
						break;
				}
			}

			return null;
		}
		
		// protected

		protected abstract void onAccept(final Object... args);
		
		protected void onInit(final Object... args) { }

	}

	public static final class ObjectProvider {

		// private

		private final ClassLoader classLoader;
		private final String className;

		// public

		public ObjectProvider(final String className, final ClassLoader classLoader) {
			this.className = TK.checkNullOrEmpty(className);
			this.classLoader = classLoader;
		}

	}

	public static final class Permission extends BasicPermission {

		// private

		private Permission(final String name) {
			super(name);
		}

	}
	
	/**
	 * @since 4.2
	 */
	public static class URIBookmark implements Serializable {
	
		// private
		
		private final File file;
		private final Icon smallIcon;
		private final String displayName;
		private final URI uri;
	
		// public
		
		public URIBookmark(final File file, final String displayName, final Icon smallIcon) {
			this.file = Objects.requireNonNull(file);
			this.uri = file.toURI();
			this.displayName = TK.isEmpty(displayName) ? file.toString() : displayName;
			this.smallIcon = smallIcon;
		}
		
		public URIBookmark(final URI uri, final String displayName, final Icon smallIcon) {
			this.uri = Objects.requireNonNull(uri);
			this.file = "file".equals(uri.getScheme()) ? new File(uri) : null;
			this.displayName = TK.isEmpty(displayName) ? uri.toString() : displayName;
			this.smallIcon = smallIcon;
		}
		
		@Override
		public boolean equals(final Object o) {
			if (o == this)
				return true;
		
			if (!(o instanceof URIBookmark))
				return false;
			
			URIBookmark other = (URIBookmark)o;
			
			return this.toURI().equals(other.toURI());
			
		}
		
		@Override
		public int hashCode() {
			return toURI().hashCode();
		}
		
		public Icon getSmallIcon() { return smallIcon; }
		
		public File toFile() { return file; }
		
		@Override
		public String toString() { return displayName; }
		
		public URI toURI() { return uri; }
	
	}

}
