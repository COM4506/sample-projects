// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.chart;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.filechooser.FileFilter;

import org.makagiga.commons.Config;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.print.ImagePrintInfo;
import org.makagiga.commons.print.PrintDialog;
import org.makagiga.commons.script.ScriptYourself;
import org.makagiga.commons.swing.MCheckBox;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MFileChooser;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MToolBar;

/**
 * @author Graphics Idea: http://riddle.jogger.pl/2007/01/16/blog-riddle-a-ma-dwa-lata
 *
 * @since 3.0
 */
public class ChartPanel<M extends ChartModel> extends MPanel {

	// private

	private ChartView<M> view;
	private static final int DEFAULT_DIALOG_FLAGS =
		MDialog.COMPACT_HEADER | MDialog.HEADER_BAR | MDialog.SIMPLE_DIALOG;
	private MCheckBox showText;
	private MToolBar toolBar;
	private String title;
	
	// public

	@SuppressWarnings("unchecked")
	public ChartPanel(final String title) {
		this((M)new ChartModel(), title);
	}
	
	public ChartPanel(final M model, final String title) {
		this.title = title;

		// init tool bar
		
		toolBar = new MToolBar();
		toolBar.setOpaque(false);
		toolBar.setTextPosition(MToolBar.TextPosition.ALONGSIDE_ICONS);

		if (MLogger.isDeveloper()) {
			toolBar.add(
				new MAction(MActionInfo.OPEN, action -> open()),
				MToolBar.SHOW_TEXT
			);
		}

		if (Kiosk.actionExport.get()) {
			toolBar.add(
				new MAction(MActionInfo.SAVE, action -> export()),
				MToolBar.SHOW_TEXT
			);
		}
		
		toolBar.add(new MApplication.PrintAction(action -> print()), MToolBar.SHOW_TEXT);
		
		showText = new MCheckBox(i18n("Show Text"));
		showText.addActionListener(e -> setTextVisible(showText.isSelected()));
		showText.setOpaque(false);
		if (Kiosk.actionSettings.get()) {
			toolBar.addGap();
			toolBar.add(showText);
		}

		ScriptYourself.install(toolBar, "chart");
		addNorth(toolBar);

		// init chart view
		
		view = new ChartView<>(model);
		addCenter(view);
		
		setupChart();
		
		// init config

		Config config = Config.getDefault();
		setTextVisible(config.read("Chart.Text.visible", true));
	}
	
	public M getModel() {
		return getView().getPainter().getModel();
	}
	
	public void setModel(final M value) {
		getView().getPainter().setModel(value);
	}
	
	@Override
	public ChartPainter<M> getPainter() {
		return getView().getPainter();
	}
	
	/**
	 * @since 4.0
	 *
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public MCheckBox getShowTextCheckBox() { return showText; }

	@Override
	public String getTitle() { return title; }
	
	public MToolBar getToolBar() { return toolBar; }
	
	public ChartView<M> getView() { return view; }

	public boolean isTextVisible() {
		return showText.isSelected();
	}

	public void setTextVisible(final boolean value) {
		showText.setSelected(value);
		getView().getPainter().textVisible.set(value);
		getView().repaint();
	}

	/**
	 * @since 5.4
	 */
	public void showDialog(final Window owner) {
		showDialog(
			owner,
			MActionInfo.STATISTICS.getDialogTitle(),
			MActionInfo.STATISTICS.getIcon(),
			DEFAULT_DIALOG_FLAGS,
			this
		);
	}

	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static void showDialog(final Window parent, final String title, final Icon icon, final int flags, final ChartModel model) {
		ChartPanel<ChartModel> panel = new ChartPanel<>(model, title);
		showDialog(parent, title, icon, flags, panel);
	}

	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	public static void showDialog(final Window parent, final String title, final Icon icon, final int flags, final ChartPanel<?> panel) {
		MDialog dialog = new MDialog(parent, title, icon, flags);

		// move tool bar to the dialog
		MToolBar toolBar = panel.getToolBar();
		if (toolBar != null)
			dialog.setToolBar(toolBar);

		dialog.addCenter(panel);
		dialog.pack();
		dialog.removeContentMargin();

		if (flags == DEFAULT_DIALOG_FLAGS) {
			dialog.getBottomPanel()
				.setVisible(false);
		}

		dialog.exec(panel);

		// restore previous tool bar location
		if (toolBar != null)
			panel.addNorth(toolBar);

		panel.saveConfig();
	}

	// protected
	
	protected void export() {
		Config config = Config.getDefault();
		
		MFileChooser chooser = MFileChooser.createFileChooser(getWindowAncestor(), i18n("Save"));
		chooser.addFilter("XML", "mgchart", "xml");
		FileFilter pngFilter = chooser.addFilter("PNG", "png");
		
		MPanel accessory = chooser.getAccessoryPanel();
		accessory.addSeparator(i18n("Options"));
		MCheckBox transparent = new MCheckBox(i18n("Transparent"));
		transparent.setSelected(config.read("Chart.Export.transparent", false));
		accessory.add(transparent);
		
		chooser.setAutoAddExtension(true);
		chooser.setConfigKey("exportChart");
		chooser.setFileFilter(pngFilter);
		chooser.setSelectedFile(new File("chart"));
		if (chooser.saveDialog()) {
			config.write("Chart.Export.transparent", transparent.isSelected());
			config.sync();
			try {
				File file = chooser.getSelectedFile();
				// png
				if (chooser.getFileFilter() == pngFilter) {
					ChartView<?> v = getView();
					Color bg = transparent.isSelected() ? null : v.getPainter().backgroundColor.get();
					BufferedImage image = v.getPainter().toBufferedImage(bg);
					ImageIO.write(image, "png", file);
				}
				// xml
				else {
					ChartPainter<M> p = getView().getPainter();
					p.getModel().write(file, p);
				}
			}
			catch (IOException exception) {
				MMessage.error(getWindowAncestor(), exception);
			}
		}
	}

	protected void print() {
		ImagePrintInfo printInfo = new ImagePrintInfo(getTitle(), getView().getPainter().toBufferedImage(null));
		PrintDialog dialog = new PrintDialog(getWindowAncestor(), printInfo);
		dialog.exec();
	}
	
	/**
	 * @deprecated Since 5.4
	 */
	@Deprecated
	protected void setupChart() { }

	// private
	
	private void open() {
		MFileChooser chooser = MFileChooser.createFileChooser(getWindowAncestor(), i18n("Open"));
		chooser.setFileFilter(
			chooser.addFilter("XML", "mgchart", "xml")
		);
		chooser.setConfigKey("importChart");
		chooser.setSelectedFile(new File("chart"));
		if (chooser.openDialog()) {
			try {
				File file = chooser.getSelectedFile();
				ChartPainter<M> p = getView().getPainter();
				p.getModel().read(file, p);
				getView().repaint();
			}
			catch (IOException exception) {
				MMessage.error(getWindowAncestor(), exception);
			}
		}
	}
	
	private void saveConfig() {
		Config config = Config.getDefault();
		config.write("Chart.Text.visible", showText.isSelected());
		config.sync();
	}

}
