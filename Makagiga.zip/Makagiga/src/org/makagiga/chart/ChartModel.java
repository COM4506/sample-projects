// Copyright 2007 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga.chart;

import static org.makagiga.commons.UI.i18n;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import org.makagiga.commons.ColorProperty;
import org.makagiga.commons.FS;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MFormat;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.Property;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.annotation.Obsolete;
import org.makagiga.commons.swing.AbstractListTableModel;
import org.makagiga.commons.xml.SimpleXMLReader;
import org.makagiga.commons.xml.XMLBuilder;

/**
 * A chart data model.
 *
 * @since 2.0
 */
public class ChartModel extends AbstractListTableModel<ChartModel.Item> {
	
	// public
	
	public static final int COLUMN_TEXT = 0;
	public static final int COLUMN_VALUE = 1;
	public static final int COLUMN_COLOR = 2;
	public static final int COLUMN_ICON = 3;
	
	// private
	
	private String format;
	
	// public
	
	/**
	 * Constructs an empty data model.
	 */
	public ChartModel() {
		super(
			new ColumnInfo(i18n("Text"), String.class),
			new ColumnInfo(i18n("Value"), Long.class),
			new ColumnInfo(i18n("Color"), Color.class),
			new ColumnInfo(i18n("Icon"), Icon.class)
		);
	}

	/**
	 * @since 3.8
	 */
	public Item addEmptyInfo(final Color color) {
		Item info = addItem("<" + i18n("No Items") + ">", 0, color);
		info.setFormat("${text}");

		return info;
	}

	public Item addItem(final String text, final long number, final Color color) {
		return addItem(text, number, color, (Icon)null);
	}
	
	/**
	 * Adds a new item to the model.
	 *
	 * @param text The item text label (can be @c null)
	 * @param number The item value
	 * @param color The item color
	 * @param icon The item icon (can be @c null)
	 *
	 * @return A new item
	 */
	public Item addItem(final String text, final long number, final Color color, final Icon icon) {
		Item item = new Item(text, number, color, icon);
		addRow(item);
		
		return item;
	}

	public Item addItem(final String text, final long number, final Color color, final String iconPath) {
		Item item = addItem(text, number, color);
		item.setIconPath(iconPath);
		
		return item;
	}

	/**
	 * @since 2.2
	 */
	public String getFormat() { return format; }

	/**
	 * @since 2.2
	 */
	public void setFormat(final String value) { format = value; }

	@Override
	public Object getValueAt(final int row, final int column) {
		Item item = getRowAt(row);
		switch (column) {
			case COLUMN_TEXT:
				return item.getText();
			case COLUMN_VALUE:
				return item.number;
			case COLUMN_COLOR:
				return item.getValue();
			case COLUMN_ICON:
				return item.getIcon();
			default:
				MLogger.error("chart", "getValueAt: Unknown column: %s", column);
				
				return null;
		}
	}

	@Override
	public void setValueAt(final Object value, final int row, final int column) {
		Item item = getRowAt(row);
		Item before = createCopyForUndo(item);
		switch (column) {
			case COLUMN_TEXT:
				item.setText((String)value);
				break;
			case COLUMN_VALUE:
				item.number = (Long)value;
				break;
			case COLUMN_COLOR:
				item.setValue((Color)value);
				break;
			case COLUMN_ICON:
				if (value == null)
					item.setIconPath(null);
				else if (value instanceof String)
					item.setIconPath((String)value);
				else
					item.setIcon((Icon)value);
				item.averageCache = null;
				item.imageCache = null;
				break;
			default:
				MLogger.error("chart", "setValueAt: Unknown column: %s", column);
		}
		fireTableCellUpdated(row, column);
		fireUndoableEditHappened(new ChangeUndo(before, createCopyForUndo(item), row));
	}
	
	public void read(final File file, final ChartPainter<?> p) throws IOException {
		try (FS.BufferedFileInput input = new FS.BufferedFileInput(file)) {
			read(input, p);
		}
	}

	public void read(final InputStream input, final ChartPainter<?> p) throws IOException {
		clear();
		
		final Map<String, String> painterProperties =
			(p == null)
			? null
			: (new HashMap<>());

		SimpleXMLReader reader = new SimpleXMLReader() {
			private boolean inItem;
			private boolean inPainter;
			private ChartModel.Item item;
			@Override
			protected void onEnd(final String name) {
				if (inItem && "item".equals(name)) {
					ChartModel.this.addRow(item);
					inItem = false;
				}
				else if (inPainter && "painter".equals(name)) {
					inPainter = false;
				}
			}
			@Override
			protected void onStart(final String name) {
				if (!inItem && "item".equals(name)) {
					item = new ChartModel.Item();
					inItem = true;
				}
				else if (!inPainter && "painter".equals(name)) {
					inPainter = true;
				}
				else if (inItem) {
					switch (name) {
						case "color":
							try {
								item.setValue(ColorProperty.parseColor(getValue()));
							}
							catch (ParseException exception) {
								setError(exception);
							}
							break;
						case "icon":
							item.setIconPath(getValue());
							break;
						case "text":
							item.setText(getValue());
							break;
						case "value":
							try {
								item.setNumber(Long.parseLong(getValue()));
							}
							catch (NumberFormatException exception) {
								setError(exception);
							}
							break;
					}
				}
				else if (inPainter && "property".equals(name) && (painterProperties != null)) {
					String propertyName = getStringAttribute("name");
					if (propertyName != null) {
						String propertyValue = getStringAttribute("value");
						if (propertyValue != null)
							painterProperties.put(propertyName, propertyValue);
					}
				}
			}
		};
		reader.read(input);
		
		if (painterProperties != null) {
			try {
				for (Map.Entry<Field, Property<?>> i : Property.list(p).entrySet()) {
					Field field = i.getKey();
					String propertyValue = painterProperties.get(field.getName());
					if (propertyValue != null) {
						Property<?> property = i.getValue();
						try {
							property.parse(propertyValue);
						}
						catch (ParseException exception) {
							throw new IOException(exception);
						}
					}
				}
			}
			catch (IllegalAccessException exception) {
				throw new IOException(exception);
			}
		}
	}

	public void write(final File file, final ChartPainter<?> p) throws IOException {
		try (FS.BufferedFileOutput output = new FS.BufferedFileOutput(file)) {
			write(output, p);
		}
	}

	public void write(final OutputStream output, final ChartPainter<?> p) throws IOException {
		XMLBuilder xml = new XMLBuilder();
		xml.beginTag(
			"chart",
			"version", "1"
		);
		
		if (p != null) {
			try {
				writePainterProperties(xml, p);
			}
			catch (IllegalAccessException exception) {
				throw new IOException(exception);
			}
		}
		
		for (Item i : this) {
			xml.beginTag("item");
				if (i.getValue() != null)
					xml.doubleTag("color", ColorProperty.toString(i.getValue()));
				if (i.getIconPath() != null)
					xml.doubleTag("icon", xml.escape(i.getIconPath()));
				if (i.getText() != null)
					xml.doubleTag("text", xml.escape(i.getText()));
				xml.doubleTag("value", Long.toString(i.getNumber()));
			xml.endTag("item");
		}
		xml.endTag("chart");
		xml.write(output, false);
	}
	
	// protected

	@Override
	protected Item createCopyForUndo(final Item original) {
		return (Item)original.clone();
	}

	// private

	private void writePainterProperties(final XMLBuilder xml, final ChartPainter<?> p) throws IllegalAccessException {
		xml.beginTag("painter");
		for (Map.Entry<Field, Property<?>> i : Property.list(p).entrySet()) {
			Property<?> property = i.getValue();
			xml.singleTag(
				"property",
				"name", i.getKey().getName(),
				"value", property
			);
		}
		xml.endTag("painter");
	}

	// package protected

	String formatText(final String painterFormat, final Item item, final long total) {
		String f = painterFormat;
		if (TK.isEmpty(f))
			f = item.getFormat();
		if (f == null)
			f = format;
		
		if (f == null)
			return item.getText();
		
		Color c = item.getValue();
		if ((c != null) && f.contains("${color}"))
			f = f.replace("${color}", ColorProperty.toDisplayString(c));
		
		long n = item.getNumber();
		if (f.contains("${number}"))
			f = f.replace("${number}", Long.toString(n));
		
		if (f.contains("${percent-float}"))
			f = f.replace("${percent-float}", MFormat.toPercent(((float)n * 100) / (float)total));

		if (f.contains("${percent-int}"))
			f = f.replace("${percent-int}", Math.round(((float)n * 100) / (float)total) + "%");

		if (f.contains("${size-auto}"))
			f = f.replace("${size-auto}", MFormat.toAutoSize(n));

		String t = item.getText();
		if (t != null)
			f = f.replace("${text}", t);
		
		return f;
	}

	long getTotal() {
		long result = 0;
		for (Item i : this)
			result += i.number;
		
		return result;
	}
	
	// public classes

	public static class Item extends org.makagiga.commons.Item<Color> implements Cloneable {
		private static final long serialVersionUID = 5843531592685082836L;

		// private
		
		transient private Color averageCache;
		private Map<String, Object> properties;
		private String format;
		private String iconPath;
		
		// package protected
		
		transient BufferedImage imageCache;
		long number;
		
		// public
		
		public Item() {
			this(null, 0, Color.BLACK, null);
		}
		
		public Item(final String text, final long number, final Color color, final Icon icon) {
			super(color, text);
			this.number = number;
			setIcon(icon);
		}
		
		/**
		 * @since 2.2
		 */
		public String getFormat() { return format; }

		/**
		 * @since 2.2
		 */
		public void setFormat(final String value) { format = value; }

		public String getIconPath() { return iconPath; }
		
		public void setIconPath(final String value) {
			setIcon((value == null) ? null : MIcon.fromFileURI(value, -1));
			iconPath = value;
			
			averageCache = null;
			imageCache = null;
		}
		
		public Image getImage() {
			if (imageCache == null) {
				Icon i = getIcon();
				
				if (i == null)
					return null;
				
				if (i instanceof ImageIcon)
					imageCache = UI.toBufferedImage(ImageIcon.class.cast(i).getImage(), true);
				else
					imageCache = UI.toBufferedImage(i);
			}
			
			return imageCache;
		}
		
		public long getNumber() { return number; }
		
		public void setNumber(final long value) { number = value; }
		
		@SuppressWarnings("unchecked")
		public <T> T getProperty(final String key, final T defaultValue) {
			if (properties == null)
				return defaultValue;
			
			Object result = properties.get(key);
			
			return (result == null) ? defaultValue : (T)result;
		}

		public void setProperty(final String key, final Object value) {
			if (properties == null)
				properties = new HashMap<>();
			
			properties.put(key, value);
		}
		
		// Cloneable

		@Obsolete
		@Override
		public Object clone() {
			try {
				return super.clone();
			}
			catch (CloneNotSupportedException exception) {
				throw new WTFError(exception);
			}
		}
		
		// package
		
		Color getAverageColor() {
			if (averageCache == null) {
				Image image = getImage();
				averageCache = (image instanceof BufferedImage) ? MColor.getAverage((BufferedImage)image, 0) : null;
			}
			
			return (averageCache == null) ? getValue() : averageCache;
		}
		
	}
	
	public static final class Sample extends ChartModel {
		
		// public
		
		public Sample() {
			addItem("Red", 1, Color.RED);
			addItem("Green", 2, Color.GREEN);
			addItem("Blue", 3, Color.BLUE);
		}
		
	}

}
