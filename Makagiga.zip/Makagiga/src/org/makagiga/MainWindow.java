// Copyright 2005 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga;

import static java.awt.event.KeyEvent.*;

import static org.makagiga.commons.UI.i18n;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import javax.script.ScriptException;
import javax.swing.Box;
import javax.swing.JComponent;

// throw new TooManyImportsException()
import org.makagiga.commons.Args;
import org.makagiga.commons.Config;
import org.makagiga.commons.Flags;
import org.makagiga.commons.FS;
import org.makagiga.commons.GeneralSettings;
import org.makagiga.commons.Globals;
import org.makagiga.commons.Kiosk;
import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.MApplication;
import org.makagiga.commons.MArrayList;
import org.makagiga.commons.MColor;
import org.makagiga.commons.MIcon;
import org.makagiga.commons.MLogger;
import org.makagiga.commons.OS;
import org.makagiga.commons.StringList;
import org.makagiga.commons.TK;
import org.makagiga.commons.UI;
import org.makagiga.commons.WTFError;
import org.makagiga.commons.about.MAboutDialog;
import org.makagiga.commons.annotation.DesignPattern;
import org.makagiga.commons.help.Help;
import org.makagiga.commons.help.HelpContext;
import org.makagiga.commons.help.HelpGenerator;
import org.makagiga.commons.help.HelpMenu;
import org.makagiga.commons.mods.Mods;
import org.makagiga.commons.print.PrintDialog;
import org.makagiga.commons.proxy.ProxySettings;
import org.makagiga.commons.script.ScriptExecutor;
import org.makagiga.commons.script.ScriptYourself;
import org.makagiga.commons.swing.Input;
import org.makagiga.commons.swing.MButton;
import org.makagiga.commons.swing.MCellTip;
import org.makagiga.commons.swing.MComponent;
import org.makagiga.commons.swing.MDialog;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MLinkButton;
import org.makagiga.commons.swing.MMainWindow;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMenuBar;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MNotification;
import org.makagiga.commons.swing.MPanel;
import org.makagiga.commons.swing.MSettingsDialog;
import org.makagiga.commons.swing.MSplitPane;
import org.makagiga.commons.swing.MSystemTray;
import org.makagiga.commons.swing.MTimer;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.commons.swing.MWhatsThis;
import org.makagiga.commons.swing.MainView;
import org.makagiga.commons.swing.MouseGestures;
import org.makagiga.commons.swing.border.MLineBorder;
import org.makagiga.commons.swing.event.MMouseAdapter;
import org.makagiga.console.Console;
import org.makagiga.desktop.Desktop;
import org.makagiga.desktop.Widget;
import org.makagiga.editors.AnnotationBar;
import org.makagiga.editors.Designer;
import org.makagiga.editors.DocumentHelp;
import org.makagiga.editors.Editor;
import org.makagiga.editors.EditorDesigner;
import org.makagiga.editors.EditorExport;
import org.makagiga.editors.EditorNavigation;
import org.makagiga.editors.EditorPlugin;
import org.makagiga.editors.EditorPrint;
import org.makagiga.editors.EditorQuickFind;
import org.makagiga.editors.EditorSearch;
import org.makagiga.editors.EditorZoom;
import org.makagiga.editors.NavigationUtils;
import org.makagiga.editors.todo.TodoEditorPlugin;
import org.makagiga.fs.AbstractFS;
import org.makagiga.fs.FSException;
import org.makagiga.fs.MetaInfo;
import org.makagiga.fs.tree.TreeFS;
import org.makagiga.plugins.ArmorSettings;
import org.makagiga.plugins.LookAndFeelSettings;
import org.makagiga.plugins.Plugin;
import org.makagiga.plugins.PluginInfo;
import org.makagiga.plugins.PluginManager;
import org.makagiga.plugins.PluginMenu;
import org.makagiga.plugins.PluginSettings;
import org.makagiga.plugins.PluginType;
import org.makagiga.tabs.CalendarTab;
import org.makagiga.tabs.ConsoleTab;
import org.makagiga.tabs.DesktopTab;
import org.makagiga.tabs.PluginSettingsTab;
import org.makagiga.tabs.WebBrowserTab;
import org.makagiga.tags.TagsMenu;
import org.makagiga.todo.Task;
import org.makagiga.tools.Autosave;
import org.makagiga.tools.BookmarksMenu;
import org.makagiga.tools.DocumentListButton;
import org.makagiga.tools.SessionManager;
import org.makagiga.tools.summary.SummaryData;
import org.makagiga.tools.summary.TasksMenu;
import org.makagiga.tools.summary.TasksSettings;
import org.makagiga.tree.ImportExport;
import org.makagiga.tree.LocationBar;
import org.makagiga.tree.PropertiesBar;
import org.makagiga.tree.PropertiesPanel;
import org.makagiga.tree.SearchBar;
import org.makagiga.tree.Tree;
import org.makagiga.tree.TreePanel;
import org.makagiga.tree.tracker.Tracker;
import org.makagiga.web.wiki.WikiPanel;

/** The main window. */
@DesignPattern(DesignPattern.SINGLETON)
public final class MainWindow extends MMainWindow {

	// public

	/**
	 * @since 4.2
	 */
	public static final String ALTERNATE_LAYOUT_PROPERTY = "org.makagiga.MainWindow.ALTERNATE_LAYOUT_PROPERTY";

	// private

	private BookmarksMenu bookmarksMenu;
	private static boolean presentationActive;
	private final DesktopTab desktopTab;
	private final DocumentListButton documentList;
	private Editor<?> lastTab;
	private int viewMenuItemCount;
	private JComponent tabBar;
	private static MainWindow _instance;
	private Map<String, Object> elements;
	private MMenu editMenu;
	private MMenu exportMenu;
	private MMenu fileMenu;
	private MMenu helpMenu;
	private MMenu importMenu;
	private MMenu tagsMenu;
	private MMenu toolsMenu;
	private MMenu viewMenu;
	private final MPanel tabPanel;
	private final MSplitPane mainSplitPane;
	private final MToolBar editorToolBar;
	private final Object updateComponentsLock = new Object();
	private final Object updateStateLock = new Object();

	// private actions
	// file
	private PrintAction printAction;
	// edit
	private FindAction findAction;
	private FindNextAction findNextAction;
	private FindPreviousAction findPreviousAction;
	// view
	private ToggleSummaryAction toggleSummaryAction;
	private ToggleDesignerAction toggleDesignerAction;
	private ToggleDesktopAction toggleDesktopAction;
	private ShowHideSidebarAction showHideSidebarAction;
	private ShowHideLocationBarAction showHideLocationBarAction;
	private ShowHidePropertiesBarAction showHidePropertiesBarAction;
	private ZoomInAction zoomInAction;
	private ZoomOutAction zoomOutAction;
	private ZoomResetAction zoomResetAction;
	// tools
	private SearchBar.Action searchAction;
	private Console.Action consoleAction;
	private ConfigureAction configureAction;
	// help
	private HelpAction helpAction;

	// public
	
	/**
	 * @since 3.8.8
	 */
	public Desktop getDesktop() {
		return desktopTab.getCore();
	}
	
	public Object getElementById(final String id) {
		if (elements == null) {
			elements = TK.newHashMap(
				// menus
				"file-menu", fileMenu,
					"import-menu", importMenu,
					"export-menu", exportMenu,
				"edit-menu", editMenu,
				"view-menu", viewMenu,
				"bookmarks-menu", bookmarksMenu,
				"tags-menu", tagsMenu,
				"tools-menu", toolsMenu,
				"help-menu", helpMenu,

				// misc
				"editor-tool-bar", editorToolBar,
				"main-split-pane", mainSplitPane,
				"tab-panel", tabPanel,

				// actions
				"previous-action", NavigationUtils.getPreviousAction(),
				"next-action", NavigationUtils.getNextAction()
			);
		}

		return elements.get(id);
	}

	public synchronized static MainWindow getInstance() {
		if (_instance == null)
			new MainWindow(); // set "_instance" in constructor

		return _instance;
	}

	/**
	 * @since 4.0
	 */
	public static Plugin<?> getPresentationPlugin() {
		PluginInfo info = PluginManager.getInstance().getByID("{e5508e4c-e070-4d4a-a2de-e9ef754a4656}");
		
		return (info == null) ? null : info.getPlugin();
	}

	/**
	 * @since 2.0
	 */
	public void installTabBar(final JComponent c) {
		if (c != null)
			c.setVisible(true);
		MComponent.replace(tabPanel, tabBar, c, BorderLayout.PAGE_END, true);
		tabBar = c;
	}

	public boolean isDesktopVisible() {
		return (desktopTab != null) && desktopTab.isTabSelected();
	}

	public void setDesktopVisible(final boolean desktopVisible) {
		Tabs tabs = Tabs.getInstance();

		Editor<?> newTab;
		if (desktopVisible) {
			Editor<?> currentTab = tabs.getSelectedTab();
			if (currentTab != desktopTab)
				lastTab = currentTab;
			newTab = desktopTab;
		}
		else {
			newTab = lastTab;
			if (
				((newTab == null) || (tabs.indexOfComponent(newTab) == -1)) &&
				(tabs.getTabCount() > 1)
			) {
				newTab = tabs.getTabAt(1);
			}
		}
		tabs.selectEditor(newTab);
		
		// focus selected widget
		if (tabs.getTabCount() == 1) {
			Editor<?> currentTab = tabs.getSelectedTab();
			if (currentTab == desktopTab)
				desktopTab.focus();
		}
	}
	
	public static boolean isInstance() {
		return _instance != null;
	}
	
	/**
	 * @since 4.0
	 */
	public static boolean isPresentationActive() { return presentationActive; }

	@Override
	public boolean onTrayIconClick(final MouseEvent e) {
		if (MMouseAdapter.isMiddle(e)) {
			ImportExport.importClipboard();

			return true;
		}

		return false;
	}

	@Override
	public void onTrayIconMenuPopup(final MMenu menu) {
		TasksMenu.update(menu);
		menu.addSeparator(false);

		// HACK: <MAction> - workaround for
		// "both method add(MAction) in MMenu and method add(String) in MMenu match"
		// compile error in JDK 8 (b78).
		// JAVA BUG: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=8024934
		menu.add(TreePanel.getInstance().getActionGroup().<MAction>getAction("quick-paste"));

		menu.add(TodoEditorPlugin.createAddTaskMenu(Task.empty()));
		menu.add(new BookmarksMenu(MIcon.small("ui/bookmark"), false));
		PluginManager.updateMenu(menu, PluginMenu.TRAY_MENU, false);
	}

	public synchronized void saveSession(final int flags) {
		// too verbose with autosave: MLogger.info("makagiga", "Saving session...");

		Config config = Config.getDefault();
		
		// splitter
		config.write(Config.getScreenKey("Splitter.Main.location"), mainSplitPane.getDividerLocation());

		// view
		config.write("PropertiesBar.enabled", showHidePropertiesBarAction.isSelected());

		PropertiesBar.sync();
		Tabs.getInstance().saveAllEditors(flags);
		Tree.getInstance().saveAllItems();
		SessionManager.save();
		
		getDesktop().saveSession(config);
		
		config.sync();
	}
	
	@Override
	public void setLocked(final boolean locked) {
		super.setLocked(locked);
		updateTitle();
	}
	
	/**
	 * @since 1.2
	 */
	public void showProperties(final MetaInfo... selection) {
		PropertiesPanel.showDialog(this, selection);
	}
	
	public static void showSidebar() {
		showSidebar(null, false);
	}

	/**
	 * @since 2.0
	 */
	public static void showSidebar(final Sidebar.Tab tab, final boolean toggle) {
		MainWindow mainWindow = getInstance();
		Sidebar.show(tab, toggle, mainWindow.mainSplitPane);
	}
	
	/**
	 * @since 2.0
	 */
	public static void showTree(final MetaInfo selection) {
		showSidebar();
		
		// false - do not change item selection
		Sidebar.getInstance().goTo(Sidebar.Tab.TREE, false);

		if (selection != null) {
			Tree tree = Tree.getInstance();
			tree.focusItem(selection);
		}
	}

	/**
	 * @since 3.8.4
	 */
	public void showWidget(final Widget widget, final boolean restoreWindow) {
		if (restoreWindow)
			restore();
		setDesktopVisible(true);

		Desktop desktop = getDesktop();
		desktop.getPager().setCurrent(widget.getDesktopNumber());

		widget.select();
	}
	
	/**
	 * @since 1.2
	 */
	@SuppressWarnings("deprecation")
	public void updateComponents(final MetaInfo... metaInfos) {
		synchronized (updateComponentsLock) { // do not use "this"
			final Tabs tabs = Tabs.getInstance();

			if (metaInfos != null) {
				Editor<?> currentTab = tabs.getSelectedTab();
				Editor<?> editor;
				for (MetaInfo i : metaInfos) {
					if (i.isFile() || i.isVirtualFile()) {
						tabs.setTabInfo(i);
						editor = tabs.getTabAt(i);
						if (editor != null) {
							boolean readOnly = !i.canModify();
							editor.setLocked(readOnly);
							if (editor instanceof EditorDesigner<?>)
								EditorDesigner.class.cast(editor).getEditorDesigner().setLocked(readOnly);
							editor.updateActions();
						}
					}
				}

				// update location bar
				if (currentTab != null)
					LocationBar.getInstance().update(currentTab.getMetaInfo());
			}

			updateTitle();
			TreePanel.getInstance().updateActions();
		}
		if (!TK.isEmpty(metaInfos)) {
			for (MetaInfo i : metaInfos)
				i.refresh(true);
		}
	}
	
	/**
	 * @since 4.8
	 */
	public void updateZoomControls(final EditorZoom editorZoom) {
		if (zoomInAction != null)
			zoomInAction.setEnabled(editorZoom.isZoomEnabled(EditorZoom.ZoomType.IN));
		if (zoomOutAction != null)
			zoomOutAction.setEnabled(editorZoom.isZoomEnabled(EditorZoom.ZoomType.OUT));
		
		if ((zoomInAction != null) && (zoomOutAction != null) && (zoomResetAction != null))
			zoomResetAction.setEnabled(zoomInAction.isEnabled() || zoomOutAction.isEnabled());
	}

	// protected
	
	@Override
	protected void onMinimize() {
		saveSession(Tabs.NORMAL_SAVE);
	}

	// private

	private MainWindow() {
		if (_instance != null)
			throw new WTFError("org.makagiga.MainWindow already created");
		
		_instance = this;
		
		// init components
		final Tabs tabs = Tabs.getInstance();
		final Sidebar sidebar = Sidebar.getInstance();

		PluginManager.Table table = PluginManager.getTable();
		
		documentList = new DocumentListButton();
		
		initActions();
		initMenuBar(table);

		// main split pane
		mainSplitPane = new MSplitPane();
		mainSplitPane.setSidebar(sidebar);
		
		// editor tool bar

		editorToolBar = new MToolBar();
		editorToolBar.setID("editor");
		MWhatsThis.set(editorToolBar, i18n("Tab Tool Bar\nEach tab has its own tool bar"));

		// editor panel
		tabPanel = new MPanel() {
			@Override
			public void updateUI() {
				super.updateUI();
				if (UI.isMetal())
					this.setBackground(MColor.WHITE);
			}
		};
		tabPanel.addCenter(tabs);
		
		// tree tool bar
		TreePanel treePanel = TreePanel.getInstance();
		PluginManager.updateToolBar(table, treePanel.getToolBar(), PluginMenu.TREE_TOOL_BAR, false);

		// main panel
		desktopTab = new DesktopTab(new Desktop());
		tabs.addEditor(desktopTab);
		
		mainSplitPane.setRightComponent(tabPanel);
		addCenter(mainSplitPane);

		// before restoreSession()
		Mods.replace(Console.MOD_CLOSE_CONSOLE, (source, command, args) -> {
			if (source instanceof Console) {
				ConsoleTab tab = tabs.findEditor(ConsoleTab.class);
				if (tab != null)
					tabs.closeEditorAt(tabs.findEditor(tab.getMetaInfo()), Tabs.REMOVE_TAB);

				return true;
			}

			return false;
		} );
		Mods.replace(Console.MOD_SHOW_CONSOLE, (source, command, args) -> {
			if (source instanceof Console) {
				ConsoleTab tab = tabs.findEditor(ConsoleTab.class);
				if (tab != null)
					tabs.selectEditor(tab);
				else
					tabs.addEditor(new ConsoleTab((Console)source));

				return true;
			}

			return false;
		} );

// FIXME: Login plugin: Do not show any file password dialogs before main window lock
// TODO: load tab content on demand
		restoreSession();

		ScriptException userScriptError = null;
		try {
			ScriptExecutor.executeUserScript();
		}
		catch (ScriptException exception) {
			userScriptError = exception;
		}

		final boolean autostart = Args.isSet("autostart");

		// add tab change event handler
		tabs.addChangeListener(e -> updateState());

		Autosave.init();
		
		setMouseGestures(new CustomMouseGestures());

		// ensure the system tray icon background is set
		UI.systemTray.addChangeListener((e, visible) -> {
			if (visible)
				MSystemTray.setBackground(MApplication.getLightBrandColor());
		} );

		if (autostart && !UI.systemTray.booleanValue()) {
			setState(ICONIFIED);
			setVisible(true);
		}

		if (userScriptError != null)
			ScriptExecutor.showErrorNotification(userScriptError, "scripts/user.js");

		Plugin<?> presentation = getPresentationPlugin();
		if (presentation != null) {
			presentation.addPropertyChangeListener(e -> {
				if (
					"active".equals(e.getPropertyName()) &&
					(e.getNewValue() instanceof Boolean)
				) {
					presentationActive = Boolean.TRUE.equals(e.getNewValue());
				}
			} );
		}

		PluginManager.postInit();
		
		// after PluginManager.postInit()

		// HACK: disable focus stealing on first window show (for slower configurations)
		if (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - Main.startTime) >= 20)
			setAutoRequestFocus(false);

		if (!autostart) {
			if (Args.isSet("full-screen"))
				setFullScreen(true);

			setVisible(true);
		}

		// after setVisible(true)
		
		setAutoRequestFocus(true); // restore default
		
		// select last tab/editor
		if (tabs.getTabCount() > 1)
			tabs.selectEditorAt(tabs.findEditor(SessionManager.getCurrentItem()));
		
		updateState();

		if (tabs.getTabCount() == 1)
			Tree.getInstance().requestFocusInWindow();

		Tracker.addTrackerListener(SummaryData.getInstance());
		Tracker.startScheduler();
		
		Mods.add(Globals.MOD_ABOUT_INIT_CREDITS, (source, command, args) -> {
			if (source instanceof MAboutDialog) {
				MAboutDialog aboutDialog = (MAboutDialog)source;
				aboutDialog.addCredit("Thotheolh", "Coding, Testing, Ideas...", "http://sourceforge.net/users/thotheolh");
				aboutDialog.addCredit("Dewitte Pierre-Alban", "Various PIM improvements", null);
				aboutDialog.addCredit("M. Korbar", "German Translation, Ideas, Testing", null);
			}

			return null;
		} );

		Mods.replace(Globals.MOD_WIKI_SHOW_PANEL,
			(source, command, args) -> {
				if ((args.length == 1) && (args[0] instanceof URI)) {
					URI pageURI = (URI)args[0];
					String wikiID = WikiPanel.class.getName();
					WebBrowserTab tab = tabs.findByID(wikiID);
					if (tab != null) {
						tab.getWebBrowser().setDocumentLocation(pageURI);
						tabs.selectEditor(tab);
					}
					else {
						tab = new WebBrowserTab(new WikiPanel(pageURI)) {
							@Override
							public void updateToolBar(final String type, final MToolBar toolBar) {
								super.updateToolBar(type, toolBar);
								if (type.equals(EDITOR_TOOL_BAR)) {
									WikiPanel wikiPanel = (WikiPanel)this.getCore();
									wikiPanel.addToolBarComponents(toolBar);
								}
							}
						};
						tab.putClientProperty(WebBrowserTab.ID_PROPERTY, wikiID);
						tabs.addEditor(tab);
					}

					return true;
				}

				return false;
			}
		);

		//MClipboard.setHistoryEnabled(true);
		
		// TEST: throw new RuntimeException("Najlepsze na kaca jest powietrze z dmuchanego materaca");

		// Defer system tray initialization.
		// - On some systems it may be slow (~1s)
		// - It displays ugly gray background if EDT is blocked
		if (UI.systemTray.booleanValue()) {
			MTimer.seconds(2, timer -> {
				MSystemTray.setBackground(MApplication.getLightBrandColor());
				MSystemTray.setVisible(true);

				// HACK: no system tray support; show minimized window instead of icon
				if (autostart && (MSystemTray.getIcon() == null)) {
					setState(ICONIFIED);
					setVisible(true);
				}

				return MTimer.STOP;
			} ).start();
		}
	}

	private void initActions() {
		// file
		printAction = new PrintAction();
		// edit
		findAction = new FindAction();
		// view
		toggleSummaryAction = new ToggleSummaryAction();
		toggleDesignerAction = new ToggleDesignerAction();
		toggleDesktopAction = new ToggleDesktopAction();
		showHideSidebarAction = new ShowHideSidebarAction();
		showHideLocationBarAction = new ShowHideLocationBarAction();
		showHidePropertiesBarAction = new ShowHidePropertiesBarAction();
		// tools
		searchAction = new SearchBar.Action();
		consoleAction = new Console.Action();
		configureAction = new ConfigureAction();
		// help
		helpAction = new HelpAction();

		// key bindings for actions outside menu bar
		Tabs tabs = Tabs.getInstance();
		MainView.bind(
			searchAction,
			toggleDesignerAction,
			toggleDesktopAction,
			toggleSummaryAction,
			NavigationUtils.getPreviousAction(),
			NavigationUtils.getNextAction(),
			tabs.getCloseAllAction(),
			tabs.getCloseAction()
		);
	}
	
	private void initExportMenu() {
		Editor<?> editor = Tabs.getInstance().getSelectedTab();
		if ((editor != null) && (editor.getPluginInfo() != null)) {
			exportMenu.addTitle(i18n("Export \"{0}\"", editor.getMetaInfo()));
			// add plugin export types
			if (editor instanceof EditorExport) {
				EditorPlugin plugin = (EditorPlugin)editor.getPluginInfo().getPlugin();
				List<EditorPlugin.FileType> types = plugin.getExportTypes();
				if (!types.isEmpty()) {
					for (EditorPlugin.FileType i : types)
						exportMenu.add(new ImportExport.ExportAction(i));
					exportMenu.addSeparator();
				}
				exportMenu.add(new ImportExport.ExportAction(new EditorPlugin.FileType("png", i18n("Document screenshot"), "image/png", true)));
			}
			else {
				exportMenu.addTitle(i18n("Export is not supported"), "ui/info");
			}
		}
		MetaInfo currentFolder = Tree.getInstance().getCurrentFolder(false);
		AbstractFS currentFS = currentFolder.getFS();
		if (currentFS instanceof PluginMenu)
			PluginMenu.class.cast(currentFS).updateMenu(PluginMenu.EXPORT_MENU, exportMenu);
		
		if (exportMenu.isEmpty())
			exportMenu.addTitle(i18n("Open or select a tab you want to export"), "ui/info");
	}

	private void initMenuBar(final PluginManager.Table plugins) {
		MMenuBar menuBar = new MMenuBar();
		MWhatsThis.set(menuBar, i18n("Main Menu"))
			.setKeyStroke(VK_F10);

		// file menu
		fileMenu = new MMenu(i18n("&File"));

		MAction saveAction = new MAction(
			MActionInfo.SAVE.withText(MActionInfo.SAVE + " (" + i18n("autosave enabled") + ')'),
			self -> saveSession(Tabs.NORMAL_SAVE)
		);
		fileMenu.add(saveAction);

		PluginManager.updateMenu(plugins, fileMenu, PluginMenu.FILE_MENU, true);
		importMenu = new ImportMenu();

		exportMenu = new MMenu(i18n("Export"));
		exportMenu.setAutoRemoveAll(true);
		UI.setHTMLHelp(exportMenu, i18n("Exports the content of the active document.<br>For example, you can save a \"todo\" table in the HTML format."));
		exportMenu.onSelect(menu -> initExportMenu());
		if (!Kiosk.actionExport.get())
			exportMenu.setEnabled(false);

		fileMenu.add(importMenu);
		fileMenu.add(exportMenu);

		fileMenu.add(printAction);
		
		fileMenu.addSeparator();
		
		fileMenu.addCheckBox(new MApplication.ToggleOfflineAction());
		MApplication.offline.addChangeListener((e, offline) -> updateTitle());

		MAction quitAction = MApplication.getQuitAction();
		quitAction.setHTMLHelp(i18n("Quits the application.<br>All the modified files are saved automatically."));
		if (Kiosk.actionQuit.get())
			fileMenu.add(quitAction);
		menuBar.add(fileMenu);

		// edit menu (used by editor plugins)
		editMenu = new MMenu(i18n("&Edit"));
		editMenu.onSelect(self -> updateEditMenu(Tabs.getInstance().getSelectedTab()));
		menuBar.add(editMenu);

		// view menu (used by editor plugins)
		viewMenu = new MMenu(i18n("&View"));

		MMenu toolBarsMenu = new MMenu(i18n("Tool Bars"));
		if (!Kiosk.toolBarLocked.get()) {
			toolBarsMenu.addCheckBox(showHideLocationBarAction);
			toolBarsMenu.addCheckBox(showHidePropertiesBarAction);
			toolBarsMenu.addSeparator();
		}
		toolBarsMenu.add(showHideSidebarAction);
		viewMenu.add(toolBarsMenu);
		viewMenu.add(MNotification.createMenu());
		viewMenu.add(toggleDesktopAction);

		if (Kiosk.actionFullScreen.get())
			viewMenu.add(new MApplication.FullScreenAction());
		PluginManager.updateMenu(plugins, viewMenu, PluginMenu.VIEW_MENU_ALL, false);
		viewMenuItemCount = viewMenu.getItemCount();
		menuBar.add(viewMenu);

		// bookmarks menu
		bookmarksMenu = new BookmarksMenu(null, true);
		menuBar.add(bookmarksMenu);

		// tags menu
		tagsMenu = new TagsMenu();
		menuBar.add(tagsMenu);

		// tools menu
		toolsMenu = new MMenu(i18n("&Tools"));
		if (Kiosk.consoleEnabled.get()) {
			toolsMenu.add(consoleAction);
		}
		if (Main.isTodoPluginEnabled())
			toolsMenu.add(new CalendarTab.Action());
		PluginManager.updateMenu(plugins, toolsMenu, PluginMenu.TOOLS_MENU, false);

		toolsMenu.addSeparator();

		if (Kiosk.pluginManager.get())
			toolsMenu.add(new PluginSettingsAction());

		toolsMenu.add(configureAction);

		menuBar.add(toolsMenu);
		
		helpMenu = new HelpMenu() {
			@Override
			protected void onInit() {
				this.add(helpAction);
				this.addSeparator();
				PluginManager.updateMenu(plugins, this, PluginMenu.HELP_MENU, true);
			}
			@Override
			protected void onInitTopics(final MMenu topics) {
				topics.addSeparator(i18n("How-To"));

				topics.add(new HelpMenu.HowToAction(i18n("Change the default web browser"), "ui/internet", new StringList(i18n("Main Menu"), i18n("Tools"), i18n("Settings"), i18n("General"))) {
					@Override
					public void onAction() {
						new GeneralSettings().exec(this.getSourceWindow());
					}
				} )
					.setEnabled(!OS.isWindows() && Kiosk.actionSettings.get());

				topics.add(new HelpMenu.HowToAction(i18n("Disable unused plugins"), "ui/plugin", new StringList(i18n("Main Menu"), i18n("Tools"), i18n("Plugins"), i18n("Tool Bar"), i18n("Disable"))) {
					@Override
					public void onAction() {
						PluginSettingsTab.getInstance();
					}
				} );
				
				topics.addSeparator("FAQ");
				
				// NOTE: based on OS.getSummary
				topics.add(new MAction("Where are my files and data?", "ui/folder", action -> {
					MDialog dialog = new MDialog(action.getSourceWindow(), action.getName(), action.getIcon(), MDialog.SIMPLE_DIALOG | MDialog.HEADER_BAR);
					dialog.getMainPanel().setGroupLayout(true)
						.beginRows();

					dialog.getMainPanel().getGroupLayout()
						.addHeader(i18n("Folders:"))
						.addComponent(new MLinkButton(FS.getConfigPath().toUri(), i18n("{0}: Settings and Data", MApplication.getFullName())));

					if (!OS.isWebStart()) {
						dialog.getMainPanel().getGroupLayout()
							.addComponent(new MLinkButton(FS.getBasePath().toUri(), i18n("Install Directory")));
					}
						
					dialog.getMainPanel().getGroupLayout()
						.addHeader(i18n("Tree"))
						.addComponent(new MLabel("Context menu -> " + MActionInfo.BROWSE))
						.addHeader(i18n("Tabs"))
						.addComponent(new MLabel("Context menu -> " + i18n("Copy File Path")))
					.end();

					dialog.packFixed();
					dialog.exec();
				} ));
				
				topics.add(new MAction("What means \"Makagiga\"?", MApplication.getSmallIcon(),
					action -> MMessage.info(action.getSourceWindow(), "\"Makagiga\" is a kind of cake made with caramel, honey, poppy, nuts... ;-)")
				));
			}
		};
		menuBar.add(helpMenu);

		if (!UI.isQuaqua()) {
			menuBar.add(LocationBar.getInstance());
			menuBar.add(Box.createHorizontalGlue());
			menuBar.add(documentList);
		}
		
		if (Args.isSet("no-security-manager")) {
			MLabel smWarning = new MLabel();
			smWarning.setIcon(MIcon.small("ui/security-low"));
			smWarning.setToolTipText(i18n("No Security Manager"));
			menuBar.add(smWarning);
		}
		
		if (!Kiosk.mainWindowShowMenuBar.get())
			menuBar.setMinimized(true);
		
		setJMenuBar(menuBar);
	}

	private void resetEditorZoom() {
		Editor<?> editor = Tabs.getInstance().getSelectedTab();
		if (editor instanceof EditorZoom) {
			EditorZoom editorZoom = (EditorZoom)editor;
			try {
				editorZoom.resetZoom();
				updateZoomControls(editorZoom);
			}
			catch (AbstractMethodError error) {
				TK.beep();
				MLogger.developerException(error);
				MLogger.error("core", "Zoom reset not supported");
			}
		}
	}

	private void restoreSession() {
		Config config = Config.getDefault();

		// splitter
		int dividerLocation = config.readInt(Config.getScreenKey("Splitter.Main.location"), 250);
		mainSplitPane.setDividerLocation(dividerLocation);
		mainSplitPane.setSidebarVisible((dividerLocation == -1) || mainSplitPane.isSidebarVisible());

		// view
		showHideLocationBarAction.setSelected(Vars.treeLocationBarVisible.get());
		showHidePropertiesBarAction.setSelected(config.read("PropertiesBar.enabled", true));

		// reopen last files, expand tree, etc.
		SessionManager.restore();

		getDesktop().restoreSession(config, 0);
	}
	
	private void updateEditMenu(final Editor<?> editor) {
		editMenu.removeAll();
		
		// add editor actions
		if (editor != null) {
			if (editor instanceof PluginMenu) {
				PluginMenu pluginMenu = (PluginMenu)editor;
				pluginMenu.updateMenu(PluginMenu.EDIT_MENU, editMenu);
			}

			PluginManager.updateMenu(editMenu, PluginMenu.EDIT_MENU_TAB, false);

			if (editor instanceof EditorSearch) {
				int searchOptions = EditorSearch.class.cast(editor).getSupportedSearchOptions();
				boolean isSearch = (searchOptions & EditorSearch.NO_SEARCH) == 0;
				
				findAction.setEnabled(isSearch);

				if (findNextAction == null)
					findNextAction = new FindNextAction();
				findNextAction.setEnabled(isSearch);

				if (findPreviousAction == null)
					findPreviousAction = new FindPreviousAction();
				boolean findPreviousSupported = (searchOptions & EditorSearch.FIND_PREVIOUS) != 0;
				findPreviousAction.setEnabled(isSearch && findPreviousSupported);
				
				if (isSearch) {
					editMenu.addSeparator(false);
					editMenu.add(findAction);
					editMenu.add(findNextAction);
					editMenu.add(findPreviousAction);
				}
			}
			else {
				findAction.setEnabled(false);
				if (findNextAction != null)
					findNextAction.setEnabled(false);
				if (findPreviousAction != null)
					findPreviousAction.setEnabled(false);
			}
		}

		editMenu.addNoItemsInfo(editMenu.isEmpty());
	}
	
	/**
	 * @since 4.0
	 */
	public void updateState() {
		synchronized (updateStateLock) { // do not use "this"
			Tabs tabs = Tabs.getInstance();
		
			if (tabs.removingTab)
				return;

			Designer designer = null;

			viewMenu.removeFrom(viewMenuItemCount);

			// update tree and tabs
			tabs.updateState();
			MetaInfo metaInfo = tabs.getCurrentMetaInfo();
			//Tree.getInstance().focusItem(metaInfo);

			// update editor
			Editor<?> editor = tabs.getSelectedTab();
			PluginMenu editorPluginMenu = (editor instanceof PluginMenu) ? (PluginMenu)editor : null;
			
			// update previous/next action
			NavigationUtils.updateActions(editor, metaInfo);
			if (editor != null) {
				// update location bar
				final LocationBar locationBar = LocationBar.getInstance();
				locationBar.update(metaInfo);
				locationBar.setVisible(true);
				
				// update view menu
				JComponent tabTitle = viewMenu.addSeparator(i18n("Current Tab"));
				int tabTitleCount = viewMenu.getItemCount();

				PluginManager.updateMenu(viewMenu, PluginMenu.VIEW_MENU_TAB, false);

				// navigation
				if (editor instanceof EditorNavigation) {
					EditorNavigation en = (EditorNavigation)editor;
					if ((en.getNavigationCapabilities() & EditorNavigation.NAVIGATION_MENU) != 0) {
						viewMenu.add(NavigationUtils.getPreviousAction());
						viewMenu.add(NavigationUtils.getNextAction());
					}
				}

				// zoom
				if (editor instanceof EditorZoom) {
					EditorZoom editorZoom = (EditorZoom)editor;
					
					if (zoomInAction == null)
						zoomInAction = new ZoomInAction();
					viewMenu.add(zoomInAction);
					
					if (zoomOutAction == null)
						zoomOutAction = new ZoomOutAction();
					viewMenu.add(zoomOutAction);

					if (zoomResetAction == null)
						zoomResetAction = new ZoomResetAction();
					viewMenu.add(zoomResetAction);
					
					updateZoomControls(editorZoom);
				}

				if (editorPluginMenu != null)
					PluginManager.updateMenu(editorPluginMenu, viewMenu, PluginMenu.VIEW_MENU_EDITOR, false);
				
				// hide unused title
				if (viewMenu.getItemCount() == tabTitleCount)
					tabTitle.setVisible(false);
				
				// update editor designer
				if (editor instanceof EditorDesigner<?>) {
					designer = EditorDesigner.class.cast(editor).getEditorDesigner();
					EditorDesigner.class.cast(editor).updateEditorDesigner();
				}

				// update editor tool bar
				editorToolBar.removeAll();
				editorToolBar.setTextPosition(editor.getPreferredToolBarTextPosition());
				editorToolBar.putClientProperty(ScriptYourself.CONTEXT_PROPERTY, editor.getClass().getName());

				MPanel editorToolBarContainer;
				if (editor.getLayout() instanceof BorderLayout)
					editorToolBarContainer = editor;
				else
					editorToolBarContainer = tabPanel;

				editorToolBar.setOpaque(editorToolBarContainer == editor);

				Container oldEditorToolBarContainer = editorToolBar.getParent();
				if (oldEditorToolBarContainer != editorToolBarContainer) {
					if (oldEditorToolBarContainer != null) {
						oldEditorToolBarContainer.remove(editorToolBar);
						oldEditorToolBarContainer.validate();
					}
					editorToolBarContainer.add(editorToolBar, BorderLayout.PAGE_START);
					editorToolBarContainer.validate();
				}

				if (editorToolBarContainer == editor) {
					editorToolBar.showLineBorder(MLineBorder.Position.BOTTOM);
				}
				else {
					editorToolBar.setBorder(null);
					editorToolBar.setBorderPainted(false);
				}

				printAction.setEnabled(editor instanceof EditorPrint);

				if (editorPluginMenu != null)
					editorPluginMenu.updateToolBar(PluginMenu.EDITOR_TOOL_BAR, editorToolBar);
				PluginManager.updateToolBar(editorToolBar, PluginMenu.EDITOR_TOOL_BAR, false);
				ScriptYourself.install(editorToolBar);

				editorToolBar.addStretch();

				// navigation

				if (editor instanceof EditorNavigation) {
					EditorNavigation en = (EditorNavigation)editor;
					if ((en.getNavigationCapabilities() & EditorNavigation.NAVIGATION_TOOL_BAR) != 0) {
						JComponent navigationComponent = en.getNavigationComponent();
						if (navigationComponent != null) {
							editorToolBar.add(navigationComponent);
							editorToolBar.addGap();
						}
						editorToolBar.add(NavigationUtils.getPreviousAction());
						editorToolBar.add(NavigationUtils.getNextAction(), MToolBar.SHOW_TEXT);
						editorToolBar.addStretch();
					}
				}

				if (editorPluginMenu != null)
					editorPluginMenu.updateToolBar(PluginMenu.EDITOR_TOOL_BAR_END, editorToolBar);
				PluginManager.updateToolBar(editorToolBar, PluginMenu.EDITOR_TOOL_BAR_END, false);

				// help

				helpAction.updateProperties(editor);
				if (editor instanceof DocumentHelp) {
					editorToolBar.addGap();
					editorToolBar.add(helpAction, MToolBar.NO_TEXT);
				}

				// zoom controls
				
				if ((editor instanceof EditorZoom) && Kiosk.actionZoom.get()) {
					JComponent zoomComponent = EditorZoom.class.cast(editor).getZoomComponent();
					if (zoomComponent != null) {
						editorToolBar.addGap();
						editorToolBar.add(zoomComponent);
					}
					editorToolBar.addGap();
					editorToolBar.addButton(new MButton(zoomInAction), MToolBar.NO_TEXT);
					editorToolBar.addButton(new MButton(zoomOutAction), MToolBar.NO_TEXT);
				}

				editorToolBar.setVisible(!isPresentationActive() || (editor == desktopTab));
				editorToolBar.validate();
				editorToolBar.repaint();

				// update actions
				editor.updateActions();
			}

			updateEditMenu(editor);
			updateTabBar(editor);
			
			// update meta info
			PropertiesBar pb = PropertiesBar.getInstance();
			pb.setMetaInfo(metaInfo);
			pb.showOrHide(showHidePropertiesBarAction.isSelected());
			AnnotationBar.getInstance().setEditor(editor);

			Sidebar.getInstance().update(editor, designer, toggleDesignerAction);
			updateTitle();
			
			MCellTip.getInstance().setVisible(false);

			if (editor != null)
				MComponent.requestFocus(editor);
		}
	}
	
	private void updateTabBar(final Editor<?> editor) {
		if (editor == null) {
			installTabBar(null);
		}
		else {
			if (
				(editor instanceof EditorSearch) &&
				EditorQuickFind.isInstance() &&
				(tabBar == EditorQuickFind.getInstance())
			) {
				installTabBar(EditorQuickFind.getInstance());
				EditorQuickFind.getInstance().updateComponents();
			}
			// Widgets tab, etc.
			else if (editor.getMetaInfo().isDummy()) {
				installTabBar(null);
			}
			else {
				PropertiesBar pb = PropertiesBar.getInstance();
				if (showHidePropertiesBarAction.isSelected()) {
					installTabBar(pb);
					pb.showOrHide(true);
				}
				else {
					installTabBar(null);
					pb.setVisible(false);
				}
			}
		}
	}

	/**
	 * @since 4.0
	 */
	public void updateTitle() { // public
		if (isLocked()) {
			// do not show document name in locked window
			updateTitle(null);
		}
		else {
			MetaInfo metaInfo = Tabs.getInstance().getCurrentMetaInfo();
			updateTitle(Objects.toString(metaInfo, null));
		}
	}
	
	private void zoomEditor(final EditorZoom.ZoomType type) {
		Editor<?> editor = Tabs.getInstance().getSelectedTab();
		if (editor instanceof EditorZoom) {
			EditorZoom editorZoom = (EditorZoom)editor;
			editorZoom.zoom(type);
			updateZoomControls(editorZoom);
		}
	}

	// public classes

	/**
	 * @since 3.8.11
	 */
	public static final class ImportMenu extends MMenu {

		// public

		public ImportMenu() {
			// HACK: do not use IMPORT icon
			super(MActionInfo.IMPORT.getText());
			setAutoRemoveAll(true);
			setToolTipText(UI.makeHTML(i18n("Tip: You can use drag and drop to import/export files.")));
			if (Vars.treeReadOnly.get())
				setEnabled(false);
		}

		// protected

		@Override
		protected void onSelect() {
			MetaInfo currentFolder = Tree.getInstance().getCurrentFolder(false);

			AbstractFS currentFS = currentFolder.getFS();
			if (currentFS instanceof TreeFS) {
				if (currentFolder.canModify()) {
					addTitle(i18n("Import into \"{0}\"", currentFolder));

					for (PluginInfo i : PluginType.EDITOR.get()) {
						EditorPlugin plugin = (EditorPlugin)i.getPlugin();
						List<EditorPlugin.FileType> types = plugin.getImportTypes();
						if (!types.isEmpty()) {
							MAction importAction = new ImportExport.ImportAction(plugin, plugin.getDocumentDisplayName(), types);
							importAction.setSmallIcon(i.getSmallIcon());
							add(importAction);
						}
					}
					
					addSeparator(false);
					
					add(new ImportFolderAction());
				}
				else {
					addTitle(i18n("This folder is locked (read only): {0}", currentFolder), "ui/error");
				}
			}

			for (AbstractFS i : Tree.getInstance()) {
				if (i instanceof PluginMenu)
					PluginMenu.class.cast(i).updateMenu(PluginMenu.IMPORT_MENU, this);
			}
			PluginManager.updateMenu(this, PluginMenu.IMPORT_MENU, false);
		}

	}

	// private classes

	private static final class ConfigureAction extends MApplication.SettingsAction {

		// public

		@Override
		public void onAction() {
			MSettingsDialog dialog = new MSettingsDialog(
				MainWindow.getInstance(),
				MSettingsDialog.STANDARD_DIALOG | MSettingsDialog.APPLY_BUTTON,
				"configure"
			) {
				@Override
				protected void apply() {
					super.apply();
					MainWindow.getInstance().repaint();
				}
			};
			
			// add pages
			dialog.addPage(new GeneralSettings());
			dialog.addPage(new LookAndFeelSettings());
			if (Main.isTodoPluginEnabled())
				dialog.addPage(new TasksSettings());
			PluginManager.addPluginOptions(dialog);
			dialog.addAdvancedPage(ProxySettings.class);
			dialog.addAdvancedPage(ArmorSettings.class);
			
			dialog.exec();
		}

		// private
		
		private ConfigureAction() {
			setHTMLHelp(i18n("Application settings (look and feel, browser, etc)."));
		}

	}

	private final class CustomMouseGestures extends MouseGestures {

		// public

		public CustomMouseGestures() { }

		// protected

		@Override
		protected boolean canShowMessage() {
			return !MainWindow.isPresentationActive();
		}

		@Override
		protected void onInit() {
			Tabs tabs = Tabs.getInstance();
			TreePanel treePanel = TreePanel.getInstance();
			
			this.add("D", treePanel.getActionGroup().getAction("new-file"));
			if (Kiosk.consoleEnabled.get())
				this.add(consoleAction);
			this.add("Ds", treePanel.getActionGroup().getAction("new-folder"));
			this.add("DR", tabs.getCloseAction());
			this.add("DRs", tabs.getCloseAllAction());
			this.add("L", NavigationUtils.getPreviousAction());
			this.add("Lc", toggleDesignerAction);
			this.add("LD", searchAction);
			this.add("LR", new MAction(i18n("Show/Hide Sidebar"),
				action -> mainSplitPane.toggleSidebar()
			));
			this.add("Ls", toggleSummaryAction);
			this.add("LU", new MAction(i18n("Show Tree"),
				action -> Sidebar.getInstance().goTo(Sidebar.Tab.TREE)
			));
			this.add("R", NavigationUtils.getNextAction());
			this.add(documentList.getPopupAction());
			this.add("Uc", TreePanel.getInstance().getActionGroup().getAction("properties"));
			this.add("Ucs", configureAction);
			this.add("UD", toggleDesktopAction);
			this.add("UR", findAction);
			this.add("URDL", printAction);
		}

	}

	private static final class FindAction extends MAction {

		// public

		@Override
		public void onAction() {
			EditorQuickFind editorQuickFind = EditorQuickFind.getInstance();
			MainWindow.getInstance().installTabBar(editorQuickFind);
			editorQuickFind.setActive(true);
		}

		// private
		
		private FindAction() {
			super(MActionInfo.FIND);
			setHTMLHelp(i18n("Search for a text in the active document."));
		}

	}

	private static final class FindNextAction extends MAction {

		// public

		@Override
		public void onAction() {
			EditorQuickFind editorQuickFind = EditorQuickFind.getInstance();
			MainWindow.getInstance().installTabBar(editorQuickFind);
			editorQuickFind.findNext();
		}

		// private
		
		private FindNextAction() {
			super(MActionInfo.FIND_NEXT);
			setHTMLHelp(i18n("Search for the next matching text in the active document."));
		}

	}

	private static final class FindPreviousAction extends MAction {

		// public

		@Override
		public void onAction() {
			EditorQuickFind editorQuickFind = EditorQuickFind.getInstance();
			MainWindow.getInstance().installTabBar(editorQuickFind);
			editorQuickFind.findPrevious();
		}

		// private
		
		private FindPreviousAction() {
			super(MActionInfo.FIND_PREVIOUS.noIcon());
			setHTMLHelp(i18n("Search for the previous matching text in the active document."));
		}

	}

	private static final class HelpAction extends MAction {

		// public

		@Override
		public void onAction() {
			Editor<?> tab = Tabs.getInstance().getSelectedTab();
			if (tab instanceof DocumentHelp) {
				HelpContext context = DocumentHelp.class.cast(tab).showHelp();

				if ((context != null) && Help.show(tab, context))
					return;
			}

			MainWindow window = MainWindow.getInstance();
			
			HelpGenerator help = new HelpGenerator();
			help.setMenuBar(window.getMMenuBar());
			help.setOutputDirectory(FS.newConfigPath("help", FS.CREATE_DIR));
			help.setTitle(i18n("Help"));
			
			// exclude dynamic menus
			help.addExcludeMenu((MMenu)window.getElementById("bookmarks-menu"));
			help.addExcludeMenu((MMenu)window.getElementById("export-menu"));
			help.addExcludeMenu((MMenu)window.getElementById("import-menu"));
			help.addExcludeMenu((MMenu)window.getElementById("tags-menu"));
			
			help.addLink(i18n("Documentation"), URI.create("http://sourceforge.net/p/makagiga/wiki/"));
			help.addLink("Makagiga Project", URI.create("http://sourceforge.net/projects/makagiga/"));
			
			help.addCommonShortcuts();

			help.addShortcut(i18n("Image Viewer"));
			help.addShortcut(i18n("Fit to Window"), VK_F);
			help.addShortcut(i18n("Full Screen"), i18n("Double Click"));

			help.addShortcut(i18n("RSS Feeds"));
			help.addShortcut(i18n("Next New"), VK_J);
			help.addShortcut(i18n("Previous New"), VK_K);
			help.addShortcut(i18n("Open in a new tab (article/notification window)"), i18n("Middle Button Click"));

			help.addShortcut(i18n("Todo List/Table"));
			help.addShortcut(i18n("Edit Cell"), VK_ENTER);
			help.addShortcut(i18n("Edit Cell"), VK_F2);
			help.addShortcut(i18n("Focus header"), VK_F8);
			help.addShortcut(i18n("Move to the previous panel"), VK_TAB, CTRL_MASK + SHIFT_MASK);

			help.addShortcut(i18n("Widgets"));
			help.addShortcut(i18n("Close active widget"), VK_F4, CTRL_MASK);
			help.addShortcut(i18n("Close active widget"), i18n("Right Button Click"));
			help.addShortcut(i18n("Activate next widget"), VK_F6, CTRL_MASK);
			
			help.addShortcut(i18n("Tabs"));
			help.addShortcut(i18n("Close"), i18n("Middle Button Click"));
			help.addShortcut(i18n("Move between the Tree and Tabs"), VK_F6);
			help.addShortcut(i18n("Move left"), VK_LEFT, CTRL_MASK);
			help.addShortcut(i18n("Move right"), VK_RIGHT, CTRL_MASK);
			help.addShortcut(MActionInfo.RENAME.getDialogTitle(), i18n("Double Click"));
			help.addShortcut(i18n("Zoom In") + '/' + i18n("Zoom Out"), getKeyModifiersText(CTRL_MASK) + '+' + i18n("Mouse Wheel"));

			help.addShortcut(i18n("System Tray"));
			help.addShortcut(i18n("Quick Paste"), i18n("Middle Button Click"));

			try {
				help.generate();

				// load page
				WebBrowserTab browserTab = WebBrowserTab.getInstance();
				browserTab.getWebBrowser()
					.setDocumentLocation(help.getIndexFile().toUri());
			}
			catch (IOException exception) {
				showErrorMessage(exception);
			}
		}

		// private

		private HelpAction() {
			super(MActionInfo.HELP);
		}

		private void updateProperties(final Editor<?> tab) {
			if (tab instanceof DocumentHelp) {
				PluginInfo info = tab.getMetaInfo().getPluginInfo();
				String name = (info != null) ? info.toString() : tab.getMetaInfo().toString();
				setName(i18n("Help: {0}", TK.rightSqueeze(name, 20)));
			}
			else {
				setName(MActionInfo.HELP.getText());
			}
		}

	}
	
	private static final class ImportFolderAction extends MAction {
	
		// public
		
		public ImportFolderAction() {
			super(i18n("Folder..."), "ui/folder");
		}
		
		@Override
		public void onAction() {
			File from = new Input.GetDirectoryBuilder()
				.title(i18n("Import Folder"))
				.configKey("import-folder")
				.ok(MActionInfo.IMPORT)
			.exec(this);
			
			if (from == null)
				return;
			
			MetaInfo toFolder = Tree.getInstance().getCurrentFolder(false);
			try {
				ImportExport.importFolder(getSourceWindow(), new MArrayList<>(from.toPath()), toFolder);
			}
			catch (FSException | IOException exception) {
				showErrorMessage(exception);
			}
		}
	
	}

	private static final class PluginSettingsAction extends PluginSettings.Action {

		// public

		@Override
		public void onAction() {
			PluginSettingsTab.getInstance();
		}

		// private

		private PluginSettingsAction() { }

	}

	private static final class PrintAction extends MApplication.PrintAction {

		// public

		@Override
		public void onAction() {
			Editor<?> editor = Tabs.getInstance().getSelectedTab();
			if (editor instanceof EditorPrint) {
				Flags caps = Flags.valueOf(editor.getPrintingCapabilities());
				if (caps.isSet(Editor.NO_PRINT_PREVIEW)) {
					PrintDialog.printDocument(editor, Flags.NONE);
				}
				else {
					PrintDialog dialog = new PrintDialog(MainWindow.getInstance(), editor);
					dialog.exec();
				}
			}
		}

		// private
		
		private PrintAction() {
			setEnabled(false);
			setHTMLHelp(i18n("Prints the content of the active document."));
		}

	}

	private static final class ShowHideLocationBarAction extends MAction {

		// public

		@Override
		public Component getHighlightedComponent() { return LocationBar.getInstance(); }

		@Override
		public void onAction() {
			Vars.treeLocationBarVisible.set(isSelected());
		}

		// private

		private ShowHideLocationBarAction() {
			super(i18n("Location Bar"));
			if (UI.isQuaqua())
				setEnabled(false);
		}

	}

	private static final class ShowHidePropertiesBarAction extends MAction {

		// public

		@Override
		public Component getHighlightedComponent() {
			return PropertiesBar.getInstance();
		}

		@Override
		public void onAction() {
			setInstalled(isSelected());
		}

		// private
		
		private ShowHidePropertiesBarAction() {
			super(i18n("Properties Bar"));
		}
		
		private void setInstalled(final boolean yes) {
			MainWindow mainWindow = MainWindow.getInstance();
			setSelected(yes);
			PropertiesBar propertiesBar = PropertiesBar.getInstance();
			if (yes) {
				propertiesBar.setMetaInfo(Tabs.getInstance().getCurrentMetaInfo());
				mainWindow.installTabBar(propertiesBar);
				propertiesBar.showOrHide(true);
			}
			else {
				mainWindow.installTabBar(null);
				propertiesBar.setVisible(false);
			}
			
			Config config = Config.getDefault();
			config.write("PropertiesBar.enabled", yes);
		}

	}

	private static final class ShowHideSidebarAction extends MAction {

		// public

		@Override
		public Component getHighlightedComponent() { return Sidebar.getInstance(); }

		@Override
		public void onAction() {
			MainWindow.getInstance().mainSplitPane.toggleSidebar();
		}

		// private
		
		private ShowHideSidebarAction() {
			super(i18n("Sidebar"), null, VK_F9);
		}

	}

	private static final class ToggleDesignerAction extends MAction {

		// public

		@Override
		public void onAction() {
			MainWindow.showSidebar(Sidebar.Tab.DESIGNER, true);
		}

		// private
		
		private ToggleDesignerAction() {
			super(i18n("Toggle: {0}", i18n("Properties")), "ui/wizard", VK_F4);
		}

	}

	private static final class ToggleDesktopAction extends MAction {

		// public

		@Override
		public void onAction() {
			MainWindow mainWindow = MainWindow.getInstance();
			mainWindow.setDesktopVisible(!mainWindow.isDesktopVisible());
		}

		// private
		
		private ToggleDesktopAction() {
			super(i18n("Show Widgets"), "ui/desktop", VK_F5);
		}

	}

	private static final class ToggleSummaryAction extends MAction {

		// public

		@Override
		public void onAction() {
			MainWindow.showSidebar(Sidebar.Tab.SUMMARY, true);
			if (Sidebar.getInstance().isTreeSelected())
				Tree.getInstance().requestFocus();
		}

		// private
		
		private ToggleSummaryAction() {
			super(i18n("Tasks"), VK_S, CTRL_MASK + SHIFT_MASK);
		}

	}

	private static final class ZoomInAction extends MApplication.ZoomInAction {

		// public

		@Override
		public void onAction() {
			MainWindow.getInstance().zoomEditor(EditorZoom.ZoomType.IN);
		}

	}

	private static final class ZoomOutAction extends MApplication.ZoomOutAction {

		// public

		@Override
		public void onAction() {
			MainWindow.getInstance().zoomEditor(EditorZoom.ZoomType.OUT);
		}

	}

	private static final class ZoomResetAction extends MApplication.ZoomResetAction {

		// public
		
		public ZoomResetAction() { }

		@Override
		public void onAction() {
			MainWindow.getInstance().resetEditorZoom();
		}

	}

}
