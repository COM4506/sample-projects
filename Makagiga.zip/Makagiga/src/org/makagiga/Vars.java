// Copyright 2006 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package org.makagiga;

import org.makagiga.commons.BooleanProperty;
import org.makagiga.commons.EnumProperty;
import org.makagiga.commons.IntegerProperty;
import org.makagiga.commons.StringProperty;
import org.makagiga.commons.TK;
import org.makagiga.commons.annotation.ConfigEntry;
import org.makagiga.commons.annotation.Uninstantiable;
import org.makagiga.todo.Column;

/**
 * Global properties.
 *
 * Below properties are loaded/saved automatically at application start/exit.
 * You can change variables's value
 * either programmatically or in the Console.
 *
 * Console example:
 * Type "Confirm.exit true" (or "Confirm.exit 1") to enable exit confirmation.
 */
public final class Vars {
	
	// public
	
	// const
	
	public static final int MIN_TREE_PREVIEW_SIZE = 25;
	public static final int MAX_TREE_PREVIEW_SIZE = 250;

	// alarm

	/**
	 * @since 5.6
	 */
	@ConfigEntry("Alarm.autoHide")
	public static final BooleanProperty alarmAutoHide = new BooleanProperty();

	/**
	 * @since 2.0
	 */
	@ConfigEntry("Alarm.enabled")
	public static final BooleanProperty alarmEnabled = new BooleanProperty();

	/**
	 * @since 4.10
	 */
	@ConfigEntry("Alarm.systemTrayIcon")
	public static final BooleanProperty alarmSystemTrayIcon = new BooleanProperty(false, BooleanProperty.NON_NULL);

	/**
	 * @since 4.10
	 */
	@ConfigEntry("Alarm.overdueOnly")
	public static final BooleanProperty alarmOverdueOnly = new BooleanProperty(true, BooleanProperty.NON_NULL);

	// armor
	
	/**
	 * Unused.
	 *
	 * @since 2.0
	 *
	 * @deprecated Since 4.4
	 */
	//@ConfigEntry("SecurityManager.enabled")
	@Deprecated
	public static final BooleanProperty armorEnabled = new BooleanProperty(false, BooleanProperty.SECURE_ALL);

	// autosave
	
	/**
	 * @since 2.2
	 */
	@ConfigEntry(value = "Autosave.timeout", description = "Autosave session (all modified documents, etc.) every n minutes")
	public static final IntegerProperty autosaveTimeout = new IntegerProperty(5);
	
	// feeds
	
	/**
	 * The number of threads used to fetch RSS feeds (1..16).
	 *
	 * - Lower value = slower download, lower CPU/bandwidth usage
	 * - Higher value = faster download, higher CPU/bandwidth usage
	 *
	 * @since 2.0
	 */
	@ConfigEntry("Feeds.threads")
	public static final IntegerProperty feedsThreads = new IntegerProperty(5, IntegerProperty.SECURE_WRITE);
	
	// kiosk

	/**
	 * Unused.
	 *
	 * @since 3.0
	 *
	 * @deprecated Since 4.4
	 */
	//@ConfigEntry("Kiosk.Action.sendFile")
	@Deprecated
	public static final BooleanProperty actionSendFile = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.NewFolder.showAdvanced")
	public static final BooleanProperty newFolderShowAdvanced = new BooleanProperty(true);

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Kiosk.Tree.readOnly")
	public static final BooleanProperty treeReadOnly = new BooleanProperty(false, BooleanProperty.SECURE_WRITE);

	// password

	/**
	 * @since 2.0
	 */
	@ConfigEntry("Password.enabled")
	public static final BooleanProperty passwordEnabled = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);
	
	// preloader

	/**
	 * @since 3.0
	 */
	@ConfigEntry(value = "Preloader.image", description = "Preload next image in image viewer. Disable on low-memory systems.")
	public static final BooleanProperty preloaderImage = new BooleanProperty(true);

	// sidebar

	/**
	 * @since 4.10
	 */
	@ConfigEntry("Sidebar.smallIcons")
	public static final BooleanProperty sidebarSmallIcons = new BooleanProperty(false, BooleanProperty.NON_NULL);

	// summary

	/**
	 * @since 4.8
	 */
	@ConfigEntry("Summary.groupMethod")
	public static final StringProperty summaryGroupMethod = new StringProperty("", StringProperty.NON_NULL);

	/**
	 * @since 3.8.3
	 */
	@ConfigEntry("Summary.printDateTime")
	public static final BooleanProperty summaryPrintDateTime = new BooleanProperty(true);

	/**
	 * @since 2.0
	 */
	@ConfigEntry("Summary.showAllTasks")
	public static final BooleanProperty summaryShowAllTasks = new BooleanProperty();

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Summary.sortMethod")
	public static final EnumProperty<Column> summarySortMethod = new EnumProperty<>(Column.SUMMARY);

	// tabs

	/**
	 * @since 3.0
	 */
	@ConfigEntry("Tabs.recentlyClosedTabs")
	public static final BooleanProperty tabsRecentlyClosedTabs = new BooleanProperty(true);

	/**
	 * @since 4.10
	 */
	@ConfigEntry("Tabs.smallIcons")
	public static final BooleanProperty tabsSmallIcons = new BooleanProperty(false, BooleanProperty.NON_NULL);

	// tags

	@ConfigEntry("Tags.autoExported")
	public static final BooleanProperty tagsAutoExported = new BooleanProperty(true);

	@ConfigEntry("Tags.autoImported")
	public static final BooleanProperty tagsAutoImported = new BooleanProperty(true);
	
	@ConfigEntry("Tags.autoPasted")
	public static final BooleanProperty tagsAutoPasted = new BooleanProperty(true);

	@ConfigEntry("Tags.autoPrinted")
	public static final BooleanProperty tagsAutoPrinted = new BooleanProperty(true);

	// tree
	
	/**
	 * @since 1.2
	 */
	@ConfigEntry("Tree.itemCount")
	public static final BooleanProperty treeItemCount = new BooleanProperty();

	/**
	 * @since 2.0
	 */
	@ConfigEntry("Tree.locationBarVisible")
	public static final BooleanProperty treeLocationBarVisible = new BooleanProperty(true);

	@ConfigEntry("Tree.preview")
	public static final BooleanProperty treePreview = new BooleanProperty();

	@ConfigEntry("Tree.previewSize")
	public static final IntegerProperty treePreviewSize = new IntegerProperty(75);

	@ConfigEntry("Tree.reopenFiles")
	public static final BooleanProperty treeReopenFiles = new BooleanProperty(true);

	/**
	 * @since 3.2
	 *
	 * @deprecated Since 5.6
	 */
	//@ConfigEntry("Tree.showCategories")
	@Deprecated
	public static final BooleanProperty treeShowCategories = new BooleanProperty();

	/**
	 * @since 4.2
	 */
	@ConfigEntry("Tree.showColor")
	public static final BooleanProperty treeShowColor = new BooleanProperty(true);

	/**
	 * @since 4.2
	 */
	@ConfigEntry("Tree.showDate")
	public static final BooleanProperty treeShowDate = new BooleanProperty();

	/**
	 * @since 2.0
	 */
	@ConfigEntry("Tree.showRating")
	public static final BooleanProperty treeShowRating = new BooleanProperty(true);

	/**
	 * @since 2.0
	 */
	@ConfigEntry("Tree.showMetaInfo")
	public static final BooleanProperty treeShowMetaInfo = new BooleanProperty();

	/**
	 * @since 2.0
	 */
	@ConfigEntry("Tree.showTags")
	public static final BooleanProperty treeShowTags = new BooleanProperty();

	/**
	 * @since 3.8.5
	 */
	@ConfigEntry("Tree.smallIcons")
	public static final BooleanProperty treeSmallIcons = new BooleanProperty(false);

	/**
	 * @since 3.8.12
	 */
	@ConfigEntry("Tree.toolTips")
	public static final BooleanProperty treeToolTips = new BooleanProperty(false);

	// version
	
	/**
	 * @since 2.0
	 */
	@ConfigEntry("Version.enabled")
	public static final BooleanProperty versionEnabled = new BooleanProperty(true, BooleanProperty.SECURE_WRITE);

	// private
	
	@Uninstantiable
	private Vars() {
		TK.uninstantiable();
	}
	
}
