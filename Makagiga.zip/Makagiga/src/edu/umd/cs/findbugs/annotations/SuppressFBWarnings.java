// Copyright 2014 Konrad Twardowski
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package edu.umd.cs.findbugs.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * An implementation of the FindBugs&trade; Bug Suppressor.
 *
 * Based on the <a href="http://findbugs.sourceforge.net/api/edu/umd/cs/findbugs/annotations/SuppressFBWarnings.html">FindBugs&trade; API Documentation</a>.
 *
 * @mg.example
 * <pre class="brush: java">
 * {@literal @}SuppressFBWarnings("DM_GC")
 * void uglyHack() {
 *   System.gc();
 * }
 * </pre>
 *
 * @since 5.0
 *
 * @see <a href="http://findbugs.sourceforge.net/">FindBugs&trade; Home Page</a>
 */
@Retention(RetentionPolicy.CLASS)
public @interface SuppressFBWarnings {

	// public

	/**
	 * The list of bugs you want to suppress.
	 *
	 * @see <a href="http://findbugs.sourceforge.net/bugDescriptions.html">Bug Descriptions</a>
	 */
	public String[] value() default { };

	/**
	 * The optional description of the suppressed bug.
	 */
	public String justification() default "";

}
