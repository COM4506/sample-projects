#!/bin/sh

java -cp "./SDK/lib" -jar "./SDK/lib/sdk.jar" --base-dir ./SDK
