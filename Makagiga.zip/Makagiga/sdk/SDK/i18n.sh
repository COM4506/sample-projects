#!/bin/bash

if [ ! -d "po" ]; then
	echo "Error: Internal tool."
	echo "       Run \"ant i18n\" instead."
	exit 1
fi

if [ "$1" == '${String.translation}' ]; then
	DIR="."
elif [ "$1" == "application" ]; then
	DIR="../../src"
else
	DIR="."
fi

# extracts all text messages from the source files
echo "Searching for messages in \"$DIR\" directory..."
find "$DIR" -name "*.java" -o -name "*.js" | sort > po/source.tmp
xgettext --from-code=utf-8 -f po/source.tmp --force-po -ki18n --language=Java -o po/TEMPLATE.pot.tmp

# fix charset info
cat po/TEMPLATE.pot.tmp| \
	sed -e "s@Content-Type: text/plain; charset=CHARSET@Content-Type: text/plain; charset=utf-8@" \
	> po/TEMPLATE.pot
rm po/TEMPLATE.pot.tmp

# merge translation messages
for i in po/*.po; do
	if [ -f $i ]; then
		echo
		echo "Merging and compiling \"${i}\"..." 
		msgmerge $i po/TEMPLATE.pot -o $i
		PROPERTIES_OUT="i18n/`basename $i .po`.properties"
		msgmerge $i po/TEMPLATE.pot --no-location --no-wrap --properties-output -o "$PROPERTIES_OUT.tmp"
		if [ -f "$PROPERTIES_OUT.tmp" ]; then
			echo -e "\n### DO NOT TRANSLATE THIS FILE! SEE THE \"po\" DIRECTORY. ###\n" > "$PROPERTIES_OUT"
			cat "$PROPERTIES_OUT.tmp"|egrep -v '^\!.*$|^\#.*$|^$'>>"$PROPERTIES_OUT"
			rm "$PROPERTIES_OUT.tmp"
		fi
	fi
done
