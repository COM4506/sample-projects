
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/weather/
// * org.makagiga.desktop package (Makagiga source)

var MLabel = Java.type("org.makagiga.commons.swing.MLabel");
var SessionListener = Java.type("org.makagiga.desktop.SessionListener");
var Widget = Java.type("org.makagiga.desktop.Widget");

// NOTE: Global variables are shared
// by all widget instances created by the same plugin.

function onCreate() {
	var widget = new Widget(plugin.info);
	widget.setDefaultSize(250, 250);

	// TODO: Add content:
	var content = new MLabel("Hello, World!");
	content.horizontalAlignment = MLabel.CENTER;
	content.iconName = "labels/emotion/happy";
	widget.addCenter(content);
	
	widget.addSessionListener(new SessionListener() {
		restoreSession: function() {
			// EXAMPLE: Read settings, load file, etc.
			//var foo = widget.getWidgetConfig().read("x.foo", "default foo value");

			// HINT: Use widget.getDataDirectory().resolve("file name")
			// to create a session data path.
		},
		saveSession: function() {
			// EXAMPLE: Write settings, save file, etc.
			//widget.getWidgetConfig().write("x.foo", "foo value");
		}
	} );

	return widget;
}
