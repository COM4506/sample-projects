
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/weather/
// * org.makagiga.desktop package (Makagiga source)

package @@PROJECT_PACKAGE_NAME@@;

import static org.makagiga.commons.UI.i18n;

import org.makagiga.commons.swing.MLabel;
import org.makagiga.desktop.Widget;
import org.makagiga.plugins.PluginInfo;

public class Main extends Widget {

	Main(PluginInfo info) {
		super(info);
		setDefaultSize(250, 250);
		
		// TODO: Add content.
		MLabel content = new MLabel(i18n("Hello"));
		content.setHorizontalAlignment(MLabel.CENTER);
		content.setIconName("labels/emotion/happy");
		addCenter(content);
	}

	/**
	 * Read settings, load file, etc.
	 */
	@Override
	protected void onRestoreSession() throws Exception {
		// EXAMPLE:
		//Config config = getWidgetConfig();
		//String foo = config.read("x.foo", "default foo value");

		// HINT: Use getDataDirectory().resolve("file name")
		// to create a session data path.
	}

	/**
	 * Write settings, save file, etc.
	 */
	@Override
	protected void onSaveSession() {
		// EXAMPLE:
		//Config config = getWidgetConfig();
		//config.write("x.foo", "foo value");
	}

}
