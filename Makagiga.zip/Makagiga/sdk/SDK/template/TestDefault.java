
import org.makagiga.test.AbstractTest;
import org.makagiga.test.Test;

/**
 * HINT: Run "ant test" to compile and run tests.
 */
@Test(className = Void.class)
public class TestDefault extends AbstractTest {

	@Test
	public void test_exceptions() {
		// EXAMPLE: NullPointerException.class - expected exception
		assertException(NullPointerException.class, () -> {
			String nullString = null;
			nullString.length();
		} );
	}
	
	@Test
	public void test_misc() {
		// EXAMPLE: assertEquals
		String foobar = "foobar";
		String s = foobar.substring(3);
		assertEquals("bar", s);
	}

}
