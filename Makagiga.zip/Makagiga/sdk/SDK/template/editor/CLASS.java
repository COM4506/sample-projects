
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/editorexample/
// * org.makagiga.editors package (Makagiga source)

package @@PROJECT_PACKAGE_NAME@@;

import static org.makagiga.commons.UI.i18n;

import java.awt.Component;
import java.awt.Window;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

import org.makagiga.commons.MAction;
import org.makagiga.commons.MActionInfo;
import org.makagiga.commons.TK;
import org.makagiga.commons.swing.ActionGroup;
import org.makagiga.commons.swing.MLabel;
import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.plugins.PluginMenu;
import org.makagiga.editors.Editor;
import org.makagiga.editors.EditorExport;
import org.makagiga.editors.EditorIO;
import org.makagiga.editors.EditorPlugin;

/**
 * A document editor/viewer example.
 */
public class Main extends Editor<Component> implements EditorExport, EditorIO, PluginMenu {

	private ActionGroup editActionGroup;
	
	/**
	 * Constructs a new editor (tab) instance.
	 */
	Main() {
// TODO: Setup User Interface:
		MLabel content = new MLabel(i18n("Hello")); // i18n - mark text for language translation
		content.setHorizontalAlignment(MLabel.CENTER);
		content.setIconName("labels/emotion/happy");
		getMainPanel().addCenter(content);

		setCore(content); // set main/central component

// TODO: Create "Edit" actions:
		editActionGroup = new ActionGroup();
		editActionGroup.add("copy", new MAction(MActionInfo.COPY, action -> {
// TODO: Example action...
		} ));
	}

// TODO: Dispose resources, set fields to "null" to avoid memory leaks, etc.
	@Override
	public void onClose() {
		editActionGroup = TK.dispose(editActionGroup);
	}

// TODO: Enable/disable actions/components if document is locked.
	@Override
	public void updateActions() {
		boolean enabled = !isLocked();
		editActionGroup.setEnabled(enabled);
	}
	
// TODO: Export file using EditorExport interface (optional).
	@Override
	public Object configureExport(Window owner, EditorPlugin.FileType type) throws Exception { return null; }
	
	@Override
	public ExportResult exportFile(EditorPlugin.FileType type, File outputFile, OutputStream output, Object configuration) throws Exception {
		if (type.is(Plugin.PRIMARY_FILE_EXTENSION))
			saveFile(output);
		else
			return ExportResult.NOT_SUPPORTED;
		
		return ExportResult.OK;
	}
	
// TODO: Load from file using EditorIO interface.
	@Override
	public void loadFile(InputStream input, boolean newFile) throws Exception { }
	
// TODO: Save to file using EditorIO interface.
	@Override
	public void saveFile(OutputStream output) throws Exception {
		// NOTE: Mark document as modified using "setModified(true)" or it will NOT be saved.
	}
	
// TODO: Add menu items and tool bar buttons.
	@Override
	public void updateMenu(String type, MMenu menu) {
		switch (type) {
			case EDIT_MENU:
				editActionGroup.updateMenu(menu);
				break;
		}
	}

	@Override
	public void updateToolBar(String type, MToolBar toolBar) {
		switch (type) {
			case EDITOR_TOOL_BAR:
				editActionGroup.updateToolBar(toolBar);
				break;
		}
	}

}
