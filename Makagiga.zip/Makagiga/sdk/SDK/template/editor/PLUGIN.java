
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/editorexample/
// * org.makagiga.editors package (Makagiga source)

package @@PROJECT_PACKAGE_NAME@@;

import org.makagiga.editors.Editor;
import org.makagiga.editors.EditorPlugin;
import org.makagiga.plugins.PluginException;

public class Plugin extends EditorPlugin {

// TODO: Replace "mgtest" with your own file suffix/extension.
// Example: "pdf" in PDF Viewer.
	static final String PRIMARY_FILE_EXTENSION = "mgtest";

	@Override
	public Editor<?> create() {
		return new Main();
	}

	@Override
	public void onInit() throws PluginException {
		super.onInit();

		FileType primaryFileType = new FileType(PRIMARY_FILE_EXTENSION, getName());

		setFileTypes(primaryFileType);
		
		// See the File|Import menu.
		setImportTypes(primaryFileType);
		
		// See the File|Export menu.
		// Used by the EditorExport interface.
		setExportTypes(primaryFileType);
	}

}
