
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/%7B8c7c649c-42a5-4ff8-aa0b-77a88784b06e%7D/
// * org.makagiga.internetsearch package (Makagiga source)

package @@PROJECT_PACKAGE_NAME@@;

import org.makagiga.internetsearch.InternetSearchPlugin;

public class Plugin extends InternetSearchPlugin {

	public Plugin() { }

}
