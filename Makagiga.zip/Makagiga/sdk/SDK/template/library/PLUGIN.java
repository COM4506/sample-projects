
package @@PROJECT_PACKAGE_NAME@@;

import org.makagiga.plugins.PluginException;

public final class Plugin extends org.makagiga.plugins.Plugin<Object> {

	@Override
	public void onInit() throws PluginException { }

	@Override
	public void onPostInit() throws PluginException { }

	@Override
	public void onDestroy() throws PluginException { }

}
