
Quick start:

* This project/plugin requires Makagiga SDK
  <http://sourceforge.net/p/makagiga/wiki/SDK/>
* Type "ant run" to compile and launch plugin
* Type "ant dist" to create plugin packages (*.mgplugin file; ready to install)
* See Makagiga SDK main window -> menu -> Help for more documentation


Files you can modify:

* resources - a directory with additional files (e.g. XML configuration files).
  All files from the "resources" directory will be automatically included in
  a .mgplugin package file.
  You can access all resource files directly from the Plugin class:
    File resourcesDir = getResourcesDirectory();
    File configFile = new File(resourcesDir, "config.xml");
  or:
    File configFile = getResourceFile("config.xml");

* icon.png       - a normal plugin icon (PNG, 48x48 or 32x32)
* icon-small.png - a small plugin icon (PNG, 16x16)
  There are two ways to change the default icon:
  1. Replace the "icon.png" file with your own image.
  2. Remove "icon.png" file and add String.icon=ICON_NAME
     to the plugin.properties file,
     where ICON_NAME is a standard Makagiga icon name.
     EXAMPLE: String.icon=ui/password
  3. Include copyright notice in LICENSE.txt file if necessary.

* ChangeLog         - a list of changes
* LICENSE.txt       - plugin license text (see plugin.properties file)
* main.js           - plugin script source (JavaScript mode)
* plugin.properties - plugin info (name, description, copyright, home page, etc.)
* po                - language translations
                      (run "ant i18new" to create a new translation)
* preview.png       - an optional small preview image (150x100)
* README.txt        - this file
* src               - source files (.java files and related resources)


Optional: Self-Signing the *.jar files:

1. Generate a certificate using the "keytool" program (part of the JDK).
   Example:
   keytool -genkeypair -keystore "Keys" -alias "myalias" -validity 365
2. Set "String.keyAlias" property in plugin.properties to "myalias"
3. Put "Keys" file in the plugin project directory (this folder)
4. Next time you run "ant dist" you will be asked for the "key store" password
   (the same password used in the 1. step)
5. The "Keys" file is not included in the "source" package,
   so keep it in the safe place.


Quick plugin project upgrade (from Makagiga 4.x to 5.x):

* plugin.properties file:
  Set "String.requires" property to version 4.99 or greater.


Optional: Full plugin project upgrade (from Makagiga 4.x to 5.x):

1. Backup your current project directory.
2. Rename your current project directory to avoid errors during the next steps.
   (for example, change folder name from "myproject" to "myproject-OLD")
3. Run SDK and New Project wizard.
   You can use the old plugin properties to fill in required fields:
   - myproject-OLD/build.xml (name, PROJECT_ID, PROJECT_INTERNAL_NAME, PROJECT_PACKAGE_NAME)
   - myproject-OLD/plugin.properties (version, license, etc.)
   NOTE: In most cases you should use the previous Plugin ID (PROJECT_ID).
4. Copy sources and other required files from "myproject-OLD" to the new project folder.
5. Compile and run your project.
6. Search SDK/doc/PORTING.txt for API changes (in case of compilation errors).


Build scripts and other files:

* build.xml - this is a build script for Ant (like Makefile)
* nbproject - NetBeans IDE project files


Generated/Removed automagically (do not modify!):

* .mgplugin     - a ready to install plugin packages
* build         - compiled Java classes
* i18n/i18n.jar - merged and compiled language translations
* plugin.jar    - compiled plugin classes
* {uuid}        - plugin test directory
* API           - an API documentation (see "ant apidoc")
