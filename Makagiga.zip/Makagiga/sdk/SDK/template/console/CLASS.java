
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/cal/
// * org.makagiga.console package (Makagiga source)

package @@PROJECT_PACKAGE_NAME@@;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.makagiga.console.Console;
import org.makagiga.console.ConsoleCommand;
import org.makagiga.console.ConsoleIO;
import org.makagiga.plugins.PluginInfo;

public class Main extends ConsoleCommand {

	Main(PluginInfo info) {
		// TODO: change command name ("date")
		super("date", info.shortDescription.get());
	}
	
	@Override
	public Object onCommand(Console console, String... args) {
		// EXAMPLE:
		if (args.length == 0) {
			onHelp(console);

			return null;
		}
		else {
			String pattern = String.join(" ", args);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
			String result = formatter.format(LocalDateTime.now());

			return result;

			// TIP: You can also print the result using other methods
			// and simply return null:
			//
			// ConsoleIO io = console.getIO();
			// EXAMPLE 1: io.printLine(result);
			// EXAMPLE 2: io.printResult("Date/Time:", result);
		}
	}
	
	@Override
	public boolean onHelp(Console console) {
		ConsoleIO io = console.getIO();
		io.printLine("Usage: date [format]");
		io.printLine("Example 1: date HH:mm");
		io.printLine("Example 2: date yyyy-MM-dd HH:mm:ss");
	
		return true;
	}

}
