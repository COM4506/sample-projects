
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/
// * Makagiga source

package @@PROJECT_PACKAGE_NAME@@;

import static org.makagiga.commons.UI.i18n;

import org.makagiga.commons.swing.MMenu;
import org.makagiga.commons.swing.MMessage;
import org.makagiga.commons.swing.MToolBar;
import org.makagiga.plugins.GeneralPlugin;
import org.makagiga.plugins.PluginAction;
import org.makagiga.plugins.PluginException;

public class Plugin extends GeneralPlugin {

	@Override
	public void onInit() throws PluginException { }

	@Override
	public void onPostInit() throws PluginException { }

	@Override
	public void onDestroy() throws PluginException { }
	
	@Override
	public void updateMenu(String type, MMenu menu) {
		switch (type) {
			case TOOLS_MENU:
				menu.add(getDefaultAction());
				break;
		}
	}
	
	@Override
	public void updateToolBar(String type, MToolBar toolBar) {
		switch (type) {
			case TREE_TOOL_BAR:
				toolBar.add(getDefaultAction());
				break;
		}
	}

	@Override
	protected void onDefaultAction(PluginAction action) {
		// The "i18n" method will mark text for language translation.
		// See README.txt for more info.
		MMessage.info(action.getSourceWindow(), i18n("Hello"));
	}

}
