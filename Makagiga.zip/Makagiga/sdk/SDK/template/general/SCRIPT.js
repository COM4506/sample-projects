
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/
// * Makagiga source

var PluginMenu = Java.type("org.makagiga.plugins.PluginMenu");

function onAction(action) {
	var name = window.prompt("Enter Your Name:");
	if (name)
		window.alert("Hello " + name);
}

function updateMenu(type, menu) {
	if (type == PluginMenu.TOOLS_MENU) {
		menu.add(plugin.action);
	}
}

function updateToolBar(type, toolBar) {
	if (type == PluginMenu.TREE_TOOL_BAR) {
		toolBar.add(plugin.action);
	}
}
