
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/substance/ (Look And Feel)
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/tangoicontheme/ (Icon Theme)

package @@PROJECT_PACKAGE_NAME@@;

import org.makagiga.plugins.LookAndFeelPlugin;

public class Plugin extends LookAndFeelPlugin {

	public Plugin() { }

}
