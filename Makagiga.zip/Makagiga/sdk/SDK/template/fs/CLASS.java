
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/findfiles/
// * org.makagiga.fs package (Makagiga source)

package @@PROJECT_PACKAGE_NAME@@;

import java.io.File;

import org.makagiga.fs.AbstractFS;
import org.makagiga.fs.FSException;
import org.makagiga.fs.FSNewFolder;
import org.makagiga.fs.MetaInfo;
import org.makagiga.plugins.PluginInfo;

public class Main extends AbstractFS implements FSNewFolder {
	
	Main(PluginInfo info) throws FSException {
		super(info);
		scan();
	}
	
	@Override
	protected void processFile(MetaInfo parent, File file) {
		processDynamicFolder(parent, file);
	}

}
