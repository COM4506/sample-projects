
// EXAMPLES:
// * http://sourceforge.net/p/makagiga/code/HEAD/tree/trunk/plugins/findfiles/
// * org.makagiga.fs package (Makagiga source)

package @@PROJECT_PACKAGE_NAME@@;

import org.makagiga.fs.AbstractFS;
import org.makagiga.fs.FSPlugin;

public class Plugin extends FSPlugin {
	
	@Override
	public AbstractFS create() throws Exception {
		return new Main(getInfo());
	}
	
}
