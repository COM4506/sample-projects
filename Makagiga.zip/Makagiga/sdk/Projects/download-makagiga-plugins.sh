#!/bin/bash

PLUGIN="$1"
URL="http://svn.code.sf.net/p/makagiga/code/trunk/plugins"

if [ -z "$PLUGIN" ]; then
	echo "Usage: $0 [plugin name]"
	echo "Example: $0 journal"
	echo
	echo "Available plugins:"
	echo "(connecting to $URL...)"
	echo
	svn list "$URL"
	echo
	exit 1
fi

svn co "$URL/$PLUGIN" "$PLUGIN"
