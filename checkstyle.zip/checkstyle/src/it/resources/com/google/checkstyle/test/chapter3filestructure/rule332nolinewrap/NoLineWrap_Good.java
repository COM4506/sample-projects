package com.google.checkstyle.test.chapter3filestructure.rule332nolinewrap; //ok

import com.google.common.annotations.Beta; //ok
 
import javax.accessibility.AccessibleAttributeSequence; //ok
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater; //ok

public class NoLineWrap_Good {
    
    public void fooMethod() {
        //
    }
}
