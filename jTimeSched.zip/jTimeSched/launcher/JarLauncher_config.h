/* jTimeSched config file for use with JarLauncher */

#define JAVA_BINARY		"javaw.exe"
#define JAVA_URL		"http://www.java.com/download/"
#define JAVA_VM_OPTS	""
#define JAVA_APP		"jTimeSched.jar"
#define JAVA_APP_OPTS	""
#define JAVA_APP_NAME	"jTimeSched"
