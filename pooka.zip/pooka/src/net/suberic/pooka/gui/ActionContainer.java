package net.suberic.pooka.gui;
import javax.swing.Action;

public interface ActionContainer {
    public Action[] getActions();
}
