package net.suberic.pooka.event;

public interface MessageLoadedListener {
    public void handleMessageLoaded(MessageLoadedEvent e);
}
