*)  If you're going to use Preview Pane mode, you should run with a 
1.3 JDK.  There are a few bugs in the sizing code in JDK 1.2 that can cause
problems in Preview mode.

