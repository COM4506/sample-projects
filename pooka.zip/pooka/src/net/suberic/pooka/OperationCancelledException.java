package net.suberic.pooka;

public class OperationCancelledException extends Exception {

}
