package net.suberic.util;

public interface ValueChangeListener {
    public void valueChanged(String changedValue);
}
