package net.sf.jabref;

/**
 * JabRef MainClass
 */
public class JabRefMain {
    public static void main(String[] args) {
        new JabRef().start(args);
    }
}
